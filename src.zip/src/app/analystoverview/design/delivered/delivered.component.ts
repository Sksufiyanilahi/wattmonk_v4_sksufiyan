import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delivered',
  templateUrl: './delivered.component.html',
  styleUrls: ['./delivered.component.scss'],
})
export class DeliveredComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
