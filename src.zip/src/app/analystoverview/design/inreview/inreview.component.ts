import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inreview',
  templateUrl: './inreview.component.html',
  styleUrls: ['./inreview.component.scss'],
})
export class InreviewComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
