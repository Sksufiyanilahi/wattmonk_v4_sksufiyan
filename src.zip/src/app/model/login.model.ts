import { User } from './user.model';

export class LoginModel {
  jwt: string;
  user: User;
}
