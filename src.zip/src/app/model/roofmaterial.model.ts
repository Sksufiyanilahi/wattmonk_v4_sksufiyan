export class RoofMaterial{
    id: number;
    name: string;
}