export class UserData{
    firstname:string;
    lastname:string;
    role:{
        name:string;
        type:string;
    };
}