import { DesginDataModel } from './design.model';
import { SurveyDataModel } from './survey.model';

export class SearchModel {
  desgin: DesginDataModel[];
  survey: SurveyDataModel[];
}
