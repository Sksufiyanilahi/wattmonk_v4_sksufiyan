export class AnalystStatistics{
    analyst:string;
    totaldesignscreated:number;
    ontimedesignscompleted:number;
    latedesignscompleted: number;
    totaldesigncompletiontime: number;
    avgdesigncompletiontime: any;
    totalreviewfailurecount: number
    avgreviewfailurecount: number
    ratingpoints: number
    monthlyrating: number



}