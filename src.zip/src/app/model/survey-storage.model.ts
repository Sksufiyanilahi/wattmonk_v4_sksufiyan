export class SurveyStorageModel {
  surveyMenu: any;
  formData: any;
  saved: boolean;
  surveyId: number;
}
