export class SolarMake {
    id: number;
    name: string;
    created_at: Date;
    updated_at: Date;
}

export class SolarMakeData {
  
}

