export class DesignStatistic{
    type: string;
    prelim: number;
    permit: number;
}