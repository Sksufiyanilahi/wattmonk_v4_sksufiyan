export class LeftoverImagesModel {
  title: string;
  mainMenuIndex: number;
  subMenuIndex: number
  subMenuImageIndex: number;
  mainMenuImageIndex: number;
}
