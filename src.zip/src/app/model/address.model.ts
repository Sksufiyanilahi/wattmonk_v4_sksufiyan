export class AddressModel {
  address: string;
  lat: number;
  long: number;
  country: string;
  state: string;
  city: string;
  postalcode: string;
}
