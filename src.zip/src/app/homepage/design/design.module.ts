import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DesignRoutingModule } from './design-routing.module';
import { PendingComponent } from './pending/pending.component';
// import { Chooser } from '@ionic-native/chooser/ngx';


@NgModule({
 
  declarations: [],
  imports: [
    CommonModule,
    DesignRoutingModule
    
  ],
  // providers:[]
})
export class DesignModule { }
