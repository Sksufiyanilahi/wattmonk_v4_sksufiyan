import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { PermitschedulePage } from './permitschedule.page';

describe('PermitschedulePage', () => {
  let component: PermitschedulePage;
  let fixture: ComponentFixture<PermitschedulePage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PermitschedulePage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(PermitschedulePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
