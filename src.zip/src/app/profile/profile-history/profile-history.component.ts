import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile-history',
  templateUrl: './profile-history.component.html',
  styleUrls: ['./profile-history.component.scss'],
})
export class ProfileHistoryComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
