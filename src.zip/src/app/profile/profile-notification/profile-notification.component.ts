import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile-notification',
  templateUrl: './profile-notification.component.html',
  styleUrls: ['./profile-notification.component.scss'],
})
export class ProfileNotificationComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
