import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chat-tabs',
  templateUrl: './chat-tabs.page.html',
  styleUrls: ['./chat-tabs.page.scss'],
})
export class ChatTabsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
