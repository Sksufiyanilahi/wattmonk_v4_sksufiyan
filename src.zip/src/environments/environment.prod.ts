export const environment = {
  production: true,
  version:'1.1.0'
};
