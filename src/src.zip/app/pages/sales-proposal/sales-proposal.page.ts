import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sales-proposal',
  templateUrl: './sales-proposal.page.html',
  styleUrls: ['./sales-proposal.page.scss'],
})
export class SalesProposalPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
