import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menu-popup',
  templateUrl: './menu-popup.component.html',
  styleUrls: ['./menu-popup.component.scss'],
})
export class MenuPopupComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
