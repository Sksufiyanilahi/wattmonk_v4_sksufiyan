import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pestamp-design-details',
  templateUrl: './pestamp-design-details.page.html',
  styleUrls: ['./pestamp-design-details.page.scss'],
})
export class PestampDesignDetailsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
