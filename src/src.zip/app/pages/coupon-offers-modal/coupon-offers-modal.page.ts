import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-coupon-offers-modal',
  templateUrl: './coupon-offers-modal.page.html',
  styleUrls: ['./coupon-offers-modal.page.scss'],
})
export class CouponOffersModalPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
