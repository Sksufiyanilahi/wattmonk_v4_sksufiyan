import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-client-schedule',
  templateUrl: './client-schedule.page.html',
  styleUrls: ['./client-schedule.page.scss'],
})
export class ClientSchedulePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
