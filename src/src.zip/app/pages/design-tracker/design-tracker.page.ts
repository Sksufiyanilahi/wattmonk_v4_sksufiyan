import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-design-tracker',
  templateUrl: './design-tracker.page.html',
  styleUrls: ['./design-tracker.page.scss'],
})
export class DesignTrackerPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
