import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-permit-design-details',
  templateUrl: './permit-design-details.page.html',
  styleUrls: ['./permit-design-details.page.scss'],
})
export class PermitDesignDetailsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
