import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-revision',
  templateUrl: './revision.page.html',
  styleUrls: ['./revision.page.scss'],
})
export class RevisionPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
