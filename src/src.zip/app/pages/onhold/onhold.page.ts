import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-onhold',
  templateUrl: './onhold.page.html',
  styleUrls: ['./onhold.page.scss'],
})
export class OnholdPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
