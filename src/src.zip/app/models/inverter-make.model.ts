export class InverterMakeModel {
  id: number;
  name: string;
  created_at: Date;
  updated_at: Date;
  data:any;
}

