export class Clients {
    companyid: number;
    companyname: string;
    parentid: number;
}