export class TimeSlotsModel{
    slotname: any;
    totalsurvey:any;
    isdisabled:any;
    isselected:any;
    value: any
}