export class BatteryModel {
  id: number;
  name: string;
}
