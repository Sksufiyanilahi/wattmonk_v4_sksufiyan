export class UploadedFile {
    id: number;
    name: string;
    url: string;
    ext: string;
}