export class Incentive{
    created_at: Date;
    id: number;
    title: string;
    updated_at: Date;
}