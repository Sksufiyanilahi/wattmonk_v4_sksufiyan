export class BatteryMake {
  id: number;
  name: string;
}