export class AccessRights {
    viewonly: boolean;
    name: string;
    visibility: boolean;
    constantname: string;
}