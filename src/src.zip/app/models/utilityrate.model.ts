export class UtilityRates{
    created_at: Date;
id: number;
rate: string;
updated_at:Date;
utility: any;
utilityrate: any;
}