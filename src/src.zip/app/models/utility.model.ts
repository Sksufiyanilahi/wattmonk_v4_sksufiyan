import { UtilityRates } from "./utilityrate.model";

export class Utility{
    addedby: any;
    city: string;
    created_at: Date;
    id: number;
    lastused: string;
    name: string;
    requirements: string;
    source: string;
    state: string;
    updated_at: Date;
    utilityrates: UtilityRates
}