export class Company{
    companyid:number;
    companyname: string;
    designcount: number;
}