export class Peenginer{
    companyid:number;
    firstname: string;
    lastname: string;
    designcount: number;
}