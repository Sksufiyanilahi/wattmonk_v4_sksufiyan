export class DesignersStatistics {
  totaldesignscreated: number;
  ontimedesignscompleted: number;
  latedesignscompleted: number;
  totaldesigncompletiontime: number;
  avgdesigncompletiontime: any;
  totalreviewfailurecount: number;
  avgreviewfailurecount: number;
  ratingpoints: number;
  monthlyrating: number;
  designer: string;
  avgdesigncompletiontimestamp?: any;
  id?: any;
}
