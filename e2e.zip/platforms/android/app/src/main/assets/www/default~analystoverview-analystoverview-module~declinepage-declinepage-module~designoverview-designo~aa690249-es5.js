function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~analystoverview-analystoverview-module~declinepage-declinepage-module~designoverview-designo~aa690249"], {
  /***/
  "./node_modules/@ionic-native/chooser/ngx/index.js":
  /*!*********************************************************!*\
    !*** ./node_modules/@ionic-native/chooser/ngx/index.js ***!
    \*********************************************************/

  /*! exports provided: Chooser */

  /***/
  function node_modulesIonicNativeChooserNgxIndexJs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Chooser", function () {
      return Chooser;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _ionic_native_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic-native/core */
    "./node_modules/@ionic-native/core/index.js");

    var Chooser =
    /** @class */
    function (_super) {
      Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(Chooser, _super);

      function Chooser() {
        return _super !== null && _super.apply(this, arguments) || this;
      }

      Chooser.prototype.getFile = function (accept) {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "getFile", {}, arguments);
      };

      Chooser.prototype.getFileMetadata = function (accept) {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "getFileMetadata", {}, arguments);
      };

      Chooser.pluginName = "Chooser";
      Chooser.plugin = "cordova-plugin-chooser";
      Chooser.pluginRef = "chooser";
      Chooser.repo = "https://github.com/cyph/cordova-plugin-chooser";
      Chooser.platforms = ["Android", "iOS"];
      Chooser = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])()], Chooser);
      return Chooser;
    }(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["IonicNativePlugin"]); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvQGlvbmljLW5hdGl2ZS9wbHVnaW5zL2Nob29zZXIvbmd4L2luZGV4LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQSxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQzNDLE9BQU8sOEJBQXNDLE1BQU0sb0JBQW9CLENBQUM7O0lBc0QzQywyQkFBaUI7Ozs7SUFRNUMseUJBQU8sYUFBQyxNQUFlO0lBV3ZCLGlDQUFlLGFBQUMsTUFBZTs7Ozs7O0lBbkJwQixPQUFPO1FBRG5CLFVBQVUsRUFBRTtPQUNBLE9BQU87a0JBdkRwQjtFQXVENkIsaUJBQWlCO1NBQWpDLE9BQU8iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBDb3Jkb3ZhLCBJb25pY05hdGl2ZVBsdWdpbiwgUGx1Z2luIH0gZnJvbSAnQGlvbmljLW5hdGl2ZS9jb3JlJztcblxuZXhwb3J0IGludGVyZmFjZSBDaG9vc2VyUmVzdWx0IHtcbiAgZGF0YT86IFVpbnQ4QXJyYXk7XG4gIGRhdGFVUkk/OiBzdHJpbmc7XG4gIG1lZGlhVHlwZTogc3RyaW5nO1xuICBuYW1lOiBzdHJpbmc7XG4gIHVyaTogc3RyaW5nO1xufVxuXG4vKipcbiAqIEBuYW1lIENob29zZXJcbiAqIEBkZXNjcmlwdGlvblxuICogRmlsZSBjaG9vc2VyIHBsdWdpbiBmb3IgQ29yZG92YS5cbiAqXG4gKiBUaGUgZm9sbG93aW5nIG11c3QgYmUgYWRkZWQgdG8gY29uZmlnLnhtbCB0byBwcmV2ZW50IGNyYXNoaW5nIHdoZW4gc2VsZWN0aW5nIGxhcmdlIGZpbGVzIG9uIEFuZHJvaWQ6XG4gKiBgYGB4bWxcbiAqIDxwbGF0Zm9ybSBuYW1lPVwiYW5kcm9pZFwiPlxuICogIDxlZGl0LWNvbmZpZ1xuICogICAgZmlsZT1cImFwcC9zcmMvbWFpbi9BbmRyb2lkTWFuaWZlc3QueG1sXCJcbiAqICAgIG1vZGU9XCJtZXJnZVwiXG4gKiAgICB0YXJnZXQ9XCIvbWFuaWZlc3QvYXBwbGljYXRpb25cIj5cbiAqICAgIDxhcHBsaWNhdGlvbiBhbmRyb2lkOmxhcmdlSGVhcD1cInRydWVcIiAvPlxuICogIDwvZWRpdC1jb25maWc+XG4gKiA8L3BsYXRmb3JtPlxuICogYGBgXG4gKlxuICogQHVzYWdlXG4gKiBgYGB0eXBlc2NyaXB0XG4gKiBpbXBvcnQgeyBDaG9vc2VyIH0gZnJvbSAnQGlvbmljLW5hdGl2ZS9jaG9vc2VyL25neCc7XG4gKlxuICpcbiAqIGNvbnN0cnVjdG9yKHByaXZhdGUgY2hvb3NlcjogQ2hvb3NlcikgeyB9XG4gKlxuICogLi4uXG4gKlxuICpcbiAqIHRoaXMuY2hvb3Nlci5nZXRGaWxlKClcbiAqICAgLnRoZW4oZmlsZSA9PiBjb25zb2xlLmxvZyhmaWxlID8gZmlsZS5uYW1lIDogJ2NhbmNlbGVkJykpXG4gKiAgIC5jYXRjaCgoZXJyb3I6IGFueSkgPT4gY29uc29sZS5lcnJvcihlcnJvcikpO1xuICpcbiAqIGBgYFxuICpcbiAqIEBpbnRlcmZhY2VzXG4gKiBDaG9vc2VyUmVzdWx0XG4gKi9cbkBQbHVnaW4oe1xuICBwbHVnaW5OYW1lOiAnQ2hvb3NlcicsXG4gIHBsdWdpbjogJ2NvcmRvdmEtcGx1Z2luLWNob29zZXInLFxuICBwbHVnaW5SZWY6ICdjaG9vc2VyJyxcbiAgcmVwbzogJ2h0dHBzOi8vZ2l0aHViLmNvbS9jeXBoL2NvcmRvdmEtcGx1Z2luLWNob29zZXInLFxuICBwbGF0Zm9ybXM6IFsnQW5kcm9pZCcsICdpT1MnXSxcbn0pXG5ASW5qZWN0YWJsZSgpXG5leHBvcnQgY2xhc3MgQ2hvb3NlciBleHRlbmRzIElvbmljTmF0aXZlUGx1Z2luIHtcbiAgLyoqXG4gICAqIERpc3BsYXlzIG5hdGl2ZSBwcm9tcHQgZm9yIHVzZXIgdG8gc2VsZWN0IGEgZmlsZS5cbiAgICogQHBhcmFtIHtzdHJpbmd9IFthY2NlcHRdIE9wdGlvbmFsIE1JTUUgdHlwZSBmaWx0ZXIgKGUuZy4gJ2ltYWdlL2dpZix2aWRlby8qJykuXG4gICAqIEByZXR1cm4ge1Byb21pc2U8YW55Pn0gUHJvbWlzZSBjb250YWluaW5nIHNlbGVjdGVkIGZpbGUncyByYXcgYmluYXJ5IGRhdGEsXG4gICAqIGJhc2U2NC1lbmNvZGVkIGRhdGE6IFVSSSwgTUlNRSB0eXBlLCBkaXNwbGF5IG5hbWUsIGFuZCBvcmlnaW5hbCBVUkkuXG4gICAqL1xuICBAQ29yZG92YSgpXG4gIGdldEZpbGUoYWNjZXB0Pzogc3RyaW5nKTogUHJvbWlzZTxDaG9vc2VyUmVzdWx0IHwgdW5kZWZpbmVkPiB7XG4gICAgcmV0dXJuO1xuICB9XG4gIC8qKlxuICAgKiBEaXNwbGF5cyBuYXRpdmUgcHJvbXB0IGZvciB1c2VyIHRvIHNlbGVjdCBhIGZpbGUuXG4gICAqIEBwYXJhbSB7c3RyaW5nfSBbYWNjZXB0XSBPcHRpb25hbCBNSU1FIHR5cGUgZmlsdGVyIChlLmcuICdpbWFnZS9naWYsdmlkZW8vKicpLlxuICAgKiBAcmV0dXJucyB7UHJvbWlzZTxhbnk+fSBQcm9taXNlIGNvbnRhaW5pbmcgc2VsZWN0ZWQgZmlsZSdzIE1JTUUgdHlwZSwgZGlzcGxheSBuYW1lLCBhbmQgb3JpZ2luYWwgVVJJLlxuICAgKiBJZiB1c2VyIGNhbmNlbHMsIHByb21pc2Ugd2lsbCBiZSByZXNvbHZlZCBhcyB1bmRlZmluZWQuXG4gICAqIElmIGVycm9yIG9jY3VycywgcHJvbWlzZSB3aWxsIGJlIHJlamVjdGVkLlxuICAgKi9cbiAgQENvcmRvdmEoKVxuICBnZXRGaWxlTWV0YWRhdGEoYWNjZXB0Pzogc3RyaW5nKTogUHJvbWlzZTxDaG9vc2VyUmVzdWx0IHwgdW5kZWZpbmVkPiB7XG4gICAgcmV0dXJuO1xuICB9XG59XG4iXX0=

    /***/

  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/declinepage/declinepage.page.html":
  /*!*****************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/declinepage/declinepage.page.html ***!
    \*****************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppDeclinepageDeclinepagePageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<!-- <ion-header>\r\n  <ion-toolbar>\r\n    <ion-title>Confirm</ion-title>\r\n  </ion-toolbar>\r\n</ion-header> -->\r\n\r\n<ion-content>\r\n  <ion-grid>\r\n  <h4 style=\"font-weight: bold;margin-bottom:0px !important;padding: 10px;\">Are you sure?</h4>\r\n      <ion-row>\r\n        <ion-col>\r\n          <h6 style=\"margin-top:0px;padding: 2px;\">Please specify the reason</h6>\r\n          <textarea placeholder=\"Reason*\" [(ngModel)]=\"reason\" (input)=\"detectchange()\" style=\"width: 100%;\" required></textarea>\r\n        </ion-col>\r\n      </ion-row>\r\n      <ion-row>\r\n        <ion-col>\r\n          <h6 style=\"margin:0px 0 0px 0;\">Attachment</h6>\r\n        \r\n            <ion-input type=\"text\" placeholder=\"Select Attachment\" [(ngModel)]=\"filename\" readonly (click)=\"selectAttachment()\" style=\"border-bottom:1px solid grey\"  > <ion-icon name=\"attach-outline\" style=\"float: right;text-align:right ;\"></ion-icon></ion-input>\r\n           \r\n         <small *ngIf=\"exceedfileSize > 0\" style=\"color:red\">File size should not be greater than 25MB.</small>\r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-grid>\r\n    <footer style=\"text-align: right;margin:12px;\">\r\n      <ion-button fill=\"clear\" (click)=\"cancel()\">Cancel</ion-button>\r\n      <ion-button fill=\"clear\" (click)=\"submit()\" [disabled]=\"enableDisable\">Submit</ion-button>\r\n    </footer>\r\n  <!-- <div class=_padding>\r\n    <p>Decline the design Request</p>\r\n    <textarea placeholder=\"Reason*\" style=\"width: 100%;\"></textarea>\r\n  </div> -->\r\n</ion-content>\r\n";
    /***/
  },

  /***/
  "./src/app/declinepage/declinepage.page.scss":
  /*!***************************************************!*\
    !*** ./src/app/declinepage/declinepage.page.scss ***!
    \***************************************************/

  /*! exports provided: default */

  /***/
  function srcAppDeclinepageDeclinepagePageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "._padding {\n  padding: 12px;\n}\n\n.modal-wrapper.sc-ion-modal-md {\n  transform: translate3d(0, 40px, 0) !important;\n  opacity: 0.01 !important;\n  height: 50% !important;\n}\n\ntextarea {\n  height: 100px;\n  padding: 7px;\n}\n\nion-grid {\n  padding: 14px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZGVjbGluZXBhZ2UvRjpcXG1vYmlsZWFwcC9zcmNcXGFwcFxcZGVjbGluZXBhZ2VcXGRlY2xpbmVwYWdlLnBhZ2Uuc2NzcyIsInNyYy9hcHAvZGVjbGluZXBhZ2UvZGVjbGluZXBhZ2UucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksYUFBQTtBQ0NKOztBREdBO0VBRUksNkNBQUE7RUFDQSx3QkFBQTtFQUNBLHNCQUFBO0FDQUo7O0FER0E7RUFDSSxhQUFBO0VBQ0EsWUFBQTtBQ0FKOztBREdBO0VBQ0ksYUFBQTtBQ0FKIiwiZmlsZSI6InNyYy9hcHAvZGVjbGluZXBhZ2UvZGVjbGluZXBhZ2UucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLl9wYWRkaW5ne1xyXG4gICAgcGFkZGluZzoxMnB4O1xyXG59XHJcblxyXG5cclxuLm1vZGFsLXdyYXBwZXIuc2MtaW9uLW1vZGFsLW1kIHtcclxuICAgIC13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgwLCA0MHB4LCAwKSAhaW1wb3J0YW50O1xyXG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgwLCA0MHB4LCAwKSAhaW1wb3J0YW50O1xyXG4gICAgb3BhY2l0eTogMC4wMSAhaW1wb3J0YW50O1xyXG4gICAgaGVpZ2h0OiA1MCUgIWltcG9ydGFudDtcclxufVxyXG5cclxudGV4dGFyZWF7XHJcbiAgICBoZWlnaHQ6IDEwMHB4O1xyXG4gICAgcGFkZGluZzogN3B4O1xyXG59XHJcblxyXG5pb24tZ3JpZHtcclxuICAgIHBhZGRpbmc6IDE0cHg7XHJcbn0iLCIuX3BhZGRpbmcge1xuICBwYWRkaW5nOiAxMnB4O1xufVxuXG4ubW9kYWwtd3JhcHBlci5zYy1pb24tbW9kYWwtbWQge1xuICAtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgNDBweCwgMCkgIWltcG9ydGFudDtcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgwLCA0MHB4LCAwKSAhaW1wb3J0YW50O1xuICBvcGFjaXR5OiAwLjAxICFpbXBvcnRhbnQ7XG4gIGhlaWdodDogNTAlICFpbXBvcnRhbnQ7XG59XG5cbnRleHRhcmVhIHtcbiAgaGVpZ2h0OiAxMDBweDtcbiAgcGFkZGluZzogN3B4O1xufVxuXG5pb24tZ3JpZCB7XG4gIHBhZGRpbmc6IDE0cHg7XG59Il19 */";
    /***/
  },

  /***/
  "./src/app/declinepage/declinepage.page.ts":
  /*!*************************************************!*\
    !*** ./src/app/declinepage/declinepage.page.ts ***!
    \*************************************************/

  /*! exports provided: DeclinepagePage */

  /***/
  function srcAppDeclinepageDeclinepagePageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DeclinepagePage", function () {
      return DeclinepagePage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic-native/camera/ngx */
    "./node_modules/@ionic-native/camera/ngx/index.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _api_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ../api.service */
    "./src/app/api.service.ts");
    /* harmony import */


    var _utilities_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ../utilities.service */
    "./src/app/utilities.service.ts");
    /* harmony import */


    var _ionic_native_chooser_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @ionic-native/chooser/ngx */
    "./node_modules/@ionic-native/chooser/ngx/index.js");
    /* harmony import */


    var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! @ionic-native/file/ngx */
    "./node_modules/@ionic-native/file/ngx/index.js");

    var DeclinepagePage = /*#__PURE__*/function () {
      function DeclinepagePage(camera, modalCtrl, apiservice, nav, utilities, chooser, file) {
        _classCallCheck(this, DeclinepagePage);

        this.camera = camera;
        this.modalCtrl = modalCtrl;
        this.apiservice = apiservice;
        this.nav = nav;
        this.utilities = utilities;
        this.chooser = chooser;
        this.file = file;
        this.exceedfileSize = 0;
        this.enableDisable = true;
      }

      _createClass(DeclinepagePage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.id = this.nav.get('id');
          console.log(this.id);
        }
      }, {
        key: "selectAttachment",
        value: function selectAttachment() {
          var _this = this;

          this.exceedfileSize = 0; // const options: CameraOptions = {
          //   quality: 30,
          //   targetWidth:600,
          //   targetHeight:300,
          //   sourceType: this.camera.PictureSourceType.PHOTOLIBRARY,
          //   destinationType: this.camera.DestinationType.DATA_URL,
          //   encodingType: this.camera.EncodingType.PNG,
          //   mediaType: this.camera.MediaType.PICTURE
          // }

          this.chooser.getFile().then(function (file) {
            console.log(file, 'canceled');
            _this.filename = file.name;

            _this.file.resolveLocalFilesystemUrl(file.uri).then(function (fileentry) {
              fileentry.file(function (fileObj) {
                console.log(fileObj);
                _this.blob = fileObj;
                console.log(fileObj.size);

                if (fileObj.size > 1024 * 1024 * 1) {
                  _this.exceedfileSize = fileObj.size;
                  _this.enableDisable = true;
                } else {
                  _this.enableDisable = false;

                  _this.getBase64(fileObj).then(function (res) {
                    var base64file = file.dataURI + res;
                    _this.blob = _this.utilities.b64toBlob(base64file);
                    console.log(_this.blob);
                  });
                }
              });
            });
          })["catch"](function (error) {
            return console.error(error);
          }); // this.camera.getPicture(options).then((imageData) => {
          //   // imageData is either a base64 encoded string or a file URI
          //   // If it's base64 (DATA_URL):
          //   let base64Image = 'data:image/jpeg;base64,' + imageData;
          //   this.blob = this.utilities.b64tBlob(base64Image);
          //   console.log(this.blob);
          //   this.filename = Date.now().toString() + '.png';
          //   if(this.blob){
          //     this.uploadFile();
          //   }
          //  }, (err) => {
          //   // Handle error
          //  })
        }
      }, {
        key: "cancel",
        value: function cancel() {
          this.modalCtrl.dismiss({
            'dismissed': true,
            cancel: 'cancel'
          });
        }
      }, {
        key: "detectchange",
        value: function detectchange() {
          // 26214400
          if (this.reason == undefined || this.reason == '') {
            this.enableDisable = true;
          } else {
            this.enableDisable = false;
          }
        }
      }, {
        key: "submit",
        value: function submit() {
          var _this2 = this;

          if (this.exceedfileSize < 1048576) {
            this.uploadFile();
          } else if (this.filename !== '' && this.exceedfileSize > 1048576) {
            console.log('could not submit');
          } else {
            var data = {
              status: 'requestdeclined',
              requestdeclinereason: this.reason,
              outsourcedto: null,
              isoutsourced: "false"
            };
            console.log(data);
            this.apiservice.updateDesignForm(data, this.id).subscribe(function (res) {
              _this2.modalCtrl.dismiss({
                'dismissed': true
              });
            });
          }
        }
      }, {
        key: "uploadFile",
        value: function uploadFile() {
          var _this3 = this;

          this.utilities.showLoading('Uploading').then(function () {
            _this3.apiservice.uploadDeclineImage(_this3.id, 'prelimdesign', _this3.blob, _this3.filename).subscribe(function (res) {
              _this3.utilities.hideLoading().then(function () {
                var data = {
                  status: 'requestdeclined',
                  requestdeclinereason: _this3.reason,
                  outsourcedto: null,
                  isoutsourced: "false"
                };
                console.log(data);

                _this3.apiservice.updateDesignForm(data, _this3.id).subscribe(function (res) {
                  _this3.modalCtrl.dismiss({
                    'dismissed': true
                  });
                });
              });
            }, function (err) {
              _this3.utilities.errorSnackBar(err.error);

              _this3.utilities.hideLoading();
            });
          });
        }
      }, {
        key: "getBase64",
        value: function getBase64(file) {
          return new Promise(function (resolve, reject) {
            var reader = new FileReader();
            reader.readAsDataURL(file);

            reader.onload = function () {
              var encoded = reader.result.toString().replace(/^data:(.*,)?/, '');

              if (encoded.length % 4 > 0) {
                encoded += '='.repeat(4 - encoded.length % 4);
              }

              resolve(encoded);
            };

            reader.onerror = function (error) {
              return reject(error);
            };
          });
        }
      }]);

      return DeclinepagePage;
    }();

    DeclinepagePage.ctorParameters = function () {
      return [{
        type: _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_2__["Camera"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"]
      }, {
        type: _api_service__WEBPACK_IMPORTED_MODULE_4__["ApiService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavParams"]
      }, {
        type: _utilities_service__WEBPACK_IMPORTED_MODULE_5__["UtilitiesService"]
      }, {
        type: _ionic_native_chooser_ngx__WEBPACK_IMPORTED_MODULE_6__["Chooser"]
      }, {
        type: _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_7__["File"]
      }];
    };

    DeclinepagePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-declinepage',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./declinepage.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/declinepage/declinepage.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./declinepage.page.scss */
      "./src/app/declinepage/declinepage.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_2__["Camera"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"], _api_service__WEBPACK_IMPORTED_MODULE_4__["ApiService"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavParams"], _utilities_service__WEBPACK_IMPORTED_MODULE_5__["UtilitiesService"], _ionic_native_chooser_ngx__WEBPACK_IMPORTED_MODULE_6__["Chooser"], _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_7__["File"]])], DeclinepagePage);
    /***/
  }
}]);
//# sourceMappingURL=default~analystoverview-analystoverview-module~declinepage-declinepage-module~designoverview-designo~aa690249-es5.js.map