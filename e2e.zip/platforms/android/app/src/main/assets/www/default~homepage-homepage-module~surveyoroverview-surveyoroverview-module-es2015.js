(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~homepage-homepage-module~surveyoroverview-surveyoroverview-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/homepage/survey/survey.component.html":
/*!*********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/homepage/survey/survey.component.html ***!
  \*********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content>\r\n    <ion-segment scrollable (ionChange)=\"segmentChanged($event)\" value=\"status=created&status=outsourced&status=requestaccepted\">\r\n        <ion-segment-button value=\"status=created&status=outsourced&status=requestaccepted\">\r\n          <ion-label class=\"segment-btn\">Pending</ion-label>\r\n        </ion-segment-button>\r\n        <ion-segment-button value=\"status=surveyassigned&status=surveyinprocess\">\r\n          <ion-label class=\"segment-btn\">In Progress</ion-label>\r\n        </ion-segment-button>\r\n        <ion-segment-button value=\"status=surveycompleted\">\r\n          <ion-label class=\"segment-btn\">Completed</ion-label>\r\n        </ion-segment-button>\r\n        <ion-segment-button value=\"status=reviewassigned&status=reviewpassed&status=reviewfailed\">\r\n          <ion-label class=\"segment-btn\">Review</ion-label>\r\n        </ion-segment-button>\r\n        <ion-segment-button value=\"status=delivered\">\r\n          <ion-label class=\"segment-btn\">Delivered</ion-label>\r\n        </ion-segment-button>\r\n      </ion-segment>\r\n    <ion-refresher slot=\"fixed\" (ionRefresh)=\"getSurveys($event)\">\r\n        <ion-refresher-content></ion-refresher-content>\r\n    </ion-refresher>\r\n    \r\n       \r\n            <ion-grid *ngIf=\"listOfSurveyDataHelper.length !== 0\">\r\n                <ion-row *ngFor=\"let item of listOfSurveyDataHelper;let i = index\">\r\n                    <ion-col size=\"12\" class=\"ion-margin-top\">\r\n                            <span class=\"ion-padding\" *ngIf=\"today === item.date\">\r\n                                Today\r\n                              </span>\r\n                        <span class=\"ion-padding\" *ngIf=\"today !== item.date\">\r\n                                  {{item.date | date: 'dd MMM yyyy'}}\r\n                            </span>\r\n                    </ion-col>\r\n                    <ion-col *ngFor=\"let surveyData of item.listOfSurveys;let i = index \" size=\"12\">\r\n                        <div class=\"ion-no-padding custom-card\" style=\"height: 100%;\">\r\n                            <p class=\"customer-name\">{{surveyData.name}}\r\n                            <span  [routerLink]=\"['/survey-detail/',surveyData.id]\"\r\n                            routerDirection=\"forward\" class=\"chipdetail\" style=\"background-color: #1289A7;\" [routerLink]=\"['/design-details/',surveyData.id]\" routerDirection=\"forward\">\r\n                              {{surveyData.datetime | date: 'hh:mm a'}}\r\n                          </span>\r\n                          <span  [routerLink]=\"['/survey-detail/',surveyData.id]\"\r\n                          routerDirection=\"forward\" *ngIf=\"surveyData.status=='surveyassigned'\" class=\"chipdetail\" style=\"background-color: #3C78D8;\" [routerLink]=\"['/survey-detail/',surveyData.id]\" routerDirection=\"forward\">\r\n                            pending\r\n                        </span>\r\n                          <span  [routerLink]=\"['/survey-detail/',surveyData.id]\"\r\n                          routerDirection=\"forward\" class=\"chipdetail\" style=\"background-color: rgb(246, 77, 10);\" *ngIf=\"surveyData.lateby > 0\">Overdue</span>\r\n                          <span fill=\"clear\" background-border=\"clear\" [routerLink]=\"['/','activity',surveyData.id,'survey']\" class=\"imagebutton\"  size=\"small\"  ><ion-icon  src=\"/assets/images/activitylist.svg\" ></ion-icon></span>\r\n                         </p>\r\n                  <p style=\"margin:0px\">\r\n\r\n                    <span class=\"customer-email\" [routerLink]=\"['/survey-detail/',surveyData.id]\"\r\n                          routerDirection=\"forward\">{{surveyData.email}}</span>\r\n                          <span *ngIf=\"surveyData.lateby > 1\" class=\"latebystyle\"><strong>Late by {{surveyData.lateby}} days</strong></span>\r\n                          <span *ngIf=\"surveyData.lateby == 1\" class=\"latebystyle\"><strong>Late by a day</strong></span>\r\n                </p>\r\n                            <a href=\"tel:{{surveyData.phonenumber}}\" style=\"text-decoration: none;\" class=\"z-100\">\r\n                                <span class=\"customer-phone\">{{surveyData?.phonenumber}}</span></a>\r\n                            <span class=\"customer-address z-100 m-0\"\r\n                                  (click)=\"openAddressOnMap(surveyData.address)\">{{(surveyData.address | slice:0:60) + (surveyData.address?.length > 60 ? '...' : '')}}</span>\r\n                                  <ion-row style=\"margin-bottom: 8px;\"  [routerLink]=\"['/survey-detail/',surveyData.id]\" class=\"m-0\">\r\n                                    <span class=\"chipdetail\" style=\"background-color: #95afc0;\" >Wattmonk</span>\r\n                                    <span class=\"chipdetail\" style=\"background-color: #95afc0;\" >{{surveyData.formattedjobtype}}</span>\r\n                                   \r\n                                </ion-row>\r\n                            <ion-row class=\"ion-no-margin\">\r\n                                <ion-col></ion-col>\r\n                                <ion-col size=\"auto\" class=\"ion-no-margin ion-no-padding\" *ngIf=\"today==item.date && userData.role.type !=='wattmonkadmins'\">\r\n                                         <ion-button  class=\"ion-no-margin ion-no-padding z-100\" fill=\"clear\" \r\n                                         [routerLink]=\"['/surveyprocess/' + surveyData.id + '/' + surveyData.jobtype + '/' + surveyData.latitude + '/' + surveyData.longitude]\"\r\n                                         routerDirection=\"forward\">\r\n                                         Start Survey\r\n                                         </ion-button>\r\n                                    <!-- <span class=\"ion-text-end action-button-color\" >Start Survey</span> -->\r\n                                </ion-col>\r\n                        <!-- <ion-col></ion-col> -->\r\n                        <ion-col *ngIf=\"segments=='status=created&status=outsourced&status=requestaccepted'\" size=\"auto\" class=\"ion-no-margin ion-no-padding\" style=\"margin-bottom: 5px;\">\r\n                                    <span *ngIf=\"surveyData.status == 'created' || surveyData.status == 'requestaccepted'\" style=\"float:right !important;\" class=\"ion-text-end action-button-color z-100\" (click)=\"openSurveyors(surveyData.id,surveyData)\"\r\n                        >Assign</span>\r\n                        <!-- <span *ngIf=\"surveyData.status == 'outsourced'\" style=\"float:right !important;\" class=\"ion-text-end action-button-color\" (click)=\"openSurveyors(surveyData.id)\"\r\n                        >Decline</span>\r\n                        <span *ngIf=\"surveyData.status == 'outsourced'\" style=\"float:right !important;\" class=\"ion-text-end action-button-color\" (click)=\"openSurveyors(surveyData.id)\"\r\n                        >Accept</span> -->\r\n                        <span style=\"float: right;\">\r\n\r\n                            <ion-col size=\"8\"  *ngIf=\"surveyData.status == 'outsourced'\"  class=\"ion-text-end action-button-color z-100\" (click)=\"openSurveyors(surveyData.id)\">\r\n                               Accept\r\n                            </ion-col>\r\n                            <ion-col size=\"4\" *ngIf=\"surveyData.status == 'outsourced'\"  class=\"ion-text-end action-button-color z-100\" (click)=\"openSurveyors(surveyData.id)\">\r\n                            Decline\r\n                            </ion-col>\r\n                        </span>\r\n                        <span *ngIf=\"surveyData.status == 'requestdeclined'\"style=\"float:right !important;\" class=\"ion-text-end action-button-color z-100\" (click)=\"openSurveyors(surveyData.id)\"\r\n                        >Reassign</span>\r\n                        </ion-col>\r\n                        <ion-col size=\"auto\" class=\"ion-no-margin ion-no-padding\"\r\n                                    *ngIf=\"segments=='status=surveycompleted'\" style=\"margin-bottom: 5px;\">\r\n                            <span *ngIf=\"surveyData.status == 'created' || surveyData.status == 'requestaccepted'\" class=\"ion-text-end action-button-color z-100\"\r\n                                    (click)=\"openAnalysts(surveyData.id,surveyData)\">Assign Review</span>\r\n                        </ion-col>\r\n                        <ion-col size=\"auto\" class=\"ion-no-margin ion-no-padding\"\r\n                                    *ngIf=\"surveyData.status == 'reviewpassed'\">\r\n                            <span class=\"ion-text-end action-button-color z-100\"\r\n                                    (click)=\"openreviewPassed(designData.id,designData)\">Deliver</span>\r\n                        </ion-col>\r\n\r\n                        <ion-col *ngIf=\"segments=='status=delivered'\">\r\n                            <span  style=\"float:right !important;\" class=\"ion-text-end action-button-color\" (click)=\"shareWhatsapp(designData)\">\r\n                                <ion-icon name=\"share-social-outline\"></ion-icon></span>&nbsp;\r\n                            <span style=\"float:right !important;margin-right: 8px;\" class=\"ion-text-end action-button-color\" (click)=\"shareViaEmails(designData.id,designData)\">\r\n                                <ion-icon name=\"mail\" ></ion-icon></span>\r\n                        </ion-col>\r\n                    </ion-row>\r\n                    <!-- <ion-progress-bar [value]=\"1\" mode=\"ios\" color=\"success\" class=\"progress-bar-height\"></ion-progress-bar> -->\r\n                            <!-- <span class=\"ion-text-end timestamp\" [routerLink]=\"['/survey-detail/',surveyData.id]\" routerDirection=\"forward\">\r\n                                {{surveyData.datetime | date: 'hh:mm a'}}\r\n                            </span> -->\r\n        \r\n                        </div>\r\n        \r\n                    </ion-col>\r\n                </ion-row>\r\n                <ion-row>\r\n                    <ion-col size=\"12\" style=\"height: 100px;\">\r\n                    </ion-col>\r\n                </ion-row>\r\n            </ion-grid>\r\n        \r\n            <div *ngIf=\"listOfSurveyDataHelper.length === 0\" class=\"h-100 d-flex flex-column align-center justify-center\">\r\n                <div *ngIf=\"!netSwitch\">\r\n                    No internet Connection\r\n                </div>\r\n                <ion-img src=\"/assets/images/blank.png\" class=\"placeholder\"></ion-img>\r\n            </div>\r\n   \r\n\r\n</ion-content>\r\n\r\n<ion-bottom-drawer [(state)]=\"drawerState\" minimumHeight=\"0\" dockedHeight=\"300\" draggable=\"false\" disableDrag=\"true\"\r\n                   shouldBounce=\"false\" distanceTop=\"0\" class=\"drawer\" style=\"z-index: 9999 !important;\">\r\n    <form [formGroup]=\"assignForm\">\r\n        <ion-grid class=\"drawer\">\r\n            <ion-row>\r\n                <ion-col size=\"12\">\r\n                    <app-user-selector (assigneeData)=getassignedata($event) placeholder=\"assign\" [assignees]=\"listOfAssignees\"\r\n                                       formControlName=\"assignedto\"></app-user-selector>\r\n                </ion-col>\r\n            </ion-row>\r\n            <ion-row style=\"justify-content: flex-end;\">\r\n                <ion-col size=\"auto\" style=\"padding-top: 0px; margin-right: 6px;\">\r\n                    <ion-button class=\"buttom-drawer-button\"  fill=\"clear\" (click)=\"assignToSurveyor()\" >\r\n                        Confirm\r\n                    </ion-button>\r\n                </ion-col>\r\n                <ion-col size=\"auto\">\r\n                    <ion-button class=\"buttom-drawer-button-cancel\" fill=\"clear\" (click)=\"dismissBottomSheet()\">\r\n                        Cancel\r\n                    </ion-button>\r\n                </ion-col>\r\n            </ion-row>\r\n        </ion-grid>\r\n    </form>\r\n\r\n</ion-bottom-drawer>\r\n\r\n");

/***/ }),

/***/ "./src/app/homepage/survey/survey.component.scss":
/*!*******************************************************!*\
  !*** ./src/app/homepage/survey/survey.component.scss ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".custom-card {\n  display: flex;\n  flex-direction: column;\n  background: white;\n  border-radius: 4px !important;\n  box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.3) !important;\n  padding: 8px 12px;\n}\n\n.customer-name {\n  font-size: 1em;\n  color: #434343;\n  font-weight: bold;\n  display: table;\n  margin: 0px;\n}\n\n.customer-email {\n  font-size: 0.8em;\n  color: #B4B4B4;\n}\n\n.customer-phone {\n  font-size: 0.8em;\n  color: #4272B9;\n}\n\n.customer-address {\n  margin-top: 16px;\n  margin-bottom: 16px;\n  font-size: 0.8em;\n  color: #4272B9;\n}\n\n.timestamp {\n  font-size: 0.7em;\n}\n\n.chipdetail {\n  display: inline;\n  vertical-align: middle;\n  background-color: #95afc0;\n  font-size: 0.6em;\n  padding: 4px 10px;\n  border-radius: 10px;\n  text-align: center;\n  color: #fff;\n}\n\n.segment-btn {\n  font-size: 10px !important;\n}\n\n.latebystyle {\n  float: right;\n  font-size: 10px;\n  color: #3C78DB;\n  text-align: right;\n}\n\n.imagebutton {\n  float: right;\n  margin-top: 0px;\n}\n\n.alertClass {\n  background-color: wheat;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaG9tZXBhZ2Uvc3VydmV5L0Y6XFxtb2JpbGVhcHAvc3JjXFxhcHBcXGhvbWVwYWdlXFxzdXJ2ZXlcXHN1cnZleS5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvaG9tZXBhZ2Uvc3VydmV5L3N1cnZleS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGFBQUE7RUFDQSxzQkFBQTtFQUNBLGlCQUFBO0VBQ0EsNkJBQUE7RUFDQSxxREFBQTtFQUNBLGlCQUFBO0FDQ0Y7O0FERUE7RUFDRSxjQUFBO0VBQ0EsY0FBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtFQUNBLFdBQUE7QUNDRjs7QURFQTtFQUNFLGdCQUFBO0VBQ0EsY0FBQTtBQ0NGOztBREVBO0VBQ0UsZ0JBQUE7RUFDQSxjQUFBO0FDQ0Y7O0FERUE7RUFDRSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0FDQ0Y7O0FETUE7RUFDRSxnQkFBQTtBQ0hGOztBRE1BO0VBQ0UsZUFBQTtFQUNBLHNCQUFBO0VBQ0EseUJBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7QUNIRjs7QURNQTtFQUNFLDBCQUFBO0FDSEY7O0FETUE7RUFDRSxZQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtBQ0hGOztBREtBO0VBQ0UsWUFBQTtFQUNBLGVBQUE7QUNGRjs7QURPQTtFQUNFLHVCQUFBO0FDSkYiLCJmaWxlIjoic3JjL2FwcC9ob21lcGFnZS9zdXJ2ZXkvc3VydmV5LmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmN1c3RvbS1jYXJkIHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgYmFja2dyb3VuZDogd2hpdGU7XHJcbiAgYm9yZGVyLXJhZGl1czogNHB4ICFpbXBvcnRhbnQ7XHJcbiAgYm94LXNoYWRvdzogMCAxcHggMnB4IDAgcmdiYSgwLCAwLCAwLCAwLjMpICFpbXBvcnRhbnQ7XHJcbiAgcGFkZGluZzogOHB4IDEycHg7XHJcbn1cclxuXHJcbi5jdXN0b21lci1uYW1lIHtcclxuICBmb250LXNpemU6IDFlbTtcclxuICBjb2xvcjogIzQzNDM0MztcclxuICBmb250LXdlaWdodDogYm9sZDtcclxuICBkaXNwbGF5OnRhYmxlO1xyXG4gIG1hcmdpbjogMHB4O1xyXG59XHJcblxyXG4uY3VzdG9tZXItZW1haWwge1xyXG4gIGZvbnQtc2l6ZTogMC44ZW07XHJcbiAgY29sb3I6ICNCNEI0QjQ7XHJcbn1cclxuXHJcbi5jdXN0b21lci1waG9uZSB7XHJcbiAgZm9udC1zaXplOiAwLjhlbTtcclxuICBjb2xvcjogIzQyNzJCOTtcclxufVxyXG5cclxuLmN1c3RvbWVyLWFkZHJlc3Mge1xyXG4gIG1hcmdpbi10b3A6IDE2cHg7XHJcbiAgbWFyZ2luLWJvdHRvbTogMTZweDtcclxuICBmb250LXNpemU6IDAuOGVtO1xyXG4gIGNvbG9yOiAjNDI3MkI5O1xyXG59XHJcblxyXG4ucGxhY2Vob2xkZXIge1xyXG4gIC8vIHdpZHRoOiA1MHZ3ICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi50aW1lc3RhbXAge1xyXG4gIGZvbnQtc2l6ZTogMC43ZW07XHJcbn1cclxuXHJcbi5jaGlwZGV0YWlse1xyXG4gIGRpc3BsYXk6IGlubGluZTtcclxuICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICM5NWFmYzA7XHJcbiAgZm9udC1zaXplOiAwLjZlbTtcclxuICBwYWRkaW5nOiA0cHggMTBweDtcclxuICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBjb2xvcjogI2ZmZjtcclxufVxyXG5cclxuLnNlZ21lbnQtYnRue1xyXG4gIGZvbnQtc2l6ZTogMTBweCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4ubGF0ZWJ5c3R5bGV7XHJcbiAgZmxvYXQ6IHJpZ2h0OyBcclxuICBmb250LXNpemU6IDEwcHg7XHJcbiAgY29sb3I6ICMzQzc4REI7XHJcbiAgdGV4dC1hbGlnbjogcmlnaHQ7XHJcbn1cclxuLmltYWdlYnV0dG9ue1xyXG4gIGZsb2F0OnJpZ2h0O1xyXG4gIG1hcmdpbi10b3A6IDBweDtcclxuICBcclxuICBcclxufVxyXG5cclxuLmFsZXJ0Q2xhc3N7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogd2hlYXQ7XHJcbn0iLCIuY3VzdG9tLWNhcmQge1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICBiYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgYm9yZGVyLXJhZGl1czogNHB4ICFpbXBvcnRhbnQ7XG4gIGJveC1zaGFkb3c6IDAgMXB4IDJweCAwIHJnYmEoMCwgMCwgMCwgMC4zKSAhaW1wb3J0YW50O1xuICBwYWRkaW5nOiA4cHggMTJweDtcbn1cblxuLmN1c3RvbWVyLW5hbWUge1xuICBmb250LXNpemU6IDFlbTtcbiAgY29sb3I6ICM0MzQzNDM7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICBkaXNwbGF5OiB0YWJsZTtcbiAgbWFyZ2luOiAwcHg7XG59XG5cbi5jdXN0b21lci1lbWFpbCB7XG4gIGZvbnQtc2l6ZTogMC44ZW07XG4gIGNvbG9yOiAjQjRCNEI0O1xufVxuXG4uY3VzdG9tZXItcGhvbmUge1xuICBmb250LXNpemU6IDAuOGVtO1xuICBjb2xvcjogIzQyNzJCOTtcbn1cblxuLmN1c3RvbWVyLWFkZHJlc3Mge1xuICBtYXJnaW4tdG9wOiAxNnB4O1xuICBtYXJnaW4tYm90dG9tOiAxNnB4O1xuICBmb250LXNpemU6IDAuOGVtO1xuICBjb2xvcjogIzQyNzJCOTtcbn1cblxuLnRpbWVzdGFtcCB7XG4gIGZvbnQtc2l6ZTogMC43ZW07XG59XG5cbi5jaGlwZGV0YWlsIHtcbiAgZGlzcGxheTogaW5saW5lO1xuICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjOTVhZmMwO1xuICBmb250LXNpemU6IDAuNmVtO1xuICBwYWRkaW5nOiA0cHggMTBweDtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBjb2xvcjogI2ZmZjtcbn1cblxuLnNlZ21lbnQtYnRuIHtcbiAgZm9udC1zaXplOiAxMHB4ICFpbXBvcnRhbnQ7XG59XG5cbi5sYXRlYnlzdHlsZSB7XG4gIGZsb2F0OiByaWdodDtcbiAgZm9udC1zaXplOiAxMHB4O1xuICBjb2xvcjogIzNDNzhEQjtcbiAgdGV4dC1hbGlnbjogcmlnaHQ7XG59XG5cbi5pbWFnZWJ1dHRvbiB7XG4gIGZsb2F0OiByaWdodDtcbiAgbWFyZ2luLXRvcDogMHB4O1xufVxuXG4uYWxlcnRDbGFzcyB7XG4gIGJhY2tncm91bmQtY29sb3I6IHdoZWF0O1xufSJdfQ== */");

/***/ }),

/***/ "./src/app/homepage/survey/survey.component.ts":
/*!*****************************************************!*\
  !*** ./src/app/homepage/survey/survey.component.ts ***!
  \*****************************************************/
/*! exports provided: SurveyComponent, SurveyDataHelper */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SurveyComponent", function() { return SurveyComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SurveyDataHelper", function() { return SurveyDataHelper; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var src_app_utilities_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/utilities.service */ "./src/app/utilities.service.ts");
/* harmony import */ var src_app_api_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/api.service */ "./src/app/api.service.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/launch-navigator/ngx */ "./node_modules/@ionic-native/launch-navigator/ngx/index.js");
/* harmony import */ var ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ion-bottom-drawer */ "./node_modules/ion-bottom-drawer/fesm2015/ion-bottom-drawer.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var src_app_storage_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/storage.service */ "./src/app/storage.service.ts");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm2015/ionic-storage.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var src_app_networkdetect_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/networkdetect.service */ "./src/app/networkdetect.service.ts");
/* harmony import */ var src_app_email_model_email_model_page__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! src/app/email-model/email-model.page */ "./src/app/email-model/email-model.page.ts");
/* harmony import */ var _ionic_native_social_sharing_ngx__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @ionic-native/social-sharing/ngx */ "./node_modules/@ionic-native/social-sharing/ngx/index.js");
















let SurveyComponent = class SurveyComponent {
    constructor(utils, alertController, socialsharing, modalController, apiService, datePipe, navController, launchNavigator, formBuilder, cdr, router, route, storage, storageService, network) {
        this.utils = utils;
        this.alertController = alertController;
        this.socialsharing = socialsharing;
        this.modalController = modalController;
        this.apiService = apiService;
        this.datePipe = datePipe;
        this.navController = navController;
        this.launchNavigator = launchNavigator;
        this.formBuilder = formBuilder;
        this.cdr = cdr;
        this.router = router;
        this.route = route;
        this.storage = storage;
        this.storageService = storageService;
        this.network = network;
        this.listOfSurveyData = [];
        this.listOfSurveyDataHelper = [];
        this.options = {
            start: '',
            app: this.launchNavigator.APP.GOOGLE_MAPS
        };
        this.drawerState = ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_7__["DrawerState"].Bottom;
        this.surveyId = 0;
        this.showBottomDraw = false;
        this.listOfAssignees = [];
        this.segments = 'status=created&status=outsourced&status=requestaccepted';
        const latestDate = new Date();
        this.today = datePipe.transform(latestDate, 'M/dd/yy');
        console.log('date', this.today);
        this.assignForm = this.formBuilder.group({
            assignedto: new _angular_forms__WEBPACK_IMPORTED_MODULE_8__["FormControl"](0, [_angular_forms__WEBPACK_IMPORTED_MODULE_8__["Validators"].required]),
            status: new _angular_forms__WEBPACK_IMPORTED_MODULE_8__["FormControl"]('surveyassigned', [_angular_forms__WEBPACK_IMPORTED_MODULE_8__["Validators"].required])
        });
    }
    segmentChanged(event) {
        this.segments = event.target.value;
        // this.getSurveys(event);
        // this.surveyRefreshSubscription = this.utils.getHomepageSurveyRefresh().subscribe((result) => {
        this.getSurveys(null);
        // });
        // this.dataRefreshSubscription = this.utils.getDataRefresh().subscribe((result) => {
        //   if(this.listOfSurveyData != null && this.listOfSurveyData.length > 0){
        //     this.formatSurveyData(this.listOfSurveyData);
        //   }
        // });
    }
    ionViewDidEnter() {
        this.network.networkDisconnect();
        this.network.networkConnect();
        this.network.networkSwitch.subscribe(data => {
            this.netSwitch = data;
            console.log(this.netSwitch);
        });
        // this.surveyRefreshSubscription = this.utils.getHomepageSurveyRefresh().subscribe((result) => {
        //   this.getSurveys(null);
        // });
        // this.dataRefreshSubscription = this.utils.getDataRefresh().subscribe((result) => {
        //   if(this.listOfSurveyData != null && this.listOfSurveyData.length > 0){
        //     this.formatSurveyData(this.listOfSurveyData);
        //   }
        // });
        // debugger;
        // this.routeSubscription.unsubscribe();
    }
    ngOnInit() {
        this.userData = this.storageService.getUser();
        console.log(this.userData);
        this.surveyRefreshSubscription = this.utils.getHomepageSurveyRefresh().subscribe((result) => {
            this.getSurveys(null);
        });
    }
    // ngOnInit() {
    //   // this.filterData(this.filterDataArray);
    //   // this.routeSubscription = this.router.events.subscribe((event) => {
    //   //   if (event instanceof NavigationEnd) {
    //   //     // Trick the Router into believing it's last link wasn't previously loaded
    //   //     if (this.router.url.indexOf('page') > -1) {
    //   //       this.router.navigated = false;
    //   //       let data = this.route.queryParams.subscribe((_res: any) => {
    //   //         console.log('Serach Term', _res);
    //   //         if (Object.keys(_res).length !== 0) {
    //   //           //  this.ApplysearchDesginAndSurvey(_res.serchTerm)
    //   //           this.filterData(_res.serchTerm);
    //   //         } else {
    //   //           // this.refreshSubscription = this.utils.getHomepageDesignRefresh().subscribe((result) => {
    //   //             // debugger;
    //   //             this.getSurveys(null);
    //   //           // });
    //   //         }
    //   //       });
    //   //     }
    //   //   }
    //   // });
    //   // console.log('inside init');
    //   // this.routeSubscription = this.router.events.subscribe((event) => {
    //   //   if (event instanceof NavigationEnd) {
    //   //     // Trick the Router into believing it's last link wasn't previously loaded
    //   //     if (this.router.url.indexOf('page') > -1) {
    //   //       this.router.navigated = false;
    //   //       const data = this.route.queryParams.subscribe((_res: any) => {
    //   //         console.log('Search Term', _res);
    //   //         if (Object.keys(_res).length !== 0) {
    //   //           //  this.ApplysearchDesginAndSurvey(_res.serchTerm)
    //   //           this.filterData(_res.serchTerm);
    //   //         } else {
    //   //           this.surveyRefreshSubscription = this.utils.getHomepageSurveyRefresh().subscribe((result) => {
    //   //             this.getSurveys(null);
    //   //           });
    //   //         }
    //   //       });
    //   //     }
    //   //   }
    //   // });
    // }
    getSurveys(event) {
        let showLoader = true;
        if (event != null && event !== undefined) {
            showLoader = false;
        }
        this.fetchPendingSurveys(event, showLoader);
    }
    fetchPendingSurveys(event, showLoader) {
        this.listOfSurveyData = [];
        this.listOfSurveyDataHelper = [];
        this.utils.showLoadingWithPullRefreshSupport(showLoader, 'Getting Surveys').then((success) => {
            this.apiService.getSurveyorSurveys(this.segments).subscribe(response => {
                this.utils.hideLoadingWithPullRefreshSupport(showLoader).then(() => {
                    console.log(response);
                    this.formatSurveyData(response);
                    if (event !== null) {
                        event.target.complete();
                    }
                });
            }, responseError => {
                this.utils.hideLoadingWithPullRefreshSupport(showLoader).then(() => {
                    if (event !== null) {
                        event.target.complete();
                    }
                    const error = responseError.error;
                    this.utils.errorSnackBar(error.message[0].messages[0].message);
                });
            });
        });
    }
    // filterData(serchTerm: any) {
    //   console.log(this.listOfSurveyData);
    //   this.filterDataArray = this.listOfSurveyData.filter(x => x.id == serchTerm);
    //   const tempData: SurveyDataHelper[] = [];
    //   this.filterDataArray.forEach((surveyItem) => {
    //     if (tempData.length === 0) {
    //       const listOfSurvey = new SurveyDataHelper();
    //       listOfSurvey.date = this.datePipe.transform(surveyItem.created_at, 'M/d/yy');
    //       listOfSurvey.listOfSurveys.push(surveyItem);
    //       tempData.push(listOfSurvey);
    //     } else {
    //       let added = false;
    //       tempData.forEach((surveyList) => {
    //         if (!added) {
    //           if (surveyList.date === this.datePipe.transform(surveyItem.created_at, 'M/d/yy')) {
    //             surveyList.listOfSurveys.push(surveyItem);
    //             added = true;
    //           }
    //         }
    //       });
    //       if (!added) {
    //         const listOfSurvey = new SurveyDataHelper();
    //         listOfSurvey.date = this.datePipe.transform(surveyItem.created_at, 'M/d/yy');
    //         listOfSurvey.listOfSurveys.push(surveyItem);
    //         tempData.push(listOfSurvey);
    //         added = true;
    //       }
    //     }
    //   });
    //   this.listOfSurveyDataHelper = tempData;
    //   this.cdr.detectChanges();
    // }
    formatSurveyData(records) {
        this.listOfSurveyData = this.fillinDynamicData(records);
        console.log(this.listOfSurveyData);
        const tempData = [];
        this.listOfSurveyData.forEach((surveyItem, i) => {
            this.sDatePassed(surveyItem.datetime, i);
            surveyItem.lateby = this.overdue;
            if (tempData.length === 0) {
                const listOfSurvey = new SurveyDataHelper();
                listOfSurvey.date = this.datePipe.transform(surveyItem.datetime, 'M/dd/yy');
                listOfSurvey.listOfSurveys.push(surveyItem);
                tempData.push(listOfSurvey);
            }
            else {
                let added = false;
                tempData.forEach((surveyList) => {
                    if (!added) {
                        if (surveyList.date === this.datePipe.transform(surveyItem.datetime, 'M/dd/yy')) {
                            surveyList.listOfSurveys.push(surveyItem);
                            added = true;
                        }
                    }
                });
                if (!added) {
                    const listOfSurvey = new SurveyDataHelper();
                    listOfSurvey.date = this.datePipe.transform(surveyItem.datetime, 'M/dd/yy');
                    listOfSurvey.listOfSurveys.push(surveyItem);
                    tempData.push(listOfSurvey);
                    added = true;
                }
            }
        });
        this.listOfSurveyDataHelper = tempData.sort(function (a, b) {
            var dateA = new Date(a.date).getTime(), dateB = new Date(b.date).getTime();
            return dateB - dateA;
        });
        this.cdr.detectChanges();
    }
    fillinDynamicData(records) {
        records.forEach(element => {
            element.formattedjobtype = this.utils.getJobTypeName(element.jobtype);
            this.storage.get('' + element.id).then((data) => {
                console.log(data);
                if (data) {
                    element.totalpercent = data.currentprogress;
                }
                else {
                    element.totalpercent = 0;
                }
            });
        });
        return records;
    }
    ngOnDestroy() {
        this.surveyRefreshSubscription.unsubscribe();
    }
    // getSurvey(event, showLoader: boolean) {
    //   this.listOfSurveyData = [];
    //   this.listOfSurveyDataHelper = [];
    //   this.utils.showLoadingWithPullRefreshSupport(showLoader, 'Getting Surveys').then((success) => {
    //     this.apiService.getSurvey().subscribe(response => {
    //       this.utils.hideLoadingWithPullRefreshSupport(showLoader).then(() => {
    //         if (event !== null) {
    //           event.target.complete();
    //         }
    //         console.log(response);
    //         this.listOfSurveyData = response;
    //         const tempData: SurveyDataHelper[] = [];
    //         this.listOfSurveyData.forEach((surveyItem) => {
    //           if (tempData.length === 0) {
    //             const listOfSurvey = new SurveyDataHelper();
    //             listOfSurvey.date = this.datePipe.transform(surveyItem.datetime, 'M/d/yy');
    //             listOfSurvey.listOfSurveys.push(surveyItem);
    //             tempData.push(listOfSurvey);
    //           } else {
    //             let added = false;
    //             tempData.forEach((surveyList) => {
    //               if (!added) {
    //                 if (surveyList.date === this.datePipe.transform(surveyItem.datetime, 'M/d/yy')) {
    //                   surveyList.listOfSurveys.push(surveyItem);
    //                   added = true;
    //                 }
    //               }
    //             });
    //             if (!added) {
    //               const listOfSurvey = new SurveyDataHelper();
    //               listOfSurvey.date = this.datePipe.transform(surveyItem.datetime, 'M/d/yy');
    //               listOfSurvey.listOfSurveys.push(surveyItem);
    //               tempData.push(listOfSurvey);
    //               added = true;
    //             }
    //           }
    //         });
    //         this.listOfSurveyDataHelper = tempData;
    //         this.cdr.detectChanges();
    //       });
    //     }, responseError => {
    //       this.utils.hideLoadingWithPullRefreshSupport(showLoader).then(() => {
    //         if (event !== null) {
    //           event.target.complete();
    //         }
    //         const error: ErrorModel = responseError.error;
    //         this.utils.errorSnackBar(error.message[0].messages[0].message);
    //       });
    //     });
    //   });
    // }
    // getSurveyorSurveys(event, showLoader: boolean) {
    //   this.listOfSurveyData = [];
    //   this.listOfSurveyDataHelper = [];
    //   this.utils.showLoadingWithPullRefreshSupport(showLoader, 'Getting Surveys').then((success) => {
    //     this.apiService.getSurveyorSurveys("").subscribe(response => {
    //       this.utils.hideLoadingWithPullRefreshSupport(showLoader).then(() => {
    //         if (event !== null) {
    //           event.target.complete();
    //         }
    //         console.log(response);
    //         this.listOfSurveyData = response;
    //         const tempData: SurveyDataHelper[] = [];
    //         this.listOfSurveyData.forEach((surveyItem) => {
    //           if (tempData.length === 0) {
    //             const listOfSurvey = new SurveyDataHelper();
    //             listOfSurvey.date = this.datePipe.transform(surveyItem.datetime, 'M/d/yy');
    //             listOfSurvey.listOfSurveys.push(surveyItem);
    //             tempData.push(listOfSurvey);
    //           } else {
    //             let added = false;
    //             tempData.forEach((surveyList) => {
    //               if (!added) {
    //                 if (surveyList.date === this.datePipe.transform(surveyItem.datetime, 'M/d/yy')) {
    //                   surveyList.listOfSurveys.push(surveyItem);
    //                   added = true;
    //                 }
    //               }
    //             });
    //             if (!added) {
    //               const listOfSurvey = new SurveyDataHelper();
    //               listOfSurvey.date = this.datePipe.transform(surveyItem.datetime, 'M/d/yy');
    //               listOfSurvey.listOfSurveys.push(surveyItem);
    //               tempData.push(listOfSurvey);
    //               added = true;
    //             }
    //           }
    //         });
    //         this.listOfSurveyDataHelper = tempData;
    //         this.cdr.detectChanges();
    //       });
    //     }, responseError => {
    //       this.utils.hideLoadingWithPullRefreshSupport(showLoader).then(() => {
    //         if (event !== null) {
    //           event.target.complete();
    //         }
    //         const error: ErrorModel = responseError.error;
    //         this.utils.errorSnackBar(error.message[0].messages[0].message);
    //       });
    //     });
    //   });
    // }
    openAddressOnMap(address) {
        this.launchNavigator.navigate(address, this.options);
    }
    dismissBottomSheet() {
        this.drawerState = ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_7__["DrawerState"].Bottom;
        this.utils.setBottomBarHomepage(true);
    }
    assignToSurveyor() {
        if (this.assignForm.status === 'INVALID') {
            this.utils.errorSnackBar('Please select a surveyor');
        }
        else {
            var designstarttime = new Date();
            var milisecond = designstarttime.getTime();
            var additonalhours = 0;
            if (this.surveyData.requesttype == "prelim") {
                console.log(parseInt(this.selectedDesigner.jobcount));
                additonalhours = parseInt(this.selectedDesigner.jobcount) * 2;
                designstarttime.setHours(designstarttime.getHours() + additonalhours);
            }
            else {
                additonalhours = parseInt(this.selectedDesigner.jobcount) * 6;
                designstarttime.setHours(designstarttime.getHours() + additonalhours);
            }
            console.log(this.selectedDesigner);
            var postData = {};
            if (this.surveyData.createdby.id == this.userData.id) {
                if (this.selectedDesigner.company == this.userData.company) {
                    if (this.selectedDesigner.role.type == "qcinspector") {
                        postData = {
                            reviewassignedto: this.selectedDesigner.id,
                            status: "reviewassigned",
                            reviewstarttime: milisecond
                        };
                    }
                    if (this.selectedDesigner.role.type == "surveyor") {
                        postData = {
                            designassignedto: this.selectedDesigner.id,
                            isoutsourced: "false",
                            status: "surveyassigned",
                            designstarttime: designstarttime
                        };
                    }
                }
                else {
                    postData = {
                        outsourcedto: this.selectedDesigner.id,
                        isoutsourced: "true",
                        status: "outsourced"
                    };
                }
            }
            else {
                if (this.selectedDesigner.role.type == "surveyor") {
                    postData = {
                        designassignedto: this.selectedDesigner.id,
                        status: "surveyassigned",
                        designstarttime: designstarttime
                    };
                }
                if (this.selectedDesigner.role.type == "qcinspector") {
                    postData = {
                        reviewassignedto: this.selectedDesigner.id,
                        status: "reviewassigned",
                        reviewstarttime: milisecond
                    };
                }
            }
            this.utils.showLoading('Assigning').then(() => {
                this.apiService.updateSurveyForm(postData, this.surveyId).subscribe((value) => {
                    this.utils.hideLoading().then(() => {
                        ;
                        console.log('reach ', value);
                        this.utils.showSnackBar('Survey request has been assigned to' + ' ' + value.name + ' ' + 'successfully');
                        this.dismissBottomSheet();
                        this.showBottomDraw = false;
                        this.utils.setHomepageDesignRefresh(true);
                    });
                }, (error) => {
                    this.utils.hideLoading();
                    this.dismissBottomSheet();
                    this.showBottomDraw = false;
                });
            });
        }
    }
    openAnalysts(id, surveyData) {
        this.surveyData = surveyData;
        if (this.listOfAssignees.length === 0) {
            this.utils.showLoading('Getting Analysts').then(() => {
                this.apiService.getAnalysts().subscribe(assignees => {
                    this.utils.hideLoading().then(() => {
                        this.listOfAssignees = [];
                        // this.listOfAssignees.push(this.utils.getDefaultAssignee(this.storage.getUserID()));
                        assignees.forEach(item => this.listOfAssignees.push(item));
                        console.log(this.listOfAssignees);
                        this.showBottomDraw = true;
                        this.surveyId = id;
                        this.utils.setBottomBarHomepage(false);
                        this.drawerState = ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_7__["DrawerState"].Docked;
                        this.assignForm.patchValue({
                            assignedto: ''
                        });
                    });
                }, (error) => {
                    this.utils.hideLoading().then(() => {
                        this.utils.errorSnackBar('Some error occurred. Please try again later');
                    });
                });
            });
        }
        else {
            this.surveyId = id;
            this.utils.setBottomBarHomepage(false);
            this.drawerState = ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_7__["DrawerState"].Docked;
            this.assignForm.patchValue({
                assignedto: ''
            });
        }
    }
    openSurveyors(id, surveyData) {
        this.surveyData = surveyData;
        if (this.listOfAssignees.length === 0) {
            this.utils.showLoading('Getting Surveyors').then(() => {
                this.apiService.getSurveyors().subscribe(assignees => {
                    this.utils.hideLoading().then(() => {
                        this.listOfAssignees = [];
                        // this.listOfAssignees.push(this.utils.getDefaultAssignee(this.storage.getUserID()));
                        assignees.forEach(item => this.listOfAssignees.push(item));
                        console.log(this.listOfAssignees);
                        this.showBottomDraw = true;
                        this.surveyId = id;
                        this.utils.setBottomBarHomepage(false);
                        this.drawerState = ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_7__["DrawerState"].Docked;
                        this.assignForm.patchValue({
                            assignedto: ''
                        });
                    });
                }, (error) => {
                    this.utils.hideLoading().then(() => {
                        this.utils.errorSnackBar('Some error occurred. Please try again later');
                    });
                });
            });
        }
        else {
            this.surveyId = id;
            this.utils.setBottomBarHomepage(false);
            this.drawerState = ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_7__["DrawerState"].Docked;
            this.assignForm.patchValue({
                assignedto: ''
            });
        }
    }
    // getSurveys(event: CustomEvent) {
    //   let showLoader = true;
    //   if (event != null && event !== undefined) {
    //     showLoader = false;
    //   }
    //   if (this.storage.getUser().role.id === ROLES.Surveyor) {
    //     this.getSurveyorSurveys(event, showLoader);
    //   } else {
    //     this.getSurvey(event, showLoader);
    //   }
    // }
    sDatePassed(datestring, i) {
        var checkdate = moment__WEBPACK_IMPORTED_MODULE_12__(datestring, "YYYYMMDD");
        var todaydate = moment__WEBPACK_IMPORTED_MODULE_12__(new Date(), "YYYYMMDD");
        var lateby = todaydate.diff(checkdate, "days");
        this.overdue = lateby;
        console.log(this.overdue, ">>>>>>>>>>>>>>>>>.");
    }
    getassignedata(asssignedata) {
        this.selectedDesigner = asssignedata;
    }
    openreviewPassed(id, designData) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.surveyId = id;
            const alert = yield this.alertController.create({
                cssClass: 'alertClass',
                header: 'Confirm!',
                message: 'Would you like to  Add Comments!!',
                inputs: [{ name: 'comment',
                        id: 'comment',
                        type: 'textarea',
                        placeholder: 'Enter Comment' }
                ],
                buttons: [
                    {
                        text: 'Cancel',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: (blah) => {
                            console.log('Confirm Cancel: blah');
                        }
                    }, {
                        text: 'deliver',
                        handler: (alertData) => {
                            var postData = {};
                            if (alertData.comment != "") {
                                postData = {
                                    status: "delivered",
                                    comments: alertData.comment,
                                };
                            }
                            else {
                                postData = {
                                    status: "delivered",
                                };
                            }
                            console.log(postData);
                            this.apiService.updateSurveyForm(postData, this.surveyId).subscribe((value) => {
                                this.utils.hideLoading().then(() => {
                                    ;
                                    console.log('reach ', value);
                                    this.utils.showSnackBar('Survey request has been delivered successfully');
                                    this.utils.setHomepageDesignRefresh(true);
                                });
                            }, (error) => {
                                this.utils.hideLoading();
                                ;
                            });
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    hareWhatsapp(designData) {
        this.socialsharing.share(designData.prelimdesign.url);
    }
    shareViaEmails(id, designData) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: src_app_email_model_email_model_page__WEBPACK_IMPORTED_MODULE_14__["EmailModelPage"],
                cssClass: 'email-modal-css',
                componentProps: {
                    id: id,
                    designData: designData
                },
            });
            modal.onDidDismiss().then((data) => {
                console.log(data);
                if (data.data.cancel == 'cancel') {
                }
                else {
                    this.getSurveys(null);
                }
            });
            return yield modal.present();
        });
    }
};
SurveyComponent.ctorParameters = () => [
    { type: src_app_utilities_service__WEBPACK_IMPORTED_MODULE_2__["UtilitiesService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["AlertController"] },
    { type: _ionic_native_social_sharing_ngx__WEBPACK_IMPORTED_MODULE_15__["SocialSharing"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ModalController"] },
    { type: src_app_api_service__WEBPACK_IMPORTED_MODULE_3__["ApiService"] },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_4__["DatePipe"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["NavController"] },
    { type: _ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_6__["LaunchNavigator"] },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_8__["FormBuilder"] },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_9__["Router"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_9__["ActivatedRoute"] },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_11__["Storage"] },
    { type: src_app_storage_service__WEBPACK_IMPORTED_MODULE_10__["StorageService"] },
    { type: src_app_networkdetect_service__WEBPACK_IMPORTED_MODULE_13__["NetworkdetectService"] }
];
SurveyComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-survey',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./survey.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/homepage/survey/survey.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./survey.component.scss */ "./src/app/homepage/survey/survey.component.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_utilities_service__WEBPACK_IMPORTED_MODULE_2__["UtilitiesService"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["AlertController"],
        _ionic_native_social_sharing_ngx__WEBPACK_IMPORTED_MODULE_15__["SocialSharing"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ModalController"],
        src_app_api_service__WEBPACK_IMPORTED_MODULE_3__["ApiService"],
        _angular_common__WEBPACK_IMPORTED_MODULE_4__["DatePipe"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["NavController"],
        _ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_6__["LaunchNavigator"],
        _angular_forms__WEBPACK_IMPORTED_MODULE_8__["FormBuilder"],
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"],
        _angular_router__WEBPACK_IMPORTED_MODULE_9__["Router"],
        _angular_router__WEBPACK_IMPORTED_MODULE_9__["ActivatedRoute"],
        _ionic_storage__WEBPACK_IMPORTED_MODULE_11__["Storage"],
        src_app_storage_service__WEBPACK_IMPORTED_MODULE_10__["StorageService"],
        src_app_networkdetect_service__WEBPACK_IMPORTED_MODULE_13__["NetworkdetectService"]])
], SurveyComponent);

class SurveyDataHelper {
    constructor() {
        this.listOfSurveys = [];
    }
}


/***/ })

}]);
//# sourceMappingURL=default~homepage-homepage-module~surveyoroverview-surveyoroverview-module-es2015.js.map