function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["change-password-change-password-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/change-password/change-password.page.html":
  /*!*************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/change-password/change-password.page.html ***!
    \*************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppChangePasswordChangePasswordPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header class=\"ion-no-border\">\r\n    <ion-grid class=\"ion-padding header-bg\">\r\n        <ion-row>\r\n            <!-- <ion-col size=\"auto\">\r\n                <ion-button fill=\"clear\" size=\"small\" class=\"ion-no-padding\" (click)=\"goBack()\">\r\n                    <ion-img src=\"/assets/images/back.svg\" class=\"action-icon\"></ion-img>\r\n                </ion-button>\r\n            </ion-col> -->\r\n            <ion-col>\r\n                <ion-grid class=\"ion-align-items-center ion-justify-content-center\">\r\n                    <ion-row class=\"ion-align-items-center ion-justify-content-center\">\r\n                        <span class=\"title\">Change password</span>\r\n                    </ion-row>\r\n                </ion-grid>\r\n            </ion-col>\r\n            <!-- <ion-col size=\"auto\">\r\n                <ion-button fill=\"clear\" disabled=\"true\" size=\"small\" class=\"ion-no-padding action-icon\">\r\n                </ion-button>\r\n            </ion-col> -->\r\n        </ion-row>\r\n    </ion-grid>\r\n\r\n    <ion-grid class=\"position-relative ion-no-padding\">\r\n        <ion-row class=\"ion-no-padding border-header header-half-height\">\r\n        </ion-row>\r\n        <ion-row class=\"ion-no-padding header-half-height\">\r\n        </ion-row>\r\n        <ion-row class=\"ion-no-padding position-absolute header-icon-position full-width\">\r\n        </ion-row>\r\n    </ion-grid>\r\n</ion-header>\r\n<ion-content>\r\n    <div class=\"ion-padding\">\r\n        <ion-grid class=\"ion-padding\">\r\n            <form [formGroup]=\"changepassword\" novalidate>\r\n                <ion-row>\r\n                    <ion-col size=\"12\">\r\n                        <span class=\"title-text font-color\">Welcome!</span>\r\n                    </ion-col>\r\n                    <ion-col size=\"12\">\r\n                        <span class=\"normal-text font-color\">Let us help you yo set a new password instead of using a default one.</span>\r\n                    </ion-col>\r\n\r\n                    <ion-col size=\"12\" class=\"ion-margin-top ion-no-padding\">\r\n                        <ion-item class=\"ion-no-padding\">\r\n                            <!-- <div class=\"password_box\"> -->\r\n                                <ion-input type=\"password\" class=\"password_input font-color\" [type]=\"getType()\" placeholder=\"new password*\" formControlName=\"newpassword\">\r\n                                </ion-input>\r\n                                <div class=\"eye_box\">\r\n                                    <ion-icon name=\"eye\" (click)=\"toggleTextPassword()\" slot=\"end\"></ion-icon>\r\n                                </div>\r\n                            <!-- </div> -->\r\n                        </ion-item>\r\n                        <ion-item class=\"ion-no-padding\">\r\n                            <!-- <div class=\"password_box\"> -->\r\n                                <ion-input type=\"password\" class=\"password_input font-color\" [type]=\"getnewType()\" placeholder=\"confirm password*\" formControlName=\"confirmpassword\">\r\n                                </ion-input>\r\n                                <div class=\"eye_box\">\r\n                                    <ion-icon name=\"eye\" (click)=\"toggleTextnewPassword()\" slot=\"end\"></ion-icon>\r\n                                </div>\r\n                            <!-- </div> -->\r\n                        </ion-item>\r\n                    </ion-col>\r\n              \r\n                      <!-- <ion-row> -->\r\n                        <ion-col size=\"12\" class=\"large-margin\">\r\n                            <span class=\"ion-padding-top ion-padding-bottom submit-text action-button-color\"\r\n                                  (click)=\"resetPassword()\">Continue</span>\r\n                        </ion-col>\r\n                      <!-- </ion-row> -->\r\n\r\n                </ion-row>\r\n            </form>\r\n        </ion-grid>\r\n    </div>\r\n\r\n</ion-content>\r\n";
    /***/
  },

  /***/
  "./src/app/change-password/change-password-routing.module.ts":
  /*!*******************************************************************!*\
    !*** ./src/app/change-password/change-password-routing.module.ts ***!
    \*******************************************************************/

  /*! exports provided: ChangePasswordPageRoutingModule */

  /***/
  function srcAppChangePasswordChangePasswordRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ChangePasswordPageRoutingModule", function () {
      return ChangePasswordPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _change_password_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./change-password.page */
    "./src/app/change-password/change-password.page.ts");

    var routes = [{
      path: '',
      component: _change_password_page__WEBPACK_IMPORTED_MODULE_3__["ChangePasswordPage"]
    }];

    var ChangePasswordPageRoutingModule = function ChangePasswordPageRoutingModule() {
      _classCallCheck(this, ChangePasswordPageRoutingModule);
    };

    ChangePasswordPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], ChangePasswordPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/change-password/change-password.module.ts":
  /*!***********************************************************!*\
    !*** ./src/app/change-password/change-password.module.ts ***!
    \***********************************************************/

  /*! exports provided: ChangePasswordPageModule */

  /***/
  function srcAppChangePasswordChangePasswordModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ChangePasswordPageModule", function () {
      return ChangePasswordPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _change_password_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./change-password-routing.module */
    "./src/app/change-password/change-password-routing.module.ts");
    /* harmony import */


    var _change_password_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./change-password.page */
    "./src/app/change-password/change-password.page.ts");

    var ChangePasswordPageModule = function ChangePasswordPageModule() {
      _classCallCheck(this, ChangePasswordPageModule);
    };

    ChangePasswordPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _change_password_routing_module__WEBPACK_IMPORTED_MODULE_5__["ChangePasswordPageRoutingModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"]],
      declarations: [_change_password_page__WEBPACK_IMPORTED_MODULE_6__["ChangePasswordPage"]]
    })], ChangePasswordPageModule);
    /***/
  },

  /***/
  "./src/app/change-password/change-password.page.scss":
  /*!***********************************************************!*\
    !*** ./src/app/change-password/change-password.page.scss ***!
    \***********************************************************/

  /*! exports provided: default */

  /***/
  function srcAppChangePasswordChangePasswordPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".title {\n  font-size: 22px;\n  text-align: center;\n  color: #666666;\n}\n\n* {\n  color: #9A9A9A;\n}\n\n.password_box {\n  display: flex;\n  border-bottom: 1px solid #ced4da !important;\n}\n\n.eye_box {\n  display: flex;\n  align-items: center;\n}\n\n.password_input {\n  margin-bottom: -5px;\n}\n\n.image-area {\n  margin-top: 1em;\n  width: 3em;\n  height: 3em;\n  background: white;\n  border-radius: 0.5em;\n  box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.5);\n}\n\n.small-padding {\n  padding: 8px;\n}\n\n.title-text {\n  font-size: 25px;\n}\n\n.normal-text {\n  font-size: 1em;\n}\n\n.large-margin {\n  margin-top: 3em;\n}\n\n.small-text {\n  font-size: 0.95em;\n}\n\n.smaller-text {\n  font-size: 0.85em;\n}\n\n.submit-text {\n  font-size: 1.5em;\n}\n\nol {\n  -webkit-padding-start: 20px;\n          padding-inline-start: 20px;\n  -webkit-margin-before: 0;\n          margin-block-start: 0;\n  -webkit-margin-after: 0;\n          margin-block-end: 0;\n}\n\n.error {\n  color: #df3e3e;\n  font-size: 11px;\n}\n\n.error1 {\n  color: #4b4b4b;\n  border-bottom: 1px solid #ff0000;\n}\n\n.font-color {\n  color: #111;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY2hhbmdlLXBhc3N3b3JkL0Y6XFxtb2JpbGVhcHAvc3JjXFxhcHBcXGNoYW5nZS1wYXNzd29yZFxcY2hhbmdlLXBhc3N3b3JkLnBhZ2Uuc2NzcyIsInNyYy9hcHAvY2hhbmdlLXBhc3N3b3JkL2NoYW5nZS1wYXNzd29yZC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxjQUFBO0FDQ0o7O0FERUU7RUFDRSxjQUFBO0FDQ0o7O0FEQ0U7RUFDRSxhQUFBO0VBQ0EsMkNBQUE7QUNFSjs7QURFRTtFQUNFLGFBQUE7RUFDQSxtQkFBQTtBQ0NKOztBREVFO0VBQ0UsbUJBQUE7QUNDSjs7QURFRTtFQUNFLGVBQUE7RUFDQSxVQUFBO0VBQ0EsV0FBQTtFQUNBLGlCQUFBO0VBQ0Esb0JBQUE7RUFDQSwwQ0FBQTtBQ0NKOztBREVFO0VBQ0UsWUFBQTtBQ0NKOztBREVFO0VBQ0UsZUFBQTtBQ0NKOztBREVFO0VBQ0UsY0FBQTtBQ0NKOztBREVFO0VBQ0UsZUFBQTtBQ0NKOztBREVFO0VBQ0UsaUJBQUE7QUNDSjs7QURFRTtFQUNFLGlCQUFBO0FDQ0o7O0FERUU7RUFDRSxnQkFBQTtBQ0NKOztBREVFO0VBQ0UsMkJBQUE7VUFBQSwwQkFBQTtFQUNBLHdCQUFBO1VBQUEscUJBQUE7RUFDQSx1QkFBQTtVQUFBLG1CQUFBO0FDQ0o7O0FERUU7RUFDRSxjQUFBO0VBQ0EsZUFBQTtBQ0NKOztBREVFO0VBQ0UsY0FBQTtFQUNBLGdDQUFBO0FDQ0o7O0FERUU7RUFDRSxXQUFBO0FDQ0oiLCJmaWxlIjoic3JjL2FwcC9jaGFuZ2UtcGFzc3dvcmQvY2hhbmdlLXBhc3N3b3JkLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi50aXRsZSB7XHJcbiAgICBmb250LXNpemU6IDIycHg7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBjb2xvcjogIzY2NjY2NjtcclxuICB9XHJcbiAgXHJcbiAgKiB7XHJcbiAgICBjb2xvcjogIzlBOUE5QTtcclxuICB9XHJcbiAgLnBhc3N3b3JkX2JveCB7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNjZWQ0ZGEgIWltcG9ydGFudDtcclxuICBcclxuICB9XHJcblxyXG4gIC5leWVfYm94IHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIH1cclxuICBcclxuICAucGFzc3dvcmRfaW5wdXQge1xyXG4gICAgbWFyZ2luLWJvdHRvbTogLTVweDtcclxuICB9XHJcbiAgXHJcbiAgLmltYWdlLWFyZWEge1xyXG4gICAgbWFyZ2luLXRvcDogMWVtO1xyXG4gICAgd2lkdGg6IDNlbTtcclxuICAgIGhlaWdodDogM2VtO1xyXG4gICAgYmFja2dyb3VuZDogd2hpdGU7XHJcbiAgICBib3JkZXItcmFkaXVzOiAwLjVlbTtcclxuICAgIGJveC1zaGFkb3c6IDAgMXB4IDNweCAwIHJnYmEoMCwgMCwgMCwgMC41KTtcclxuICB9XHJcbiAgXHJcbiAgLnNtYWxsLXBhZGRpbmcge1xyXG4gICAgcGFkZGluZzogOHB4O1xyXG4gIH1cclxuICBcclxuICAudGl0bGUtdGV4dCB7XHJcbiAgICBmb250LXNpemU6IDI1cHg7XHJcbiAgfVxyXG4gIFxyXG4gIC5ub3JtYWwtdGV4dCB7XHJcbiAgICBmb250LXNpemU6IDFlbTtcclxuICB9XHJcbiAgXHJcbiAgLmxhcmdlLW1hcmdpbiB7XHJcbiAgICBtYXJnaW4tdG9wOiAzZW07XHJcbiAgfVxyXG4gIFxyXG4gIC5zbWFsbC10ZXh0IHtcclxuICAgIGZvbnQtc2l6ZTogMC45NWVtO1xyXG4gIH1cclxuICBcclxuICAuc21hbGxlci10ZXh0IHtcclxuICAgIGZvbnQtc2l6ZTogMC44NWVtO1xyXG4gIH1cclxuICBcclxuICAuc3VibWl0LXRleHQge1xyXG4gICAgZm9udC1zaXplOiAxLjVlbTtcclxuICB9XHJcbiAgXHJcbiAgb2wge1xyXG4gICAgcGFkZGluZy1pbmxpbmUtc3RhcnQ6IDIwcHg7XHJcbiAgICBtYXJnaW4tYmxvY2stc3RhcnQ6IDA7XHJcbiAgICBtYXJnaW4tYmxvY2stZW5kOiAwO1xyXG4gIH1cclxuICBcclxuICAuZXJyb3Ige1xyXG4gICAgY29sb3I6IHJnYigyMjMsIDYyLCA2Mik7XHJcbiAgICBmb250LXNpemU6IDExcHg7XHJcbiAgfVxyXG4gIFxyXG4gIC5lcnJvcjEge1xyXG4gICAgY29sb3I6IHJnYig3NSwgNzUsIDc1KTtcclxuICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZmYwMDAwO1xyXG4gIH1cclxuXHJcbiAgLmZvbnQtY29sb3J7XHJcbiAgICBjb2xvcjojMTExO1xyXG4gIH1cclxuICAiLCIudGl0bGUge1xuICBmb250LXNpemU6IDIycHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgY29sb3I6ICM2NjY2NjY7XG59XG5cbioge1xuICBjb2xvcjogIzlBOUE5QTtcbn1cblxuLnBhc3N3b3JkX2JveCB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjY2VkNGRhICFpbXBvcnRhbnQ7XG59XG5cbi5leWVfYm94IHtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbn1cblxuLnBhc3N3b3JkX2lucHV0IHtcbiAgbWFyZ2luLWJvdHRvbTogLTVweDtcbn1cblxuLmltYWdlLWFyZWEge1xuICBtYXJnaW4tdG9wOiAxZW07XG4gIHdpZHRoOiAzZW07XG4gIGhlaWdodDogM2VtO1xuICBiYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgYm9yZGVyLXJhZGl1czogMC41ZW07XG4gIGJveC1zaGFkb3c6IDAgMXB4IDNweCAwIHJnYmEoMCwgMCwgMCwgMC41KTtcbn1cblxuLnNtYWxsLXBhZGRpbmcge1xuICBwYWRkaW5nOiA4cHg7XG59XG5cbi50aXRsZS10ZXh0IHtcbiAgZm9udC1zaXplOiAyNXB4O1xufVxuXG4ubm9ybWFsLXRleHQge1xuICBmb250LXNpemU6IDFlbTtcbn1cblxuLmxhcmdlLW1hcmdpbiB7XG4gIG1hcmdpbi10b3A6IDNlbTtcbn1cblxuLnNtYWxsLXRleHQge1xuICBmb250LXNpemU6IDAuOTVlbTtcbn1cblxuLnNtYWxsZXItdGV4dCB7XG4gIGZvbnQtc2l6ZTogMC44NWVtO1xufVxuXG4uc3VibWl0LXRleHQge1xuICBmb250LXNpemU6IDEuNWVtO1xufVxuXG5vbCB7XG4gIHBhZGRpbmctaW5saW5lLXN0YXJ0OiAyMHB4O1xuICBtYXJnaW4tYmxvY2stc3RhcnQ6IDA7XG4gIG1hcmdpbi1ibG9jay1lbmQ6IDA7XG59XG5cbi5lcnJvciB7XG4gIGNvbG9yOiAjZGYzZTNlO1xuICBmb250LXNpemU6IDExcHg7XG59XG5cbi5lcnJvcjEge1xuICBjb2xvcjogIzRiNGI0YjtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNmZjAwMDA7XG59XG5cbi5mb250LWNvbG9yIHtcbiAgY29sb3I6ICMxMTE7XG59Il19 */";
    /***/
  },

  /***/
  "./src/app/change-password/change-password.page.ts":
  /*!*********************************************************!*\
    !*** ./src/app/change-password/change-password.page.ts ***!
    \*********************************************************/

  /*! exports provided: ChangePasswordPage */

  /***/
  function srcAppChangePasswordChangePasswordPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ChangePasswordPage", function () {
      return ChangePasswordPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_storage__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/storage */
    "./node_modules/@ionic/storage/fesm2015/ionic-storage.js");
    /* harmony import */


    var _storage_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ../storage.service */
    "./src/app/storage.service.ts");
    /* harmony import */


    var _utilities_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ../utilities.service */
    "./src/app/utilities.service.ts");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _api_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ../api.service */
    "./src/app/api.service.ts");
    /* harmony import */


    var _model_constants__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! ../model/constants */
    "./src/app/model/constants.ts");

    var ChangePasswordPage = /*#__PURE__*/function () {
      function ChangePasswordPage(formBuilder, utils, navController, apiService, storage, deviceStorage) {
        _classCallCheck(this, ChangePasswordPage);

        this.formBuilder = formBuilder;
        this.utils = utils;
        this.navController = navController;
        this.apiService = apiService;
        this.storage = storage;
        this.deviceStorage = deviceStorage; // error messages from constants

        this.emailError = _model_constants__WEBPACK_IMPORTED_MODULE_8__["INVALID_EMAIL_MESSAGE"];
        this.fieldRequired = _model_constants__WEBPACK_IMPORTED_MODULE_8__["FIELD_REQUIRED"];
      }

      _createClass(ChangePasswordPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.password = localStorage.getItem('password');
          this.changepassword = this.formBuilder.group({
            newpassword: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(6)]),
            oldpassword: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(6)),
            confirmpassword: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(6))
          });
        }
      }, {
        key: "toggleTextPassword",
        value: function toggleTextPassword() {
          this.isActiveToggleTextPassword = this.isActiveToggleTextPassword == true ? false : true;
        }
      }, {
        key: "toggleTextnewPassword",
        value: function toggleTextnewPassword() {
          this.isActiveToggleTextnewPassword = this.isActiveToggleTextnewPassword == true ? false : true;
        }
      }, {
        key: "getType",
        value: function getType() {
          return this.isActiveToggleTextPassword ? 'text' : 'password';
        }
      }, {
        key: "getnewType",
        value: function getnewType() {
          return this.isActiveToggleTextnewPassword ? 'text' : 'password';
        }
      }, {
        key: "resetPassword",
        value: function resetPassword() {
          var _this = this;

          var data = {
            newpassword: this.changepassword.controls.newpassword.value,
            confirmpassword: this.changepassword.controls.confirmpassword.value,
            oldpassword: this.password
          };
          console.log(data, ">>>>>>>>>>>>>>>>.");

          if (this.changepassword.status === 'VALID') {
            console.log(this.changepassword.value);
            this.utils.showLoading('Resetting password').then(function () {
              _this.apiService.changepassword(data).subscribe(function (response) {
                console.log(response);
                var postdata = {
                  isdefaultpassword: false
                };

                _this.utils.hideLoading().then(function () {
                  _this.utils.showSnackBar('Your password has been changed successfully!'); //  this.utils.showSuccessModal('User password changed successfully!').then((modal) => {
                  //  this.apiService.updateresetpassword(response.user.id,postdata).subscribe(res=>{
                  //   console.log(res,"ressss");
                  //  },err=>{
                  //       console.log(err,"errr");
                  //  })
                  //  modal.present();
                  //  modal.onWillDismiss().then((dismissed) => {
                  // this.goBack();


                  _this.storage.logout();

                  _this.deviceStorage.clear();

                  _this.navController.navigateBack('login'); //  });
                  //  }, (responseError) => {
                  //   const error: ErrorModel = responseError.error;
                  //   this.utils.errorSnackBar(error.message[0].messages[0].message);
                  //  });

                });
              }, function (responseError) {
                var error = responseError.error;

                _this.utils.hideLoading().then(function () {
                  _this.utils.errorSnackBar(error.message[0].messages[0].message);
                });
              });
            });
          } else {
            this.utils.errorSnackBar('Invalid Password entered.');
          }
        }
      }, {
        key: "goBack",
        value: function goBack() {
          this.navController.pop();
        }
      }]);

      return ChangePasswordPage;
    }();

    ChangePasswordPage.ctorParameters = function () {
      return [{
        type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"]
      }, {
        type: _utilities_service__WEBPACK_IMPORTED_MODULE_5__["UtilitiesService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["NavController"]
      }, {
        type: _api_service__WEBPACK_IMPORTED_MODULE_7__["ApiService"]
      }, {
        type: _storage_service__WEBPACK_IMPORTED_MODULE_4__["StorageService"]
      }, {
        type: _ionic_storage__WEBPACK_IMPORTED_MODULE_3__["Storage"]
      }];
    };

    ChangePasswordPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-change-password',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./change-password.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/change-password/change-password.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./change-password.page.scss */
      "./src/app/change-password/change-password.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"], _utilities_service__WEBPACK_IMPORTED_MODULE_5__["UtilitiesService"], _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["NavController"], _api_service__WEBPACK_IMPORTED_MODULE_7__["ApiService"], _storage_service__WEBPACK_IMPORTED_MODULE_4__["StorageService"], _ionic_storage__WEBPACK_IMPORTED_MODULE_3__["Storage"]])], ChangePasswordPage);
    /***/
  }
}]);
//# sourceMappingURL=change-password-change-password-module-es5.js.map