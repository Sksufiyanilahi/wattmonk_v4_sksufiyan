function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["stripe-stripe-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/stripe/stripe.page.html":
  /*!*******************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/stripe/stripe.page.html ***!
    \*******************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppStripeStripePageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\r\n  <ion-toolbar>\r\n    <ion-title>Payment</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <ion-grid>\r\n    <ion-row>\r\n      <ion-col>\r\n        <ion-label>Debit/Credit Card Details</ion-label>\r\n        <ion-input type=\"number\" [(ngModel)]=\"card.number\" style=\"border: 1px solid black;\"></ion-input>\r\n      </ion-col>\r\n    </ion-row>\r\n    <ion-row>\r\n      <ion-col size=\"1\">\r\n      </ion-col>\r\n      <ion-col size=\"3\">\r\n        <ion-label style=\"font-size: 13px;\">Expiry Month</ion-label>\r\n        <ion-input type=\"number\" [(ngModel)]=\"card.expMonth\" style=\"border: 1px solid black;\" max=\"2\" [maxlength]=\"2\"></ion-input>\r\n      </ion-col>\r\n      <ion-col size=\"1\"  style=\"text-align: center;display: flex;align-self: flex-end;justify-content: center;font-size: 40px;\">\r\n        <ion-label>/</ion-label>\r\n      </ion-col>\r\n      <ion-col size=\"3\" style=\"text-align: center;\">\r\n        <ion-label >Year</ion-label>\r\n        <ion-input type=\"number\" [(ngModel)]=\"card.expYear\" style=\"border: 1px solid black;\" max=\"4\" [maxlength]=\"4\"></ion-input>\r\n      </ion-col>\r\n      <ion-col size=\"3\" style=\"text-align: center;\">\r\n        <ion-label>CVV</ion-label>\r\n        <ion-input type=\"number\" [(ngModel)]=\"card.cvc\" style=\"border: 1px solid black;\" max=\"3\" [maxlength]=\"3\"></ion-input>\r\n      </ion-col>\r\n      <ion-col size=\"2\">\r\n     \r\n      </ion-col>\r\n\r\n    </ion-row>\r\n  </ion-grid>\r\n\r\n</ion-content>\r\n";
    /***/
  },

  /***/
  "./src/app/stripe/stripe-routing.module.ts":
  /*!*************************************************!*\
    !*** ./src/app/stripe/stripe-routing.module.ts ***!
    \*************************************************/

  /*! exports provided: StripePageRoutingModule */

  /***/
  function srcAppStripeStripeRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "StripePageRoutingModule", function () {
      return StripePageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _stripe_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./stripe.page */
    "./src/app/stripe/stripe.page.ts");

    var routes = [{
      path: '',
      component: _stripe_page__WEBPACK_IMPORTED_MODULE_3__["StripePage"]
    }];

    var StripePageRoutingModule = function StripePageRoutingModule() {
      _classCallCheck(this, StripePageRoutingModule);
    };

    StripePageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], StripePageRoutingModule);
    /***/
  },

  /***/
  "./src/app/stripe/stripe.module.ts":
  /*!*****************************************!*\
    !*** ./src/app/stripe/stripe.module.ts ***!
    \*****************************************/

  /*! exports provided: StripePageModule */

  /***/
  function srcAppStripeStripeModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "StripePageModule", function () {
      return StripePageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _stripe_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./stripe-routing.module */
    "./src/app/stripe/stripe-routing.module.ts");
    /* harmony import */


    var _stripe_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./stripe.page */
    "./src/app/stripe/stripe.page.ts");

    var StripePageModule = function StripePageModule() {
      _classCallCheck(this, StripePageModule);
    };

    StripePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _stripe_routing_module__WEBPACK_IMPORTED_MODULE_5__["StripePageRoutingModule"]],
      declarations: [_stripe_page__WEBPACK_IMPORTED_MODULE_6__["StripePage"]]
    })], StripePageModule);
    /***/
  },

  /***/
  "./src/app/stripe/stripe.page.scss":
  /*!*****************************************!*\
    !*** ./src/app/stripe/stripe.page.scss ***!
    \*****************************************/

  /*! exports provided: default */

  /***/
  function srcAppStripeStripePageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3N0cmlwZS9zdHJpcGUucGFnZS5zY3NzIn0= */";
    /***/
  },

  /***/
  "./src/app/stripe/stripe.page.ts":
  /*!***************************************!*\
    !*** ./src/app/stripe/stripe.page.ts ***!
    \***************************************/

  /*! exports provided: StripePage */

  /***/
  function srcAppStripeStripePageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "StripePage", function () {
      return StripePage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _ionic_native_stripe_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic-native/stripe/ngx */
    "./node_modules/@ionic-native/stripe/ngx/index.js");

    var StripePage = /*#__PURE__*/function () {
      function StripePage(stripe) {
        _classCallCheck(this, StripePage);

        this.stripe = stripe;
      }

      _createClass(StripePage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "stripepayment",
        value: function stripepayment() {
          this.stripe.setPublishableKey("pk_test_51HUoT7EmzMn44Mbmtqd3Sfx1knRySaWxgTuOAbVlsGFmS0zVpfLnkpzDL32sZcV116MCpI3vKA2E3Zw9WEopsnFu00pyCDs0sq");
          var card = {
            number: '4242424242424242',
            expMonth: 12,
            expYear: 2020,
            cvc: '220'
          };
          this.stripe.createCardToken(this.card).then(function (token) {
            return console.log(token.id);
          })["catch"](function (error) {
            return console.error(error);
          });
        }
      }]);

      return StripePage;
    }();

    StripePage.ctorParameters = function () {
      return [{
        type: _ionic_native_stripe_ngx__WEBPACK_IMPORTED_MODULE_2__["Stripe"]
      }];
    };

    StripePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-stripe',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./stripe.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/stripe/stripe.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./stripe.page.scss */
      "./src/app/stripe/stripe.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_native_stripe_ngx__WEBPACK_IMPORTED_MODULE_2__["Stripe"]])], StripePage);
    /***/
  }
}]);
//# sourceMappingURL=stripe-stripe-module-es5.js.map