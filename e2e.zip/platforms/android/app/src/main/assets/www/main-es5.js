function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"], {
  /***/
  "./$$_lazy_route_resource lazy recursive":
  /*!******************************************************!*\
    !*** ./$$_lazy_route_resource lazy namespace object ***!
    \******************************************************/

  /*! no static exports found */

  /***/
  function $$_lazy_route_resourceLazyRecursive(module, exports) {
    function webpackEmptyAsyncContext(req) {
      // Here Promise.resolve().then() is used instead of new Promise() to prevent
      // uncaught exception popping up in devtools
      return Promise.resolve().then(function () {
        var e = new Error("Cannot find module '" + req + "'");
        e.code = 'MODULE_NOT_FOUND';
        throw e;
      });
    }

    webpackEmptyAsyncContext.keys = function () {
      return [];
    };

    webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
    module.exports = webpackEmptyAsyncContext;
    webpackEmptyAsyncContext.id = "./$$_lazy_route_resource lazy recursive";
    /***/
  },

  /***/
  "./node_modules/@ionic/core/dist/esm lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$ exclude: \\.system\\.entry\\.js$":
  /*!*****************************************************************************************************************************************!*\
    !*** ./node_modules/@ionic/core/dist/esm lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
    \*****************************************************************************************************************************************/

  /*! no static exports found */

  /***/
  function node_modulesIonicCoreDistEsmLazyRecursiveEntryJs$IncludeEntryJs$ExcludeSystemEntryJs$(module, exports, __webpack_require__) {
    var map = {
      "./ion-action-sheet.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-action-sheet.entry.js", "common", 0],
      "./ion-alert.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-alert.entry.js", "common", 1],
      "./ion-app_8.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-app_8.entry.js", "common", 2],
      "./ion-avatar_3.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-avatar_3.entry.js", "common", 3],
      "./ion-back-button.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-back-button.entry.js", "common", 4],
      "./ion-backdrop.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-backdrop.entry.js", 5],
      "./ion-button_2.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-button_2.entry.js", "common", 6],
      "./ion-card_5.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-card_5.entry.js", "common", 7],
      "./ion-checkbox.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-checkbox.entry.js", "common", 8],
      "./ion-chip.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-chip.entry.js", "common", 9],
      "./ion-col_3.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-col_3.entry.js", 10],
      "./ion-datetime_3.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-datetime_3.entry.js", "common", 11],
      "./ion-fab_3.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-fab_3.entry.js", "common", 12],
      "./ion-img.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-img.entry.js", 13],
      "./ion-infinite-scroll_2.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-infinite-scroll_2.entry.js", 14],
      "./ion-input.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-input.entry.js", "common", 15],
      "./ion-item-option_3.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-item-option_3.entry.js", "common", 16],
      "./ion-item_8.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-item_8.entry.js", "common", 17],
      "./ion-loading.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-loading.entry.js", "common", 18],
      "./ion-menu_3.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-menu_3.entry.js", "common", 19],
      "./ion-modal.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-modal.entry.js", "common", 20],
      "./ion-nav_2.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-nav_2.entry.js", "common", 21],
      "./ion-popover.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-popover.entry.js", "common", 22],
      "./ion-progress-bar.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-progress-bar.entry.js", "common", 23],
      "./ion-radio_2.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-radio_2.entry.js", "common", 24],
      "./ion-range.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-range.entry.js", "common", 25],
      "./ion-refresher_2.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-refresher_2.entry.js", "common", 26],
      "./ion-reorder_2.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-reorder_2.entry.js", "common", 27],
      "./ion-ripple-effect.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-ripple-effect.entry.js", 28],
      "./ion-route_4.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-route_4.entry.js", "common", 29],
      "./ion-searchbar.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-searchbar.entry.js", "common", 30],
      "./ion-segment_2.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-segment_2.entry.js", "common", 31],
      "./ion-select_3.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-select_3.entry.js", "common", 32],
      "./ion-slide_2.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-slide_2.entry.js", 33],
      "./ion-spinner.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-spinner.entry.js", "common", 34],
      "./ion-split-pane.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-split-pane.entry.js", 35],
      "./ion-tab-bar_2.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-tab-bar_2.entry.js", "common", 36],
      "./ion-tab_2.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-tab_2.entry.js", "common", 37],
      "./ion-text.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-text.entry.js", "common", 38],
      "./ion-textarea.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-textarea.entry.js", "common", 39],
      "./ion-toast.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-toast.entry.js", "common", 40],
      "./ion-toggle.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-toggle.entry.js", "common", 41],
      "./ion-virtual-scroll.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-virtual-scroll.entry.js", 42]
    };

    function webpackAsyncContext(req) {
      if (!__webpack_require__.o(map, req)) {
        return Promise.resolve().then(function () {
          var e = new Error("Cannot find module '" + req + "'");
          e.code = 'MODULE_NOT_FOUND';
          throw e;
        });
      }

      var ids = map[req],
          id = ids[0];
      return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function () {
        return __webpack_require__(id);
      });
    }

    webpackAsyncContext.keys = function webpackAsyncContextKeys() {
      return Object.keys(map);
    };

    webpackAsyncContext.id = "./node_modules/@ionic/core/dist/esm lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$ exclude: \\.system\\.entry\\.js$";
    module.exports = webpackAsyncContext;
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html":
  /*!**************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html ***!
    \**************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppAppComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-app>\r\n  <ion-router-outlet></ion-router-outlet>\r\n</ion-app>\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/utilities/auto-complete/auto-complete.component.html":
  /*!************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/utilities/auto-complete/auto-complete.component.html ***!
    \************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppUtilitiesAutoCompleteAutoCompleteComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-item class=\"ion-no-padding\" #searchBar>\r\n    <ion-input [placeholder]=\"placeholder\" style=\"font-size: 12px;word-wrap: break-word;\" class=\"form_input\" (ionChange)=\"onValueChanged($event)\" (ionBlur)=\"onBlur($event)\" (ionFocus)=\"onFocus($event)\" \r\n               [(ngModel)]=\"selectedDataName\"></ion-input>\r\n</ion-item>\r\n<ion-grid class=\"ion-no-padding popup-list\"\r\n          *ngIf=\"sortedList.length !== 0\">\r\n    <ion-row *ngFor=\"let data of sortedList\" (click)=\"selectOption(data)\">\r\n        <ion-col size=\"12\">\r\n            <ion-item>\r\n                <ion-label style=\"font-size: 10px;word-wrap: break-word;\">{{data.name}}</ion-label>\r\n            </ion-item>\r\n        </ion-col>\r\n    </ion-row>\r\n</ion-grid>\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/utilities/date-time/date-time.component.html":
  /*!****************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/utilities/date-time/date-time.component.html ***!
    \****************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppUtilitiesDateTimeDateTimeComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div class=\"d-flex flex-column\">\r\n  <span class=\"input-placeholder\">{{placeholder}}*</span>\r\n  <div class=\"main-background d-flex flex-row align-center justify-center\">\r\n    <div class=\"d-flex flex-column align-center justify-center ion-padding date-background\" (click)=\"changeDate()\">\r\n      <span class=\"month\">{{date | date: 'MMM'}}</span>\r\n      <span class=\"day\">{{date | date: 'dd'}}</span>\r\n    </div>\r\n    <div class=\"ion-padding\" (click)=\"changeTime()\">\r\n      <span class=\"time\">{{date | date: 'hh : mm a'}}</span>\r\n    </div>\r\n  </div>\r\n</div>\r\n\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/utilities/email-selector/email-selector.component.html":
  /*!**************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/utilities/email-selector/email-selector.component.html ***!
    \**************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppUtilitiesEmailSelectorEmailSelectorComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-card >\n<div class=\"row\">\n  <div class=\"col-11\">\n      <h4 class=\"dialogformtitle\">Select the Emails</h4>\n  </div>\n  <div class=\"col-1\">\n      <ion-button mat-icon-button (click)=\"onCloseClick()\">\n          <img class=\"dialogclose\" src=\"../../../../../assets/close.svg\" />\n      </ion-button>\n  </div>\n</div>\n<div mat-dialog-content>\n  \n<ion-list  class=\"matlist\">\n  \n  <ion-label class=\"selectall\">\n      <ion-input type=\"checkbox\"  name=\"selectall\" [value]=\"TeamData\" (change)=\"selectAll($event)\"></ion-input>&nbsp;&nbsp;\n       Select All\n    </ion-label>\n  <ion-item-option [ngClass]=\"[ i%2 == 0 ? 'itemcard even' : 'itemcard odd']\"\n   *ngFor=\"let item of example; let i = index \">\n      <input  type=\"checkbox\" [(ngModel)]=\"item.checked\"> \n      <a class=\"listitem1\">{{item.firstname}}</a>\n      <a class=\"listitem1\">{{item.lastname}}</a>\n      <a class=\"listitem2\">{{item.name}}</a>\n      <a class=\"listitem\">({{item.email}})</a>\n  </ion-item-option> \n  \n\n</ion-list>\n\n</div>\n<div style=\"padding-top: 16px; padding-left: 16px; \">\n<ion-textarea id=\"inputemails\" style=\"width: 50%; height: 60px; word-wrap: break-word;\" type=\"email\"  matInput multiple placeholder=\"john@gmail.com,troy@gmail.com\"></ion-textarea>\n</div>\n<ion-button mat-raised-button class=\"sendButton\" (click)=\"SendMail()\">Send</ion-button>\n</ion-card>\n\n\n\n\n\n\n\n\n\n\n\n\n\n<!-- <form #f=\"ngForm\" (ngSubmit)=\"onSubmit(f)\">\n<mat-list-item class=\"primary-imenu-item\" role=\"listitem\">\n  <mat-form-field class=\"select-form\">  \n  <mat-select\n      placeholder=\"Emails\"\n      name=\"Emails\"\n      class=\"filter-select\" \n      multiple \n      #emailsSelect=\"ngModel\"\n       ngModel >\n      <mat-option disabled=\"disabled\" class=\"filter-option\">\n          <input type=\"checkbox\"(click)=\"selectAll(checkAll.checked, emailsSelect, teamMember)\" #checkAll>\n          {{Emails}}\n      </mat-option> \n      <mat-option >{{data.design.email}}</mat-option>\n  </mat-select>\n  </mat-form-field>\n</mat-list-item>\n<button mat-button>Submit</button>\n</form> -->";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/utilities/success-modal/success-modal.component.html":
  /*!************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/utilities/success-modal/success-modal.component.html ***!
    \************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppUtilitiesSuccessModalSuccessModalComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-content>\r\n\r\n    <ion-grid>\r\n        <ion-row>\r\n          <ion-col size=\"12\" class=\"ion-text-end\">\r\n            <ion-button fill=\"clear\" size=\"small\" class=\"ion-no-padding\" (click)=\"closeModal()\">\r\n              <ion-icon name=\"close-outline\" color=\"dark\" size=\"large\"></ion-icon>\r\n            </ion-button>\r\n          </ion-col>\r\n            <ion-col size=\"12\" class=\"ion-text-center\">\r\n                <img src=\"/assets/images/success.svg\" class=\"success-image\" />\r\n            </ion-col>\r\n            <ion-col size=\"12\" class=\"ion-text-center\">\r\n                <span>{{message}}</span>\r\n            </ion-col>\r\n        </ion-row>\r\n    </ion-grid>\r\n\r\n\r\n</ion-content>\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/utilities/user-selector/user-selector.component.html":
  /*!************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/utilities/user-selector/user-selector.component.html ***!
    \************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppUtilitiesUserSelectorUserSelectorComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div class=\"d-flex flex-column transparent-background margin\" style=\"overflow:scroll\">\r\n  <span class=\"input-placeholder\" style=\"margin-left: 8px;\">{{placeholder}}</span>\r\n  <span class=\"input-placeholder\" *ngIf=\"required\">*</span>\r\n  <div scrollX=\"true\" style=\"margin-top: 4px;\">\r\n    <div class=\"d-flex flex-row\">\r\n      <div *ngFor=\"let assignee of assignees\" class=\"assignee-margin \" (click)=\"selectAssignee(assignee)\">\r\n        \r\n        <div class=\"selected d-flex\"\r\n             [class.selected]=\"assignee.selected\" [class.normal]=\"!assignee.selected\">\r\n             <ion-badge class=\"badge\" style=\"z-index:999\">{{assignee?.jobcount}}</ion-badge>\r\n          <img *ngIf=\"assignee.contractorlogo && assignee.contractorlogo.logo\" [src]=\"assignee.contractorlogo.logo.url\" class=\"assignee-image\"/>\r\n          <div *ngIf=\"!assignee.contractorlogo || !assignee.contractorlogo.logo\" class=\"assignee-image d-flex flex-row align-center justify-center\">\r\n            <div class=\"name_div\">\r\n            \r\n              <span style=\"text-transform: capitalize;\">{{assignee?.firstname?.substring(0, 1) | uppercase}}{{assignee?.lastname?.substring(0, 1) | uppercase}}</span>\r\n            </div>\r\n          </div>\r\n        </div>\r\n        <small style=\"font-size: 8px;\">{{assignee?.firstname}} <br />{{assignee?.lastname}}</small>\r\n      </div>\r\n    </div>\r\n  </div>\r\n\r\n</div>\r\n\r\n";
    /***/
  },

  /***/
  "./node_modules/tslib/tslib.es6.js":
  /*!*****************************************!*\
    !*** ./node_modules/tslib/tslib.es6.js ***!
    \*****************************************/

  /*! exports provided: __extends, __assign, __rest, __decorate, __param, __metadata, __awaiter, __generator, __createBinding, __exportStar, __values, __read, __spread, __spreadArrays, __await, __asyncGenerator, __asyncDelegator, __asyncValues, __makeTemplateObject, __importStar, __importDefault, __classPrivateFieldGet, __classPrivateFieldSet */

  /***/
  function node_modulesTslibTslibEs6Js(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__extends", function () {
      return __extends;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__assign", function () {
      return _assign;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__rest", function () {
      return __rest;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__decorate", function () {
      return __decorate;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__param", function () {
      return __param;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__metadata", function () {
      return __metadata;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__awaiter", function () {
      return __awaiter;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__generator", function () {
      return __generator;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__createBinding", function () {
      return __createBinding;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__exportStar", function () {
      return __exportStar;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__values", function () {
      return __values;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__read", function () {
      return __read;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__spread", function () {
      return __spread;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__spreadArrays", function () {
      return __spreadArrays;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__await", function () {
      return __await;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__asyncGenerator", function () {
      return __asyncGenerator;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__asyncDelegator", function () {
      return __asyncDelegator;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__asyncValues", function () {
      return __asyncValues;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__makeTemplateObject", function () {
      return __makeTemplateObject;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__importStar", function () {
      return __importStar;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__importDefault", function () {
      return __importDefault;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__classPrivateFieldGet", function () {
      return __classPrivateFieldGet;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__classPrivateFieldSet", function () {
      return __classPrivateFieldSet;
    });
    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation.
    
    Permission to use, copy, modify, and/or distribute this software for any
    purpose with or without fee is hereby granted.
    
    THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
    REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
    INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
    LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
    OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
    PERFORMANCE OF THIS SOFTWARE.
    ***************************************************************************** */

    /* global Reflect, Promise */


    var _extendStatics = function extendStatics(d, b) {
      _extendStatics = Object.setPrototypeOf || {
        __proto__: []
      } instanceof Array && function (d, b) {
        d.__proto__ = b;
      } || function (d, b) {
        for (var p in b) {
          if (b.hasOwnProperty(p)) d[p] = b[p];
        }
      };

      return _extendStatics(d, b);
    };

    function __extends(d, b) {
      _extendStatics(d, b);

      function __() {
        this.constructor = d;
      }

      d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }

    var _assign = function __assign() {
      _assign = Object.assign || function __assign(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];

          for (var p in s) {
            if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
          }
        }

        return t;
      };

      return _assign.apply(this, arguments);
    };

    function __rest(s, e) {
      var t = {};

      for (var p in s) {
        if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
      }

      if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
      }
      return t;
    }

    function __decorate(decorators, target, key, desc) {
      var c = arguments.length,
          r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc,
          d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);else for (var i = decorators.length - 1; i >= 0; i--) {
        if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      }
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    }

    function __param(paramIndex, decorator) {
      return function (target, key) {
        decorator(target, key, paramIndex);
      };
    }

    function __metadata(metadataKey, metadataValue) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
    }

    function __awaiter(thisArg, _arguments, P, generator) {
      function adopt(value) {
        return value instanceof P ? value : new P(function (resolve) {
          resolve(value);
        });
      }

      return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) {
          try {
            step(generator.next(value));
          } catch (e) {
            reject(e);
          }
        }

        function rejected(value) {
          try {
            step(generator["throw"](value));
          } catch (e) {
            reject(e);
          }
        }

        function step(result) {
          result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }

        step((generator = generator.apply(thisArg, _arguments || [])).next());
      });
    }

    function __generator(thisArg, body) {
      var _ = {
        label: 0,
        sent: function sent() {
          if (t[0] & 1) throw t[1];
          return t[1];
        },
        trys: [],
        ops: []
      },
          f,
          y,
          t,
          g;
      return g = {
        next: verb(0),
        "throw": verb(1),
        "return": verb(2)
      }, typeof Symbol === "function" && (g[Symbol.iterator] = function () {
        return this;
      }), g;

      function verb(n) {
        return function (v) {
          return step([n, v]);
        };
      }

      function step(op) {
        if (f) throw new TypeError("Generator is already executing.");

        while (_) {
          try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];

            switch (op[0]) {
              case 0:
              case 1:
                t = op;
                break;

              case 4:
                _.label++;
                return {
                  value: op[1],
                  done: false
                };

              case 5:
                _.label++;
                y = op[1];
                op = [0];
                continue;

              case 7:
                op = _.ops.pop();

                _.trys.pop();

                continue;

              default:
                if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                  _ = 0;
                  continue;
                }

                if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                  _.label = op[1];
                  break;
                }

                if (op[0] === 6 && _.label < t[1]) {
                  _.label = t[1];
                  t = op;
                  break;
                }

                if (t && _.label < t[2]) {
                  _.label = t[2];

                  _.ops.push(op);

                  break;
                }

                if (t[2]) _.ops.pop();

                _.trys.pop();

                continue;
            }

            op = body.call(thisArg, _);
          } catch (e) {
            op = [6, e];
            y = 0;
          } finally {
            f = t = 0;
          }
        }

        if (op[0] & 5) throw op[1];
        return {
          value: op[0] ? op[1] : void 0,
          done: true
        };
      }
    }

    function __createBinding(o, m, k, k2) {
      if (k2 === undefined) k2 = k;
      o[k2] = m[k];
    }

    function __exportStar(m, exports) {
      for (var p in m) {
        if (p !== "default" && !exports.hasOwnProperty(p)) exports[p] = m[p];
      }
    }

    function __values(o) {
      var s = typeof Symbol === "function" && Symbol.iterator,
          m = s && o[s],
          i = 0;
      if (m) return m.call(o);
      if (o && typeof o.length === "number") return {
        next: function next() {
          if (o && i >= o.length) o = void 0;
          return {
            value: o && o[i++],
            done: !o
          };
        }
      };
      throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
    }

    function __read(o, n) {
      var m = typeof Symbol === "function" && o[Symbol.iterator];
      if (!m) return o;
      var i = m.call(o),
          r,
          ar = [],
          e;

      try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) {
          ar.push(r.value);
        }
      } catch (error) {
        e = {
          error: error
        };
      } finally {
        try {
          if (r && !r.done && (m = i["return"])) m.call(i);
        } finally {
          if (e) throw e.error;
        }
      }

      return ar;
    }

    function __spread() {
      for (var ar = [], i = 0; i < arguments.length; i++) {
        ar = ar.concat(__read(arguments[i]));
      }

      return ar;
    }

    function __spreadArrays() {
      for (var s = 0, i = 0, il = arguments.length; i < il; i++) {
        s += arguments[i].length;
      }

      for (var r = Array(s), k = 0, i = 0; i < il; i++) {
        for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++) {
          r[k] = a[j];
        }
      }

      return r;
    }

    ;

    function __await(v) {
      return this instanceof __await ? (this.v = v, this) : new __await(v);
    }

    function __asyncGenerator(thisArg, _arguments, generator) {
      if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
      var g = generator.apply(thisArg, _arguments || []),
          i,
          q = [];
      return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () {
        return this;
      }, i;

      function verb(n) {
        if (g[n]) i[n] = function (v) {
          return new Promise(function (a, b) {
            q.push([n, v, a, b]) > 1 || resume(n, v);
          });
        };
      }

      function resume(n, v) {
        try {
          step(g[n](v));
        } catch (e) {
          settle(q[0][3], e);
        }
      }

      function step(r) {
        r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r);
      }

      function fulfill(value) {
        resume("next", value);
      }

      function reject(value) {
        resume("throw", value);
      }

      function settle(f, v) {
        if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]);
      }
    }

    function __asyncDelegator(o) {
      var i, p;
      return i = {}, verb("next"), verb("throw", function (e) {
        throw e;
      }), verb("return"), i[Symbol.iterator] = function () {
        return this;
      }, i;

      function verb(n, f) {
        i[n] = o[n] ? function (v) {
          return (p = !p) ? {
            value: __await(o[n](v)),
            done: n === "return"
          } : f ? f(v) : v;
        } : f;
      }
    }

    function __asyncValues(o) {
      if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
      var m = o[Symbol.asyncIterator],
          i;
      return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () {
        return this;
      }, i);

      function verb(n) {
        i[n] = o[n] && function (v) {
          return new Promise(function (resolve, reject) {
            v = o[n](v), settle(resolve, reject, v.done, v.value);
          });
        };
      }

      function settle(resolve, reject, d, v) {
        Promise.resolve(v).then(function (v) {
          resolve({
            value: v,
            done: d
          });
        }, reject);
      }
    }

    function __makeTemplateObject(cooked, raw) {
      if (Object.defineProperty) {
        Object.defineProperty(cooked, "raw", {
          value: raw
        });
      } else {
        cooked.raw = raw;
      }

      return cooked;
    }

    ;

    function __importStar(mod) {
      if (mod && mod.__esModule) return mod;
      var result = {};
      if (mod != null) for (var k in mod) {
        if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
      }
      result["default"] = mod;
      return result;
    }

    function __importDefault(mod) {
      return mod && mod.__esModule ? mod : {
        "default": mod
      };
    }

    function __classPrivateFieldGet(receiver, privateMap) {
      if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to get private field on non-instance");
      }

      return privateMap.get(receiver);
    }

    function __classPrivateFieldSet(receiver, privateMap, value) {
      if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to set private field on non-instance");
      }

      privateMap.set(receiver, value);
      return value;
    }
    /***/

  },

  /***/
  "./src/app/api.service.ts":
  /*!********************************!*\
    !*** ./src/app/api.service.ts ***!
    \********************************/

  /*! exports provided: ApiService */

  /***/
  function srcAppApiServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ApiService", function () {
      return ApiService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! rxjs */
    "./node_modules/rxjs/_esm2015/index.js");
    /* harmony import */


    var _storage_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ./storage.service */
    "./src/app/storage.service.ts");
    /* harmony import */


    var _contants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./contants */
    "./src/app/contants.ts");
    /* harmony import */


    var _model_constants__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./model/constants */
    "./src/app/model/constants.ts");
    /* harmony import */


    var _utilities_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ./utilities.service */
    "./src/app/utilities.service.ts");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var _auth_guard_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! ./auth-guard.service */
    "./src/app/auth-guard.service.ts");

    var ApiService = /*#__PURE__*/function () {
      function ApiService(http, storageService, utilities, auth) {
        var _this = this;

        _classCallCheck(this, ApiService);

        this.http = http;
        this.storageService = storageService;
        this.utilities = utilities;
        this.auth = auth;
        this.onlineOffline = navigator.onLine;
        this.parentId = '';
        this.userId = '';
        this.searchbarElement = '';
        this.solarMakeValue = new rxjs__WEBPACK_IMPORTED_MODULE_3__["BehaviorSubject"]('');

        if (!navigator.onLine) {// this.utilities.showSnackBar('No internet connection');
          //Do task when no internet connection
        }

        window.addEventListener('online', function () {//Do task when internet connection returns
        });
        window.addEventListener('offline', function () {
          //Do task when no internet connection
          _this.utilities.errorSnackBar('No internet connection');
        });
        this.resetHeaders();
        this._OnMessageReceivedSubject = new rxjs__WEBPACK_IMPORTED_MODULE_3__["Subject"]();
      }
      /**
      * emits a message.
      */


      _createClass(ApiService, [{
        key: "emitMessageReceived",
        value: function emitMessageReceived(msg) {
          this._OnMessageReceivedSubject.next(msg);
        }
      }, {
        key: "login",
        value: function login(data) {
          this.resetHeaders();
          return this.http.post(_contants__WEBPACK_IMPORTED_MODULE_5__["BaseUrl"] + '/auth/local', data, {
            headers: this.headers
          });
        }
      }, {
        key: "sendForgotPasswordLink",
        value: function sendForgotPasswordLink(data) {
          return this.http.post(_contants__WEBPACK_IMPORTED_MODULE_5__["BaseUrl"] + '/auth/forgot-password', data, {
            headers: this.headers
          });
        }
      }, {
        key: "getSolarMake",
        value: function getSolarMake() {
          return this.http.get(_contants__WEBPACK_IMPORTED_MODULE_5__["BaseUrl"] + '/modulemakes', {
            headers: this.headers
          });
        }
      }, {
        key: "postSolarMake",
        value: function postSolarMake(data) {
          return this.http.post(_contants__WEBPACK_IMPORTED_MODULE_5__["BaseUrl"] + '/modulemakes', data, {
            headers: this.headers
          });
        }
      }, {
        key: "getRoofMaterial",
        value: function getRoofMaterial() {
          return this.http.get(_contants__WEBPACK_IMPORTED_MODULE_5__["BaseUrl"] + '/roofmaterials', {
            headers: this.headers
          });
        }
      }, {
        key: "getSolarMade",
        value: function getSolarMade(id) {
          return this.http.get(_contants__WEBPACK_IMPORTED_MODULE_5__["BaseUrl"] + '/modulemodels?modulemake.id_eq=' + id, {
            headers: this.headers
          });
        }
      }, {
        key: "postSolarMade",
        value: function postSolarMade(data) {
          return this.http.post(_contants__WEBPACK_IMPORTED_MODULE_5__["BaseUrl"] + '/modulemodels', data, {
            headers: this.headers
          });
        }
      }, {
        key: "getInverterMake",
        value: function getInverterMake() {
          return this.http.get(_contants__WEBPACK_IMPORTED_MODULE_5__["BaseUrl"] + '/invertermakes', {
            headers: this.headers
          });
        }
      }, {
        key: "postInverterMake",
        value: function postInverterMake(data) {
          return this.http.post(_contants__WEBPACK_IMPORTED_MODULE_5__["BaseUrl"] + '/invertermakes', data, {
            headers: this.headers
          });
        }
      }, {
        key: "postInverterMade",
        value: function postInverterMade(data) {
          return this.http.post(_contants__WEBPACK_IMPORTED_MODULE_5__["BaseUrl"] + '/invertermodels', data, {
            headers: this.headers
          });
        }
      }, {
        key: "getUtilities",
        value: function getUtilities() {
          return this.http.get(_contants__WEBPACK_IMPORTED_MODULE_5__["BaseUrl"] + '/utilities', {
            headers: this.headers
          });
        }
      }, {
        key: "addUtility",
        value: function addUtility(data) {
          return this.http.post(_contants__WEBPACK_IMPORTED_MODULE_5__["BaseUrl"] + '/utilities', data, {
            headers: this.headers
          });
        }
      }, {
        key: "getRoofMaterials",
        value: function getRoofMaterials() {
          return this.http.get(_contants__WEBPACK_IMPORTED_MODULE_5__["BaseUrl"] + '/roofmaterials', {
            headers: this.headers
          });
        }
      }, {
        key: "getInverterMade",
        value: function getInverterMade(id) {
          console.log(id);
          return this.http.get(_contants__WEBPACK_IMPORTED_MODULE_5__["BaseUrl"] + '/invertermodels?invertermake.id_eq=' + id, {
            headers: this.headers
          });
        }
      }, {
        key: "addDesginForm",
        value: function addDesginForm(data) {
          return this.http.post(_contants__WEBPACK_IMPORTED_MODULE_5__["BaseUrl"] + '/designs', data, {
            headers: this.headers
          });
        }
      }, {
        key: "updateDesignForm",
        value: function updateDesignForm(data, id) {
          return this.http.put(_contants__WEBPACK_IMPORTED_MODULE_5__["BaseUrl"] + '/designs/' + id, data, {
            headers: this.headers
          });
        }
      }, {
        key: "getDesgin",
        value: function getDesgin() {
          return this.http.get(_contants__WEBPACK_IMPORTED_MODULE_5__["BaseUrl"] + '/userdesigns?id=' + this.userId, {
            headers: this.headers
          });
        }
      }, {
        key: "getDesginDetail",
        value: function getDesginDetail(id) {
          return this.http.get(_contants__WEBPACK_IMPORTED_MODULE_5__["BaseUrl"] + '/designs/' + id, {
            headers: this.headers
          });
        }
      }, {
        key: "deleteDesign",
        value: function deleteDesign(id) {
          return this.http["delete"](_contants__WEBPACK_IMPORTED_MODULE_5__["BaseUrl"] + '/designs/' + id, {
            headers: this.headers
          });
        }
      }, {
        key: "getSurvey",
        value: function getSurvey() {
          return this.http.get(_contants__WEBPACK_IMPORTED_MODULE_5__["BaseUrl"] + '/usersurveys?id=' + this.userId, {
            headers: this.headers
          });
        }
      }, {
        key: "getSurveyDetail",
        value: function getSurveyDetail(id) {
          return this.http.get(_contants__WEBPACK_IMPORTED_MODULE_5__["BaseUrl"] + '/surveys/' + id, {
            headers: this.headers
          });
        }
      }, {
        key: "deleteSurvey",
        value: function deleteSurvey(id) {
          return this.http["delete"](_contants__WEBPACK_IMPORTED_MODULE_5__["BaseUrl"] + '/surveys/' + id, {
            headers: this.headers
          });
        }
      }, {
        key: "updateSurveyForm",
        value: function updateSurveyForm(data, id) {
          return this.http.put(_contants__WEBPACK_IMPORTED_MODULE_5__["BaseUrl"] + '/surveys/' + id, data, {
            headers: this.headers
          });
        }
      }, {
        key: "getSurveyorSurveys",
        value: function getSurveyorSurveys(search) {
          return this.http.get(_contants__WEBPACK_IMPORTED_MODULE_5__["BaseUrl"] + '/usersurveys?id=' + this.userId + '&' + search, {
            headers: this.headers
          });
        }
      }, {
        key: "getDesignSurveys",
        value: function getDesignSurveys(search) {
          return this.http.get(_contants__WEBPACK_IMPORTED_MODULE_5__["BaseUrl"] + '/userdesigns?id=' + this.userId + '&' + search, {
            headers: this.headers
          });
        }
      }, {
        key: "getAnalystDesign",
        value: function getAnalystDesign(search) {
          return this.http.get(_contants__WEBPACK_IMPORTED_MODULE_5__["BaseUrl"] + '/userdesign?id=' + this.userId + '&' + search, {
            headers: this.headers
          });
        }
      }, {
        key: "refreshHeader",
        value: function refreshHeader() {
          this.headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.storageService.getJWTToken()
          });
          this.uploadHeaders = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
            Authorization: 'Bearer ' + this.storageService.getJWTToken()
          });
          this.parentId = this.storageService.getParentId();
          this.userId = this.storageService.getUserID();
        }
      }, {
        key: "resetHeaders",
        value: function resetHeaders() {
          this.headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
            'Content-Type': 'application/json'
          });
          this.uploadHeaders = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]();
          this.parentId = '';
          this.userId = '';
        }
      }, {
        key: "saveSurvey",
        value: function saveSurvey(data) {
          return this.http.post(_contants__WEBPACK_IMPORTED_MODULE_5__["BaseUrl"] + '/surveys', data, {
            headers: this.headers
          });
        }
      }, {
        key: "getSurveyors",
        value: function getSurveyors() {
          return this.http.get(_contants__WEBPACK_IMPORTED_MODULE_5__["BaseUrl"] + '/surveyors?parent_eq=' + this.parentId, {
            headers: this.headers
          });
        }
      }, {
        key: "getAnalysts",
        value: function getAnalysts() {
          return this.http.get(_contants__WEBPACK_IMPORTED_MODULE_5__["BaseUrl"] + '/analysts?parent_eq=' + this.parentId, {
            headers: this.headers
          });
        }
      }, {
        key: "searchAllDesgin",
        value: function searchAllDesgin(searchterm) {
          return this.http.get(_contants__WEBPACK_IMPORTED_MODULE_5__["BaseUrl"] + '/globalsearch?term=' + searchterm + '&userid=' + this.userId, {
            headers: this.headers
          });
        }
      }, {
        key: "getDesigners",
        value: function getDesigners() {
          return this.http.get(_contants__WEBPACK_IMPORTED_MODULE_5__["BaseUrl"] + '/designers?parent_eq=' + this.parentId, {
            headers: this.headers
          });
        }
      }, {
        key: "uploadImage",
        value: function uploadImage(surveyId, key, blob, fileName) {
          var data = new FormData();
          data.append('files', blob, fileName);
          data.append('path', 'survey/' + surveyId);
          data.append('refId', surveyId + '');
          data.append('ref', 'survey');
          data.append('field', key);
          console.log("file upload data---" + data);
          return this.http.post(_contants__WEBPACK_IMPORTED_MODULE_5__["BaseUrl"] + '/upload', data, {
            headers: this.uploadHeaders
          });
        }
      }, {
        key: "uploadDeclineImage",
        value: function uploadDeclineImage(designId, key, blob, fileName) {
          var data = new FormData();
          data.append('files', blob, fileName);
          data.append('path', 'designs/' + designId);
          data.append('refId', designId + '');
          data.append('ref', 'design');
          data.append('field', key);
          console.log("file upload data---" + data);
          return this.http.post(_contants__WEBPACK_IMPORTED_MODULE_5__["BaseUrl"] + '/upload', data, {
            headers: this.uploadHeaders
          });
        }
      }, {
        key: "uploaddesign",
        value: function uploaddesign(data) {
          return this.http.post(_contants__WEBPACK_IMPORTED_MODULE_5__["BaseUrl"] + '/upload', data, {
            headers: this.uploadHeaders
          });
        }
      }, {
        key: "resetpassword",
        value: function resetpassword(data) {
          return this.http.post(_contants__WEBPACK_IMPORTED_MODULE_5__["BaseUrl"] + '/auth/reset-password', data, {
            headers: this.uploadHeaders
          });
        }
      }, {
        key: "changepassword",
        value: function changepassword(data) {
          return this.http.post(_contants__WEBPACK_IMPORTED_MODULE_5__["BaseUrl"] + '/auth/set-password', data, {
            headers: this.uploadHeaders
          });
        }
      }, {
        key: "updateresetpassword",
        value: function updateresetpassword(userId, data) {
          return this.http.put(_contants__WEBPACK_IMPORTED_MODULE_5__["BaseUrl"] + '/users/' + userId, data, {
            headers: this.uploadHeaders
          });
        }
      }, {
        key: "updateUser",
        value: function updateUser(id, data) {
          return this.http.put(_contants__WEBPACK_IMPORTED_MODULE_5__["BaseUrl"] + '/users/' + id, data, {
            headers: this.uploadHeaders
          });
        }
      }, {
        key: "profileNotification",
        value: function profileNotification() {
          return this.http.get(_contants__WEBPACK_IMPORTED_MODULE_5__["BaseUrl"] + '/notifications/user/' + this.userId, {
            headers: this.headers
          });
        }
      }, {
        key: "getGoogleImage",
        value: function getGoogleImage(lat, lng) {
          var imageurl = "https://maps.googleapis.com/maps/api/staticmap?zoom=19&size=1200x1600&scale=4&maptype=satellite&center=" + lat + "," + lng + "&key=" + _model_constants__WEBPACK_IMPORTED_MODULE_6__["GOOGLE_API_KEY"];
          return this.http.get(imageurl, {
            responseType: 'blob'
          });
        }
      }, {
        key: "deletePrelimImage",
        value: function deletePrelimImage(id) {
          return this.http["delete"](_contants__WEBPACK_IMPORTED_MODULE_5__["BaseUrl"] + "upload/files/" + id, {
            headers: this.headers
          });
        }
      }, {
        key: "rechargePost",
        value: function rechargePost(data) {
          return this.http.post(_contants__WEBPACK_IMPORTED_MODULE_5__["BaseUrl"] + "recharges/", data, {
            headers: this.headers
          });
        }
      }, {
        key: "design_activityDetails",
        value: function design_activityDetails(designid) {
          return this.http.get(_contants__WEBPACK_IMPORTED_MODULE_5__["BaseUrl"] + "designs/" + designid, {
            headers: this.headers
          });
        }
      }, {
        key: "survey_activityDetails",
        value: function survey_activityDetails(surveyid) {
          return this.http.get(_contants__WEBPACK_IMPORTED_MODULE_5__["BaseUrl"] + "surveys/" + surveyid, {
            headers: this.headers
          });
        }
      }, {
        key: "publishSolarMake",
        value: function publishSolarMake(value) {
          this.solarMakeValue.next(value);
        }
      }, {
        key: "editDesign",
        value: function editDesign(id, inputData) {
          return this.http.put(_contants__WEBPACK_IMPORTED_MODULE_5__["BaseUrl"] + "designs/" + id, inputData, {
            observe: "response"
          }).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_8__["map"])(function (value) {
            var member = value.body;
            return member;
          }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_8__["catchError"])(function (err) {
            console.log(err); //   this.utils.showApiError(err.error.message);

            return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(err.error.message);
          }));
        }
      }, {
        key: "pushtoken",
        value: function pushtoken(id, data) {
          return this.http.put(_contants__WEBPACK_IMPORTED_MODULE_5__["BaseUrl"] + '/users/pushtokens/' + id, data, {
            headers: this.uploadHeaders
          });
        }
      }, {
        key: "getTeamData",
        value: function getTeamData() {
          return this.http.get(_contants__WEBPACK_IMPORTED_MODULE_5__["BaseUrl"] + "/users?_sort=created_at:desc&parent=" + this.parentId + "&id_ne=" + this.parentId, {
            headers: this.headers,
            observe: "response"
          }).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_8__["map"])(function (value) {
            var members = value.body;
            return members;
          }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_8__["catchError"])(function (err) {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(err.error.message);
          }));
        }
      }]);

      return ApiService;
    }();

    ApiService.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
      }, {
        type: _storage_service__WEBPACK_IMPORTED_MODULE_4__["StorageService"]
      }, {
        type: _utilities_service__WEBPACK_IMPORTED_MODULE_7__["UtilitiesService"]
      }, {
        type: _auth_guard_service__WEBPACK_IMPORTED_MODULE_9__["AuthGuardService"]
      }];
    };

    ApiService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"], _storage_service__WEBPACK_IMPORTED_MODULE_4__["StorageService"], _utilities_service__WEBPACK_IMPORTED_MODULE_7__["UtilitiesService"], _auth_guard_service__WEBPACK_IMPORTED_MODULE_9__["AuthGuardService"]])], ApiService);
    /***/
  },

  /***/
  "./src/app/app-routing.module.ts":
  /*!***************************************!*\
    !*** ./src/app/app-routing.module.ts ***!
    \***************************************/

  /*! exports provided: AppRoutingModule */

  /***/
  function srcAppAppRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function () {
      return AppRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _auth_guard_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./auth-guard.service */
    "./src/app/auth-guard.service.ts");

    var routes = [{
      path: '',
      redirectTo: 'login',
      pathMatch: 'full'
    }, {
      path: 'forgot-password',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | forgot-password-forgot-password-module */
        "forgot-password-forgot-password-module").then(__webpack_require__.bind(null,
        /*! ./forgot-password/forgot-password.module */
        "./src/app/forgot-password/forgot-password.module.ts")).then(function (m) {
          return m.ForgotPasswordPageModule;
        });
      }
    }, {
      path: 'login',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | login-login-module */
        "login-login-module").then(__webpack_require__.bind(null,
        /*! ./login/login.module */
        "./src/app/login/login.module.ts")).then(function (m) {
          return m.LoginPageModule;
        });
      }
    }, {
      path: 'homepage',
      loadChildren: function loadChildren() {
        return Promise.all(
        /*! import() | homepage-homepage-module */
        [__webpack_require__.e("default~analystoverview-analystoverview-module~designoverview-designoverview-module~homepage-homepag~2dccd1d9"), __webpack_require__.e("default~analystoverview-analystoverview-module~design-details-design-details-module~designoverview-d~88ee45fb"), __webpack_require__.e("default~analystoverview-analystoverview-module~declinepage-declinepage-module~designoverview-designo~9d1d3d74"), __webpack_require__.e("default~analystoverview-analystoverview-module~designoverview-designoverview-module~homepage-homepag~bfe20b59"), __webpack_require__.e("default~activity-details-activity-details-module~analystoverview-analystoverview-module~designovervi~858c096c"), __webpack_require__.e("default~analystoverview-analystoverview-module~declinepage-declinepage-module~designoverview-designo~aa690249"), __webpack_require__.e("default~designoverview-designoverview-module~homepage-homepage-module~searchbar-searchbar-module"), __webpack_require__.e("default~homepage-homepage-module~surveyoroverview-surveyoroverview-module"), __webpack_require__.e("common"), __webpack_require__.e("homepage-homepage-module")]).then(__webpack_require__.bind(null,
        /*! ./homepage/homepage.module */
        "./src/app/homepage/homepage.module.ts")).then(function (m) {
          return m.HomepagePageModule;
        });
      },
      canActivate: [_auth_guard_service__WEBPACK_IMPORTED_MODULE_3__["AuthGuardService"]]
    }, {
      path: 'schedule',
      loadChildren: function loadChildren() {
        return Promise.all(
        /*! import() | schedule-schedule-module */
        [__webpack_require__.e("default~analystoverview-analystoverview-module~designoverview-designoverview-module~homepage-homepag~2dccd1d9"), __webpack_require__.e("default~analystoverview-analystoverview-module~declinepage-declinepage-module~designoverview-designo~9d1d3d74"), __webpack_require__.e("schedule-schedule-module")]).then(__webpack_require__.bind(null,
        /*! ./schedule/schedule.module */
        "./src/app/schedule/schedule.module.ts")).then(function (m) {
          return m.SchedulePageModule;
        });
      },
      canActivate: [_auth_guard_service__WEBPACK_IMPORTED_MODULE_3__["AuthGuardService"]]
    }, {
      path: 'profile',
      loadChildren: function loadChildren() {
        return Promise.all(
        /*! import() | profile-profile-module */
        [__webpack_require__.e("default~paymentgateway-paymentgateway-module~profile-profile-module"), __webpack_require__.e("profile-profile-module")]).then(__webpack_require__.bind(null,
        /*! ./profile/profile.module */
        "./src/app/profile/profile.module.ts")).then(function (m) {
          return m.ProfilePageModule;
        });
      },
      canActivate: [_auth_guard_service__WEBPACK_IMPORTED_MODULE_3__["AuthGuardService"]]
    }, {
      path: 'notification',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | notification-notification-module */
        "notification-notification-module").then(__webpack_require__.bind(null,
        /*! ./notification/notification.module */
        "./src/app/notification/notification.module.ts")).then(function (m) {
          return m.NotificationPageModule;
        });
      },
      canActivate: [_auth_guard_service__WEBPACK_IMPORTED_MODULE_3__["AuthGuardService"]]
    }, {
      path: 'map-page',
      loadChildren: function loadChildren() {
        return Promise.all(
        /*! import() | map-page-map-page-module */
        [__webpack_require__.e("default~analystoverview-analystoverview-module~designoverview-designoverview-module~homepage-homepag~2dccd1d9"), __webpack_require__.e("map-page-map-page-module")]).then(__webpack_require__.bind(null,
        /*! ./map-page/map-page.module */
        "./src/app/map-page/map-page.module.ts")).then(function (m) {
          return m.MapPagePageModule;
        });
      },
      canActivate: [_auth_guard_service__WEBPACK_IMPORTED_MODULE_3__["AuthGuardService"]]
    }, {
      path: 'gallery/:id',
      loadChildren: function loadChildren() {
        return Promise.all(
        /*! import() | gallery-gallery-module */
        [__webpack_require__.e("default~gallery-gallery-module~surveyprocess-surveyprocess-module"), __webpack_require__.e("gallery-gallery-module")]).then(__webpack_require__.bind(null,
        /*! ./gallery/gallery.module */
        "./src/app/gallery/gallery.module.ts")).then(function (m) {
          return m.GalleryPageModule;
        });
      },
      canActivate: [_auth_guard_service__WEBPACK_IMPORTED_MODULE_3__["AuthGuardService"]]
    }, {
      path: 'homepagedetail',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | homepagedetail-homepagedetail-module */
        "homepagedetail-homepagedetail-module").then(__webpack_require__.bind(null,
        /*! ./homepagedetail/homepagedetail.module */
        "./src/app/homepagedetail/homepagedetail.module.ts")).then(function (m) {
          return m.HomepagedetailPageModule;
        });
      },
      canActivate: [_auth_guard_service__WEBPACK_IMPORTED_MODULE_3__["AuthGuardService"]]
    }, {
      path: 'survey-detail/:id',
      loadChildren: function loadChildren() {
        return Promise.all(
        /*! import() | survey-detail-survey-detail-module */
        [__webpack_require__.e("default~analystoverview-analystoverview-module~design-details-design-details-module~designoverview-d~88ee45fb"), __webpack_require__.e("default~analystoverview-analystoverview-module~designoverview-designoverview-module~homepage-homepag~bfe20b59"), __webpack_require__.e("survey-detail-survey-detail-module")]).then(__webpack_require__.bind(null,
        /*! ./survey-detail/survey-detail.module */
        "./src/app/survey-detail/survey-detail.module.ts")).then(function (m) {
          return m.SurveyDetailPageModule;
        });
      },
      canActivate: [_auth_guard_service__WEBPACK_IMPORTED_MODULE_3__["AuthGuardService"]]
    }, {
      path: 'design-details/:id',
      loadChildren: function loadChildren() {
        return Promise.all(
        /*! import() | design-details-design-details-module */
        [__webpack_require__.e("default~analystoverview-analystoverview-module~design-details-design-details-module~designoverview-d~88ee45fb"), __webpack_require__.e("design-details-design-details-module")]).then(__webpack_require__.bind(null,
        /*! ./design-details/design-details.module */
        "./src/app/design-details/design-details.module.ts")).then(function (m) {
          return m.DesignDetailsPageModule;
        });
      },
      canActivate: [_auth_guard_service__WEBPACK_IMPORTED_MODULE_3__["AuthGuardService"]]
    }, {
      path: 'activity/:id',
      loadChildren: function loadChildren() {
        return Promise.all(
        /*! import() | activity-details-activity-details-module */
        [__webpack_require__.e("default~activity-details-activity-details-module~analystoverview-analystoverview-module~designovervi~858c096c"), __webpack_require__.e("activity-details-activity-details-module")]).then(__webpack_require__.bind(null,
        /*! ./activity-details/activity-details.module */
        "./src/app/activity-details/activity-details.module.ts")).then(function (m) {
          return m.ActivityDetailsPageModule;
        });
      },
      canActivate: [_auth_guard_service__WEBPACK_IMPORTED_MODULE_3__["AuthGuardService"]]
    }, {
      path: 'message',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | message-message-module */
        "message-message-module").then(__webpack_require__.bind(null,
        /*! ./message/message.module */
        "./src/app/message/message.module.ts")).then(function (m) {
          return m.MessagePageModule;
        });
      },
      canActivate: [_auth_guard_service__WEBPACK_IMPORTED_MODULE_3__["AuthGuardService"]]
    }, {
      path: 'chat/:id',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | chat-chat-module */
        "chat-chat-module").then(__webpack_require__.bind(null,
        /*! ./chat/chat.module */
        "./src/app/chat/chat.module.ts")).then(function (m) {
          return m.ChatPageModule;
        });
      },
      canActivate: [_auth_guard_service__WEBPACK_IMPORTED_MODULE_3__["AuthGuardService"]]
    }, {
      path: 'changepassword',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | change-password-change-password-module */
        "change-password-change-password-module").then(__webpack_require__.bind(null,
        /*! ./change-password/change-password.module */
        "./src/app/change-password/change-password.module.ts")).then(function (m) {
          return m.ChangePasswordPageModule;
        });
      }
    }, {
      path: 'surveyprocess/:id/:type/:lat/:long/:city/:state',
      loadChildren: function loadChildren() {
        return Promise.all(
        /*! import() | surveyprocess-surveyprocess-module */
        [__webpack_require__.e("default~analystoverview-analystoverview-module~designoverview-designoverview-module~homepage-homepag~2dccd1d9"), __webpack_require__.e("default~gallery-gallery-module~surveyprocess-surveyprocess-module"), __webpack_require__.e("surveyprocess-surveyprocess-module")]).then(__webpack_require__.bind(null,
        /*! ./surveyprocess/surveyprocess.module */
        "./src/app/surveyprocess/surveyprocess.module.ts")).then(function (m) {
          return m.SurveyprocessPageModule;
        });
      },
      canActivate: [_auth_guard_service__WEBPACK_IMPORTED_MODULE_3__["AuthGuardService"]]
    }, {
      path: 'surveyoroverview',
      loadChildren: function loadChildren() {
        return Promise.all(
        /*! import() | surveyoroverview-surveyoroverview-module */
        [__webpack_require__.e("default~analystoverview-analystoverview-module~designoverview-designoverview-module~homepage-homepag~2dccd1d9"), __webpack_require__.e("default~analystoverview-analystoverview-module~design-details-design-details-module~designoverview-d~88ee45fb"), __webpack_require__.e("default~analystoverview-analystoverview-module~designoverview-designoverview-module~homepage-homepag~bfe20b59"), __webpack_require__.e("default~activity-details-activity-details-module~analystoverview-analystoverview-module~designovervi~858c096c"), __webpack_require__.e("default~homepage-homepage-module~surveyoroverview-surveyoroverview-module"), __webpack_require__.e("surveyoroverview-surveyoroverview-module")]).then(__webpack_require__.bind(null,
        /*! ./surveyoroverview/surveyoroverview.module */
        "./src/app/surveyoroverview/surveyoroverview.module.ts")).then(function (m) {
          return m.SurveyoroverviewPageModule;
        });
      }
    }, {
      path: 'designoverview',
      loadChildren: function loadChildren() {
        return Promise.all(
        /*! import() | designoverview-designoverview-module */
        [__webpack_require__.e("default~analystoverview-analystoverview-module~designoverview-designoverview-module~homepage-homepag~2dccd1d9"), __webpack_require__.e("default~analystoverview-analystoverview-module~design-details-design-details-module~designoverview-d~88ee45fb"), __webpack_require__.e("default~analystoverview-analystoverview-module~declinepage-declinepage-module~designoverview-designo~9d1d3d74"), __webpack_require__.e("default~analystoverview-analystoverview-module~designoverview-designoverview-module~homepage-homepag~bfe20b59"), __webpack_require__.e("default~activity-details-activity-details-module~analystoverview-analystoverview-module~designovervi~858c096c"), __webpack_require__.e("default~analystoverview-analystoverview-module~declinepage-declinepage-module~designoverview-designo~aa690249"), __webpack_require__.e("default~designoverview-designoverview-module~homepage-homepage-module~searchbar-searchbar-module"), __webpack_require__.e("common"), __webpack_require__.e("designoverview-designoverview-module")]).then(__webpack_require__.bind(null,
        /*! ./designoverview/designoverview.module */
        "./src/app/designoverview/designoverview.module.ts")).then(function (m) {
          return m.DesignoverviewPageModule;
        });
      }
    }, {
      path: 'searchbar',
      loadChildren: function loadChildren() {
        return Promise.all(
        /*! import() | searchbar-searchbar-module */
        [__webpack_require__.e("default~analystoverview-analystoverview-module~designoverview-designoverview-module~homepage-homepag~2dccd1d9"), __webpack_require__.e("default~analystoverview-analystoverview-module~design-details-design-details-module~designoverview-d~88ee45fb"), __webpack_require__.e("default~analystoverview-analystoverview-module~declinepage-declinepage-module~designoverview-designo~9d1d3d74"), __webpack_require__.e("default~analystoverview-analystoverview-module~designoverview-designoverview-module~homepage-homepag~bfe20b59"), __webpack_require__.e("default~activity-details-activity-details-module~analystoverview-analystoverview-module~designovervi~858c096c"), __webpack_require__.e("default~analystoverview-analystoverview-module~declinepage-declinepage-module~designoverview-designo~aa690249"), __webpack_require__.e("default~designoverview-designoverview-module~homepage-homepage-module~searchbar-searchbar-module"), __webpack_require__.e("searchbar-searchbar-module")]).then(__webpack_require__.bind(null,
        /*! ./searchbar/searchbar.module */
        "./src/app/searchbar/searchbar.module.ts")).then(function (m) {
          return m.SearchbarPageModule;
        });
      }
    }, {
      path: 'declinepage',
      loadChildren: function loadChildren() {
        return Promise.all(
        /*! import() | declinepage-declinepage-module */
        [__webpack_require__.e("default~analystoverview-analystoverview-module~declinepage-declinepage-module~designoverview-designo~9d1d3d74"), __webpack_require__.e("default~analystoverview-analystoverview-module~declinepage-declinepage-module~designoverview-designo~aa690249"), __webpack_require__.e("declinepage-declinepage-module")]).then(__webpack_require__.bind(null,
        /*! ./declinepage/declinepage.module */
        "./src/app/declinepage/declinepage.module.ts")).then(function (m) {
          return m.DeclinepagePageModule;
        });
      }
    }, {
      path: 'paymentgateway',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | paymentgateway-paymentgateway-module */
        "default~paymentgateway-paymentgateway-module~profile-profile-module").then(__webpack_require__.bind(null,
        /*! ./paymentgateway/paymentgateway.module */
        "./src/app/paymentgateway/paymentgateway.module.ts")).then(function (m) {
          return m.PaymentgatewayPageModule;
        });
      }
    }, {
      path: 'activity/:id/:name',
      loadChildren: function loadChildren() {
        return Promise.all(
        /*! import() | activity-details-activity-details-module */
        [__webpack_require__.e("default~activity-details-activity-details-module~analystoverview-analystoverview-module~designovervi~858c096c"), __webpack_require__.e("activity-details-activity-details-module")]).then(__webpack_require__.bind(null,
        /*! ./activity-details/activity-details.module */
        "./src/app/activity-details/activity-details.module.ts")).then(function (m) {
          return m.ActivityDetailsPageModule;
        });
      }
    }, {
      path: 'search-bar1',
      loadChildren: function loadChildren() {
        return Promise.all(
        /*! import() | search-bar1-search-bar1-module */
        [__webpack_require__.e("default~analystoverview-analystoverview-module~designoverview-designoverview-module~homepage-homepag~2dccd1d9"), __webpack_require__.e("default~analystoverview-analystoverview-module~design-details-design-details-module~designoverview-d~88ee45fb"), __webpack_require__.e("default~analystoverview-analystoverview-module~declinepage-declinepage-module~designoverview-designo~9d1d3d74"), __webpack_require__.e("default~analystoverview-analystoverview-module~designoverview-designoverview-module~homepage-homepag~bfe20b59"), __webpack_require__.e("default~analystoverview-analystoverview-module~declinepage-declinepage-module~designoverview-designo~aa690249"), __webpack_require__.e("search-bar1-search-bar1-module")]).then(__webpack_require__.bind(null,
        /*! ./search-bar1/search-bar1.module */
        "./src/app/search-bar1/search-bar1.module.ts")).then(function (m) {
          return m.SearchBar1PageModule;
        });
      }
    }, {
      path: 'stripe',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | stripe-stripe-module */
        "stripe-stripe-module").then(__webpack_require__.bind(null,
        /*! ./stripe/stripe.module */
        "./src/app/stripe/stripe.module.ts")).then(function (m) {
          return m.StripePageModule;
        });
      }
    }, {
      path: 'activity-details',
      loadChildren: function loadChildren() {
        return Promise.all(
        /*! import() | activity-details-activity-details-module */
        [__webpack_require__.e("default~activity-details-activity-details-module~analystoverview-analystoverview-module~designovervi~858c096c"), __webpack_require__.e("activity-details-activity-details-module")]).then(__webpack_require__.bind(null,
        /*! ./activity-details/activity-details.module */
        "./src/app/activity-details/activity-details.module.ts")).then(function (m) {
          return m.ActivityDetailsPageModule;
        });
      }
    }, {
      path: 'analystoverview',
      loadChildren: function loadChildren() {
        return Promise.all(
        /*! import() | analystoverview-analystoverview-module */
        [__webpack_require__.e("default~analystoverview-analystoverview-module~designoverview-designoverview-module~homepage-homepag~2dccd1d9"), __webpack_require__.e("default~analystoverview-analystoverview-module~design-details-design-details-module~designoverview-d~88ee45fb"), __webpack_require__.e("default~analystoverview-analystoverview-module~declinepage-declinepage-module~designoverview-designo~9d1d3d74"), __webpack_require__.e("default~analystoverview-analystoverview-module~designoverview-designoverview-module~homepage-homepag~bfe20b59"), __webpack_require__.e("default~activity-details-activity-details-module~analystoverview-analystoverview-module~designovervi~858c096c"), __webpack_require__.e("default~analystoverview-analystoverview-module~declinepage-declinepage-module~designoverview-designo~aa690249"), __webpack_require__.e("common"), __webpack_require__.e("analystoverview-analystoverview-module")]).then(__webpack_require__.bind(null,
        /*! ./analystoverview/analystoverview.module */
        "./src/app/analystoverview/analystoverview.module.ts")).then(function (m) {
          return m.AnalystoverviewPageModule;
        });
      }
    }, {
      path: 'add-money',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | add-money-add-money-module */
        "add-money-add-money-module").then(__webpack_require__.bind(null,
        /*! ./add-money/add-money.module */
        "./src/app/add-money/add-money.module.ts")).then(function (m) {
          return m.AddMoneyPageModule;
        });
      }
    }, {
      path: 'email-model',
      loadChildren: function loadChildren() {
        return Promise.all(
        /*! import() | email-model-email-model-module */
        [__webpack_require__.e("common"), __webpack_require__.e("email-model-email-model-module")]).then(__webpack_require__.bind(null,
        /*! ./email-model/email-model.module */
        "./src/app/email-model/email-model.module.ts")).then(function (m) {
          return m.EmailModelPageModule;
        });
      }
    }];

    var AppRoutingModule = function AppRoutingModule() {
      _classCallCheck(this, AppRoutingModule);
    };

    AppRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes, {
        preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_2__["PreloadAllModules"]
      })],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], AppRoutingModule);
    /***/
  },

  /***/
  "./src/app/app.component.scss":
  /*!************************************!*\
    !*** ./src/app/app.component.scss ***!
    \************************************/

  /*! exports provided: default */

  /***/
  function srcAppAppComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FwcC5jb21wb25lbnQuc2NzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/app.component.ts":
  /*!**********************************!*\
    !*** ./src/app/app.component.ts ***!
    \**********************************/

  /*! exports provided: AppComponent */

  /***/
  function srcAppAppComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AppComponent", function () {
      return AppComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic-native/splash-screen/ngx */
    "./node_modules/@ionic-native/splash-screen/ngx/index.js");
    /* harmony import */


    var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic-native/status-bar/ngx */
    "./node_modules/@ionic-native/status-bar/ngx/index.js");
    /* harmony import */


    var _storage_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./storage.service */
    "./src/app/storage.service.ts");
    /* harmony import */


    var _api_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./api.service */
    "./src/app/api.service.ts");
    /* harmony import */


    var _utilities_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ./utilities.service */
    "./src/app/utilities.service.ts");
    /* harmony import */


    var _cometchat_pro_cordova_ionic_chat__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! @cometchat-pro/cordova-ionic-chat */
    "./node_modules/@cometchat-pro/cordova-ionic-chat/CometChat.js");
    /* harmony import */


    var _cometchat_pro_cordova_ionic_chat__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_cometchat_pro_cordova_ionic_chat__WEBPACK_IMPORTED_MODULE_8__);
    /* harmony import */


    var _model_constants__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! ./model/constants */
    "./src/app/model/constants.ts");
    /* harmony import */


    var _ionic_native_firebase_ngx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
    /*! @ionic-native/firebase/ngx */
    "./node_modules/@ionic-native/firebase/ngx/index.js");
    /* harmony import */


    var _networkdetect_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
    /*! ./networkdetect.service */
    "./src/app/networkdetect.service.ts"); // import { FCM } from '@ionic-native/fcm/ngx';


    var AppComponent = /*#__PURE__*/function () {
      function AppComponent(platform, splashScreen, statusBar, storageService, navController, // private fcm: FCM,
      apiservice, utilitiesService, firebase, utilities, network) {
        var _this2 = this;

        _classCallCheck(this, AppComponent);

        this.platform = platform;
        this.splashScreen = splashScreen;
        this.statusBar = statusBar;
        this.storageService = storageService;
        this.navController = navController;
        this.apiservice = apiservice;
        this.utilitiesService = utilitiesService;
        this.firebase = firebase;
        this.utilities = utilities;
        this.network = network;
        this.onlineOffline = navigator.onLine;
        this.initializeApp();

        if (!navigator.onLine) {// this.utilities.showSnackBar('No internet connection');
          //Do task when no internet connection
        }

        window.addEventListener('online', function () {//Do task when internet connection returns
        });
        window.addEventListener('offline', function () {
          //Do task when no internet connection
          setTimeout(function () {
            _this2.utilities.errorSnackBar('No internet connection');
          }, 2000);
        });
      }

      _createClass(AppComponent, [{
        key: "initializeApp",
        value: function initializeApp() {
          var _this3 = this;

          this.platform.ready().then(function () {
            setTimeout(function () {
              _this3.splashScreen.hide();
            }, 1000);

            _this3.getFcmToken();

            if (_this3.platform.is('ios')) {
              _this3.statusBar.overlaysWebView(false);

              _this3.statusBar.backgroundColorByHexString("#fffff");

              _this3.statusBar.styleDefault();
            } else if (_this3.platform.is('android')) {
              _this3.statusBar.overlaysWebView(false);

              _this3.statusBar.styleDefault();

              _this3.statusBar.backgroundColorByHexString("#fffff");

              _this3.statusBar.styleLightContent();
            } else {}

            _this3.getNotification();

            _this3.setupCometChat();
          });
        }
      }, {
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this4 = this;

          this.network.networkSwitch.subscribe(function (data) {
            _this4.netSwitch = data;
            console.log(_this4.netSwitch);
          });
          this.network.networkDisconnect();
          this.network.networkConnect();

          if (this.storageService.isUserPresent()) {
            this.apiservice.refreshHeader();
            this.user = JSON.parse(localStorage.getItem('user')); // console.log("???",this.user.role);

            console.log(this.user.role.type);

            if (this.user.role.type == 'surveyors') {
              this.navController.navigateRoot('surveyoroverview');
            } else if (this.user.role.type == 'designer') {
              this.navController.navigateRoot('designoverview');
            } else if (this.user.role.type === 'qcinspector') {
              console.log(this.user.role.type);
              this.navController.navigateRoot('analystoverview');
            } else {
              this.navController.navigateRoot('homepage');
            }
          }
        }
      }, {
        key: "getFcmToken",
        value: function getFcmToken() {
          this.firebase.getToken().then(function (token) {
            console.log("The token is ".concat(token));
            localStorage.setItem('pushtoken', token);
          })["catch"](function (error) {//  console.error('Error getting token', error)
          });
        }
      }, {
        key: "getNotification",
        value: function getNotification() {
          var _this5 = this;

          this.firebase.onNotificationOpen().subscribe(function (data) {
            console.log("User opened a notification ".concat(data), data);

            _this5.apiservice.emitMessageReceived("pushNotification");
          });
        }
      }, {
        key: "setupCometChat",
        value: function setupCometChat() {
          var appSetting = new _cometchat_pro_cordova_ionic_chat__WEBPACK_IMPORTED_MODULE_8__["CometChat"].AppSettingsBuilder().subscribePresenceForAllUsers().setRegion(_model_constants__WEBPACK_IMPORTED_MODULE_9__["COMET_CHAT_REGION"]).build();

          _cometchat_pro_cordova_ionic_chat__WEBPACK_IMPORTED_MODULE_8__["CometChat"].init(_model_constants__WEBPACK_IMPORTED_MODULE_9__["COMET_CHAT_APP_ID"], appSetting).then(function () {
            console.log('Initialization completed successfully');
          }, function (error) {
            console.log('Initialization failed with error:', error);
          });
        }
      }]);

      return AppComponent;
    }();

    AppComponent.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"]
      }, {
        type: _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__["SplashScreen"]
      }, {
        type: _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__["StatusBar"]
      }, {
        type: _storage_service__WEBPACK_IMPORTED_MODULE_5__["StorageService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"]
      }, {
        type: _api_service__WEBPACK_IMPORTED_MODULE_6__["ApiService"]
      }, {
        type: _utilities_service__WEBPACK_IMPORTED_MODULE_7__["UtilitiesService"]
      }, {
        type: _ionic_native_firebase_ngx__WEBPACK_IMPORTED_MODULE_10__["Firebase"]
      }, {
        type: _utilities_service__WEBPACK_IMPORTED_MODULE_7__["UtilitiesService"]
      }, {
        type: _networkdetect_service__WEBPACK_IMPORTED_MODULE_11__["NetworkdetectService"]
      }];
    };

    AppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-root',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./app.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./app.component.scss */
      "./src/app/app.component.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"], _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__["SplashScreen"], _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__["StatusBar"], _storage_service__WEBPACK_IMPORTED_MODULE_5__["StorageService"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"], _api_service__WEBPACK_IMPORTED_MODULE_6__["ApiService"], _utilities_service__WEBPACK_IMPORTED_MODULE_7__["UtilitiesService"], _ionic_native_firebase_ngx__WEBPACK_IMPORTED_MODULE_10__["Firebase"], _utilities_service__WEBPACK_IMPORTED_MODULE_7__["UtilitiesService"], _networkdetect_service__WEBPACK_IMPORTED_MODULE_11__["NetworkdetectService"]])], AppComponent);
    /***/
  },

  /***/
  "./src/app/app.module.ts":
  /*!*******************************!*\
    !*** ./src/app/app.module.ts ***!
    \*******************************/

  /*! exports provided: AppModule */

  /***/
  function srcAppAppModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AppModule", function () {
      return AppModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/platform-browser */
    "./node_modules/@angular/platform-browser/fesm2015/platform-browser.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic-native/splash-screen/ngx */
    "./node_modules/@ionic-native/splash-screen/ngx/index.js");
    /* harmony import */


    var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @ionic-native/status-bar/ngx */
    "./node_modules/@ionic-native/status-bar/ngx/index.js");
    /* harmony import */


    var _app_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ./app.component */
    "./src/app/app.component.ts");
    /* harmony import */


    var _app_routing_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! ./app-routing.module */
    "./src/app/app-routing.module.ts");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var _auth_guard_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
    /*! ./auth-guard.service */
    "./src/app/auth-guard.service.ts");
    /* harmony import */


    var _storage_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
    /*! ./storage.service */
    "./src/app/storage.service.ts");
    /* harmony import */


    var _utilities_utilities_module__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
    /*! ./utilities/utilities.module */
    "./src/app/utilities/utilities.module.ts");
    /* harmony import */


    var _utilities_success_modal_success_modal_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(
    /*! ./utilities/success-modal/success-modal.component */
    "./src/app/utilities/success-modal/success-modal.component.ts");
    /* harmony import */


    var _ionic_native_geolocation_ngx__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(
    /*! @ionic-native/geolocation/ngx */
    "./node_modules/@ionic-native/geolocation/ngx/index.js");
    /* harmony import */


    var _ionic_storage__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(
    /*! @ionic/storage */
    "./node_modules/@ionic/storage/fesm2015/ionic-storage.js");
    /* harmony import */


    var _ionic_native_firebase_ngx__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(
    /*! @ionic-native/firebase/ngx */
    "./node_modules/@ionic-native/firebase/ngx/index.js");
    /* harmony import */


    var ngx_image_compress__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(
    /*! ngx-image-compress */
    "./node_modules/ngx-image-compress/fesm2015/ngx-image-compress.js");
    /* harmony import */


    var _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(
    /*! @ionic-native/camera/ngx */
    "./node_modules/@ionic-native/camera/ngx/index.js");
    /* harmony import */


    var _ionic_native_in_app_browser_ngx__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(
    /*! @ionic-native/in-app-browser/ngx */
    "./node_modules/@ionic-native/in-app-browser/ngx/index.js");
    /* harmony import */


    var _ionic_native_network_ngx__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(
    /*! @ionic-native/network/ngx */
    "./node_modules/@ionic-native/network/ngx/index.js");
    /* harmony import */


    var _ionic_native_stripe_ngx__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(
    /*! @ionic-native/stripe/ngx */
    "./node_modules/@ionic-native/stripe/ngx/index.js");
    /* harmony import */


    var _ionic_native_social_sharing_ngx__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(
    /*! @ionic-native/social-sharing/ngx */
    "./node_modules/@ionic-native/social-sharing/ngx/index.js");
    /* harmony import */


    var _ionic_native_dialogs_ngx__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(
    /*! @ionic-native/dialogs/ngx */
    "./node_modules/@ionic-native/dialogs/ngx/index.js"); // import { FCM } from '@ionic-native/fcm/ngx';


    var AppModule = function AppModule() {
      _classCallCheck(this, AppModule);
    };

    AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      declarations: [_app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"], _utilities_success_modal_success_modal_component__WEBPACK_IMPORTED_MODULE_13__["SuccessModalComponent"]],
      entryComponents: [_utilities_success_modal_success_modal_component__WEBPACK_IMPORTED_MODULE_13__["SuccessModalComponent"]],
      imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["BrowserModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"].forRoot(), _app_routing_module__WEBPACK_IMPORTED_MODULE_8__["AppRoutingModule"], _angular_common_http__WEBPACK_IMPORTED_MODULE_9__["HttpClientModule"], _utilities_utilities_module__WEBPACK_IMPORTED_MODULE_12__["UtilitiesModule"], _ionic_storage__WEBPACK_IMPORTED_MODULE_15__["IonicStorageModule"].forRoot()],
      providers: [_ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__["StatusBar"], _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__["SplashScreen"], // FCM,
      {
        provide: _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouteReuseStrategy"],
        useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicRouteStrategy"]
      }, _angular_common_http__WEBPACK_IMPORTED_MODULE_9__["HttpClient"], _storage_service__WEBPACK_IMPORTED_MODULE_11__["StorageService"], _auth_guard_service__WEBPACK_IMPORTED_MODULE_10__["AuthGuardService"], _ionic_native_geolocation_ngx__WEBPACK_IMPORTED_MODULE_14__["Geolocation"], _ionic_native_firebase_ngx__WEBPACK_IMPORTED_MODULE_16__["Firebase"], ngx_image_compress__WEBPACK_IMPORTED_MODULE_17__["NgxImageCompressService"], _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_18__["Camera"], _ionic_native_in_app_browser_ngx__WEBPACK_IMPORTED_MODULE_19__["InAppBrowser"], _ionic_native_network_ngx__WEBPACK_IMPORTED_MODULE_20__["Network"], _ionic_native_stripe_ngx__WEBPACK_IMPORTED_MODULE_21__["Stripe"], _ionic_native_social_sharing_ngx__WEBPACK_IMPORTED_MODULE_22__["SocialSharing"], _ionic_native_dialogs_ngx__WEBPACK_IMPORTED_MODULE_23__["Dialogs"]],
      exports: [_utilities_utilities_module__WEBPACK_IMPORTED_MODULE_12__["UtilitiesModule"]],
      bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"]]
    })], AppModule);
    /***/
  },

  /***/
  "./src/app/auth-guard.service.ts":
  /*!***************************************!*\
    !*** ./src/app/auth-guard.service.ts ***!
    \***************************************/

  /*! exports provided: AuthGuardService */

  /***/
  function srcAppAuthGuardServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AuthGuardService", function () {
      return AuthGuardService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _storage_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ./storage.service */
    "./src/app/storage.service.ts");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");

    var AuthGuardService = /*#__PURE__*/function () {
      function AuthGuardService(storageService, navController) {
        _classCallCheck(this, AuthGuardService);

        this.storageService = storageService;
        this.navController = navController;
      }

      _createClass(AuthGuardService, [{
        key: "canActivate",
        value: function canActivate(route, state) {
          if (!this.storageService.isUserPresent()) {
            this.navController.navigateRoot('login');
            return false;
          }

          return true;
        }
      }]);

      return AuthGuardService;
    }();

    AuthGuardService.ctorParameters = function () {
      return [{
        type: _storage_service__WEBPACK_IMPORTED_MODULE_2__["StorageService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"]
      }];
    };

    AuthGuardService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_storage_service__WEBPACK_IMPORTED_MODULE_2__["StorageService"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"]])], AuthGuardService);
    /***/
  },

  /***/
  "./src/app/contants.ts":
  /*!*****************************!*\
    !*** ./src/app/contants.ts ***!
    \*****************************/

  /*! exports provided: BaseUrl, COMETCHAT_CONSTANTS, ROLES */

  /***/
  function srcAppContantsTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "BaseUrl", function () {
      return BaseUrl;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "COMETCHAT_CONSTANTS", function () {
      return COMETCHAT_CONSTANTS;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ROLES", function () {
      return ROLES;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js"); //Live Server
    // export const BaseUrl = 'http://ec2-3-17-28-7.us-east-2.compute.amazonaws.com:1337';
    // export const COMETCHAT_CONSTANTS = {
    //     APP_ID: '190385dcec51285',
    //     REGION: 'US',
    //     API_KEY: '5cafae1939d4fc620698c50ae3f25e727fc90213'
    // }
    // Test Server


    var BaseUrl = 'https://testorbit.wattmonk.com/api';
    var COMETCHAT_CONSTANTS = {
      APP_ID: '22738c62a78b107',
      REGION: 'US',
      API_KEY: '3afc04a7495edb03f4c7c802096a954faf7e3a27'
    }; //Development Server
    //export const BaseUrl = 'https://devspace.wattmonk.com/api';
    //export const COMETCHAT_CONSTANTS = {
    //  APP_ID: '2145560cac03137',
    //REGION: 'US',
    //API_KEY: '83ac811da8283c9e235ab912bf7a6213c207dd4d'
    //}

    var ROLES;

    (function (ROLES) {
      ROLES[ROLES["SuperAdmin"] = 4] = "SuperAdmin";
      ROLES[ROLES["ContractorSuperAdmin"] = 6] = "ContractorSuperAdmin";
      ROLES[ROLES["ContractorAdmin"] = 7] = "ContractorAdmin";
      ROLES[ROLES["Admin"] = 5] = "Admin";
      ROLES[ROLES["BD"] = 3] = "BD";
      ROLES[ROLES["Designer"] = 8] = "Designer";
      ROLES[ROLES["Surveyor"] = 9] = "Surveyor";
      ROLES[ROLES["Analyst"] = 10] = "Analyst";
    })(ROLES || (ROLES = {}));
    /***/

  },

  /***/
  "./src/app/model/constants.ts":
  /*!************************************!*\
    !*** ./src/app/model/constants.ts ***!
    \************************************/

  /*! exports provided: ScheduleFormEvent, UserRoles, MapPageType, INVALID_EMAIL_MESSAGE, FIELD_REQUIRED, COMET_CHAT_APP_ID, COMET_CHAT_AUTH_KEY, COMET_CHAT_REGION, GOOGLE_API_KEY, ImageUploadModel */

  /***/
  function srcAppModelConstantsTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ScheduleFormEvent", function () {
      return ScheduleFormEvent;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "UserRoles", function () {
      return UserRoles;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MapPageType", function () {
      return MapPageType;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "INVALID_EMAIL_MESSAGE", function () {
      return INVALID_EMAIL_MESSAGE;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "FIELD_REQUIRED", function () {
      return FIELD_REQUIRED;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "COMET_CHAT_APP_ID", function () {
      return COMET_CHAT_APP_ID;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "COMET_CHAT_AUTH_KEY", function () {
      return COMET_CHAT_AUTH_KEY;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "COMET_CHAT_REGION", function () {
      return COMET_CHAT_REGION;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "GOOGLE_API_KEY", function () {
      return GOOGLE_API_KEY;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ImageUploadModel", function () {
      return ImageUploadModel;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");

    var ScheduleFormEvent;

    (function (ScheduleFormEvent) {
      ScheduleFormEvent[ScheduleFormEvent["NO_EVENT"] = 0] = "NO_EVENT";
      ScheduleFormEvent[ScheduleFormEvent["SAVE_DESIGN_FORM"] = 1] = "SAVE_DESIGN_FORM";
      ScheduleFormEvent[ScheduleFormEvent["SAVE_SURVEY_FORM"] = 2] = "SAVE_SURVEY_FORM";
      ScheduleFormEvent[ScheduleFormEvent["START_SURVEY"] = 3] = "START_SURVEY";
    })(ScheduleFormEvent || (ScheduleFormEvent = {}));

    var UserRoles;

    (function (UserRoles) {
      UserRoles[UserRoles["ADMIN"] = 5] = "ADMIN";
      UserRoles[UserRoles["BD"] = 3] = "BD";
      UserRoles[UserRoles["DESIGNER"] = 8] = "DESIGNER";
      UserRoles[UserRoles["SURVEYOR"] = 9] = "SURVEYOR";
      UserRoles[UserRoles["ANALYST"] = 10] = "ANALYST";
    })(UserRoles || (UserRoles = {}));

    var MapPageType;

    (function (MapPageType) {
      MapPageType[MapPageType["CAMERA_INTERFACE"] = 0] = "CAMERA_INTERFACE";
      MapPageType[MapPageType["IMAGE_PREVIEW"] = 1] = "IMAGE_PREVIEW";
      MapPageType[MapPageType["IMAGE_PREVIEW_WITH_OPTIONS"] = 2] = "IMAGE_PREVIEW_WITH_OPTIONS";
      MapPageType[MapPageType["DETAILS_FORM"] = 3] = "DETAILS_FORM";
      MapPageType[MapPageType["NONE"] = 4] = "NONE";
      MapPageType[MapPageType["MAP_PAGE"] = 5] = "MAP_PAGE";
    })(MapPageType || (MapPageType = {}));

    var INVALID_EMAIL_MESSAGE = 'Invalid Email';
    var FIELD_REQUIRED = 'This field is required';
    var COMET_CHAT_APP_ID = '190385dcec51285';
    var COMET_CHAT_AUTH_KEY = '5cafae1939d4fc620698c50ae3f25e727fc90213';
    var COMET_CHAT_REGION = 'us';
    var GOOGLE_API_KEY = 'AIzaSyCePxz4wA_knfjvNBhV0RKzrySsf4o8QFU'; // export const CAMERA_MODULE_MENU_BATTERY: MenuModel[] = [
    //   {
    //     name: 'Electricals',
    //     isSelected: true,
    //     imageModel: [],
    //     subMenu: [
    //       {
    //         name: 'MSP',
    //         isSelected: true,
    //         allCaptured: false,
    //         askBeforeImage: false,
    //         answered: false,
    //         questionToAsk: '',
    //         formControlToUpdate: '',
    //         images: [
    //           {
    //             image: '',
    //             imageTitle: 'Long Shot',
    //             popupTitle: 'Confirm',
    //             showPopup: true,
    //             popupQuestion: 'Is MSP location inside or outside of building?',
    //             questionType: QuestionType.YES_NO,
    //             questionOptions: ['Inside', 'Outside'],
    //             givenAnswer: '',
    //             formValueToUpdate: 'msplocation',
    //             imageUploadTag: 'mspimages',
    //             imageName: 'msplongshot'
    //           },
    //           {
    //             image: '',
    //             imageTitle: 'Open Shutter, Zoom Shot',
    //             showPopup: true,
    //             popupTitle: 'Confirm',
    //             popupQuestion: 'Main Breaker Size',
    //             questionType: QuestionType.INPUT_NUMBER,
    //             questionOptions: [],
    //             givenAnswer: '',
    //             formValueToUpdate: 'mainbreakersize',
    //             imageUploadTag: 'mspimages',
    //             imageName: 'mspopenshutterzoomshot'
    //           },
    //           {
    //             image: '',
    //             imageTitle: 'Zoom Shot',
    //             showPopup: true,
    //             popupTitle: 'Confirm',
    //             popupQuestion: 'MSP Rating',
    //             questionType: QuestionType.INPUT_NUMBER,
    //             questionOptions: ['MSP Rating', 'Bus Rating'],
    //             givenAnswer: '',
    //             formValueToUpdate: 'msprating',
    //             imageUploadTag: 'mspimages',
    //             imageName: 'mspzoomshot'
    //           },
    //           {
    //             image: '',
    //             imageTitle: 'Without Cover, Zoom shot',
    //             showPopup: true,
    //             popupTitle: 'Confirm',
    //             popupQuestion: 'Main breaker location in MSP',
    //             questionType: QuestionType.RADIO_BUTTON,
    //             questionOptions: ['Top', 'Bottom', 'Center'],
    //             givenAnswer: '',
    //             formValueToUpdate: 'mspbreaker',
    //             imageUploadTag: 'mspimages',
    //             imageName: 'mspwithoutcovershot'
    //           }
    //         ]
    //       },
    //       {
    //         name: 'PV Inverter',
    //         isSelected: false,
    //         allCaptured: false,
    //         askBeforeImage: false,
    //         answered: false,
    //         questionToAsk: '',
    //         formControlToUpdate: '',
    //         images: [
    //           {
    //             image: '',
    //             imageTitle: 'Wide angle shot',
    //             showPopup: true,
    //             popupTitle: 'Confirm',
    //             popupQuestion: 'Inverter Location',
    //             questionType: QuestionType.YES_NO,
    //             questionOptions: ['Inside', 'Outside'],
    //             givenAnswer: '',
    //             formValueToUpdate: 'pvinverterlocation',
    //             imageUploadTag: 'pvinverterimages',
    //             imageName: 'pvinverterwideshoturl'
    //           },
    //           {
    //             image: '',
    //             imageTitle: 'Zoom shot',
    //             showPopup: true,
    //             popupTitle: 'Confirm',
    //             popupQuestion: 'Inverter manufacture model',
    //             questionType: QuestionType.INVERTER_MODEL,
    //             questionOptions: [],
    //             givenAnswer: '',
    //             formValueToUpdate: '',
    //             imageUploadTag: 'pvinverterimages',
    //             imageName: 'pvinverterzoomshoturl'
    //           }
    //         ]
    //       },
    //       {
    //         name: 'PV Meter',
    //         isSelected: false,
    //         allCaptured: false,
    //         askBeforeImage: true,
    //         answered: false,
    //         questionToAsk: 'Is PV meter installed in premises',
    //         formControlToUpdate: 'pvmeter',
    //         images: [
    //           {
    //             image: '',
    //             imageTitle: 'PV Meter',
    //             showPopup: true,
    //             popupTitle: 'Confirm',
    //             popupQuestion: 'Inverter Location',
    //             questionType: QuestionType.NONE,
    //             questionOptions: [],
    //             givenAnswer: '',
    //             formValueToUpdate: '',
    //             imageUploadTag: 'pvmeterimages',
    //             imageName: 'pvmeterwideshoturl'
    //           }
    //         ]
    //       },
    //       {
    //         name: 'AC Disconnect',
    //         isSelected: false,
    //         allCaptured: false,
    //         askBeforeImage: true,
    //         answered: false,
    //         questionToAsk: 'Is AC disconnected?',
    //         formControlToUpdate: 'acdisconnect',
    //         images: [
    //           {
    //             image: '',
    //             imageTitle: 'Wide Angle Shot',
    //             showPopup: true,
    //             popupTitle: 'Confirm',
    //             popupQuestion: 'Inverter Location',
    //             questionType: QuestionType.NONE,
    //             questionOptions: [],
    //             givenAnswer: '',
    //             formValueToUpdate: '',
    //             imageUploadTag: 'acdisconnectimages',
    //             imageName: 'acdisconnectwideshoturl'
    //           },
    //           {
    //             image: '',
    //             imageTitle: 'Zoom Shot',
    //             showPopup: true,
    //             popupTitle: 'Confirm',
    //             popupQuestion: 'Inverter Location',
    //             questionType: QuestionType.NONE,
    //             questionOptions: [],
    //             givenAnswer: '',
    //             formValueToUpdate: '',
    //             imageUploadTag: 'acdisconnectimages',
    //             imageName: 'acdisconnectzoomshoturl'
    //           }
    //         ]
    //       },
    //       {
    //         name: 'Utility Meter',
    //         isSelected: false,
    //         allCaptured: false,
    //         askBeforeImage: false,
    //         answered: false,
    //         questionToAsk: '',
    //         formControlToUpdate: '',
    //         images: [
    //           {
    //             image: '',
    //             imageTitle: 'Wide angle shot',
    //             showPopup: true,
    //             popupTitle: 'Confirm',
    //             popupQuestion: 'Is Utility meter is attached or detached with MSP?',
    //             questionType: QuestionType.YES_NO,
    //             questionOptions: ['Attach', 'Detach'],
    //             givenAnswer: '',
    //             formValueToUpdate: 'utilitymeter',
    //             imageUploadTag: 'utilitymeterimages',
    //             imageName: 'umwideshoturl'
    //           },
    //           {
    //             image: '',
    //             imageTitle: 'Zoom shot',
    //             showPopup: true,
    //             popupTitle: 'Confirm',
    //             popupQuestion: 'Utility Name',
    //             questionType: QuestionType.UTILITIES,
    //             questionOptions: [],
    //             givenAnswer: '',
    //             formValueToUpdate: '',
    //             imageUploadTag: 'utilitymeterimages',
    //             imageName: 'umzoomshoturl'
    //           }
    //         ]
    //       }
    //     ]
    //   },
    //   {
    //     name: 'Solar',
    //     isSelected: false,
    //     imageModel: [],
    //     subMenu: [
    //       {
    //         name: 'Panels',
    //         isSelected: true,
    //         allCaptured: false,
    //         askBeforeImage: false,
    //         answered: false,
    //         questionToAsk: '',
    //         formControlToUpdate: '',
    //         images: [{
    //           image: '',
    //           imageTitle: 'Wide angle shot',
    //           showPopup: false,
    //           popupTitle: 'Confirm',
    //           popupQuestion: 'Number of Modules',
    //           questionType: QuestionType.INPUT_NUMBER,
    //           questionOptions: [],
    //           givenAnswer: '',
    //           formValueToUpdate: 'numberofmodules',
    //           imageUploadTag: 'roofimages',
    //           imageName: 'solarpanels'
    //         }]
    //       }
    //     ]
    //   },
    //   {
    //     name: 'Roof',
    //     isSelected: false,
    //     imageModel: [{
    //       image: '',
    //       imageTitle: '',
    //       popupTitle: 'Confirm',
    //       showPopup: false,
    //       popupQuestion: '',
    //       questionType: QuestionType.MORE_PHOTOS,
    //       questionOptions: [],
    //       givenAnswer: '',
    //       formValueToUpdate: '',
    //       imageUploadTag: 'roofimages',
    //       imageName: 'modulewideshoturl1'
    //     }],
    //     subMenu: []
    //   },
    //   {
    //     name: 'Appliances',
    //     isSelected: false,
    //     imageModel: [{
    //       image: '',
    //       imageTitle: '',
    //       popupTitle: 'Appliance Name',
    //       showPopup: false,
    //       popupQuestion: 'Please enter appliance name',
    //       questionType: QuestionType.MORE_PHOTOS_WITH_INPUT_STRING,
    //       questionOptions: [],
    //       givenAnswer: '',
    //       formValueToUpdate: '',
    //       imageUploadTag: 'appliancesimages',
    //       imageName: 'appliances1'
    //     }],
    //     subMenu: []
    //   },
    //   {
    //     name: 'Details',
    //     isSelected: false,
    //     imageModel: null,
    //     subMenu: null
    //   }
    // ];
    // export const CAMERA_MODULE_MENU_PV: MenuModel[] = [
    //   {
    //     name: 'Electricals',
    //     isSelected: true,
    //     imageModel: [],
    //     subMenu: [
    //       {
    //         name: 'MSP',
    //         isSelected: true,
    //         allCaptured: false,
    //         askBeforeImage: false,
    //         answered: false,
    //         questionToAsk: '',
    //         formControlToUpdate: '',
    //         images: [
    //           {
    //             image: '',
    //             imageTitle: 'Long Shot',
    //             popupTitle: 'Confirm',
    //             showPopup: true,
    //             popupQuestion: 'Is MSP location inside or outside of building?',
    //             questionType: QuestionType.YES_NO,
    //             questionOptions: ['Inside', 'Outside'],
    //             givenAnswer: '',
    //             formValueToUpdate: 'msplocation',
    //             imageUploadTag: 'mspimages',
    //             imageName: 'msplongshot'
    //           },
    //           {
    //             image: '',
    //             imageTitle: 'Open Shutter, Zoom Shot',
    //             showPopup: true,
    //             popupTitle: 'Confirm',
    //             popupQuestion: 'Main Breaker Size',
    //             questionType: QuestionType.INPUT_NUMBER,
    //             questionOptions: [],
    //             givenAnswer: '',
    //             formValueToUpdate: 'mainbreakersize',
    //             imageUploadTag: 'mspimages',
    //             imageName: 'mspopenshutterzoomshot'
    //           },
    //           {
    //             image: '',
    //             imageTitle: 'Zoom Shot',
    //             showPopup: true,
    //             popupTitle: 'Confirm',
    //             popupQuestion: 'MSP Rating',
    //             questionType: QuestionType.INPUT_NUMBER,
    //             questionOptions: ['MSP Rating', 'Bus Rating'],
    //             givenAnswer: '',
    //             formValueToUpdate: 'msprating',
    //             imageUploadTag: 'mspimages',
    //             imageName: 'mspzoomshot'
    //           },
    //           {
    //             image: '',
    //             imageTitle: 'Without Cover, Zoom shot',
    //             showPopup: true,
    //             popupTitle: 'Confirm',
    //             popupQuestion: 'Main breaker location in MSP',
    //             questionType: QuestionType.RADIO_BUTTON,
    //             questionOptions: ['Top', 'Bottom', 'Center'],
    //             givenAnswer: '',
    //             formValueToUpdate: 'mspbreaker',
    //             imageUploadTag: 'mspimages',
    //             imageName: 'mspwithoutcovershot'
    //           }
    //         ]
    //       },
    //       {
    //         name: 'Existing Sub Panel',
    //         isSelected: false,
    //         allCaptured: false,
    //         askBeforeImage: false,
    //         answered: false,
    //         questionToAsk: '',
    //         formControlToUpdate: '',
    //         images: [
    //           {
    //             image: '',
    //             imageTitle: '',
    //             showPopup: true,
    //             popupTitle: '',
    //             popupQuestion: '',
    //             questionType: QuestionType.NONE,
    //             questionOptions: [],
    //             givenAnswer: '',
    //             formValueToUpdate: '',
    //             imageUploadTag: 'existingsubpanelimages',
    //             imageName: 'Existingsubpanelimages'
    //           }
    //         ]
    //       },
    //       {
    //         name: 'Utility Meter',
    //         isSelected: false,
    //         allCaptured: false,
    //         askBeforeImage: false,
    //         answered: false,
    //         questionToAsk: '',
    //         formControlToUpdate: '',
    //         images: [
    //           {
    //             image: '',
    //             imageTitle: 'Wide angle shot',
    //             showPopup: true,
    //             popupTitle: 'Confirm',
    //             popupQuestion: 'Is Utility meter is attached or detached with MSP?',
    //             questionType: QuestionType.YES_NO,
    //             questionOptions: ['Attach', 'Detach'],
    //             givenAnswer: '',
    //             formValueToUpdate: 'utilitymeter',
    //             imageUploadTag: 'utilitymeterimages',
    //             imageName: 'umwideshoturl'
    //           },
    //           {
    //             image: '',
    //             imageTitle: 'Zoom shot',
    //             showPopup: true,
    //             popupTitle: 'Confirm',
    //             popupQuestion: 'Utility Name',
    //             questionType: QuestionType.UTILITIES,
    //             questionOptions: [],
    //             givenAnswer: '',
    //             formValueToUpdate: '',
    //             imageUploadTag: 'utilitymeterimages',
    //             imageName: 'umzoomshoturl'
    //           }
    //         ]
    //       }
    //     ]
    //   },
    //   {
    //     name: 'Roof',
    //     isSelected: false,
    //     imageModel: [],
    //     subMenu: [
    //       {
    //         name: 'Roof Photos',
    //         isSelected: false,
    //         allCaptured: false,
    //         askBeforeImage: false,
    //         answered: false,
    //         questionToAsk: '',
    //         formControlToUpdate: '',
    //         images: [
    //           {
    //             image: '',
    //             imageTitle: '',
    //             showPopup: true,
    //             popupTitle: '',
    //             popupQuestion: '',
    //             questionType: QuestionType.MORE_PHOTOS,
    //             questionOptions: [],
    //             givenAnswer: '',
    //             formValueToUpdate: '',
    //             imageUploadTag: 'roofimages',
    //             imageName: 'moduleshot1'
    //           }
    //         ]
    //       },
    //       {
    //         name: 'Roof Dimensions',
    //         isSelected: false,
    //         allCaptured: false,
    //         askBeforeImage: false,
    //         answered: false,
    //         questionToAsk: '',
    //         formControlToUpdate: '',
    //         images: [
    //           {
    //             image: '',
    //             imageTitle: '',
    //             showPopup: true,
    //             popupTitle: '',
    //             popupQuestion: '',
    //             questionType: QuestionType.MORE_PHOTOS,
    //             questionOptions: [],
    //             givenAnswer: '',
    //             formValueToUpdate: '',
    //             imageUploadTag: 'roofdimensionimages',
    //             imageName: 'roofdimensions1'
    //           }
    //         ]
    //       },
    //       {
    //         name: 'Obstacle Photos',
    //         isSelected: false,
    //         allCaptured: false,
    //         askBeforeImage: false,
    //         answered: false,
    //         questionToAsk: '',
    //         formControlToUpdate: '',
    //         images: [
    //           {
    //             image: '',
    //             imageTitle: '',
    //             showPopup: true,
    //             popupTitle: '',
    //             popupQuestion: '',
    //             questionType: QuestionType.MORE_PHOTOS,
    //             questionOptions: [],
    //             givenAnswer: '',
    //             formValueToUpdate: '',
    //             imageUploadTag: 'obstaclesimages',
    //             imageName: 'obstaclesphotos1'
    //           }
    //         ]
    //       },
    //       {
    //         name: 'Obstacle Dimensions',
    //         isSelected: false,
    //         allCaptured: false,
    //         askBeforeImage: false,
    //         answered: false,
    //         questionToAsk: '',
    //         formControlToUpdate: '',
    //         images: [
    //           {
    //             image: '',
    //             imageTitle: '',
    //             showPopup: true,
    //             popupTitle: '',
    //             popupQuestion: '',
    //             questionType: QuestionType.MORE_PHOTOS,
    //             questionOptions: [],
    //             givenAnswer: '',
    //             formValueToUpdate: '',
    //             imageUploadTag: 'obstaclesdimensionsimages',
    //             imageName: 'obstaclesdimensions1'
    //           }
    //         ]
    //       }
    //     ]
    //   },
    //   {
    //     name: 'Attic',
    //     isSelected: false,
    //     imageModel: [],
    //     subMenu: [
    //       {
    //         name: 'Attic Photos',
    //         isSelected: false,
    //         allCaptured: false,
    //         askBeforeImage: false,
    //         answered: false,
    //         questionToAsk: '',
    //         formControlToUpdate: '',
    //         images: [
    //           {
    //             image: '',
    //             imageTitle: '',
    //             showPopup: true,
    //             popupTitle: '',
    //             popupQuestion: '',
    //             questionType: QuestionType.MORE_PHOTOS,
    //             questionOptions: [],
    //             givenAnswer: '',
    //             formValueToUpdate: '',
    //             imageUploadTag: 'atticimages',
    //             imageName: 'atticphotos1'
    //           }
    //         ]
    //       }
    //     ]
    //   },
    //   {
    //     name: 'Appliances',
    //     isSelected: false,
    //     imageModel: [{
    //       image: '',
    //       imageTitle: '',
    //       popupTitle: 'Appliance Name',
    //       showPopup: false,
    //       popupQuestion: 'Please enter appliance name',
    //       questionType: QuestionType.MORE_PHOTOS_WITH_INPUT_STRING,
    //       questionOptions: [],
    //       givenAnswer: '',
    //       formValueToUpdate: '',
    //       imageUploadTag: 'appliancesimages',
    //       imageName: 'appliances1'
    //     }],
    //     subMenu: []
    //   },
    //   {
    //     name: 'Details',
    //     isSelected: false,
    //     imageModel: null,
    //     subMenu: null
    //   }
    // ];
    // export const CAMERA_MODULE_MENU_PV_BATTERY: MenuModel[] = [
    //   {
    //     name: 'Electricals',
    //     isSelected: true,
    //     imageModel: [],
    //     subMenu: [
    //       {
    //         name: 'MSP',
    //         isSelected: true,
    //         allCaptured: false,
    //         askBeforeImage: false,
    //         answered: false,
    //         questionToAsk: '',
    //         formControlToUpdate: '',
    //         images: [
    //           {
    //             image: '',
    //             imageTitle: 'Long Shot',
    //             popupTitle: 'Confirm',
    //             showPopup: true,
    //             popupQuestion: 'Is MSP location inside or outside of building?',
    //             questionType: QuestionType.YES_NO,
    //             questionOptions: ['Inside', 'Outside'],
    //             givenAnswer: '',
    //             formValueToUpdate: 'msplocation',
    //             imageUploadTag: 'mspimages',
    //             imageName: 'msplongshot'
    //           },
    //           {
    //             image: '',
    //             imageTitle: 'Open Shutter, Zoom Shot',
    //             showPopup: true,
    //             popupTitle: 'Confirm',
    //             popupQuestion: 'Main Breaker Size',
    //             questionType: QuestionType.INPUT_NUMBER,
    //             questionOptions: [],
    //             givenAnswer: '',
    //             formValueToUpdate: 'mainbreakersize',
    //             imageUploadTag: 'mspimages',
    //             imageName: 'mspopenshutterzoomshot'
    //           },
    //           {
    //             image: '',
    //             imageTitle: 'Zoom Shot',
    //             showPopup: true,
    //             popupTitle: 'Confirm',
    //             popupQuestion: 'MSP Rating',
    //             questionType: QuestionType.INPUT_NUMBER,
    //             questionOptions: ['MSP Rating', 'Bus Rating'],
    //             givenAnswer: '',
    //             formValueToUpdate: 'msprating',
    //             imageUploadTag: 'mspimages',
    //             imageName: 'mspzoomshot'
    //           },
    //           {
    //             image: '',
    //             imageTitle: 'Without Cover, Zoom shot',
    //             showPopup: true,
    //             popupTitle: 'Confirm',
    //             popupQuestion: 'Main breaker location in MSP',
    //             questionType: QuestionType.RADIO_BUTTON,
    //             questionOptions: ['Top', 'Bottom', 'Center'],
    //             givenAnswer: '',
    //             formValueToUpdate: 'mspbreaker',
    //             imageUploadTag: 'mspimages',
    //             imageName: 'mspwithoutcovershot'
    //           }
    //         ]
    //       },
    //       {
    //         name: 'Existing Sub Panel',
    //         isSelected: false,
    //         allCaptured: false,
    //         askBeforeImage: false,
    //         answered: false,
    //         questionToAsk: '',
    //         formControlToUpdate: '',
    //         images: [
    //           {
    //             image: '',
    //             imageTitle: '',
    //             showPopup: true,
    //             popupTitle: '',
    //             popupQuestion: '',
    //             questionType: QuestionType.NONE,
    //             questionOptions: [],
    //             givenAnswer: '',
    //             formValueToUpdate: '',
    //             imageUploadTag: 'existingsubpanelimages',
    //             imageName: 'existingsubpanelimages'
    //           }
    //         ]
    //       },
    //       {
    //         name: 'Location of Battery',
    //         isSelected: false,
    //         allCaptured: false,
    //         askBeforeImage: false,
    //         answered: false,
    //         questionToAsk: '',
    //         formControlToUpdate: '',
    //         images: [
    //           {
    //             image: '',
    //             imageTitle: '',
    //             showPopup: true,
    //             popupTitle: '',
    //             popupQuestion: '',
    //             questionType: QuestionType.NONE,
    //             questionOptions: [],
    //             givenAnswer: '',
    //             formValueToUpdate: '',
    //             imageUploadTag: 'roofimages',
    //             imageName: 'locationofbattery'
    //           }
    //         ]
    //       },
    //       {
    //         name: 'Utility Meter',
    //         isSelected: false,
    //         allCaptured: false,
    //         askBeforeImage: false,
    //         answered: false,
    //         questionToAsk: '',
    //         formControlToUpdate: '',
    //         images: [
    //           {
    //             image: '',
    //             imageTitle: 'Wide angle shot',
    //             showPopup: true,
    //             popupTitle: 'Confirm',
    //             popupQuestion: 'Is Utility meter is attached or detached with MSP?',
    //             questionType: QuestionType.YES_NO,
    //             questionOptions: ['Attach', 'Detach'],
    //             givenAnswer: '',
    //             formValueToUpdate: 'utilitymeter',
    //             imageUploadTag: 'utilitymeterimages',
    //             imageName: 'umwideshoturl'
    //           },
    //           {
    //             image: '',
    //             imageTitle: 'Zoom shot',
    //             showPopup: true,
    //             popupTitle: 'Confirm',
    //             popupQuestion: 'Utility Name',
    //             questionType: QuestionType.UTILITIES,
    //             questionOptions: [],
    //             givenAnswer: '',
    //             formValueToUpdate: '',
    //             imageUploadTag: 'utilitymeterimages',
    //             imageName: 'umzoomshoturl'
    //           }
    //         ]
    //       }
    //     ]
    //   },
    //   {
    //     name: 'Roof',
    //     isSelected: false,
    //     imageModel: [],
    //     subMenu: [
    //       {
    //         name: 'Roof Photos',
    //         isSelected: false,
    //         allCaptured: false,
    //         askBeforeImage: false,
    //         answered: false,
    //         questionToAsk: '',
    //         formControlToUpdate: '',
    //         images: [
    //           {
    //             image: '',
    //             imageTitle: '',
    //             showPopup: true,
    //             popupTitle: '',
    //             popupQuestion: '',
    //             questionType: QuestionType.MORE_PHOTOS,
    //             questionOptions: [],
    //             givenAnswer: '',
    //             formValueToUpdate: '',
    //             imageUploadTag: 'roofimages',
    //             imageName: 'moduleshot1'
    //           }
    //         ]
    //       },
    //       {
    //         name: 'Roof Dimensions',
    //         isSelected: false,
    //         allCaptured: false,
    //         askBeforeImage: false,
    //         answered: false,
    //         questionToAsk: '',
    //         formControlToUpdate: '',
    //         images: [
    //           {
    //             image: '',
    //             imageTitle: '',
    //             showPopup: true,
    //             popupTitle: '',
    //             popupQuestion: '',
    //             questionType: QuestionType.MORE_PHOTOS,
    //             questionOptions: [],
    //             givenAnswer: '',
    //             formValueToUpdate: '',
    //             imageUploadTag: 'roofdimensionimages',
    //             imageName: 'roofdimensions1'
    //           }
    //         ]
    //       },
    //       {
    //         name: 'Obstacle Photos',
    //         isSelected: false,
    //         allCaptured: false,
    //         askBeforeImage: false,
    //         answered: false,
    //         questionToAsk: '',
    //         formControlToUpdate: '',
    //         images: [
    //           {
    //             image: '',
    //             imageTitle: '',
    //             showPopup: true,
    //             popupTitle: '',
    //             popupQuestion: '',
    //             questionType: QuestionType.MORE_PHOTOS,
    //             questionOptions: [],
    //             givenAnswer: '',
    //             formValueToUpdate: '',
    //             imageUploadTag: 'obstaclesimages',
    //             imageName: 'obstaclephotos1'
    //           }
    //         ]
    //       },
    //       {
    //         name: 'Obstacle Dimensions',
    //         isSelected: false,
    //         allCaptured: false,
    //         askBeforeImage: false,
    //         answered: false,
    //         questionToAsk: '',
    //         formControlToUpdate: '',
    //         images: [
    //           {
    //             image: '',
    //             imageTitle: '',
    //             showPopup: true,
    //             popupTitle: '',
    //             popupQuestion: '',
    //             questionType: QuestionType.MORE_PHOTOS,
    //             questionOptions: [],
    //             givenAnswer: '',
    //             formValueToUpdate: '',
    //             imageUploadTag: 'obstaclesdimensionsimages',
    //             imageName: 'obstaclesdimensions1'
    //           }
    //         ]
    //       }
    //     ]
    //   },
    //   {
    //     name: 'Attic',
    //     isSelected: false,
    //     imageModel: [],
    //     subMenu: [
    //       {
    //         name: 'Attic Photos',
    //         isSelected: false,
    //         allCaptured: false,
    //         askBeforeImage: false,
    //         answered: false,
    //         questionToAsk: '',
    //         formControlToUpdate: '',
    //         images: [
    //           {
    //             image: '',
    //             imageTitle: '',
    //             showPopup: true,
    //             popupTitle: '',
    //             popupQuestion: '',
    //             questionType: QuestionType.MORE_PHOTOS,
    //             questionOptions: [],
    //             givenAnswer: '',
    //             formValueToUpdate: '',
    //             imageUploadTag: 'atticimages',
    //             imageName: 'atticphotos1'
    //           }
    //         ]
    //       }
    //     ]
    //   },
    //   {
    //     name: 'Appliances',
    //     isSelected: false,
    //     imageModel: [{
    //       image: '',
    //       imageTitle: '',
    //       popupTitle: 'Appliance Name',
    //       showPopup: false,
    //       popupQuestion: 'Please enter appliance name',
    //       questionType: QuestionType.MORE_PHOTOS_WITH_INPUT_STRING,
    //       questionOptions: [],
    //       givenAnswer: '',
    //       formValueToUpdate: '',
    //       imageUploadTag: 'appliancesimages',
    //       imageName: 'appliances1'
    //     }],
    //     subMenu: []
    //   },
    //   {
    //     name: 'Details',
    //     isSelected: false,
    //     imageModel: null,
    //     subMenu: null
    //   }
    // ];
    // export const EQUIPMENTS: Equipment[] = [
    //   {
    //     id: 1,
    //     name: 'AC Disconnect',
    //     color: '#FEC412',
    //     disabledColor: '#fec41280',
    //     enabled: true
    //   }, {
    //     id: 2,
    //     name: 'PV Meter',
    //     color: '#6AA84F',
    //     disabledColor: '#6aa84f80',
    //     enabled: true
    //   }, {
    //     id: 3,
    //     name: 'MSP',
    //     color: '#FF0000',
    //     disabledColor: '#ff000080',
    //     enabled: true
    //   }, {
    //     id: 4,
    //     name: 'Inverter',
    //     color: '#6D9EEB',
    //     disabledColor: '#6d9eeb80',
    //     enabled: true
    //   }, {
    //     id: 5,
    //     name: 'Battery',
    //     color: '#FF00FF',
    //     disabledColor: '#ff00ff80',
    //     enabled: true
    //   }, {
    //     id: 6,
    //     name: 'GP',
    //     color: '#00FFFF',
    //     disabledColor: '#00ffff80',
    //     enabled: true
    //   }, {
    //     id: 7,
    //     name: 'Electrical Equipment',
    //     color: '#FFFF00',
    //     disabledColor: '#ffff0080',
    //     enabled: true
    //   }
    // ];

    var ImageUploadModel = function ImageUploadModel() {
      _classCallCheck(this, ImageUploadModel);
    };
    /***/

  },

  /***/
  "./src/app/networkdetect.service.ts":
  /*!******************************************!*\
    !*** ./src/app/networkdetect.service.ts ***!
    \******************************************/

  /*! exports provided: NetworkdetectService */

  /***/
  function srcAppNetworkdetectServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "NetworkdetectService", function () {
      return NetworkdetectService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _ionic_native_network_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic-native/network/ngx */
    "./node_modules/@ionic-native/network/ngx/index.js");
    /* harmony import */


    var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! rxjs */
    "./node_modules/rxjs/_esm2015/index.js");

    var NetworkdetectService = /*#__PURE__*/function () {
      function NetworkdetectService(network) {
        _classCallCheck(this, NetworkdetectService);

        this.network = network;
        this.networkSwitch = new rxjs__WEBPACK_IMPORTED_MODULE_3__["BehaviorSubject"](true);
      }

      _createClass(NetworkdetectService, [{
        key: "networkDisconnect",
        value: function networkDisconnect() {
          var _this6 = this;

          this.network.onDisconnect().subscribe(function () {
            console.log('network was disconnected :-(');

            _this6.networkSwitch.next(false); // netSwitch= this.networkSwitch;

          });
        }
      }, {
        key: "networkConnect",
        value: function networkConnect() {
          var _this7 = this;

          var connectSubscription = this.network.onConnect().subscribe(function () {
            console.log('network connected!');

            _this7.networkSwitch.next(true); // netSwitch = this.networkSwitch;
            // We just got a connection but we need to wait briefly
            // before we determine the connection type. Might need to wait.
            // prior to doing any api requests as well.


            setTimeout(function () {
              if (_this7.network.type === 'wifi') {
                console.log('we got a wifi connection, woohoo!');
              }
            }, 3000);
          });
        }
      }]);

      return NetworkdetectService;
    }();

    NetworkdetectService.ctorParameters = function () {
      return [{
        type: _ionic_native_network_ngx__WEBPACK_IMPORTED_MODULE_2__["Network"]
      }];
    };

    NetworkdetectService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_native_network_ngx__WEBPACK_IMPORTED_MODULE_2__["Network"]])], NetworkdetectService);
    /***/
  },

  /***/
  "./src/app/storage.service.ts":
  /*!************************************!*\
    !*** ./src/app/storage.service.ts ***!
    \************************************/

  /*! exports provided: StorageService */

  /***/
  function srcAppStorageServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "StorageService", function () {
      return StorageService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");

    var StorageService = /*#__PURE__*/function () {
      function StorageService() {
        _classCallCheck(this, StorageService);
      }

      _createClass(StorageService, [{
        key: "isUserPresent",
        value: function isUserPresent() {
          return localStorage.getItem('user') !== null && localStorage.getItem('user') !== undefined;
        }
      }, {
        key: "setUser",
        value: function setUser(user, jwt) {
          localStorage.setItem('user', JSON.stringify(user));
          this.setUserId(user.id);

          if (user.parent) {
            this.setParentId(user.parent.id);
          }

          this.setJWTToken(jwt);
          this.setLoggedInOnce();
        }
      }, {
        key: "getUser",
        value: function getUser() {
          return JSON.parse(localStorage.getItem('user'));
        }
      }, {
        key: "setDesgings",
        value: function setDesgings(desgins) {
          localStorage.setItem('desgin', JSON.stringify(desgins));
        }
      }, {
        key: "getDesgins",
        value: function getDesgins() {
          return JSON.parse(localStorage.getItem('desgin'));
        }
      }, {
        key: "setUserId",
        value: function setUserId(userId) {
          localStorage.setItem('userId', userId);
        }
      }, {
        key: "getUserID",
        value: function getUserID() {
          return localStorage.getItem('userId');
        }
      }, {
        key: "removeUser",
        value: function removeUser() {
          localStorage.removeItem('user');
        }
      }, {
        key: "setJWTToken",
        value: function setJWTToken(token) {
          localStorage.setItem('token', token); //console.log(token);
        }
      }, {
        key: "getJWTToken",
        value: function getJWTToken() {
          return localStorage.getItem('token');
        }
      }, {
        key: "isLocationAllowedOnIOS",
        value: function isLocationAllowedOnIOS() {
          if (localStorage.getItem('ios_location_allowed') === null || localStorage.getItem('ios_location_allowed') === undefined) {
            return false;
          } else {
            return JSON.parse(localStorage.getItem('ios_location_allowed'));
          }
        }
      }, {
        key: "isLocationCheckedOnIOS",
        value: function isLocationCheckedOnIOS() {
          if (localStorage.getItem('ios_location_checked') === null || localStorage.getItem('ios_location_checked') === undefined) {
            return false;
          } else {
            return JSON.parse(localStorage.getItem('ios_location_checked'));
          }
        }
      }, {
        key: "setLocationCheckedOnIOS",
        value: function setLocationCheckedOnIOS(status) {
          localStorage.setItem('ios_location_checked', JSON.stringify(status));
        }
      }, {
        key: "setLocationAllowedOnIOS",
        value: function setLocationAllowedOnIOS(status) {
          localStorage.setItem('ios_location_allowed', JSON.stringify(status));
        }
      }, {
        key: "setParentId",
        value: function setParentId(parentId) {
          localStorage.setItem('parentId', parentId);
        }
      }, {
        key: "getParentId",
        value: function getParentId() {
          return localStorage.getItem('parentId');
        }
      }, {
        key: "logout",
        value: function logout() {
          var username = this.getUserName();
          var password = this.getPassword();
          localStorage.clear();
          this.setLoggedInOnce();
          this.setUserName(username);
          this.setPassword(password);
        }
      }, {
        key: "setLoggedInOnce",
        value: function setLoggedInOnce() {
          localStorage.setItem('loggedInOnce', 'yes');
        }
      }, {
        key: "isLoggedInOnce",
        value: function isLoggedInOnce() {
          return localStorage.getItem('loggedInOnce') !== null && localStorage.getItem('loggedInOnce') !== undefined;
        }
      }, {
        key: "setUserName",
        value: function setUserName(username) {
          localStorage.setItem('username', username);
        }
      }, {
        key: "getUserName",
        value: function getUserName() {
          return this.checkKeyAndReturnValue('username');
        }
      }, {
        key: "setPassword",
        value: function setPassword(password) {
          localStorage.setItem('password', password);
        }
      }, {
        key: "getPassword",
        value: function getPassword() {
          return this.checkKeyAndReturnValue('password');
        }
      }, {
        key: "checkKeyAndReturnValue",
        value: function checkKeyAndReturnValue(key) {
          if (localStorage.getItem(key) === null || localStorage.getItem(key) === undefined) {
            return '';
          } else {
            return localStorage.getItem(key);
          }
        }
      }, {
        key: "setData",
        value: function setData(value) {
          this.data = value;
        }
      }, {
        key: "getData",
        value: function getData() {
          return this.data;
        }
      }]);

      return StorageService;
    }();

    StorageService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])], StorageService);
    /***/
  },

  /***/
  "./src/app/utilities.service.ts":
  /*!**************************************!*\
    !*** ./src/app/utilities.service.ts ***!
    \**************************************/

  /*! exports provided: UtilitiesService */

  /***/
  function srcAppUtilitiesServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "UtilitiesService", function () {
      return UtilitiesService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _utilities_success_modal_success_modal_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./utilities/success-modal/success-modal.component */
    "./src/app/utilities/success-modal/success-modal.component.ts");
    /* harmony import */


    var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! rxjs */
    "./node_modules/rxjs/_esm2015/index.js");
    /* harmony import */


    var _model_constants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./model/constants */
    "./src/app/model/constants.ts");

    var UtilitiesService = /*#__PURE__*/function () {
      function UtilitiesService(loadingController, toastController, alertController, modalController) {
        _classCallCheck(this, UtilitiesService);

        this.loadingController = loadingController;
        this.toastController = toastController;
        this.alertController = alertController;
        this.modalController = modalController;
        this.isLoading = false;
        this.address = new rxjs__WEBPACK_IMPORTED_MODULE_4__["BehaviorSubject"]({
          address: '',
          lat: 0,
          "long": 0,
          country: '',
          state: '',
          city: '',
          postalcode: ''
        });
        this.staticAddress = new rxjs__WEBPACK_IMPORTED_MODULE_4__["BehaviorSubject"]('');
        this.saveScheduleForm = new rxjs__WEBPACK_IMPORTED_MODULE_4__["BehaviorSubject"](_model_constants__WEBPACK_IMPORTED_MODULE_5__["ScheduleFormEvent"].NO_EVENT);
        this.homepageDesignRefresh = new rxjs__WEBPACK_IMPORTED_MODULE_4__["BehaviorSubject"](false);
        this.homepageSurveyRefresh = new rxjs__WEBPACK_IMPORTED_MODULE_4__["BehaviorSubject"](false);
        this.surveyDetailsRefresh = new rxjs__WEBPACK_IMPORTED_MODULE_4__["BehaviorSubject"](false);
        this.designDetailsRefresh = new rxjs__WEBPACK_IMPORTED_MODULE_4__["BehaviorSubject"](false);
        this.showBottomBarHomepage = new rxjs__WEBPACK_IMPORTED_MODULE_4__["BehaviorSubject"](true);
        this.uploadfile = new rxjs__WEBPACK_IMPORTED_MODULE_4__["BehaviorSubject"]('');
        this.manualInput = new rxjs__WEBPACK_IMPORTED_MODULE_4__["BehaviorSubject"]('');
        this.dataRefresh = new rxjs__WEBPACK_IMPORTED_MODULE_4__["BehaviorSubject"](false);
      }

      _createClass(UtilitiesService, [{
        key: "getAddressObservable",
        value: function getAddressObservable() {
          return this.address;
        }
      }, {
        key: "setAddress",
        value: function setAddress(address) {
          this.address.next(address);
        }
      }, {
        key: "getHomepageDesignRefresh",
        value: function getHomepageDesignRefresh() {
          return this.homepageDesignRefresh;
        }
      }, {
        key: "setHomepageDesignRefresh",
        value: function setHomepageDesignRefresh(refresh) {
          this.homepageDesignRefresh.next(refresh);
        }
      }, {
        key: "getHomepageSurveyRefresh",
        value: function getHomepageSurveyRefresh() {
          return this.homepageSurveyRefresh;
        }
      }, {
        key: "sethomepageSurveyRefresh",
        value: function sethomepageSurveyRefresh(refresh) {
          this.homepageSurveyRefresh.next(refresh);
        }
      }, {
        key: "getDataRefresh",
        value: function getDataRefresh() {
          return this.dataRefresh;
        }
      }, {
        key: "setDataRefresh",
        value: function setDataRefresh(refresh) {
          this.dataRefresh.next(refresh);
        }
      }, {
        key: "getSurveyDetailsRefresh",
        value: function getSurveyDetailsRefresh() {
          return this.surveyDetailsRefresh;
        }
      }, {
        key: "setSurveyDetailsRefresh",
        value: function setSurveyDetailsRefresh(refresh) {
          this.surveyDetailsRefresh.next(refresh);
        }
      }, {
        key: "getBottomBarHomepage",
        value: function getBottomBarHomepage() {
          return this.showBottomBarHomepage;
        }
      }, {
        key: "setBottomBarHomepage",
        value: function setBottomBarHomepage(value) {
          this.showBottomBarHomepage.next(value);
        }
      }, {
        key: "getDesignDetailsRefresh",
        value: function getDesignDetailsRefresh() {
          return this.designDetailsRefresh;
        }
      }, {
        key: "setDesignDetailsRefresh",
        value: function setDesignDetailsRefresh(value) {
          this.designDetailsRefresh.next(value);
        }
      }, {
        key: "getScheduleFormEvent",
        value: function getScheduleFormEvent() {
          return this.saveScheduleForm;
        }
      }, {
        key: "setScheduleFormEvent",
        value: function setScheduleFormEvent(event) {
          this.saveScheduleForm.next(event);
          this.saveScheduleForm.next(_model_constants__WEBPACK_IMPORTED_MODULE_5__["ScheduleFormEvent"].NO_EVENT);
        }
      }, {
        key: "showLoading",
        value: function showLoading(message) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            var finalMessage;
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    finalMessage = '';

                    if (message) {
                      finalMessage = message;
                    } else {
                      finalMessage = 'Please Wait';
                    }

                    _context.next = 4;
                    return this.loadingController.create({
                      message: finalMessage
                    });

                  case 4:
                    this.loading = _context.sent;
                    return _context.abrupt("return", this.loading.present());

                  case 6:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "showLoadingWithPullRefreshSupport",
        value: function showLoadingWithPullRefreshSupport(showPopup, message) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
            var finalMessage;
            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    if (!showPopup) {
                      _context2.next = 9;
                      break;
                    }

                    finalMessage = '';

                    if (message) {
                      finalMessage = message;
                    } else {
                      finalMessage = 'Please Wait';
                    }

                    _context2.next = 5;
                    return this.loadingController.create({
                      message: finalMessage
                    });

                  case 5:
                    this.loading = _context2.sent;
                    return _context2.abrupt("return", this.loading.present());

                  case 9:
                    return _context2.abrupt("return", Promise.resolve());

                  case 10:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2, this);
          }));
        }
      }, {
        key: "setLoadingMessage",
        value: function setLoadingMessage(message) {
          this.loading.message = message;
        }
      }, {
        key: "hideLoading",
        value: function hideLoading() {
          return this.loading.dismiss();
        }
      }, {
        key: "hideLoadingWithPullRefreshSupport",
        value: function hideLoadingWithPullRefreshSupport(showPopup) {
          if (showPopup) {
            return this.loading.dismiss();
          } else {
            return Promise.resolve(true);
          }
        }
      }, {
        key: "showAlert",
        value: function showAlert(message) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
            var alert;
            return regeneratorRuntime.wrap(function _callee3$(_context3) {
              while (1) {
                switch (_context3.prev = _context3.next) {
                  case 0:
                    _context3.next = 2;
                    return this.alertController.create({
                      header: 'Error',
                      message: message,
                      buttons: ['OK']
                    });

                  case 2:
                    alert = _context3.sent;
                    _context3.next = 5;
                    return alert.present();

                  case 5:
                  case "end":
                    return _context3.stop();
                }
              }
            }, _callee3, this);
          }));
        }
      }, {
        key: "showSuccessModal",
        value: function showSuccessModal(successMessage) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
            var modal;
            return regeneratorRuntime.wrap(function _callee4$(_context4) {
              while (1) {
                switch (_context4.prev = _context4.next) {
                  case 0:
                    _context4.next = 2;
                    return this.modalController.create({
                      component: _utilities_success_modal_success_modal_component__WEBPACK_IMPORTED_MODULE_3__["SuccessModalComponent"],
                      componentProps: {
                        message: successMessage
                      }
                    });

                  case 2:
                    modal = _context4.sent;
                    return _context4.abrupt("return", modal);

                  case 4:
                  case "end":
                    return _context4.stop();
                }
              }
            }, _callee4, this);
          }));
        }
      }, {
        key: "capitalizeWord",
        value: function capitalizeWord(word) {
          if (!word) {
            return word;
          }

          return word[0].toUpperCase() + word.substr(1).toLowerCase();
        }
      }, {
        key: "showSnackBar",
        value: function showSnackBar(message) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
            var toast;
            return regeneratorRuntime.wrap(function _callee5$(_context5) {
              while (1) {
                switch (_context5.prev = _context5.next) {
                  case 0:
                    this.hideLoading();
                    _context5.next = 3;
                    return this.toastController.create({
                      message: message,
                      duration: 2000,
                      cssClass: 'my-custom-class'
                    });

                  case 3:
                    toast = _context5.sent;
                    _context5.next = 6;
                    return toast.present();

                  case 6:
                  case "end":
                    return _context5.stop();
                }
              }
            }, _callee5, this);
          }));
        }
      }, {
        key: "errorSnackBar",
        value: function errorSnackBar(message) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee6() {
            var toast;
            return regeneratorRuntime.wrap(function _callee6$(_context6) {
              while (1) {
                switch (_context6.prev = _context6.next) {
                  case 0:
                    this.hideLoading();
                    _context6.next = 3;
                    return this.toastController.create({
                      message: message,
                      duration: 2000,
                      cssClass: 'my-custom-error-class'
                    });

                  case 3:
                    toast = _context6.sent;
                    _context6.next = 6;
                    return toast.present();

                  case 6:
                  case "end":
                    return _context6.stop();
                }
              }
            }, _callee6, this);
          }));
        }
      }, {
        key: "setStaticAddress",
        value: function setStaticAddress(address) {
          this.staticAddress.next(address);
        }
      }, {
        key: "getStaticAddress",
        value: function getStaticAddress() {
          return this.staticAddress;
        }
      }, {
        key: "getBlobFromImageData",
        value: function getBlobFromImageData(dataURI) {
          // convert base64 to raw binary data held in a string
          var byteString = atob(dataURI.split(',')[1]); // separate out the mime component

          var mimeString = dataURI.split(',')[0].split(':')[1].split(';')[0]; // write the bytes of the string to an ArrayBuffer

          var ab = new ArrayBuffer(byteString.length);
          var ia = new Uint8Array(ab);

          for (var i = 0; i < byteString.length; i++) {
            ia[i] = byteString.charCodeAt(i);
          }

          return new Blob([ab], {
            type: mimeString
          });
        }
      }, {
        key: "getJobTypeName",
        value: function getJobTypeName(type) {
          if (type == "pvbattery") {
            return "PV + Battery";
          } else if (type == "battery") {
            return "Battery";
          } else {
            return "PV";
          }
        }
      }, {
        key: "b64toBlob",
        value: function b64toBlob(b64Data) {
          var contentType = b64Data.split(',')[0].split(':')[1].split(';')[0] || '';
          var sliceSize = 256;
          var byteCharacters = atob(b64Data.split(',')[1]);
          var byteArrays = [];

          for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
            var slice = byteCharacters.slice(offset, offset + sliceSize);
            var byteNumbers = new Array(slice.length);

            for (var i = 0; i < slice.length; i++) {
              byteNumbers[i] = slice.charCodeAt(i);
            }

            var byteArray = new Uint8Array(byteNumbers);
            byteArrays.push(byteArray);
          }

          return new Blob(byteArrays, {
            type: contentType
          });
        }
      }, {
        key: "b64tBlob",
        value: function b64tBlob(b64Data) {
          var contentType = 'image/jpg';
          var sliceSize = 512;
          b64Data = b64Data.replace(/data\:image\/(jpeg|jpg|png)\;base64\,/gi, '');
          var byteCharacters = atob(b64Data);
          var byteArrays = [];

          for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
            var slice = byteCharacters.slice(offset, offset + sliceSize);
            var byteNumbers = new Array(slice.length);

            for (var i = 0; i < slice.length; i++) {
              byteNumbers[i] = slice.charCodeAt(i);
            }

            var byteArray = new Uint8Array(byteNumbers);
            byteArrays.push(byteArray);
          }

          return new Blob(byteArrays, {
            type: contentType
          });
        }
      }]);

      return UtilitiesService;
    }();

    UtilitiesService.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]
      }];
    };

    UtilitiesService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]])], UtilitiesService);
    /***/
  },

  /***/
  "./src/app/utilities/auto-complete/auto-complete.component.scss":
  /*!**********************************************************************!*\
    !*** ./src/app/utilities/auto-complete/auto-complete.component.scss ***!
    \**********************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppUtilitiesAutoCompleteAutoCompleteComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".popup-list {\n  height: 150px;\n  position: absolute;\n  z-index: 100;\n  overflow-y: scroll;\n  background: white;\n  border-radius: 4px;\n  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdXRpbGl0aWVzL2F1dG8tY29tcGxldGUvRjpcXG1vYmlsZWFwcC9zcmNcXGFwcFxcdXRpbGl0aWVzXFxhdXRvLWNvbXBsZXRlXFxhdXRvLWNvbXBsZXRlLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC91dGlsaXRpZXMvYXV0by1jb21wbGV0ZS9hdXRvLWNvbXBsZXRlLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsYUFBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLDRFQUFBO0FDQ0YiLCJmaWxlIjoic3JjL2FwcC91dGlsaXRpZXMvYXV0by1jb21wbGV0ZS9hdXRvLWNvbXBsZXRlLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnBvcHVwLWxpc3Qge1xyXG4gIGhlaWdodDogMTUwcHg7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIHotaW5kZXg6IDEwMDtcclxuICBvdmVyZmxvdy15OiBzY3JvbGw7XHJcbiAgYmFja2dyb3VuZDogd2hpdGU7XHJcbiAgYm9yZGVyLXJhZGl1czogNHB4O1xyXG4gIGJveC1zaGFkb3c6IDAgNHB4IDhweCAwIHJnYmEoMCwgMCwgMCwgMC4yKSwgMCA2cHggMjBweCAwIHJnYmEoMCwgMCwgMCwgMC4xOSk7XHJcbn1cclxuIiwiLnBvcHVwLWxpc3Qge1xuICBoZWlnaHQ6IDE1MHB4O1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHotaW5kZXg6IDEwMDtcbiAgb3ZlcmZsb3cteTogc2Nyb2xsO1xuICBiYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgYm9yZGVyLXJhZGl1czogNHB4O1xuICBib3gtc2hhZG93OiAwIDRweCA4cHggMCByZ2JhKDAsIDAsIDAsIDAuMiksIDAgNnB4IDIwcHggMCByZ2JhKDAsIDAsIDAsIDAuMTkpO1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/utilities/auto-complete/auto-complete.component.ts":
  /*!********************************************************************!*\
    !*** ./src/app/utilities/auto-complete/auto-complete.component.ts ***!
    \********************************************************************/

  /*! exports provided: AutoCompleteComponent */

  /***/
  function srcAppUtilitiesAutoCompleteAutoCompleteComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AutoCompleteComponent", function () {
      return AutoCompleteComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var src_app_api_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! src/app/api.service */
    "./src/app/api.service.ts");
    /* harmony import */


    var src_app_utilities_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! src/app/utilities.service */
    "./src/app/utilities.service.ts");

    var AutoCompleteComponent_1;

    var AutoCompleteComponent = AutoCompleteComponent_1 = /*#__PURE__*/function () {
      function AutoCompleteComponent(apiService, utility) {
        _classCallCheck(this, AutoCompleteComponent);

        this.apiService = apiService;
        this.utility = utility;
        this.placeholder = '';
        this.mode = 'id'; //id or object

        this.name = '';
        this.modulename = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.sortedList = [];
        this.selectedDataId = 0;
        this.selectedDataName = '';
        this.manualinput = '';
      }

      _createClass(AutoCompleteComponent, [{
        key: "registerOnChange",
        value: function registerOnChange(fn) {
          this.onChange = fn;
        }
      }, {
        key: "registerOnTouched",
        value: function registerOnTouched(fn) {}
      }, {
        key: "validate",
        value: function validate(control) {
          if (this.selectedDataId !== 0) {
            return null;
          }

          return null; // return {
          //   error: 'No option selected'
          // };
        }
      }, {
        key: "writeValue",
        value: function writeValue(data) {
          if (data !== null && data !== undefined && data !== '') {
            this.selectedDataId = data;
            var selectedData;
            this.dataList.forEach(function (item) {
              if (item.id === data) {
                selectedData = item;
              }
            });

            if (selectedData) {
              this.sortedList = this.dataList.filter(function (item) {
                return item.name.toLowerCase().indexOf(selectedData.name.toLowerCase()) > -1;
              });
            }

            if (this.sortedList.length === 1) {
              if (this.sortedList[0].name.toLowerCase() === selectedData.name.toLowerCase()) {
                this.sortedList = [];
              }
            }

            if (selectedData) {
              this.selectOption(selectedData);
            }
          } else {
            this.selectedDataId = 0;
            this.selectedDataName = '';
            this.dataList = [];
          }
        }
      }, {
        key: "onValueChanged",
        value: function onValueChanged(event) {
          console.log('value changed');
          console.log(this.dataList);
          this.manualinput = event.detail.value;
          this.utility.manualInput.next(this.manualinput); // this.selectedDataName = event.detail.value;

          console.log(this.selectedDataName);
          this.sortedList = this.dataList.filter(function (item) {
            if (item.name !== null) {
              return item.name.toLowerCase().indexOf(event.detail.value.toLowerCase()) > -1;
            }
          });

          if (this.sortedList.length === 1) {
            if (this.sortedList[0].name.toLowerCase() === event.detail.value.toLowerCase()) {
              // this.onChange(event.target.value);
              this.sortedList = [];
            }
          } else {// this.selectedDataName= event.detail.value;
            // event.detail.value = this.selectedDataName;
            // this.onChange(this.selectedDataName);
          }
        }
      }, {
        key: "selectOption",
        value: function selectOption(data) {
          console.log('data changed');
          this.sortedList = [];
          this.selectedOption = data;
          this.selectedDataId = data.id;
          this.selectedDataName = data.name;
          console.log(data, "KK");

          if (this.mode === 'id') {
            this.onChange(data.id);
          } else {
            this.onChange(data);
          }
        }
      }, {
        key: "onFocus",
        value: function onFocus(event) {
          var _this8 = this;

          // this.selectedDataName= event.detail.value;
          console.log("HELLO", event);
          this.sortedList = this.dataList.filter(function (item) {
            // console.log(item);
            if (item.name !== null) {
              return item.name.toLowerCase().indexOf(_this8.selectedDataName) > -1;
            }
          });

          if (this.sortedList.length === 1) {
            this.selectedDataName = this.sortedList[0].name; // if (this.mode === 'id') {
            //   this.onChange(this.sortedList[0].id);
            // } else {
            // }

            if (this.sortedList[0].name.toLowerCase() === this.selectedDataName.toLowerCase()) {
              this.sortedList = [];
            }
          }
        }
      }, {
        key: "onBlur",
        value: function onBlur(event) {
          var _this9 = this;

          setTimeout(function () {
            _this9.sortedList = [];
          }, 100);
        }
      }]);

      return AutoCompleteComponent;
    }();

    AutoCompleteComponent.ctorParameters = function () {
      return [{
        type: src_app_api_service__WEBPACK_IMPORTED_MODULE_3__["ApiService"]
      }, {
        type: src_app_utilities_service__WEBPACK_IMPORTED_MODULE_4__["UtilitiesService"]
      }];
    };

    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Array)], AutoCompleteComponent.prototype, "dataList", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)], AutoCompleteComponent.prototype, "placeholder", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)], AutoCompleteComponent.prototype, "mode", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)], AutoCompleteComponent.prototype, "name", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)], AutoCompleteComponent.prototype, "modulename", void 0);
    AutoCompleteComponent = AutoCompleteComponent_1 = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-auto-complete',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./auto-complete.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/utilities/auto-complete/auto-complete.component.html"))["default"],
      providers: [{
        provide: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["NG_VALUE_ACCESSOR"],
        multi: true,
        useExisting: AutoCompleteComponent_1
      }, {
        provide: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["NG_VALIDATORS"],
        multi: true,
        useExisting: AutoCompleteComponent_1
      }],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./auto-complete.component.scss */
      "./src/app/utilities/auto-complete/auto-complete.component.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_api_service__WEBPACK_IMPORTED_MODULE_3__["ApiService"], src_app_utilities_service__WEBPACK_IMPORTED_MODULE_4__["UtilitiesService"]])], AutoCompleteComponent);
    /***/
  },

  /***/
  "./src/app/utilities/date-time/date-time.component.scss":
  /*!**************************************************************!*\
    !*** ./src/app/utilities/date-time/date-time.component.scss ***!
    \**************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppUtilitiesDateTimeDateTimeComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".main-background {\n  margin-top: 8px;\n  background: #EFEFEF;\n  border-radius: 0.5em;\n  color: #656565;\n}\n\n.date-background {\n  width: 4em;\n  height: 4em;\n  background: #3c78d8;\n  border-radius: 0.5em;\n  color: white;\n}\n\n.month {\n  font-size: 1em;\n}\n\n.day {\n  font-size: 1.5em;\n  font-weight: bold;\n}\n\n.time {\n  font-size: 1.5em;\n  font-weight: bold;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdXRpbGl0aWVzL2RhdGUtdGltZS9GOlxcbW9iaWxlYXBwL3NyY1xcYXBwXFx1dGlsaXRpZXNcXGRhdGUtdGltZVxcZGF0ZS10aW1lLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC91dGlsaXRpZXMvZGF0ZS10aW1lL2RhdGUtdGltZS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGVBQUE7RUFDQSxtQkFBQTtFQUNBLG9CQUFBO0VBQ0EsY0FBQTtBQ0NGOztBREVBO0VBQ0UsVUFBQTtFQUNBLFdBQUE7RUFDQSxtQkFBQTtFQUNBLG9CQUFBO0VBQ0EsWUFBQTtBQ0NGOztBREVBO0VBQ0UsY0FBQTtBQ0NGOztBREVBO0VBQ0UsZ0JBQUE7RUFDQSxpQkFBQTtBQ0NGOztBREVBO0VBQ0UsZ0JBQUE7RUFDQSxpQkFBQTtBQ0NGIiwiZmlsZSI6InNyYy9hcHAvdXRpbGl0aWVzL2RhdGUtdGltZS9kYXRlLXRpbWUuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubWFpbi1iYWNrZ3JvdW5kIHtcclxuICBtYXJnaW4tdG9wOiA4cHg7XHJcbiAgYmFja2dyb3VuZDogI0VGRUZFRjtcclxuICBib3JkZXItcmFkaXVzOiAwLjVlbTtcclxuICBjb2xvcjogIzY1NjU2NTtcclxufVxyXG5cclxuLmRhdGUtYmFja2dyb3VuZCB7XHJcbiAgd2lkdGg6IDRlbTtcclxuICBoZWlnaHQ6IDRlbTtcclxuICBiYWNrZ3JvdW5kOiAjM2M3OGQ4O1xyXG4gIGJvcmRlci1yYWRpdXM6IDAuNWVtO1xyXG4gIGNvbG9yOiB3aGl0ZTtcclxufVxyXG5cclxuLm1vbnRoIHtcclxuICBmb250LXNpemU6IDFlbTtcclxufVxyXG5cclxuLmRheSB7XHJcbiAgZm9udC1zaXplOiAxLjVlbTtcclxuICBmb250LXdlaWdodDogYm9sZDtcclxufVxyXG5cclxuLnRpbWUge1xyXG4gIGZvbnQtc2l6ZTogMS41ZW07XHJcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbn1cclxuXHJcblxyXG4iLCIubWFpbi1iYWNrZ3JvdW5kIHtcbiAgbWFyZ2luLXRvcDogOHB4O1xuICBiYWNrZ3JvdW5kOiAjRUZFRkVGO1xuICBib3JkZXItcmFkaXVzOiAwLjVlbTtcbiAgY29sb3I6ICM2NTY1NjU7XG59XG5cbi5kYXRlLWJhY2tncm91bmQge1xuICB3aWR0aDogNGVtO1xuICBoZWlnaHQ6IDRlbTtcbiAgYmFja2dyb3VuZDogIzNjNzhkODtcbiAgYm9yZGVyLXJhZGl1czogMC41ZW07XG4gIGNvbG9yOiB3aGl0ZTtcbn1cblxuLm1vbnRoIHtcbiAgZm9udC1zaXplOiAxZW07XG59XG5cbi5kYXkge1xuICBmb250LXNpemU6IDEuNWVtO1xuICBmb250LXdlaWdodDogYm9sZDtcbn1cblxuLnRpbWUge1xuICBmb250LXNpemU6IDEuNWVtO1xuICBmb250LXdlaWdodDogYm9sZDtcbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/utilities/date-time/date-time.component.ts":
  /*!************************************************************!*\
    !*** ./src/app/utilities/date-time/date-time.component.ts ***!
    \************************************************************/

  /*! exports provided: DateTimeComponent */

  /***/
  function srcAppUtilitiesDateTimeDateTimeComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DateTimeComponent", function () {
      return DateTimeComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_native_date_picker_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic-native/date-picker/ngx */
    "./node_modules/@ionic-native/date-picker/ngx/index.js");

    var DateTimeComponent_1;

    var DateTimeComponent = DateTimeComponent_1 = /*#__PURE__*/function () {
      function DateTimeComponent(datePicker) {
        _classCallCheck(this, DateTimeComponent);

        this.datePicker = datePicker;
        this.placeholder = '';
      }

      _createClass(DateTimeComponent, [{
        key: "registerOnChange",
        value: function registerOnChange(fn) {
          this.onChange = fn;
        }
      }, {
        key: "registerOnTouched",
        value: function registerOnTouched(fn) {}
      }, {
        key: "writeValue",
        value: function writeValue(date) {
          this.date = date;
        }
      }, {
        key: "validate",
        value: function validate(control) {
          if (this.date !== null && this.date !== undefined && this.date !== 0 && this.date > new Date().getTime()) {
            return null;
          }

          if (this.date > 0 && this.date < new Date().getTime()) {
            return null; // return {
            //   error: 'Date must be a future date'
            // };
          }

          return {
            error: 'Please choose a date'
          };
        }
      }, {
        key: "changeDate",
        value: function changeDate() {
          var _this10 = this;

          var currentDate = new Date(this.date);
          console.log(currentDate);
          this.datePicker.show({
            date: new Date(this.date),
            minDate: new Date(),
            mode: 'date',
            androidTheme: this.datePicker.ANDROID_THEMES.THEME_DEVICE_DEFAULT_LIGHT
          }).then(function (date) {
            _this10.date = date.getTime();

            _this10.onChange(date);
          }, function (err) {
            return console.log('Error occurred while getting date: ', err);
          });
        }
      }, {
        key: "changeTime",
        value: function changeTime() {
          var _this11 = this;

          var currentDate = new Date(this.date);
          console.log(currentDate);
          this.datePicker.show({
            date: new Date(this.date),
            minDate: new Date(),
            mode: 'time',
            androidTheme: this.datePicker.ANDROID_THEMES.THEME_DEVICE_DEFAULT_LIGHT
          }).then(function (date) {
            var oldDate = new Date(_this11.date);
            oldDate.setHours(date.getHours(), date.getMinutes(), date.getSeconds(), date.getMilliseconds());
            _this11.date = oldDate.getTime();

            _this11.onChange(oldDate);
          }, function (err) {
            return console.log('Error occurred while getting date: ', err);
          });
        }
      }]);

      return DateTimeComponent;
    }();

    DateTimeComponent.ctorParameters = function () {
      return [{
        type: _ionic_native_date_picker_ngx__WEBPACK_IMPORTED_MODULE_3__["DatePicker"]
      }];
    };

    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Number)], DateTimeComponent.prototype, "date", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)], DateTimeComponent.prototype, "placeholder", void 0);
    DateTimeComponent = DateTimeComponent_1 = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-date-time',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./date-time.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/utilities/date-time/date-time.component.html"))["default"],
      providers: [{
        provide: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["NG_VALUE_ACCESSOR"],
        multi: true,
        useExisting: DateTimeComponent_1
      }, {
        provide: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["NG_VALIDATORS"],
        multi: true,
        useExisting: DateTimeComponent_1
      }],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./date-time.component.scss */
      "./src/app/utilities/date-time/date-time.component.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_native_date_picker_ngx__WEBPACK_IMPORTED_MODULE_3__["DatePicker"]])], DateTimeComponent);
    /***/
  },

  /***/
  "./src/app/utilities/email-selector/email-selector.component.scss":
  /*!************************************************************************!*\
    !*** ./src/app/utilities/email-selector/email-selector.component.scss ***!
    \************************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppUtilitiesEmailSelectorEmailSelectorComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".even {\n  background-color: #ecf0f9ab;\n}\n\n.odd {\n  background-color: #ffffff;\n}\n\n.listitem {\n  display: flex;\n  font-size: 0.7em;\n  font-weight: 600;\n  margin: 0 10px;\n  color: black;\n}\n\n.selectall {\n  font-size: 0.9em;\n  font-weight: 700;\n  margin: 16px;\n}\n\n.matlist {\n  padding-top: 16px;\n  padding-left: 16px;\n}\n\n.sendButton {\n  margin-top: 16px;\n  text-align: center;\n  margin-left: 480px;\n}\n\n.item {\n  padding-bottom: 16px;\n}\n\n.close {\n  margin-left: 500px;\n}\n\n.listitem1 {\n  display: flex;\n  font-size: 0.7em;\n  font-weight: 600;\n  margin: 0 2px;\n  color: black;\n}\n\n.listitem2 {\n  display: flex;\n  font-size: 0.7em;\n  font-weight: 600;\n  margin: 0 2px;\n  color: black;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdXRpbGl0aWVzL2VtYWlsLXNlbGVjdG9yL0Y6XFxtb2JpbGVhcHAvc3JjXFxhcHBcXHV0aWxpdGllc1xcZW1haWwtc2VsZWN0b3JcXGVtYWlsLXNlbGVjdG9yLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC91dGlsaXRpZXMvZW1haWwtc2VsZWN0b3IvZW1haWwtc2VsZWN0b3IuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBR0U7RUFDRSwyQkFBQTtBQ0ZKOztBRElBO0VBQ0kseUJBQUE7QUNESjs7QURLQTtFQUNFLGFBQUE7RUFDQSxnQkFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtFQUNBLFlBQUE7QUNGRjs7QURLQTtFQUNFLGdCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxZQUFBO0FDRkY7O0FESUE7RUFDRSxpQkFBQTtFQUNBLGtCQUFBO0FDREY7O0FESUE7RUFDRSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7QUNERjs7QURHQTtFQUNFLG9CQUFBO0FDQUY7O0FERUE7RUFDRSxrQkFBQTtBQ0NGOztBRENBO0VBQ0UsYUFBQTtFQUNBLGdCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxhQUFBO0VBQ0EsWUFBQTtBQ0VGOztBREFBO0VBQ0UsYUFBQTtFQUNBLGdCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxhQUFBO0VBQ0EsWUFBQTtBQ0dGIiwiZmlsZSI6InNyYy9hcHAvdXRpbGl0aWVzL2VtYWlsLXNlbGVjdG9yL2VtYWlsLXNlbGVjdG9yLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcblxyXG5cclxuICAuZXZlbiB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZWNmMGY5YWI7XHJcbn1cclxuLm9kZCB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmZmZmO1xyXG59XHJcblxyXG5cclxuLmxpc3RpdGVte1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZm9udC1zaXplOiAwLjdlbTtcclxuICBmb250LXdlaWdodDogNjAwO1xyXG4gIG1hcmdpbjogMCAxMHB4O1xyXG4gIGNvbG9yOiBibGFjaztcclxufVxyXG5cclxuLnNlbGVjdGFsbHtcclxuICBmb250LXNpemU6IDAuOWVtO1xyXG4gIGZvbnQtd2VpZ2h0OiA3MDA7XHJcbiAgbWFyZ2luOjE2cHg7XHJcbn1cclxuLm1hdGxpc3R7XHJcbiAgcGFkZGluZy10b3A6IDE2cHg7XHJcbiAgcGFkZGluZy1sZWZ0OiAxNnB4O1xyXG59XHJcblxyXG4uc2VuZEJ1dHRvbntcclxuICBtYXJnaW4tdG9wOiAxNnB4O1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBtYXJnaW4tbGVmdDogNDgwcHg7XHJcbn1cclxuLml0ZW17XHJcbiAgcGFkZGluZy1ib3R0b206IDE2cHg7XHJcbn1cclxuLmNsb3Nle1xyXG4gIG1hcmdpbi1sZWZ0OiA1MDBweDtcclxufVxyXG4ubGlzdGl0ZW0xe1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZm9udC1zaXplOiAwLjdlbTtcclxuICBmb250LXdlaWdodDogNjAwO1xyXG4gIG1hcmdpbjogMCAycHg7XHJcbiAgY29sb3I6IGJsYWNrO1xyXG59XHJcbi5saXN0aXRlbTJ7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBmb250LXNpemU6IDAuN2VtO1xyXG4gIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgbWFyZ2luOiAwIDJweDtcclxuICBjb2xvcjogYmxhY2s7XHJcbn1cclxuXHJcblxyXG5cclxuXHJcbiIsIi5ldmVuIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2VjZjBmOWFiO1xufVxuXG4ub2RkIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZmZmZjtcbn1cblxuLmxpc3RpdGVtIHtcbiAgZGlzcGxheTogZmxleDtcbiAgZm9udC1zaXplOiAwLjdlbTtcbiAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgbWFyZ2luOiAwIDEwcHg7XG4gIGNvbG9yOiBibGFjaztcbn1cblxuLnNlbGVjdGFsbCB7XG4gIGZvbnQtc2l6ZTogMC45ZW07XG4gIGZvbnQtd2VpZ2h0OiA3MDA7XG4gIG1hcmdpbjogMTZweDtcbn1cblxuLm1hdGxpc3Qge1xuICBwYWRkaW5nLXRvcDogMTZweDtcbiAgcGFkZGluZy1sZWZ0OiAxNnB4O1xufVxuXG4uc2VuZEJ1dHRvbiB7XG4gIG1hcmdpbi10b3A6IDE2cHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgbWFyZ2luLWxlZnQ6IDQ4MHB4O1xufVxuXG4uaXRlbSB7XG4gIHBhZGRpbmctYm90dG9tOiAxNnB4O1xufVxuXG4uY2xvc2Uge1xuICBtYXJnaW4tbGVmdDogNTAwcHg7XG59XG5cbi5saXN0aXRlbTEge1xuICBkaXNwbGF5OiBmbGV4O1xuICBmb250LXNpemU6IDAuN2VtO1xuICBmb250LXdlaWdodDogNjAwO1xuICBtYXJnaW46IDAgMnB4O1xuICBjb2xvcjogYmxhY2s7XG59XG5cbi5saXN0aXRlbTIge1xuICBkaXNwbGF5OiBmbGV4O1xuICBmb250LXNpemU6IDAuN2VtO1xuICBmb250LXdlaWdodDogNjAwO1xuICBtYXJnaW46IDAgMnB4O1xuICBjb2xvcjogYmxhY2s7XG59Il19 */";
    /***/
  },

  /***/
  "./src/app/utilities/email-selector/email-selector.component.ts":
  /*!**********************************************************************!*\
    !*** ./src/app/utilities/email-selector/email-selector.component.ts ***!
    \**********************************************************************/

  /*! exports provided: EmailSelectorComponent */

  /***/
  function srcAppUtilitiesEmailSelectorEmailSelectorComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "EmailSelectorComponent", function () {
      return EmailSelectorComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var src_app_contants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! src/app/contants */
    "./src/app/contants.ts");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var src_app_utilities_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! src/app/utilities.service */
    "./src/app/utilities.service.ts");
    /* harmony import */


    var src_app_storage_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! src/app/storage.service */
    "./src/app/storage.service.ts");
    /* harmony import */


    var src_app_api_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! src/app/api.service */
    "./src/app/api.service.ts");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _user_selector_user_selector_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! ../user-selector/user-selector.component */
    "./src/app/utilities/user-selector/user-selector.component.ts");

    var EmailSelectorComponent = /*#__PURE__*/function () {
      function EmailSelectorComponent(util, cdr, http, storage, api) {
        _classCallCheck(this, EmailSelectorComponent);

        this.util = util;
        this.cdr = cdr;
        this.http = http;
        this.storage = storage;
        this.api = api;
        this.example = [];
        this.teamMember = [];
        this.TeamData = [];
        this.bodyData = [];
        this.selectedEmails = [];
        this.resp = [];
      }

      _createClass(EmailSelectorComponent, [{
        key: "validate",
        value: function validate(control) {
          throw new Error("Method not implemented.");
        }
      }, {
        key: "registerOnValidatorChange",
        value: function registerOnValidatorChange(fn) {
          throw new Error("Method not implemented.");
        }
      }, {
        key: "writeValue",
        value: function writeValue(obj) {
          throw new Error("Method not implemented.");
        }
      }, {
        key: "registerOnChange",
        value: function registerOnChange(fn) {
          throw new Error("Method not implemented.");
        }
      }, {
        key: "registerOnTouched",
        value: function registerOnTouched(fn) {
          throw new Error("Method not implemented.");
        }
      }, {
        key: "setDisabledState",
        value: function setDisabledState(isDisabled) {
          throw new Error("Method not implemented.");
        }
      }, {
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this12 = this;

          this.api.getTeamData().subscribe(function (response) {
            _this12.teamMember = response;
            _this12.example = response;

            _this12.example.push(_this12.design);

            _this12.TeamData = _this12.example;
          });
        } //onCloseClick(){
        // this.dialogRef.close(this.data);
        // }

      }, {
        key: "selectAll",
        value: function selectAll(event) {
          var checked = event.target.checked;
          this.TeamData.forEach(function (item) {
            return item.checked = checked;
          });
        }
      }, {
        key: "SendMail",
        value: function SendMail() {
          var _this13 = this;

          var emails = document.getElementById("inputemails").value;
          this.emailArray = emails.split(',');
          this.emailArray.forEach(function (element) {
            _this13.selectedEmails.push(element);
          });
          this.bodyData = this.TeamData.filter(function (item) {
            return item.checked;
          });
          this.bodyData.forEach(function (element) {
            _this13.selectedEmails.push(element.email);
          });
          this.selectedEmails.push();
          console.log(this.selectedEmails);
          var body = {
            emails: this.selectedEmails,
            id: this.design
          };
          return this.http.post(src_app_contants__WEBPACK_IMPORTED_MODULE_2__["BaseUrl"] + "designs/send-prelim-design", body, {
            headers: this.headers
          }).subscribe(function (response) {
            _this13.resp = response;

            if (_this13.resp.status == 'success') {
              _this13.util.showSnackBar("Email Sent  Successfully"); // this.dialogRef.close( );

            }
          }, function (error) {
            _this13.util.errorSnackBar("Something went wrong. Please try again.");
          });
        }
      }]);

      return EmailSelectorComponent;
    }();

    EmailSelectorComponent.ctorParameters = function () {
      return [{
        type: src_app_utilities_service__WEBPACK_IMPORTED_MODULE_4__["UtilitiesService"]
      }, {
        type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"]
      }, {
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"]
      }, {
        type: src_app_storage_service__WEBPACK_IMPORTED_MODULE_5__["StorageService"]
      }, {
        type: src_app_api_service__WEBPACK_IMPORTED_MODULE_6__["ApiService"]
      }];
    };

    EmailSelectorComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-email-selector',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./email-selector.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/utilities/email-selector/email-selector.component.html"))["default"],
      providers: [{
        provide: _angular_forms__WEBPACK_IMPORTED_MODULE_7__["NG_VALUE_ACCESSOR"],
        multi: true,
        useExisting: _user_selector_user_selector_component__WEBPACK_IMPORTED_MODULE_8__["UserSelectorComponent"]
      }, {
        provide: _angular_forms__WEBPACK_IMPORTED_MODULE_7__["NG_VALIDATORS"],
        multi: true,
        useExisting: _user_selector_user_selector_component__WEBPACK_IMPORTED_MODULE_8__["UserSelectorComponent"]
      }],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./email-selector.component.scss */
      "./src/app/utilities/email-selector/email-selector.component.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_utilities_service__WEBPACK_IMPORTED_MODULE_4__["UtilitiesService"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"], _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"], src_app_storage_service__WEBPACK_IMPORTED_MODULE_5__["StorageService"], src_app_api_service__WEBPACK_IMPORTED_MODULE_6__["ApiService"]])], EmailSelectorComponent);
    /***/
  },

  /***/
  "./src/app/utilities/success-modal/success-modal.component.scss":
  /*!**********************************************************************!*\
    !*** ./src/app/utilities/success-modal/success-modal.component.scss ***!
    \**********************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppUtilitiesSuccessModalSuccessModalComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".success-image {\n  width: 8em;\n  height: 8em;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdXRpbGl0aWVzL3N1Y2Nlc3MtbW9kYWwvRjpcXG1vYmlsZWFwcC9zcmNcXGFwcFxcdXRpbGl0aWVzXFxzdWNjZXNzLW1vZGFsXFxzdWNjZXNzLW1vZGFsLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC91dGlsaXRpZXMvc3VjY2Vzcy1tb2RhbC9zdWNjZXNzLW1vZGFsLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsVUFBQTtFQUNBLFdBQUE7QUNDRiIsImZpbGUiOiJzcmMvYXBwL3V0aWxpdGllcy9zdWNjZXNzLW1vZGFsL3N1Y2Nlc3MtbW9kYWwuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuc3VjY2Vzcy1pbWFnZSB7XHJcbiAgd2lkdGg6IDhlbTtcclxuICBoZWlnaHQ6IDhlbTtcclxufVxyXG4iLCIuc3VjY2Vzcy1pbWFnZSB7XG4gIHdpZHRoOiA4ZW07XG4gIGhlaWdodDogOGVtO1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/utilities/success-modal/success-modal.component.ts":
  /*!********************************************************************!*\
    !*** ./src/app/utilities/success-modal/success-modal.component.ts ***!
    \********************************************************************/

  /*! exports provided: SuccessModalComponent */

  /***/
  function srcAppUtilitiesSuccessModalSuccessModalComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SuccessModalComponent", function () {
      return SuccessModalComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");

    var SuccessModalComponent = /*#__PURE__*/function () {
      function SuccessModalComponent(modalController) {
        _classCallCheck(this, SuccessModalComponent);

        this.modalController = modalController;
        this.message = '';
      }

      _createClass(SuccessModalComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "closeModal",
        value: function closeModal() {
          this.modalController.dismiss();
        }
      }]);

      return SuccessModalComponent;
    }();

    SuccessModalComponent.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]
      }];
    };

    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])('message'), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)], SuccessModalComponent.prototype, "message", void 0);
    SuccessModalComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-success-modal',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./success-modal.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/utilities/success-modal/success-modal.component.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./success-modal.component.scss */
      "./src/app/utilities/success-modal/success-modal.component.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]])], SuccessModalComponent);
    /***/
  },

  /***/
  "./src/app/utilities/user-selector/user-selector.component.scss":
  /*!**********************************************************************!*\
    !*** ./src/app/utilities/user-selector/user-selector.component.scss ***!
    \**********************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppUtilitiesUserSelectorUserSelectorComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".transparent-background {\n  --background: transparent !important;\n  background: transparent !important;\n}\n\n.assignee-image {\n  width: 3.5em;\n  height: 3.5em;\n  border-radius: 50%;\n  -o-object-fit: fill;\n     object-fit: fill;\n  border: 2px solid white;\n  padding: 8px;\n  text-align: center;\n  background: #FFF1CF;\n}\n\n.assignee-margin {\n  margin: 4px;\n  text-align: center;\n}\n\n.selected {\n  border: 3px solid #3c78d8;\n  border-radius: 50%;\n}\n\n.normal {\n  border: 3px solid transparent;\n  border-radius: 50%;\n}\n\ndiv[scrollx=true], div[scrolly=true] {\n  position: relative;\n  overflow: hidden;\n}\n\ndiv[scrollx=true] ::-webkit-scrollbar, div[scrolly=true] ::-webkit-scrollbar {\n  display: none;\n}\n\ndiv[scrollx=true] {\n  overflow-x: auto;\n}\n\ndiv[scrolly=true] {\n  overflow-y: auto;\n}\n\n.name_div {\n  font-size: 20px;\n}\n\n.badge {\n  position: absolute;\n  margin-left: 34px;\n  /* border-radius: 50%; */\n  padding-bottom: 1px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdXRpbGl0aWVzL3VzZXItc2VsZWN0b3IvRjpcXG1vYmlsZWFwcC9zcmNcXGFwcFxcdXRpbGl0aWVzXFx1c2VyLXNlbGVjdG9yXFx1c2VyLXNlbGVjdG9yLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC91dGlsaXRpZXMvdXNlci1zZWxlY3Rvci91c2VyLXNlbGVjdG9yLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Usb0NBQUE7RUFDQSxrQ0FBQTtBQ0NGOztBREVBO0VBQ0UsWUFBQTtFQUNBLGFBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0tBQUEsZ0JBQUE7RUFDQSx1QkFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0FDQ0Y7O0FERUE7RUFDRSxXQUFBO0VBQ0Esa0JBQUE7QUNDRjs7QURFQTtFQUNFLHlCQUFBO0VBQ0Esa0JBQUE7QUNDRjs7QURFQTtFQUNFLDZCQUFBO0VBQ0Esa0JBQUE7QUNDRjs7QURFQTtFQUNFLGtCQUFBO0VBQ0EsZ0JBQUE7QUNDRjs7QURDRTtFQUNFLGFBQUE7QUNDSjs7QURHQTtFQUNFLGdCQUFBO0FDQUY7O0FER0E7RUFDRSxnQkFBQTtBQ0FGOztBREdBO0VBQ0UsZUFBQTtBQ0FGOztBREVBO0VBQ0Usa0JBQUE7RUFDQSxpQkFBQTtFQUNBLHdCQUFBO0VBQ0EsbUJBQUE7QUNDRiIsImZpbGUiOiJzcmMvYXBwL3V0aWxpdGllcy91c2VyLXNlbGVjdG9yL3VzZXItc2VsZWN0b3IuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIudHJhbnNwYXJlbnQtYmFja2dyb3VuZCB7XHJcbiAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xyXG4gIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50ICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5hc3NpZ25lZS1pbWFnZSB7XHJcbiAgd2lkdGg6IDMuNWVtO1xyXG4gIGhlaWdodDogMy41ZW07XHJcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gIG9iamVjdC1maXQ6IGZpbGw7XHJcbiAgYm9yZGVyOiAycHggc29saWQgd2hpdGU7XHJcbiAgcGFkZGluZzogOHB4O1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBiYWNrZ3JvdW5kOiAjRkZGMUNGO1xyXG59XHJcblxyXG4uYXNzaWduZWUtbWFyZ2luIHtcclxuICBtYXJnaW46IDRweDtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbn1cclxuXHJcbi5zZWxlY3RlZCB7XHJcbiAgYm9yZGVyOiAzcHggc29saWQgIzNjNzhkODtcclxuICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbn1cclxuXHJcbi5ub3JtYWwge1xyXG4gIGJvcmRlcjogM3B4IHNvbGlkIHRyYW5zcGFyZW50O1xyXG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcclxufVxyXG5cclxuZGl2W3Njcm9sbHg9dHJ1ZV0sIGRpdltzY3JvbGx5PXRydWVdIHtcclxuICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcclxuXHJcbiAgOjotd2Via2l0LXNjcm9sbGJhciB7XHJcbiAgICBkaXNwbGF5OiBub25lO1xyXG4gIH1cclxufVxyXG5cclxuZGl2W3Njcm9sbHg9dHJ1ZV0ge1xyXG4gIG92ZXJmbG93LXg6IGF1dG87XHJcbn1cclxuXHJcbmRpdltzY3JvbGx5PXRydWVdIHtcclxuICBvdmVyZmxvdy15OiBhdXRvO1xyXG59XHJcblxyXG4ubmFtZV9kaXYge1xyXG4gIGZvbnQtc2l6ZTogMjBweDtcclxufVxyXG4uYmFkZ2V7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIG1hcmdpbi1sZWZ0OiAzNHB4O1xyXG4gIC8qIGJvcmRlci1yYWRpdXM6IDUwJTsgKi9cclxuICBwYWRkaW5nLWJvdHRvbTogMXB4O1xyXG5cclxufVxyXG5cclxuLy8gLm1hcmdpbntcclxuLy8gICBtYXJnaW4tYm90dG9tOiA4MHB4OztcclxuLy8gfVxyXG5cclxuXHJcbiIsIi50cmFuc3BhcmVudC1iYWNrZ3JvdW5kIHtcbiAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xuICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xufVxuXG4uYXNzaWduZWUtaW1hZ2Uge1xuICB3aWR0aDogMy41ZW07XG4gIGhlaWdodDogMy41ZW07XG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgb2JqZWN0LWZpdDogZmlsbDtcbiAgYm9yZGVyOiAycHggc29saWQgd2hpdGU7XG4gIHBhZGRpbmc6IDhweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBiYWNrZ3JvdW5kOiAjRkZGMUNGO1xufVxuXG4uYXNzaWduZWUtbWFyZ2luIHtcbiAgbWFyZ2luOiA0cHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxuLnNlbGVjdGVkIHtcbiAgYm9yZGVyOiAzcHggc29saWQgIzNjNzhkODtcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xufVxuXG4ubm9ybWFsIHtcbiAgYm9yZGVyOiAzcHggc29saWQgdHJhbnNwYXJlbnQ7XG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcbn1cblxuZGl2W3Njcm9sbHg9dHJ1ZV0sIGRpdltzY3JvbGx5PXRydWVdIHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICBvdmVyZmxvdzogaGlkZGVuO1xufVxuZGl2W3Njcm9sbHg9dHJ1ZV0gOjotd2Via2l0LXNjcm9sbGJhciwgZGl2W3Njcm9sbHk9dHJ1ZV0gOjotd2Via2l0LXNjcm9sbGJhciB7XG4gIGRpc3BsYXk6IG5vbmU7XG59XG5cbmRpdltzY3JvbGx4PXRydWVdIHtcbiAgb3ZlcmZsb3cteDogYXV0bztcbn1cblxuZGl2W3Njcm9sbHk9dHJ1ZV0ge1xuICBvdmVyZmxvdy15OiBhdXRvO1xufVxuXG4ubmFtZV9kaXYge1xuICBmb250LXNpemU6IDIwcHg7XG59XG5cbi5iYWRnZSB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgbWFyZ2luLWxlZnQ6IDM0cHg7XG4gIC8qIGJvcmRlci1yYWRpdXM6IDUwJTsgKi9cbiAgcGFkZGluZy1ib3R0b206IDFweDtcbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/utilities/user-selector/user-selector.component.ts":
  /*!********************************************************************!*\
    !*** ./src/app/utilities/user-selector/user-selector.component.ts ***!
    \********************************************************************/

  /*! exports provided: UserSelectorComponent */

  /***/
  function srcAppUtilitiesUserSelectorUserSelectorComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "UserSelectorComponent", function () {
      return UserSelectorComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");

    var UserSelectorComponent_1;

    var UserSelectorComponent = UserSelectorComponent_1 = /*#__PURE__*/function () {
      // assignee: AssigneeModel;
      function UserSelectorComponent() {
        _classCallCheck(this, UserSelectorComponent);

        this.assignees = [];
        this.placeholder = 'assign to';
        this.required = false;
        this.assigneeData = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.selectedUserId = null;
      }

      _createClass(UserSelectorComponent, [{
        key: "registerOnChange",
        value: function registerOnChange(fn) {
          this.onChange = fn;
        }
      }, {
        key: "registerOnTouched",
        value: function registerOnTouched(fn) {}
      }, {
        key: "writeValue",
        value: function writeValue(assignee) {
          var _this14 = this;

          this.selectedUserId = assignee;
          this.assignees.forEach(function (item) {
            item.selected = item.id === _this14.selectedUserId;
          });
        }
      }, {
        key: "validate",
        value: function validate(control) {
          if (this.required) {
            console.log(this.selectedUserId);

            if (this.selectedUserId !== null) {
              return null;
            }

            return {
              error: 'Assignee is required'
            };
          }

          return null;
        }
      }, {
        key: "selectAssignee",
        value: function selectAssignee(assignee) {
          this.assigneeData.emit(assignee);
          this.assignees.forEach(function (item) {
            item.selected = false;
          });

          if (assignee.id === this.selectedUserId) {
            this.selectedUserId = null;
            this.onChange(null);
          } else {
            assignee.selected = true;
            console.log(assignee);
            this.selectedUserId = assignee.id;
            this.onChange(assignee.id);
          }
        }
      }, {
        key: "selectSelf",
        value: function selectSelf() {}
      }]);

      return UserSelectorComponent;
    }();

    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Array)], UserSelectorComponent.prototype, "assignees", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)], UserSelectorComponent.prototype, "placeholder", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)], UserSelectorComponent.prototype, "required", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)], UserSelectorComponent.prototype, "assigneeData", void 0);
    UserSelectorComponent = UserSelectorComponent_1 = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-user-selector',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./user-selector.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/utilities/user-selector/user-selector.component.html"))["default"],
      providers: [{
        provide: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["NG_VALUE_ACCESSOR"],
        multi: true,
        useExisting: UserSelectorComponent_1
      }, {
        provide: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["NG_VALIDATORS"],
        multi: true,
        useExisting: UserSelectorComponent_1
      }],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./user-selector.component.scss */
      "./src/app/utilities/user-selector/user-selector.component.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])], UserSelectorComponent);
    /***/
  },

  /***/
  "./src/app/utilities/utilities.module.ts":
  /*!***********************************************!*\
    !*** ./src/app/utilities/utilities.module.ts ***!
    \***********************************************/

  /*! exports provided: UtilitiesModule */

  /***/
  function srcAppUtilitiesUtilitiesModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "UtilitiesModule", function () {
      return UtilitiesModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _date_time_date_time_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./date-time/date-time.component */
    "./src/app/utilities/date-time/date-time.component.ts");
    /* harmony import */


    var _user_selector_user_selector_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ./user-selector/user-selector.component */
    "./src/app/utilities/user-selector/user-selector.component.ts");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _ionic_native_date_picker_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @ionic-native/date-picker/ngx */
    "./node_modules/@ionic-native/date-picker/ngx/index.js");
    /* harmony import */


    var _auto_complete_auto_complete_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ./auto-complete/auto-complete.component */
    "./src/app/utilities/auto-complete/auto-complete.component.ts");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _email_selector_email_selector_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! ./email-selector/email-selector.component */
    "./src/app/utilities/email-selector/email-selector.component.ts");

    var UtilitiesModule = function UtilitiesModule() {
      _classCallCheck(this, UtilitiesModule);
    };

    UtilitiesModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      declarations: [_date_time_date_time_component__WEBPACK_IMPORTED_MODULE_3__["DateTimeComponent"], _user_selector_user_selector_component__WEBPACK_IMPORTED_MODULE_4__["UserSelectorComponent"], _auto_complete_auto_complete_component__WEBPACK_IMPORTED_MODULE_7__["AutoCompleteComponent"], _email_selector_email_selector_component__WEBPACK_IMPORTED_MODULE_9__["EmailSelectorComponent"]],
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_8__["FormsModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_8__["ReactiveFormsModule"]],
      exports: [_date_time_date_time_component__WEBPACK_IMPORTED_MODULE_3__["DateTimeComponent"], _user_selector_user_selector_component__WEBPACK_IMPORTED_MODULE_4__["UserSelectorComponent"], _auto_complete_auto_complete_component__WEBPACK_IMPORTED_MODULE_7__["AutoCompleteComponent"], _email_selector_email_selector_component__WEBPACK_IMPORTED_MODULE_9__["EmailSelectorComponent"]],
      providers: [_ionic_native_date_picker_ngx__WEBPACK_IMPORTED_MODULE_6__["DatePicker"]]
    })], UtilitiesModule);
    /***/
  },

  /***/
  "./src/environments/environment.ts":
  /*!*****************************************!*\
    !*** ./src/environments/environment.ts ***!
    \*****************************************/

  /*! exports provided: environment */

  /***/
  function srcEnvironmentsEnvironmentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "environment", function () {
      return environment;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js"); // This file can be replaced during build by using the `fileReplacements` array.
    // `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
    // The list of file replacements can be found in `angular.json`.


    var environment = {
      production: false
    };
    /*
     * For easier debugging in development mode, you can import the following file
     * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
     *
     * This import should be commented out in production mode because it will have a negative impact
     * on performance if an error is thrown.
     */
    // import 'zone.js/dist/zone-error';  // Included with Angular CLI.

    /***/
  },

  /***/
  "./src/main.ts":
  /*!*********************!*\
    !*** ./src/main.ts ***!
    \*********************/

  /*! no exports provided */

  /***/
  function srcMainTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/platform-browser-dynamic */
    "./node_modules/@angular/platform-browser-dynamic/fesm2015/platform-browser-dynamic.js");
    /* harmony import */


    var _app_app_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./app/app.module */
    "./src/app/app.module.ts");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ./environments/environment */
    "./src/environments/environment.ts");

    if (_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].production) {
      Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["enableProdMode"])();
    }

    Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_2__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_3__["AppModule"])["catch"](function (err) {
      return console.log(err);
    });
    /***/
  },

  /***/
  0:
  /*!***************************!*\
    !*** multi ./src/main.ts ***!
    \***************************/

  /*! no static exports found */

  /***/
  function _(module, exports, __webpack_require__) {
    module.exports = __webpack_require__(
    /*! F:\mobileapp\src\main.ts */
    "./src/main.ts");
    /***/
  }
}, [[0, "runtime", "vendor"]]]);
//# sourceMappingURL=main-es5.js.map