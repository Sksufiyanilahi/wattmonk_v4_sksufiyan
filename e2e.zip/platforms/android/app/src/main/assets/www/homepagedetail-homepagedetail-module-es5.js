function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["homepagedetail-homepagedetail-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/homepagedetail/homepagedetail.page.html":
  /*!***********************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/homepagedetail/homepagedetail.page.html ***!
    \***********************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppHomepagedetailHomepagedetailPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-content>\r\n  <ion-grid class=\"detail_box\">\r\n    <ion-row class=\"ion-align-items-center ion-padding-start\">\r\n      <ion-col>\r\n        <ion-button fill=\"clear\" size=\"small\" class=\"ion-no-padding\" (click)=\"goBack()\">\r\n          <ion-icon name=\"arrow-back-outline\" color=\"dark\" size=\"large\"></ion-icon>\r\n      </ion-button>     \r\n      </ion-col>\r\n      <ion-col size=\"5\">\r\n        <h1 class=\"title\">{{desginData.name}}</h1>\r\n    </ion-col>\r\n      <ion-col size=\"auto\">\r\n        <ion-button fill=\"clear\" size=\"small\" class=\"ion-no-padding\">\r\n          <img class=\"edit-icon\"  src=\"assets/images/edit.svg\">\r\n        </ion-button>\r\n    </ion-col>\r\n      <ion-col size=\"auto\">\r\n          <ion-button fill=\"clear\" size=\"small\" class=\"ion-no-padding\">\r\n            <img class=\"delete-icon\"  src=\"assets/images/trash.svg\">\r\n          </ion-button>\r\n      </ion-col>\r\n  </ion-row>\r\n  <ion-row>\r\n    <ion-col size=\"12\" class=\"ion-no-padding\">\r\n      <div style=\"text-align: center\">\r\n        <span class=\"customer-email\">{{desginData.email}}</span>\r\n      </div>\r\n    </ion-col>\r\n\r\n    <ion-col size=\"12\" class=\"ion-no-padding\">\r\n      <div style=\"text-align: center\">\r\n        <span class=\"customer-phone\" *ngIf=\"desginData.phonenumber === undefined\">+91-6272567676</span>\r\n        <span class=\"customer-phone\" *ngIf=\"desginData.phonenumber !== undefined\">{{desginData.phonenumber}}</span>     \r\n      </div>\r\n    </ion-col>\r\n    </ion-row>\r\n  <ion-row class=\"ion-justify-content-center\">\r\n    <ion-col size=\"auto\">\r\n        <div class=\"image-area small-padding\">\r\n            <img  src=\"assets/images/blueprint.svg\">\r\n        </div>\r\n    </ion-col>\r\n</ion-row>\r\n  </ion-grid>\r\n\r\n \r\n  \r\n</ion-content>\r\n";
    /***/
  },

  /***/
  "./src/app/homepagedetail/homepagedetail-routing.module.ts":
  /*!*****************************************************************!*\
    !*** ./src/app/homepagedetail/homepagedetail-routing.module.ts ***!
    \*****************************************************************/

  /*! exports provided: HomepagedetailPageRoutingModule */

  /***/
  function srcAppHomepagedetailHomepagedetailRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "HomepagedetailPageRoutingModule", function () {
      return HomepagedetailPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _homepagedetail_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./homepagedetail.page */
    "./src/app/homepagedetail/homepagedetail.page.ts");

    var routes = [{
      path: ':id',
      component: _homepagedetail_page__WEBPACK_IMPORTED_MODULE_3__["HomepagedetailPage"]
    }];

    var HomepagedetailPageRoutingModule = function HomepagedetailPageRoutingModule() {
      _classCallCheck(this, HomepagedetailPageRoutingModule);
    };

    HomepagedetailPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], HomepagedetailPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/homepagedetail/homepagedetail.module.ts":
  /*!*********************************************************!*\
    !*** ./src/app/homepagedetail/homepagedetail.module.ts ***!
    \*********************************************************/

  /*! exports provided: HomepagedetailPageModule */

  /***/
  function srcAppHomepagedetailHomepagedetailModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "HomepagedetailPageModule", function () {
      return HomepagedetailPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _homepagedetail_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./homepagedetail-routing.module */
    "./src/app/homepagedetail/homepagedetail-routing.module.ts");
    /* harmony import */


    var _homepagedetail_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./homepagedetail.page */
    "./src/app/homepagedetail/homepagedetail.page.ts");

    var HomepagedetailPageModule = function HomepagedetailPageModule() {
      _classCallCheck(this, HomepagedetailPageModule);
    };

    HomepagedetailPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _homepagedetail_routing_module__WEBPACK_IMPORTED_MODULE_5__["HomepagedetailPageRoutingModule"]],
      declarations: [_homepagedetail_page__WEBPACK_IMPORTED_MODULE_6__["HomepagedetailPage"]]
    })], HomepagedetailPageModule);
    /***/
  },

  /***/
  "./src/app/homepagedetail/homepagedetail.page.scss":
  /*!*********************************************************!*\
    !*** ./src/app/homepagedetail/homepagedetail.page.scss ***!
    \*********************************************************/

  /*! exports provided: default */

  /***/
  function srcAppHomepagedetailHomepagedetailPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".detail_box {\n  border-bottom-left-radius: 40%;\n  border-bottom-right-radius: 40%;\n  background-color: #F9F9F9;\n}\n\n.title {\n  font-size: 22px;\n  color: #666666;\n}\n\n.image-area {\n  margin-top: 1em;\n  width: 3em;\n  height: 3em;\n  background: white;\n  border-radius: 0.5em;\n  box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.5);\n}\n\n.image-area img {\n  margin-left: 2px;\n  margin-top: 3px;\n}\n\n.small-padding {\n  padding: 8px;\n}\n\n.profile-name {\n  color: #8B8B8B;\n  font-size: 20px;\n}\n\n.customer-phone {\n  font-size: 0.8em;\n  color: #4272B9;\n}\n\n.customer-email {\n  font-size: 16px;\n  color: #B4B4B4;\n}\n\n.edit-icon {\n  width: 24px;\n  height: 24px;\n}\n\n.delete-icon {\n  width: 22px;\n  height: 22px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaG9tZXBhZ2VkZXRhaWwvRjpcXG1vYmlsZWFwcC9zcmNcXGFwcFxcaG9tZXBhZ2VkZXRhaWxcXGhvbWVwYWdlZGV0YWlsLnBhZ2Uuc2NzcyIsInNyYy9hcHAvaG9tZXBhZ2VkZXRhaWwvaG9tZXBhZ2VkZXRhaWwucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksOEJBQUE7RUFDQSwrQkFBQTtFQUNBLHlCQUFBO0FDQ0o7O0FERUU7RUFDRSxlQUFBO0VBQ0EsY0FBQTtBQ0NKOztBREVFO0VBQ0UsZUFBQTtFQUNBLFVBQUE7RUFDQSxXQUFBO0VBQ0EsaUJBQUE7RUFDQSxvQkFBQTtFQUNBLDBDQUFBO0FDQ0o7O0FEQUk7RUFDSSxnQkFBQTtFQUNKLGVBQUE7QUNFSjs7QURFRTtFQUNFLFlBQUE7QUNDSjs7QURDRTtFQUNFLGNBQUE7RUFDQSxlQUFBO0FDRUo7O0FEQUU7RUFDRSxnQkFBQTtFQUNBLGNBQUE7QUNHSjs7QURBRTtFQUNFLGVBQUE7RUFDQSxjQUFBO0FDR0o7O0FEQUU7RUFDRSxXQUFBO0VBQ0EsWUFBQTtBQ0dKOztBRENBO0VBQ0ksV0FBQTtFQUNBLFlBQUE7QUNFSiIsImZpbGUiOiJzcmMvYXBwL2hvbWVwYWdlZGV0YWlsL2hvbWVwYWdlZGV0YWlsLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5kZXRhaWxfYm94IHtcclxuICAgIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDQwJTtcclxuICAgIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiA0MCU7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjRjlGOUY5O1xyXG4gIH1cclxuXHJcbiAgLnRpdGxlIHtcclxuICAgIGZvbnQtc2l6ZTogMjJweDtcclxuICAgIGNvbG9yOiAjNjY2NjY2O1xyXG4gIH1cclxuXHJcbiAgLmltYWdlLWFyZWEge1xyXG4gICAgbWFyZ2luLXRvcDogMWVtO1xyXG4gICAgd2lkdGg6IDNlbTtcclxuICAgIGhlaWdodDogM2VtO1xyXG4gICAgYmFja2dyb3VuZDogd2hpdGU7XHJcbiAgICBib3JkZXItcmFkaXVzOiAwLjVlbTtcclxuICAgIGJveC1zaGFkb3c6IDAgMXB4IDNweCAwIHJnYmEoMCwgMCwgMCwgMC41KTtcclxuICAgIGltZ3tcclxuICAgICAgICBtYXJnaW4tbGVmdDogMnB4O1xyXG4gICAgbWFyZ2luLXRvcDogM3B4O1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLnNtYWxsLXBhZGRpbmcge1xyXG4gICAgcGFkZGluZzogOHB4O1xyXG4gIH1cclxuICAucHJvZmlsZS1uYW1le1xyXG4gICAgY29sb3I6ICM4QjhCOEI7XHJcbiAgICBmb250LXNpemU6IDIwcHg7XHJcbiAgfVxyXG4gIC5jdXN0b21lci1waG9uZSB7XHJcbiAgICBmb250LXNpemU6IDAuOGVtO1xyXG4gICAgY29sb3I6ICM0MjcyQjk7XHJcbiAgfVxyXG5cclxuICAuY3VzdG9tZXItZW1haWwge1xyXG4gICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgY29sb3I6ICNCNEI0QjQ7XHJcbiAgfVxyXG5cclxuICAuZWRpdC1pY29ue1xyXG4gICAgd2lkdGg6IDI0cHg7XHJcbiAgICBoZWlnaHQ6IDI0cHg7XHJcbiAgfVxyXG5cclxuICBcclxuLmRlbGV0ZS1pY29uIHtcclxuICAgIHdpZHRoOiAyMnB4O1xyXG4gICAgaGVpZ2h0OiAyMnB4O1xyXG59XHJcbiAgIiwiLmRldGFpbF9ib3gge1xuICBib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiA0MCU7XG4gIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiA0MCU7XG4gIGJhY2tncm91bmQtY29sb3I6ICNGOUY5Rjk7XG59XG5cbi50aXRsZSB7XG4gIGZvbnQtc2l6ZTogMjJweDtcbiAgY29sb3I6ICM2NjY2NjY7XG59XG5cbi5pbWFnZS1hcmVhIHtcbiAgbWFyZ2luLXRvcDogMWVtO1xuICB3aWR0aDogM2VtO1xuICBoZWlnaHQ6IDNlbTtcbiAgYmFja2dyb3VuZDogd2hpdGU7XG4gIGJvcmRlci1yYWRpdXM6IDAuNWVtO1xuICBib3gtc2hhZG93OiAwIDFweCAzcHggMCByZ2JhKDAsIDAsIDAsIDAuNSk7XG59XG4uaW1hZ2UtYXJlYSBpbWcge1xuICBtYXJnaW4tbGVmdDogMnB4O1xuICBtYXJnaW4tdG9wOiAzcHg7XG59XG5cbi5zbWFsbC1wYWRkaW5nIHtcbiAgcGFkZGluZzogOHB4O1xufVxuXG4ucHJvZmlsZS1uYW1lIHtcbiAgY29sb3I6ICM4QjhCOEI7XG4gIGZvbnQtc2l6ZTogMjBweDtcbn1cblxuLmN1c3RvbWVyLXBob25lIHtcbiAgZm9udC1zaXplOiAwLjhlbTtcbiAgY29sb3I6ICM0MjcyQjk7XG59XG5cbi5jdXN0b21lci1lbWFpbCB7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgY29sb3I6ICNCNEI0QjQ7XG59XG5cbi5lZGl0LWljb24ge1xuICB3aWR0aDogMjRweDtcbiAgaGVpZ2h0OiAyNHB4O1xufVxuXG4uZGVsZXRlLWljb24ge1xuICB3aWR0aDogMjJweDtcbiAgaGVpZ2h0OiAyMnB4O1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/homepagedetail/homepagedetail.page.ts":
  /*!*******************************************************!*\
    !*** ./src/app/homepagedetail/homepagedetail.page.ts ***!
    \*******************************************************/

  /*! exports provided: HomepagedetailPage */

  /***/
  function srcAppHomepagedetailHomepagedetailPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "HomepagedetailPage", function () {
      return HomepagedetailPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _model_design_model__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../model/design.model */
    "./src/app/model/design.model.ts");
    /* harmony import */


    var _api_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ../api.service */
    "./src/app/api.service.ts");
    /* harmony import */


    var _utilities_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ../utilities.service */
    "./src/app/utilities.service.ts");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");

    var HomepagedetailPage = /*#__PURE__*/function () {
      function HomepagedetailPage(route, apiservice, utils, navController) {
        _classCallCheck(this, HomepagedetailPage);

        this.route = route;
        this.apiservice = apiservice;
        this.utils = utils;
        this.navController = navController;
        this.myId = null;
      }

      _createClass(HomepagedetailPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.myId = this.route.snapshot.paramMap.get('id');
          console.log(this.myId);
          this.desginData = new _model_design_model__WEBPACK_IMPORTED_MODULE_3__["DesginDataModel"]();
          this.getDesginDetail();
          console.log("re", this.desginData.phonenumber);
        }
      }, {
        key: "getDesginDetail",
        value: function getDesginDetail() {
          var _this = this;

          this.utils.showLoading('loading').then(function (success) {
            _this.apiservice.getDesginDetail(_this.myId).subscribe(function (response) {
              _this.utils.hideLoading();

              _this.desginData = response[0];
              console.log("reach", _this.desginData);
            }, function (responseError) {
              _this.utils.hideLoading();

              var error = responseError.error;

              _this.utils.errorSnackBar(error.message[0].messages[0].message);
            });
          });
        }
      }, {
        key: "goBack",
        value: function goBack() {
          this.navController.pop();
        }
      }]);

      return HomepagedetailPage;
    }();

    HomepagedetailPage.ctorParameters = function () {
      return [{
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]
      }, {
        type: _api_service__WEBPACK_IMPORTED_MODULE_4__["ApiService"]
      }, {
        type: _utilities_service__WEBPACK_IMPORTED_MODULE_5__["UtilitiesService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["NavController"]
      }];
    };

    HomepagedetailPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-homepagedetail',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./homepagedetail.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/homepagedetail/homepagedetail.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./homepagedetail.page.scss */
      "./src/app/homepagedetail/homepagedetail.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], _api_service__WEBPACK_IMPORTED_MODULE_4__["ApiService"], _utilities_service__WEBPACK_IMPORTED_MODULE_5__["UtilitiesService"], _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["NavController"]])], HomepagedetailPage);
    /***/
  },

  /***/
  "./src/app/model/design.model.ts":
  /*!***************************************!*\
    !*** ./src/app/model/design.model.ts ***!
    \***************************************/

  /*! exports provided: DesignModel, DesignDetails, Solarmake, Solarmodel, Invertermake, Invertermodel, DesginDataModel, PrelimDesign, activities */

  /***/
  function srcAppModelDesignModelTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DesignModel", function () {
      return DesignModel;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DesignDetails", function () {
      return DesignDetails;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Solarmake", function () {
      return Solarmake;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Solarmodel", function () {
      return Solarmodel;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Invertermake", function () {
      return Invertermake;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Invertermodel", function () {
      return Invertermodel;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DesginDataModel", function () {
      return DesginDataModel;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "PrelimDesign", function () {
      return PrelimDesign;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "activities", function () {
      return activities;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");

    var DesignModel = function DesignModel() {
      _classCallCheck(this, DesignModel);
    };

    var DesignDetails = function DesignDetails() {
      _classCallCheck(this, DesignDetails);
    };

    var Solarmake = function Solarmake() {
      _classCallCheck(this, Solarmake);
    };

    var Solarmodel = function Solarmodel() {
      _classCallCheck(this, Solarmodel);
    };

    var Invertermake = function Invertermake() {
      _classCallCheck(this, Invertermake);
    };

    var Invertermodel = function Invertermodel() {
      _classCallCheck(this, Invertermodel);
    };

    var DesginDataModel = function DesginDataModel() {
      _classCallCheck(this, DesginDataModel);

      this.architecturaldesign = [];
      this.attachments = [];
    };

    var PrelimDesign = function PrelimDesign() {
      _classCallCheck(this, PrelimDesign);
    };

    var activities = function activities() {
      _classCallCheck(this, activities);
    };
    /***/

  }
}]);
//# sourceMappingURL=homepagedetail-homepagedetail-module-es5.js.map