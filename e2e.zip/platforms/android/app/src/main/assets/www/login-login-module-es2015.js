(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["login-login-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/login/login.page.html":
/*!*****************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/login/login.page.html ***!
  \*****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content class=\"ion-padding login-background\">\r\n    <ion-grid class=\"ion-padding\">\r\n        <ion-row class=\"ion-margin-top\">\r\n            <ion-col size=\"12\" class=\"ion-no-margin ion-no-padding\">\r\n                <span class=\"title text-bold\">\r\n                    Wattmonk\r\n                </span>\r\n            </ion-col>\r\n        </ion-row>\r\n\r\n    </ion-grid>\r\n\r\n    <ion-grid class=\"ion-padding form-background\">\r\n        <ion-row class=\"ion-margin-top\">\r\n            <ion-col size=\"12\" class=\"ion-no-margin ion-no-padding\">\r\n                <span class=\"subtitle\">\r\n                    Welcome\r\n                </span>\r\n                <span class=\"subtitle\" *ngIf=\"isLoggedInOnce\">\r\n                    back\r\n                </span>\r\n            </ion-col>\r\n            <ion-col size=\"12\" class=\"ion-no-margin ion-no-padding\">\r\n                <span class=\"subtitle-sub-text subtitle-dim-color\">\r\n                    sign in to continue\r\n                </span>\r\n            </ion-col>\r\n        </ion-row>\r\n        <ion-row class=\"ion-margin-top\">\r\n            <ion-col size=\"12\" class=\"ion-no-padding\">\r\n                <form [formGroup]=\"loginForm\" novalidate>\r\n                    <ion-grid class=\"ion-no-padding\">\r\n                        <ion-row class=\"ion-margin-top\">\r\n                            <ion-col size=\"12\">\r\n                                <ion-input type=\"email\" placeholder=\"your email address\" class=\"form-control\" autocomplete=\"off\"\r\n                                    formControlName=\"identifier\">\r\n                                </ion-input>\r\n                                <div class=\"error_div\">\r\n                                    <div *ngIf=\"loginForm.get('identifier').hasError('pattern') && loginForm.get('identifier').dirty\" >\r\n                                        <span class=\"error\">{{emailError}}</span>\r\n                                    </div> \r\n                                    <div *ngIf=\"loginForm.get('identifier').value === '' && loginForm.get('identifier').dirty\" >\r\n                                        <span class=\"error\">{{fieldRequired}}</span>\r\n                                    </div>      \r\n                                </div>  \r\n                            </ion-col>\r\n\r\n                            <ion-col size=\"12\" class=\"ion-margin-top\">\r\n                                <div class=\"password_box\">\r\n                                    <ion-input type=\"password\" class=\"password_input\" [type]=\"getType()\" placeholder=\"your password\" formControlName=\"password\">\r\n                                    </ion-input>\r\n                                    <div class=\"eye_box\">\r\n                                        <ion-icon name=\"eye\" *ngIf=\"!this.isActiveToggleTextPassword\" (click)=\"toggleTextPassword()\" slot=\"end\"></ion-icon>\r\n                                        <ion-icon name=\"eye-off\" *ngIf=\"this.isActiveToggleTextPassword\" (click)=\"toggleTextPassword()\" slot=\"end\"></ion-icon>\r\n                                    </div>\r\n                                </div>\r\n                                <div class=\"error_div\">\r\n                                    <div *ngIf=\"password.errors?.minlength\">\r\n                                        <span class=\"error\">Invalid password</span>\r\n                                    </div>       \r\n                                </div>  \r\n                            </ion-col>\r\n\r\n                            <ion-col size=\"12\" class=\"forgot-password-text\">\r\n                                <p style=\"text-align: end\" class=\"ion-padding\" [routerLink]=\"['/forgot-password']\"\r\n                                    routerDirection=\"forward\">Forgot your password?</p>\r\n                            </ion-col>\r\n\r\n                            <ion-col size=\"12\" class=\"ion-margin-top\">\r\n                                <h1 class=\"ion-no-margin ion-no-padding action-button-color\" (click)=\"login()\">\r\n                                    Login\r\n                                </h1>\r\n                            </ion-col>\r\n                        </ion-row>\r\n                    </ion-grid>\r\n                </form>\r\n            </ion-col>\r\n        </ion-row>\r\n    </ion-grid>\r\n\r\n\r\n</ion-content>\r\n");

/***/ }),

/***/ "./src/app/login/login-routing.module.ts":
/*!***********************************************!*\
  !*** ./src/app/login/login-routing.module.ts ***!
  \***********************************************/
/*! exports provided: LoginPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPageRoutingModule", function() { return LoginPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./login.page */ "./src/app/login/login.page.ts");




const routes = [
    {
        path: '',
        component: _login_page__WEBPACK_IMPORTED_MODULE_3__["LoginPage"]
    }
];
let LoginPageRoutingModule = class LoginPageRoutingModule {
};
LoginPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], LoginPageRoutingModule);



/***/ }),

/***/ "./src/app/login/login.module.ts":
/*!***************************************!*\
  !*** ./src/app/login/login.module.ts ***!
  \***************************************/
/*! exports provided: LoginPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPageModule", function() { return LoginPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _login_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./login-routing.module */ "./src/app/login/login-routing.module.ts");
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./login.page */ "./src/app/login/login.page.ts");







let LoginPageModule = class LoginPageModule {
};
LoginPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _login_routing_module__WEBPACK_IMPORTED_MODULE_5__["LoginPageRoutingModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"]
        ],
        declarations: [_login_page__WEBPACK_IMPORTED_MODULE_6__["LoginPage"]]
    })
], LoginPageModule);



/***/ }),

/***/ "./src/app/login/login.page.scss":
/*!***************************************!*\
  !*** ./src/app/login/login.page.scss ***!
  \***************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".title {\n  font-size: 3em;\n}\n\n.text-bold {\n  font-weight: bold;\n}\n\n.subtitle {\n  font-size: 2em;\n  color: #434343;\n}\n\nion-content.login-background {\n  --background: white;\n  background: linear-gradient(rgba(255, 255, 255, 0.9), rgba(255, 255, 255, 0.9)), url(\"/assets/images/login_background.png\");\n  background-position: bottom;\n  background-repeat: no-repeat;\n  background-size: contain;\n}\n\n.form-background {\n  background: linear-gradient(rgba(255, 255, 255, 0.9), rgba(255, 255, 255, 0.9)), url(\"/assets/images/wattmonk_logo.png\");\n  background-position: top;\n  background-repeat: no-repeat;\n  background-size: contain;\n}\n\n.subtitle-sub-text {\n  font-size: 1.8em;\n  color: #A5A095;\n}\n\n.forgot-password-text {\n  color: #7DA4DD;\n}\n\n.email_valid {\n  color: #495057 !important;\n}\n\n.password_box {\n  display: flex;\n  border-bottom: 1px solid #ced4da !important;\n}\n\n.password_input {\n  margin-bottom: -5px;\n  font-size: 14px;\n}\n\n.eye_box {\n  display: flex;\n  align-items: center;\n}\n\n.error {\n  color: #df3e3e;\n  font-size: 11px;\n  margin-left: 5px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbG9naW4vRjpcXG1vYmlsZWFwcC9zcmNcXGFwcFxcbG9naW5cXGxvZ2luLnBhZ2Uuc2NzcyIsInNyYy9hcHAvbG9naW4vbG9naW4ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsY0FBQTtBQ0NGOztBREVBO0VBQ0UsaUJBQUE7QUNDRjs7QURFQTtFQUNFLGNBQUE7RUFDQSxjQUFBO0FDQ0Y7O0FERUE7RUFDRSxtQkFBQTtFQUNBLDJIQUFBO0VBQ0EsMkJBQUE7RUFDQSw0QkFBQTtFQUNBLHdCQUFBO0FDQ0Y7O0FERUE7RUFDRSx3SEFBQTtFQUNBLHdCQUFBO0VBQ0EsNEJBQUE7RUFDQSx3QkFBQTtBQ0NGOztBRElBO0VBQ0UsZ0JBQUE7RUFDQSxjQUFBO0FDREY7O0FESUE7RUFDRSxjQUFBO0FDREY7O0FESUE7RUFDRSx5QkFBQTtBQ0RGOztBRElBO0VBQ0UsYUFBQTtFQUNBLDJDQUFBO0FDREY7O0FES0E7RUFDRSxtQkFBQTtFQUNBLGVBQUE7QUNGRjs7QURLQTtFQUNFLGFBQUE7RUFDQSxtQkFBQTtBQ0ZGOztBREtBO0VBQ0UsY0FBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtBQ0ZGIiwiZmlsZSI6InNyYy9hcHAvbG9naW4vbG9naW4ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnRpdGxlIHtcclxuICBmb250LXNpemU6IDNlbTtcclxufVxyXG5cclxuLnRleHQtYm9sZCB7XHJcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbn1cclxuXHJcbi5zdWJ0aXRsZSB7XHJcbiAgZm9udC1zaXplOiAyZW07XHJcbiAgY29sb3I6ICM0MzQzNDM7XHJcbn1cclxuXHJcbmlvbi1jb250ZW50LmxvZ2luLWJhY2tncm91bmQge1xyXG4gIC0tYmFja2dyb3VuZDogd2hpdGU7XHJcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KHJnYmEoMjU1LCAyNTUsIDI1NSwgMC45KSwgcmdiYSgyNTUsIDI1NSwgMjU1LCAwLjkpKSwgdXJsKFwiL2Fzc2V0cy9pbWFnZXMvbG9naW5fYmFja2dyb3VuZC5wbmdcIik7XHJcbiAgYmFja2dyb3VuZC1wb3NpdGlvbjogYm90dG9tO1xyXG4gIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XHJcbiAgYmFja2dyb3VuZC1zaXplOiBjb250YWluO1xyXG59XHJcblxyXG4uZm9ybS1iYWNrZ3JvdW5kIHtcclxuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQocmdiYSgyNTUsIDI1NSwgMjU1LCAwLjkpLCByZ2JhKDI1NSwgMjU1LCAyNTUsIDAuOSkpLCB1cmwoXCIvYXNzZXRzL2ltYWdlcy93YXR0bW9ua19sb2dvLnBuZ1wiKTtcclxuICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiB0b3A7XHJcbiAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcclxuICBiYWNrZ3JvdW5kLXNpemU6IGNvbnRhaW47XHJcbn1cclxuXHJcblxyXG5cclxuLnN1YnRpdGxlLXN1Yi10ZXh0IHtcclxuICBmb250LXNpemU6IDEuOGVtO1xyXG4gIGNvbG9yOiAjQTVBMDk1O1xyXG59XHJcblxyXG4uZm9yZ290LXBhc3N3b3JkLXRleHQge1xyXG4gIGNvbG9yOiAjN0RBNEREO1xyXG59XHJcblxyXG4uZW1haWxfdmFsaWQge1xyXG4gIGNvbG9yOiAjNDk1MDU3ICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5wYXNzd29yZF9ib3gge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNjZWQ0ZGEgIWltcG9ydGFudDtcclxuXHJcbn1cclxuXHJcbi5wYXNzd29yZF9pbnB1dCB7XHJcbiAgbWFyZ2luLWJvdHRvbTogLTVweDtcclxuICBmb250LXNpemU6IDE0cHg7XHJcbn1cclxuXHJcbi5leWVfYm94IHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbn1cclxuXHJcbi5lcnJvciB7XHJcbiAgY29sb3I6IHJnYigyMjMsIDYyLCA2Mik7XHJcbiAgZm9udC1zaXplOiAxMXB4O1xyXG4gIG1hcmdpbi1sZWZ0OiA1cHg7XHJcbn1cclxuIiwiLnRpdGxlIHtcbiAgZm9udC1zaXplOiAzZW07XG59XG5cbi50ZXh0LWJvbGQge1xuICBmb250LXdlaWdodDogYm9sZDtcbn1cblxuLnN1YnRpdGxlIHtcbiAgZm9udC1zaXplOiAyZW07XG4gIGNvbG9yOiAjNDM0MzQzO1xufVxuXG5pb24tY29udGVudC5sb2dpbi1iYWNrZ3JvdW5kIHtcbiAgLS1iYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KHJnYmEoMjU1LCAyNTUsIDI1NSwgMC45KSwgcmdiYSgyNTUsIDI1NSwgMjU1LCAwLjkpKSwgdXJsKFwiL2Fzc2V0cy9pbWFnZXMvbG9naW5fYmFja2dyb3VuZC5wbmdcIik7XG4gIGJhY2tncm91bmQtcG9zaXRpb246IGJvdHRvbTtcbiAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcbiAgYmFja2dyb3VuZC1zaXplOiBjb250YWluO1xufVxuXG4uZm9ybS1iYWNrZ3JvdW5kIHtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KHJnYmEoMjU1LCAyNTUsIDI1NSwgMC45KSwgcmdiYSgyNTUsIDI1NSwgMjU1LCAwLjkpKSwgdXJsKFwiL2Fzc2V0cy9pbWFnZXMvd2F0dG1vbmtfbG9nby5wbmdcIik7XG4gIGJhY2tncm91bmQtcG9zaXRpb246IHRvcDtcbiAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcbiAgYmFja2dyb3VuZC1zaXplOiBjb250YWluO1xufVxuXG4uc3VidGl0bGUtc3ViLXRleHQge1xuICBmb250LXNpemU6IDEuOGVtO1xuICBjb2xvcjogI0E1QTA5NTtcbn1cblxuLmZvcmdvdC1wYXNzd29yZC10ZXh0IHtcbiAgY29sb3I6ICM3REE0REQ7XG59XG5cbi5lbWFpbF92YWxpZCB7XG4gIGNvbG9yOiAjNDk1MDU3ICFpbXBvcnRhbnQ7XG59XG5cbi5wYXNzd29yZF9ib3gge1xuICBkaXNwbGF5OiBmbGV4O1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2NlZDRkYSAhaW1wb3J0YW50O1xufVxuXG4ucGFzc3dvcmRfaW5wdXQge1xuICBtYXJnaW4tYm90dG9tOiAtNXB4O1xuICBmb250LXNpemU6IDE0cHg7XG59XG5cbi5leWVfYm94IHtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbn1cblxuLmVycm9yIHtcbiAgY29sb3I6ICNkZjNlM2U7XG4gIGZvbnQtc2l6ZTogMTFweDtcbiAgbWFyZ2luLWxlZnQ6IDVweDtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/login/login.page.ts":
/*!*************************************!*\
  !*** ./src/app/login/login.page.ts ***!
  \*************************************/
/*! exports provided: LoginPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPage", function() { return LoginPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _api_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../api.service */ "./src/app/api.service.ts");
/* harmony import */ var _utilities_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../utilities.service */ "./src/app/utilities.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _storage_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../storage.service */ "./src/app/storage.service.ts");
/* harmony import */ var _model_constants__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../model/constants */ "./src/app/model/constants.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _contants__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../contants */ "./src/app/contants.ts");
/* harmony import */ var _networkdetect_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../networkdetect.service */ "./src/app/networkdetect.service.ts");











let LoginPage = class LoginPage {
    constructor(formBuilder, utils, apiService, storageService, router, network, navController) {
        this.formBuilder = formBuilder;
        this.utils = utils;
        this.apiService = apiService;
        this.storageService = storageService;
        this.router = router;
        this.network = network;
        this.navController = navController;
        this.isActiveToggleTextPassword = true;
        this.emailError = _model_constants__WEBPACK_IMPORTED_MODULE_7__["INVALID_EMAIL_MESSAGE"];
        this.fieldRequired = _model_constants__WEBPACK_IMPORTED_MODULE_7__["FIELD_REQUIRED"];
        this.isLoggedInOnce = false;
        this.isLoggedInOnce = this.storageService.isLoggedInOnce();
    }
    ngOnInit() {
        const EMAILPATTERN = /^[a-z0-9!#$%&'*+\/=?^_`{|}~.-]+@[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)*$/i;
        this.loginForm = this.formBuilder.group({
            identifier: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](this.storageService.getUserName(), [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].pattern(EMAILPATTERN)]),
            password: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](this.storageService.getPassword(), [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(6)])
        });
    }
    ionViewDidEnter() {
        this.network.networkSwitch.subscribe(data => {
            this.netSwitch = data;
            console.log(this.netSwitch);
        });
        this.network.networkDisconnect();
        this.network.networkConnect();
    }
    login() {
        if (!this.netSwitch) {
            this.utils.errorSnackBar('No internet connection');
        }
        else {
            console.log(this.loginForm);
            if (this.loginForm.status === 'VALID') {
                this.utils.showLoading('Logging In').then(() => {
                    this.apiService.login(this.loginForm.value).subscribe(response => {
                        this.utils.hideLoading().then(() => {
                            console.log('Res', response);
                            if (response.user.role.id == _contants__WEBPACK_IMPORTED_MODULE_9__["ROLES"].Surveyor) {
                                this.storageService.setUserName(this.loginForm.get('identifier').value);
                                this.storageService.setPassword(this.loginForm.get('password').value);
                                // this.storageService.setUser(response.user, response.jwt);
                                if (response.user.isdefaultpassword) {
                                    this.storageService.setJWTToken(response.jwt);
                                    this.apiService.refreshHeader();
                                    this.navController.navigateRoot(['changepassword']);
                                }
                                else {
                                    this.storageService.setUser(response.user, response.jwt);
                                    this.apiService.refreshHeader();
                                    // this.navController.navigateRoot(['homepage']);
                                    this.navController.navigateRoot(['surveyoroverview']);
                                }
                            }
                            else if (response.user.role.id == _contants__WEBPACK_IMPORTED_MODULE_9__["ROLES"].Designer) {
                                // this.utils.errorSnackBar("Access Denied!! Soon we will be coming up with our platform accessibility.");
                                this.storageService.setUserName(this.loginForm.get('identifier').value);
                                this.storageService.setPassword(this.loginForm.get('password').value);
                                if (response.user.isdefaultpassword) {
                                    this.storageService.setJWTToken(response.jwt);
                                    this.apiService.refreshHeader();
                                    this.navController.navigateRoot(['changepassword']);
                                }
                                else {
                                    this.storageService.setUser(response.user, response.jwt);
                                    this.apiService.refreshHeader();
                                    this.navController.navigateRoot(['designoverview']);
                                }
                            }
                            else if (response.user.role.id == _contants__WEBPACK_IMPORTED_MODULE_9__["ROLES"].Analyst) {
                                this.storageService.setUserName(this.loginForm.get('identifier').value);
                                this.storageService.setPassword(this.loginForm.get('password').value);
                                if (response.user.isdefaultpassword) {
                                    this.storageService.setJWTToken(response.jwt);
                                    this.apiService.refreshHeader();
                                    this.navController.navigateRoot(['changepassword']);
                                }
                                else {
                                    this.storageService.setUser(response.user, response.jwt);
                                    this.apiService.refreshHeader();
                                    this.navController.navigateRoot(['analystoverview']);
                                }
                            }
                            else {
                                // this.utils.errorSnackBar("Access Denied!! Soon we will be coming up with our platform accessibility.");
                                this.storageService.setUserName(this.loginForm.get('identifier').value);
                                this.storageService.setPassword(this.loginForm.get('password').value);
                                this.storageService.setUser(response.user, response.jwt);
                                this.apiService.refreshHeader();
                                if (response.user.isdefaultpassword) {
                                    this.storageService.setJWTToken(response.jwt);
                                    this.apiService.refreshHeader();
                                    this.navController.navigateRoot(['changepassword']);
                                }
                                else {
                                    this.navController.navigateRoot(['homepage']);
                                }
                            }
                        });
                    }, responseError => {
                        this.utils.hideLoading().then(() => {
                            this.apiService.resetHeaders();
                            const error = responseError.error;
                            // this.utils.errorSnackBar(error);
                            this.utils.errorSnackBar("Entered email and password combination doesn't match any of our records. Please try again.");
                        });
                    });
                });
            }
            else {
                this.apiService.resetHeaders();
                this.utils.errorSnackBar("Entered email and password combination doesn't match any of our records. Please try again.");
            }
        }
    }
    toggleTextPassword() {
        this.isActiveToggleTextPassword = (this.isActiveToggleTextPassword == true) ? false : true;
    }
    getType() {
        return this.isActiveToggleTextPassword ? 'password' : 'text';
    }
    get password() {
        return this.loginForm.get('password');
    }
    changepassword() {
        console.log('rrrrrrrrrrrrrrr');
        this.router.navigate(['/changepassword']);
    }
};
LoginPage.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"] },
    { type: _utilities_service__WEBPACK_IMPORTED_MODULE_4__["UtilitiesService"] },
    { type: _api_service__WEBPACK_IMPORTED_MODULE_3__["ApiService"] },
    { type: _storage_service__WEBPACK_IMPORTED_MODULE_6__["StorageService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_8__["Router"] },
    { type: _networkdetect_service__WEBPACK_IMPORTED_MODULE_10__["NetworkdetectService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["NavController"] }
];
LoginPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-login',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./login.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/login/login.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./login.page.scss */ "./src/app/login/login.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"],
        _utilities_service__WEBPACK_IMPORTED_MODULE_4__["UtilitiesService"],
        _api_service__WEBPACK_IMPORTED_MODULE_3__["ApiService"],
        _storage_service__WEBPACK_IMPORTED_MODULE_6__["StorageService"],
        _angular_router__WEBPACK_IMPORTED_MODULE_8__["Router"],
        _networkdetect_service__WEBPACK_IMPORTED_MODULE_10__["NetworkdetectService"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["NavController"]])
], LoginPage);



/***/ })

}]);
//# sourceMappingURL=login-login-module-es2015.js.map