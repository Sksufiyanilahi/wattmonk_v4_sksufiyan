(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["message-message-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/message/message.page.html":
/*!*********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/message/message.page.html ***!
  \*********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header class=\"ion-no-border\">\r\n    <ion-grid class=\"ion-padding-top ion-padding-start ion-padding-end header-bg\">\r\n        <ion-row>\r\n            <ion-col size=\"auto\">\r\n                <ion-button fill=\"clear\" size=\"small\" class=\"ion-no-padding\" (click)=\"goBack()\">\r\n                    <ion-img src=\"/assets/images/back.svg\" class=\"action-icon\"></ion-img>\r\n                </ion-button>\r\n            </ion-col>\r\n            <ion-col>\r\n                <ion-grid class=\"ion-align-items-center ion-justify-content-center\">\r\n                    <ion-row class=\"ion-align-items-center ion-justify-content-center\">\r\n                        <span class=\"survey-name ion-text-center\">Chats</span>\r\n                    </ion-row>\r\n                </ion-grid>\r\n            </ion-col>\r\n            <ion-col size=\"auto\">\r\n            </ion-col>\r\n            <ion-col size=\"auto\">\r\n            </ion-col>\r\n        </ion-row>\r\n    </ion-grid>\r\n    <ion-grid class=\"position-relative ion-no-padding\">\r\n        <ion-row class=\"ion-no-padding border-header header-half-height\">\r\n        </ion-row>\r\n        <ion-row class=\"ion-no-padding header-half-height\">\r\n\r\n        </ion-row>\r\n        <ion-row class=\"ion-no-padding position-absolute header-icon-position full-width\">\r\n            <ion-col class=\"flex-center\">\r\n                <ion-img src=\"/assets/images/icons8-chat-room.svg\" class=\"header-icon\"></ion-img>\r\n            </ion-col>\r\n        </ion-row>\r\n    </ion-grid>\r\n</ion-header>\r\n\r\n<ion-content>\r\n    <ion-grid *ngIf=\"conversations.length === 0\">\r\n        <ion-row class=\"ion-align-items-center ion-justify-content-center\">\r\n            <ion-col size=\"12\" class=\"ion-align-items-center ion-justify-content-center\">\r\n                No Messages\r\n            </ion-col>\r\n        </ion-row>\r\n    </ion-grid>\r\n\r\n    <ion-list *ngIf=\"conversations.length !== 0\">\r\n        <ion-item *ngFor=\"let conversation of conversations\" (click)=\"openConversation(conversation)\">\r\n            <ion-avatar slot=\"start\">\r\n                <img *ngIf=\"conversation.getConversationWith().getAvatar()\" [src]=\"conversation.getConversationWith().getAvatar()\">\r\n                <img *ngIf=\"!conversation.getConversationWith().getAvatar()\" src=\"/assets/images/user_placeholder.jpg\">\r\n            </ion-avatar>\r\n            <ion-label>\r\n                <h2>{{conversation.getConversationWith().getName()}}</h2>\r\n                <p *ngIf=\"conversation.getLastMessage().getType() === 'text'\">{{conversation.getLastMessage().getText()}}</p>\r\n                <p *ngIf=\"conversation.getLastMessage().getType() !== 'text'\">Media Message</p>\r\n            </ion-label>\r\n        </ion-item>\r\n\r\n    </ion-list>\r\n\r\n    <ion-infinite-scroll threshold=\"100px\" (ionInfinite)=\"loadData($event)\">\r\n        <ion-infinite-scroll-content\r\n                loadingSpinner=\"bubbles\"\r\n                loadingText=\"Loading more data...\">\r\n        </ion-infinite-scroll-content>\r\n    </ion-infinite-scroll>\r\n\r\n\r\n</ion-content>\r\n");

/***/ }),

/***/ "./src/app/message/message-routing.module.ts":
/*!***************************************************!*\
  !*** ./src/app/message/message-routing.module.ts ***!
  \***************************************************/
/*! exports provided: MessagePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MessagePageRoutingModule", function() { return MessagePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _message_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./message.page */ "./src/app/message/message.page.ts");




const routes = [
    {
        path: '',
        component: _message_page__WEBPACK_IMPORTED_MODULE_3__["MessagePage"]
    }
];
let MessagePageRoutingModule = class MessagePageRoutingModule {
};
MessagePageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], MessagePageRoutingModule);



/***/ }),

/***/ "./src/app/message/message.module.ts":
/*!*******************************************!*\
  !*** ./src/app/message/message.module.ts ***!
  \*******************************************/
/*! exports provided: MessagePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MessagePageModule", function() { return MessagePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _message_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./message-routing.module */ "./src/app/message/message-routing.module.ts");
/* harmony import */ var _message_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./message.page */ "./src/app/message/message.page.ts");







let MessagePageModule = class MessagePageModule {
};
MessagePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _message_routing_module__WEBPACK_IMPORTED_MODULE_5__["MessagePageRoutingModule"]
        ],
        declarations: [_message_page__WEBPACK_IMPORTED_MODULE_6__["MessagePage"]]
    })
], MessagePageModule);



/***/ }),

/***/ "./src/app/message/message.page.scss":
/*!*******************************************!*\
  !*** ./src/app/message/message.page.scss ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-header {\n  color: #666666;\n}\n\n.survey-name {\n  font-size: 1.7em;\n  margin-right: 18px;\n}\n\n.profile-icon {\n  width: 50px;\n  height: 50px;\n  margin-right: 4px;\n}\n\n.history-name {\n  font-size: 16px;\n  color: #636363;\n  font-weight: bold;\n}\n\n.history-add {\n  color: #9D9D9D;\n  font-size: 14px;\n}\n\n.history-time {\n  color: #9D9D9D;\n  font-size: 14px;\n}\n\n.assign {\n  font-size: 14px;\n  color: #878382;\n}\n\n.message-box {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbWVzc2FnZS9GOlxcbW9iaWxlYXBwL3NyY1xcYXBwXFxtZXNzYWdlXFxtZXNzYWdlLnBhZ2Uuc2NzcyIsInNyYy9hcHAvbWVzc2FnZS9tZXNzYWdlLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGNBQUE7QUNDSjs7QURDQTtFQUNJLGdCQUFBO0VBQ0Esa0JBQUE7QUNFSjs7QURBQTtFQUNJLFdBQUE7RUFDQSxZQUFBO0VBQ0EsaUJBQUE7QUNHSjs7QURDRTtFQUNFLGVBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7QUNFSjs7QURDRTtFQUNFLGNBQUE7RUFDRSxlQUFBO0FDRU47O0FEQ0U7RUFDRSxjQUFBO0VBQ0EsZUFBQTtBQ0VKOztBRENFO0VBQ0ksZUFBQTtFQUNBLGNBQUE7QUNFTjs7QURDRTtFQUNFLGFBQUE7RUFDQSw4QkFBQTtFQUNBLG1CQUFBO0FDRUoiLCJmaWxlIjoic3JjL2FwcC9tZXNzYWdlL21lc3NhZ2UucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWhlYWRlciB7XHJcbiAgICBjb2xvcjogIzY2NjY2NjtcclxuICB9IFxyXG4uc3VydmV5LW5hbWUge1xyXG4gICAgZm9udC1zaXplOiAxLjdlbTtcclxuICAgIG1hcmdpbi1yaWdodDogMThweFxyXG4gIH0gXHJcbi5wcm9maWxlLWljb257XHJcbiAgICB3aWR0aDogNTBweDtcclxuICAgIGhlaWdodDogNTBweDtcclxuICAgIG1hcmdpbi1yaWdodDogNHB4O1xyXG4gICBcclxuICB9XHJcblxyXG4gIC5oaXN0b3J5LW5hbWV7XHJcbiAgICBmb250LXNpemU6IDE2cHg7IFxyXG4gICAgY29sb3I6ICM2MzYzNjM7XHJcbiAgICBmb250LXdlaWdodDogYm9sZDtcclxuICB9XHJcblxyXG4gIC5oaXN0b3J5LWFkZHtcclxuICAgIGNvbG9yOiAjOUQ5RDlEO1xyXG4gICAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgfVxyXG5cclxuICAuaGlzdG9yeS10aW1le1xyXG4gICAgY29sb3I6ICM5RDlEOUQ7XHJcbiAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgfVxyXG5cclxuICAuYXNzaWdue1xyXG4gICAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICAgIGNvbG9yOiAjODc4MzgyO1xyXG4gIH1cclxuXHJcbiAgLm1lc3NhZ2UtYm94e1xyXG4gICAgZGlzcGxheTogZmxleDsgXHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIH0iLCJpb24taGVhZGVyIHtcbiAgY29sb3I6ICM2NjY2NjY7XG59XG5cbi5zdXJ2ZXktbmFtZSB7XG4gIGZvbnQtc2l6ZTogMS43ZW07XG4gIG1hcmdpbi1yaWdodDogMThweDtcbn1cblxuLnByb2ZpbGUtaWNvbiB7XG4gIHdpZHRoOiA1MHB4O1xuICBoZWlnaHQ6IDUwcHg7XG4gIG1hcmdpbi1yaWdodDogNHB4O1xufVxuXG4uaGlzdG9yeS1uYW1lIHtcbiAgZm9udC1zaXplOiAxNnB4O1xuICBjb2xvcjogIzYzNjM2MztcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG59XG5cbi5oaXN0b3J5LWFkZCB7XG4gIGNvbG9yOiAjOUQ5RDlEO1xuICBmb250LXNpemU6IDE0cHg7XG59XG5cbi5oaXN0b3J5LXRpbWUge1xuICBjb2xvcjogIzlEOUQ5RDtcbiAgZm9udC1zaXplOiAxNHB4O1xufVxuXG4uYXNzaWduIHtcbiAgZm9udC1zaXplOiAxNHB4O1xuICBjb2xvcjogIzg3ODM4Mjtcbn1cblxuLm1lc3NhZ2UtYm94IHtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xufSJdfQ== */");

/***/ }),

/***/ "./src/app/message/message.page.ts":
/*!*****************************************!*\
  !*** ./src/app/message/message.page.ts ***!
  \*****************************************/
/*! exports provided: MessagePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MessagePage", function() { return MessagePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _cometchat_pro_cordova_ionic_chat_CometChat__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @cometchat-pro/cordova-ionic-chat/CometChat */ "./node_modules/@cometchat-pro/cordova-ionic-chat/CometChat.js");
/* harmony import */ var _cometchat_pro_cordova_ionic_chat_CometChat__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_cometchat_pro_cordova_ionic_chat_CometChat__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _utilities_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../utilities.service */ "./src/app/utilities.service.ts");





let MessagePage = class MessagePage {
    constructor(navController, utilities) {
        this.navController = navController;
        this.utilities = utilities;
        this.conversations = [];
    }
    ngOnInit() {
        this.conversationsRequest = new _cometchat_pro_cordova_ionic_chat_CometChat__WEBPACK_IMPORTED_MODULE_3__["CometChat"].ConversationsRequestBuilder()
            .setLimit(50)
            .setConversationType('user')
            .build();
        this.loadData(null);
    }
    goBack() {
        this.navController.pop();
    }
    loadData(event) {
        this.utilities.showLoading('Getting Conversations').then(() => {
            this.conversationsRequest.fetchNext().then((conversationList) => {
                this.utilities.hideLoading().then(() => {
                    console.log('Conversations list received:', conversationList);
                    conversationList.forEach((item) => {
                        console.log('item', item);
                        this.conversations.push(item);
                    });
                    console.log(this.conversations);
                    if (event !== null) {
                        event.target.complete();
                    }
                });
            }, error => {
                this.utilities.hideLoading().then(() => {
                    if (event !== null) {
                        event.target.complete();
                    }
                    console.log('Conversations list fetching failed with error:', error);
                });
            });
        });
    }
    openConversation(conversation) {
        this.navController.navigateForward(['chat/' + conversation.getConversationWith().getUid()]);
    }
};
MessagePage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] },
    { type: _utilities_service__WEBPACK_IMPORTED_MODULE_4__["UtilitiesService"] }
];
MessagePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-message',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./message.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/message/message.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./message.page.scss */ "./src/app/message/message.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"],
        _utilities_service__WEBPACK_IMPORTED_MODULE_4__["UtilitiesService"]])
], MessagePage);



/***/ })

}]);
//# sourceMappingURL=message-message-module-es2015.js.map