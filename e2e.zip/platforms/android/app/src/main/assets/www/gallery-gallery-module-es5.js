function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["gallery-gallery-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/gallery/gallery.page.html":
  /*!*********************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/gallery/gallery.page.html ***!
    \*********************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppGalleryGalleryPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-content class=\"white-bg\">\r\n    <ion-grid slot=\"fixed\" style=\"top: 0; width: 100vw;\">\r\n        <ion-row class=\"ion-justify-content-center ion-align-items-center\">\r\n            <ion-col size=\"auto\">\r\n                <ion-button fill=\"clear\" size=\"small\" (click)=\"goBack()\">\r\n                    <ion-icon name=\"chevron-back-outline\" color=\"dark\"></ion-icon>\r\n                </ion-button>\r\n            </ion-col>\r\n            <ion-col class=\"ion-text-center\">\r\n                <span>{{menuName}}</span>\r\n            </ion-col>\r\n            <ion-col size=\"auto\">\r\n                <ion-button fill=\"light\" size=\"small\" (click)=\"showMenu($event)\">\r\n                    <ion-icon name=\"grid-outline\" color=\"dark\"></ion-icon>\r\n                </ion-button>\r\n            </ion-col>\r\n\r\n        </ion-row>\r\n        <ion-row *ngIf=\"menuName === 'Electricals'\">\r\n            <ion-col>\r\n                <ion-segment mode=\"ios\" class=\"segments\" (ionChange)=\"onTabSelected($event)\">\r\n                    <ion-segment-button value=\"mspimages\">\r\n                        <ion-label>MSP</ion-label>\r\n                    </ion-segment-button>\r\n                    <ion-segment-button value=\"utilitymeterimages\">\r\n                        <ion-label>Utility Meter</ion-label>\r\n                    </ion-segment-button>\r\n                    <ion-segment-button value=\"pvinverterimages\">\r\n                        <ion-label>Pv Inverter</ion-label>\r\n                    </ion-segment-button>\r\n                    <ion-segment-button value=\"pvmeterimages\">\r\n                        <ion-label>Pv Meter</ion-label>\r\n                    </ion-segment-button>\r\n                    <ion-segment-button value=\"acdisconnectimages\">\r\n                        <ion-label>Ac Disconnect</ion-label>\r\n                    </ion-segment-button>\r\n                </ion-segment>\r\n            </ion-col>\r\n        </ion-row>\r\n    </ion-grid>\r\n\r\n    <ion-grid class=\"ion-no-padding\" slot=\"fixed\" style=\"bottom: 0; width: 100vw;\" *ngIf=\"listOfImages.length !== 0\">\r\n        <ion-row class=\"ion-justify-content-center ion-align-items-center\">\r\n            <ion-col></ion-col>\r\n            <ion-col size=\"auto\"\r\n                     class=\"white-background ion-align-items-center ion-justify-content-center\" style=\"padding: 8px;\">\r\n                <ion-row class=\"ion-justify-content-center ion-align-items-center\">\r\n                    <ion-col>\r\n                        <ion-button fill=\"clear\" size=\"small\" (click)=\"previousImage()\">\r\n                            <ion-icon name=\"chevron-back-outline\" color=\"dark\"></ion-icon>\r\n                        </ion-button>\r\n                    </ion-col>\r\n                    <ion-col>\r\n                        <ion-label>\r\n                            {{currentPosition + 1}}/{{listOfImages.length}}\r\n                        </ion-label>\r\n                    </ion-col>\r\n                    <ion-col>\r\n                        <ion-button fill=\"clear\" size=\"small\" (click)=\"nextImage()\">\r\n                            <ion-icon name=\"chevron-forward-outline\" color=\"dark\"></ion-icon>\r\n                        </ion-button>\r\n                    </ion-col>\r\n                </ion-row>\r\n            </ion-col>\r\n        </ion-row>\r\n    </ion-grid>\r\n\r\n    <pinch-zoom *ngIf=\"image\" class=\"full-image white-bg\">\r\n        <ion-img [src]=\"image.url\" class=\"full-image\"></ion-img>\r\n    </pinch-zoom>\r\n    <div *ngIf=\"!image\" class=\"d-flex flex-row align-center justify-center full-image\">\r\n        <h1>No image available</h1>\r\n    </div>\r\n\r\n</ion-content>\r\n\r\n\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/gallery/menu-popup/menu-popup.component.html":
  /*!****************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/gallery/menu-popup/menu-popup.component.html ***!
    \****************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppGalleryMenuPopupMenuPopupComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-content>\r\n    <ion-list>\r\n        <ion-item button lines=\"none\" (click)=\"showImages('electrical')\">\r\n            Electricals\r\n        </ion-item>\r\n        <ion-item button lines=\"none\" (click)=\"showImages('roof')\">\r\n            Roof\r\n        </ion-item>\r\n        <ion-item button lines=\"none\" (click)=\"showImages('roofdimensionimages')\">\r\n            Roofdimensionimages\r\n        </ion-item>\r\n        <ion-item button lines=\"none\" (click)=\"showImages('appliancesimages')\">\r\n            Appliancesimages\r\n        </ion-item>\r\n        <ion-item button lines=\"none\" (click)=\"showImages('atticimages')\">\r\n            Atticimages\r\n        </ion-item>\r\n        <ion-item button lines=\"none\" (click)=\"showImages('obstaclesimages')\">\r\n            Obstaclesimages\r\n        </ion-item>\r\n        <ion-item button lines=\"none\" (click)=\"showImages('obstaclesdimensionsimages')\">\r\n            Obstaclesdimensionsimages\r\n        </ion-item>\r\n    </ion-list>\r\n\r\n</ion-content>\r\n";
    /***/
  },

  /***/
  "./src/app/gallery/gallery-routing.module.ts":
  /*!***************************************************!*\
    !*** ./src/app/gallery/gallery-routing.module.ts ***!
    \***************************************************/

  /*! exports provided: GalleryPageRoutingModule */

  /***/
  function srcAppGalleryGalleryRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "GalleryPageRoutingModule", function () {
      return GalleryPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _gallery_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./gallery.page */
    "./src/app/gallery/gallery.page.ts");

    var routes = [{
      path: '',
      component: _gallery_page__WEBPACK_IMPORTED_MODULE_3__["GalleryPage"]
    }];

    var GalleryPageRoutingModule = function GalleryPageRoutingModule() {
      _classCallCheck(this, GalleryPageRoutingModule);
    };

    GalleryPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], GalleryPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/gallery/gallery.module.ts":
  /*!*******************************************!*\
    !*** ./src/app/gallery/gallery.module.ts ***!
    \*******************************************/

  /*! exports provided: GalleryPageModule */

  /***/
  function srcAppGalleryGalleryModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "GalleryPageModule", function () {
      return GalleryPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _gallery_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./gallery-routing.module */
    "./src/app/gallery/gallery-routing.module.ts");
    /* harmony import */


    var _gallery_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./gallery.page */
    "./src/app/gallery/gallery.page.ts");
    /* harmony import */


    var _menu_popup_menu_popup_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ./menu-popup/menu-popup.component */
    "./src/app/gallery/menu-popup/menu-popup.component.ts");
    /* harmony import */


    var ngx_pinch_zoom__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! ngx-pinch-zoom */
    "./node_modules/ngx-pinch-zoom/fesm2015/ngx-pinch-zoom.js");

    var GalleryPageModule = function GalleryPageModule() {
      _classCallCheck(this, GalleryPageModule);
    };

    GalleryPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _gallery_routing_module__WEBPACK_IMPORTED_MODULE_5__["GalleryPageRoutingModule"], ngx_pinch_zoom__WEBPACK_IMPORTED_MODULE_8__["PinchZoomModule"]],
      declarations: [_gallery_page__WEBPACK_IMPORTED_MODULE_6__["GalleryPage"], _menu_popup_menu_popup_component__WEBPACK_IMPORTED_MODULE_7__["MenuPopupComponent"]],
      entryComponents: [_gallery_page__WEBPACK_IMPORTED_MODULE_6__["GalleryPage"], _menu_popup_menu_popup_component__WEBPACK_IMPORTED_MODULE_7__["MenuPopupComponent"]]
    })], GalleryPageModule);
    /***/
  },

  /***/
  "./src/app/gallery/gallery.page.scss":
  /*!*******************************************!*\
    !*** ./src/app/gallery/gallery.page.scss ***!
    \*******************************************/

  /*! exports provided: default */

  /***/
  function srcAppGalleryGalleryPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".full-image {\n  width: 100%;\n  height: 100%;\n  -o-object-fit: contain;\n     object-fit: contain;\n  position: absolute;\n  top: 0;\n  left: 0;\n}\n\nion-content {\n  --background: transparent !important;\n}\n\n.white-background {\n  background: white !important;\n  color: black;\n  border-top-left-radius: 4px;\n}\n\nion-segment {\n  --background: #EFEFEF;\n}\n\nion-segment-button {\n  --indicator-color: #FFFFFF;\n  --color-checked: black;\n}\n\n.segments {\n  height: 40px;\n}\n\nion-button {\n  --background: white;\n  height: 40px;\n  width: 40px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZ2FsbGVyeS9GOlxcbW9iaWxlYXBwL3NyY1xcYXBwXFxnYWxsZXJ5XFxnYWxsZXJ5LnBhZ2Uuc2NzcyIsInNyYy9hcHAvZ2FsbGVyeS9nYWxsZXJ5LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0Esc0JBQUE7S0FBQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsTUFBQTtFQUNBLE9BQUE7QUNDRjs7QURFQTtFQUNFLG9DQUFBO0FDQ0Y7O0FERUE7RUFDRSw0QkFBQTtFQUNBLFlBQUE7RUFDQSwyQkFBQTtBQ0NGOztBREVBO0VBQ0UscUJBQUE7QUNDRjs7QURFQTtFQUNFLDBCQUFBO0VBQ0Esc0JBQUE7QUNDRjs7QURFQTtFQUNFLFlBQUE7QUNDRjs7QURFQTtFQUNFLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7QUNDRiIsImZpbGUiOiJzcmMvYXBwL2dhbGxlcnkvZ2FsbGVyeS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuZnVsbC1pbWFnZSB7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgaGVpZ2h0OiAxMDAlO1xyXG4gIG9iamVjdC1maXQ6IGNvbnRhaW47XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIHRvcDogMDtcclxuICBsZWZ0OiAwO1xyXG59XHJcblxyXG5pb24tY29udGVudCB7XHJcbiAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4ud2hpdGUtYmFja2dyb3VuZCB7XHJcbiAgYmFja2dyb3VuZDogd2hpdGUgIWltcG9ydGFudDtcclxuICBjb2xvcjogYmxhY2s7XHJcbiAgYm9yZGVyLXRvcC1sZWZ0LXJhZGl1czogNHB4O1xyXG59XHJcblxyXG5pb24tc2VnbWVudCB7XHJcbiAgLS1iYWNrZ3JvdW5kOiAjRUZFRkVGO1xyXG59XHJcblxyXG5pb24tc2VnbWVudC1idXR0b24ge1xyXG4gIC0taW5kaWNhdG9yLWNvbG9yOiAjRkZGRkZGO1xyXG4gIC0tY29sb3ItY2hlY2tlZDogYmxhY2s7XHJcbn1cclxuXHJcbi5zZWdtZW50cyB7XHJcbiAgaGVpZ2h0OiA0MHB4O1xyXG59XHJcblxyXG5pb24tYnV0dG9uIHtcclxuICAtLWJhY2tncm91bmQ6IHdoaXRlO1xyXG4gIGhlaWdodDogNDBweDtcclxuICB3aWR0aDogNDBweDtcclxufVxyXG5cclxuIiwiLmZ1bGwtaW1hZ2Uge1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAxMDAlO1xuICBvYmplY3QtZml0OiBjb250YWluO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogMDtcbiAgbGVmdDogMDtcbn1cblxuaW9uLWNvbnRlbnQge1xuICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50ICFpbXBvcnRhbnQ7XG59XG5cbi53aGl0ZS1iYWNrZ3JvdW5kIHtcbiAgYmFja2dyb3VuZDogd2hpdGUgIWltcG9ydGFudDtcbiAgY29sb3I6IGJsYWNrO1xuICBib3JkZXItdG9wLWxlZnQtcmFkaXVzOiA0cHg7XG59XG5cbmlvbi1zZWdtZW50IHtcbiAgLS1iYWNrZ3JvdW5kOiAjRUZFRkVGO1xufVxuXG5pb24tc2VnbWVudC1idXR0b24ge1xuICAtLWluZGljYXRvci1jb2xvcjogI0ZGRkZGRjtcbiAgLS1jb2xvci1jaGVja2VkOiBibGFjaztcbn1cblxuLnNlZ21lbnRzIHtcbiAgaGVpZ2h0OiA0MHB4O1xufVxuXG5pb24tYnV0dG9uIHtcbiAgLS1iYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgaGVpZ2h0OiA0MHB4O1xuICB3aWR0aDogNDBweDtcbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/gallery/gallery.page.ts":
  /*!*****************************************!*\
    !*** ./src/app/gallery/gallery.page.ts ***!
    \*****************************************/

  /*! exports provided: GalleryPage */

  /***/
  function srcAppGalleryGalleryPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "GalleryPage", function () {
      return GalleryPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _menu_popup_menu_popup_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ./menu-popup/menu-popup.component */
    "./src/app/gallery/menu-popup/menu-popup.component.ts");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _utilities_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ../utilities.service */
    "./src/app/utilities.service.ts");
    /* harmony import */


    var _api_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ../api.service */
    "./src/app/api.service.ts");
    /* harmony import */


    var _ionic_storage__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! @ionic/storage */
    "./node_modules/@ionic/storage/fesm2015/ionic-storage.js");

    var GalleryPage = /*#__PURE__*/function () {
      function GalleryPage(popoverController, navController, route, utilities, apiService, storage) {
        _classCallCheck(this, GalleryPage);

        this.popoverController = popoverController;
        this.navController = navController;
        this.route = route;
        this.utilities = utilities;
        this.apiService = apiService;
        this.storage = storage;
        this.currentPosition = 0;
        this.listOfImages = [];
        this.menuName = 'Electricals';
        this.selectedTab = 'mspimages';
        this.surveyId = +this.route.snapshot.paramMap.get('id');
      }

      _createClass(GalleryPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.getSurveyDetails();
        } // setDataToDataModel(data: MenuModel[]) {
        //   console.log(this.survey);
        //   data.forEach((mainMenu) => {
        //     if (mainMenu.imageModel !== null && mainMenu.imageModel !== undefined) {
        //       mainMenu.imageModel.forEach((imageModel) => {
        //         if (imageModel.image !== '') {
        //           const image = new Image();
        //           image.url = imageModel.image;
        //           this.survey[imageModel.imageUploadTag].push(image);
        //         }
        //       });
        //     }
        //     if (mainMenu.subMenu !== null && mainMenu.subMenu !== undefined) {
        //       mainMenu.subMenu.forEach((submenu) => {
        //         submenu.images.forEach((imageModel) => {
        //           if (imageModel.image !== '') {
        //             const image = new Image();
        //             image.url = imageModel.image;
        //             this.survey[imageModel.imageUploadTag].push(image);
        //           }
        //         });
        //       });
        //     }
        //   });
        //   this.listOfImages = this.survey.mspimages;
        //   this.setImage();
        // }

      }, {
        key: "getSurveyDetails",
        value: function getSurveyDetails() {
          var _this = this;

          this.utilities.showLoading('Getting Survey Details').then(function (success) {
            _this.apiService.getSurveyDetail(_this.surveyId).subscribe(function (result) {
              _this.utilities.hideLoading().then(function () {
                _this.survey = result;
                _this.listOfImages = _this.survey.mspimages;
                _this.currentPosition = 0;

                _this.setImage();
              });
            }, function (error) {
              _this.utilities.hideLoading();
            });
          });
        }
      }, {
        key: "previousImage",
        value: function previousImage() {
          if (this.currentPosition > 0) {
            this.currentPosition--;
            this.setImage();
          }
        }
      }, {
        key: "nextImage",
        value: function nextImage() {
          if (this.currentPosition < this.listOfImages.length - 1) {
            this.currentPosition++;
            this.setImage();
          }
        }
      }, {
        key: "showMenu",
        value: function showMenu(event) {
          this.presentPopover(event);
        }
      }, {
        key: "presentPopover",
        value: function presentPopover(buttonEvent) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            var _this2 = this;

            var popover;
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.popoverController.create({
                      component: _menu_popup_menu_popup_component__WEBPACK_IMPORTED_MODULE_2__["MenuPopupComponent"],
                      event: buttonEvent,
                      translucent: true
                    });

                  case 2:
                    popover = _context.sent;
                    popover.onWillDismiss().then(function (data) {
                      switch (data.data) {
                        case 'electrical':
                          _this2.menuName = 'Electricals';

                          _this2.setImageSource();

                          break;

                        case 'roof':
                          _this2.menuName = 'Roof';
                          _this2.listOfImages = _this2.survey.roofimages;
                          _this2.currentPosition = 0;

                          _this2.setImage();

                          break;

                        default:
                          _this2.menuName = data.data;
                          _this2.listOfImages = _this2.survey[data.data];
                          _this2.currentPosition = 0;

                          _this2.setImage();

                          break;
                      }
                    });
                    _context.next = 6;
                    return popover.present();

                  case 6:
                    return _context.abrupt("return", _context.sent);

                  case 7:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "goBack",
        value: function goBack() {
          this.navController.pop();
        }
      }, {
        key: "setImage",
        value: function setImage() {
          this.image = this.listOfImages[this.currentPosition];
          console.log(this.image);
        }
      }, {
        key: "onTabSelected",
        value: function onTabSelected(event) {
          console.log(event.detail.value);
          this.selectedTab = event.detail.value;
          this.setImageSource();
        }
      }, {
        key: "setImageSource",
        value: function setImageSource() {
          this.listOfImages = this.survey[this.selectedTab];
          this.currentPosition = 0;
          this.setImage();
        }
      }]);

      return GalleryPage;
    }();

    GalleryPage.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["PopoverController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"]
      }, {
        type: _utilities_service__WEBPACK_IMPORTED_MODULE_5__["UtilitiesService"]
      }, {
        type: _api_service__WEBPACK_IMPORTED_MODULE_6__["ApiService"]
      }, {
        type: _ionic_storage__WEBPACK_IMPORTED_MODULE_7__["Storage"]
      }];
    };

    GalleryPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-gallery',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./gallery.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/gallery/gallery.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./gallery.page.scss */
      "./src/app/gallery/gallery.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_3__["PopoverController"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"], _utilities_service__WEBPACK_IMPORTED_MODULE_5__["UtilitiesService"], _api_service__WEBPACK_IMPORTED_MODULE_6__["ApiService"], _ionic_storage__WEBPACK_IMPORTED_MODULE_7__["Storage"]])], GalleryPage);
    /***/
  },

  /***/
  "./src/app/gallery/menu-popup/menu-popup.component.scss":
  /*!**************************************************************!*\
    !*** ./src/app/gallery/menu-popup/menu-popup.component.scss ***!
    \**************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppGalleryMenuPopupMenuPopupComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2dhbGxlcnkvbWVudS1wb3B1cC9tZW51LXBvcHVwLmNvbXBvbmVudC5zY3NzIn0= */";
    /***/
  },

  /***/
  "./src/app/gallery/menu-popup/menu-popup.component.ts":
  /*!************************************************************!*\
    !*** ./src/app/gallery/menu-popup/menu-popup.component.ts ***!
    \************************************************************/

  /*! exports provided: MenuPopupComponent */

  /***/
  function srcAppGalleryMenuPopupMenuPopupComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MenuPopupComponent", function () {
      return MenuPopupComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");

    var MenuPopupComponent = /*#__PURE__*/function () {
      function MenuPopupComponent(popoverController) {
        _classCallCheck(this, MenuPopupComponent);

        this.popoverController = popoverController;
      }

      _createClass(MenuPopupComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "showImages",
        value: function showImages(keyname) {
          this.popoverController.dismiss(keyname);
        }
      }]);

      return MenuPopupComponent;
    }();

    MenuPopupComponent.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["PopoverController"]
      }];
    };

    MenuPopupComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-menu-popup',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./menu-popup.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/gallery/menu-popup/menu-popup.component.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./menu-popup.component.scss */
      "./src/app/gallery/menu-popup/menu-popup.component.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["PopoverController"]])], MenuPopupComponent);
    /***/
  }
}]);
//# sourceMappingURL=gallery-gallery-module-es5.js.map