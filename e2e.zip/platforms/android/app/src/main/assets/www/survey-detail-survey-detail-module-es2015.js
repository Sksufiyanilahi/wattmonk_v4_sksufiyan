(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["survey-detail-survey-detail-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/survey-detail/modal-page/modal-page.component.html":
/*!**********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/survey-detail/modal-page/modal-page.component.html ***!
  \**********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<p>\r\n  modal-page works!\r\n</p>\r\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/survey-detail/survey-detail.page.html":
/*!*********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/survey-detail/survey-detail.page.html ***!
  \*********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header class=\"ion-no-border white-bg\" *ngIf=\"survey\">\r\n    <ion-grid class=\"ion-padding-top ion-padding-start ion-padding-end header-bg\">\r\n        <ion-row>\r\n            <ion-col size=\"2\">\r\n                <ion-button fill=\"clear\" size=\"small\" class=\"ion-no-padding\" (click)=\"goBack()\">\r\n                    <ion-img src=\"/assets/images/back.svg\" class=\"action-icon\"></ion-img>\r\n                </ion-button>\r\n            </ion-col>\r\n            <ion-col size=\"6\" *ngIf=\"iseditable\">\r\n                <ion-button fill=\"clear\" disabled=\"true\" size=\"small\" class=\"ion-no-padding action-icon\">\r\n                </ion-button>\r\n            </ion-col>\r\n            <!-- <ion-col>\r\n                <ion-grid class=\"ion-align-items-center ion-justify-content-center\">\r\n                    <ion-row class=\"ion-align-items-center ion-justify-content-center\">\r\n                        <span class=\"survey-name ion-text-center\">{{survey.name}}</span>\r\n                    </ion-row>\r\n                    <ion-row class=\"ion-align-items-center ion-justify-content-center\">\r\n                        <span class=\"survey-email ion-text-center\">{{survey.email}}</span>\r\n                    </ion-row>\r\n                </ion-grid>\r\n            </ion-col> -->\r\n            <ion-col size=\"2\" *ngIf=\"iseditable\" style=\"text-align: right !important;\">\r\n                <ion-button fill=\"clear\" size=\"small\" class=\"ion-no-padding\"\r\n                            [routerLink]=\"['/schedule/survey/',surveyId]\"\r\n                            routerDirection=\"forward\">\r\n                    <ion-img src=\"/assets/images/edit.svg\" class=\"action-icon\"></ion-img>\r\n                </ion-button>\r\n            </ion-col>\r\n            <ion-col size=\"2\" *ngIf=\"iseditable\">\r\n                <ion-button fill=\"clear\" size=\"small\" class=\"ion-no-padding\" (click)=\"deleteSurvey()\">\r\n                    <ion-img src=\"/assets/images/trash.svg\" class=\"action-icon\"></ion-img>\r\n                </ion-button>\r\n            </ion-col>\r\n            <ion-col size=\"auto\" *ngIf=\"!iseditable\">\r\n                <ion-button fill=\"clear\" disabled=\"true\" size=\"small\" class=\"ion-no-padding action-icon\">\r\n                </ion-button>\r\n            </ion-col>\r\n        </ion-row>\r\n    </ion-grid>\r\n    <ion-grid class=\"position-relative ion-no-padding\">\r\n        <ion-row class=\"ion-no-padding border-header header-half-height\">\r\n        </ion-row>\r\n        <ion-row class=\"ion-no-padding header-half-height\">\r\n\r\n        </ion-row>\r\n        <ion-row class=\"ion-no-padding position-absolute header-icon-position full-width\">\r\n            <ion-col class=\"flex-center\">\r\n                <ion-img src=\"/assets/images/survey.svg\" class=\"header-icon\"></ion-img>\r\n            </ion-col>\r\n        </ion-row>\r\n    </ion-grid>\r\n</ion-header>\r\n\r\n<ion-content class=\"ion-padding page-text-color\" *ngIf='survey' >\r\n    <!-- <ion-grid fixed> -->\r\n        <!-- <ion-row> -->\r\n            <!-- <ion-col> -->\r\n                <ion-segment scrollable [(ngModel)]=\"segments\" class=\"wd140 colorwht\" *ngIf='survey.status !==\"surveyassigned\"'>\r\n                <ion-segment-button value=\"SiteDetils\" class=\"wd140 colorwht\"> \r\n                    <ion-label>\r\n                        Site Details\r\n                    </ion-label>\r\n                </ion-segment-button>\r\n                <ion-segment-button value=\"electricals\" class=\"wd140 colorwht\">\r\n                    <ion-label>\r\n                        Electrical\r\n                    </ion-label>\r\n                </ion-segment-button>\r\n                <ion-segment-button value=\"solarPanel\" class=\"wd140 colorwht\">\r\n                    <ion-label>\r\n                        Solar Panel\r\n                    </ion-label>\r\n                </ion-segment-button>\r\n                <ion-segment-button value=\"roof\" class=\"wd140 colorwht\">\r\n                    <ion-label>\r\n                        Roof\r\n                    </ion-label>\r\n                </ion-segment-button>\r\n                <ion-segment-button value=\"appliances\" class=\"wd140 colorwht\">\r\n                    <ion-label>\r\n                        Appliances\r\n                    </ion-label>\r\n                </ion-segment-button>\r\n                <ion-segment-button value=\"equipmentMarketing\" class=\"wd140 colorwht\">\r\n                    <ion-label style=\"width:100%\">\r\n                        Equipment Marking\r\n                    </ion-label>\r\n                </ion-segment-button>\r\n                <ion-segment-button value=\"generalInfo\" class=\"wd140 colorwht\">\r\n                    <ion-label>\r\n                        General information\r\n                    </ion-label>\r\n                </ion-segment-button>\r\n                </ion-segment>\r\n                <div [ngSwitch]=\"segments\">\r\n                    <ion-grid *ngSwitchCase=\"'SiteDetils'\">\r\n                        <ion-row class=\"bkg\">\r\n                            <ion-col class=\"hgt-margin\">\r\n                                <!-- <ion-item> -->\r\n                                    <label>Customer Details</label>\r\n                                <!-- </ion-item> -->\r\n                            </ion-col>\r\n                        </ion-row>\r\n                        <ion-row>\r\n                            <ion-col size=\"6\">Name</ion-col>\r\n                            <ion-col size=\"6\">{{survey.name}}</ion-col>\r\n                        </ion-row>\r\n                        <ion-row>\r\n                            <ion-col size=\"6\">Address</ion-col>\r\n                            <ion-col size=\"6\">{{survey.address}}</ion-col>\r\n                        </ion-row>\r\n                        <ion-row>\r\n                            <ion-col size=\"6\">Email</ion-col>\r\n                            <ion-col size=\"6\">{{survey.email}}</ion-col>\r\n                        </ion-row>\r\n    \r\n                        <ion-row class=\"bkg\">\r\n                            <ion-col class=\"hgt-margin\">\r\n                                <!-- <ion-item> -->\r\n                                    <label>Job Details</label>\r\n                                <!-- </ion-item> -->\r\n                            </ion-col>\r\n                        </ion-row>\r\n                        <ion-row>\r\n                            <ion-col size=\"6\">Job</ion-col>\r\n                            <ion-col size=\"6\">{{survey.jobtype}}</ion-col>\r\n                        </ion-row>\r\n                        <ion-row>\r\n                            <ion-col size=\"6\">Scheduled On</ion-col>\r\n                            <ion-col size=\"6\">{{survey.created_at | date:'dd/MM/yyyy'}}</ion-col>\r\n                        </ion-row>\r\n               \r\n                        <ion-row class=\"bkg\">\r\n                            <ion-col class=\"hgt-margin\">\r\n                                <!-- <ion-item> -->\r\n                                    <label>Comments</label>\r\n                                <!-- </ion-item> -->\r\n                            </ion-col>\r\n                        </ion-row>\r\n                        <ion-row  *ngFor=\"let comments of survey.comments\">\r\n                            <ion-col>{{comments.message}}</ion-col>\r\n                            <!-- <ion-col style=\"text-align: right;\">{{comments.createdBy.firstname}} &nbsp;{{comments.createdBy.lastname}} </ion-col>\r\n                            <ion-col style=\"text-align: right;\">{{comments.createdBy.updated_at | date:'dd/MM/yyyy'}}</ion-col> -->\r\n                        </ion-row>\r\n               \r\n                        <ion-row class=\"bkg\">\r\n                            <ion-col class=\"hgt-margin\">\r\n                                <!-- <ion-item> -->\r\n                                    <label>Assignee Details</label>\r\n                                <!-- </ion-item> -->\r\n                            </ion-col>\r\n                        </ion-row>\r\n                        <ion-row>\r\n                            <ion-col size=\"6\">Assigned To</ion-col>\r\n                            <ion-col size=\"6\">{{survey.assignedto?.firstname}} &nbsp; {{survey.assignedto?.lastname}}</ion-col>\r\n                        </ion-row>\r\n                    </ion-grid>\r\n                    \r\n                   <ion-grid *ngSwitchCase=\"'electricals'\">\r\n                    <ion-row>\r\n                        <ion-col>\r\n                            <ion-segment scrollable [(ngModel)]=\"electricals\" class=\"segment-btn\">\r\n                                <ion-segment-button class=\"wd140\" value=\"MSB\">\r\n                                    <ion-label>MSP</ion-label>\r\n                                </ion-segment-button>\r\n                                <ion-segment-button value=\"utilityMeter\" class=\"wd140\">\r\n                                    <ion-label>Utility Meter</ion-label>\r\n                                </ion-segment-button>\r\n                                <ion-segment-button value=\"pvMeter\" class=\"wd140\">\r\n                                    <ion-label>PV Inverter</ion-label>\r\n                                </ion-segment-button>\r\n                                <ion-segment-button value=\"acDisconnect\" class=\"wd140\">\r\n                                    <ion-label>AC Disconnected</ion-label>\r\n                                </ion-segment-button>\r\n                            </ion-segment>\r\n                        </ion-col>\r\n                    </ion-row>\r\n                            <div [ngSwitch]=\"electricals\">\r\n                                <div *ngSwitchCase=\"'MSB'\">\r\n                                    <ion-slides pager=\"true\" zoom [options]=\"slideOpts\" class=\"image-slider\">\r\n                                        <ion-slide *ngFor=\"let elecmsb of survey.mspimages\">\r\n                                            <div class=\"swiper-zoom-container\">\r\n                                                <img [src]=\"elecmsb.url\" />\r\n                                            </div>\r\n                                        </ion-slide>\r\n                                    </ion-slides>\r\n                                </div>\r\n                                <div *ngSwitchCase=\"'utilityMeter'\">\r\n                                    <ion-slides pager=\"true\" [options]=\"slideOpts\" zoom=\"true\">\r\n                                        <ion-slide *ngFor=\"let elecutility of survey.utilitymeterimages\">\r\n                                            <div class=\"swiper-zoom-container\">\r\n                                                <img [src]=\"elecutility.url\" width='100%'/>\r\n                                            </div>\r\n                                        </ion-slide>\r\n                                    </ion-slides>\r\n                                </div>\r\n                                <div *ngSwitchCase=\"'pvMeter'\">\r\n                                    <ion-slides pager=\"true\" [options]=\"slideOpts\" zom=\"true\">\r\n                                        <ion-slide *ngFor=\"let elecpvmeter of survey.pvmeterimages\">\r\n                                            <div class=\"swiper-zoom-container\">\r\n                                                <img [src]=\"elecpvmeter.url\" width='100%'/>\r\n                                            </div>\r\n                                        </ion-slide>\r\n                                    </ion-slides>\r\n                                </div>\r\n                                <div *ngSwitchCase=\"'acDisconnect'\">\r\n                                    <ion-slides pager=\"true\" [options]=\"slideOpts\" zoom=\"true\">\r\n                                        <ion-slide *ngFor=\"let elecacdisconnect of survey.acdisconnectimages\">\r\n                                            <div class=\"swiper-zoom-container\">\r\n                                                <img [src]=\"elecacdisconnect.url\" width='100%'/>\r\n                                            </div>\r\n\r\n                                        </ion-slide>\r\n                                    </ion-slides>\r\n                                </div>\r\n                            </div>\r\n                     \r\n                 </ion-grid>\r\n                   <ion-grid *ngSwitchCase=\"'solarPanel'\">\r\n                    <ion-slides pager=\"true\" [options]=\"slideOpts\" zoom=\"true\">\r\n                        <ion-slide *ngFor=\"let solarpanel of survey.solarpanelsimages\">\r\n                            <div class=\"swiper-zoom-container\">\r\n                            <h2 class=\"position-fix\">{{solarpanel.name}}</h2>\r\n                                <img [src]=\"solarpanel.url\" />\r\n                            </div>\r\n                        </ion-slide>\r\n                    </ion-slides>\r\n                 </ion-grid>\r\n                   <ion-grid *ngSwitchCase=\"'roof'\">\r\n                    <ion-slides pager=\"true\" [options]=\"slideOpts\" zoom=\"true\">\r\n                        <ion-slide *ngFor=\"let roof of survey.roofimages\">\r\n                            <div class=\"swiper-zoom-container\">\r\n                                <h2 class=\"position-fix\">{{roof.name}}</h2>\r\n                                <img [src]=\"roof.url\" />\r\n                            </div>\r\n\r\n                        </ion-slide>\r\n                    </ion-slides>\r\n                 </ion-grid>\r\n                   <ion-grid *ngSwitchCase=\"'appliances'\">\r\n                    <ion-slides pager=\"true\" [options]=\"slideOpts\" zoom=\"true\">\r\n                        <ion-slide *ngFor=\"let appliance of survey.appliancesimages\">\r\n                            <div class=\"swiper-zoom-container\">\r\n                                <h2 class=\"position-fix\">{{appliance.name}}</h2>\r\n                                <img [src]=\"appliance.url\" />\r\n                            </div>\r\n                        </ion-slide>\r\n                    </ion-slides>\r\n                 </ion-grid>\r\n                   <ion-grid *ngSwitchCase=\"'equipmentMarketing'\">\r\n                    \r\n                 </ion-grid>\r\n                   <ion-grid *ngSwitchCase=\"'generalInfo'\">\r\n                    <ion-row class=\"bkg\">\r\n                        <ion-col class=\"hgt-margin\">\r\n                            <!-- <ion-item> -->\r\n                                <label>Details</label>\r\n                            <!-- </ion-item> -->\r\n                        </ion-col>\r\n                    </ion-row>\r\n                    <ion-row>\r\n                        <ion-col size=\"6\">Existing Modules Brand</ion-col>\r\n                        <ion-col size=\"6\">{{survey.modulemake.name}}</ion-col>\r\n                    </ion-row>\r\n                    <ion-row>\r\n                        <ion-col size=\"6\">Existing Modules Model</ion-col>\r\n                        <ion-col size=\"6\">{{survey.modulemodel.name}}</ion-col>\r\n                    </ion-row>\r\n                    <ion-row>\r\n                        <ion-col size=\"6\">Battery Backup</ion-col>\r\n                        <ion-col size=\"6\">{{survey.batterybackup}}</ion-col>\r\n                    </ion-row>\r\n                    <ion-row>\r\n                        <ion-col size=\"6\">Interconnection</ion-col>\r\n                        <ion-col size=\"6\">{{survey.interconnection}}</ion-col>\r\n                    </ion-row>\r\n                    <ion-row>\r\n                        <ion-col size=\"6\">Service Feed Source</ion-col>\r\n                        <ion-col size=\"6\">{{survey.servicefeedsource}}</ion-col>\r\n                    </ion-row>\r\n                    \r\n                 </ion-grid>\r\n                </div>\r\n                <!-- <ion-content [fullscreen]=\"true\" class=\"ion-padding\"> -->\r\n              \r\n\r\n                <!-- </ion-content> -->\r\n            <!-- </ion-col> -->\r\n        <!-- </ion-row> -->\r\n    <!-- </ion-grid> -->\r\n    <!-- <ion-grid *ngIf=\"survey\" class=\"page-text-color\">\r\n        <ion-row>\r\n            <ion-col size=\"12\">\r\n                <span (click)=\"openAddressOnMap(survey.address)\" class=\"address\">{{survey.address}}</span>\r\n            </ion-col>\r\n        </ion-row>\r\n        <ion-row class=\"ion-margin-top\">\r\n            <ion-col size=\"12\">\r\n                <span class=\"input-placeholder\">date and time</span>\r\n            </ion-col>\r\n            <ion-col>\r\n                <div class=\"d-flex\">\r\n                    <div class=\"d-flex flex-column\">\r\n                        <div class=\"main-background d-flex flex-row align-center justify-center\">\r\n                            <div class=\"d-flex flex-column align-center justify-center ion-padding date-background\">\r\n                                <span class=\"month\">{{survey.datetime | date: 'MMM'}}</span>\r\n                                <span class=\"day\">{{survey.datetime | date: 'dd'}}</span>\r\n                            </div>\r\n                            <div class=\"ion-padding\">\r\n                                <span class=\"time\">{{survey.datetime | date: 'hh : mm a'}}</span>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n            </ion-col>\r\n            <ion-col size=\"auto\" *ngIf=\"iseditable\">\r\n                <div class=\"d-flex flex-column align-center justify-center\" (click)=\"reschedule()\">\r\n                    <ion-img src=\"/assets/images/schedule.svg\" class=\"reschedule-icon\"></ion-img>\r\n                    <span>Reschedule</span>\r\n                </div>\r\n            </ion-col>\r\n        </ion-row>\r\n\r\n        <ion-row class=\"ion-no-padding\">\r\n            <ion-col><span class=\"model-type\">jobtype</span></ion-col>\r\n            <ion-col size=\"auto\">\r\n                <span class=\"model-name\">{{survey.jobtype}}</span>\r\n            </ion-col>\r\n        </ion-row>\r\n\r\n        <ion-row class=\"ion-margin-top\">\r\n            <ion-col size=\"12\">\r\n                <span class=\"models\">Solar Details</span>\r\n            </ion-col>\r\n            <ion-col>\r\n                <ion-grid class=\"ion-no-padding\">\r\n                    <ion-row class=\"ion-no-padding\">\r\n                        <ion-col><span class=\"model-type\">make</span></ion-col>\r\n                        <ion-col size=\"auto\">\r\n                            <span class=\"model-name\" *ngIf=\"survey.modulemake\">{{survey.modulemake.name}}</span>\r\n                            <span class=\"model-name\" *ngIf=\"!survey.modulemake\">n/a</span>\r\n                        </ion-col>\r\n                    </ion-row>\r\n                    <ion-row>\r\n                        <ion-col><span class=\"model-type\">model</span></ion-col>\r\n                        <ion-col size=\"auto\">\r\n                            <span class=\"model-name\" *ngIf=\"survey.modulemodel\">{{survey.modulemodel.name}}</span>\r\n                            <span class=\"model-name\" *ngIf=\"!survey.modulemodel\">n/a</span>\r\n                        </ion-col>\r\n                    </ion-row>\r\n                </ion-grid>\r\n            </ion-col>\r\n        </ion-row>\r\n\r\n        <ion-row class=\"ion-margin-top\">\r\n            <ion-col size=\"12\">\r\n                <span class=\"models\">Inverter Details</span>\r\n            </ion-col>\r\n            <ion-col>\r\n                <ion-grid class=\"ion-no-padding\">\r\n                    <ion-row class=\"ion-no-padding\">\r\n                        <ion-col><span class=\"model-type\">make</span></ion-col>\r\n                        <ion-col size=\"auto\">\r\n                            <span class=\"model-name\" *ngIf=\"survey.invertermake\">{{survey.invertermake}}</span>\r\n                            <span class=\"model-name\" *ngIf=\"!survey.invertermake\">n/a</span>\r\n                        </ion-col>\r\n                    </ion-row>\r\n                    <ion-row>\r\n                        <ion-col><span class=\"model-type\">model</span></ion-col>\r\n                        <ion-col size=\"auto\">\r\n                            <span class=\"model-name\" *ngIf=\"survey.invertermodel\">{{survey.invertermodel}}</span>\r\n                            <span class=\"model-name\" *ngIf=\"!survey.invertermodel\">n/a</span>\r\n                        </ion-col>\r\n                    </ion-row>\r\n                </ion-grid>\r\n            </ion-col>\r\n        </ion-row>\r\n\r\n        <ion-row class=\"ion-margin-top\">\r\n            <ion-col>\r\n                <ion-grid class=\"ion-no-padding\">\r\n                    <ion-row class=\"ion-no-padding\">\r\n                        <ion-col><span class=\"model-type\">utility</span></ion-col>\r\n                        <ion-col size=\"auto\">\r\n                            <span class=\"model-name\" *ngIf=\"survey.utility\">{{survey.utility.name}}</span>\r\n                            <span class=\"model-name\" *ngIf=\"!survey.utility\">n/a</span>\r\n                        </ion-col>\r\n                    </ion-row>\r\n                    <ion-row class=\"ion-no-padding\">\r\n                        <ion-col><span class=\"model-type\">msp location</span></ion-col>\r\n                        <ion-col size=\"auto\">\r\n                            <span class=\"model-name\" *ngIf=\"survey.msplocation\">{{survey.msplocation}}</span>\r\n                            <span class=\"model-name\" *ngIf=\"!survey.msplocation\">n/a</span>\r\n                        </ion-col>\r\n                    </ion-row>\r\n                    <ion-row>\r\n                        <ion-col><span class=\"model-type\">msp breaker</span></ion-col>\r\n                        <ion-col size=\"auto\">\r\n                            <span class=\"model-name\" *ngIf=\"survey.mspbreaker\">{{survey.mspbreaker}}</span>\r\n                            <span class=\"model-name\" *ngIf=\"!survey.mspbreaker\">n/a</span>\r\n                        </ion-col>\r\n                    </ion-row>\r\n                    <ion-row>\r\n                        <ion-col><span class=\"model-type\">msp rating</span></ion-col>\r\n                        <ion-col size=\"auto\">\r\n                            <span class=\"model-name\" *ngIf=\"survey.msprating\">{{survey.msprating}}</span>\r\n                            <span class=\"model-name\" *ngIf=\"!survey.msprating\">n/a</span>\r\n                        </ion-col>\r\n                    </ion-row>\r\n                    <ion-row>\r\n                        <ion-col><span class=\"model-type\">main breaker size</span></ion-col>\r\n                        <ion-col size=\"auto\">\r\n                            <span class=\"model-name\" *ngIf=\"survey.mainbreakersize\">{{survey.mainbreakersize}}</span>\r\n                            <span class=\"model-name\" *ngIf=\"!survey.mainbreakersize\">n/a</span>\r\n                        </ion-col>\r\n                    </ion-row>\r\n                </ion-grid>\r\n            </ion-col>\r\n        </ion-row>\r\n\r\n        <ion-row class=\"ion-margin-top\">\r\n            <ion-col>\r\n                <ion-grid class=\"ion-no-padding\">\r\n                    <ion-row class=\"ion-no-padding\">\r\n                        <ion-col><span class=\"model-type\">pv meter</span></ion-col>\r\n                        <ion-col size=\"auto\">\r\n                            <span class=\"model-name\" *ngIf=\"survey.pvmeter\">{{survey.pvmeter}}</span>\r\n                            <span class=\"model-name\" *ngIf=\"!survey.pvmeter\">n/a</span>\r\n                        </ion-col>\r\n                    </ion-row>\r\n                    <ion-row>\r\n                        <ion-col><span class=\"model-type\">pv inverter location</span></ion-col>\r\n                        <ion-col size=\"auto\">\r\n                            <span class=\"model-name\"\r\n                                  *ngIf=\"survey.pvinverterlocation\">{{survey.pvinverterlocation}}</span>\r\n                            <span class=\"model-name\" *ngIf=\"!survey.pvinverterlocation\">n/a</span>\r\n                        </ion-col>\r\n                    </ion-row>\r\n                </ion-grid>\r\n            </ion-col>\r\n        </ion-row>\r\n\r\n        <ion-row class=\"ion-margin-top\">\r\n            <ion-col>\r\n                <ion-grid class=\"ion-no-padding\">\r\n                    <ion-row class=\"ion-no-padding\">\r\n                        <ion-col><span class=\"model-type\">utility meter</span></ion-col>\r\n                        <ion-col size=\"auto\">\r\n                            <span class=\"model-name\" *ngIf=\"survey.utilitymeter\">{{survey.utilitymeter}}</span>\r\n                            <span class=\"model-name\" *ngIf=\"!survey.utilitymeter\">n/a</span>\r\n                        </ion-col>\r\n                    </ion-row>\r\n                    <ion-row>\r\n                        <ion-col><span class=\"model-type\">ac disconnect</span></ion-col>\r\n                        <ion-col size=\"auto\">\r\n                            <span class=\"model-name\" *ngIf=\"survey.acdisconnect\">{{survey.acdisconnect}}</span>\r\n                            <span class=\"model-name\" *ngIf=\"!survey.acdisconnect\">n/a</span>\r\n                        </ion-col>\r\n                    </ion-row>\r\n                    <ion-row>\r\n                        <ion-col><span class=\"model-type\">no of modules</span></ion-col>\r\n                        <ion-col size=\"auto\">\r\n                            <span class=\"model-name\" *ngIf=\"survey.numberofmodules\">{{survey.numberofmodules}}</span>\r\n                            <span class=\"model-name\" *ngIf=\"!survey.numberofmodules\">n/a</span>\r\n                        </ion-col>\r\n                    </ion-row>\r\n                    <ion-row>\r\n                        <ion-col><span class=\"model-type\">service feed source</span></ion-col>\r\n                        <ion-col size=\"auto\">\r\n                            <span class=\"model-name\"\r\n                                  *ngIf=\"survey.servicefeedsource\">{{survey.servicefeedsource}}</span>\r\n                            <span class=\"model-name\" *ngIf=\"!survey.servicefeedsource\">n/a</span>\r\n                        </ion-col>\r\n                    </ion-row>\r\n                    <ion-row>\r\n                        <ion-col><span class=\"model-type\">service feed source</span></ion-col>\r\n                        <ion-col size=\"auto\">\r\n                            <span class=\"model-name\"\r\n                                  *ngIf=\"survey.interconnection\">{{survey.interconnection}}</span>\r\n                            <span class=\"model-name\" *ngIf=\"!survey.interconnection\">n/a</span>\r\n                        </ion-col>\r\n                    </ion-row>\r\n\r\n                </ion-grid>\r\n            </ion-col>\r\n        </ion-row>\r\n\r\n\r\n        <ion-row class=\"ion-align-items-center ion-justify-content-center ion-margin-top\">\r\n            <ion-col class=\"ion-no-padding\">\r\n                <span class=\"data-header\">gallery</span>\r\n            </ion-col>\r\n            <ion-col size=\"auto\" [routerLink]=\"['/gallery/', surveyId]\"\r\n                     routerDirection=\"forward\">\r\n                <span>View all</span>\r\n            </ion-col>\r\n            <ion-col class=\"ion-align-items-center d-flex\" size=\"12\">\r\n                <img src=\"/assets/images/images.svg\" class=\"image-count\">\r\n                <span>{{getSurveyImages()}} images</span>\r\n            </ion-col>\r\n        </ion-row>\r\n\r\n        <ion-row class=\"ion-no-padding ion-margin-top\">\r\n            <ion-col size=\"12\" class=\"ion-no-padding\">\r\n                <span class=\"data-header\">comments</span>\r\n            </ion-col>\r\n            <ion-col size=\"12\" class=\"ion-no-padding\">\r\n                <span class=\"data-point\">\"{{survey.comments}}\"</span>\r\n            </ion-col>\r\n            <ion-col size=\"12\" class=\"ion-no-padding ion-text-end\">\r\n                <span class=\"comment-by\">Posted by {{survey.createdby.firstname}} {{survey.createdby.lastname}}</span>\r\n            </ion-col>\r\n        </ion-row>\r\n\r\n        <ion-row>\r\n            <ion-col><span class=\"model-type\">created at</span></ion-col>\r\n            <ion-col size=\"auto\">\r\n                <span class=\"model-name\">{{survey.created_at | date: 'dd/MM/yyyy hh:mm a'}}</span>\r\n            </ion-col>\r\n        </ion-row>\r\n\r\n        <ion-row class=\"ion-no-padding ion-margin-top ion-justify-content-center ion-align-items-center\"\r\n                 *ngIf=\"assigned\">\r\n            <ion-col class=\"ion-justify-content-center ion-align-items-center\"><span\r\n                    class=\"model-type\">assigned to</span></ion-col>\r\n            <ion-col size=\"auto\">\r\n                <div class=\"selected d-flex\">\r\n                    <img *ngIf=\"survey.assignedto.contractorlogo && survey.assignedto.contractorlogo.logo\" [src]=\"survey.assignedto.contractorlogo.logo.url\"\r\n                         class=\"assignee-image\"/>\r\n                    <div *ngIf=\"!survey.assignedto.contractorlogo || !survey.assignedto.contractorlogo.logo\"\r\n                         class=\"assignee-image d-flex flex-row align-center justify-center\">\r\n                        <div class=\"name_div\">\r\n                            <span style=\"text-transform: capitalize;\">{{survey.assignedto.firstname.substring(0, 1)}}{{survey.assignedto.lastname.substring(0, 1)}}</span>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n            </ion-col>\r\n        </ion-row>\r\n\r\n        <ion-row class=\"ion-no-padding ion-margin-top\" *ngIf=\"!assigned\">\r\n            <ion-col size=\"12\">\r\n                <form novalidate [formGroup]=\"assigneeForm\">\r\n                    <ion-item class=\"ion-no-padding no-border\" lines=\"none\">\r\n                        <app-user-selector placeholder=\"assign\" [assignees]=\"listOfAssignees\"\r\n                                           formControlName=\"assignto\"></app-user-selector>\r\n                    </ion-item>\r\n                </form>\r\n            </ion-col>\r\n        </ion-row>\r\n\r\n    </ion-grid> -->\r\n</ion-content>\r\n\r\n<!-- <ion-footer *ngIf=\"!assigned && survey\" class=\"ion-no-border white-bg\">\r\n    <ion-grid>\r\n        <ion-row class=\"ion-text-end ion-align-items-end ion-justify-content-end\">\r\n            <ion-col size=\"auto\">\r\n                <ion-button class=\"action-button-color\" fill=\"clear\" (click)=\"updateAssignee()\">Done</ion-button>\r\n            </ion-col>\r\n        </ion-row>\r\n    </ion-grid>\r\n\r\n</ion-footer> -->\r\n\r\n<!-- <ion-bottom-drawer [(state)]=\"drawerState\" minimumHeight=\"0\" dockedHeight=\"300\" draggable=\"false\" disableDrag=\"true\"\r\n                   shouldBounce=\"false\" distanceTop=\"0\" class=\"drawer\">\r\n    <form [formGroup]=\"rescheduleForm\">\r\n        <ion-grid class=\"drawer\">\r\n            <ion-row>\r\n                <ion-col size=\"12\">\r\n                    <span>date and time</span>\r\n                </ion-col>\r\n                <ion-col *ngIf=\"survey\" size=\"auto\">\r\n                    <ion-item lines=\"none\" class=\"date-picker\" (click)=\"changeDate()\">\r\n                        {{date | date: 'dd MMM'}}\r\n                    </ion-item>\r\n                </ion-col>\r\n                <ion-col *ngIf=\"survey\" size=\"auto\">\r\n                    <ion-item lines=\"none\" class=\"date-picker\" (click)=\"changeTime()\">\r\n                        {{date | date: 'hh:mm a'}}\r\n                    </ion-item>\r\n                </ion-col>\r\n            </ion-row>\r\n\r\n            <ion-row>\r\n                <ion-col size=\"12\">\r\n                    <span>comments</span>\r\n                </ion-col>\r\n                <ion-col size=\"12\">\r\n                    <ion-textarea class=\"ion-no-margin ion-no-padding comment_box\" formControlName=\"comments\"\r\n                                  rows=\"3\"></ion-textarea>\r\n                </ion-col>\r\n            </ion-row>\r\n\r\n            <ion-row>\r\n                <ion-col size=\"auto\">\r\n                    <ion-button class=\"buttom-drawer-button\" (click)=\"rescheduleSurvey()\">\r\n                        Confirm\r\n                    </ion-button>\r\n                </ion-col>\r\n                <ion-col size=\"auto\">\r\n                    <ion-button class=\"buttom-drawer-button-cancel\" fill=\"clear\" (click)=\"dismissBottomSheet()\">\r\n                        Cancel\r\n                    </ion-button>\r\n                </ion-col>\r\n            </ion-row>\r\n        </ion-grid>\r\n    </form>\r\n\r\n</ion-bottom-drawer> -->\r\n\r\n");

/***/ }),

/***/ "./src/app/survey-detail/modal-page/modal-page.component.scss":
/*!********************************************************************!*\
  !*** ./src/app/survey-detail/modal-page/modal-page.component.scss ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".modal-wrapper.sc-ion-modal-ios {\n  height: 100% !important;\n  width: 100% !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc3VydmV5LWRldGFpbC9tb2RhbC1wYWdlL0Y6XFxtb2JpbGVhcHAvc3JjXFxhcHBcXHN1cnZleS1kZXRhaWxcXG1vZGFsLXBhZ2VcXG1vZGFsLXBhZ2UuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL3N1cnZleS1kZXRhaWwvbW9kYWwtcGFnZS9tb2RhbC1wYWdlLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksdUJBQUE7RUFDQSxzQkFBQTtBQ0NKIiwiZmlsZSI6InNyYy9hcHAvc3VydmV5LWRldGFpbC9tb2RhbC1wYWdlL21vZGFsLXBhZ2UuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubW9kYWwtd3JhcHBlci5zYy1pb24tbW9kYWwtaW9zIHtcclxuICAgIGhlaWdodDoxMDAlICFpbXBvcnRhbnQ7XHJcbiAgICB3aWR0aDoxMDAlICFpbXBvcnRhbnQ7XHJcbn0iLCIubW9kYWwtd3JhcHBlci5zYy1pb24tbW9kYWwtaW9zIHtcbiAgaGVpZ2h0OiAxMDAlICFpbXBvcnRhbnQ7XG4gIHdpZHRoOiAxMDAlICFpbXBvcnRhbnQ7XG59Il19 */");

/***/ }),

/***/ "./src/app/survey-detail/modal-page/modal-page.component.ts":
/*!******************************************************************!*\
  !*** ./src/app/survey-detail/modal-page/modal-page.component.ts ***!
  \******************************************************************/
/*! exports provided: ModalPageComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ModalPageComponent", function() { return ModalPageComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");



let ModalPageComponent = class ModalPageComponent {
    constructor(navParam) {
        this.navParam = navParam;
    }
    ngOnInit() {
        let image = this.navParam.get('image_url');
        console.log(image);
    }
};
ModalPageComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavParams"] }
];
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], ModalPageComponent.prototype, "image_url", void 0);
ModalPageComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-modal-page',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./modal-page.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/survey-detail/modal-page/modal-page.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./modal-page.component.scss */ "./src/app/survey-detail/modal-page/modal-page.component.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavParams"]])
], ModalPageComponent);



/***/ }),

/***/ "./src/app/survey-detail/survey-detail-routing.module.ts":
/*!***************************************************************!*\
  !*** ./src/app/survey-detail/survey-detail-routing.module.ts ***!
  \***************************************************************/
/*! exports provided: SurveyDetailPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SurveyDetailPageRoutingModule", function() { return SurveyDetailPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _survey_detail_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./survey-detail.page */ "./src/app/survey-detail/survey-detail.page.ts");




const routes = [
    {
        path: '',
        component: _survey_detail_page__WEBPACK_IMPORTED_MODULE_3__["SurveyDetailPage"]
    }
];
let SurveyDetailPageRoutingModule = class SurveyDetailPageRoutingModule {
};
SurveyDetailPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], SurveyDetailPageRoutingModule);



/***/ }),

/***/ "./src/app/survey-detail/survey-detail.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/survey-detail/survey-detail.module.ts ***!
  \*******************************************************/
/*! exports provided: SurveyDetailPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SurveyDetailPageModule", function() { return SurveyDetailPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _survey_detail_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./survey-detail-routing.module */ "./src/app/survey-detail/survey-detail-routing.module.ts");
/* harmony import */ var _survey_detail_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./survey-detail.page */ "./src/app/survey-detail/survey-detail.page.ts");
/* harmony import */ var ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ion-bottom-drawer */ "./node_modules/ion-bottom-drawer/fesm2015/ion-bottom-drawer.js");
/* harmony import */ var _utilities_utilities_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../utilities/utilities.module */ "./src/app/utilities/utilities.module.ts");
/* harmony import */ var _ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic-native/launch-navigator/ngx */ "./node_modules/@ionic-native/launch-navigator/ngx/index.js");
/* harmony import */ var _modal_page_modal_page_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./modal-page/modal-page.component */ "./src/app/survey-detail/modal-page/modal-page.component.ts");











let SurveyDetailPageModule = class SurveyDetailPageModule {
};
SurveyDetailPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_7__["IonBottomDrawerModule"],
            _survey_detail_routing_module__WEBPACK_IMPORTED_MODULE_5__["SurveyDetailPageRoutingModule"],
            _utilities_utilities_module__WEBPACK_IMPORTED_MODULE_8__["UtilitiesModule"]
        ],
        declarations: [_survey_detail_page__WEBPACK_IMPORTED_MODULE_6__["SurveyDetailPage"], _modal_page_modal_page_component__WEBPACK_IMPORTED_MODULE_10__["ModalPageComponent"]],
        providers: [
            _ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_9__["LaunchNavigator"]
        ],
        entryComponents: [_modal_page_modal_page_component__WEBPACK_IMPORTED_MODULE_10__["ModalPageComponent"]],
    })
], SurveyDetailPageModule);



/***/ }),

/***/ "./src/app/survey-detail/survey-detail.page.scss":
/*!*******************************************************!*\
  !*** ./src/app/survey-detail/survey-detail.page.scss ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".survey-email {\n  font-size: 0.8em;\n}\n\n.survey-name {\n  font-size: 1.7em;\n}\n\n.survey-phone {\n  font-size: 0.8em;\n}\n\nion-header {\n  color: #666666;\n}\n\n.image-count {\n  width: 48px;\n  height: 48px;\n}\n\n.data-header {\n  font-size: 0.9em;\n  color: #BFBFBF;\n}\n\n.data-point {\n  font-size: 1em;\n  color: black;\n}\n\n.address {\n  color: #3a7be0;\n}\n\n.comment-by {\n  font-size: 10px;\n  font-style: italic;\n  color: #666666 !important;\n}\n\n.main-background {\n  background: #EFEFEF;\n  border-radius: 0.5em;\n  color: #656565;\n}\n\n.date-background {\n  width: 4em;\n  height: 4em;\n  background: #3c78d8;\n  border-radius: 0.5em;\n  color: white;\n}\n\n.month {\n  font-size: 1em;\n}\n\n.day {\n  font-size: 1.5em;\n  font-weight: bold;\n}\n\n.time {\n  font-size: 1.5em;\n  font-weight: bold;\n}\n\n.reschedule-icon {\n  width: 48px;\n  height: 48px;\n}\n\n.assignee-image {\n  width: 3.5em;\n  height: 3.5em;\n  border-radius: 50%;\n  -o-object-fit: fill;\n     object-fit: fill;\n  border: 2px solid white;\n  padding: 8px;\n  text-align: center;\n  background: #FFF1CF;\n}\n\n.assignee-margin {\n  margin: 8px;\n}\n\n.selected {\n  border: 3px solid #3c78d8;\n  border-radius: 50%;\n}\n\n.normal {\n  border: 3px solid white;\n}\n\ndiv[scrollx=true], div[scrolly=true] {\n  position: relative;\n  overflow: hidden;\n}\n\ndiv[scrollx=true] ::-webkit-scrollbar, div[scrolly=true] ::-webkit-scrollbar {\n  display: none;\n}\n\ndiv[scrollx=true] {\n  overflow-x: auto;\n}\n\ndiv[scrolly=true] {\n  overflow-y: auto;\n}\n\n.date-picker {\n  --background: #E1E1E1;\n  --border: 2px solid #666666;\n}\n\n.picker-button {\n  --background: #3c78d8;\n  --color: white;\n}\n\n.name_div {\n  font-size: 20px;\n}\n\n.page-text-color {\n  color: #666666 !important;\n}\n\n.segments {\n  height: 40px;\n}\n\nion-segment-button {\n  width: calc(100% / 4);\n}\n\nion-segment-button ion-label {\n  max-width: calc(90vw / 4);\n}\n\n.bkg {\n  color: #666;\n  background-color: #f9f9f9;\n}\n\nion-slides {\n  height: 100%;\n}\n\n.position-fix {\n  position: absolute;\n  z-index: 999;\n  transform: translateY(-1000%);\n}\n\n.segment-btn {\n  background: blue !important;\n  color: #fff !important;\n}\n\n.wd140 {\n  min-width: auto;\n  max-width: 100%;\n  width: auto !important;\n  color: #fff;\n}\n\n.wd140 ion-label {\n  width: auto !important;\n  max-width: 100%;\n}\n\n.colorwht {\n  color: #111 !important;\n  background: #fff !important;\n}\n\nmain inner-scroll scroll-y {\n  padding: 0px !important;\n}\n\nion-slides {\n  padding: 0px !important;\n}\n\nion-content main {\n  padding: 0px !important;\n}\n\nbutton {\n  background: blue !important;\n}\n\n.hgt-margin {\n  height: 39px;\n  margin-top: 10px;\n}\n\nion-grid {\n  padding: 0px !important;\n}\n\nion-content main {\n  padding: 0px !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc3VydmV5LWRldGFpbC9GOlxcbW9iaWxlYXBwL3NyY1xcYXBwXFxzdXJ2ZXktZGV0YWlsXFxzdXJ2ZXktZGV0YWlsLnBhZ2Uuc2NzcyIsInNyYy9hcHAvc3VydmV5LWRldGFpbC9zdXJ2ZXktZGV0YWlsLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGdCQUFBO0FDQ0Y7O0FERUE7RUFDRSxnQkFBQTtBQ0NGOztBREVBO0VBQ0UsZ0JBQUE7QUNDRjs7QURFQTtFQUNFLGNBQUE7QUNDRjs7QURFQTtFQUNFLFdBQUE7RUFDQSxZQUFBO0FDQ0Y7O0FERUE7RUFDRSxnQkFBQTtFQUNBLGNBQUE7QUNDRjs7QURFQTtFQUNFLGNBQUE7RUFDQSxZQUFBO0FDQ0Y7O0FERUE7RUFDRSxjQUFBO0FDQ0Y7O0FERUE7RUFDRSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSx5QkFBQTtBQ0NGOztBREVBO0VBQ0UsbUJBQUE7RUFDQSxvQkFBQTtFQUNBLGNBQUE7QUNDRjs7QURFQTtFQUNFLFVBQUE7RUFDQSxXQUFBO0VBQ0EsbUJBQUE7RUFDQSxvQkFBQTtFQUNBLFlBQUE7QUNDRjs7QURFQTtFQUNFLGNBQUE7QUNDRjs7QURFQTtFQUNFLGdCQUFBO0VBQ0EsaUJBQUE7QUNDRjs7QURFQTtFQUNFLGdCQUFBO0VBQ0EsaUJBQUE7QUNDRjs7QURFQTtFQUNFLFdBQUE7RUFDQSxZQUFBO0FDQ0Y7O0FERUE7RUFDRSxZQUFBO0VBQ0EsYUFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7S0FBQSxnQkFBQTtFQUNBLHVCQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7QUNDRjs7QURFQTtFQUNFLFdBQUE7QUNDRjs7QURFQTtFQUNFLHlCQUFBO0VBQ0Esa0JBQUE7QUNDRjs7QURFQTtFQUNFLHVCQUFBO0FDQ0Y7O0FERUE7RUFDRSxrQkFBQTtFQUNBLGdCQUFBO0FDQ0Y7O0FEQ0U7RUFDRSxhQUFBO0FDQ0o7O0FER0E7RUFDRSxnQkFBQTtBQ0FGOztBREdBO0VBQ0UsZ0JBQUE7QUNBRjs7QURHQTtFQUNFLHFCQUFBO0VBQ0EsMkJBQUE7QUNBRjs7QURHQTtFQUNHLHFCQUFBO0VBQ0EsY0FBQTtBQ0FIOztBREdBO0VBQ0UsZUFBQTtBQ0FGOztBREdBO0VBQ0UseUJBQUE7QUNBRjs7QURHQTtFQUNFLFlBQUE7QUNBRjs7QURHQTtFQUNFLHFCQUFBO0FDQUY7O0FERUU7RUFDSSx5QkFBQTtBQ0FOOztBREtBO0VBQ0UsV0FBQTtFQUNBLHlCQUFBO0FDRkY7O0FESUE7RUFDRSxZQUFBO0FDREY7O0FESUE7RUFDRSxrQkFBQTtFQUNBLFlBQUE7RUFDQSw2QkFBQTtBQ0RGOztBRElBO0VBQ0EsMkJBQUE7RUFDQSxzQkFBQTtBQ0RBOztBREdBO0VBQ0EsZUFBQTtFQUNBLGVBQUE7RUFBZ0Isc0JBQUE7RUFDaEIsV0FBQTtBQ0NBOztBRENBO0VBQWlCLHNCQUFBO0VBQXVCLGVBQUE7QUNJeEM7O0FERkE7RUFDRSxzQkFBQTtFQUNBLDJCQUFBO0FDS0Y7O0FERkE7RUFDQSx1QkFBQTtBQ0tBOztBREhBO0VBQ0UsdUJBQUE7QUNNRjs7QURGRTtFQUNFLHVCQUFBO0FDS0o7O0FEREE7RUFDRSwyQkFBQTtBQ0lGOztBRERBO0VBQ0UsWUFBQTtFQUNBLGdCQUFBO0FDSUY7O0FERkE7RUFDRSx1QkFBQTtBQ0tGOztBREZFO0VBQ0UsdUJBQUE7QUNLSiIsImZpbGUiOiJzcmMvYXBwL3N1cnZleS1kZXRhaWwvc3VydmV5LWRldGFpbC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuc3VydmV5LWVtYWlsIHtcclxuICBmb250LXNpemU6IDAuOGVtO1xyXG59XHJcblxyXG4uc3VydmV5LW5hbWUge1xyXG4gIGZvbnQtc2l6ZTogMS43ZW07XHJcbn1cclxuXHJcbi5zdXJ2ZXktcGhvbmUge1xyXG4gIGZvbnQtc2l6ZTogMC44ZW07XHJcbn1cclxuXHJcbmlvbi1oZWFkZXIge1xyXG4gIGNvbG9yOiAjNjY2NjY2O1xyXG59XHJcblxyXG4uaW1hZ2UtY291bnQge1xyXG4gIHdpZHRoOiA0OHB4O1xyXG4gIGhlaWdodDogNDhweDtcclxufVxyXG5cclxuLmRhdGEtaGVhZGVyIHtcclxuICBmb250LXNpemU6IDAuOWVtO1xyXG4gIGNvbG9yOiAjQkZCRkJGO1xyXG59XHJcblxyXG4uZGF0YS1wb2ludCB7XHJcbiAgZm9udC1zaXplOiAxZW07XHJcbiAgY29sb3I6IGJsYWNrO1xyXG59XHJcblxyXG4uYWRkcmVzcyB7XHJcbiAgY29sb3I6ICMzYTdiZTA7XHJcbn1cclxuXHJcbi5jb21tZW50LWJ5IHtcclxuICBmb250LXNpemU6IDEwcHg7XHJcbiAgZm9udC1zdHlsZTogaXRhbGljO1xyXG4gIGNvbG9yOiAjNjY2NjY2ICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5tYWluLWJhY2tncm91bmQge1xyXG4gIGJhY2tncm91bmQ6ICNFRkVGRUY7XHJcbiAgYm9yZGVyLXJhZGl1czogMC41ZW07XHJcbiAgY29sb3I6ICM2NTY1NjU7XHJcbn1cclxuXHJcbi5kYXRlLWJhY2tncm91bmQge1xyXG4gIHdpZHRoOiA0ZW07XHJcbiAgaGVpZ2h0OiA0ZW07XHJcbiAgYmFja2dyb3VuZDogIzNjNzhkODtcclxuICBib3JkZXItcmFkaXVzOiAwLjVlbTtcclxuICBjb2xvcjogd2hpdGU7XHJcbn1cclxuXHJcbi5tb250aCB7XHJcbiAgZm9udC1zaXplOiAxZW07XHJcbn1cclxuXHJcbi5kYXkge1xyXG4gIGZvbnQtc2l6ZTogMS41ZW07XHJcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbn1cclxuXHJcbi50aW1lIHtcclxuICBmb250LXNpemU6IDEuNWVtO1xyXG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG59XHJcblxyXG4ucmVzY2hlZHVsZS1pY29uIHtcclxuICB3aWR0aDogNDhweDtcclxuICBoZWlnaHQ6IDQ4cHg7XHJcbn1cclxuXHJcbi5hc3NpZ25lZS1pbWFnZSB7XHJcbiAgd2lkdGg6IDMuNWVtO1xyXG4gIGhlaWdodDogMy41ZW07XHJcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gIG9iamVjdC1maXQ6IGZpbGw7XHJcbiAgYm9yZGVyOiAycHggc29saWQgd2hpdGU7XHJcbiAgcGFkZGluZzogOHB4O1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBiYWNrZ3JvdW5kOiAjRkZGMUNGO1xyXG59XHJcblxyXG4uYXNzaWduZWUtbWFyZ2luIHtcclxuICBtYXJnaW46IDhweDtcclxufVxyXG5cclxuLnNlbGVjdGVkIHtcclxuICBib3JkZXI6IDNweCBzb2xpZCAjM2M3OGQ4O1xyXG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcclxufVxyXG5cclxuLm5vcm1hbCB7XHJcbiAgYm9yZGVyOiAzcHggc29saWQgd2hpdGU7XHJcbn1cclxuXHJcbmRpdltzY3JvbGx4PXRydWVdLCBkaXZbc2Nyb2xseT10cnVlXSB7XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIG92ZXJmbG93OiBoaWRkZW47XHJcblxyXG4gIDo6LXdlYmtpdC1zY3JvbGxiYXIge1xyXG4gICAgZGlzcGxheTogbm9uZTtcclxuICB9XHJcbn1cclxuXHJcbmRpdltzY3JvbGx4PXRydWVdIHtcclxuICBvdmVyZmxvdy14OiBhdXRvO1xyXG59XHJcblxyXG5kaXZbc2Nyb2xseT10cnVlXSB7XHJcbiAgb3ZlcmZsb3cteTogYXV0bztcclxufVxyXG5cclxuLmRhdGUtcGlja2VyIHtcclxuICAtLWJhY2tncm91bmQ6ICNFMUUxRTE7XHJcbiAgLS1ib3JkZXI6IDJweCBzb2xpZCAjNjY2NjY2O1xyXG59XHJcblxyXG4ucGlja2VyLWJ1dHRvbiB7XHJcbiAgIC0tYmFja2dyb3VuZDogIzNjNzhkODtcclxuICAgLS1jb2xvcjogd2hpdGU7XHJcbiB9XHJcblxyXG4ubmFtZV9kaXZ7XHJcbiAgZm9udC1zaXplOiAyMHB4O1xyXG59XHJcblxyXG4ucGFnZS10ZXh0LWNvbG9yIHtcclxuICBjb2xvcjogIzY2NjY2NiAhaW1wb3J0YW50OztcclxufVxyXG5cclxuLnNlZ21lbnRze1xyXG4gIGhlaWdodDo0MHB4O1xyXG59XHJcblxyXG5pb24tc2VnbWVudC1idXR0b24ge1xyXG4gIHdpZHRoOiBjYWxjKDEwMCUgLyA0KTtcclxuXHJcbiAgaW9uLWxhYmVsIHtcclxuICAgICAgbWF4LXdpZHRoOiBjYWxjKDkwdncgLyA0KTtcclxuICB9XHJcbn1cclxuXHJcblxyXG4uYmtne1xyXG4gIGNvbG9yOiAjNjY2O1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICNmOWY5Zjk7XHJcbn1cclxuaW9uLXNsaWRlcyB7XHJcbiAgaGVpZ2h0OiAxMDAlO1xyXG59XHJcblxyXG4ucG9zaXRpb24tZml4e1xyXG4gIHBvc2l0aW9uOmFic29sdXRlO1xyXG4gIHotaW5kZXg6OTk5O1xyXG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlWSgtMTAwMCUpO1xyXG59XHJcblxyXG4uc2VnbWVudC1idG57XHJcbmJhY2tncm91bmQ6IGJsdWUgIWltcG9ydGFudDtcclxuY29sb3I6I2ZmZiAhaW1wb3J0YW50O1xyXG59XHJcbi53ZDE0MHtcclxubWluLXdpZHRoOiBhdXRvO1xyXG5tYXgtd2lkdGg6IDEwMCU7d2lkdGg6IGF1dG8gIWltcG9ydGFudDtcclxuY29sb3I6I2ZmZjtcclxufVxyXG4ud2QxNDAgaW9uLWxhYmVse3dpZHRoOiBhdXRvICFpbXBvcnRhbnQ7bWF4LXdpZHRoOiAxMDAlO31cclxuXHJcbi5jb2xvcndodHtcclxuICBjb2xvcjojMTExICFpbXBvcnRhbnQ7XHJcbiAgYmFja2dyb3VuZDogI2ZmZiAhaW1wb3J0YW50O1xyXG59XHJcblxyXG5tYWluIGlubmVyLXNjcm9sbCBzY3JvbGwteXtcclxucGFkZGluZzowcHggIWltcG9ydGFudDt9XHJcblxyXG5pb24tc2xpZGVze1xyXG4gIHBhZGRpbmc6MHB4ICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbmlvbi1jb250ZW50e1xyXG4gIG1haW57XHJcbiAgICBwYWRkaW5nOjBweCAhaW1wb3J0YW50O1xyXG4gIH1cclxufVxyXG5cclxuYnV0dG9ue1xyXG4gIGJhY2tncm91bmQ6IGJsdWUgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmhndC1tYXJnaW57XHJcbiAgaGVpZ2h0OiAzOXB4O1xyXG4gIG1hcmdpbi10b3A6IDEwcHg7XHJcbn1cclxuaW9uLWdyaWR7XHJcbiAgcGFkZGluZzowcHggIWltcG9ydGFudDtcclxufVxyXG5pb24tY29udGVudHtcclxuICBtYWlue1xyXG4gICAgcGFkZGluZzowcHggIWltcG9ydGFudDtcclxuICB9XHJcbn1cclxuXHJcbiIsIi5zdXJ2ZXktZW1haWwge1xuICBmb250LXNpemU6IDAuOGVtO1xufVxuXG4uc3VydmV5LW5hbWUge1xuICBmb250LXNpemU6IDEuN2VtO1xufVxuXG4uc3VydmV5LXBob25lIHtcbiAgZm9udC1zaXplOiAwLjhlbTtcbn1cblxuaW9uLWhlYWRlciB7XG4gIGNvbG9yOiAjNjY2NjY2O1xufVxuXG4uaW1hZ2UtY291bnQge1xuICB3aWR0aDogNDhweDtcbiAgaGVpZ2h0OiA0OHB4O1xufVxuXG4uZGF0YS1oZWFkZXIge1xuICBmb250LXNpemU6IDAuOWVtO1xuICBjb2xvcjogI0JGQkZCRjtcbn1cblxuLmRhdGEtcG9pbnQge1xuICBmb250LXNpemU6IDFlbTtcbiAgY29sb3I6IGJsYWNrO1xufVxuXG4uYWRkcmVzcyB7XG4gIGNvbG9yOiAjM2E3YmUwO1xufVxuXG4uY29tbWVudC1ieSB7XG4gIGZvbnQtc2l6ZTogMTBweDtcbiAgZm9udC1zdHlsZTogaXRhbGljO1xuICBjb2xvcjogIzY2NjY2NiAhaW1wb3J0YW50O1xufVxuXG4ubWFpbi1iYWNrZ3JvdW5kIHtcbiAgYmFja2dyb3VuZDogI0VGRUZFRjtcbiAgYm9yZGVyLXJhZGl1czogMC41ZW07XG4gIGNvbG9yOiAjNjU2NTY1O1xufVxuXG4uZGF0ZS1iYWNrZ3JvdW5kIHtcbiAgd2lkdGg6IDRlbTtcbiAgaGVpZ2h0OiA0ZW07XG4gIGJhY2tncm91bmQ6ICMzYzc4ZDg7XG4gIGJvcmRlci1yYWRpdXM6IDAuNWVtO1xuICBjb2xvcjogd2hpdGU7XG59XG5cbi5tb250aCB7XG4gIGZvbnQtc2l6ZTogMWVtO1xufVxuXG4uZGF5IHtcbiAgZm9udC1zaXplOiAxLjVlbTtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG59XG5cbi50aW1lIHtcbiAgZm9udC1zaXplOiAxLjVlbTtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG59XG5cbi5yZXNjaGVkdWxlLWljb24ge1xuICB3aWR0aDogNDhweDtcbiAgaGVpZ2h0OiA0OHB4O1xufVxuXG4uYXNzaWduZWUtaW1hZ2Uge1xuICB3aWR0aDogMy41ZW07XG4gIGhlaWdodDogMy41ZW07XG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgb2JqZWN0LWZpdDogZmlsbDtcbiAgYm9yZGVyOiAycHggc29saWQgd2hpdGU7XG4gIHBhZGRpbmc6IDhweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBiYWNrZ3JvdW5kOiAjRkZGMUNGO1xufVxuXG4uYXNzaWduZWUtbWFyZ2luIHtcbiAgbWFyZ2luOiA4cHg7XG59XG5cbi5zZWxlY3RlZCB7XG4gIGJvcmRlcjogM3B4IHNvbGlkICMzYzc4ZDg7XG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcbn1cblxuLm5vcm1hbCB7XG4gIGJvcmRlcjogM3B4IHNvbGlkIHdoaXRlO1xufVxuXG5kaXZbc2Nyb2xseD10cnVlXSwgZGl2W3Njcm9sbHk9dHJ1ZV0ge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIG92ZXJmbG93OiBoaWRkZW47XG59XG5kaXZbc2Nyb2xseD10cnVlXSA6Oi13ZWJraXQtc2Nyb2xsYmFyLCBkaXZbc2Nyb2xseT10cnVlXSA6Oi13ZWJraXQtc2Nyb2xsYmFyIHtcbiAgZGlzcGxheTogbm9uZTtcbn1cblxuZGl2W3Njcm9sbHg9dHJ1ZV0ge1xuICBvdmVyZmxvdy14OiBhdXRvO1xufVxuXG5kaXZbc2Nyb2xseT10cnVlXSB7XG4gIG92ZXJmbG93LXk6IGF1dG87XG59XG5cbi5kYXRlLXBpY2tlciB7XG4gIC0tYmFja2dyb3VuZDogI0UxRTFFMTtcbiAgLS1ib3JkZXI6IDJweCBzb2xpZCAjNjY2NjY2O1xufVxuXG4ucGlja2VyLWJ1dHRvbiB7XG4gIC0tYmFja2dyb3VuZDogIzNjNzhkODtcbiAgLS1jb2xvcjogd2hpdGU7XG59XG5cbi5uYW1lX2RpdiB7XG4gIGZvbnQtc2l6ZTogMjBweDtcbn1cblxuLnBhZ2UtdGV4dC1jb2xvciB7XG4gIGNvbG9yOiAjNjY2NjY2ICFpbXBvcnRhbnQ7XG59XG5cbi5zZWdtZW50cyB7XG4gIGhlaWdodDogNDBweDtcbn1cblxuaW9uLXNlZ21lbnQtYnV0dG9uIHtcbiAgd2lkdGg6IGNhbGMoMTAwJSAvIDQpO1xufVxuaW9uLXNlZ21lbnQtYnV0dG9uIGlvbi1sYWJlbCB7XG4gIG1heC13aWR0aDogY2FsYyg5MHZ3IC8gNCk7XG59XG5cbi5ia2cge1xuICBjb2xvcjogIzY2NjtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2Y5ZjlmOTtcbn1cblxuaW9uLXNsaWRlcyB7XG4gIGhlaWdodDogMTAwJTtcbn1cblxuLnBvc2l0aW9uLWZpeCB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgei1pbmRleDogOTk5O1xuICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTEwMDAlKTtcbn1cblxuLnNlZ21lbnQtYnRuIHtcbiAgYmFja2dyb3VuZDogYmx1ZSAhaW1wb3J0YW50O1xuICBjb2xvcjogI2ZmZiAhaW1wb3J0YW50O1xufVxuXG4ud2QxNDAge1xuICBtaW4td2lkdGg6IGF1dG87XG4gIG1heC13aWR0aDogMTAwJTtcbiAgd2lkdGg6IGF1dG8gIWltcG9ydGFudDtcbiAgY29sb3I6ICNmZmY7XG59XG5cbi53ZDE0MCBpb24tbGFiZWwge1xuICB3aWR0aDogYXV0byAhaW1wb3J0YW50O1xuICBtYXgtd2lkdGg6IDEwMCU7XG59XG5cbi5jb2xvcndodCB7XG4gIGNvbG9yOiAjMTExICFpbXBvcnRhbnQ7XG4gIGJhY2tncm91bmQ6ICNmZmYgIWltcG9ydGFudDtcbn1cblxubWFpbiBpbm5lci1zY3JvbGwgc2Nyb2xsLXkge1xuICBwYWRkaW5nOiAwcHggIWltcG9ydGFudDtcbn1cblxuaW9uLXNsaWRlcyB7XG4gIHBhZGRpbmc6IDBweCAhaW1wb3J0YW50O1xufVxuXG5pb24tY29udGVudCBtYWluIHtcbiAgcGFkZGluZzogMHB4ICFpbXBvcnRhbnQ7XG59XG5cbmJ1dHRvbiB7XG4gIGJhY2tncm91bmQ6IGJsdWUgIWltcG9ydGFudDtcbn1cblxuLmhndC1tYXJnaW4ge1xuICBoZWlnaHQ6IDM5cHg7XG4gIG1hcmdpbi10b3A6IDEwcHg7XG59XG5cbmlvbi1ncmlkIHtcbiAgcGFkZGluZzogMHB4ICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1jb250ZW50IG1haW4ge1xuICBwYWRkaW5nOiAwcHggIWltcG9ydGFudDtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/survey-detail/survey-detail.page.ts":
/*!*****************************************************!*\
  !*** ./src/app/survey-detail/survey-detail.page.ts ***!
  \*****************************************************/
/*! exports provided: SurveyDetailPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SurveyDetailPage", function() { return SurveyDetailPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _utilities_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../utilities.service */ "./src/app/utilities.service.ts");
/* harmony import */ var _api_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../api.service */ "./src/app/api.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _storage_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../storage.service */ "./src/app/storage.service.ts");
/* harmony import */ var ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ion-bottom-drawer */ "./node_modules/ion-bottom-drawer/fesm2015/ion-bottom-drawer.js");
/* harmony import */ var _ionic_native_date_picker_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic-native/date-picker/ngx */ "./node_modules/@ionic-native/date-picker/ngx/index.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic-native/launch-navigator/ngx */ "./node_modules/@ionic-native/launch-navigator/ngx/index.js");
/* harmony import */ var _contants__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../contants */ "./src/app/contants.ts");
/* harmony import */ var _modal_page_modal_page_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./modal-page/modal-page.component */ "./src/app/survey-detail/modal-page/modal-page.component.ts");













let SurveyDetailPage = class SurveyDetailPage {
    constructor(utilities, apiService, route, navController, alertController, storage, datePicker, formBuilder, launchNavigator, toastController, modalController) {
        this.utilities = utilities;
        this.apiService = apiService;
        this.route = route;
        this.navController = navController;
        this.alertController = alertController;
        this.storage = storage;
        this.datePicker = datePicker;
        this.formBuilder = formBuilder;
        this.launchNavigator = launchNavigator;
        this.toastController = toastController;
        this.modalController = modalController;
        this.slideOpts = {
            initialSlide: 1,
            speed: 400
        };
        this.listOfAssignees = [];
        this.drawerState = ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_7__["DrawerState"].Bottom;
        this.assigned = false;
        this.refreshDataOnPreviousPage = 0;
        this.segments = 'SiteDetils';
        this.electricals = 'MSB';
        this.options = {
            start: '',
            app: this.launchNavigator.APP.GOOGLE_MAPS
        };
        this.iseditable = true;
        this.surveyId = +this.route.snapshot.paramMap.get('id');
        this.rescheduleForm = this.formBuilder.group({
            datetime: new _angular_forms__WEBPACK_IMPORTED_MODULE_9__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_9__["Validators"].required]),
            comments: new _angular_forms__WEBPACK_IMPORTED_MODULE_9__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_9__["Validators"].required])
        });
        this.assigneeForm = this.formBuilder.group({
            assignedto: new _angular_forms__WEBPACK_IMPORTED_MODULE_9__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_9__["Validators"].required])
        });
        if (this.storage.getUser().role.id == _contants__WEBPACK_IMPORTED_MODULE_11__["ROLES"].Surveyor) {
            this.iseditable = false;
        }
    }
    ngOnInit() {
        this.dataSubscription = this.utilities.getSurveyDetailsRefresh().subscribe((result) => {
            this.refreshDataOnPreviousPage++;
            this.getSurveyDetails();
            this.getAssignees();
        });
    }
    ngOnDestroy() {
        this.dataSubscription.unsubscribe();
        if (this.refreshDataOnPreviousPage > 1) {
            this.utilities.sethomepageSurveyRefresh(true);
        }
    }
    getSurveyDetails() {
        this.utilities.showLoading('Getting Survey Details').then((success) => {
            this.apiService.getSurveyDetail(this.surveyId).subscribe((result) => {
                this.utilities.hideLoading().then(() => {
                    this.setData(result);
                    console.log(">>>", result);
                });
            }, (error) => {
                this.utilities.hideLoading();
            });
        });
    }
    setData(result) {
        console.log(result);
        this.survey = result;
        if (this.survey.acdisconnect) {
            if (this.survey.acdisconnect === 'true') {
                this.survey.acdisconnect = 'yes';
            }
            else {
                this.survey.acdisconnect = 'no';
            }
        }
        if (this.survey.pvmeter) {
            if (this.survey.pvmeter === 'true') {
                this.survey.pvmeter = 'yes';
            }
            else {
                this.survey.pvmeter = 'no';
            }
        }
        this.assigned = this.survey.assignedto !== null && this.survey.assignedto !== undefined;
        this.rescheduleForm.patchValue({
            datetime: this.survey.datetime
        });
    }
    chat() {
    }
    goBack() {
        this.navController.pop();
    }
    getSurveyImages() {
        return this.survey.mspimages.length
            + this.survey.utilitymeterimages.length
            + this.survey.pvinverterimages.length
            + this.survey.pvmeterimages.length
            + this.survey.roofimages.length
            + this.survey.acdisconnectimages.length
            + this.survey.existingsubpanelimages.length
            + this.survey.appliancesimages.length
            + this.survey.atticimages.length
            + this.survey.roofdimensionimages.length
            + this.survey.obstaclesimages.length
            + this.survey.obstaclesdimensionsimages.length;
    }
    deleteSurvey() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                header: 'Delete Survey',
                message: 'Are you sure you want to delete this survey?',
                cssClass: 'my-custom-class',
                buttons: [
                    {
                        text: 'Yes',
                        handler: () => {
                            this.deleteSurveyFromServer();
                        }
                    }, {
                        text: 'No'
                    }
                ]
            });
            toast.present();
        });
    }
    deleteSurveyFromServer() {
        this.utilities.showLoading('Deleting Survey').then((success) => {
            this.apiService.deleteSurvey(this.surveyId).subscribe((result) => {
                this.utilities.hideLoading().then(() => {
                    this.utilities.showSnackBar('Survey deleted successfully');
                    this.navController.pop();
                    this.utilities.sethomepageSurveyRefresh(true);
                });
            }, (error) => {
                this.utilities.hideLoading().then(() => {
                    this.utilities.errorSnackBar('Some Error Occurred');
                });
            });
        });
    }
    getAssignees() {
        this.apiService.getSurveyors().subscribe(assignees => {
            this.listOfAssignees = [];
            assignees.forEach(item => this.listOfAssignees.push(item));
            console.log(this.listOfAssignees);
        });
    }
    reschedule() {
        this.drawerState = ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_7__["DrawerState"].Docked;
        this.date = this.survey.datetime;
    }
    changeDate() {
        const currentDate = new Date(this.date);
        console.log(currentDate);
        this.datePicker.show({
            date: new Date(this.date),
            minDate: new Date(),
            mode: 'date',
            androidTheme: this.datePicker.ANDROID_THEMES.THEME_DEVICE_DEFAULT_LIGHT
        }).then(date => {
            this.date = date;
            this.rescheduleForm.patchValue({
                datetime: this.date.getTime()
            });
        }, err => console.log('Error occurred while getting date: ', err));
    }
    changeTime() {
        const currentDate = new Date(this.date);
        console.log(currentDate);
        this.datePicker.show({
            date: new Date(this.date),
            mode: 'time',
            minDate: new Date(),
            androidTheme: this.datePicker.ANDROID_THEMES.THEME_DEVICE_DEFAULT_LIGHT
        }).then(date => {
            const oldDate = new Date(this.date);
            oldDate.setHours(date.getHours(), date.getMinutes(), date.getSeconds(), date.getMilliseconds());
            this.date = oldDate;
            this.rescheduleForm.patchValue({
                datetime: this.date.getTime()
            });
        }, err => console.log('Error occurred while getting date: ', err));
    }
    rescheduleSurvey() {
        if (this.rescheduleForm.status === 'INVALID') {
            this.utilities.errorSnackBar('Invalid Data');
        }
        else {
            this.utilities.showLoading('Updating').then(() => {
                this.apiService.updateSurveyForm(this.rescheduleForm.value, this.surveyId).subscribe(response => {
                    this.utilities.hideLoading().then(() => {
                        this.survey = response;
                        this.drawerState = ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_7__["DrawerState"].Bottom;
                    });
                }, responseError => {
                    this.utilities.hideLoading().then(() => {
                        const error = responseError.error;
                        if (error.message instanceof String) {
                            this.utilities.errorSnackBar(error.message);
                        }
                        else if (error.message instanceof Array) {
                            this.utilities.errorSnackBar(error.message[0].messages[0].message);
                        }
                    });
                });
            });
        }
    }
    dismissBottomSheet() {
        this.drawerState = ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_7__["DrawerState"].Bottom;
    }
    updateAssignee() {
        if (this.assigneeForm.status === 'INVALID') {
            this.utilities.errorSnackBar('Please select an assignee');
        }
        else {
            this.utilities.showLoading('Updating').then(() => {
                this.apiService.updateSurveyForm(this.assigneeForm.value, this.surveyId).subscribe((success) => {
                    this.utilities.hideLoading().then(() => {
                        this.utilities.showSnackBar('Assignee selected');
                        this.setData(success);
                        this.refreshDataOnPreviousPage++;
                    });
                }, (error) => {
                    this.utilities.hideLoading().then(() => {
                        this.utilities.errorSnackBar('Some Error Occurred');
                    });
                });
            });
        }
    }
    openAddressOnMap(address) {
        this.launchNavigator.navigate(address, this.options);
    }
    openModal(image) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            console.log(image);
            const modal = yield this.modalController.create({
                component: _modal_page_modal_page_component__WEBPACK_IMPORTED_MODULE_12__["ModalPageComponent"],
                showBackdrop: true,
                backdropDismiss: true,
                componentProps: {
                    image_url: image,
                },
            });
            return yield modal.present();
        });
    }
};
SurveyDetailPage.ctorParameters = () => [
    { type: _utilities_service__WEBPACK_IMPORTED_MODULE_2__["UtilitiesService"] },
    { type: _api_service__WEBPACK_IMPORTED_MODULE_3__["ApiService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["NavController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["AlertController"] },
    { type: _storage_service__WEBPACK_IMPORTED_MODULE_6__["StorageService"] },
    { type: _ionic_native_date_picker_ngx__WEBPACK_IMPORTED_MODULE_8__["DatePicker"] },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_9__["FormBuilder"] },
    { type: _ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_10__["LaunchNavigator"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ToastController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ModalController"] }
];
SurveyDetailPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-survey-detail',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./survey-detail.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/survey-detail/survey-detail.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./survey-detail.page.scss */ "./src/app/survey-detail/survey-detail.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_utilities_service__WEBPACK_IMPORTED_MODULE_2__["UtilitiesService"],
        _api_service__WEBPACK_IMPORTED_MODULE_3__["ApiService"],
        _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["NavController"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["AlertController"],
        _storage_service__WEBPACK_IMPORTED_MODULE_6__["StorageService"],
        _ionic_native_date_picker_ngx__WEBPACK_IMPORTED_MODULE_8__["DatePicker"],
        _angular_forms__WEBPACK_IMPORTED_MODULE_9__["FormBuilder"],
        _ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_10__["LaunchNavigator"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ToastController"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ModalController"]])
], SurveyDetailPage);



/***/ })

}]);
//# sourceMappingURL=survey-detail-survey-detail-module-es2015.js.map