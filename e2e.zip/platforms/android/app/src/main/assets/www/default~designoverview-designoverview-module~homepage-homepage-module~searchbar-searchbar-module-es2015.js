(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~designoverview-designoverview-module~homepage-homepage-module~searchbar-searchbar-module"],{

/***/ "./node_modules/@ionic-native/native-geocoder/ngx/index.js":
/*!*****************************************************************!*\
  !*** ./node_modules/@ionic-native/native-geocoder/ngx/index.js ***!
  \*****************************************************************/
/*! exports provided: NativeGeocoder */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NativeGeocoder", function() { return NativeGeocoder; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_native_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic-native/core */ "./node_modules/@ionic-native/core/index.js");



var NativeGeocoder = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(NativeGeocoder, _super);
    function NativeGeocoder() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    NativeGeocoder.prototype.reverseGeocode = function (latitude, longitude, options) { return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "reverseGeocode", { "callbackOrder": "reverse" }, arguments); };
    NativeGeocoder.prototype.forwardGeocode = function (addressString, options) { return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "forwardGeocode", { "callbackOrder": "reverse" }, arguments); };
    NativeGeocoder.pluginName = "NativeGeocoder";
    NativeGeocoder.plugin = "cordova-plugin-nativegeocoder";
    NativeGeocoder.pluginRef = "nativegeocoder";
    NativeGeocoder.repo = "https://github.com/sebastianbaar/cordova-plugin-nativegeocoder";
    NativeGeocoder.platforms = ["iOS", "Android"];
    NativeGeocoder = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])()
    ], NativeGeocoder);
    return NativeGeocoder;
}(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["IonicNativePlugin"]));

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvQGlvbmljLW5hdGl2ZS9wbHVnaW5zL25hdGl2ZS1nZW9jb2Rlci9uZ3gvaW5kZXgudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDM0MsT0FBTyw4QkFBc0MsTUFBTSxvQkFBb0IsQ0FBQzs7SUF3Q3BDLGtDQUFpQjs7OztJQVduRCx1Q0FBYyxhQUNaLFFBQWdCLEVBQ2hCLFNBQWlCLEVBQ2pCLE9BQStCO0lBY2pDLHVDQUFjLGFBQUMsYUFBcUIsRUFBRSxPQUErQjs7Ozs7O0lBNUIxRCxjQUFjO1FBRDFCLFVBQVUsRUFBRTtPQUNBLGNBQWM7eUJBekMzQjtFQXlDb0MsaUJBQWlCO1NBQXhDLGNBQWMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBDb3Jkb3ZhLCBJb25pY05hdGl2ZVBsdWdpbiwgUGx1Z2luIH0gZnJvbSAnQGlvbmljLW5hdGl2ZS9jb3JlJztcblxuLyoqXG4gKiBAbmFtZSBOYXRpdmUgR2VvY29kZXJcbiAqIEBkZXNjcmlwdGlvblxuICogQ29yZG92YSBwbHVnaW4gZm9yIG5hdGl2ZSBmb3J3YXJkIGFuZCByZXZlcnNlIGdlb2NvZGluZ1xuICpcbiAqIEB1c2FnZVxuICogYGBgdHlwZXNjcmlwdFxuICogaW1wb3J0IHsgTmF0aXZlR2VvY29kZXIsIE5hdGl2ZUdlb2NvZGVyUmVzdWx0LCBOYXRpdmVHZW9jb2Rlck9wdGlvbnMgfSBmcm9tICdAaW9uaWMtbmF0aXZlL25hdGl2ZS1nZW9jb2Rlci9uZ3gnO1xuICpcbiAqIGNvbnN0cnVjdG9yKHByaXZhdGUgbmF0aXZlR2VvY29kZXI6IE5hdGl2ZUdlb2NvZGVyKSB7IH1cbiAqXG4gKiAuLi5cbiAqXG4gKiBsZXQgb3B0aW9uczogTmF0aXZlR2VvY29kZXJPcHRpb25zID0ge1xuICogICAgIHVzZUxvY2FsZTogdHJ1ZSxcbiAqICAgICBtYXhSZXN1bHRzOiA1XG4gKiB9O1xuICpcbiAqIHRoaXMubmF0aXZlR2VvY29kZXIucmV2ZXJzZUdlb2NvZGUoNTIuNTA3MjA5NSwgMTMuMTQ1MjgxOCwgb3B0aW9ucylcbiAqICAgLnRoZW4oKHJlc3VsdDogTmF0aXZlR2VvY29kZXJSZXN1bHRbXSkgPT4gY29uc29sZS5sb2coSlNPTi5zdHJpbmdpZnkocmVzdWx0WzBdKSkpXG4gKiAgIC5jYXRjaCgoZXJyb3I6IGFueSkgPT4gY29uc29sZS5sb2coZXJyb3IpKTtcbiAqXG4gKiB0aGlzLm5hdGl2ZUdlb2NvZGVyLmZvcndhcmRHZW9jb2RlKCdCZXJsaW4nLCBvcHRpb25zKVxuICogICAudGhlbigocmVzdWx0OiBOYXRpdmVHZW9jb2RlclJlc3VsdFtdKSA9PiBjb25zb2xlLmxvZygnVGhlIGNvb3JkaW5hdGVzIGFyZSBsYXRpdHVkZT0nICsgcmVzdWx0WzBdLmxhdGl0dWRlICsgJyBhbmQgbG9uZ2l0dWRlPScgKyByZXN1bHRbMF0ubG9uZ2l0dWRlKSlcbiAqICAgLmNhdGNoKChlcnJvcjogYW55KSA9PiBjb25zb2xlLmxvZyhlcnJvcikpO1xuICogYGBgXG4gKiBAaW50ZXJmYWNlc1xuICogTmF0aXZlR2VvY29kZXJSZXN1bHRcbiAqIE5hdGl2ZUdlb2NvZGVyT3B0aW9uc1xuICovXG5AUGx1Z2luKHtcbiAgcGx1Z2luTmFtZTogJ05hdGl2ZUdlb2NvZGVyJyxcbiAgcGx1Z2luOiAnY29yZG92YS1wbHVnaW4tbmF0aXZlZ2VvY29kZXInLFxuICBwbHVnaW5SZWY6ICduYXRpdmVnZW9jb2RlcicsXG4gIHJlcG86ICdodHRwczovL2dpdGh1Yi5jb20vc2ViYXN0aWFuYmFhci9jb3Jkb3ZhLXBsdWdpbi1uYXRpdmVnZW9jb2RlcicsXG4gIHBsYXRmb3JtczogWydpT1MnLCAnQW5kcm9pZCddLFxufSlcbkBJbmplY3RhYmxlKClcbmV4cG9ydCBjbGFzcyBOYXRpdmVHZW9jb2RlciBleHRlbmRzIElvbmljTmF0aXZlUGx1Z2luIHtcbiAgLyoqXG4gICAqIFJldmVyc2UgZ2VvY29kZSBhIGdpdmVuIGxhdGl0dWRlIGFuZCBsb25naXR1ZGUgdG8gZmluZCBsb2NhdGlvbiBhZGRyZXNzXG4gICAqIEBwYXJhbSBsYXRpdHVkZSB7bnVtYmVyfSBUaGUgbGF0aXR1ZGVcbiAgICogQHBhcmFtIGxvbmdpdHVkZSB7bnVtYmVyfSBUaGUgbG9uZ2l0dWRlXG4gICAqIEBwYXJhbSBvcHRpb25zIHtOYXRpdmVHZW9jb2Rlck9wdGlvbnN9IFRoZSBvcHRpb25zXG4gICAqIEByZXR1cm4ge1Byb21pc2U8TmF0aXZlR2VvY29kZXJSZXN1bHRbXT59XG4gICAqL1xuICBAQ29yZG92YSh7XG4gICAgY2FsbGJhY2tPcmRlcjogJ3JldmVyc2UnLFxuICB9KVxuICByZXZlcnNlR2VvY29kZShcbiAgICBsYXRpdHVkZTogbnVtYmVyLFxuICAgIGxvbmdpdHVkZTogbnVtYmVyLFxuICAgIG9wdGlvbnM/OiBOYXRpdmVHZW9jb2Rlck9wdGlvbnNcbiAgKTogUHJvbWlzZTxOYXRpdmVHZW9jb2RlclJlc3VsdFtdPiB7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgLyoqXG4gICAqIEZvcndhcmQgZ2VvY29kZSBhIGdpdmVuIGFkZHJlc3MgdG8gZmluZCBjb29yZGluYXRlc1xuICAgKiBAcGFyYW0gYWRkcmVzc1N0cmluZyB7c3RyaW5nfSBUaGUgYWRkcmVzcyB0byBiZSBnZW9jb2RlZFxuICAgKiBAcGFyYW0gb3B0aW9ucyB7TmF0aXZlR2VvY29kZXJPcHRpb25zfSBUaGUgb3B0aW9uc1xuICAgKiBAcmV0dXJuIHtQcm9taXNlPE5hdGl2ZUdlb2NvZGVyUmVzdWx0W10+fVxuICAgKi9cbiAgQENvcmRvdmEoe1xuICAgIGNhbGxiYWNrT3JkZXI6ICdyZXZlcnNlJyxcbiAgfSlcbiAgZm9yd2FyZEdlb2NvZGUoYWRkcmVzc1N0cmluZzogc3RyaW5nLCBvcHRpb25zPzogTmF0aXZlR2VvY29kZXJPcHRpb25zKTogUHJvbWlzZTxOYXRpdmVHZW9jb2RlclJlc3VsdFtdPiB7XG4gICAgcmV0dXJuO1xuICB9XG59XG5cbi8qKlxuICogRW5jYXBzdWxhdGVzIGZvcm1hdCBpbmZvcm1hdGlvbiBhYm91dCBhIGdlb2NvZGluZyByZXN1bHQuXG4gKiBtb3JlIEluZm86XG4gKiAgLSBodHRwczovL2RldmVsb3Blci5hcHBsZS5jb20vZG9jdW1lbnRhdGlvbi9jb3JlbG9jYXRpb24vY2xwbGFjZW1hcmtcbiAqICAtIGh0dHBzOi8vZGV2ZWxvcGVyLmFuZHJvaWQuY29tL3JlZmVyZW5jZS9hbmRyb2lkL2xvY2F0aW9uL0FkZHJlc3MuaHRtbFxuICovXG5leHBvcnQgaW50ZXJmYWNlIE5hdGl2ZUdlb2NvZGVyUmVzdWx0IHtcbiAgLyoqXG4gICAqIFRoZSBsYXRpdHVkZS5cbiAgICovXG4gIGxhdGl0dWRlOiBzdHJpbmc7XG4gIC8qKlxuICAgKiBUaGUgbG9uZ2l0dWRlLlxuICAgKi9cbiAgbG9uZ2l0dWRlOiBzdHJpbmc7XG4gIC8qKlxuICAgKiBUaGUgY291bnRyeSBjb2RlLlxuICAgKi9cbiAgY291bnRyeUNvZGU6IHN0cmluZztcbiAgLyoqXG4gICAqIFRoZSBjb3VudHJ5IG5hbWUuXG4gICAqL1xuICBjb3VudHJ5TmFtZTogc3RyaW5nO1xuICAvKipcbiAgICogVGhlIHBvc3RhbCBjb2RlLlxuICAgKi9cbiAgcG9zdGFsQ29kZTogc3RyaW5nO1xuICAvKipcbiAgICogVGhlIGFkbWluaXN0cmF0aXZlQXJlYS5cbiAgICovXG4gIGFkbWluaXN0cmF0aXZlQXJlYTogc3RyaW5nO1xuICAvKipcbiAgICogVGhlIHN1YkFkbWluaXN0cmF0aXZlQXJlYS5cbiAgICovXG4gIHN1YkFkbWluaXN0cmF0aXZlQXJlYTogc3RyaW5nO1xuICAvKipcbiAgICogVGhlIGxvY2FsaXR5LlxuICAgKi9cbiAgbG9jYWxpdHk6IHN0cmluZztcbiAgLyoqXG4gICAqIFRoZSBzdWJMb2NhbGl0eS5cbiAgICovXG4gIHN1YkxvY2FsaXR5OiBzdHJpbmc7XG4gIC8qKlxuICAgKiBUaGUgdGhvcm91Z2hmYXJlLlxuICAgKi9cbiAgdGhvcm91Z2hmYXJlOiBzdHJpbmc7XG4gIC8qKlxuICAgKiBUaGUgc3ViVGhvcm91Z2hmYXJlLlxuICAgKi9cbiAgc3ViVGhvcm91Z2hmYXJlOiBzdHJpbmc7XG4gIC8qKlxuICAgKiBUaGUgYXJlYXNPZkludGVyZXN0XG4gICAqL1xuICBhcmVhc09mSW50ZXJlc3Q6IHN0cmluZ1tdO1xufVxuXG4vKipcbiAqIE9wdGlvbnMgZm9yIHJldmVyc2UgYW5kIGZvcndhcmQgZ2VvY29kaW5nLlxuICovXG5leHBvcnQgaW50ZXJmYWNlIE5hdGl2ZUdlb2NvZGVyT3B0aW9ucyB7XG4gIC8qKlxuICAgKiBUaGUgbG9jYWxlIHRvIHVzZSB3aGVuIHJldHVybmluZyB0aGUgYWRkcmVzcyBpbmZvcm1hdGlvbi5cbiAgICogSWYgc2V0IHRvICdmYWxzZScgdGhlIGxvY2FsZSB3aWxsIGFsd2F5cyBiZSAnZW5fVVMnLlxuICAgKiBEZWZhdWx0IGlzICd0cnVlJ1xuICAgKi9cbiAgdXNlTG9jYWxlOiBib29sZWFuO1xuICAvKipcbiAgICogVGhlIGRlZmF1bHQgbG9jYWxlIHRvIHVzZSB3aGVuIHJldHVybmluZyB0aGUgYWRkcmVzcyBpbmZvcm1hdGlvbi5cbiAgICogZS5nLjogJ2ZhLUlSJyBvciAnZGVfREUnLlxuICAgKi9cbiAgZGVmYXVsdExvY2FsZT86IHN0cmluZztcbiAgLyoqXG4gICAqIFRoZSBtYXhpbXVtIG51bWJlciBvZiByZXN1bHQgdG8gcmV0dXJuIChtYXggaXMgNSkuXG4gICAqIERlZmF1bHQgaXMgMVxuICAgKi9cbiAgbWF4UmVzdWx0czogbnVtYmVyO1xufVxuIl19

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/email-model/email-model.page.html":
/*!*****************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/email-model/email-model.page.html ***!
  \*****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\r\n  <h4 style=\"font-weight: bold;margin-bottom:0px !important;padding: 10px;\">Select the Emails</h4>\r\n  \r\n  <ion-content>\r\n    <ion-list>\r\n     <ion-item>\r\n       <ion-label>\r\n       <input type=\"checkbox\" name=\"selectall\" [value]=\"TeamData\" (change)=\"selectAll($event)\" style=\"height: 17px;width: 28px;\">\r\n       Select All</ion-label>\r\n     </ion-item>\r\n     <ion-list>\r\n     <ion-item\r\n      *ngFor=\"let item of example; let i = index \">\r\n         <!-- <input type=\"checkbox\" [(ngModel)]=\"item.Checked\">&nbsp;  -->\r\n         <p class=\"listitem\">{{item?.firstname}}</p>\r\n         <p class=\"listitem\">{{item?.lastname}}</p>\r\n         <p class=\"listitem\">({{item?.email}})</p>\r\n         <ion-checkbox slot=\"start\" [(ngModel)]=\"item.Checked\" ></ion-checkbox>\r\n         \r\n     \r\n     </ion-item>\r\n     </ion-list>\r\n   </ion-list>\r\n   <ion-grid>\r\n         <ion-row>\r\n           <ion-col>\r\n             <h6 style=\"margin-top:0px;padding: 2px;\"></h6>\r\n             <textarea id=\"inputemails\" placeholder=\"eg : john@gmail.com\" type=\"emails\" multiple style=\"width: 100%;\" ></textarea>\r\n           </ion-col>\r\n         </ion-row>\r\n        <!-- <ion-row>\r\n           <ion-col>\r\n             <h6 style=\"margin:0px 0 0px 0;\">Attachment</h6>\r\n           \r\n               <ion-input type=\"text\" placeholder=\"Select Attachment\" [(ngModel)]=\"filename\" readonly (click)=\"selectAttachment()\" style=\"border-bottom:1px solid grey\"  > <ion-icon name=\"attach-outline\" style=\"float: right;text-align:right ;\"></ion-icon></ion-input>\r\n              \r\n            <small *ngIf=\"exceedfileSize > 0\" style=\"color:red\">File size should not be greater than 25MB.</small>\r\n           </ion-col>\r\n         </ion-row>-->\r\n       </ion-grid>\r\n  </ion-content>\r\n    <footer style=\"text-align: right;margin:12px;\">\r\n      <ion-button fill=\"clear\" (click)=\"cancel()\">Cancel</ion-button>\r\n      <ion-button fill=\"clear\" (click)=\"SendMail()\">Send</ion-button>\r\n    </footer>\r\n  <!-- <div class=_padding>\r\n    <p>Decline the design Request</p>\r\n    <textarea placeholder=\"Reason*\" style=\"width: 100%;\"></textarea>\r\n  </div> -->\r\n\r\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/homepage/design/design.component.html":
/*!*********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/homepage/design/design.component.html ***!
  \*********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content (click)=\"close()\" style=\"padding-bottom: 250px;\">\r\n\r\n    <ion-segment scrollable (ionChange)=\"segmentChanged($event)\" value=\"newDesign\">\r\n        <ion-segment-button value=\"newDesign\">\r\n          <ion-label class=\"segment-btn\">New Designs</ion-label>\r\n        </ion-segment-button>\r\n        <ion-segment-button value=\"InDesign\">\r\n          <ion-label class=\"segment-btn\">In Designing</ion-label>\r\n        </ion-segment-button>\r\n        <ion-segment-button value=\"completed\">\r\n          <ion-label class=\"segment-btn\">Completed</ion-label>\r\n        </ion-segment-button>\r\n        <ion-segment-button value=\"InReview\">\r\n          <ion-label class=\"segment-btn\"> In Review</ion-label>\r\n        </ion-segment-button>\r\n        <ion-segment-button value=\"delivered\">\r\n          <ion-label class=\"segment-btn\">Delivered</ion-label>\r\n        </ion-segment-button>\r\n      </ion-segment>\r\n      <ion-refresher slot=\"fixed\" (ionRefresh)=\"refreshDesigns($event)\">    \r\n          <ion-refresher-content></ion-refresher-content>\r\n        </ion-refresher>\r\n                   \r\n                       \r\n        <ion-grid *ngIf=\"listOfDesignsHelper.length !== 0\">\r\n            <ion-row *ngFor=\"let item of listOfDesignsHelper;let i = index\">\r\n                <ion-col size=\"12\" class=\"ion-margin-top\">\r\n                        <span class=\"ion-padding\" *ngIf=\"today === item.date\">\r\n                            Today\r\n                            </span>\r\n                    <span class=\"ion-padding\" *ngIf=\"today !== item.date\">\r\n                                {{item.date | date: 'dd MMM yyyy'}}\r\n                        </span>\r\n                </ion-col>\r\n                <ion-col *ngFor=\"let designData of item.listOfDesigns;let j = index\" size=\"12\">\r\n                    <ion-card class=\"ion-no-padding custom-card ion-no-margin\" style=\"height: 100%;\">\r\n                        <p class=\"customer-name\" \r\n                        routerDirection=\"forward\">{{designData.name}}\r\n                        <!-- <span class=\"chipdetail\" style=\"background-color: #1289A7;\" [routerLink]=\"['/design-details/',designData.id]\" routerDirection=\"forward\">\r\n                          {{designData.deliverydate | date: 'hh:mm a'}}\r\n                      </span> -->\r\n                      \r\n                      <span class=\"chipdetail\" style=\"background-color: rgb(246, 77, 10);\" *ngIf=\"designData.status == 'requestdeclined'\"  [routerLink]=\"['/design-details/',designData.id]\">Declined</span>\r\n                      <span class=\"chipdetail\" style=\"background-color: rgb(246, 77, 10);\" *ngIf=\"designData.status == 'reviewfailed'\"  [routerLink]=\"['/design-details/',designData.id]\">Review Failed</span>\r\n                      <span class=\"chipdetail\" style=\"background-color: rgb(246, 104, 10);\" *ngIf=\"item.lateby > 0\" [routerLink]=\"['/design-details/',designData.id]\">Overdue</span>\r\n                      <span class=\"chipdetail\" style=\"background-color: rgb(109, 187, 26);\" *ngIf=\"designData.status == 'requestaccepted'\" [routerLink]=\"['/design-details/',designData.id]\">Accepted</span>\r\n                      <span class=\"chipdetail\" style=\"background-color: rgb(109, 187, 26);\" *ngIf=\"designData.status == 'reviewpassed'\" [routerLink]=\"['/design-details/',designData.id]\">Review Passed</span>\r\n                      <span class=\"chipdetail\" style=\"background-color: rgb(109, 187, 26);\" *ngIf=\"designData.status == 'delivered'\" [routerLink]=\"['/design-details/',designData.id]\">Delivered</span>\r\n                      <span class=\"chipdetail\" style=\"background-color: rgb(109, 187, 26);\" *ngIf=\"designData.status == 'designcompleted'\" [routerLink]=\"['/design-details/',designData.id]\">Completed</span>\r\n                      <span class=\"chipdetail\" style=\"background-color: #1289A7;;\" *ngIf=\"designData.status == 'created'\" [routerLink]=\"['/design-details/',designData.id]\">Unassigned</span>\r\n                      <span class=\"chipdetail\" style=\"background-color: #1289A7;;\" *ngIf=\"designData.status == 'designassigned'\" [routerLink]=\"['/design-details/',designData.id]\">Design Assigned</span>\r\n                      <span class=\"chipdetail\" style=\"background-color: #1289A7;;\" *ngIf=\"designData.status == 'reviewassigned'\" [routerLink]=\"['/design-details/',designData.id]\">In Review</span>\r\n                      <span class=\"chipdetail\" *ngIf=\"designData.status == 'outsourced' && (userData.role.name=='ContractorAdmin' || userData.role.name=='ContractorSuperAdmin')\" style=\"background-color: #95afc0;\" [routerLink]=\"['/design-details/',designData.id]\">Waiting for acceptance</span>\r\n                      <span fill=\"clear\" background-border=\"clear\" [routerLink]=\"['/','activity',designData.id,'design']\" class=\"imagebutton\"  size=\"small\"  ><ion-icon  src=\"/assets/images/activitylist.svg\" ></ion-icon></span>\r\n              </p>\r\n              \r\n              <p style=\"margin:0px\">\r\n                  <span class=\"customer-email\" [routerLink]=\"['/design-details/',designData.id]\"\r\n                          routerDirection=\"forward\">{{designData.email}}</span>\r\n                          <span *ngIf=\"item.lateby > 1\" class=\"latebystyle\"><strong>Late by {{item.lateby}} days</strong></span>\r\n                          <span *ngIf=\"item.lateby == 1\" class=\"latebystyle\"><strong>Late by a day</strong></span>\r\n              </p>\r\n                        <a href=\"tel:{{designData.phonenumber}}\" style=\"text-decoration: none;\" class=\"z-100\">\r\n                            <span class=\"customer-phone\">{{designData.phonenumber}}</span></a>\r\n                        <span class=\"customer-address z-100\"\r\n                                (click)=\"openAddressOnMap(designData.address)\">{{(designData.address | slice:0:60) + (designData.address.length > 60 ? '...' : '')}}</span>\r\n        \r\n                        <ion-row style=\"margin-bottom: 8px;\" [routerLink]=\"['/design-details/',designData.id]\">\r\n                            <span class=\"chipdetail\" style=\"background-color: #95afc0;\" >Wattmonk</span>\r\n                            <span class=\"chipdetail\" style=\"background-color: #95afc0;\" >{{designData?.formattedjobtype}}</span>\r\n                            <ion-col>     \r\n                              \r\n                            </ion-col>\r\n                        </ion-row>\r\n                        <ion-row class=\"ion-no-margin ion-no-margin\">\r\n                            <ion-col *ngIf=\"segments=='requesttype=prelim&status=created&status=outsourced&status=requestaccepted'\">\r\n                                <span *ngIf=\"designData.status == 'created' || designData.status == 'requestaccepted' || designData.status=='requestdeclined'\" style=\"float:right !important;\" class=\"ion-text-end action-button-color\" (click)=\"openDesigners(designData.id,designData)\"\r\n                                >Assign</span>\r\n                                <span style=\"float: right;\">\r\n                                    <ng-container *ngIf=\"userData.role.type !=='clientsuperadmin'\"> \r\n                                        <ion-col size=\"8\"  *ngIf=\"designData.status == 'outsourced'\"  class=\"ion-text-end action-button-color\" (click)=\"accept(designData.id,'requestaccepted')\">\r\n                                           Accept\r\n                                        </ion-col>\r\n                                        <ion-col size=\"4\" *ngIf=\"designData.status == 'outsourced'\"  class=\"ion-text-end action-button-color\" (click)=\"decline(designData.id)\">\r\n                                        On Hold\r\n                                        </ion-col>\r\n                                    </ng-container>\r\n                                </span>\r\n                              \r\n                                <span *ngIf=\"designData.status == 'requestdeclined'\"style=\"float:right !important;\" class=\"ion-text-end action-button-color\" (click)=\"openDesigners(designData.id)\"\r\n                                >Reassign</span>\r\n                            </ion-col>\r\n\r\n\r\n                            <ion-col *ngIf=\"segments=='requesttype=prelim&status=designcompleted'\">\r\n                                <span  style=\"float:right !important;\" class=\"ion-text-end action-button-color\" (click)=\"openAnalysts(designData.id,designData)\"\r\n                                >Assign Review</span>\r\n                            </ion-col>\r\n                            <ion-col *ngIf=\"segments=='requesttype=prelim&status=reviewassigned&status=reviewfailed&status=reviewpassed'\">\r\n                                <span *ngIf=\"designData.status =='reviewpassed'\" style=\"float:right !important;\" class=\"ion-text-end action-button-color\" (click)=\"openreviewPassed(designData.id,designData)\"\r\n                                >  &nbsp; Deliver</span>\r\n                                <span *ngIf=\"designData.status =='reviewpassed'||designData.status=='reviewfailed'||designData.status=='reviewassigned'\" style=\"float:right !important;\" class=\"ion-text-end action-button-color\" (click)=\"openAnalysts(designData.id,designData)\"\r\n                                >Reassign Review</span>\r\n                            </ion-col>\r\n                         \r\n                            <ion-col *ngIf=\"segments=='requesttype=prelim&status=delivered'\">\r\n                                <span  style=\"float:right !important;\" class=\"ion-text-end action-button-color\" (click)=\"shareWhatsapp(designData)\">\r\n                                    <ion-icon name=\"share-social-outline\"></ion-icon></span>&nbsp;\r\n                                <span style=\"float:right !important;margin-right: 8px;\" class=\"ion-text-end action-button-color\" (click)=\"shareViaEmails(designData.id,designData)\">\r\n                                    <ion-icon name=\"mail\" ></ion-icon></span>\r\n                            </ion-col>\r\n                            <!-- <ion-col class=\"ion-no-margin ion-no-padding\">\r\n                                <ion-button class=\"ion-no-margin ion-no-padding\" fill=\"clear\" [routerLink]=\"['/surveyprocess/' + designData.id + '/' + designData.jobtype + '/' + designData.latitude + '/' + designData.longitude]\"\r\n                                routerDirection=\"forward\">\r\n                                    Restart Survey\r\n                                </ion-button>\r\n                            </ion-col> -->\r\n                        </ion-row>\r\n                        <!-- <ion-progress-bar [value]=\"1\" mode=\"ios\" color=\"success\" class=\"progress-bar-height\"></ion-progress-bar> -->\r\n                          <!-- <span class=\"ion-text-end timestamp\" [routerLink]=\"['/design-details/',designData.id]\" routerDirection=\"forward\">\r\n                                {{designData.deliverydate | date: 'hh:mm a'}}\r\n                           \r\n                    </span> -->\r\n                </ion-card>\r\n                </ion-col>\r\n            </ion-row>\r\n            <ion-row>\r\n                <ion-col size=\"12\" style=\"height: 100px;\">\r\n                \r\n                </ion-col>\r\n            </ion-row>\r\n        </ion-grid>\r\n       \r\n        <div *ngIf=\"listOfDesignsHelper.length === 0 \" class=\"h-100 d-flex flex-column align-center justify-center\">\r\n                <div *ngIf=\"!netSwitch\">\r\n                    No internet Connection\r\n                </div>\r\n                \r\n            <ion-img src=\"/assets/images/blank.png\" class=\"placeholder\"></ion-img>\r\n        </div>\r\n       \r\n\r\n</ion-content>\r\n\r\n<ion-bottom-drawer [(state)]=\"drawerState\" minimumHeight=\"0\" dockedHeight=\"400\" draggable=\"false\" disableDrag=\"true\"\r\n                   shouldBounce=\"true\" distanceTop=\"0\" class=\"drawer\" style=\"z-index: 9999 !important;\">\r\n    <form [formGroup]=\"assignForm\">\r\n        <ion-grid class=\"drawer\">\r\n            <ion-row>\r\n               <ion-col size=\"12\">\r\n                    <app-user-selector  (assigneeData)=getassignedata($event) placeholder=\"assign\" [assignees]=\"listOfAssignees\"\r\n                                       formControlName=\"assignedto\"></app-user-selector>\r\n                   \r\n                </ion-col>\r\n            </ion-row>\r\n            <ion-row style=\"margin-left: 8px;\">\r\n                <ion-col size=\"12\">\r\n                    <span class=\"input-placeholder\">comments</span>\r\n                </ion-col>\r\n                <ion-col size=\"12\" style=\"padding-top: 0px;\">\r\n                    <ion-textarea style=\"max-width: 98%;\" class=\"ion-no-margin ion-no-padding comment_box\" rows=\"3\"\r\n                                  formControlName=\"comment\"></ion-textarea>\r\n                </ion-col>\r\n            </ion-row>\r\n            <ion-row style=\"justify-content: flex-end;\">\r\n                <ion-col size=\"auto\" style=\"padding-top: 0px; margin-right: 6px;\">\r\n                    <ion-button class=\"buttom-drawer-button\" fill=\"clear\" (click)=\"assignToDesigner()\">\r\n                        Confirm\r\n                    </ion-button>\r\n                </ion-col>\r\n                <ion-col size=\"auto\">\r\n                    <ion-button class=\"buttom-drawer-button-cancel\" fill=\"clear\" (click)=\"dismissBottomSheet()\">\r\n                        Cancel\r\n                    </ion-button>\r\n                </ion-col>\r\n            </ion-row>\r\n        </ion-grid>\r\n    </form>\r\n\r\n</ion-bottom-drawer>\r\n\r\n<!-- <router-outlet></router-outlet> -->\r\n");

/***/ }),

/***/ "./src/app/email-model/email-model.page.scss":
/*!***************************************************!*\
  !*** ./src/app/email-model/email-model.page.scss ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".listitem {\n  font-size: 12px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZW1haWwtbW9kZWwvRjpcXG1vYmlsZWFwcC9zcmNcXGFwcFxcZW1haWwtbW9kZWxcXGVtYWlsLW1vZGVsLnBhZ2Uuc2NzcyIsInNyYy9hcHAvZW1haWwtbW9kZWwvZW1haWwtbW9kZWwucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksZUFBQTtBQ0NKIiwiZmlsZSI6InNyYy9hcHAvZW1haWwtbW9kZWwvZW1haWwtbW9kZWwucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmxpc3RpdGVte1xyXG4gICAgZm9udC1zaXplOiAxMnB4O1xyXG59IiwiLmxpc3RpdGVtIHtcbiAgZm9udC1zaXplOiAxMnB4O1xufSJdfQ== */");

/***/ }),

/***/ "./src/app/email-model/email-model.page.ts":
/*!*************************************************!*\
  !*** ./src/app/email-model/email-model.page.ts ***!
  \*************************************************/
/*! exports provided: EmailModelPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EmailModelPage", function() { return EmailModelPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var src_app_contants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/contants */ "./src/app/contants.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var src_app_utilities_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/utilities.service */ "./src/app/utilities.service.ts");
/* harmony import */ var src_app_storage_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/storage.service */ "./src/app/storage.service.ts");
/* harmony import */ var src_app_api_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/api.service */ "./src/app/api.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");








let EmailModelPage = class EmailModelPage {
    constructor(util, http, storage, api, modalctrl, nav) {
        this.util = util;
        this.http = http;
        this.storage = storage;
        this.api = api;
        this.modalctrl = modalctrl;
        this.nav = nav;
        this.example = [];
        this.teamMember = [];
        this.TeamData = [];
        this.bodyData = [];
        this.selectedEmails = [];
        this.resp = [];
        this.getTeamData();
    }
    validate(control) {
        throw new Error("Method not implemented.");
    }
    registerOnValidatorChange(fn) {
        throw new Error("Method not implemented.");
    }
    writeValue(obj) {
        throw new Error("Method not implemented.");
    }
    registerOnChange(fn) {
        throw new Error("Method not implemented.");
    }
    registerOnTouched(fn) {
        throw new Error("Method not implemented.");
    }
    setDisabledState(isDisabled) {
        throw new Error("Method not implemented.");
    }
    ngOnInit() {
        this.id = this.nav.get('id');
        this.data = this.nav.get('designData');
        console.log("hello", this.data);
    }
    getTeamData() {
        this.util.showLoading('Loading emails').then(() => {
            this.api.getTeamData().subscribe(response => {
                this.util.hideLoading().then(() => {
                    this.teamMember = response;
                    this.example = response;
                    this.TeamData = this.example;
                });
            });
        });
    }
    //onCloseClick(){
    // this.dialogRef.close(this.data);
    // }
    selectAll(event) {
        debugger;
        const Checked = event.target.checked;
        this.TeamData.forEach(item => item.Checked = Checked);
    }
    SendMail() {
        var emails = document.getElementById("inputemails").value;
        this.emailArray = emails.split(',');
        this.emailArray.forEach(element => {
            this.selectedEmails.push(element);
        });
        this.bodyData = this.TeamData.filter(item => item.Checked);
        this.bodyData.forEach(element => {
            this.selectedEmails.push(element.email);
        });
        console.log(this.selectedEmails);
        let body = { emails: this.selectedEmails,
            id: this.id };
        return this.http.post(src_app_contants__WEBPACK_IMPORTED_MODULE_2__["BaseUrl"] + "designs/send-prelim-design", body, {
            headers: this.headers
        }).subscribe((response) => {
            this.resp = response;
            if (this.resp.status == 'success') {
                this.util.showSnackBar("Email Sent  Successfully");
                this.modalctrl.dismiss({
                    'dismissed': true
                });
                // this.dialogRef.close( );
            }
            this.selectedEmails = [];
        }, error => {
            this.util.errorSnackBar("Something went wrong. Please try again.");
            this.selectedEmails = [];
        });
    }
    cancel() {
        this.modalctrl.dismiss({
            'dismissed': true,
            cancel: 'cancel'
        });
    }
    checkedData(event) {
        console.log(event.target.checked);
    }
};
EmailModelPage.ctorParameters = () => [
    { type: src_app_utilities_service__WEBPACK_IMPORTED_MODULE_4__["UtilitiesService"] },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"] },
    { type: src_app_storage_service__WEBPACK_IMPORTED_MODULE_5__["StorageService"] },
    { type: src_app_api_service__WEBPACK_IMPORTED_MODULE_6__["ApiService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["ModalController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["NavParams"] }
];
EmailModelPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-email-model',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./email-model.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/email-model/email-model.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./email-model.page.scss */ "./src/app/email-model/email-model.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_utilities_service__WEBPACK_IMPORTED_MODULE_4__["UtilitiesService"],
        _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"],
        src_app_storage_service__WEBPACK_IMPORTED_MODULE_5__["StorageService"],
        src_app_api_service__WEBPACK_IMPORTED_MODULE_6__["ApiService"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["ModalController"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["NavParams"]])
], EmailModelPage);



/***/ }),

/***/ "./src/app/homepage/design/design.component.scss":
/*!*******************************************************!*\
  !*** ./src/app/homepage/design/design.component.scss ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".custom-card {\n  display: flex !important;\n  flex-direction: column !important;\n  background: white !important;\n  border-radius: 4px !important;\n  box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.3) !important;\n  padding: 8px 12px;\n}\n\n.customer-name {\n  font-size: 1em;\n  color: #434343;\n  font-weight: bold;\n  display: table;\n  margin: 0px;\n}\n\n.customer-email {\n  font-size: 0.8em;\n  color: #B4B4B4;\n}\n\n.customer-phone {\n  font-size: 0.8em;\n  color: #4272B9;\n}\n\n.customer-address {\n  margin-top: 4px;\n  margin-bottom: 6px;\n  font-size: 0.8em;\n  color: #4272B9;\n}\n\n.timestamp {\n  font-size: 0.7em;\n}\n\n.chipdetail {\n  display: inline;\n  vertical-align: middle;\n  background-color: #95afc0;\n  font-size: 0.6em;\n  padding: 4px 10px;\n  border-radius: 10px;\n  text-align: center;\n  color: #fff;\n}\n\n.cssclass {\n  --max-height:100% !important;\n}\n\nion-bottom-drawer {\n  --padding: 0 !important;\n  padding: 0 !important;\n  --background: #F3F3F3 !important;\n  background: #F3F3F3 !important;\n}\n\nion-bottom-drawer ion-content {\n  --background: #F3F3F3 !important;\n}\n\n.segment-btn {\n  font-size: 10px !important;\n}\n\n.latebystyle {\n  float: right;\n  font-size: 10px;\n  color: #3C78DB;\n}\n\n.imagebutton {\n  float: right;\n  margin-top: 0px;\n}\n\n.alertClass {\n  background-color: wheat;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaG9tZXBhZ2UvZGVzaWduL0Y6XFxtb2JpbGVhcHAvc3JjXFxhcHBcXGhvbWVwYWdlXFxkZXNpZ25cXGRlc2lnbi5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvaG9tZXBhZ2UvZGVzaWduL2Rlc2lnbi5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHdCQUFBO0VBQ0EsaUNBQUE7RUFDQSw0QkFBQTtFQUNBLDZCQUFBO0VBQ0EscURBQUE7RUFDQSxpQkFBQTtBQ0NGOztBREVBO0VBQ0UsY0FBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtFQUNBLGNBQUE7RUFDQSxXQUFBO0FDQ0Y7O0FERUE7RUFDRSxnQkFBQTtFQUNBLGNBQUE7QUNDRjs7QURFQTtFQUNFLGdCQUFBO0VBQ0EsY0FBQTtBQ0NGOztBREVBO0VBQ0UsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0FDQ0Y7O0FETUE7RUFDRSxnQkFBQTtBQ0hGOztBRE9BO0VBQ0UsZUFBQTtFQUNBLHNCQUFBO0VBQ0EseUJBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7QUNKRjs7QURNQTtFQUNFLDRCQUFBO0FDSEY7O0FEa0JBO0VBRUUsdUJBQUE7RUFDQSxxQkFBQTtFQUVBLGdDQUFBO0VBQ0EsOEJBQUE7QUNqQkY7O0FEbUJFO0VBQ0UsZ0NBQUE7QUNqQko7O0FEc0JJO0VBQ0UsMEJBQUE7QUNuQk47O0FEc0JJO0VBQ0UsWUFBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0FDbkJOOztBRHNCQTtFQUNFLFlBQUE7RUFDQSxlQUFBO0FDbkJGOztBRHNCQTtFQUNFLHVCQUFBO0FDbkJGIiwiZmlsZSI6InNyYy9hcHAvaG9tZXBhZ2UvZGVzaWduL2Rlc2lnbi5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jdXN0b20tY2FyZCB7XHJcbiAgZGlzcGxheTogZmxleCAhaW1wb3J0YW50O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW4gIWltcG9ydGFudDtcclxuICBiYWNrZ3JvdW5kOiB3aGl0ZSAhaW1wb3J0YW50O1xyXG4gIGJvcmRlci1yYWRpdXM6IDRweCAhaW1wb3J0YW50O1xyXG4gIGJveC1zaGFkb3c6IDAgMXB4IDJweCAwIHJnYmEoMCwgMCwgMCwgMC4zKSAhaW1wb3J0YW50O1xyXG4gIHBhZGRpbmc6IDhweCAxMnB4O1xyXG59XHJcblxyXG4uY3VzdG9tZXItbmFtZSB7XHJcbiAgZm9udC1zaXplOiAxZW07XHJcbiAgY29sb3I6ICM0MzQzNDM7XHJcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgZGlzcGxheTp0YWJsZTtcclxuICBtYXJnaW46IDBweDtcclxufVxyXG5cclxuLmN1c3RvbWVyLWVtYWlsIHtcclxuICBmb250LXNpemU6IDAuOGVtO1xyXG4gIGNvbG9yOiAjQjRCNEI0O1xyXG59XHJcblxyXG4uY3VzdG9tZXItcGhvbmUge1xyXG4gIGZvbnQtc2l6ZTogMC44ZW07XHJcbiAgY29sb3I6ICM0MjcyQjk7XHJcbn1cclxuXHJcbi5jdXN0b21lci1hZGRyZXNzIHtcclxuICBtYXJnaW4tdG9wOiA0cHg7XHJcbiAgbWFyZ2luLWJvdHRvbTogNnB4O1xyXG4gIGZvbnQtc2l6ZTogMC44ZW07XHJcbiAgY29sb3I6ICM0MjcyQjk7XHJcbn1cclxuXHJcbi5wbGFjZWhvbGRlciB7XHJcbiAgLy8gd2lkdGg6IDUwdncgIWltcG9ydGFudDtcclxufVxyXG5cclxuLnRpbWVzdGFtcCB7XHJcbiAgZm9udC1zaXplOiAwLjdlbTtcclxuIFxyXG59XHJcblxyXG4uY2hpcGRldGFpbHtcclxuICBkaXNwbGF5OiBpbmxpbmU7XHJcbiAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjOTVhZmMwO1xyXG4gIGZvbnQtc2l6ZTogMC42ZW07XHJcbiAgcGFkZGluZzogNHB4IDEwcHg7XHJcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgY29sb3I6ICNmZmY7XHJcbn1cclxuLmNzc2NsYXNze1xyXG4gIC0tbWF4LWhlaWdodCA6MTAwJSAhaW1wb3J0YW50O1xyXG4gIC8vIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAvLyBkaXNwbGF5OiBibG9jaztcclxufVxyXG5cclxuXHJcbi8vLmRyYXdlciB7XHJcbi8vICBiYWNrZ3JvdW5kOiAjRjNGM0YzO1xyXG4vLyAgLS1iYWNrZ3JvdW5kOiAjRjNGM0YzO1xyXG4vL31cclxuLy9cclxuLy8uaW9uLWJvdHRvbS1kcmF3ZXItc2Nyb2xsYWJsZS1jb250ZW50IHtcclxuLy8gIGJhY2tncm91bmQ6ICNGM0YzRjMgIWltcG9ydGFudDtcclxuLy99XHJcblxyXG5pb24tYm90dG9tLWRyYXdlciB7XHJcblxyXG4gIC0tcGFkZGluZzogMCAhaW1wb3J0YW50O1xyXG4gIHBhZGRpbmc6IDAgIWltcG9ydGFudDtcclxuXHJcbiAgLS1iYWNrZ3JvdW5kOiAjRjNGM0YzICFpbXBvcnRhbnQ7XHJcbiAgYmFja2dyb3VuZDogI0YzRjNGMyAhaW1wb3J0YW50O1xyXG5cclxuICBpb24tY29udGVudCB7XHJcbiAgICAtLWJhY2tncm91bmQ6ICNGM0YzRjMgIWltcG9ydGFudDtcclxuICB9XHJcblxyXG4gIFxyXG59XHJcbiAgICAuc2VnbWVudC1idG57XHJcbiAgICAgIGZvbnQtc2l6ZTogMTBweCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG5cclxuICAgIC5sYXRlYnlzdHlsZXtcclxuICAgICAgZmxvYXQ6IHJpZ2h0OyBcclxuICAgICAgZm9udC1zaXplOiAxMHB4O1xyXG4gICAgICBjb2xvcjogIzNDNzhEQjtcclxuICAgIH1cclxuXHJcbi5pbWFnZWJ1dHRvbntcclxuICBmbG9hdDpyaWdodDtcclxuICBtYXJnaW4tdG9wOiAwcHg7XHJcbn1cclxuXHJcbi5hbGVydENsYXNze1xyXG4gIGJhY2tncm91bmQtY29sb3I6IHdoZWF0O1xyXG59IiwiLmN1c3RvbS1jYXJkIHtcbiAgZGlzcGxheTogZmxleCAhaW1wb3J0YW50O1xuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uICFpbXBvcnRhbnQ7XG4gIGJhY2tncm91bmQ6IHdoaXRlICFpbXBvcnRhbnQ7XG4gIGJvcmRlci1yYWRpdXM6IDRweCAhaW1wb3J0YW50O1xuICBib3gtc2hhZG93OiAwIDFweCAycHggMCByZ2JhKDAsIDAsIDAsIDAuMykgIWltcG9ydGFudDtcbiAgcGFkZGluZzogOHB4IDEycHg7XG59XG5cbi5jdXN0b21lci1uYW1lIHtcbiAgZm9udC1zaXplOiAxZW07XG4gIGNvbG9yOiAjNDM0MzQzO1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgZGlzcGxheTogdGFibGU7XG4gIG1hcmdpbjogMHB4O1xufVxuXG4uY3VzdG9tZXItZW1haWwge1xuICBmb250LXNpemU6IDAuOGVtO1xuICBjb2xvcjogI0I0QjRCNDtcbn1cblxuLmN1c3RvbWVyLXBob25lIHtcbiAgZm9udC1zaXplOiAwLjhlbTtcbiAgY29sb3I6ICM0MjcyQjk7XG59XG5cbi5jdXN0b21lci1hZGRyZXNzIHtcbiAgbWFyZ2luLXRvcDogNHB4O1xuICBtYXJnaW4tYm90dG9tOiA2cHg7XG4gIGZvbnQtc2l6ZTogMC44ZW07XG4gIGNvbG9yOiAjNDI3MkI5O1xufVxuXG4udGltZXN0YW1wIHtcbiAgZm9udC1zaXplOiAwLjdlbTtcbn1cblxuLmNoaXBkZXRhaWwge1xuICBkaXNwbGF5OiBpbmxpbmU7XG4gIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XG4gIGJhY2tncm91bmQtY29sb3I6ICM5NWFmYzA7XG4gIGZvbnQtc2l6ZTogMC42ZW07XG4gIHBhZGRpbmc6IDRweCAxMHB4O1xuICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGNvbG9yOiAjZmZmO1xufVxuXG4uY3NzY2xhc3Mge1xuICAtLW1heC1oZWlnaHQ6MTAwJSAhaW1wb3J0YW50O1xufVxuXG5pb24tYm90dG9tLWRyYXdlciB7XG4gIC0tcGFkZGluZzogMCAhaW1wb3J0YW50O1xuICBwYWRkaW5nOiAwICFpbXBvcnRhbnQ7XG4gIC0tYmFja2dyb3VuZDogI0YzRjNGMyAhaW1wb3J0YW50O1xuICBiYWNrZ3JvdW5kOiAjRjNGM0YzICFpbXBvcnRhbnQ7XG59XG5pb24tYm90dG9tLWRyYXdlciBpb24tY29udGVudCB7XG4gIC0tYmFja2dyb3VuZDogI0YzRjNGMyAhaW1wb3J0YW50O1xufVxuXG4uc2VnbWVudC1idG4ge1xuICBmb250LXNpemU6IDEwcHggIWltcG9ydGFudDtcbn1cblxuLmxhdGVieXN0eWxlIHtcbiAgZmxvYXQ6IHJpZ2h0O1xuICBmb250LXNpemU6IDEwcHg7XG4gIGNvbG9yOiAjM0M3OERCO1xufVxuXG4uaW1hZ2VidXR0b24ge1xuICBmbG9hdDogcmlnaHQ7XG4gIG1hcmdpbi10b3A6IDBweDtcbn1cblxuLmFsZXJ0Q2xhc3Mge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGVhdDtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/homepage/design/design.component.ts":
/*!*****************************************************!*\
  !*** ./src/app/homepage/design/design.component.ts ***!
  \*****************************************************/
/*! exports provided: DesignComponent, DesginDataHelper */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DesignComponent", function() { return DesignComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DesginDataHelper", function() { return DesginDataHelper; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var src_app_api_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/api.service */ "./src/app/api.service.ts");
/* harmony import */ var src_app_utilities_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/utilities.service */ "./src/app/utilities.service.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/launch-navigator/ngx */ "./node_modules/@ionic-native/launch-navigator/ngx/index.js");
/* harmony import */ var ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ion-bottom-drawer */ "./node_modules/ion-bottom-drawer/fesm2015/ion-bottom-drawer.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm2015/ionic-storage.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var src_app_declinepage_declinepage_page__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/declinepage/declinepage.page */ "./src/app/declinepage/declinepage.page.ts");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var src_app_storage_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/storage.service */ "./src/app/storage.service.ts");
/* harmony import */ var src_app_networkdetect_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! src/app/networkdetect.service */ "./src/app/networkdetect.service.ts");
/* harmony import */ var _ionic_native_social_sharing_ngx__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @ionic-native/social-sharing/ngx */ "./node_modules/@ionic-native/social-sharing/ngx/index.js");
/* harmony import */ var src_app_email_model_email_model_page__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! src/app/email-model/email-model.page */ "./src/app/email-model/email-model.page.ts");

















let DesignComponent = class DesignComponent {
    constructor(utils, apiService, datePipe, storage, cdr, launchNavigator, formBuilder, route, router, modalController, storageService, network, alertController, socialsharing) {
        this.utils = utils;
        this.apiService = apiService;
        this.datePipe = datePipe;
        this.storage = storage;
        this.cdr = cdr;
        this.launchNavigator = launchNavigator;
        this.formBuilder = formBuilder;
        this.route = route;
        this.router = router;
        this.modalController = modalController;
        this.storageService = storageService;
        this.network = network;
        this.alertController = alertController;
        this.socialsharing = socialsharing;
        this.listOfDesignDataHelper = [];
        this.listOfDesignsData = [];
        this.options = {
            start: '',
            app: this.launchNavigator.APP.GOOGLE_MAPS
        };
        this.drawerState = ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_6__["DrawerState"].Bottom;
        this.listOfAssignees = [];
        this.listOfAssignees2 = [];
        this.designId = 0;
        this.showBottomDraw = false;
        this.myFiles = [];
        this.segments = 'requesttype=prelim&status=created&status=outsourced&status=requestaccepted';
        const latestDate = new Date();
        this.today = datePipe.transform(latestDate, 'M/dd/yy');
        console.log('date', this.today);
        this.todaysdate = datePipe.transform(latestDate, 'yyyy-MM-dd');
        this.assignForm = this.formBuilder.group({
            assignedto: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required]),
            comment: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormControl"]('')
        });
    }
    ionViewDidEnter() {
        this.network.networkSwitch.subscribe(data => {
            this.netSwitch = data;
            console.log(this.netSwitch);
        });
        this.network.networkDisconnect();
        this.network.networkConnect();
    }
    segmentChanged(event) {
        if (this.userData.role.type == 'wattmonkadmins' || this.userData.role.name == 'Admin' || this.userData.role.name == 'ContractorAdmin' || this.userData.role.name == 'BD') {
            if (event.target.value == 'newDesign') {
                this.segments = 'requesttype=prelim&status=created&status=outsourced&status=requestaccepted';
                // return this.segments;
            }
            else if (event.target.value == 'InDesign') {
                this.segments = "requesttype=prelim&status=designassigned";
                // return this.segments;
            }
            else if (event.target.value == 'completed') {
                this.segments = "requesttype=prelim&status=designcompleted";
                // return this.segments;
            }
            else if (event.target.value == 'InReview') {
                this.segments = "requesttype=prelim&status=reviewassigned&status=reviewfailed&status=reviewpassed";
                // return this.segments;
            }
            else if (event.target.value == 'delivered') {
                this.segments = "requesttype=prelim&status=delivered";
            }
            this.getDesigns(null);
            // return this.segments;
        }
        else if (this.userData.role.type == 'clientsuperadmin' || this.userData.role.name == 'SuperAdmin' || this.userData.role.name == 'ContractorSuperAdmin') {
            if (event.target.value == 'newDesign') {
                this.segments = 'requesttype=prelim&status=created&status=outsourced&status=requestaccepted&&status=requestdeclined';
                // return this.segments;
            }
            else if (event.target.value == 'InDesign') {
                this.segments = "requesttype=prelim&status=designassigned";
                // return this.segments;
            }
            else if (event.target.value == 'completed') {
                this.segments = "requesttype=prelim&status=designcompleted";
                // return this.segments;
            }
            else if (event.target.value == 'InReview') {
                this.segments = "requesttype=prelim&status=reviewassigned&status=reviewfailed&status=reviewpassed";
                // return this.segments;
            }
            else if (event.target.value == 'delivered') {
                this.segments = "requesttype=prelim&status=delivered";
            }
            this.getDesigns(null);
        }
        // this.getsegmentdata(event.target.value);
        console.log((event.target.value));
        // this.segments = event.target.value;
        // this.DesignRefreshSubscription = this.utils.getHomepageDesignRefresh().subscribe((result) => {
        // });
        // this.dataRefreshSubscription = this.utils.getDataRefresh().subscribe((result) => {
        //   if(this.listOfDesigns != null && this.listOfDesigns.length > 0){
        //     this.formatDesignData(this.listOfDesigns);
        //   }
        // });
    }
    ngOnInit() {
        this.userData = this.storageService.getUser();
        console.log(this.userData);
        // this.router.navigate(['homepage/design/pending']);
        // this.routeSubscription = this.router.events.subscribe((event) => {
        //   if (event instanceof NavigationEnd) {
        //     // Trick the Router into believing it's last link wasn't previously loaded
        //     if (this.router.url.indexOf('page') > -1) {
        //       this.router.navigated = false;
        //       let data = this.route.queryParams.subscribe((_res: any) => {
        //         console.log('Serach Term', _res);
        //         if (Object.keys(_res).length !== 0) {
        //           //  this.ApplysearchDesginAndSurvey(_res.serchTerm)
        //           this.filterData(_res.serchTerm);
        //         } else {
        //           // this.refreshSubscription = this.utils.getHomepageDesignRefresh().subscribe((result) => {
        //             // ;
        //             this.getDesign(null, true);
        //           // });
        //         }
        //       });
        //     }
        //   }
        // });
        this.DesignRefreshSubscription = this.utils.getHomepageDesignRefresh().subscribe((result) => {
            this.getDesigns(null);
        });
        this.dataRefreshSubscription = this.utils.getDataRefresh().subscribe((result) => {
            if (this.listOfDesigns != null && this.listOfDesigns.length > 0) {
                this.formatDesignData(this.listOfDesigns);
            }
        });
    }
    getDesigns(event) {
        let showLoader = true;
        if (event != null && event !== undefined) {
            showLoader = false;
        }
        this.fetchPendingDesigns(event, showLoader);
    }
    fetchPendingDesigns(event, showLoader) {
        console.log("inside fetch Designs");
        this.listOfDesigns = [];
        this.listOfDesignsHelper = [];
        this.utils.showLoadingWithPullRefreshSupport(showLoader, 'Getting Designs').then((success) => {
            this.apiService.getDesignSurveys(this.segments).subscribe((response) => {
                this.utils.hideLoadingWithPullRefreshSupport(showLoader).then(() => {
                    console.log(response);
                    this.formatDesignData(response);
                    if (event !== null) {
                        event.target.complete();
                    }
                });
            }, responseError => {
                this.utils.hideLoadingWithPullRefreshSupport(showLoader).then(() => {
                    if (event !== null) {
                        event.target.complete();
                    }
                    const error = responseError.error;
                    this.utils.errorSnackBar(error.message[0].messages[0].message);
                });
            });
        });
    }
    formatDesignData(records) {
        this.overdue = [];
        this.listOfDesigns = this.fillinDynamicData(records);
        console.log(this.listOfDesigns);
        const tempData = [];
        this.listOfDesigns.forEach((designItem, i) => {
            console.log(i);
            if (tempData.length === 0) {
                this.sDatePassed(designItem.updated_at, i);
                const listOfDesign = new DesginDataHelper();
                listOfDesign.date = this.datePipe.transform(designItem.updated_at, 'M/dd/yy');
                listOfDesign.lateby = this.overdue;
                listOfDesign.listOfDesigns.push(designItem);
                tempData.push(listOfDesign);
                console.log(tempData);
                ;
            }
            else {
                let added = false;
                tempData.forEach((DesignList) => {
                    // DesignList['listOfDesigns'].forEach(element=>{
                    //   console.log(element.deliverydate,":::::::::::::");
                    //   this.sDatePassed(element.deliverydate);
                    // })
                    if (!added) {
                        if (DesignList.date === this.datePipe.transform(designItem.updated_at, 'M/dd/yy')) {
                            DesignList.listOfDesigns.push(designItem);
                            this.sDatePassed(designItem.updated_at, i);
                            added = true;
                        }
                    }
                });
                if (!added) {
                    ;
                    this.sDatePassed(designItem.updated_at, i);
                    const listOfDesign = new DesginDataHelper();
                    listOfDesign.date = this.datePipe.transform(designItem.updated_at, 'M/dd/yy');
                    listOfDesign.lateby = this.overdue;
                    listOfDesign.listOfDesigns.push(designItem);
                    tempData.push(listOfDesign);
                    added = true;
                }
            }
        });
        this.listOfDesignsHelper = tempData.sort(function (a, b) {
            var dateA = new Date(a.date).getTime(), dateB = new Date(b.date).getTime();
            return dateB - dateA;
        });
        this.cdr.detectChanges();
    }
    ngOnDestroy() {
        // this.refreshSubscription.unsubscribe();
        // this.routeSubscription.unsubscribe();
        this.dataRefreshSubscription.unsubscribe();
        this.DesignRefreshSubscription.unsubscribe();
    }
    // filterData(records : DesginDataModel[]) {
    //   console.log(this.listOfDesignsData);
    //   this.listOfDesigns = this.fillinDynamicData(records);
    //   // let filterDataArray: any = this.listOfDesignsData.filter(x => x.id == serchTerm);
    //   const tempData: DesginDataHelper[] = [];
    //   this.listOfDesigns.forEach((desginItem) => {
    //     if (tempData.length === 0) {
    //       const listOfDesign = new DesginDataHelper();
    //       listOfDesign.date = this.datePipe.transform(desginItem.updated_at, 'M/d/yy');
    //       listOfDesign.listOfDesigns.push(desginItem);
    //       tempData.push(listOfDesign);
    //     } else {
    //       let added = false;
    //       tempData.forEach((desginList) => {
    //         if (!added) {
    //           if (desginList.date === this.datePipe.transform(desginItem.updated_at, 'M/d/yy')) {
    //             desginList.listOfDesigns.push(desginItem);
    //             added = true;
    //           }
    //         }
    //       });
    //       if (!added) {
    //         const listOfDesign = new DesginDataHelper();
    //         listOfDesign.date = this.datePipe.transform(desginItem.updated_at, 'M/d/yy');
    //         listOfDesign.listOfDesigns.push(desginItem);
    //         tempData.push(listOfDesign);
    //         added = true;
    //         this.listOfDesignDataHelper.push(listOfDesign);
    //         console.log(this.listOfDesignDataHelper);
    //       }
    //     }
    //   });
    //   this.listOfDesignDataHelper = tempData;
    //   this.cdr.detectChanges();
    // }
    fillinDynamicData(records) {
        records.forEach(element => {
            element.formattedjobtype = this.utils.getJobTypeName(element.jobtype);
            this.storage.get('' + element.id).then((data) => {
                console.log(data);
                if (data) {
                    element.totalpercent = data.currentprogress;
                }
                else {
                    element.totalpercent = 0;
                }
            });
        });
        return records;
    }
    // getDesign(event, showLoader: boolean) {
    //   this.listOfDesignsData = [];
    //   this.listOfDesignDataHelper = [];
    //   this.utils.showLoadingWithPullRefreshSupport(showLoader, 'Getting designs').then((success) => {
    //     // ;
    //     this.apiService.getDesignSurveys(this.segments).subscribe((response:any) => {
    //       this.utils.hideLoadingWithPullRefreshSupport(showLoader).then((loaderHidden) => {
    //         // ;
    //         if (event !== null) {
    //           event.target.complete();
    //         }
    //         console.log(response, '>>');
    //         this.listOfDesignsData = response;
    //          response.forEach(element => {
    //             this.roleType = element.type;            
    //         });;
    //         console.log(this.roleType);
    //         const tempData: DesginDataHelper[] = [];
    //         this.listOfDesignsData.forEach((desginItem) => {
    //           if (tempData.length === 0) {
    //             const listOfDesign = new DesginDataHelper();
    //             listOfDesign.date = this.datePipe.transform(desginItem.updated_at, 'M/d/yy');
    //             listOfDesign.listOfDesigns.push(desginItem);
    //             tempData.push(listOfDesign);
    //           } else {
    //             let added = false;
    //             tempData.forEach((desginList) => {
    //               if (!added) {
    //                 if (desginList.date === this.datePipe.transform(desginItem.updated_at, 'M/d/yy')) {
    //                   desginList.listOfDesigns.push(desginItem);
    //                   added = true;
    //                 }
    //               }
    //             });
    //             if (!added) {
    //               const listOfDesign = new DesginDataHelper();
    //               listOfDesign.date = this.datePipe.transform(desginItem.updated_at, 'M/d/yy');
    //               listOfDesign.listOfDesigns.push(desginItem);
    //               tempData.push(listOfDesign);
    //               added = true;
    //               this.listOfDesignDataHelper.push(listOfDesign);
    //               console.log(this.listOfDesignDataHelper,"<<<<>>>>");
    //             }
    //           }
    //         });
    //         this.listOfDesignDataHelper = tempData;
    //         this.cdr.detectChanges();
    //       },responseError=>{
    //         this.utils.hideLoadingWithPullRefreshSupport(showLoader).then((loaderHidden) => {
    //           if (event !== null) {
    //             event.target.complete();
    //           }
    //           const error: ErrorModel = responseError.error;
    //           this.utils.errorSnackBar(error.message[0].messages[0].message);
    //         });
    //       });
    //     }, responseError => {
    //       this.utils.hideLoadingWithPullRefreshSupport(showLoader).then((loaderHidden) => {
    //         if (event !== null) {
    //           event.target.complete();
    //         }
    //         const error: ErrorModel = responseError.error;
    //         this.utils.errorSnackBar(error.message);
    //       });
    //     });
    //   }, (apiError) => {
    //     this.utils.hideLoadingWithPullRefreshSupport(showLoader).then(() => {
    //       if (event !== null) {
    //         event.target.complete();
    //       }
    //     });
    //   });
    // }
    openAddressOnMap(address) {
        this.launchNavigator.navigate(address, this.options);
    }
    dismissBottomSheet() {
        console.log('this', this.drawerState);
        this.drawerState = ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_6__["DrawerState"].Bottom;
        this.utils.setBottomBarHomepage(true);
        this.listOfAssignees = [];
        // console.log("this works",this.listOfAssignees)
    }
    assignToDesigner() {
        console.log(this.designerData.createdby.id);
        ;
        if (this.assignForm.status === 'INVALID') {
            this.utils.errorSnackBar('Please select a designer');
        }
        else {
            var designstarttime = new Date();
            var milisecond = designstarttime.getTime();
            var additonalhours = 0;
            if (this.designerData.requesttype == "prelim") {
                console.log(parseInt(this.selectedDesigner.jobcount));
                additonalhours = parseInt(this.selectedDesigner.jobcount) * 2;
                designstarttime.setHours(designstarttime.getHours() + additonalhours);
            }
            else {
                additonalhours = parseInt(this.selectedDesigner.jobcount) * 6;
                designstarttime.setHours(designstarttime.getHours() + additonalhours);
            }
            console.log(this.selectedDesigner);
            var postData = {};
            if (this.designerData.createdby.id == this.userData.id) {
                if (this.selectedDesigner.company == this.userData.company) {
                    if (this.selectedDesigner.role.type == "qcinspector") {
                        postData = {
                            reviewassignedto: this.selectedDesigner.id,
                            status: "reviewassigned",
                            reviewstarttime: milisecond
                        };
                    }
                    if (this.selectedDesigner.role.type == "designer") {
                        postData = {
                            designassignedto: this.selectedDesigner.id,
                            isoutsourced: "false",
                            status: "designassigned",
                            designstarttime: designstarttime
                        };
                    }
                }
                else {
                    postData = {
                        outsourcedto: this.selectedDesigner.id,
                        isoutsourced: "true",
                        status: "outsourced"
                    };
                }
            }
            else {
                if (this.selectedDesigner.role.type == "designer") {
                    postData = {
                        designassignedto: this.selectedDesigner.id,
                        status: "designassigned",
                        designstarttime: designstarttime
                    };
                }
                if (this.selectedDesigner.role.type == "qcinspector") {
                    postData = {
                        reviewassignedto: this.selectedDesigner.id,
                        status: "reviewassigned",
                        reviewstarttime: milisecond
                    };
                }
            }
            this.utils.showLoading('Assigning').then(() => {
                this.apiService.updateDesignForm(postData, this.designId).subscribe((value) => {
                    this.utils.hideLoading().then(() => {
                        ;
                        console.log('reach ', value);
                        this.utils.showSnackBar('Design request has been assigned to' + ' ' + value.name + ' ' + 'successfully');
                        this.dismissBottomSheet();
                        this.showBottomDraw = false;
                        this.utils.setHomepageDesignRefresh(true);
                    });
                }, (error) => {
                    this.utils.hideLoading();
                    this.dismissBottomSheet();
                    this.showBottomDraw = false;
                });
            });
        }
    }
    openDesigners(id, designData) {
        console.log("this is", designData);
        this.designerData = designData;
        if (this.listOfAssignees.length === 0) {
            this.utils.showLoading('Getting Designers').then(() => {
                this.apiService.getDesigners().subscribe(assignees => {
                    this.utils.hideLoading().then(() => {
                        this.listOfAssignees = [];
                        // this.listOfAssignees.push(this.utils.getDefaultAssignee(this.storage.getUserID()));
                        assignees.forEach(item => this.listOfAssignees.push(item));
                        console.log(this.listOfAssignees);
                        this.showBottomDraw = true;
                        this.designId = id;
                        this.utils.setBottomBarHomepage(false);
                        this.drawerState = ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_6__["DrawerState"].Docked;
                        this.assignForm.patchValue({
                            assignedto: ''
                        });
                    });
                }, (error) => {
                    this.utils.hideLoading().then(() => {
                        this.utils.errorSnackBar('Some error occurred. Please try again later');
                    });
                });
            });
        }
        else {
            this.designId = id;
            this.utils.setBottomBarHomepage(false);
            this.drawerState = ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_6__["DrawerState"].Docked;
            this.assignForm.patchValue({
                assignedto: ''
            });
        }
    }
    openAnalysts(id, designData) {
        console.log("this is", designData);
        this.designerData = designData;
        if (this.listOfAssignees.length === 0) {
            this.utils.showLoading('Getting Analysts').then(() => {
                this.apiService.getAnalysts().subscribe(assignees => {
                    this.utils.hideLoading().then(() => {
                        this.listOfAssignees = [];
                        // this.listOfAssignees.push(this.utils.getDefaultAssignee(this.storage.getUserID()));
                        assignees.forEach(item => this.listOfAssignees.push(item));
                        console.log(this.listOfAssignees);
                        this.showBottomDraw = true;
                        this.designId = id;
                        this.utils.setBottomBarHomepage(false);
                        this.drawerState = ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_6__["DrawerState"].Docked;
                        this.assignForm.patchValue({
                            assignedto: ''
                        });
                    });
                }, (error) => {
                    this.utils.hideLoading().then(() => {
                        this.utils.errorSnackBar('Some error occurred. Please try again later');
                    });
                });
            });
        }
        else {
            this.designId = id;
            this.utils.setBottomBarHomepage(false);
            this.drawerState = ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_6__["DrawerState"].Docked;
            this.assignForm.patchValue({
                assignedto: ''
            });
        }
    }
    close() {
        if (this.showBottomDraw === true) {
            this.showBottomDraw = false;
            this.drawerState = ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_6__["DrawerState"].Bottom;
            this.utils.setBottomBarHomepage(true);
        }
        else {
            this.showBottomDraw = true;
        }
    }
    openreviewPassed(id, designData) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.designId = id;
            const alert = yield this.alertController.create({
                cssClass: 'alertClass',
                header: 'Confirm!',
                message: 'Would you like to  Add Comments!!',
                inputs: [{ name: 'comment',
                        id: 'comment',
                        type: 'textarea',
                        placeholder: 'Enter Comment' }
                ],
                buttons: [
                    {
                        text: 'Cancel',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: (blah) => {
                            console.log('Confirm Cancel: blah');
                        }
                    }, {
                        text: 'deliver',
                        handler: (alertData) => {
                            var postData = {};
                            if (alertData.comment != "") {
                                postData = {
                                    status: "delivered",
                                    comments: alertData.comment,
                                };
                            }
                            else {
                                postData = {
                                    status: "delivered",
                                };
                            }
                            console.log(postData);
                            this.apiService.updateDesignForm(postData, this.designId).subscribe((value) => {
                                this.utils.hideLoading().then(() => {
                                    ;
                                    console.log('reach ', value);
                                    this.utils.showSnackBar('Design request has been delivered successfully');
                                    this.utils.setHomepageDesignRefresh(true);
                                });
                            }, (error) => {
                                this.utils.hideLoading();
                                ;
                            });
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    refreshDesigns(event) {
        let showLoader = true;
        if (event !== null && event !== undefined) {
            showLoader = false;
        }
        this.fetchPendingDesigns(event, showLoader);
    }
    accept(id, data) {
        let status = {
            status: data
        };
        this.apiService.updateDesignForm(status, id).subscribe((res) => {
            this.getDesigns(null);
        });
    }
    decline(id) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: src_app_declinepage_declinepage_page__WEBPACK_IMPORTED_MODULE_11__["DeclinepagePage"],
                cssClass: 'my-custom-modal-css',
                componentProps: {
                    id: id
                },
                backdropDismiss: false
            });
            modal.onDidDismiss().then((data) => {
                console.log(data);
                if (data.data.cancel == 'cancel') {
                }
                else {
                    this.getDesigns(null);
                }
            });
            // modal.dismiss(() => {
            //   ;
            //   this.getDesigns(null);
            // });
            return yield modal.present();
        });
    }
    sDatePassed(datestring, i) {
        var checkdate = moment__WEBPACK_IMPORTED_MODULE_12__(datestring, "YYYYMMDD");
        var todaydate = moment__WEBPACK_IMPORTED_MODULE_12__(new Date(), "YYYYMMDD");
        var lateby = todaydate.diff(checkdate, "days");
        this.overdue = lateby;
    }
    pending(value) {
        ;
        if (this.userData.role.type == 'SuperAdmin') {
            value = "requesttype=prelim&status=created&status=outsourced&status=requestaccepted&status=requestdeclined";
        }
        else {
            value = "requesttype=prelim&status=created&status=outsourced&status=requestaccepted";
        }
    }
    getassignedata(asssignedata) {
        this.selectedDesigner = asssignedata;
    }
    shareWhatsapp(designData) {
        this.socialsharing.share(designData.prelimdesign.url);
    }
    shareViaEmails(id, designData) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: src_app_email_model_email_model_page__WEBPACK_IMPORTED_MODULE_16__["EmailModelPage"],
                cssClass: 'email-modal-css',
                componentProps: {
                    id: id,
                    designData: designData
                },
            });
            modal.onDidDismiss().then((data) => {
                console.log(data);
                if (data.data.cancel == 'cancel') {
                }
                else {
                    this.getDesigns(null);
                }
            });
            return yield modal.present();
        });
    }
};
DesignComponent.ctorParameters = () => [
    { type: src_app_utilities_service__WEBPACK_IMPORTED_MODULE_3__["UtilitiesService"] },
    { type: src_app_api_service__WEBPACK_IMPORTED_MODULE_2__["ApiService"] },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_4__["DatePipe"] },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_9__["Storage"] },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"] },
    { type: _ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_5__["LaunchNavigator"] },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormBuilder"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_8__["ActivatedRoute"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_8__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_10__["ModalController"] },
    { type: src_app_storage_service__WEBPACK_IMPORTED_MODULE_13__["StorageService"] },
    { type: src_app_networkdetect_service__WEBPACK_IMPORTED_MODULE_14__["NetworkdetectService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_10__["AlertController"] },
    { type: _ionic_native_social_sharing_ngx__WEBPACK_IMPORTED_MODULE_15__["SocialSharing"] }
];
DesignComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-design',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./design.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/homepage/design/design.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./design.component.scss */ "./src/app/homepage/design/design.component.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_utilities_service__WEBPACK_IMPORTED_MODULE_3__["UtilitiesService"],
        src_app_api_service__WEBPACK_IMPORTED_MODULE_2__["ApiService"],
        _angular_common__WEBPACK_IMPORTED_MODULE_4__["DatePipe"],
        _ionic_storage__WEBPACK_IMPORTED_MODULE_9__["Storage"],
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"],
        _ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_5__["LaunchNavigator"],
        _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormBuilder"],
        _angular_router__WEBPACK_IMPORTED_MODULE_8__["ActivatedRoute"],
        _angular_router__WEBPACK_IMPORTED_MODULE_8__["Router"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_10__["ModalController"],
        src_app_storage_service__WEBPACK_IMPORTED_MODULE_13__["StorageService"],
        src_app_networkdetect_service__WEBPACK_IMPORTED_MODULE_14__["NetworkdetectService"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_10__["AlertController"],
        _ionic_native_social_sharing_ngx__WEBPACK_IMPORTED_MODULE_15__["SocialSharing"]])
], DesignComponent);

class DesginDataHelper {
    constructor() {
        this.listOfDesigns = [];
    }
    shareDesign() {
    }
}


/***/ })

}]);
//# sourceMappingURL=default~designoverview-designoverview-module~homepage-homepage-module~searchbar-searchbar-module-es2015.js.map