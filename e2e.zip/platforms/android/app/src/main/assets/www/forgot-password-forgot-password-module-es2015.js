(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["forgot-password-forgot-password-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/forgot-password/forgot-password.page.html":
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/forgot-password/forgot-password.page.html ***!
  \*************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header class=\"ion-no-border\">\r\n    <ion-grid class=\"ion-padding header-bg\">\r\n        <ion-row class=\"ion-margin-top\">\r\n            <ion-col size=\"auto\">\r\n                <ion-button fill=\"clear\" size=\"small\" class=\"ion-no-padding\" (click)=\"goBack()\">\r\n                    <ion-img src=\"/assets/images/back.svg\" class=\"action-icon\"></ion-img>\r\n                </ion-button>\r\n            </ion-col>\r\n            <ion-col>\r\n                <ion-grid class=\"ion-align-items-center ion-justify-content-center\">\r\n                    <ion-row class=\"ion-align-items-center ion-justify-content-center\">\r\n                        <span class=\"title\">Forgot password</span>\r\n                    </ion-row>\r\n                </ion-grid>\r\n            </ion-col>\r\n            <ion-col size=\"auto\">\r\n                <ion-button fill=\"clear\" disabled=\"true\" size=\"small\" class=\"ion-no-padding action-icon\">\r\n                </ion-button>\r\n            </ion-col>\r\n        </ion-row>\r\n    </ion-grid>\r\n\r\n    <ion-grid class=\"position-relative ion-no-padding\">\r\n        <ion-row class=\"ion-no-padding border-header header-half-height\">\r\n        </ion-row>\r\n        <ion-row class=\"ion-no-padding header-half-height\">\r\n        </ion-row>\r\n        <ion-row class=\"ion-no-padding position-absolute header-icon-position full-width\">\r\n            <ion-col class=\"flex-center\">\r\n                <ion-img src=\"/assets/images/forgot.svg\" class=\"header-icon\"></ion-img>\r\n            </ion-col>\r\n        </ion-row>\r\n    </ion-grid>\r\n</ion-header>\r\n<ion-content>\r\n    <div class=\"ion-padding\">\r\n        <ion-grid class=\"ion-padding\">\r\n            <form [formGroup]=\"forgotPasswordForm\" novalidate>\r\n                <ion-row>\r\n                    <ion-col size=\"12\">\r\n                        <span class=\"title-text\">Having trouble logging in?</span>\r\n                    </ion-col>\r\n                    <ion-col size=\"12\">\r\n                        <span class=\"normal-text\">To reset your password, enter your wattmonk registered email\r\n                            address.</span>\r\n                    </ion-col>\r\n\r\n                    <ion-col size=\"12\" class=\"ion-margin-top ion-no-padding\">\r\n                        <ion-item class=\"ion-no-padding\">\r\n                            <ion-input type=\"email\" placeholder=\"your email address\"\r\n                                       class=\"form_input\" autocomplete=\"off\"\r\n                                       formControlName=\"email\">\r\n                            </ion-input>\r\n                        </ion-item>\r\n                        <div class=\"error_div\">\r\n                            <div  *ngIf=\"forgotPasswordForm.get('email').hasError('pattern') && forgotPasswordForm.get('email').dirty\">\r\n                                <span class=\"error\">{{emailError}}</span>\r\n                            </div>       \r\n                        </div>  \r\n                        <div class=\"error_div\">\r\n                            <div *ngIf=\"forgotPasswordForm.get('email').value === '' && forgotPasswordForm.get('email').dirty\">\r\n                                <span class=\"error\">{{fieldRequired}}</span>\r\n                            </div>       \r\n                        </div>  \r\n\r\n                    </ion-col>\r\n                    <ion-col size=\"12\" class=\"large-margin\">\r\n                        <span class=\"small-text\">Steps to follow:-</span>\r\n                    </ion-col>\r\n                    <ion-col size=\"12\" class=\"ion-no-margin ion-no-padding\">\r\n                        <ol class=\"smaller-text\">\r\n                            <li>Reset password link will be shared to your registered email.</li>\r\n                            <li>Click on the link to reset your password instantly.</li>\r\n                            <li>The link is valid for 24 hours.</li>\r\n                        </ol>\r\n                    </ion-col>\r\n\r\n                    <ion-col size=\"12\" class=\"large-margin\">\r\n                        <span class=\"ion-padding-top ion-padding-bottom submit-text action-button-color\"\r\n                              (click)=\"resendPassword()\">Continue</span>\r\n                    </ion-col>\r\n\r\n                </ion-row>\r\n            </form>\r\n        </ion-grid>\r\n    </div>\r\n\r\n</ion-content>\r\n");

/***/ }),

/***/ "./src/app/forgot-password/forgot-password-routing.module.ts":
/*!*******************************************************************!*\
  !*** ./src/app/forgot-password/forgot-password-routing.module.ts ***!
  \*******************************************************************/
/*! exports provided: ForgotPasswordPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ForgotPasswordPageRoutingModule", function() { return ForgotPasswordPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _forgot_password_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./forgot-password.page */ "./src/app/forgot-password/forgot-password.page.ts");




const routes = [
    {
        path: '',
        component: _forgot_password_page__WEBPACK_IMPORTED_MODULE_3__["ForgotPasswordPage"]
    }
];
let ForgotPasswordPageRoutingModule = class ForgotPasswordPageRoutingModule {
};
ForgotPasswordPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], ForgotPasswordPageRoutingModule);



/***/ }),

/***/ "./src/app/forgot-password/forgot-password.module.ts":
/*!***********************************************************!*\
  !*** ./src/app/forgot-password/forgot-password.module.ts ***!
  \***********************************************************/
/*! exports provided: ForgotPasswordPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ForgotPasswordPageModule", function() { return ForgotPasswordPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _forgot_password_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./forgot-password-routing.module */ "./src/app/forgot-password/forgot-password-routing.module.ts");
/* harmony import */ var _forgot_password_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./forgot-password.page */ "./src/app/forgot-password/forgot-password.page.ts");







let ForgotPasswordPageModule = class ForgotPasswordPageModule {
};
ForgotPasswordPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _forgot_password_routing_module__WEBPACK_IMPORTED_MODULE_5__["ForgotPasswordPageRoutingModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"]
        ],
        declarations: [_forgot_password_page__WEBPACK_IMPORTED_MODULE_6__["ForgotPasswordPage"]]
    })
], ForgotPasswordPageModule);



/***/ }),

/***/ "./src/app/forgot-password/forgot-password.page.scss":
/*!***********************************************************!*\
  !*** ./src/app/forgot-password/forgot-password.page.scss ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".title {\n  font-size: 22px;\n  text-align: center;\n  color: #666666;\n}\n\n* {\n  color: #9A9A9A;\n}\n\n.image-area {\n  margin-top: 1em;\n  width: 3em;\n  height: 3em;\n  background: white;\n  border-radius: 0.5em;\n  box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.5);\n}\n\n.small-padding {\n  padding: 8px;\n}\n\n.title-text {\n  font-size: 1.3em;\n}\n\n.normal-text {\n  font-size: 1em;\n}\n\n.large-margin {\n  margin-top: 3em;\n}\n\n.small-text {\n  font-size: 0.95em;\n}\n\n.smaller-text {\n  font-size: 0.85em;\n}\n\n.submit-text {\n  font-size: 1.5em;\n}\n\nol {\n  -webkit-padding-start: 20px;\n          padding-inline-start: 20px;\n  -webkit-margin-before: 0;\n          margin-block-start: 0;\n  -webkit-margin-after: 0;\n          margin-block-end: 0;\n}\n\n.error {\n  color: #df3e3e;\n  font-size: 11px;\n}\n\n.error1 {\n  color: #4b4b4b;\n  border-bottom: 1px solid #ff0000;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZm9yZ290LXBhc3N3b3JkL0Y6XFxtb2JpbGVhcHAvc3JjXFxhcHBcXGZvcmdvdC1wYXNzd29yZFxcZm9yZ290LXBhc3N3b3JkLnBhZ2Uuc2NzcyIsInNyYy9hcHAvZm9yZ290LXBhc3N3b3JkL2ZvcmdvdC1wYXNzd29yZC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxjQUFBO0FDQ0Y7O0FERUE7RUFDRSxjQUFBO0FDQ0Y7O0FERUE7RUFDRSxlQUFBO0VBQ0EsVUFBQTtFQUNBLFdBQUE7RUFDQSxpQkFBQTtFQUNBLG9CQUFBO0VBQ0EsMENBQUE7QUNDRjs7QURFQTtFQUNFLFlBQUE7QUNDRjs7QURFQTtFQUNFLGdCQUFBO0FDQ0Y7O0FERUE7RUFDRSxjQUFBO0FDQ0Y7O0FERUE7RUFDRSxlQUFBO0FDQ0Y7O0FERUE7RUFDRSxpQkFBQTtBQ0NGOztBREVBO0VBQ0UsaUJBQUE7QUNDRjs7QURFQTtFQUNFLGdCQUFBO0FDQ0Y7O0FERUE7RUFDRSwyQkFBQTtVQUFBLDBCQUFBO0VBQ0Esd0JBQUE7VUFBQSxxQkFBQTtFQUNBLHVCQUFBO1VBQUEsbUJBQUE7QUNDRjs7QURFQTtFQUNFLGNBQUE7RUFDQSxlQUFBO0FDQ0Y7O0FERUE7RUFDRSxjQUFBO0VBQ0EsZ0NBQUE7QUNDRiIsImZpbGUiOiJzcmMvYXBwL2ZvcmdvdC1wYXNzd29yZC9mb3Jnb3QtcGFzc3dvcmQucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnRpdGxlIHtcclxuICBmb250LXNpemU6IDIycHg7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIGNvbG9yOiAjNjY2NjY2O1xyXG59XHJcblxyXG4qIHtcclxuICBjb2xvcjogIzlBOUE5QTtcclxufVxyXG5cclxuLmltYWdlLWFyZWEge1xyXG4gIG1hcmdpbi10b3A6IDFlbTtcclxuICB3aWR0aDogM2VtO1xyXG4gIGhlaWdodDogM2VtO1xyXG4gIGJhY2tncm91bmQ6IHdoaXRlO1xyXG4gIGJvcmRlci1yYWRpdXM6IDAuNWVtO1xyXG4gIGJveC1zaGFkb3c6IDAgMXB4IDNweCAwIHJnYmEoMCwgMCwgMCwgMC41KTtcclxufVxyXG5cclxuLnNtYWxsLXBhZGRpbmcge1xyXG4gIHBhZGRpbmc6IDhweDtcclxufVxyXG5cclxuLnRpdGxlLXRleHQge1xyXG4gIGZvbnQtc2l6ZTogMS4zZW07XHJcbn1cclxuXHJcbi5ub3JtYWwtdGV4dCB7XHJcbiAgZm9udC1zaXplOiAxZW07XHJcbn1cclxuXHJcbi5sYXJnZS1tYXJnaW4ge1xyXG4gIG1hcmdpbi10b3A6IDNlbTtcclxufVxyXG5cclxuLnNtYWxsLXRleHQge1xyXG4gIGZvbnQtc2l6ZTogMC45NWVtO1xyXG59XHJcblxyXG4uc21hbGxlci10ZXh0IHtcclxuICBmb250LXNpemU6IDAuODVlbTtcclxufVxyXG5cclxuLnN1Ym1pdC10ZXh0IHtcclxuICBmb250LXNpemU6IDEuNWVtO1xyXG59XHJcblxyXG5vbCB7XHJcbiAgcGFkZGluZy1pbmxpbmUtc3RhcnQ6IDIwcHg7XHJcbiAgbWFyZ2luLWJsb2NrLXN0YXJ0OiAwO1xyXG4gIG1hcmdpbi1ibG9jay1lbmQ6IDA7XHJcbn1cclxuXHJcbi5lcnJvciB7XHJcbiAgY29sb3I6IHJnYigyMjMsIDYyLCA2Mik7XHJcbiAgZm9udC1zaXplOiAxMXB4O1xyXG59XHJcblxyXG4uZXJyb3IxIHtcclxuICBjb2xvcjogcmdiKDc1LCA3NSwgNzUpO1xyXG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZmYwMDAwO1xyXG59XHJcbiIsIi50aXRsZSB7XG4gIGZvbnQtc2l6ZTogMjJweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBjb2xvcjogIzY2NjY2Njtcbn1cblxuKiB7XG4gIGNvbG9yOiAjOUE5QTlBO1xufVxuXG4uaW1hZ2UtYXJlYSB7XG4gIG1hcmdpbi10b3A6IDFlbTtcbiAgd2lkdGg6IDNlbTtcbiAgaGVpZ2h0OiAzZW07XG4gIGJhY2tncm91bmQ6IHdoaXRlO1xuICBib3JkZXItcmFkaXVzOiAwLjVlbTtcbiAgYm94LXNoYWRvdzogMCAxcHggM3B4IDAgcmdiYSgwLCAwLCAwLCAwLjUpO1xufVxuXG4uc21hbGwtcGFkZGluZyB7XG4gIHBhZGRpbmc6IDhweDtcbn1cblxuLnRpdGxlLXRleHQge1xuICBmb250LXNpemU6IDEuM2VtO1xufVxuXG4ubm9ybWFsLXRleHQge1xuICBmb250LXNpemU6IDFlbTtcbn1cblxuLmxhcmdlLW1hcmdpbiB7XG4gIG1hcmdpbi10b3A6IDNlbTtcbn1cblxuLnNtYWxsLXRleHQge1xuICBmb250LXNpemU6IDAuOTVlbTtcbn1cblxuLnNtYWxsZXItdGV4dCB7XG4gIGZvbnQtc2l6ZTogMC44NWVtO1xufVxuXG4uc3VibWl0LXRleHQge1xuICBmb250LXNpemU6IDEuNWVtO1xufVxuXG5vbCB7XG4gIHBhZGRpbmctaW5saW5lLXN0YXJ0OiAyMHB4O1xuICBtYXJnaW4tYmxvY2stc3RhcnQ6IDA7XG4gIG1hcmdpbi1ibG9jay1lbmQ6IDA7XG59XG5cbi5lcnJvciB7XG4gIGNvbG9yOiAjZGYzZTNlO1xuICBmb250LXNpemU6IDExcHg7XG59XG5cbi5lcnJvcjEge1xuICBjb2xvcjogIzRiNGI0YjtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNmZjAwMDA7XG59Il19 */");

/***/ }),

/***/ "./src/app/forgot-password/forgot-password.page.ts":
/*!*********************************************************!*\
  !*** ./src/app/forgot-password/forgot-password.page.ts ***!
  \*********************************************************/
/*! exports provided: ForgotPasswordPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ForgotPasswordPage", function() { return ForgotPasswordPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _utilities_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../utilities.service */ "./src/app/utilities.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _api_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../api.service */ "./src/app/api.service.ts");
/* harmony import */ var _model_constants__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../model/constants */ "./src/app/model/constants.ts");







let ForgotPasswordPage = class ForgotPasswordPage {
    constructor(formBuilder, utils, navController, apiService) {
        this.formBuilder = formBuilder;
        this.utils = utils;
        this.navController = navController;
        this.apiService = apiService;
        // error messages from constants
        this.emailError = _model_constants__WEBPACK_IMPORTED_MODULE_6__["INVALID_EMAIL_MESSAGE"];
        this.fieldRequired = _model_constants__WEBPACK_IMPORTED_MODULE_6__["FIELD_REQUIRED"];
    }
    ngOnInit() {
        const EMAILPATTERN = /^[a-z0-9!#$%&'*+\/=?^_`{|}~.-]+@[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)*$/i;
        this.forgotPasswordForm = this.formBuilder.group({
            email: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].pattern(EMAILPATTERN)]),
        });
    }
    resendPassword() {
        if (this.forgotPasswordForm.status === 'VALID') {
            this.utils.showLoading('Sending password Link').then(() => {
                this.apiService.sendForgotPasswordLink(this.forgotPasswordForm.value).subscribe((response) => {
                    this.utils.hideLoading().then(() => {
                        this.utils.showSuccessModal('Password link sent successfully').then((modal) => {
                            modal.present();
                            modal.onWillDismiss().then((dismissed) => {
                                this.goBack();
                            });
                        }, (error) => {
                        });
                    });
                }, (responseError) => {
                    const error = responseError.error;
                    this.utils.hideLoading().then(() => {
                        this.utils.errorSnackBar(error.message[0].messages[0].message);
                    });
                });
            });
        }
        else {
            this.utils.errorSnackBar('Invalid Email address');
        }
    }
    goBack() {
        this.navController.navigateBack('login');
    }
};
ForgotPasswordPage.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"] },
    { type: _utilities_service__WEBPACK_IMPORTED_MODULE_3__["UtilitiesService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"] },
    { type: _api_service__WEBPACK_IMPORTED_MODULE_5__["ApiService"] }
];
ForgotPasswordPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-forgot-password',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./forgot-password.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/forgot-password/forgot-password.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./forgot-password.page.scss */ "./src/app/forgot-password/forgot-password.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"],
        _utilities_service__WEBPACK_IMPORTED_MODULE_3__["UtilitiesService"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"],
        _api_service__WEBPACK_IMPORTED_MODULE_5__["ApiService"]])
], ForgotPasswordPage);



/***/ })

}]);
//# sourceMappingURL=forgot-password-forgot-password-module-es2015.js.map