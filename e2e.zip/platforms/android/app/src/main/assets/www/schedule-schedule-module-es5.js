function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["schedule-schedule-module"], {
  /***/
  "./node_modules/@ionic-native/Camera/ngx/index.js":
  /*!********************************************************!*\
    !*** ./node_modules/@ionic-native/Camera/ngx/index.js ***!
    \********************************************************/

  /*! exports provided: DestinationType, EncodingType, MediaType, PictureSourceType, PopoverArrowDirection, Direction, Camera */

  /***/
  function node_modulesIonicNativeCameraNgxIndexJs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DestinationType", function () {
      return DestinationType;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "EncodingType", function () {
      return EncodingType;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MediaType", function () {
      return MediaType;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "PictureSourceType", function () {
      return PictureSourceType;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "PopoverArrowDirection", function () {
      return PopoverArrowDirection;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Direction", function () {
      return Direction;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Camera", function () {
      return Camera;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _ionic_native_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic-native/core */
    "./node_modules/@ionic-native/core/index.js");

    var DestinationType;

    (function (DestinationType) {
      DestinationType[DestinationType["DATA_URL"] = 0] = "DATA_URL";
      DestinationType[DestinationType["FILE_URL"] = 1] = "FILE_URL";
      DestinationType[DestinationType["NATIVE_URI"] = 2] = "NATIVE_URI";
    })(DestinationType || (DestinationType = {}));

    var EncodingType;

    (function (EncodingType) {
      EncodingType[EncodingType["JPEG"] = 0] = "JPEG";
      EncodingType[EncodingType["PNG"] = 1] = "PNG";
    })(EncodingType || (EncodingType = {}));

    var MediaType;

    (function (MediaType) {
      MediaType[MediaType["PICTURE"] = 0] = "PICTURE";
      MediaType[MediaType["VIDEO"] = 1] = "VIDEO";
      MediaType[MediaType["ALLMEDIA"] = 2] = "ALLMEDIA";
    })(MediaType || (MediaType = {}));

    var PictureSourceType;

    (function (PictureSourceType) {
      PictureSourceType[PictureSourceType["PHOTOLIBRARY"] = 0] = "PHOTOLIBRARY";
      PictureSourceType[PictureSourceType["CAMERA"] = 1] = "CAMERA";
      PictureSourceType[PictureSourceType["SAVEDPHOTOALBUM"] = 2] = "SAVEDPHOTOALBUM";
    })(PictureSourceType || (PictureSourceType = {}));

    var PopoverArrowDirection;

    (function (PopoverArrowDirection) {
      PopoverArrowDirection[PopoverArrowDirection["ARROW_UP"] = 1] = "ARROW_UP";
      PopoverArrowDirection[PopoverArrowDirection["ARROW_DOWN"] = 2] = "ARROW_DOWN";
      PopoverArrowDirection[PopoverArrowDirection["ARROW_LEFT"] = 3] = "ARROW_LEFT";
      PopoverArrowDirection[PopoverArrowDirection["ARROW_RIGHT"] = 4] = "ARROW_RIGHT";
      PopoverArrowDirection[PopoverArrowDirection["ARROW_ANY"] = 5] = "ARROW_ANY";
    })(PopoverArrowDirection || (PopoverArrowDirection = {}));

    var Direction;

    (function (Direction) {
      Direction[Direction["BACK"] = 0] = "BACK";
      Direction[Direction["FRONT"] = 1] = "FRONT";
    })(Direction || (Direction = {}));

    var Camera =
    /** @class */
    function (_super) {
      Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(Camera, _super);

      function Camera() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        /**
         * Constant for possible destination types
         */


        _this.DestinationType = {
          /** Return base64 encoded string. DATA_URL can be very memory intensive and cause app crashes or out of memory errors. Use FILE_URI or NATIVE_URI if possible */
          DATA_URL: 0,

          /** Return file uri (content://media/external/images/media/2 for Android) */
          FILE_URI: 1,

          /** Return native uri (eg. asset-library://... for iOS) */
          NATIVE_URI: 2
        };
        /**
         * Convenience constant
         */

        _this.EncodingType = {
          /** Return JPEG encoded image */
          JPEG: 0,

          /** Return PNG encoded image */
          PNG: 1
        };
        /**
         * Convenience constant
         */

        _this.MediaType = {
          /** Allow selection of still pictures only. DEFAULT. Will return format specified via DestinationType */
          PICTURE: 0,

          /** Allow selection of video only, ONLY RETURNS URL */
          VIDEO: 1,

          /** Allow selection from all media types */
          ALLMEDIA: 2
        };
        /**
         * Convenience constant
         */

        _this.PictureSourceType = {
          /** Choose image from picture library (same as PHOTOLIBRARY for Android) */
          PHOTOLIBRARY: 0,

          /** Take picture from camera */
          CAMERA: 1,

          /** Choose image from picture library (same as SAVEDPHOTOALBUM for Android) */
          SAVEDPHOTOALBUM: 2
        };
        /**
         * Convenience constant
         */

        _this.PopoverArrowDirection = {
          ARROW_UP: 1,
          ARROW_DOWN: 2,
          ARROW_LEFT: 4,
          ARROW_RIGHT: 8,
          ARROW_ANY: 15
        };
        /**
         * Convenience constant
         */

        _this.Direction = {
          /** Use the back-facing camera */
          BACK: 0,

          /** Use the front-facing camera */
          FRONT: 1
        };
        return _this;
      }

      Camera.prototype.getPicture = function (options) {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "getPicture", {
          "callbackOrder": "reverse"
        }, arguments);
      };

      Camera.prototype.cleanup = function () {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "cleanup", {
          "platforms": ["iOS"]
        }, arguments);
      };

      Camera.pluginName = "Camera";
      Camera.plugin = "cordova-plugin-camera";
      Camera.pluginRef = "navigator.camera";
      Camera.repo = "https://github.com/apache/cordova-plugin-camera";
      Camera.platforms = ["Android", "Browser", "iOS", "Windows"];
      Camera = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])()], Camera);
      return Camera;
    }(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["IonicNativePlugin"]); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvQGlvbmljLW5hdGl2ZS9wbHVnaW5zL2NhbWVyYS9uZ3gvaW5kZXgudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDM0MsT0FBTyw4QkFBc0MsTUFBTSxvQkFBb0IsQ0FBQztBQXNGeEUsTUFBTSxDQUFOLElBQVksZUFJWDtBQUpELFdBQVksZUFBZTtJQUN6Qiw2REFBWSxDQUFBO0lBQ1osNkRBQVEsQ0FBQTtJQUNSLGlFQUFVLENBQUE7QUFDWixDQUFDLEVBSlcsZUFBZSxLQUFmLGVBQWUsUUFJMUI7QUFFRCxNQUFNLENBQU4sSUFBWSxZQUdYO0FBSEQsV0FBWSxZQUFZO0lBQ3RCLCtDQUFRLENBQUE7SUFDUiw2Q0FBRyxDQUFBO0FBQ0wsQ0FBQyxFQUhXLFlBQVksS0FBWixZQUFZLFFBR3ZCO0FBRUQsTUFBTSxDQUFOLElBQVksU0FJWDtBQUpELFdBQVksU0FBUztJQUNuQiwrQ0FBVyxDQUFBO0lBQ1gsMkNBQUssQ0FBQTtJQUNMLGlEQUFRLENBQUE7QUFDVixDQUFDLEVBSlcsU0FBUyxLQUFULFNBQVMsUUFJcEI7QUFFRCxNQUFNLENBQU4sSUFBWSxpQkFJWDtBQUpELFdBQVksaUJBQWlCO0lBQzNCLHlFQUFnQixDQUFBO0lBQ2hCLDZEQUFNLENBQUE7SUFDTiwrRUFBZSxDQUFBO0FBQ2pCLENBQUMsRUFKVyxpQkFBaUIsS0FBakIsaUJBQWlCLFFBSTVCO0FBRUQsTUFBTSxDQUFOLElBQVkscUJBTVg7QUFORCxXQUFZLHFCQUFxQjtJQUMvQix5RUFBWSxDQUFBO0lBQ1osNkVBQVUsQ0FBQTtJQUNWLDZFQUFVLENBQUE7SUFDViwrRUFBVyxDQUFBO0lBQ1gsMkVBQVMsQ0FBQTtBQUNYLENBQUMsRUFOVyxxQkFBcUIsS0FBckIscUJBQXFCLFFBTWhDO0FBRUQsTUFBTSxDQUFOLElBQVksU0FHWDtBQUhELFdBQVksU0FBUztJQUNuQix5Q0FBUSxDQUFBO0lBQ1IsMkNBQUssQ0FBQTtBQUNQLENBQUMsRUFIVyxTQUFTLEtBQVQsU0FBUyxRQUdwQjs7SUFzRDJCLDBCQUFpQjs7O1FBQzNDOztXQUVHO1FBQ0gscUJBQWUsR0FBRztZQUNoQixnS0FBZ0s7WUFDaEssUUFBUSxFQUFFLENBQUM7WUFDWCw0RUFBNEU7WUFDNUUsUUFBUSxFQUFFLENBQUM7WUFDWCwwREFBMEQ7WUFDMUQsVUFBVSxFQUFFLENBQUM7U0FDZCxDQUFDO1FBRUY7O1dBRUc7UUFDSCxrQkFBWSxHQUFHO1lBQ2IsZ0NBQWdDO1lBQ2hDLElBQUksRUFBRSxDQUFDO1lBQ1AsK0JBQStCO1lBQy9CLEdBQUcsRUFBRSxDQUFDO1NBQ1AsQ0FBQztRQUVGOztXQUVHO1FBQ0gsZUFBUyxHQUFHO1lBQ1Ysd0dBQXdHO1lBQ3hHLE9BQU8sRUFBRSxDQUFDO1lBQ1Ysc0RBQXNEO1lBQ3RELEtBQUssRUFBRSxDQUFDO1lBQ1IsMkNBQTJDO1lBQzNDLFFBQVEsRUFBRSxDQUFDO1NBQ1osQ0FBQztRQUVGOztXQUVHO1FBQ0gsdUJBQWlCLEdBQUc7WUFDbEIsMkVBQTJFO1lBQzNFLFlBQVksRUFBRSxDQUFDO1lBQ2YsK0JBQStCO1lBQy9CLE1BQU0sRUFBRSxDQUFDO1lBQ1QsOEVBQThFO1lBQzlFLGVBQWUsRUFBRSxDQUFDO1NBQ25CLENBQUM7UUFFRjs7V0FFRztRQUNILDJCQUFxQixHQUFHO1lBQ3RCLFFBQVEsRUFBRSxDQUFDO1lBQ1gsVUFBVSxFQUFFLENBQUM7WUFDYixVQUFVLEVBQUUsQ0FBQztZQUNiLFdBQVcsRUFBRSxDQUFDO1lBQ2QsU0FBUyxFQUFFLEVBQUU7U0FDZCxDQUFDO1FBRUY7O1dBRUc7UUFDSCxlQUFTLEdBQUc7WUFDVixpQ0FBaUM7WUFDakMsSUFBSSxFQUFFLENBQUM7WUFDUCxrQ0FBa0M7WUFDbEMsS0FBSyxFQUFFLENBQUM7U0FDVCxDQUFDOzs7SUFVRiwyQkFBVSxhQUFDLE9BQXVCO0lBWWxDLHdCQUFPOzs7Ozs7SUF4RkksTUFBTTtRQURsQixVQUFVLEVBQUU7T0FDQSxNQUFNO2lCQS9LbkI7RUErSzRCLGlCQUFpQjtTQUFoQyxNQUFNIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQ29yZG92YSwgSW9uaWNOYXRpdmVQbHVnaW4sIFBsdWdpbiB9IGZyb20gJ0Bpb25pYy1uYXRpdmUvY29yZSc7XG5cbmV4cG9ydCBpbnRlcmZhY2UgQ2FtZXJhT3B0aW9ucyB7XG4gIC8qKiBQaWN0dXJlIHF1YWxpdHkgaW4gcmFuZ2UgMC0xMDAuIERlZmF1bHQgaXMgNTAgKi9cbiAgcXVhbGl0eT86IG51bWJlcjtcbiAgLyoqXG4gICAqIENob29zZSB0aGUgZm9ybWF0IG9mIHRoZSByZXR1cm4gdmFsdWUuXG4gICAqIERlZmluZWQgaW4gQ2FtZXJhLkRlc3RpbmF0aW9uVHlwZS4gRGVmYXVsdCBpcyBGSUxFX1VSSS5cbiAgICogICAgICBEQVRBX1VSTCA6IDAsICAgUmV0dXJuIGltYWdlIGFzIGJhc2U2NC1lbmNvZGVkIHN0cmluZyAoREFUQV9VUkwgY2FuIGJlIHZlcnkgbWVtb3J5IGludGVuc2l2ZSBhbmQgY2F1c2UgYXBwIGNyYXNoZXMgb3Igb3V0IG9mIG1lbW9yeSBlcnJvcnMuIFVzZSBGSUxFX1VSSSBvciBOQVRJVkVfVVJJIGlmIHBvc3NpYmxlKSxcbiAgICogICAgICBGSUxFX1VSSSA6IDEsICAgUmV0dXJuIGltYWdlIGZpbGUgVVJJLFxuICAgKiAgICAgIE5BVElWRV9VUkkgOiAyICBSZXR1cm4gaW1hZ2UgbmF0aXZlIFVSSVxuICAgKiAgICAgICAgICAoZS5nLiwgYXNzZXRzLWxpYnJhcnk6Ly8gb24gaU9TIG9yIGNvbnRlbnQ6Ly8gb24gQW5kcm9pZClcbiAgICovXG4gIGRlc3RpbmF0aW9uVHlwZT86IG51bWJlcjtcbiAgLyoqXG4gICAqIFNldCB0aGUgc291cmNlIG9mIHRoZSBwaWN0dXJlLlxuICAgKiBEZWZpbmVkIGluIENhbWVyYS5QaWN0dXJlU291cmNlVHlwZS4gRGVmYXVsdCBpcyBDQU1FUkEuXG4gICAqICAgICAgUEhPVE9MSUJSQVJZIDogMCxcbiAgICogICAgICBDQU1FUkEgOiAxLFxuICAgKiAgICAgIFNBVkVEUEhPVE9BTEJVTSA6IDJcbiAgICovXG4gIHNvdXJjZVR5cGU/OiBudW1iZXI7XG4gIC8qKiBBbGxvdyBzaW1wbGUgZWRpdGluZyBvZiBpbWFnZSBiZWZvcmUgc2VsZWN0aW9uLiAqL1xuICBhbGxvd0VkaXQ/OiBib29sZWFuO1xuICAvKipcbiAgICogQ2hvb3NlIHRoZSByZXR1cm5lZCBpbWFnZSBmaWxlJ3MgZW5jb2RpbmcuXG4gICAqIERlZmluZWQgaW4gQ2FtZXJhLkVuY29kaW5nVHlwZS4gRGVmYXVsdCBpcyBKUEVHXG4gICAqICAgICAgSlBFRyA6IDAgICAgUmV0dXJuIEpQRUcgZW5jb2RlZCBpbWFnZVxuICAgKiAgICAgIFBORyA6IDEgICAgIFJldHVybiBQTkcgZW5jb2RlZCBpbWFnZVxuICAgKi9cbiAgZW5jb2RpbmdUeXBlPzogbnVtYmVyO1xuICAvKipcbiAgICogV2lkdGggaW4gcGl4ZWxzIHRvIHNjYWxlIGltYWdlLiBNdXN0IGJlIHVzZWQgd2l0aCB0YXJnZXRIZWlnaHQuXG4gICAqIEFzcGVjdCByYXRpbyByZW1haW5zIGNvbnN0YW50LlxuICAgKi9cbiAgdGFyZ2V0V2lkdGg/OiBudW1iZXI7XG4gIC8qKlxuICAgKiBIZWlnaHQgaW4gcGl4ZWxzIHRvIHNjYWxlIGltYWdlLiBNdXN0IGJlIHVzZWQgd2l0aCB0YXJnZXRXaWR0aC5cbiAgICogQXNwZWN0IHJhdGlvIHJlbWFpbnMgY29uc3RhbnQuXG4gICAqL1xuICB0YXJnZXRIZWlnaHQ/OiBudW1iZXI7XG4gIC8qKlxuICAgKiBTZXQgdGhlIHR5cGUgb2YgbWVkaWEgdG8gc2VsZWN0IGZyb20uIE9ubHkgd29ya3Mgd2hlbiBQaWN0dXJlU291cmNlVHlwZVxuICAgKiBpcyBQSE9UT0xJQlJBUlkgb3IgU0FWRURQSE9UT0FMQlVNLiBEZWZpbmVkIGluIENhbWVyYS5NZWRpYVR5cGVcbiAgICogICAgICBQSUNUVVJFOiAwICAgICAgYWxsb3cgc2VsZWN0aW9uIG9mIHN0aWxsIHBpY3R1cmVzIG9ubHkuIERFRkFVTFQuXG4gICAqICAgICAgICAgIFdpbGwgcmV0dXJuIGZvcm1hdCBzcGVjaWZpZWQgdmlhIERlc3RpbmF0aW9uVHlwZVxuICAgKiAgICAgIFZJREVPOiAxICAgICAgICBhbGxvdyBzZWxlY3Rpb24gb2YgdmlkZW8gb25seSwgV0lMTCBBTFdBWVMgUkVUVVJOIEZJTEVfVVJJXG4gICAqICAgICAgQUxMTUVESUEgOiAyICAgIGFsbG93IHNlbGVjdGlvbiBmcm9tIGFsbCBtZWRpYSB0eXBlc1xuICAgKi9cbiAgbWVkaWFUeXBlPzogbnVtYmVyO1xuICAvKiogUm90YXRlIHRoZSBpbWFnZSB0byBjb3JyZWN0IGZvciB0aGUgb3JpZW50YXRpb24gb2YgdGhlIGRldmljZSBkdXJpbmcgY2FwdHVyZS4gKi9cbiAgY29ycmVjdE9yaWVudGF0aW9uPzogYm9vbGVhbjtcbiAgLyoqIFNhdmUgdGhlIGltYWdlIHRvIHRoZSBwaG90byBhbGJ1bSBvbiB0aGUgZGV2aWNlIGFmdGVyIGNhcHR1cmUuICovXG4gIHNhdmVUb1Bob3RvQWxidW0/OiBib29sZWFuO1xuICAvKipcbiAgICogQ2hvb3NlIHRoZSBjYW1lcmEgdG8gdXNlIChmcm9udC0gb3IgYmFjay1mYWNpbmcpLlxuICAgKiBEZWZpbmVkIGluIENhbWVyYS5EaXJlY3Rpb24uIERlZmF1bHQgaXMgQkFDSy5cbiAgICogICAgICBCQUNLOiAwXG4gICAqICAgICAgRlJPTlQ6IDFcbiAgICovXG4gIGNhbWVyYURpcmVjdGlvbj86IG51bWJlcjtcbiAgLyoqIGlPUy1vbmx5IG9wdGlvbnMgdGhhdCBzcGVjaWZ5IHBvcG92ZXIgbG9jYXRpb24gaW4gaVBhZC4gRGVmaW5lZCBpbiBDYW1lcmFQb3BvdmVyT3B0aW9ucy4gKi9cbiAgcG9wb3Zlck9wdGlvbnM/OiBDYW1lcmFQb3BvdmVyT3B0aW9ucztcbn1cblxuLyoqXG4gKiBpT1Mtb25seSBwYXJhbWV0ZXJzIHRoYXQgc3BlY2lmeSB0aGUgYW5jaG9yIGVsZW1lbnQgbG9jYXRpb24gYW5kIGFycm93IGRpcmVjdGlvblxuICogb2YgdGhlIHBvcG92ZXIgd2hlbiBzZWxlY3RpbmcgaW1hZ2VzIGZyb20gYW4gaVBhZCdzIGxpYnJhcnkgb3IgYWxidW0uXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ2FtZXJhUG9wb3Zlck9wdGlvbnMge1xuICB4OiBudW1iZXI7XG4gIHk6IG51bWJlcjtcbiAgd2lkdGg6IG51bWJlcjtcbiAgaGVpZ2h0OiBudW1iZXI7XG4gIC8qKlxuICAgKiBEaXJlY3Rpb24gdGhlIGFycm93IG9uIHRoZSBwb3BvdmVyIHNob3VsZCBwb2ludC4gRGVmaW5lZCBpbiBDYW1lcmEuUG9wb3ZlckFycm93RGlyZWN0aW9uXG4gICAqIE1hdGNoZXMgaU9TIFVJUG9wb3ZlckFycm93RGlyZWN0aW9uIGNvbnN0YW50cy5cbiAgICogICAgICBBUlJPV19VUCA6IDEsXG4gICAqICAgICAgQVJST1dfRE9XTiA6IDIsXG4gICAqICAgICAgQVJST1dfTEVGVCA6IDQsXG4gICAqICAgICAgQVJST1dfUklHSFQgOiA4LFxuICAgKiAgICAgIEFSUk9XX0FOWSA6IDE1XG4gICAqL1xuICBhcnJvd0RpcjogbnVtYmVyO1xufVxuXG5leHBvcnQgZW51bSBEZXN0aW5hdGlvblR5cGUge1xuICBEQVRBX1VSTCA9IDAsXG4gIEZJTEVfVVJMLFxuICBOQVRJVkVfVVJJLFxufVxuXG5leHBvcnQgZW51bSBFbmNvZGluZ1R5cGUge1xuICBKUEVHID0gMCxcbiAgUE5HLFxufVxuXG5leHBvcnQgZW51bSBNZWRpYVR5cGUge1xuICBQSUNUVVJFID0gMCxcbiAgVklERU8sXG4gIEFMTE1FRElBLFxufVxuXG5leHBvcnQgZW51bSBQaWN0dXJlU291cmNlVHlwZSB7XG4gIFBIT1RPTElCUkFSWSA9IDAsXG4gIENBTUVSQSxcbiAgU0FWRURQSE9UT0FMQlVNLFxufVxuXG5leHBvcnQgZW51bSBQb3BvdmVyQXJyb3dEaXJlY3Rpb24ge1xuICBBUlJPV19VUCA9IDEsXG4gIEFSUk9XX0RPV04sXG4gIEFSUk9XX0xFRlQsXG4gIEFSUk9XX1JJR0hULFxuICBBUlJPV19BTlksXG59XG5cbmV4cG9ydCBlbnVtIERpcmVjdGlvbiB7XG4gIEJBQ0sgPSAwLFxuICBGUk9OVCxcbn1cblxuLyoqXG4gKiBAbmFtZSBDYW1lcmFcbiAqIEBwcmVtaWVyIGNhbWVyYVxuICogQGRlc2NyaXB0aW9uXG4gKiBUYWtlIGEgcGhvdG8gb3IgY2FwdHVyZSB2aWRlby5cbiAqXG4gKiBSZXF1aXJlcyB0aGUgQ29yZG92YSBwbHVnaW46IGBjb3Jkb3ZhLXBsdWdpbi1jYW1lcmFgLiBGb3IgbW9yZSBpbmZvLCBwbGVhc2Ugc2VlIHRoZSBbQ29yZG92YSBDYW1lcmEgUGx1Z2luIERvY3NdKGh0dHBzOi8vZ2l0aHViLmNvbS9hcGFjaGUvY29yZG92YS1wbHVnaW4tY2FtZXJhKS5cbiAqXG4gKiBbV2FybmluZ10gU2luY2UgSU9TIDEwIHRoZSBjYW1lcmEgcmVxdWlyZXMgcGVybWlzc2lvbnMgdG8gYmUgcGxhY2VkIGluIHlvdXIgY29uZmlnLnhtbCBhZGRcbiAqIGBgYHhtbFxuICogPGNvbmZpZy1maWxlIHBhcmVudD1cIk5TQ2FtZXJhVXNhZ2VEZXNjcmlwdGlvblwiIHBsYXRmb3JtPVwiaW9zXCIgdGFyZ2V0PVwiKi1JbmZvLnBsaXN0XCI+XG4gKiAgPHN0cmluZz5Zb3UgY2FuIHRha2UgcGhvdG9zPC9zdHJpbmc+XG4gKiA8L2NvbmZpZy1maWxlPlxuICogYGBgXG4gKiBpbnNpZGUgb2YgdGhlIDxwbGF0Zm9ybSBuYW1lPSdpb3M+IHNlY3Rpb25cbiAqXG4gKiBAdXNhZ2VcbiAqIGBgYHR5cGVzY3JpcHRcbiAqIGltcG9ydCB7IENhbWVyYSwgQ2FtZXJhT3B0aW9ucyB9IGZyb20gJ0Bpb25pYy1uYXRpdmUvY2FtZXJhL25neCc7XG4gKlxuICogY29uc3RydWN0b3IocHJpdmF0ZSBjYW1lcmE6IENhbWVyYSkgeyB9XG4gKlxuICogLi4uXG4gKlxuICpcbiAqIGNvbnN0IG9wdGlvbnM6IENhbWVyYU9wdGlvbnMgPSB7XG4gKiAgIHF1YWxpdHk6IDEwMCxcbiAqICAgZGVzdGluYXRpb25UeXBlOiB0aGlzLmNhbWVyYS5EZXN0aW5hdGlvblR5cGUuRklMRV9VUkksXG4gKiAgIGVuY29kaW5nVHlwZTogdGhpcy5jYW1lcmEuRW5jb2RpbmdUeXBlLkpQRUcsXG4gKiAgIG1lZGlhVHlwZTogdGhpcy5jYW1lcmEuTWVkaWFUeXBlLlBJQ1RVUkVcbiAqIH1cbiAqXG4gKiB0aGlzLmNhbWVyYS5nZXRQaWN0dXJlKG9wdGlvbnMpLnRoZW4oKGltYWdlRGF0YSkgPT4ge1xuICogIC8vIGltYWdlRGF0YSBpcyBlaXRoZXIgYSBiYXNlNjQgZW5jb2RlZCBzdHJpbmcgb3IgYSBmaWxlIFVSSVxuICogIC8vIElmIGl0J3MgYmFzZTY0IChEQVRBX1VSTCk6XG4gKiAgbGV0IGJhc2U2NEltYWdlID0gJ2RhdGE6aW1hZ2UvanBlZztiYXNlNjQsJyArIGltYWdlRGF0YTtcbiAqIH0sIChlcnIpID0+IHtcbiAqICAvLyBIYW5kbGUgZXJyb3JcbiAqIH0pO1xuICogYGBgXG4gKiBAaW50ZXJmYWNlc1xuICogQ2FtZXJhT3B0aW9uc1xuICogQ2FtZXJhUG9wb3Zlck9wdGlvbnNcbiAqL1xuQFBsdWdpbih7XG4gIHBsdWdpbk5hbWU6ICdDYW1lcmEnLFxuICBwbHVnaW46ICdjb3Jkb3ZhLXBsdWdpbi1jYW1lcmEnLFxuICBwbHVnaW5SZWY6ICduYXZpZ2F0b3IuY2FtZXJhJyxcbiAgcmVwbzogJ2h0dHBzOi8vZ2l0aHViLmNvbS9hcGFjaGUvY29yZG92YS1wbHVnaW4tY2FtZXJhJyxcbiAgcGxhdGZvcm1zOiBbJ0FuZHJvaWQnLCAnQnJvd3NlcicsICdpT1MnLCAnV2luZG93cyddLFxufSlcbkBJbmplY3RhYmxlKClcbmV4cG9ydCBjbGFzcyBDYW1lcmEgZXh0ZW5kcyBJb25pY05hdGl2ZVBsdWdpbiB7XG4gIC8qKlxuICAgKiBDb25zdGFudCBmb3IgcG9zc2libGUgZGVzdGluYXRpb24gdHlwZXNcbiAgICovXG4gIERlc3RpbmF0aW9uVHlwZSA9IHtcbiAgICAvKiogUmV0dXJuIGJhc2U2NCBlbmNvZGVkIHN0cmluZy4gREFUQV9VUkwgY2FuIGJlIHZlcnkgbWVtb3J5IGludGVuc2l2ZSBhbmQgY2F1c2UgYXBwIGNyYXNoZXMgb3Igb3V0IG9mIG1lbW9yeSBlcnJvcnMuIFVzZSBGSUxFX1VSSSBvciBOQVRJVkVfVVJJIGlmIHBvc3NpYmxlICovXG4gICAgREFUQV9VUkw6IDAsXG4gICAgLyoqIFJldHVybiBmaWxlIHVyaSAoY29udGVudDovL21lZGlhL2V4dGVybmFsL2ltYWdlcy9tZWRpYS8yIGZvciBBbmRyb2lkKSAqL1xuICAgIEZJTEVfVVJJOiAxLFxuICAgIC8qKiBSZXR1cm4gbmF0aXZlIHVyaSAoZWcuIGFzc2V0LWxpYnJhcnk6Ly8uLi4gZm9yIGlPUykgKi9cbiAgICBOQVRJVkVfVVJJOiAyLFxuICB9O1xuXG4gIC8qKlxuICAgKiBDb252ZW5pZW5jZSBjb25zdGFudFxuICAgKi9cbiAgRW5jb2RpbmdUeXBlID0ge1xuICAgIC8qKiBSZXR1cm4gSlBFRyBlbmNvZGVkIGltYWdlICovXG4gICAgSlBFRzogMCxcbiAgICAvKiogUmV0dXJuIFBORyBlbmNvZGVkIGltYWdlICovXG4gICAgUE5HOiAxLFxuICB9O1xuXG4gIC8qKlxuICAgKiBDb252ZW5pZW5jZSBjb25zdGFudFxuICAgKi9cbiAgTWVkaWFUeXBlID0ge1xuICAgIC8qKiBBbGxvdyBzZWxlY3Rpb24gb2Ygc3RpbGwgcGljdHVyZXMgb25seS4gREVGQVVMVC4gV2lsbCByZXR1cm4gZm9ybWF0IHNwZWNpZmllZCB2aWEgRGVzdGluYXRpb25UeXBlICovXG4gICAgUElDVFVSRTogMCxcbiAgICAvKiogQWxsb3cgc2VsZWN0aW9uIG9mIHZpZGVvIG9ubHksIE9OTFkgUkVUVVJOUyBVUkwgKi9cbiAgICBWSURFTzogMSxcbiAgICAvKiogQWxsb3cgc2VsZWN0aW9uIGZyb20gYWxsIG1lZGlhIHR5cGVzICovXG4gICAgQUxMTUVESUE6IDIsXG4gIH07XG5cbiAgLyoqXG4gICAqIENvbnZlbmllbmNlIGNvbnN0YW50XG4gICAqL1xuICBQaWN0dXJlU291cmNlVHlwZSA9IHtcbiAgICAvKiogQ2hvb3NlIGltYWdlIGZyb20gcGljdHVyZSBsaWJyYXJ5IChzYW1lIGFzIFBIT1RPTElCUkFSWSBmb3IgQW5kcm9pZCkgKi9cbiAgICBQSE9UT0xJQlJBUlk6IDAsXG4gICAgLyoqIFRha2UgcGljdHVyZSBmcm9tIGNhbWVyYSAqL1xuICAgIENBTUVSQTogMSxcbiAgICAvKiogQ2hvb3NlIGltYWdlIGZyb20gcGljdHVyZSBsaWJyYXJ5IChzYW1lIGFzIFNBVkVEUEhPVE9BTEJVTSBmb3IgQW5kcm9pZCkgKi9cbiAgICBTQVZFRFBIT1RPQUxCVU06IDIsXG4gIH07XG5cbiAgLyoqXG4gICAqIENvbnZlbmllbmNlIGNvbnN0YW50XG4gICAqL1xuICBQb3BvdmVyQXJyb3dEaXJlY3Rpb24gPSB7XG4gICAgQVJST1dfVVA6IDEsXG4gICAgQVJST1dfRE9XTjogMixcbiAgICBBUlJPV19MRUZUOiA0LFxuICAgIEFSUk9XX1JJR0hUOiA4LFxuICAgIEFSUk9XX0FOWTogMTUsXG4gIH07XG5cbiAgLyoqXG4gICAqIENvbnZlbmllbmNlIGNvbnN0YW50XG4gICAqL1xuICBEaXJlY3Rpb24gPSB7XG4gICAgLyoqIFVzZSB0aGUgYmFjay1mYWNpbmcgY2FtZXJhICovXG4gICAgQkFDSzogMCxcbiAgICAvKiogVXNlIHRoZSBmcm9udC1mYWNpbmcgY2FtZXJhICovXG4gICAgRlJPTlQ6IDEsXG4gIH07XG5cbiAgLyoqXG4gICAqIFRha2UgYSBwaWN0dXJlIG9yIHZpZGVvLCBvciBsb2FkIG9uZSBmcm9tIHRoZSBsaWJyYXJ5LlxuICAgKiBAcGFyYW0ge0NhbWVyYU9wdGlvbnN9IFtvcHRpb25zXSBPcHRpb25zIHRoYXQgeW91IHdhbnQgdG8gcGFzcyB0byB0aGUgY2FtZXJhLiBFbmNvZGluZyB0eXBlLCBxdWFsaXR5LCBldGMuIFBsYXRmb3JtLXNwZWNpZmljIHF1aXJrcyBhcmUgZGVzY3JpYmVkIGluIHRoZSBbQ29yZG92YSBwbHVnaW4gZG9jc10oaHR0cHM6Ly9naXRodWIuY29tL2FwYWNoZS9jb3Jkb3ZhLXBsdWdpbi1jYW1lcmEjY2FtZXJhb3B0aW9ucy1lcnJhdGEtKS5cbiAgICogQHJldHVybnMge1Byb21pc2U8YW55Pn0gUmV0dXJucyBhIFByb21pc2UgdGhhdCByZXNvbHZlcyB3aXRoIEJhc2U2NCBlbmNvZGluZyBvZiB0aGUgaW1hZ2UgZGF0YSwgb3IgdGhlIGltYWdlIGZpbGUgVVJJLCBkZXBlbmRpbmcgb24gY2FtZXJhT3B0aW9ucywgb3RoZXJ3aXNlIHJlamVjdHMgd2l0aCBhbiBlcnJvci5cbiAgICovXG4gIEBDb3Jkb3ZhKHtcbiAgICBjYWxsYmFja09yZGVyOiAncmV2ZXJzZScsXG4gIH0pXG4gIGdldFBpY3R1cmUob3B0aW9ucz86IENhbWVyYU9wdGlvbnMpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZW1vdmUgaW50ZXJtZWRpYXRlIGltYWdlIGZpbGVzIHRoYXQgYXJlIGtlcHQgaW4gdGVtcG9yYXJ5IHN0b3JhZ2UgYWZ0ZXIgY2FsbGluZyBjYW1lcmEuZ2V0UGljdHVyZS5cbiAgICogQXBwbGllcyBvbmx5IHdoZW4gdGhlIHZhbHVlIG9mIENhbWVyYS5zb3VyY2VUeXBlIGVxdWFscyBDYW1lcmEuUGljdHVyZVNvdXJjZVR5cGUuQ0FNRVJBIGFuZCB0aGUgQ2FtZXJhLmRlc3RpbmF0aW9uVHlwZSBlcXVhbHMgQ2FtZXJhLkRlc3RpbmF0aW9uVHlwZS5GSUxFX1VSSS5cbiAgICogQHJldHVybnMge1Byb21pc2U8YW55Pn1cbiAgICovXG4gIEBDb3Jkb3ZhKHtcbiAgICBwbGF0Zm9ybXM6IFsnaU9TJ10sXG4gIH0pXG4gIGNsZWFudXAoKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cbn1cbiJdfQ==

    /***/

  },

  /***/
  "./node_modules/@ionic-native/native-geocoder/ngx/index.js":
  /*!*****************************************************************!*\
    !*** ./node_modules/@ionic-native/native-geocoder/ngx/index.js ***!
    \*****************************************************************/

  /*! exports provided: NativeGeocoder */

  /***/
  function node_modulesIonicNativeNativeGeocoderNgxIndexJs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "NativeGeocoder", function () {
      return NativeGeocoder;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _ionic_native_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic-native/core */
    "./node_modules/@ionic-native/core/index.js");

    var NativeGeocoder =
    /** @class */
    function (_super) {
      Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(NativeGeocoder, _super);

      function NativeGeocoder() {
        return _super !== null && _super.apply(this, arguments) || this;
      }

      NativeGeocoder.prototype.reverseGeocode = function (latitude, longitude, options) {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "reverseGeocode", {
          "callbackOrder": "reverse"
        }, arguments);
      };

      NativeGeocoder.prototype.forwardGeocode = function (addressString, options) {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "forwardGeocode", {
          "callbackOrder": "reverse"
        }, arguments);
      };

      NativeGeocoder.pluginName = "NativeGeocoder";
      NativeGeocoder.plugin = "cordova-plugin-nativegeocoder";
      NativeGeocoder.pluginRef = "nativegeocoder";
      NativeGeocoder.repo = "https://github.com/sebastianbaar/cordova-plugin-nativegeocoder";
      NativeGeocoder.platforms = ["iOS", "Android"];
      NativeGeocoder = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])()], NativeGeocoder);
      return NativeGeocoder;
    }(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["IonicNativePlugin"]); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvQGlvbmljLW5hdGl2ZS9wbHVnaW5zL25hdGl2ZS1nZW9jb2Rlci9uZ3gvaW5kZXgudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDM0MsT0FBTyw4QkFBc0MsTUFBTSxvQkFBb0IsQ0FBQzs7SUF3Q3BDLGtDQUFpQjs7OztJQVduRCx1Q0FBYyxhQUNaLFFBQWdCLEVBQ2hCLFNBQWlCLEVBQ2pCLE9BQStCO0lBY2pDLHVDQUFjLGFBQUMsYUFBcUIsRUFBRSxPQUErQjs7Ozs7O0lBNUIxRCxjQUFjO1FBRDFCLFVBQVUsRUFBRTtPQUNBLGNBQWM7eUJBekMzQjtFQXlDb0MsaUJBQWlCO1NBQXhDLGNBQWMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBDb3Jkb3ZhLCBJb25pY05hdGl2ZVBsdWdpbiwgUGx1Z2luIH0gZnJvbSAnQGlvbmljLW5hdGl2ZS9jb3JlJztcblxuLyoqXG4gKiBAbmFtZSBOYXRpdmUgR2VvY29kZXJcbiAqIEBkZXNjcmlwdGlvblxuICogQ29yZG92YSBwbHVnaW4gZm9yIG5hdGl2ZSBmb3J3YXJkIGFuZCByZXZlcnNlIGdlb2NvZGluZ1xuICpcbiAqIEB1c2FnZVxuICogYGBgdHlwZXNjcmlwdFxuICogaW1wb3J0IHsgTmF0aXZlR2VvY29kZXIsIE5hdGl2ZUdlb2NvZGVyUmVzdWx0LCBOYXRpdmVHZW9jb2Rlck9wdGlvbnMgfSBmcm9tICdAaW9uaWMtbmF0aXZlL25hdGl2ZS1nZW9jb2Rlci9uZ3gnO1xuICpcbiAqIGNvbnN0cnVjdG9yKHByaXZhdGUgbmF0aXZlR2VvY29kZXI6IE5hdGl2ZUdlb2NvZGVyKSB7IH1cbiAqXG4gKiAuLi5cbiAqXG4gKiBsZXQgb3B0aW9uczogTmF0aXZlR2VvY29kZXJPcHRpb25zID0ge1xuICogICAgIHVzZUxvY2FsZTogdHJ1ZSxcbiAqICAgICBtYXhSZXN1bHRzOiA1XG4gKiB9O1xuICpcbiAqIHRoaXMubmF0aXZlR2VvY29kZXIucmV2ZXJzZUdlb2NvZGUoNTIuNTA3MjA5NSwgMTMuMTQ1MjgxOCwgb3B0aW9ucylcbiAqICAgLnRoZW4oKHJlc3VsdDogTmF0aXZlR2VvY29kZXJSZXN1bHRbXSkgPT4gY29uc29sZS5sb2coSlNPTi5zdHJpbmdpZnkocmVzdWx0WzBdKSkpXG4gKiAgIC5jYXRjaCgoZXJyb3I6IGFueSkgPT4gY29uc29sZS5sb2coZXJyb3IpKTtcbiAqXG4gKiB0aGlzLm5hdGl2ZUdlb2NvZGVyLmZvcndhcmRHZW9jb2RlKCdCZXJsaW4nLCBvcHRpb25zKVxuICogICAudGhlbigocmVzdWx0OiBOYXRpdmVHZW9jb2RlclJlc3VsdFtdKSA9PiBjb25zb2xlLmxvZygnVGhlIGNvb3JkaW5hdGVzIGFyZSBsYXRpdHVkZT0nICsgcmVzdWx0WzBdLmxhdGl0dWRlICsgJyBhbmQgbG9uZ2l0dWRlPScgKyByZXN1bHRbMF0ubG9uZ2l0dWRlKSlcbiAqICAgLmNhdGNoKChlcnJvcjogYW55KSA9PiBjb25zb2xlLmxvZyhlcnJvcikpO1xuICogYGBgXG4gKiBAaW50ZXJmYWNlc1xuICogTmF0aXZlR2VvY29kZXJSZXN1bHRcbiAqIE5hdGl2ZUdlb2NvZGVyT3B0aW9uc1xuICovXG5AUGx1Z2luKHtcbiAgcGx1Z2luTmFtZTogJ05hdGl2ZUdlb2NvZGVyJyxcbiAgcGx1Z2luOiAnY29yZG92YS1wbHVnaW4tbmF0aXZlZ2VvY29kZXInLFxuICBwbHVnaW5SZWY6ICduYXRpdmVnZW9jb2RlcicsXG4gIHJlcG86ICdodHRwczovL2dpdGh1Yi5jb20vc2ViYXN0aWFuYmFhci9jb3Jkb3ZhLXBsdWdpbi1uYXRpdmVnZW9jb2RlcicsXG4gIHBsYXRmb3JtczogWydpT1MnLCAnQW5kcm9pZCddLFxufSlcbkBJbmplY3RhYmxlKClcbmV4cG9ydCBjbGFzcyBOYXRpdmVHZW9jb2RlciBleHRlbmRzIElvbmljTmF0aXZlUGx1Z2luIHtcbiAgLyoqXG4gICAqIFJldmVyc2UgZ2VvY29kZSBhIGdpdmVuIGxhdGl0dWRlIGFuZCBsb25naXR1ZGUgdG8gZmluZCBsb2NhdGlvbiBhZGRyZXNzXG4gICAqIEBwYXJhbSBsYXRpdHVkZSB7bnVtYmVyfSBUaGUgbGF0aXR1ZGVcbiAgICogQHBhcmFtIGxvbmdpdHVkZSB7bnVtYmVyfSBUaGUgbG9uZ2l0dWRlXG4gICAqIEBwYXJhbSBvcHRpb25zIHtOYXRpdmVHZW9jb2Rlck9wdGlvbnN9IFRoZSBvcHRpb25zXG4gICAqIEByZXR1cm4ge1Byb21pc2U8TmF0aXZlR2VvY29kZXJSZXN1bHRbXT59XG4gICAqL1xuICBAQ29yZG92YSh7XG4gICAgY2FsbGJhY2tPcmRlcjogJ3JldmVyc2UnLFxuICB9KVxuICByZXZlcnNlR2VvY29kZShcbiAgICBsYXRpdHVkZTogbnVtYmVyLFxuICAgIGxvbmdpdHVkZTogbnVtYmVyLFxuICAgIG9wdGlvbnM/OiBOYXRpdmVHZW9jb2Rlck9wdGlvbnNcbiAgKTogUHJvbWlzZTxOYXRpdmVHZW9jb2RlclJlc3VsdFtdPiB7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgLyoqXG4gICAqIEZvcndhcmQgZ2VvY29kZSBhIGdpdmVuIGFkZHJlc3MgdG8gZmluZCBjb29yZGluYXRlc1xuICAgKiBAcGFyYW0gYWRkcmVzc1N0cmluZyB7c3RyaW5nfSBUaGUgYWRkcmVzcyB0byBiZSBnZW9jb2RlZFxuICAgKiBAcGFyYW0gb3B0aW9ucyB7TmF0aXZlR2VvY29kZXJPcHRpb25zfSBUaGUgb3B0aW9uc1xuICAgKiBAcmV0dXJuIHtQcm9taXNlPE5hdGl2ZUdlb2NvZGVyUmVzdWx0W10+fVxuICAgKi9cbiAgQENvcmRvdmEoe1xuICAgIGNhbGxiYWNrT3JkZXI6ICdyZXZlcnNlJyxcbiAgfSlcbiAgZm9yd2FyZEdlb2NvZGUoYWRkcmVzc1N0cmluZzogc3RyaW5nLCBvcHRpb25zPzogTmF0aXZlR2VvY29kZXJPcHRpb25zKTogUHJvbWlzZTxOYXRpdmVHZW9jb2RlclJlc3VsdFtdPiB7XG4gICAgcmV0dXJuO1xuICB9XG59XG5cbi8qKlxuICogRW5jYXBzdWxhdGVzIGZvcm1hdCBpbmZvcm1hdGlvbiBhYm91dCBhIGdlb2NvZGluZyByZXN1bHQuXG4gKiBtb3JlIEluZm86XG4gKiAgLSBodHRwczovL2RldmVsb3Blci5hcHBsZS5jb20vZG9jdW1lbnRhdGlvbi9jb3JlbG9jYXRpb24vY2xwbGFjZW1hcmtcbiAqICAtIGh0dHBzOi8vZGV2ZWxvcGVyLmFuZHJvaWQuY29tL3JlZmVyZW5jZS9hbmRyb2lkL2xvY2F0aW9uL0FkZHJlc3MuaHRtbFxuICovXG5leHBvcnQgaW50ZXJmYWNlIE5hdGl2ZUdlb2NvZGVyUmVzdWx0IHtcbiAgLyoqXG4gICAqIFRoZSBsYXRpdHVkZS5cbiAgICovXG4gIGxhdGl0dWRlOiBzdHJpbmc7XG4gIC8qKlxuICAgKiBUaGUgbG9uZ2l0dWRlLlxuICAgKi9cbiAgbG9uZ2l0dWRlOiBzdHJpbmc7XG4gIC8qKlxuICAgKiBUaGUgY291bnRyeSBjb2RlLlxuICAgKi9cbiAgY291bnRyeUNvZGU6IHN0cmluZztcbiAgLyoqXG4gICAqIFRoZSBjb3VudHJ5IG5hbWUuXG4gICAqL1xuICBjb3VudHJ5TmFtZTogc3RyaW5nO1xuICAvKipcbiAgICogVGhlIHBvc3RhbCBjb2RlLlxuICAgKi9cbiAgcG9zdGFsQ29kZTogc3RyaW5nO1xuICAvKipcbiAgICogVGhlIGFkbWluaXN0cmF0aXZlQXJlYS5cbiAgICovXG4gIGFkbWluaXN0cmF0aXZlQXJlYTogc3RyaW5nO1xuICAvKipcbiAgICogVGhlIHN1YkFkbWluaXN0cmF0aXZlQXJlYS5cbiAgICovXG4gIHN1YkFkbWluaXN0cmF0aXZlQXJlYTogc3RyaW5nO1xuICAvKipcbiAgICogVGhlIGxvY2FsaXR5LlxuICAgKi9cbiAgbG9jYWxpdHk6IHN0cmluZztcbiAgLyoqXG4gICAqIFRoZSBzdWJMb2NhbGl0eS5cbiAgICovXG4gIHN1YkxvY2FsaXR5OiBzdHJpbmc7XG4gIC8qKlxuICAgKiBUaGUgdGhvcm91Z2hmYXJlLlxuICAgKi9cbiAgdGhvcm91Z2hmYXJlOiBzdHJpbmc7XG4gIC8qKlxuICAgKiBUaGUgc3ViVGhvcm91Z2hmYXJlLlxuICAgKi9cbiAgc3ViVGhvcm91Z2hmYXJlOiBzdHJpbmc7XG4gIC8qKlxuICAgKiBUaGUgYXJlYXNPZkludGVyZXN0XG4gICAqL1xuICBhcmVhc09mSW50ZXJlc3Q6IHN0cmluZ1tdO1xufVxuXG4vKipcbiAqIE9wdGlvbnMgZm9yIHJldmVyc2UgYW5kIGZvcndhcmQgZ2VvY29kaW5nLlxuICovXG5leHBvcnQgaW50ZXJmYWNlIE5hdGl2ZUdlb2NvZGVyT3B0aW9ucyB7XG4gIC8qKlxuICAgKiBUaGUgbG9jYWxlIHRvIHVzZSB3aGVuIHJldHVybmluZyB0aGUgYWRkcmVzcyBpbmZvcm1hdGlvbi5cbiAgICogSWYgc2V0IHRvICdmYWxzZScgdGhlIGxvY2FsZSB3aWxsIGFsd2F5cyBiZSAnZW5fVVMnLlxuICAgKiBEZWZhdWx0IGlzICd0cnVlJ1xuICAgKi9cbiAgdXNlTG9jYWxlOiBib29sZWFuO1xuICAvKipcbiAgICogVGhlIGRlZmF1bHQgbG9jYWxlIHRvIHVzZSB3aGVuIHJldHVybmluZyB0aGUgYWRkcmVzcyBpbmZvcm1hdGlvbi5cbiAgICogZS5nLjogJ2ZhLUlSJyBvciAnZGVfREUnLlxuICAgKi9cbiAgZGVmYXVsdExvY2FsZT86IHN0cmluZztcbiAgLyoqXG4gICAqIFRoZSBtYXhpbXVtIG51bWJlciBvZiByZXN1bHQgdG8gcmV0dXJuIChtYXggaXMgNSkuXG4gICAqIERlZmF1bHQgaXMgMVxuICAgKi9cbiAgbWF4UmVzdWx0czogbnVtYmVyO1xufVxuIl19

    /***/

  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/schedule/design/design.component.html":
  /*!*********************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/schedule/design/design.component.html ***!
    \*********************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppScheduleDesignDesignComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-content class=\"ion-padding-start ion-padding-end ion-padding-bottom\" style=\"height:650px\">\r\n<form [formGroup]=\"desginForm\" novalidate style=\"overflow:scroll\">\r\n    <ion-grid style=\"position: relative;margin-top: 30px;\">\r\n        <!-- <ion-row *ngIf=\"address !== ''\">\r\n            <ion-col>\r\n                {{address}}\r\n            </ion-col>\r\n        \r\n        </ion-row>\r\n        <ion-row *ngIf=\"address == ''\">\r\n            <ion-col>\r\n            Address not found.\r\n            </ion-col>\r\n        \r\n        </ion-row> -->\r\n        <ion-row >\r\n            <ion-col>\r\n                <ion-item class=\"ion-no-padding\">\r\n                    <ion-label position=\"floating\">name*</ion-label>\r\n                    <ion-input type=\"text\" class=\"form_input\" autocapitalize=\"words\"\r\n                                formControlName=\"name\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n        </ion-row>\r\n        <ion-row class=\"ion-align-items-center ion-justify-content-center\">\r\n            <ion-col>\r\n                <ion-item class=\"ion-no-padding\">\r\n                    <ion-label position=\"floating\">email*</ion-label>\r\n                    <ion-input class=\"form_input\" type=\"email\" autocapitalize=\"none\" autocomplete=\"off\"\r\n                                formControlName=\"email\"></ion-input>\r\n                </ion-item>\r\n                <div style=\"height: 5px;\">\r\n                    <div *ngIf=\"desginForm.get('email').hasError('pattern') && desginForm.get('email').dirty\">\r\n                        <span class=\"error\">{{emailError}}</span>\r\n                    </div>\r\n                    <div *ngIf=\"desginForm.get('email').value === '' && desginForm.get('email').dirty\">\r\n                        <span class=\"error\">{{fieldRequired}}</span>\r\n                    </div>\r\n                </div>\r\n            </ion-col>\r\n        </ion-row>\r\n        <ion-row class=\"ion-align-items-center ion-justify-content-center\">\r\n            <ion-col>\r\n                <ion-item class=\"ion-no-padding\">\r\n                    <ion-label position=\"floating\">annual units (Kwh)*</ion-label>\r\n                    <ion-input class=\"form_input\"  type=\"number\" (ionInput)=\"numberfield($event)\"\r\n                                formControlName=\"monthlybill\"></ion-input>\r\n                </ion-item>\r\n                <div style=\"height: 5px;\">\r\n                    <div *ngIf=\"desginForm.get('monthlybill').dirty && desginForm.get('monthlybill').hasError('min')\">\r\n                        <span class=\"error\">{{\"Annual units should not be negative\"}}</span>\r\n                    </div>\r\n                    \r\n                </div>\r\n            </ion-col>\r\n        </ion-row>\r\n\r\n        <!-- <ion-row class=\"ion-margin-top\">\r\n            <ion-col>\r\n                <ion-range [min]=\"minRange\" [max]=\"maxRange\" formControlName=\"monthlybill\" mode=\"ios\" pin=\"true\"\r\n                            class=\"ion-no-padding\">\r\n                    <ion-label slot=\"start\">{{minRange | currency :'USD':'symbol':'1.0-0'}}</ion-label>\r\n                    <ion-label slot=\"end\">{{maxRange | currency :'USD':'symbol':'1.0-0'  }} <span style=\"color:red\">*</span></ion-label>\r\n                    \r\n                </ion-range>\r\n                \r\n            </ion-col>\r\n        </ion-row> -->\r\n\r\n        <ion-row>\r\n            <ion-col size=\"6\">\r\n                <!-- <ion-label position=\"floating\">module make*</ion-label> -->\r\n                <app-auto-complete #myinput style=\"font-size: 14px;\" [dataList]=\"listOfSolarMake\" placeholder=\"module make*\"\r\n              formControlName=\"solarmake\" [name]=\"'solarmake'\" (modulename)=\"getmodulename($event)\"></app-auto-complete>\r\n\r\n            </ion-col>\r\n            <ion-col size=\"6\">\r\n                <!-- <ion-label position=\"floating\">module model*</ion-label> -->\r\n                <app-auto-complete style=\"font-size: 14px;\"  [dataList]=\"listOfSolarMade\" placeholder=\"module model*\"\r\n                                    formControlName=\"solarmodel\" [name]=\"'solarmade'\" (modulename)=\"getmodulename($event)\"></app-auto-complete>\r\n\r\n            </ion-col>\r\n        </ion-row>\r\n\r\n        <ion-row>\r\n            <ion-col size=\"6\">\r\n                <!-- <ion-label position=\"floating\">inverter make*</ion-label> -->\r\n                <app-auto-complete style=\"font-size: 12px;\" [dataList]=\"listOfInverterMake\" placeholder=\"inverter make*\"\r\n                                    formControlName=\"invertermake\" [name]=\"'invertermake'\"  (modulename)=\"getmodulename($event)\"></app-auto-complete>\r\n            </ion-col>\r\n            <ion-col size=\"6\">\r\n                <!-- <ion-label position=\"floating\">invertor model*</ion-label> -->\r\n                <app-auto-complete style=\"font-size: 10px;\" [dataList]=\"listOfInverterMade\" placeholder=\"invertor model*\"\r\n                                    formControlName=\"invertermodel\" [name]=\"'invertermade'\" (modulename)=\"getmodulename($event)\"></app-auto-complete>\r\n            </ion-col>\r\n        </ion-row>\r\n\r\n        <ion-row class=\"ion-align-items-center ion-justify-content-center\">\r\n            <ion-col size=\"6\">\r\n                <ion-item class=\"ion-no-padding\">\r\n                    <!-- <ion-label style=\"display: none;\">Project Type</ion-label> -->\r\n                    <!-- <ion-label position=\"floating\">project type</ion-label> -->\r\n                    <ion-select class=\"form_input\" ok-text=\"\" placeholder=\"project type*\"\r\n                                cancel-text=\"\"\r\n                                formControlName=\"projecttype\" interface=\"popover\">\r\n                        <ion-select-option value=\"residential\">Residential</ion-select-option>\r\n                        <ion-select-option value=\"commercial\">Commercial</ion-select-option>\r\n                    </ion-select>\r\n                </ion-item>\r\n\r\n            </ion-col>\r\n        \r\n            <!-- <ion-col size=\"6\">\r\n                <ion-item class=\"ion-no-padding\">\r\n                    <ion-label style=\"display: none;\">Job Type</ion-label>\r\n                    <ion-select class=\"form_input select_div\" placeholder=\"job type\"\r\n                                ok-text=\"\"\r\n                                cancel-text=\"\"\r\n                                formControlName=\"jobtype\" interface=\"popover\">\r\n                        <ion-select-option value=\"pvbattery\">PV+Battery</ion-select-option>\r\n                        <ion-select-option value=\"battery\">Battery</ion-select-option>\r\n                        <ion-select-option value=\"pv\">PV</ion-select-option>\r\n                    </ion-select>\r\n                </ion-item>\r\n            </ion-col> -->\r\n            <ion-col size=\"6\">\r\n                <ion-item class=\"ion-no-padding\">\r\n                    <!-- <ion-label style=\"display: none;\">New construction</ion-label> -->\r\n                    <!-- <ion-label position=\"floating\">new construction</ion-label> -->\r\n                    <ion-select  (ionChange)=\"showUpload($event)\" class=\"form_input select_div\" placeholder=\"new construction*\"\r\n                                    ok-text=\"\"\r\n                                cancel-text=\"\"\r\n                                formControlName=\"newconstruction\" interface=\"popover\">\r\n                        <ion-select-option value=\"true\">Yes</ion-select-option>\r\n                        <ion-select-option value=\"false\">No</ion-select-option>\r\n                    </ion-select>\r\n                </ion-item>\r\n            </ion-col>\r\n        </ion-row>\r\n\r\n        <ion-row class=\"ion-align-items-center ion-justify-content-center\">\r\n        \r\n            <ion-col size=\"12\">\r\n                <ion-item class=\"ion-no-padding\">\r\n                    <ion-label style=\"display: none;\">Mounting Type*</ion-label>\r\n                    <!-- <ion-label position=\"floating\">mounting type</ion-label> -->\r\n                    <ion-select class=\"form_input select_div\" (ionChange)=\"eventcheck($event)\" placeholder=\"mounting type\"\r\n                                ok-text=\"\" cancel-text=\"\"\r\n                                formControlName=\"mountingtype\" interface=\"popover\">\r\n                        <ion-select-option value=\"roof\">Roof</ion-select-option>\r\n                        <ion-select-option value=\"ground\">Ground</ion-select-option>\r\n                        <ion-select-option value=\"both\">Both</ion-select-option>\r\n                    </ion-select>\r\n                </ion-item>\r\n            </ion-col>\r\n        </ion-row>\r\n        \r\n        <!-- condition base roof type-->\r\n        <ion-row>\r\n            <ion-col size=\"6\" *ngIf='(showValue==\"roof\" ||showValue== \"both\")'>\r\n                <ion-item class=\"ion-no-padding\">\r\n                    <ion-label style=\"display: none;\">Roof Type</ion-label>\r\n                    <ion-label position=\"floating\">roof type*</ion-label>\r\n                    <ion-select class=\"form_input select_div\"\r\n                                ok-text=\"\" cancel-text=\"\"\r\n                                formControlName=\"rooftype\" interface=\"popover\">\r\n                        <ion-select-option value=\"flat\">Flat</ion-select-option>\r\n                        <ion-select-option value=\"pitch\">Pitch</ion-select-option>\r\n                        <ion-select-option value=\"both\">Both</ion-select-option>\r\n                    </ion-select>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"6\" *ngIf='(showValue==\"ground\" || showValue==\"both\")'>\r\n                    <ion-item class=\"ion-no-padding\">\r\n                        <ion-label position=\"floating\" style=\"font-size: 12px;\">tilt for ground mount*</ion-label>\r\n                        <ion-input class=\"form_input\"  type=\"number\" formControlName=\"tiltofgroundmountingsystem\"></ion-input>\r\n                    </ion-item>\r\n                    <div style=\"height: 5px;\">\r\n                        <div *ngIf=\"desginForm.get('tiltofgroundmountingsystem').dirty && desginForm.get('tiltofgroundmountingsystem').hasError('min')\">\r\n                            <span class=\"error\">{{\"Tilt for ground mount should not be negative\"}}</span>\r\n                        </div>\r\n                        \r\n                    </div>\r\n            </ion-col>\r\n        </ion-row>\r\n            <!--upload box-->\r\n<ion-row *ngIf='uploadbox==\"true\"'>\r\n    <ion-col size=\"12\">\r\n        <ion-item class=\"ion-no-padding\">\r\n            <!-- <ion-input class=\"form_input\" type=\"file\" placeholder=\"Upload Architectural design\" \r\n                    (ionChange)=\"files($event)\"  multiple></ion-input> -->\r\n                    <ion-label position=\"floating\">architectural design*</ion-label>\r\n                    <ion-input type=\"file\"  class=\"form_input\"  (change)=\"files($event)\" style=\"margin-top: 12px;\" formControlName=\"architecturaldesign\" placeholder=\"Upload Architectural design\" multiple></ion-input>\r\n                </ion-item>\r\n                    <ng-template *ngIf=\"design.architecturaldesign !=''\">\r\n                        <ion-item>\r\n                        <ion-label position=\"floating\">architectural design*</ion-label>\r\n                        \r\n                            <!-- <div *ngFor=\"let arc of design.architecturaldesign\">\r\n                                \r\n                                {{arc.name}}{{arc.ext}}\r\n                            \r\n                                \r\n                            </div> -->\r\n                        </ion-item>\r\n                    </ng-template>\r\n        \r\n    </ion-col>\r\n    \r\n</ion-row>\r\n\r\n            <ion-row>\r\n                <ion-col size=\"11\">\r\n                    <ion-item class=\"ion-no-padding\">\r\n                        <ion-label position=\"floating\">Attachment</ion-label>\r\n                       <p  *ngFor=\"let attachment of attachmentData\"> <ion-row style=\"display:flex;align-items: flex-end;top: 10px;padding: 0px;\" ><ion-col><ion-label *ngIf=\"attachment.value!=''\" position=\"floating\" (change)=\"submitform()\">{{attachment?.name}}</ion-label></ion-col>\r\n                       <ion-col style=\"display:flex;align-items: flex-end;top: 10px;padding: 0px;\"> <ion-icon name=\"close-circle-outline\" *ngIf=\"attachment.name!=''\" (click)=\"attachment.name=''\"></ion-icon></ion-col></ion-row></p>\r\n                        \r\n                       <ion-input style=\"font-size:12px\" class=\"form_input\"  #myinput type=\"file\" formControlName=\"attachments\" (change)=\"prelimfiles($event)\" multiple>\r\n                        </ion-input>\r\n                    </ion-item>    \r\n                </ion-col>\r\n                <ion-col size=\"1\" style=\"display: flex;align-items: flex-end;\">\r\n                     <ion-icon name=\"close-circle-outline\" *ngIf=\"myinput.value !=''\" (click)=\"myinput.value=''\"></ion-icon>  \r\n                </ion-col>\r\n            </ion-row>\r\n\r\n        <ion-row class=\"ion-margin-top\">\r\n            <ion-label position=\"floating\">Comments</ion-label>\r\n            <ion-col size=\"12\" class=\"ion-no-padding\">\r\n                <ion-textarea class=\"ion-no-margin ion-no-padding comment_box\" rows=\"3\"\r\n                                formControlName=\"comments\"></ion-textarea>\r\n            </ion-col>\r\n        </ion-row>\r\n<!-- \r\n        <ion-row class=\"ion-margin-top\">\r\n            <ion-col>\r\n                <ion-item class=\" ion-no-padding no-border\" lines=\"none\" style=\"padding: 30px 0px;\">\r\n                    <app-user-selector style=\"overflow:scroll;\" placeholder=\"assign\" [assignees]=\"listOfAssignees\"\r\n                                        formControlName=\"assignedto\"></app-user-selector>\r\n                </ion-item>\r\n            </ion-col>\r\n        </ion-row> -->\r\n    </ion-grid>\r\n</form>\r\n\r\n</ion-content>\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/schedule/schedule.page.html":
  /*!***********************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/schedule/schedule.page.html ***!
    \***********************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppScheduleSchedulePageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<!-- <ion-content scroll=\"false\"> -->\r\n    <!-- <ion-grid style=\"overflow:hidden;\" scroll=\"false\"> -->\r\n        <ion-row class=\"ion-align-items-center ion-padding-start\">\r\n            <ion-col>\r\n                <h1 class=\"ion-no-padding ion-no-margin\" *ngIf=\"!tabsDisabled\">Schedule</h1>\r\n                <h1 class=\"ion-no-padding ion-no-margin\" *ngIf=\"tabsDisabled\">Edit</h1>\r\n            </ion-col>\r\n            <ion-col size=\"auto\">\r\n                <ion-button fill=\"clear\" size=\"small\" class=\"ion-no-padding\" (click)=\"goBack()\">\r\n                    <ion-icon name=\"close-outline\" color=\"dark\" size=\"large\"></ion-icon>\r\n                </ion-button>\r\n            </ion-col>\r\n        </ion-row>\r\n        <!-- <ion-row class=\"ion-padding-start ion-padding-end\">\r\n            <ion-col *ngIf=\"address !== '' \">\r\n                <span class=\"address-text\">\r\n                    {{address}}\r\n                </span>\r\n            </ion-col>\r\n            <ion-col *ngIf=\"address === '' \">\r\n                <span>\r\n                    No address found\r\n                </span>\r\n            </ion-col>\r\n        </ion-row> -->\r\n        <!-- <ion-row class=\"ion-padding-start ion-padding-end\">\r\n            <ion-col class=\"ion-text-end\" *ngIf=\"!tabsDisabled\">\r\n                <span [routerLink]=\"['/map-page']\" routerDirection=\"forward\" style=\"color: #4E6FB0;\">\r\n                    Change\r\n                </span>\r\n            </ion-col>\r\n            <ion-col class=\"ion-text-end\" *ngIf=\"tabsDisabled\">\r\n                <span class=\"edit_span\">\r\n                    Change\r\n                </span>\r\n            </ion-col>\r\n        </ion-row> -->\r\n    <!-- </ion-grid> -->\r\n\r\n    <!-- <ion-grid class=\"ion-margin-start ion-margin-end\" style=\"overflow:hidden;\" scroll=\"false\"> -->\r\n        <ion-segment mode=\"ios\" class=\"segments\" (ionChange)=\"segmentChanged($event)\" [value]=\"currentTab\"\r\n            [disabled]=\"tabsDisabled\">\r\n            <ion-segment-button value=\"design\">\r\n                <ion-label>Design</ion-label>\r\n            </ion-segment-button>\r\n            <ion-segment-button value=\"survey\">\r\n                <ion-label>Survey</ion-label>\r\n            </ion-segment-button>\r\n        </ion-segment>\r\n    <!-- </ion-grid> -->\r\n    <ion-content style=\"overflow:hidden\" scroll=\"false\" >\r\n        <ion-tabs #tabs tyle=\"overflow:hidden\">\r\n            <ion-tab-bar slot=\"top\" style=\"display:none;\" >\r\n                <ion-tab-button tab=\"design\">\r\n                    <ion-label>Design</ion-label>\r\n                </ion-tab-button>\r\n\r\n                <ion-tab-button tab=\"survey\">\r\n                    <ion-label>Survey</ion-label>\r\n                </ion-tab-button>\r\n            </ion-tab-bar>\r\n        </ion-tabs>\r\n        <ion-grid style=\"margin-top:10px\">\r\n            <ion-row class=\"ion-padding-start ion-padding-end mrT\">\r\n                <ion-col size=\"9\">\r\n                    <!-- <span class=\"address-text\"> -->\r\n                    {{address == \"\" ? \"No Address Found\" : address}}\r\n                    <!-- </span> -->\r\n                </ion-col>\r\n              \r\n                <ion-col class=\"ion-text-end\" *ngIf=\"!tabsDisabled\" size=\"3\">\r\n                    <span [routerLink]=\"['/map-page']\" routerDirection=\"forward\" style=\"color: #4E6FB0;\">\r\n                        Change\r\n                    </span>\r\n                </ion-col>\r\n                <ion-col class=\"ion-text-end\" *ngIf=\"tabsDisabled\" size=\"3\">\r\n                    <span class=\"edit_span\">\r\n                        Change\r\n                    </span>\r\n                </ion-col>\r\n            </ion-row>\r\n\r\n        </ion-grid>\r\n    </ion-content>\r\n<!-- </ion-content> -->\r\n\r\n<ion-footer class=\"ion-no-border white-bg\">\r\n    <ion-grid *ngIf=\"currentTab === 'design'\">\r\n        <ion-row>\r\n            <ion-col></ion-col>\r\n            <ion-col size=\"auto\">\r\n                <ion-button class=\"action-button-color\" fill=\"clear\" (click)=\"saveDesignForm()\">Order Prelim Design</ion-button>\r\n            </ion-col>\r\n        </ion-row>\r\n    </ion-grid>\r\n    <ion-grid *ngIf=\"currentTab === 'survey'\">\r\n        <ion-row>\r\n            <ion-col size=\"auto\">\r\n                <ion-button class=\"action-button-color\" fill=\"clear\" (click)=\"saveSurveyForm()\">Save</ion-button>\r\n            </ion-col>\r\n            <ion-col></ion-col>\r\n            <ion-col size=\"auto\" *ngIf=\"userdata.role.type !=='wattmonkadmins'\">\r\n                <ion-button class=\"action-button-color\" fill=\"clear\" (click)=\"startSurvey()\">Start Survey</ion-button>\r\n            </ion-col>\r\n        </ion-row>\r\n    </ion-grid>\r\n</ion-footer>\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/schedule/survey/survey.component.html":
  /*!*********************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/schedule/survey/survey.component.html ***!
    \*********************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppScheduleSurveySurveyComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-content class=\"ion-padding-start ion-padding-end ion-padding-bottom\" >\r\n    <form [formGroup]=\"surveyForm\">\r\n        <ion-grid>\r\n            <!-- <ion-row *ngIf=\"address !== ''\">\r\n                <ion-col>\r\n                    {{address}}\r\n                </ion-col>\r\n         \r\n            </ion-row>\r\n            <ion-row *ngIf=\"address == ''\">\r\n                <ion-col>\r\n                Address not found.\r\n                </ion-col>\r\n         \r\n            </ion-row> -->\r\n            <ion-row>\r\n                <ion-col>\r\n                    <ion-item class=\"ion-no-padding\">\r\n                        <ion-input placeholder=\"name*\" class=\"form_input\" autocapitalize=\"words\"\r\n                                   formControlName=\"name\"></ion-input>\r\n                    </ion-item>\r\n                </ion-col>\r\n            </ion-row>\r\n            <ion-row>\r\n                <ion-col>\r\n                    <ion-item class=\"ion-no-padding\">\r\n                        <ion-input placeholder=\"email*\" autocapitalize=\"none\" formControlName=\"email\" email=\"true\"\r\n                                   type=\"email\" autocomplete=\"off\"\r\n                                   class=\"form_input\"></ion-input>\r\n                    </ion-item>\r\n                    <div style=\"height: 5px;\">\r\n                        <div *ngIf=\"surveyForm.get('email').hasError('pattern') && surveyForm.get('email').dirty\">\r\n                            <span class=\"error\">{{emailError}}</span>\r\n                        </div>\r\n                        <div *ngIf=\"surveyForm.get('email').value === '' && surveyForm.get('email').dirty\">\r\n                            <span class=\"error\">{{fieldRequired}}</span>\r\n                        </div>\r\n                    </div>\r\n                </ion-col>\r\n            </ion-row>\r\n\r\n            <ion-row>\r\n                <ion-col>\r\n                    <ion-item class=\"ion-no-padding\">\r\n                        <ion-input placeholder=\"phone*\" formControlName=\"phonenumber\" type=\"number\"\r\n                                   class=\"form_input\"></ion-input>\r\n                    </ion-item>\r\n                </ion-col>\r\n            </ion-row>\r\n\r\n            <ion-row>\r\n                <ion-col>\r\n                    <ion-item class=\"ion-no-padding\">\r\n                        <ion-label style=\"display: none;\">Job Type</ion-label>\r\n                        <ion-select class=\"form_input select_div\" placeholder=\"job type\"\r\n                                    ok-text=\"\"\r\n                                    cancel-text=\"\"\r\n                                    formControlName=\"jobtype\" interface=\"popover\">\r\n                            <ion-select-option value=\"pvbattery\">PV+Battery</ion-select-option>\r\n                            <ion-select-option value=\"battery\">Battery</ion-select-option>\r\n                            <ion-select-option value=\"pv\">PV</ion-select-option>\r\n                        </ion-select>\r\n                    </ion-item>\r\n                </ion-col>\r\n            </ion-row>\r\n\r\n            <ion-row class=\"ion-margin-top\">\r\n                <ion-col>\r\n                    <ion-item class=\"ion-no-padding no-border\" lines=\"none\">\r\n                        <app-date-time formControlName=\"datetime\" placeholder=\"date and time\"\r\n                                       required=\"false\"></app-date-time>\r\n                    </ion-item>\r\n                </ion-col>\r\n            </ion-row>\r\n\r\n            <ion-row class=\"ion-margin-top\">\r\n                <ion-col size=\"12\" class=\"ion-no-padding\">\r\n                    <span class=\"input-placeholder\">comments</span>\r\n                </ion-col>\r\n                <ion-col size=\"12\" class=\"ion-no-padding\">\r\n                    <ion-textarea class=\"ion-no-margin ion-no-padding comment_box\" rows=\"3\"\r\n                                  formControlName=\"comments\"></ion-textarea>\r\n                </ion-col>\r\n            </ion-row>\r\n\r\n            <ion-row class=\"ion-margin-top\">\r\n                <ion-col>\r\n                    <ion-item class=\"ion-no-padding no-border\" lines=\"none\">\r\n                        <app-user-selector formControlName=\"assignedto\" placeholder=\"assign\"\r\n                                           [assignees]=\"listOfAssignees\"></app-user-selector>\r\n                    </ion-item>\r\n                </ion-col>\r\n            </ion-row>\r\n\r\n        </ion-grid>\r\n    </form>\r\n\r\n</ion-content>\r\n";
    /***/
  },

  /***/
  "./src/app/schedule/design/design.component.scss":
  /*!*******************************************************!*\
    !*** ./src/app/schedule/design/design.component.scss ***!
    \*******************************************************/

  /*! exports provided: default */

  /***/
  function srcAppScheduleDesignDesignComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".user-image {\n  width: 50px;\n  height: 50px;\n  -o-object-fit: cover;\n     object-fit: cover;\n  border-radius: 50%;\n}\n\nion-range {\n  --bar-background: #CBCBCB;\n  --bar-background-active: #CBCBCB;\n  --knob-background: #3c78d8;\n  --knob-border-radius: 2px solid white;\n  --knob-size: 20px;\n  --knob-border-radius: 50%;\n  --pin-color: #E1E1E1;\n}\n\n.solar-data {\n  position: absolute;\n  margin-top: 50px;\n  width: 146px;\n  max-width: 150px;\n  z-index: 3;\n  margin-left: 0px;\n  max-height: 200px;\n  overflow: auto;\n}\n\n.solar-made {\n  position: absolute;\n  width: 172px;\n  max-width: 175px;\n  z-index: 3;\n  margin-left: 0px;\n  max-height: 200px;\n  overflow: auto;\n  margin-top: 2px;\n}\n\nion-label {\n  color: #6C6C6C !important;\n}\n\n.error {\n  color: #df3e3e;\n  font-size: 11px;\n}\n\n.select_div {\n  border-bottom: 1px solid #E1E1E1;\n}\n\nion-select {\n  max-width: 100% !important;\n  width: 100% !important;\n  padding-left: 0px !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2NoZWR1bGUvZGVzaWduL0Y6XFxtb2JpbGVhcHAvc3JjXFxhcHBcXHNjaGVkdWxlXFxkZXNpZ25cXGRlc2lnbi5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvc2NoZWR1bGUvZGVzaWduL2Rlc2lnbi5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0Esb0JBQUE7S0FBQSxpQkFBQTtFQUNBLGtCQUFBO0FDQ0Y7O0FERUE7RUFDRSx5QkFBQTtFQUNBLGdDQUFBO0VBQ0EsMEJBQUE7RUFDQSxxQ0FBQTtFQUNBLGlCQUFBO0VBQ0EseUJBQUE7RUFDQSxvQkFBQTtBQ0NGOztBREVBO0VBQ0Usa0JBQUE7RUFDQSxnQkFBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtFQUNBLFVBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtBQ0NGOztBREVBO0VBQ0Usa0JBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSxVQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0FDQ0Y7O0FERUE7RUFDRSx5QkFBQTtBQ0NGOztBREVBO0VBQ0UsY0FBQTtFQUNBLGVBQUE7QUNDRjs7QURFQTtFQUNFLGdDQUFBO0FDQ0Y7O0FERUE7RUFDRSwwQkFBQTtFQUNBLHNCQUFBO0VBQ0EsNEJBQUE7QUNDRiIsImZpbGUiOiJzcmMvYXBwL3NjaGVkdWxlL2Rlc2lnbi9kZXNpZ24uY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIudXNlci1pbWFnZSB7XHJcbiAgd2lkdGg6IDUwcHg7XHJcbiAgaGVpZ2h0OiA1MHB4O1xyXG4gIG9iamVjdC1maXQ6IGNvdmVyO1xyXG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcclxufVxyXG5cclxuaW9uLXJhbmdlIHtcclxuICAtLWJhci1iYWNrZ3JvdW5kOiAjQ0JDQkNCO1xyXG4gIC0tYmFyLWJhY2tncm91bmQtYWN0aXZlOiAjQ0JDQkNCO1xyXG4gIC0ta25vYi1iYWNrZ3JvdW5kOiAjM2M3OGQ4O1xyXG4gIC0ta25vYi1ib3JkZXItcmFkaXVzOiAycHggc29saWQgd2hpdGU7XHJcbiAgLS1rbm9iLXNpemU6IDIwcHg7XHJcbiAgLS1rbm9iLWJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAtLXBpbi1jb2xvcjogI0UxRTFFMTtcclxufVxyXG5cclxuLnNvbGFyLWRhdGEge1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICBtYXJnaW4tdG9wOiA1MHB4O1xyXG4gIHdpZHRoOiAxNDZweDtcclxuICBtYXgtd2lkdGg6IDE1MHB4O1xyXG4gIHotaW5kZXg6IDM7XHJcbiAgbWFyZ2luLWxlZnQ6IDBweDtcclxuICBtYXgtaGVpZ2h0OiAyMDBweDtcclxuICBvdmVyZmxvdzogYXV0bztcclxufVxyXG5cclxuLnNvbGFyLW1hZGUge1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICB3aWR0aDogMTcycHg7XHJcbiAgbWF4LXdpZHRoOiAxNzVweDtcclxuICB6LWluZGV4OiAzO1xyXG4gIG1hcmdpbi1sZWZ0OiAwcHg7XHJcbiAgbWF4LWhlaWdodDogMjAwcHg7XHJcbiAgb3ZlcmZsb3c6IGF1dG87XHJcbiAgbWFyZ2luLXRvcDogMnB4O1xyXG59XHJcblxyXG5pb24tbGFiZWwge1xyXG4gIGNvbG9yOiAjNkM2QzZDICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5lcnJvciB7XHJcbiAgY29sb3I6IHJnYigyMjMsIDYyLCA2Mik7XHJcbiAgZm9udC1zaXplOiAxMXB4O1xyXG59XHJcblxyXG4uc2VsZWN0X2RpdiB7XHJcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNFMUUxRTE7XHJcbn1cclxuXHJcbmlvbi1zZWxlY3R7XHJcbiAgbWF4LXdpZHRoOiAxMDAlICFpbXBvcnRhbnQ7XHJcbiAgd2lkdGg6IDEwMCUgIWltcG9ydGFudDtcclxuICBwYWRkaW5nLWxlZnQ6IDBweCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG5cclxuIiwiLnVzZXItaW1hZ2Uge1xuICB3aWR0aDogNTBweDtcbiAgaGVpZ2h0OiA1MHB4O1xuICBvYmplY3QtZml0OiBjb3ZlcjtcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xufVxuXG5pb24tcmFuZ2Uge1xuICAtLWJhci1iYWNrZ3JvdW5kOiAjQ0JDQkNCO1xuICAtLWJhci1iYWNrZ3JvdW5kLWFjdGl2ZTogI0NCQ0JDQjtcbiAgLS1rbm9iLWJhY2tncm91bmQ6ICMzYzc4ZDg7XG4gIC0ta25vYi1ib3JkZXItcmFkaXVzOiAycHggc29saWQgd2hpdGU7XG4gIC0ta25vYi1zaXplOiAyMHB4O1xuICAtLWtub2ItYm9yZGVyLXJhZGl1czogNTAlO1xuICAtLXBpbi1jb2xvcjogI0UxRTFFMTtcbn1cblxuLnNvbGFyLWRhdGEge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIG1hcmdpbi10b3A6IDUwcHg7XG4gIHdpZHRoOiAxNDZweDtcbiAgbWF4LXdpZHRoOiAxNTBweDtcbiAgei1pbmRleDogMztcbiAgbWFyZ2luLWxlZnQ6IDBweDtcbiAgbWF4LWhlaWdodDogMjAwcHg7XG4gIG92ZXJmbG93OiBhdXRvO1xufVxuXG4uc29sYXItbWFkZSB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgd2lkdGg6IDE3MnB4O1xuICBtYXgtd2lkdGg6IDE3NXB4O1xuICB6LWluZGV4OiAzO1xuICBtYXJnaW4tbGVmdDogMHB4O1xuICBtYXgtaGVpZ2h0OiAyMDBweDtcbiAgb3ZlcmZsb3c6IGF1dG87XG4gIG1hcmdpbi10b3A6IDJweDtcbn1cblxuaW9uLWxhYmVsIHtcbiAgY29sb3I6ICM2QzZDNkMgIWltcG9ydGFudDtcbn1cblxuLmVycm9yIHtcbiAgY29sb3I6ICNkZjNlM2U7XG4gIGZvbnQtc2l6ZTogMTFweDtcbn1cblxuLnNlbGVjdF9kaXYge1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI0UxRTFFMTtcbn1cblxuaW9uLXNlbGVjdCB7XG4gIG1heC13aWR0aDogMTAwJSAhaW1wb3J0YW50O1xuICB3aWR0aDogMTAwJSAhaW1wb3J0YW50O1xuICBwYWRkaW5nLWxlZnQ6IDBweCAhaW1wb3J0YW50O1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/schedule/design/design.component.ts":
  /*!*****************************************************!*\
    !*** ./src/app/schedule/design/design.component.ts ***!
    \*****************************************************/

  /*! exports provided: DesignComponent */

  /***/
  function srcAppScheduleDesignDesignComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DesignComponent", function () {
      return DesignComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var src_app_api_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! src/app/api.service */
    "./src/app/api.service.ts");
    /* harmony import */


    var src_app_utilities_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! src/app/utilities.service */
    "./src/app/utilities.service.ts");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _model_constants__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ../../model/constants */
    "./src/app/model/constants.ts");
    /* harmony import */


    var _storage_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ../../storage.service */
    "./src/app/storage.service.ts");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _ionic_native_Camera_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! @ionic-native/Camera/ngx */
    "./node_modules/@ionic-native/Camera/ngx/index.js");
    /* harmony import */


    var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
    /*! @ionic-native/file/ngx */
    "./node_modules/@ionic-native/file/ngx/index.js");

    var DesignComponent = /*#__PURE__*/function () {
      function DesignComponent(formBuilder, apiService, utils, navController, storage, route, camera, file, router) {
        var _this2 = this;

        _classCallCheck(this, DesignComponent);

        this.formBuilder = formBuilder;
        this.apiService = apiService;
        this.utils = utils;
        this.navController = navController;
        this.storage = storage;
        this.route = route;
        this.camera = camera;
        this.file = file;
        this.router = router;
        this.listOfAssignees = [];
        this.listOfSolarMake = [];
        this.listOfSolarMade = [];
        this.listOfInverterMade = [];
        this.listOfInverterMake = [];
        this.emailError = _model_constants__WEBPACK_IMPORTED_MODULE_6__["INVALID_EMAIL_MESSAGE"];
        this.fieldRequired = _model_constants__WEBPACK_IMPORTED_MODULE_6__["FIELD_REQUIRED"];
        this.designId = 0;
        this.design = null;
        this.archFiles = [];
        this.prelimFiles = []; //attachmentName = this.desginForm.get('attachments').value;

        this.options = {
          quality: 30,
          targetWidth: 600,
          targetHeight: 300,
          sourceType: this.camera.PictureSourceType.PHOTOLIBRARY,
          destinationType: this.camera.DestinationType.DATA_URL,
          encodingType: this.camera.EncodingType.PNG,
          mediaType: this.camera.MediaType.PICTURE
        };
        this.onFormSubmit = true; // onProjectChange(event){
        // console.log("eve",this.desginForm);
        // }

        this.getclass = function () {
          return _this2.address == "" ? "0px" : "50px";
        };

        var EMAILPATTERN = /^[a-z0-9!#$%&'*+\/=?^_`{|}~.-]+@[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)*$/i;
        this.desginForm = this.formBuilder.group({
          name: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
          email: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].pattern(EMAILPATTERN)]),
          solarmake: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
          solarmodel: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
          invertermake: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
          invertermodel: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
          monthlybill: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].min(0)]),
          address: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
          createdby: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](''),
          assignedto: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](''),
          rooftype: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](''),
          prelimdesign: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](null),
          architecturaldesign: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]([], [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
          tiltofgroundmountingsystem: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](''),
          mountingtype: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
          // jobtype: new FormControl('', [Validators.required]),
          projecttype: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
          newconstruction: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](''),
          source: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('android', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
          comments: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](''),
          requesttype: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('prelim'),
          latitude: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](''),
          longitude: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](''),
          country: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](''),
          state: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](''),
          city: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](''),
          postalcode: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](''),
          status: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('created'),
          attachments: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]([]) // uploadbox:new FormControl('')

        });
        this.designId = +this.route.snapshot.paramMap.get('id');
        this.getAssignees();
      }

      _createClass(DesignComponent, [{
        key: "numberfield",
        value: function numberfield(event) {
          console.log(event);
        }
      }, {
        key: "getmodulename",
        value: function getmodulename(event) {
          this.modulename = event;
          console.log(this.modulename);
        } // logScrolling(e){
        // }
        // record(){
        //   this.filterrecord= this.listOfSolarMake.filter(x=>
        // }

      }, {
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this3 = this;

          this.utils.manualInput.subscribe(function (data) {
            if (_this3.modulename == 'solarmake') {
              _this3.solarmake = data; // this.solarMakeDisposable.unsubscribe();
              // this.desginForm.patchValue({
              //   solarmake:data
              // });
              // this.solarMakeDisposable = this.desginForm.get('solarmake').valueChanges.subscribe(val => {
              //   this.getSolarMade();
              // });
            } else if (_this3.modulename == 'solarmade') {
              _this3.solarmade = data;
            } else if (_this3.modulename == 'invertermake') {
              _this3.invertermake = data;
            } else if (_this3.modulename == 'invertermade') {
              _this3.invertermade = data;
            }
          });
          this.address = this.storage.getData();
          this.subscription = this.utils.getScheduleFormEvent().subscribe(function (event) {
            if (event === _model_constants__WEBPACK_IMPORTED_MODULE_6__["ScheduleFormEvent"].SAVE_DESIGN_FORM) {
              _this3.addForm();
            }
          });

          if (this.designId !== 0) {
            setTimeout(function () {
              _this3.getDesignDetails();
            }, 1000);
          } else {
            // if(this.onFormSubmit){
            this.solarMakeDisposable = this.desginForm.get('solarmake').valueChanges.subscribe(function (val) {
              _this3.getSolarMade();
            });
            this.desginForm.get('invertermake').valueChanges.subscribe(function (val) {
              _this3.getInverterMade();
            }); // }

            this.addressSubscription = this.utils.getAddressObservable().subscribe(function (address) {
              console.log(address, ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");

              _this3.desginForm.get('address').setValue('fffff');

              _this3.desginForm.get('latitude').setValue('444444444444');

              _this3.desginForm.get('longitude').setValue('555555555');

              _this3.desginForm.get('country').setValue('india');

              _this3.desginForm.get('city').setValue('Lucknow');

              _this3.desginForm.get('state').setValue('UP');

              _this3.desginForm.get('postalcode').setValue(3232343); //  this.desginForm.get('address').setValue(address.address);
              //  this.desginForm.get('latitude').setValue(address.lat);
              //  this.desginForm.get('longitude').setValue(address.long);
              //  this.desginForm.get('country').setValue(address.country);
              //  this.desginForm.get('city').setValue(address.city);
              //  this.desginForm.get('state').setValue(address.state);
              //  this.desginForm.get('postalcode').setValue(address.postalcode);

            }, function (error) {
              _this3.desginForm.get('address').setValue('');

              _this3.desginForm.get('latitude').setValue('');

              _this3.desginForm.get('longitude').setValue('');

              _this3.desginForm.get('country').setValue('');

              _this3.desginForm.get('city').setValue('');

              _this3.desginForm.get('state').setValue('');

              _this3.desginForm.get('postalcode').setValue('');
            });
            this.desginForm.patchValue({
              createdby: this.storage.getUserID()
            });
            this.getSolarMake();
          }

          this.formControlValueChanged();
          this.uploadcontrolvalidation();
        }
      }, {
        key: "formControlValueChanged",
        value: function formControlValueChanged() {
          var tiltControl = this.desginForm.get('tiltofgroundmountingsystem');
          var roofcontrol = this.desginForm.get('rooftype');
          this.desginForm.get('mountingtype').valueChanges.subscribe(function (mode) {
            console.log(mode);

            if (mode === 'ground') {
              tiltControl.setValidators([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]);
              roofcontrol.clearValidators();
              roofcontrol.reset();
            } else if (mode === 'both') {
              tiltControl.setValidators([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required,, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].min(0)]);
              roofcontrol.setValidators([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]);
            } else if (mode === 'roof') {
              roofcontrol.setValidators([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]);
              tiltControl.clearValidators();
              tiltControl.reset();
            } else {
              tiltControl.clearValidators();
              roofcontrol.clearValidators();
            }

            tiltControl.updateValueAndValidity();
            roofcontrol.updateValueAndValidity();
          });
        }
      }, {
        key: "uploadcontrolvalidation",
        value: function uploadcontrolvalidation() {
          var uploadboxcontrol = this.desginForm.get('architecturaldesign');
          this.desginForm.get('newconstruction').valueChanges.subscribe(function (uploadmode) {
            console.log(uploadmode);

            if (uploadmode == 'true') {
              uploadboxcontrol.setValidators([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]);
            } else if (uploadmode == 'false') {
              uploadboxcontrol.clearValidators();
              uploadboxcontrol.reset();
            }

            uploadboxcontrol.updateValueAndValidity();
          });
        }
      }, {
        key: "ngOnDestroy",
        value: function ngOnDestroy() {
          this.subscription.unsubscribe();

          if (this.designId === 0) {
            this.addressSubscription.unsubscribe();
          }
        }
      }, {
        key: "getDesignDetails",
        value: function getDesignDetails() {
          var _this4 = this;

          this.utils.showLoading('Getting Design Details').then(function () {
            _this4.apiService.getDesginDetail(_this4.designId).subscribe(function (result) {
              return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this4, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
                var _this5 = this;

                return regeneratorRuntime.wrap(function _callee$(_context) {
                  while (1) {
                    switch (_context.prev = _context.next) {
                      case 0:
                        _context.next = 2;
                        return this.utils.hideLoading().then(function () {
                          _this5.design = result;
                          _this5.attachmentData = _this5.design.attachments;
                          console.log("hello", _this5.design.attachments);

                          _this5.desginForm.patchValue({
                            name: _this5.design.name,
                            email: _this5.design.email,
                            monthlybill: _this5.design.monthlybill,
                            address: _this5.design.address,
                            createdby: _this5.design.createdby,
                            rooftype: _this5.design.rooftype,
                            mountingtype: _this5.design.mountingtype,
                            architecturaldesign: _this5.design.architecturaldesign,
                            // jobtype: this.design.jobtype,
                            tiltofgroundmountingsystem: _this5.design.tiltofgroundmountingsystem,
                            comments: _this5.design.comments == '' ? '' : _this5.design.comments[0].message,
                            projecttype: _this5.design.projecttype,
                            latitude: _this5.design.latitude,
                            longitude: _this5.design.longitude,
                            country: _this5.design.country,
                            state: _this5.design.state,
                            city: _this5.design.city,
                            postalcode: _this5.design.postalcode,
                            newconstruction: _this5.design.newconstruction + '',
                            prelimdesign: null,
                            //attachments:this.design.attachments,
                            attachments: _this5.design.attachments,
                            solarmake: _this5.design.solarmake,
                            solarmodel: _this5.design.solarmodel,
                            invertermake: _this5.design.invertermake,
                            invertermodel: _this5.design.invertermodel
                          }); //console.log("attachments",this.desginForm.get('attachments').value)


                          _this5.utils.setStaticAddress(_this5.design.address); //  this.attachmentData=this.design.attachments.length==1 ? this.design.attachments[0].name + this.design.attachments[0].ext : this.design.attachments.length;


                          if (_this5.design.assignedto !== null && _this5.design.assignedto !== undefined) {
                            _this5.desginForm.patchValue({
                              assignedto: _this5.design.assignedto.id
                            });
                          }

                          setTimeout(function () {
                            _this5.getSolarMakeForForm();

                            _this5.getInverterMakeForForm();
                          }, 500);
                        });

                      case 2:
                      case "end":
                        return _context.stop();
                    }
                  }
                }, _callee, this);
              }));
            }, function (error) {
              _this4.utils.hideLoading();
            });
          });
        }
      }, {
        key: "getSolarMakeForForm",
        value: function getSolarMakeForForm() {
          var _this6 = this;

          this.apiService.getSolarMake().subscribe(function (response) {
            _this6.listOfSolarMake = response;

            _this6.apiService.getSolarMade(_this6.design.solarmake.id).subscribe(function (solarresponse) {
              // this.utils.hideLoading().then(()=>{
              _this6.listOfSolarMade = solarresponse;
              console.log(solarresponse);
              console.log('patching solar');
              setTimeout(function () {
                _this6.desginForm.patchValue({
                  solarmake: _this6.design.solarmake.id,
                  solarmodel: _this6.design.solarmodel.id
                }); // if(this.onFormSubmit){


                _this6.desginForm.get('solarmake').valueChanges.subscribe(function (val) {
                  _this6.getSolarMade();
                }); // }

              }, 500); // });
            }, function (solarResponseError) {
              var error = solarResponseError.error;

              if (error.message instanceof String) {
                _this6.utils.errorSnackBar(error.message);
              } else if (error.message instanceof Array) {
                _this6.utils.errorSnackBar(error.message[0].messages[0].message);
              }
            });
          }, function (responseError) {
            var error = responseError.error;

            if (error.message instanceof String) {
              _this6.utils.errorSnackBar(error.message);
            } else if (error.message instanceof Array) {
              _this6.utils.errorSnackBar(error.message[0].messages[0].message);
            }
          });
        }
      }, {
        key: "getInverterMakeForForm",
        value: function getInverterMakeForForm() {
          var _this7 = this;

          this.apiService.getInverterMake().subscribe(function (response) {
            console.log(response);
            _this7.listOfInverterMake = response;

            _this7.apiService.getInverterMade(_this7.design.invertermake.id).subscribe(function (makeResponse) {
              // this.utils.hideLoading();
              console.log('patching inverter');
              _this7.listOfInverterMade = makeResponse;
              setTimeout(function () {
                _this7.desginForm.patchValue({
                  invertermake: _this7.design.invertermake.id,
                  invertermodel: _this7.design.invertermodel.id
                }); // if(this.onFormSubmit){


                _this7.desginForm.get('invertermake').valueChanges.subscribe(function (val) {
                  _this7.getInverterMade();
                }); // }

              }, 500);
            }, function (makeResponseError) {
              var error = makeResponseError.error;

              if (error.message instanceof String) {
                _this7.utils.errorSnackBar(error.message);
              } else if (error.message instanceof Array) {
                _this7.utils.errorSnackBar(error.message[0].messages[0].message);
              }
            });
          }, function (responseError) {
            var error = responseError.error;

            if (error.message instanceof String) {
              _this7.utils.errorSnackBar(error.message);
            } else if (error.message instanceof Array) {
              _this7.utils.errorSnackBar(error.message[0].messages[0].message);
            }
          });
        }
      }, {
        key: "saveModuleMake",
        value: function saveModuleMake() {
          var _this8 = this;

          var found = this.listOfSolarMake.some(function (el) {
            return el.name === _this8.solarmake;
          });
          console.log(found);

          if (!found) {
            var solarmakedata = {
              name: this.solarmake
            };
            this.apiService.postSolarMake(solarmakedata).subscribe(function (response) {
              _this8.desginForm.patchValue({
                solarmake: response.id
              });

              _this8.saveModuleModel();
            }, function (err) {
              console.log(err, 'err in savemodulemake');
            });
          } else {
            this.saveModuleModel();
          }
        }
      }, {
        key: "saveModuleModel",
        value: function saveModuleModel() {
          var _this9 = this;

          var ismakefound = this.listOfSolarMake.some(function (el) {
            return el.name === _this9.solarmake;
          });
          var found = this.listOfSolarMade.some(function (el) {
            return el.name === _this9.solarmade;
          });

          if (!ismakefound || !found) {
            var solarmadedata = {
              solarmade: this.solarmade,
              solarmake: this.desginForm.get('solarmake').value
            };
            console.log(solarmadedata);
            this.apiService.postSolarMade(solarmadedata).subscribe(function (response) {
              _this9.desginForm.patchValue({
                solarmade: response.id
              });

              _this9.saveInvertermake();
            });
          } else {
            this.saveInvertermake();
          }
        }
      }, {
        key: "saveInvertermake",
        value: function saveInvertermake() {
          var _this10 = this;

          var found = this.listOfInverterMake.some(function (el) {
            return el.name === _this10.invertermake;
          });

          if (!found) {
            var invertermakedata = {
              invertermake: this.invertermake
            };
            this.apiService.postInverterMake(invertermakedata).subscribe(function (response) {
              _this10.desginForm.patchValue({
                invertermake: response.id
              });

              _this10.saveInverterMade();
            });
          } else {
            this.saveInverterMade();
          }
        }
      }, {
        key: "saveInverterMade",
        value: function saveInverterMade() {
          var _this11 = this;

          var ismakefound = this.listOfInverterMake.some(function (el) {
            return el.name === _this11.invertermake;
          });
          var found = this.listOfInverterMade.some(function (el) {
            return el.name === _this11.invertermade;
          });

          if (!ismakefound || !found) {
            var invertermadedata = {
              invertermade: this.invertermade,
              invertermake: this.desginForm.get('invertermake').value
            };
            console.log(invertermadedata);
            this.apiService.postInverterMade(invertermadedata).subscribe(function (response) {
              _this11.desginForm.patchValue({
                invertermade: response.id
              });

              _this11.submitform();
            });
          } else {
            this.submitform();
          }
        }
      }, {
        key: "addForm",
        value: function addForm() {
          this.onFormSubmit = false; // this.saveModuleMake();

          debugger;
          console.log('Reach', this.desginForm.value); // debugger;
          // this.saveModuleMake();

          this.submitform();
        }
      }, {
        key: "submitform",
        value: function submitform() {
          var _this12 = this;

          if (this.desginForm.status === 'VALID') {
            this.utils.showLoading('Saving').then(function () {
              if (_this12.designId === 0) {
                _this12.apiService.addDesginForm(_this12.desginForm.value).subscribe(function (response) {
                  _this12.uploaarchitecturedesign(response.id, 'architecturaldesign');

                  _this12.uploadpreliumdesign(response.id, 'attachments');

                  _this12.utils.hideLoading().then(function () {
                    console.log('Res', response);

                    _this12.router.navigate(['/homepage']); // this.utils.showSnackBar('Design have been saved');


                    _this12.utils.setHomepageDesignRefresh(true); // this.navController.pop();
                    // this.utils.showSuccessModal('Desgin have been saved').then((modal) => {
                    //   modal.present();
                    //   modal.onWillDismiss().then((dismissed) => {
                    // this.utils.setHomepageDesignRefresh(true);
                    //     this.navController.pop();
                    //   });
                    // });

                  });
                }, function (responseError) {
                  _this12.utils.hideLoading();

                  var error = responseError.error;

                  _this12.utils.errorSnackBar(error.message);
                });
              } else {
                _this12.apiService.updateDesignForm(_this12.desginForm.value, _this12.designId).subscribe(function (response) {
                  _this12.uploaarchitecturedesign(response.id, 'architecturaldesign');

                  _this12.uploadpreliumdesign(response.id, 'attachments');

                  _this12.utils.hideLoading().then(function () {
                    console.log('Res', response);

                    _this12.utils.showSnackBar('Design have been updated');

                    _this12.utils.setDesignDetailsRefresh(true);

                    _this12.navController.pop();
                  });
                }, function (responseError) {
                  _this12.utils.hideLoading().then(function () {
                    var error = responseError.error;

                    _this12.utils.errorSnackBar(error.message[0].messages[0].message);
                  });
                });
              }
            });
          } else {
            if (this.desginForm.value.name == '') {
              this.utils.errorSnackBar('Please fill the name.');
            } else if (this.desginForm.value.email == '') {
              this.utils.errorSnackBar('Please fill the email.');
            } else if (this.desginForm.value.monthlybill == '') {
              this.utils.errorSnackBar('Please fill the annual units.');
            } else if (this.desginForm.value.solarmake == '') {
              this.utils.errorSnackBar('Please fill the module make.');
            } else if (this.desginForm.value.solarmodel == '') {
              this.utils.errorSnackBar('Please fill the module model.');
            } else if (this.desginForm.value.invertermake == '') {
              this.utils.errorSnackBar('Please fill the inverter make.');
            } else if (this.desginForm.value.invertermodel == '') {
              this.utils.errorSnackBar('Please fill the inverter model.');
            } else if (this.desginForm.value.mountingtype == '') {
              this.utils.errorSnackBar('Please fill the mounting type.');
            } else if (this.desginForm.value.projecttype == '') {
              this.utils.errorSnackBar('Please fill the project type.');
            } else if (this.desginForm.value.tiltofgroundmountingsystem == '') {
              this.utils.errorSnackBar('Please fill the tilt for ground mount.');
            } else if (this.desginForm.value.rooftype == '') {
              this.utils.errorSnackBar('Please fill the rooftype.');
            } else if (this.desginForm.value.architecturaldesign == '') {
              this.utils.errorSnackBar('Please attach architectural design.');
            } else {
              this.utils.errorSnackBar('Address not found. Make sure location is on on device.');
            }
          }
        }
      }, {
        key: "showInvalidFormAlert",
        value: function showInvalidFormAlert() {
          var _this13 = this;

          var error = '';
          Object.keys(this.desginForm.controls).forEach(function (key) {
            var control = _this13.desginForm.get(key);

            if (control.invalid) {
              if (error !== '') {
                error = error + '<br/>';
              }

              if (control.errors.required === true) {
                error = error + _this13.utils.capitalizeWord(key) + ' is required';
              }

              if (control.errors.email === true) {
                error = error + 'Invalid email';
              }

              if (control.errors.error !== null && control.errors.error !== undefined) {
                error = error + control.errors.error;
              }
            }
          });
          console.log(this.desginForm.value);
          this.utils.showAlert(error);
        }
      }, {
        key: "getAssignees",
        value: function getAssignees() {
          var _this14 = this;

          this.apiService.getDesigners().subscribe(function (assignees) {
            _this14.listOfAssignees = []; // this.listOfAssignees.push(this.utils.getDefaultAssignee(this.storage.getUserID()));

            assignees.forEach(function (item) {
              return _this14.listOfAssignees.push(item);
            });
            console.log(_this14.listOfAssignees);
          });
        }
      }, {
        key: "getSolarMade",
        value: function getSolarMade() {
          var _this15 = this;

          this.utils.showLoading('Getting module models').then(function (success) {
            _this15.apiService.getSolarMade(_this15.desginForm.get('solarmake').value).subscribe(function (response) {
              _this15.utils.hideLoading().then(function () {
                console.log(response);
                _this15.listOfSolarMade = response;

                _this15.desginForm.patchValue({
                  solarmodel: ''
                });
              });
            }, function (responseError) {
              _this15.utils.hideLoading();

              var error = responseError.error;

              _this15.utils.errorSnackBar(error.message[0].messages[0].message);
            }); // }, (error) => {

          });
        }
      }, {
        key: "ioniViewDidEnter",
        value: function ioniViewDidEnter() {}
      }, {
        key: "getSolarMake",
        value: function getSolarMake() {
          var _this16 = this;

          this.getInverterMake();
          this.apiService.getSolarMake().subscribe(function (response) {
            _this16.listOfSolarMake = response;
          }, function (responseError) {
            var error = responseError.error;
            console.log(error);

            _this16.utils.errorSnackBar(error.message[0].messages[0].message);
          });
        }
      }, {
        key: "getInverterMade",
        value: function getInverterMade() {
          var _this17 = this;

          console.log(this.desginForm.get('invertermake').value);
          this.utils.showLoading('Getting inverter models').then(function (success) {
            _this17.apiService.getInverterMade(_this17.desginForm.get('invertermake').value).subscribe(function (response) {
              _this17.utils.hideLoading().then(function () {
                console.log(response);
                _this17.listOfInverterMade = response;

                _this17.desginForm.patchValue({
                  invertermodel: ''
                });
              });
            }, function (responseError) {
              _this17.utils.hideLoading();

              var error = responseError.error;

              _this17.utils.errorSnackBar(error.message[0].messages[0].message);
            }); // }, (reject) => {

          });
        }
      }, {
        key: "getInverterMake",
        value: function getInverterMake() {
          var _this18 = this;

          this.apiService.getInverterMake().subscribe(function (response) {
            console.log(response);
            _this18.listOfInverterMake = response;
          }, function (responseError) {
            var error = responseError.error;

            _this18.utils.errorSnackBar(error.message[0].messages[0].message);
          });
        }
      }, {
        key: "eventcheck",
        value: function eventcheck(e) {
          this.showValue = e.target.value;
          console.log(this.showValue);
        }
      }, {
        key: "showUpload",
        value: function showUpload(e) {
          this.uploadbox = e.target.value;
        }
      }, {
        key: "files",
        value: function files(event) {
          console.log(event.target.files);

          for (var i = 0; i < event.target.files.length; i++) {
            this.archFiles.push(event.target.files[i]);
          }

          console.log(this.archFiles);
        }
      }, {
        key: "prelimfiles",
        value: function prelimfiles(event) {
          console.log(event.target.files);

          for (var i = 0; i < event.target.files.length; i++) {
            this.prelimFiles.push(event.target.files[i]);
          }

          if (this.prelimFiles.length == 1) {
            this.fileName = event.target.files[0].name;
            console.log(this.fileName);
          } else if (this.prelimFiles.length > 1) {
            this.fileName = this.prelimFiles.length;
          } else {
            this.fileName = '';
          }
        }
      }, {
        key: "uploaarchitecturedesign",
        value: function uploaarchitecturedesign(designId, key) {
          console.log(this.archFiles);
          var imageData = new FormData();

          for (var i = 0; i < this.archFiles.length; i++) {
            imageData.append("files", this.archFiles[i]);

            if (i == 0) {
              imageData.append('path', 'design/' + designId);
              imageData.append('refId', designId + '');
              imageData.append('ref', 'design');
              imageData.append('field', key);
            }
          }

          this.apiService.uploaddesign(imageData).subscribe(function (res) {
            console.log(res);
          });
        }
      }, {
        key: "uploadpreliumdesign",
        value: function uploadpreliumdesign(designId, key, filearray) {
          var _this19 = this;

          console.log(this.prelimFiles);
          var imageData = new FormData();

          for (var i = 0; i < this.prelimFiles.length; i++) {
            imageData.append("files", this.prelimFiles[i]);

            if (i == 0) {
              imageData.append('path', 'design/' + designId);
              imageData.append('refId', designId + '');
              imageData.append('ref', 'design');
              imageData.append('field', key);
            }
          }

          this.apiService.uploaddesign(imageData).subscribe(function (res) {
            console.log(res);
          }, function (responseError) {
            _this19.utils.hideLoading();

            var error = responseError.error;

            _this19.utils.errorSnackBar(error.message[0].messages[0].message);
          });
        }
      }]);

      return DesignComponent;
    }();

    DesignComponent.ctorParameters = function () {
      return [{
        type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"]
      }, {
        type: src_app_api_service__WEBPACK_IMPORTED_MODULE_3__["ApiService"]
      }, {
        type: src_app_utilities_service__WEBPACK_IMPORTED_MODULE_4__["UtilitiesService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["NavController"]
      }, {
        type: _storage_service__WEBPACK_IMPORTED_MODULE_7__["StorageService"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_8__["ActivatedRoute"]
      }, {
        type: _ionic_native_Camera_ngx__WEBPACK_IMPORTED_MODULE_9__["Camera"]
      }, {
        type: _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_10__["File"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_8__["Router"]
      }];
    };

    DesignComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-design',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./design.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/schedule/design/design.component.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./design.component.scss */
      "./src/app/schedule/design/design.component.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"], src_app_api_service__WEBPACK_IMPORTED_MODULE_3__["ApiService"], src_app_utilities_service__WEBPACK_IMPORTED_MODULE_4__["UtilitiesService"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["NavController"], _storage_service__WEBPACK_IMPORTED_MODULE_7__["StorageService"], _angular_router__WEBPACK_IMPORTED_MODULE_8__["ActivatedRoute"], _ionic_native_Camera_ngx__WEBPACK_IMPORTED_MODULE_9__["Camera"], _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_10__["File"], _angular_router__WEBPACK_IMPORTED_MODULE_8__["Router"]])], DesignComponent);
    /***/
  },

  /***/
  "./src/app/schedule/number.directive.ts":
  /*!**********************************************!*\
    !*** ./src/app/schedule/number.directive.ts ***!
    \**********************************************/

  /*! exports provided: NumberOnlyDirective */

  /***/
  function srcAppScheduleNumberDirectiveTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "NumberOnlyDirective", function () {
      return NumberOnlyDirective;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");

    var NumberOnlyDirective = /*#__PURE__*/function () {
      function NumberOnlyDirective(el) {
        _classCallCheck(this, NumberOnlyDirective);

        this.el = el; // Allow decimal numbers and negative values

        this.regex = new RegExp(/^[0-9]+(\.[0-9]*){0,1}$/g); // Allow key codes for special events. Reflect :
        // Backspace, tab, end, home

        this.specialKeys = ['Backspace', 'Tab', 'End', 'Home', '-'];
      }

      _createClass(NumberOnlyDirective, [{
        key: "onKeyDown",
        value: function onKeyDown(event) {
          // Allow Backspace, tab, end, and home keys
          if (this.specialKeys.indexOf(event.key) !== -1) {
            return;
          }

          var current = this.el.nativeElement.value;
          var next = current.concat(event.key);

          if (next && !String(next).match(this.regex)) {
            event.preventDefault();
          }
        }
      }]);

      return NumberOnlyDirective;
    }();

    NumberOnlyDirective.ctorParameters = function () {
      return [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"]
      }];
    };

    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["HostListener"])('keydown', ['$event']), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [KeyboardEvent]), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:returntype", void 0)], NumberOnlyDirective.prototype, "onKeyDown", null);
    NumberOnlyDirective = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Directive"])({
      selector: '[numberOnly]'
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"]])], NumberOnlyDirective);
    /***/
  },

  /***/
  "./src/app/schedule/schedule-routing.module.ts":
  /*!*****************************************************!*\
    !*** ./src/app/schedule/schedule-routing.module.ts ***!
    \*****************************************************/

  /*! exports provided: SchedulePageRoutingModule */

  /***/
  function srcAppScheduleScheduleRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SchedulePageRoutingModule", function () {
      return SchedulePageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _schedule_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./schedule.page */
    "./src/app/schedule/schedule.page.ts");
    /* harmony import */


    var _design_design_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ./design/design.component */
    "./src/app/schedule/design/design.component.ts");
    /* harmony import */


    var _survey_survey_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./survey/survey.component */
    "./src/app/schedule/survey/survey.component.ts");
    /* harmony import */


    var _ionic_native_geolocation_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @ionic-native/geolocation/ngx */
    "./node_modules/@ionic-native/geolocation/ngx/index.js");

    var routes = [{
      path: '',
      component: _schedule_page__WEBPACK_IMPORTED_MODULE_3__["SchedulePage"],
      children: [{
        path: 'design/:id',
        component: _design_design_component__WEBPACK_IMPORTED_MODULE_4__["DesignComponent"]
      }, {
        path: 'design',
        component: _design_design_component__WEBPACK_IMPORTED_MODULE_4__["DesignComponent"]
      }, {
        path: 'survey/:id',
        component: _survey_survey_component__WEBPACK_IMPORTED_MODULE_5__["SurveyComponent"]
      }, {
        path: 'survey',
        component: _survey_survey_component__WEBPACK_IMPORTED_MODULE_5__["SurveyComponent"]
      }, {
        path: '',
        redirectTo: 'design',
        pathMatch: 'full'
      }]
    }];

    var SchedulePageRoutingModule = function SchedulePageRoutingModule() {
      _classCallCheck(this, SchedulePageRoutingModule);
    };

    SchedulePageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
      providers: [_ionic_native_geolocation_ngx__WEBPACK_IMPORTED_MODULE_6__["Geolocation"]]
    })], SchedulePageRoutingModule);
    /***/
  },

  /***/
  "./src/app/schedule/schedule.module.ts":
  /*!*********************************************!*\
    !*** ./src/app/schedule/schedule.module.ts ***!
    \*********************************************/

  /*! exports provided: SchedulePageModule */

  /***/
  function srcAppScheduleScheduleModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SchedulePageModule", function () {
      return SchedulePageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _schedule_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./schedule-routing.module */
    "./src/app/schedule/schedule-routing.module.ts");
    /* harmony import */


    var _schedule_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./schedule.page */
    "./src/app/schedule/schedule.page.ts");
    /* harmony import */


    var _survey_survey_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ./survey/survey.component */
    "./src/app/schedule/survey/survey.component.ts");
    /* harmony import */


    var _design_design_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! ./design/design.component */
    "./src/app/schedule/design/design.component.ts");
    /* harmony import */


    var _utilities_utilities_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! ../utilities/utilities.module */
    "./src/app/utilities/utilities.module.ts");
    /* harmony import */


    var _ionic_native_diagnostic_ngx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
    /*! @ionic-native/diagnostic/ngx */
    "./node_modules/@ionic-native/diagnostic/ngx/index.js");
    /* harmony import */


    var _ionic_native_native_geocoder_ngx__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
    /*! @ionic-native/native-geocoder/ngx */
    "./node_modules/@ionic-native/native-geocoder/ngx/index.js");
    /* harmony import */


    var _number_directive__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
    /*! ./number.directive */
    "./src/app/schedule/number.directive.ts");
    /* harmony import */


    var _ionic_native_Camera_ngx__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(
    /*! @ionic-native/Camera/ngx */
    "./node_modules/@ionic-native/Camera/ngx/index.js");
    /* harmony import */


    var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(
    /*! @ionic-native/file/ngx */
    "./node_modules/@ionic-native/file/ngx/index.js");

    var SchedulePageModule = function SchedulePageModule() {
      _classCallCheck(this, SchedulePageModule);
    };

    SchedulePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _schedule_routing_module__WEBPACK_IMPORTED_MODULE_5__["SchedulePageRoutingModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"], _utilities_utilities_module__WEBPACK_IMPORTED_MODULE_9__["UtilitiesModule"]],
      declarations: [_schedule_page__WEBPACK_IMPORTED_MODULE_6__["SchedulePage"], _survey_survey_component__WEBPACK_IMPORTED_MODULE_7__["SurveyComponent"], _design_design_component__WEBPACK_IMPORTED_MODULE_8__["DesignComponent"], _number_directive__WEBPACK_IMPORTED_MODULE_12__["NumberOnlyDirective"]],
      providers: [_ionic_native_diagnostic_ngx__WEBPACK_IMPORTED_MODULE_10__["Diagnostic"], _ionic_native_native_geocoder_ngx__WEBPACK_IMPORTED_MODULE_11__["NativeGeocoder"], _ionic_native_Camera_ngx__WEBPACK_IMPORTED_MODULE_13__["Camera"], _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_14__["File"]]
    })], SchedulePageModule);
    /***/
  },

  /***/
  "./src/app/schedule/schedule.page.scss":
  /*!*********************************************!*\
    !*** ./src/app/schedule/schedule.page.scss ***!
    \*********************************************/

  /*! exports provided: default */

  /***/
  function srcAppScheduleSchedulePageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".segments {\n  height: 40px;\n}\n\nion-segment {\n  --background: #EFEFEF;\n}\n\nion-segment-button {\n  --indicator-color: #3c78d8;\n  --color-checked: white;\n}\n\nhtml, body {\n  background-color: white !important;\n}\n\nion-app {\n  --background: white !important;\n}\n\nion-content {\n  --background: white !important;\n}\n\napp-ar ion-content {\n  --background: white;\n}\n\n.schedule-area-border {\n  box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.3);\n  border-top-left-radius: 2em;\n  border-top-right-radius: 2em;\n}\n\n.margin-top {\n  margin-top: 16px;\n}\n\n.edit_span {\n  color: gray;\n  pointer-events: none;\n}\n\n.mrT {\n  margin-top: -11px !important;\n  font-size: 10px !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2NoZWR1bGUvRjpcXG1vYmlsZWFwcC9zcmNcXGFwcFxcc2NoZWR1bGVcXHNjaGVkdWxlLnBhZ2Uuc2NzcyIsInNyYy9hcHAvc2NoZWR1bGUvc2NoZWR1bGUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsWUFBQTtBQ0NGOztBREVBO0VBQ0UscUJBQUE7QUNDRjs7QURFQTtFQUNFLDBCQUFBO0VBQ0Esc0JBQUE7QUNDRjs7QURFQTtFQUNJLGtDQUFBO0FDQ0o7O0FERUE7RUFDSSw4QkFBQTtBQ0NKOztBREVBO0VBQ0ksOEJBQUE7QUNDSjs7QURFQTtFQUNJLG1CQUFBO0FDQ0o7O0FERUE7RUFDRSwwQ0FBQTtFQUNBLDJCQUFBO0VBQ0EsNEJBQUE7QUNDRjs7QURFQTtFQUNFLGdCQUFBO0FDQ0Y7O0FERUE7RUFDRSxXQUFBO0VBQ0Esb0JBQUE7QUNDRjs7QURNQTtFQUNFLDRCQUFBO0VBQTRCLDBCQUFBO0FDRjlCIiwiZmlsZSI6InNyYy9hcHAvc2NoZWR1bGUvc2NoZWR1bGUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnNlZ21lbnRzIHtcclxuICBoZWlnaHQ6IDQwcHg7XHJcbn1cclxuXHJcbmlvbi1zZWdtZW50IHtcclxuICAtLWJhY2tncm91bmQ6ICNFRkVGRUY7XHJcbn1cclxuXHJcbmlvbi1zZWdtZW50LWJ1dHRvbiB7XHJcbiAgLS1pbmRpY2F0b3ItY29sb3I6ICMzYzc4ZDg7XHJcbiAgLS1jb2xvci1jaGVja2VkOiB3aGl0ZTtcclxufVxyXG5cclxuaHRtbCwgYm9keSB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG5pb24tYXBwIHtcclxuICAgIC0tYmFja2dyb3VuZDogd2hpdGUgIWltcG9ydGFudDtcclxufVxyXG5cclxuaW9uLWNvbnRlbnQge1xyXG4gICAgLS1iYWNrZ3JvdW5kOiB3aGl0ZSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG5hcHAtYXIgaW9uLWNvbnRlbnQge1xyXG4gICAgLS1iYWNrZ3JvdW5kOiB3aGl0ZTtcclxufVxyXG5cclxuLnNjaGVkdWxlLWFyZWEtYm9yZGVyIHtcclxuICBib3gtc2hhZG93OiAwIDFweCAycHggMCByZ2JhKDAsIDAsIDAsIDAuMyk7XHJcbiAgYm9yZGVyLXRvcC1sZWZ0LXJhZGl1czogMmVtO1xyXG4gIGJvcmRlci10b3AtcmlnaHQtcmFkaXVzOiAyZW07XHJcbn1cclxuXHJcbi5tYXJnaW4tdG9wIHtcclxuICBtYXJnaW4tdG9wOiAxNnB4O1xyXG59XHJcblxyXG4uZWRpdF9zcGFue1xyXG4gIGNvbG9yOiBncmF5O1xyXG4gIHBvaW50ZXItZXZlbnRzOiBub25lO1xyXG59XHJcblxyXG4vLyAuYWRkcmVzcy10ZXh0IHtcclxuLy8gICBmb250LXNpemU6IDEuMmVtO1xyXG4vLyAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4vLyB9XHJcbi5tclR7XHJcbiAgbWFyZ2luLXRvcDotMTFweCAhaW1wb3J0YW50O2ZvbnQtc2l6ZTogMTBweCFpbXBvcnRhbnQ7XHJcbn1cclxuIiwiLnNlZ21lbnRzIHtcbiAgaGVpZ2h0OiA0MHB4O1xufVxuXG5pb24tc2VnbWVudCB7XG4gIC0tYmFja2dyb3VuZDogI0VGRUZFRjtcbn1cblxuaW9uLXNlZ21lbnQtYnV0dG9uIHtcbiAgLS1pbmRpY2F0b3ItY29sb3I6ICMzYzc4ZDg7XG4gIC0tY29sb3ItY2hlY2tlZDogd2hpdGU7XG59XG5cbmh0bWwsIGJvZHkge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xufVxuXG5pb24tYXBwIHtcbiAgLS1iYWNrZ3JvdW5kOiB3aGl0ZSAhaW1wb3J0YW50O1xufVxuXG5pb24tY29udGVudCB7XG4gIC0tYmFja2dyb3VuZDogd2hpdGUgIWltcG9ydGFudDtcbn1cblxuYXBwLWFyIGlvbi1jb250ZW50IHtcbiAgLS1iYWNrZ3JvdW5kOiB3aGl0ZTtcbn1cblxuLnNjaGVkdWxlLWFyZWEtYm9yZGVyIHtcbiAgYm94LXNoYWRvdzogMCAxcHggMnB4IDAgcmdiYSgwLCAwLCAwLCAwLjMpO1xuICBib3JkZXItdG9wLWxlZnQtcmFkaXVzOiAyZW07XG4gIGJvcmRlci10b3AtcmlnaHQtcmFkaXVzOiAyZW07XG59XG5cbi5tYXJnaW4tdG9wIHtcbiAgbWFyZ2luLXRvcDogMTZweDtcbn1cblxuLmVkaXRfc3BhbiB7XG4gIGNvbG9yOiBncmF5O1xuICBwb2ludGVyLWV2ZW50czogbm9uZTtcbn1cblxuLm1yVCB7XG4gIG1hcmdpbi10b3A6IC0xMXB4ICFpbXBvcnRhbnQ7XG4gIGZvbnQtc2l6ZTogMTBweCAhaW1wb3J0YW50O1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/schedule/schedule.page.ts":
  /*!*******************************************!*\
    !*** ./src/app/schedule/schedule.page.ts ***!
    \*******************************************/

  /*! exports provided: SchedulePage */

  /***/
  function srcAppScheduleSchedulePageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SchedulePage", function () {
      return SchedulePage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _ionic_native_native_geocoder_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic-native/native-geocoder/ngx */
    "./node_modules/@ionic-native/native-geocoder/ngx/index.js");
    /* harmony import */


    var _ionic_native_geolocation_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic-native/geolocation/ngx */
    "./node_modules/@ionic-native/geolocation/ngx/index.js");
    /* harmony import */


    var _storage_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ../storage.service */
    "./src/app/storage.service.ts");
    /* harmony import */


    var _utilities_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ../utilities.service */
    "./src/app/utilities.service.ts");
    /* harmony import */


    var _ionic_native_diagnostic_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! @ionic-native/diagnostic/ngx */
    "./node_modules/@ionic-native/diagnostic/ngx/index.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _model_constants__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! ../model/constants */
    "./src/app/model/constants.ts");

    var SchedulePage = /*#__PURE__*/function () {
      function SchedulePage(navController, nativeGeocoder, diagnostic, geolocation, platform, storage, utilities, router, alertController, toastController) {
        _classCallCheck(this, SchedulePage);

        this.navController = navController;
        this.nativeGeocoder = nativeGeocoder;
        this.diagnostic = diagnostic;
        this.geolocation = geolocation;
        this.platform = platform;
        this.storage = storage;
        this.utilities = utilities;
        this.router = router;
        this.alertController = alertController;
        this.toastController = toastController;
        this.address = '';
        this.currentTab = 'design';
        this.tabsDisabled = false; // Geocoder configuration

        this.geoEncoderOptions = {
          useLocale: true,
          maxResults: 5
        };
        this.locationAllowed = false;
        this.gpsActive = false;
        var url = this.router.url;
        var splittedUrl = url.split('/');
        console.log(splittedUrl);
        this.tabsDisabled = splittedUrl.length === 4;
        this.currentTab = splittedUrl[2];
      }

      _createClass(SchedulePage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this20 = this;

          this.userdata = this.storage.getUser();
          this.requestLocationPermission();

          if (this.tabsDisabled) {
            this.subscription = this.utilities.getStaticAddress().subscribe(function (address) {
              _this20.address = address;

              _this20.storage.setData(_this20.address);
            });
          } else {
            // await this.getGeoLocation();
            this.subscription = this.utilities.getAddressObservable().subscribe(function (address) {
              console.log(address);
              _this20.address = address.address;

              _this20.storage.setData(_this20.address);
            });
          }
        }
      }, {
        key: "goBack",
        value: function goBack() {
          this.navController.pop();
        }
      }, {
        key: "ngOnDestroy",
        value: function ngOnDestroy() {
          this.subscription.unsubscribe();
          this.utilities.setStaticAddress('');
        }
      }, {
        key: "segmentChanged",
        value: function segmentChanged(event) {
          console.log(event);
          this.currentTab = event.detail.value;
          this.tabs.select(event.detail.value);
        }
      }, {
        key: "getGeoLocation",
        value: function getGeoLocation() {
          var _this21 = this;

          // this.utilities.showLoading('Getting Location').then(()=>{
          // setTimeout(()=>{
          //   this.utilities.hideLoading();
          // },1000)
          this.geolocation.getCurrentPosition().then(function (resp) {
            _this21.utilities.hideLoading(); // .then(()=>{


            console.log('resp', resp);

            _this21.getGeoEncoder(resp.coords.latitude, resp.coords.longitude);

            _this21.utilities.hideLoading(); // });

          }, function (err) {
            _this21.utilities.hideLoading();

            _this21.utilities.errorSnackBar('Unable to get location');
          })["catch"](function (error) {
            _this21.utilities.hideLoading();

            _this21.utilities.errorSnackBar('Unable to get location');

            console.log('Error getting location', error);

            _this21.showNoLocation();
          }); // },err=>{
          //   this.utilities.hideLoading();
          // });
        }
      }, {
        key: "showNoLocation",
        value: function showNoLocation() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
            var _this22 = this;

            var toast;
            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    _context2.next = 2;
                    return this.toastController.create({
                      header: 'Error',
                      message: 'Unable to get location',
                      cssClass: 'my-custom-class',
                      buttons: [{
                        text: 'OK',
                        handler: function handler() {
                          _this22.goBack();
                        }
                      }]
                    });

                  case 2:
                    toast = _context2.sent;
                    toast.present();

                  case 4:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2, this);
          }));
        }
      }, {
        key: "showLocationDenied",
        value: function showLocationDenied() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
            var _this23 = this;

            var toast;
            return regeneratorRuntime.wrap(function _callee3$(_context3) {
              while (1) {
                switch (_context3.prev = _context3.next) {
                  case 0:
                    _context3.next = 2;
                    return this.toastController.create({
                      header: 'Error',
                      message: 'Location services denied, please enable them manually',
                      cssClass: 'my-custom-class',
                      buttons: [{
                        text: 'OK',
                        handler: function handler() {
                          _this23.goBack();
                        }
                      }]
                    });

                  case 2:
                    toast = _context3.sent;
                    toast.present();

                  case 4:
                  case "end":
                    return _context3.stop();
                }
              }
            }, _callee3, this);
          }));
        }
      }, {
        key: "getGeoEncoder",
        value: function getGeoEncoder(latitude, longitude) {
          var _this24 = this;

          // this.utilities.hideLoading().then((success) => {
          this.utilities.showLoading('Getting Location').then(function () {
            _this24.nativeGeocoder.reverseGeocode(latitude, longitude, _this24.geoEncoderOptions).then(function (result) {
              console.log(result);

              _this24.utilities.hideLoading();

              var address = {
                address: _this24.generateAddress(result[0]),
                lat: latitude,
                "long": longitude,
                country: result[0].countryName,
                state: result[0].administrativeArea,
                city: result[0].locality,
                postalcode: result[0].postalCode
              };

              _this24.utilities.setAddress(address);
            })["catch"](function (error) {
              _this24.showNoLocation();

              _this24.utilities.hideLoading();

              alert('Error getting location' + JSON.stringify(error));
            });
          }); // }, (error) => {
          // }
          // );
        }
      }, {
        key: "generateAddress",
        value: function generateAddress(addressObj) {
          var obj = [];
          var address = '';

          for (var key in addressObj) {
            obj.push(addressObj[key]);
          }

          obj.reverse();

          for (var val in obj) {
            if (obj[val].length) {
              address += obj[val] + ', ';
            }
          }

          return address.slice(0, -2);
        }
      }, {
        key: "requestLocationPermission",
        value: function requestLocationPermission() {
          var _this25 = this;

          this.diagnostic.requestLocationAuthorization(this.diagnostic.locationAuthorizationMode.WHEN_IN_USE).then(function (mode) {
            console.log(mode);

            switch (mode) {
              case _this25.diagnostic.permissionStatus.NOT_REQUESTED:
                _this25.goBack();

                break;

              case _this25.diagnostic.permissionStatus.DENIED_ALWAYS:
                _this25.showLocationDenied();

                break;

              case _this25.diagnostic.permissionStatus.DENIED_ONCE:
                _this25.goBack();

                break;

              case _this25.diagnostic.permissionStatus.GRANTED:
                _this25.fetchLocation();

                break;

              case _this25.diagnostic.permissionStatus.GRANTED_WHEN_IN_USE:
                _this25.fetchLocation();

                break;

              case 'authorized_when_in_use':
                _this25.fetchLocation();

                break;
            }
          }, function (rejection) {
            console.log(rejection); // this.goBack();
          }); // if (this.platform.is('ios')) {
          //   if (this.storage.isLocationAllowedOnIOS()) {
          //     this.fetchLocation();
          //   } else {
          //     if (!this.storage.isLocationCheckedOnIOS()) {
          //       this.storage.setLocationCheckedOnIOS(true);
          //       this.diagnostic.requestLocationAuthorization(this.diagnostic.locationAuthorizationMode.WHEN_IN_USE).then((mode) => {
          //         switch (mode) {
          //           case this.diagnostic.permissionStatus.NOT_REQUESTED:
          //             this.storage.setLocationAllowedOnIOS(false);
          //             break;
          //           case this.diagnostic.permissionStatus.DENIED_ALWAYS:
          //             this.storage.setLocationAllowedOnIOS(false);
          //             break;
          //           case this.diagnostic.permissionStatus.GRANTED:
          //             this.storage.setLocationAllowedOnIOS(true);
          //             this.fetchLocation();
          //             break;
          //           case this.diagnostic.permissionStatus.GRANTED_WHEN_IN_USE:
          //             this.storage.setLocationAllowedOnIOS(true);
          //             this.fetchLocation();
          //             break;
          //           case 'authorized_when_in_use':
          //             this.storage.setLocationAllowedOnIOS(true);
          //             this.fetchLocation();
          //             break;
          //         }
          //       }, (rejection) => {
          //         this.locationAllowed = false;
          //         this.storage.setLocationAllowedOnIOS(false);
          //       });
          //     }
          //   }
          // } else {
          //
          // }
        }
      }, {
        key: "fetchLocation",
        value: function fetchLocation() {
          var _this26 = this;

          if (this.platform.is('ios')) {
            this.getGeoLocation();
          } else {
            this.diagnostic.isGpsLocationEnabled().then(function (status) {
              if (status === true) {
                _this26.getGeoLocation(); // this.utilities.showLoading('Getting Location').then(() => {
                // });

              } else {
                _this26.askToChangeSettings();
              }
            });
          }
        }
      }, {
        key: "askToChangeSettings",
        value: function askToChangeSettings() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
            var _this27 = this;

            var toast;
            return regeneratorRuntime.wrap(function _callee4$(_context4) {
              while (1) {
                switch (_context4.prev = _context4.next) {
                  case 0:
                    _context4.next = 2;
                    return this.toastController.create({
                      header: 'Location Disabled',
                      message: 'Please enable location services',
                      cssClass: 'my-custom-class',
                      buttons: [{
                        text: 'OK',
                        handler: function handler() {
                          _this27.changeLocationSettings();
                        }
                      }, {
                        text: 'Cancel',
                        handler: function handler() {
                          _this27.goBack();
                        }
                      }]
                    });

                  case 2:
                    toast = _context4.sent;
                    toast.present();

                  case 4:
                  case "end":
                    return _context4.stop();
                }
              }
            }, _callee4, this);
          }));
        }
      }, {
        key: "changeLocationSettings",
        value: function changeLocationSettings() {
          var _this28 = this;

          this.diagnostic.switchToLocationSettings();
          this.diagnostic.registerLocationStateChangeHandler(function (state) {
            if (_this28.platform.is('android') && state !== _this28.diagnostic.locationMode.LOCATION_OFF || _this28.platform.is('ios') && (state === _this28.diagnostic.permissionStatus.GRANTED || state === _this28.diagnostic.permissionStatus.GRANTED_WHEN_IN_USE)) {
              _this28.checkLocationAccess();
            }
          });
        }
      }, {
        key: "checkLocationAccess",
        value: function checkLocationAccess() {
          var _this29 = this;

          this.diagnostic.isLocationAuthorized().then(function (success) {
            _this29.fetchLocation();
          }, function (error) {
            _this29.utilities.showSnackBar('GPS Not Allowed');
          });
        }
      }, {
        key: "goTo",
        value: function goTo() {
          this.router.navigate(['/mappage']);
        }
      }, {
        key: "saveDesignForm",
        value: function saveDesignForm() {
          console.log('posting value');
          this.utilities.setScheduleFormEvent(_model_constants__WEBPACK_IMPORTED_MODULE_9__["ScheduleFormEvent"].SAVE_DESIGN_FORM);
        }
      }, {
        key: "saveSurveyForm",
        value: function saveSurveyForm() {
          console.log('posting value');
          this.utilities.setScheduleFormEvent(_model_constants__WEBPACK_IMPORTED_MODULE_9__["ScheduleFormEvent"].SAVE_SURVEY_FORM);
        }
      }, {
        key: "startSurvey",
        value: function startSurvey() {
          console.log('posting value');
          this.utilities.setScheduleFormEvent(_model_constants__WEBPACK_IMPORTED_MODULE_9__["ScheduleFormEvent"].START_SURVEY);
        }
      }]);

      return SchedulePage;
    }();

    SchedulePage.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"]
      }, {
        type: _ionic_native_native_geocoder_ngx__WEBPACK_IMPORTED_MODULE_3__["NativeGeocoder"]
      }, {
        type: _ionic_native_diagnostic_ngx__WEBPACK_IMPORTED_MODULE_7__["Diagnostic"]
      }, {
        type: _ionic_native_geolocation_ngx__WEBPACK_IMPORTED_MODULE_4__["Geolocation"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"]
      }, {
        type: _storage_service__WEBPACK_IMPORTED_MODULE_5__["StorageService"]
      }, {
        type: _utilities_service__WEBPACK_IMPORTED_MODULE_6__["UtilitiesService"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_8__["Router"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]
      }];
    };

    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('tabs', {
      "static": true
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonTabs"])], SchedulePage.prototype, "tabs", void 0);
    SchedulePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-schedule',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./schedule.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/schedule/schedule.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./schedule.page.scss */
      "./src/app/schedule/schedule.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"], _ionic_native_native_geocoder_ngx__WEBPACK_IMPORTED_MODULE_3__["NativeGeocoder"], _ionic_native_diagnostic_ngx__WEBPACK_IMPORTED_MODULE_7__["Diagnostic"], _ionic_native_geolocation_ngx__WEBPACK_IMPORTED_MODULE_4__["Geolocation"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"], _storage_service__WEBPACK_IMPORTED_MODULE_5__["StorageService"], _utilities_service__WEBPACK_IMPORTED_MODULE_6__["UtilitiesService"], _angular_router__WEBPACK_IMPORTED_MODULE_8__["Router"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]])], SchedulePage);
    /***/
  },

  /***/
  "./src/app/schedule/survey/survey.component.scss":
  /*!*******************************************************!*\
    !*** ./src/app/schedule/survey/survey.component.scss ***!
    \*******************************************************/

  /*! exports provided: default */

  /***/
  function srcAppScheduleSurveySurveyComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".error {\n  color: #df3e3e;\n  font-size: 11px;\n}\n\nion-select {\n  max-width: 100% !important;\n  width: 100% !important;\n  padding-left: 0px !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2NoZWR1bGUvc3VydmV5L0Y6XFxtb2JpbGVhcHAvc3JjXFxhcHBcXHNjaGVkdWxlXFxzdXJ2ZXlcXHN1cnZleS5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvc2NoZWR1bGUvc3VydmV5L3N1cnZleS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGNBQUE7RUFDQSxlQUFBO0FDQ0Y7O0FERUE7RUFDRSwwQkFBQTtFQUNBLHNCQUFBO0VBQ0EsNEJBQUE7QUNDRiIsImZpbGUiOiJzcmMvYXBwL3NjaGVkdWxlL3N1cnZleS9zdXJ2ZXkuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuZXJyb3Ige1xyXG4gIGNvbG9yOiByZ2IoMjIzLCA2MiwgNjIpO1xyXG4gIGZvbnQtc2l6ZTogMTFweDtcclxufVxyXG5cclxuaW9uLXNlbGVjdHtcclxuICBtYXgtd2lkdGg6IDEwMCUgIWltcG9ydGFudDtcclxuICB3aWR0aDogMTAwJSAhaW1wb3J0YW50O1xyXG4gIHBhZGRpbmctbGVmdDogMHB4ICFpbXBvcnRhbnQ7XHJcbn1cclxuIiwiLmVycm9yIHtcbiAgY29sb3I6ICNkZjNlM2U7XG4gIGZvbnQtc2l6ZTogMTFweDtcbn1cblxuaW9uLXNlbGVjdCB7XG4gIG1heC13aWR0aDogMTAwJSAhaW1wb3J0YW50O1xuICB3aWR0aDogMTAwJSAhaW1wb3J0YW50O1xuICBwYWRkaW5nLWxlZnQ6IDBweCAhaW1wb3J0YW50O1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/schedule/survey/survey.component.ts":
  /*!*****************************************************!*\
    !*** ./src/app/schedule/survey/survey.component.ts ***!
    \*****************************************************/

  /*! exports provided: SurveyComponent */

  /***/
  function srcAppScheduleSurveySurveyComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SurveyComponent", function () {
      return SurveyComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _utilities_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ../../utilities.service */
    "./src/app/utilities.service.ts");
    /* harmony import */


    var _model_constants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ../../model/constants */
    "./src/app/model/constants.ts");
    /* harmony import */


    var _api_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ../../api.service */
    "./src/app/api.service.ts");
    /* harmony import */


    var _storage_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ../../storage.service */
    "./src/app/storage.service.ts");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");

    var SurveyComponent = /*#__PURE__*/function () {
      function SurveyComponent(formBuilder, navController, utilities, platform, apiService, storage, route) {
        _classCallCheck(this, SurveyComponent);

        this.formBuilder = formBuilder;
        this.navController = navController;
        this.utilities = utilities;
        this.platform = platform;
        this.apiService = apiService;
        this.storage = storage;
        this.route = route;
        this.listOfAssignees = [];
        this.emailError = _model_constants__WEBPACK_IMPORTED_MODULE_5__["INVALID_EMAIL_MESSAGE"];
        this.fieldRequired = _model_constants__WEBPACK_IMPORTED_MODULE_5__["FIELD_REQUIRED"];
        this.surveyId = 0;
        this.surveyId = +this.route.snapshot.paramMap.get('id');
        var EMAILPATTERN = /^[a-z0-9!#$%&'*+\/=?^_`{|}~.-]+@[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)*$/i;
        this.surveyForm = this.formBuilder.group({
          name: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
          email: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].pattern(EMAILPATTERN)]),
          phonenumber: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
          jobtype: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
          datetime: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](new Date().getTime(), [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
          comments: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](''),
          address: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
          source: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('android', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
          assignedto: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](null),
          createdby: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](this.storage.getUserID(), [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
          latitude: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](''),
          longitude: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](''),
          country: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](''),
          state: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](''),
          city: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](''),
          postalcode: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](''),
          status: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('created')
        });
      }

      _createClass(SurveyComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this30 = this;

          // this.address= this.storage.getData();
          this.subscription = this.utilities.getScheduleFormEvent().subscribe(function (event) {
            switch (event) {
              case _model_constants__WEBPACK_IMPORTED_MODULE_5__["ScheduleFormEvent"].SAVE_SURVEY_FORM:
                _this30.saveSurvey();

                break;

              case _model_constants__WEBPACK_IMPORTED_MODULE_5__["ScheduleFormEvent"].START_SURVEY:
                _this30.startSurvey();

                break;
            }
          });

          if (this.surveyId !== 0) {
            this.getSurveyDetails();
          } else {
            this.addressSubscription = this.utilities.getAddressObservable().subscribe(function (address) {
              _this30.surveyForm.get('address').setValue("sdck");

              _this30.surveyForm.get('latitude').setValue('1111111');

              _this30.surveyForm.get('longitude').setValue('222222222');

              _this30.surveyForm.get('country').setValue('India');

              _this30.surveyForm.get('city').setValue('delhi');

              _this30.surveyForm.get('state').setValue('up');

              _this30.surveyForm.get('postalcode').setValue(777777777); // this.surveyForm.get('address').setValue(address.address);
              //this.surveyForm.get('latitude').setValue(address.lat);
              //this.surveyForm.get('longitude').setValue(address.long);
              // this.surveyForm.get('country').setValue(address.country);
              //this.surveyForm.get('city').setValue(address.city);
              //this.surveyForm.get('state').setValue(address.state);
              //this.surveyForm.get('postalcode').setValue(address.postalcode);

            }, function (error) {
              _this30.surveyForm.get('address').setValue('');

              _this30.surveyForm.get('latitude').setValue('');

              _this30.surveyForm.get('longitude').setValue('');

              _this30.surveyForm.get('country').setValue('');

              _this30.surveyForm.get('city').setValue('');

              _this30.surveyForm.get('state').setValue('');

              _this30.surveyForm.get('postalcode').setValue('');
            });
          }

          this.getAssignees();
        }
      }, {
        key: "ngOnDestroy",
        value: function ngOnDestroy() {
          this.subscription.unsubscribe();

          if (this.surveyId === 0) {
            this.addressSubscription.unsubscribe();
          } // this.utilities.getScheduleFormEvent().unsubscribe();

        }
      }, {
        key: "startSurvey",
        value: function startSurvey() {
          var _this31 = this;

          if (this.surveyForm.status === 'INVALID') {
            this.showInvalidFormAlert();
          } else {
            this.utilities.showLoading('Saving Survey').then(function () {
              if (_this31.surveyId !== 0) {
                _this31.apiService.updateSurveyForm(_this31.surveyForm.value, _this31.surveyId).subscribe(function (survey) {
                  _this31.utilities.hideLoading().then(function () {
                    _this31.utilities.setDesignDetailsRefresh(true);

                    _this31.navController.navigateForward('camera/' + survey.id + '/' + survey.jobtype + '/' + survey.latitude + '/' + survey.longitude);
                  });
                });
              } else {
                // if starting survey directly, assign the survey to yourself
                _this31.surveyForm.get('assignedto').setValue(_this31.storage.getUserID());

                _this31.surveyForm.get('status').setValue('surveyassigned');

                _this31.apiService.saveSurvey(_this31.surveyForm.value).subscribe(function (survey) {
                  _this31.utilities.hideLoading().then(function () {
                    _this31.utilities.setDesignDetailsRefresh(true);

                    _this31.navController.navigateForward('camera/' + survey.id + '/' + survey.jobtype + '/' + survey.latitude + '/' + survey.longitude);
                  });
                });
              }
            });
          }
        }
      }, {
        key: "saveSurvey",
        value: function saveSurvey() {
          var _this32 = this;

          if (this.surveyForm.status === 'INVALID') {
            console.log(this.surveyForm.value);

            if (this.surveyForm.value.name == '') {
              this.utilities.errorSnackBar('Please enter name.');
            } else if (this.surveyForm.value.email == '') {
              this.utilities.errorSnackBar('Please enter email.');
            } else if (this.surveyForm.value.phonenumber == '') {
              this.utilities.errorSnackBar('Please enter phone number.');
            } else if (this.surveyForm.value.jobtype == '') {
              this.utilities.errorSnackBar('Please enter job type.');
            } else {
              this.utilities.errorSnackBar('Address not found. Make sure your location is on in device.');
            }
          } else {
            this.utilities.showLoading('Saving Survey').then(function () {
              if (_this32.surveyId !== 0) {
                _this32.apiService.updateSurveyForm(_this32.surveyForm.value, _this32.surveyId).subscribe(function (survey) {
                  _this32.utilities.hideLoading().then(function () {
                    _this32.utilities.showSnackBar('Survey has been updated');

                    _this32.utilities.setSurveyDetailsRefresh(true); // this.navController.navigateRoot('homepage/survey');


                    _this32.navController.pop();
                  });
                });
              } else {
                if (_this32.surveyForm.get('assignedto').value !== '' && _this32.surveyForm.get('assignedto').value !== null && _this32.surveyForm.get('assignedto').value !== undefined && _this32.surveyForm.get('assignedto').value !== 0) {
                  _this32.surveyForm.get('status').setValue('surveyassigned');
                }

                console.log(_this32.surveyForm.value);

                _this32.apiService.saveSurvey(_this32.surveyForm.value).subscribe(function (survey) {
                  _this32.utilities.showSuccessModal('Survey have been saved').then(function (modal) {
                    _this32.utilities.hideLoading(); // this.navController.pop();


                    modal.present();
                    modal.onWillDismiss().then(function (dismissed) {
                      _this32.utilities.sethomepageSurveyRefresh(true);

                      _this32.navController.navigateRoot('homepage/survey');
                    }); // });
                  });
                });
              }
            });
          }
        }
      }, {
        key: "showInvalidFormAlert",
        value: function showInvalidFormAlert() {
          var _this33 = this;

          var error = '';
          Object.keys(this.surveyForm.controls).forEach(function (key) {
            var control = _this33.surveyForm.get(key);

            if (control.invalid) {
              if (error !== '') {
                error = error + '<br/>';
              }

              if (control.errors.required === true) {
                error = error + _this33.utilities.capitalizeWord(key) + ' is required';
              }

              if (control.errors.email === true) {
                error = error + 'Invalid email';
              }

              if (control.errors.error !== null && control.errors.error !== undefined) {
                error = error + control.errors.error;
              }
            }
          });
          console.log(this.surveyForm.value);
          this.utilities.showAlert(error);
        }
      }, {
        key: "getAssignees",
        value: function getAssignees() {
          var _this34 = this;

          this.apiService.getSurveyors().subscribe(function (assignees) {
            _this34.listOfAssignees = [];
            assignees.forEach(function (item) {
              return _this34.listOfAssignees.push(item);
            });
            console.log(_this34.listOfAssignees);
          });
        }
      }, {
        key: "getSurveyDetails",
        value: function getSurveyDetails() {
          var _this35 = this;

          this.utilities.showLoading('Getting Survey Details').then(function (success) {
            _this35.apiService.getSurveyDetail(_this35.surveyId).subscribe(function (result) {
              _this35.utilities.hideLoading().then(function () {
                _this35.survey = result;
                var date = new Date(_this35.survey.datetime);

                _this35.surveyForm.patchValue({
                  name: _this35.survey.name,
                  email: _this35.survey.email,
                  jobtype: _this35.survey.jobtype,
                  phonenumber: _this35.survey.phonenumber,
                  datetime: date.getTime(),
                  comments: _this35.survey.comments[0].message,
                  address: _this35.survey.address,
                  source: _this35.survey.source,
                  createdby: _this35.survey.createdby.id,
                  latitude: _this35.survey.latitude,
                  longitude: _this35.survey.longitude,
                  country: _this35.survey.country,
                  state: _this35.survey.state,
                  city: _this35.survey.city,
                  postalcode: _this35.survey.postalcode
                });

                if (_this35.survey.assignedto !== null && _this35.survey.assignedto !== undefined) {
                  _this35.surveyForm.patchValue({
                    assignedto: _this35.survey.assignedto.id,
                    status: 'surveyassigned'
                  });
                }

                _this35.utilities.setStaticAddress(_this35.survey.address);
              });
            }, function (error) {
              _this35.utilities.hideLoading();
            });
          });
        }
      }]);

      return SurveyComponent;
    }();

    SurveyComponent.ctorParameters = function () {
      return [{
        type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"]
      }, {
        type: _utilities_service__WEBPACK_IMPORTED_MODULE_4__["UtilitiesService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["Platform"]
      }, {
        type: _api_service__WEBPACK_IMPORTED_MODULE_6__["ApiService"]
      }, {
        type: _storage_service__WEBPACK_IMPORTED_MODULE_7__["StorageService"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_8__["ActivatedRoute"]
      }];
    };

    SurveyComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-survey',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./survey.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/schedule/survey/survey.component.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./survey.component.scss */
      "./src/app/schedule/survey/survey.component.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"], _utilities_service__WEBPACK_IMPORTED_MODULE_4__["UtilitiesService"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["Platform"], _api_service__WEBPACK_IMPORTED_MODULE_6__["ApiService"], _storage_service__WEBPACK_IMPORTED_MODULE_7__["StorageService"], _angular_router__WEBPACK_IMPORTED_MODULE_8__["ActivatedRoute"]])], SurveyComponent);
    /***/
  }
}]);
//# sourceMappingURL=schedule-schedule-module-es5.js.map