(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["search-bar1-search-bar1-module"],{

/***/ "./node_modules/@ionic-native/native-geocoder/ngx/index.js":
/*!*****************************************************************!*\
  !*** ./node_modules/@ionic-native/native-geocoder/ngx/index.js ***!
  \*****************************************************************/
/*! exports provided: NativeGeocoder */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NativeGeocoder", function() { return NativeGeocoder; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_native_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic-native/core */ "./node_modules/@ionic-native/core/index.js");



var NativeGeocoder = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(NativeGeocoder, _super);
    function NativeGeocoder() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    NativeGeocoder.prototype.reverseGeocode = function (latitude, longitude, options) { return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "reverseGeocode", { "callbackOrder": "reverse" }, arguments); };
    NativeGeocoder.prototype.forwardGeocode = function (addressString, options) { return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "forwardGeocode", { "callbackOrder": "reverse" }, arguments); };
    NativeGeocoder.pluginName = "NativeGeocoder";
    NativeGeocoder.plugin = "cordova-plugin-nativegeocoder";
    NativeGeocoder.pluginRef = "nativegeocoder";
    NativeGeocoder.repo = "https://github.com/sebastianbaar/cordova-plugin-nativegeocoder";
    NativeGeocoder.platforms = ["iOS", "Android"];
    NativeGeocoder = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])()
    ], NativeGeocoder);
    return NativeGeocoder;
}(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["IonicNativePlugin"]));

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvQGlvbmljLW5hdGl2ZS9wbHVnaW5zL25hdGl2ZS1nZW9jb2Rlci9uZ3gvaW5kZXgudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDM0MsT0FBTyw4QkFBc0MsTUFBTSxvQkFBb0IsQ0FBQzs7SUF3Q3BDLGtDQUFpQjs7OztJQVduRCx1Q0FBYyxhQUNaLFFBQWdCLEVBQ2hCLFNBQWlCLEVBQ2pCLE9BQStCO0lBY2pDLHVDQUFjLGFBQUMsYUFBcUIsRUFBRSxPQUErQjs7Ozs7O0lBNUIxRCxjQUFjO1FBRDFCLFVBQVUsRUFBRTtPQUNBLGNBQWM7eUJBekMzQjtFQXlDb0MsaUJBQWlCO1NBQXhDLGNBQWMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBDb3Jkb3ZhLCBJb25pY05hdGl2ZVBsdWdpbiwgUGx1Z2luIH0gZnJvbSAnQGlvbmljLW5hdGl2ZS9jb3JlJztcblxuLyoqXG4gKiBAbmFtZSBOYXRpdmUgR2VvY29kZXJcbiAqIEBkZXNjcmlwdGlvblxuICogQ29yZG92YSBwbHVnaW4gZm9yIG5hdGl2ZSBmb3J3YXJkIGFuZCByZXZlcnNlIGdlb2NvZGluZ1xuICpcbiAqIEB1c2FnZVxuICogYGBgdHlwZXNjcmlwdFxuICogaW1wb3J0IHsgTmF0aXZlR2VvY29kZXIsIE5hdGl2ZUdlb2NvZGVyUmVzdWx0LCBOYXRpdmVHZW9jb2Rlck9wdGlvbnMgfSBmcm9tICdAaW9uaWMtbmF0aXZlL25hdGl2ZS1nZW9jb2Rlci9uZ3gnO1xuICpcbiAqIGNvbnN0cnVjdG9yKHByaXZhdGUgbmF0aXZlR2VvY29kZXI6IE5hdGl2ZUdlb2NvZGVyKSB7IH1cbiAqXG4gKiAuLi5cbiAqXG4gKiBsZXQgb3B0aW9uczogTmF0aXZlR2VvY29kZXJPcHRpb25zID0ge1xuICogICAgIHVzZUxvY2FsZTogdHJ1ZSxcbiAqICAgICBtYXhSZXN1bHRzOiA1XG4gKiB9O1xuICpcbiAqIHRoaXMubmF0aXZlR2VvY29kZXIucmV2ZXJzZUdlb2NvZGUoNTIuNTA3MjA5NSwgMTMuMTQ1MjgxOCwgb3B0aW9ucylcbiAqICAgLnRoZW4oKHJlc3VsdDogTmF0aXZlR2VvY29kZXJSZXN1bHRbXSkgPT4gY29uc29sZS5sb2coSlNPTi5zdHJpbmdpZnkocmVzdWx0WzBdKSkpXG4gKiAgIC5jYXRjaCgoZXJyb3I6IGFueSkgPT4gY29uc29sZS5sb2coZXJyb3IpKTtcbiAqXG4gKiB0aGlzLm5hdGl2ZUdlb2NvZGVyLmZvcndhcmRHZW9jb2RlKCdCZXJsaW4nLCBvcHRpb25zKVxuICogICAudGhlbigocmVzdWx0OiBOYXRpdmVHZW9jb2RlclJlc3VsdFtdKSA9PiBjb25zb2xlLmxvZygnVGhlIGNvb3JkaW5hdGVzIGFyZSBsYXRpdHVkZT0nICsgcmVzdWx0WzBdLmxhdGl0dWRlICsgJyBhbmQgbG9uZ2l0dWRlPScgKyByZXN1bHRbMF0ubG9uZ2l0dWRlKSlcbiAqICAgLmNhdGNoKChlcnJvcjogYW55KSA9PiBjb25zb2xlLmxvZyhlcnJvcikpO1xuICogYGBgXG4gKiBAaW50ZXJmYWNlc1xuICogTmF0aXZlR2VvY29kZXJSZXN1bHRcbiAqIE5hdGl2ZUdlb2NvZGVyT3B0aW9uc1xuICovXG5AUGx1Z2luKHtcbiAgcGx1Z2luTmFtZTogJ05hdGl2ZUdlb2NvZGVyJyxcbiAgcGx1Z2luOiAnY29yZG92YS1wbHVnaW4tbmF0aXZlZ2VvY29kZXInLFxuICBwbHVnaW5SZWY6ICduYXRpdmVnZW9jb2RlcicsXG4gIHJlcG86ICdodHRwczovL2dpdGh1Yi5jb20vc2ViYXN0aWFuYmFhci9jb3Jkb3ZhLXBsdWdpbi1uYXRpdmVnZW9jb2RlcicsXG4gIHBsYXRmb3JtczogWydpT1MnLCAnQW5kcm9pZCddLFxufSlcbkBJbmplY3RhYmxlKClcbmV4cG9ydCBjbGFzcyBOYXRpdmVHZW9jb2RlciBleHRlbmRzIElvbmljTmF0aXZlUGx1Z2luIHtcbiAgLyoqXG4gICAqIFJldmVyc2UgZ2VvY29kZSBhIGdpdmVuIGxhdGl0dWRlIGFuZCBsb25naXR1ZGUgdG8gZmluZCBsb2NhdGlvbiBhZGRyZXNzXG4gICAqIEBwYXJhbSBsYXRpdHVkZSB7bnVtYmVyfSBUaGUgbGF0aXR1ZGVcbiAgICogQHBhcmFtIGxvbmdpdHVkZSB7bnVtYmVyfSBUaGUgbG9uZ2l0dWRlXG4gICAqIEBwYXJhbSBvcHRpb25zIHtOYXRpdmVHZW9jb2Rlck9wdGlvbnN9IFRoZSBvcHRpb25zXG4gICAqIEByZXR1cm4ge1Byb21pc2U8TmF0aXZlR2VvY29kZXJSZXN1bHRbXT59XG4gICAqL1xuICBAQ29yZG92YSh7XG4gICAgY2FsbGJhY2tPcmRlcjogJ3JldmVyc2UnLFxuICB9KVxuICByZXZlcnNlR2VvY29kZShcbiAgICBsYXRpdHVkZTogbnVtYmVyLFxuICAgIGxvbmdpdHVkZTogbnVtYmVyLFxuICAgIG9wdGlvbnM/OiBOYXRpdmVHZW9jb2Rlck9wdGlvbnNcbiAgKTogUHJvbWlzZTxOYXRpdmVHZW9jb2RlclJlc3VsdFtdPiB7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgLyoqXG4gICAqIEZvcndhcmQgZ2VvY29kZSBhIGdpdmVuIGFkZHJlc3MgdG8gZmluZCBjb29yZGluYXRlc1xuICAgKiBAcGFyYW0gYWRkcmVzc1N0cmluZyB7c3RyaW5nfSBUaGUgYWRkcmVzcyB0byBiZSBnZW9jb2RlZFxuICAgKiBAcGFyYW0gb3B0aW9ucyB7TmF0aXZlR2VvY29kZXJPcHRpb25zfSBUaGUgb3B0aW9uc1xuICAgKiBAcmV0dXJuIHtQcm9taXNlPE5hdGl2ZUdlb2NvZGVyUmVzdWx0W10+fVxuICAgKi9cbiAgQENvcmRvdmEoe1xuICAgIGNhbGxiYWNrT3JkZXI6ICdyZXZlcnNlJyxcbiAgfSlcbiAgZm9yd2FyZEdlb2NvZGUoYWRkcmVzc1N0cmluZzogc3RyaW5nLCBvcHRpb25zPzogTmF0aXZlR2VvY29kZXJPcHRpb25zKTogUHJvbWlzZTxOYXRpdmVHZW9jb2RlclJlc3VsdFtdPiB7XG4gICAgcmV0dXJuO1xuICB9XG59XG5cbi8qKlxuICogRW5jYXBzdWxhdGVzIGZvcm1hdCBpbmZvcm1hdGlvbiBhYm91dCBhIGdlb2NvZGluZyByZXN1bHQuXG4gKiBtb3JlIEluZm86XG4gKiAgLSBodHRwczovL2RldmVsb3Blci5hcHBsZS5jb20vZG9jdW1lbnRhdGlvbi9jb3JlbG9jYXRpb24vY2xwbGFjZW1hcmtcbiAqICAtIGh0dHBzOi8vZGV2ZWxvcGVyLmFuZHJvaWQuY29tL3JlZmVyZW5jZS9hbmRyb2lkL2xvY2F0aW9uL0FkZHJlc3MuaHRtbFxuICovXG5leHBvcnQgaW50ZXJmYWNlIE5hdGl2ZUdlb2NvZGVyUmVzdWx0IHtcbiAgLyoqXG4gICAqIFRoZSBsYXRpdHVkZS5cbiAgICovXG4gIGxhdGl0dWRlOiBzdHJpbmc7XG4gIC8qKlxuICAgKiBUaGUgbG9uZ2l0dWRlLlxuICAgKi9cbiAgbG9uZ2l0dWRlOiBzdHJpbmc7XG4gIC8qKlxuICAgKiBUaGUgY291bnRyeSBjb2RlLlxuICAgKi9cbiAgY291bnRyeUNvZGU6IHN0cmluZztcbiAgLyoqXG4gICAqIFRoZSBjb3VudHJ5IG5hbWUuXG4gICAqL1xuICBjb3VudHJ5TmFtZTogc3RyaW5nO1xuICAvKipcbiAgICogVGhlIHBvc3RhbCBjb2RlLlxuICAgKi9cbiAgcG9zdGFsQ29kZTogc3RyaW5nO1xuICAvKipcbiAgICogVGhlIGFkbWluaXN0cmF0aXZlQXJlYS5cbiAgICovXG4gIGFkbWluaXN0cmF0aXZlQXJlYTogc3RyaW5nO1xuICAvKipcbiAgICogVGhlIHN1YkFkbWluaXN0cmF0aXZlQXJlYS5cbiAgICovXG4gIHN1YkFkbWluaXN0cmF0aXZlQXJlYTogc3RyaW5nO1xuICAvKipcbiAgICogVGhlIGxvY2FsaXR5LlxuICAgKi9cbiAgbG9jYWxpdHk6IHN0cmluZztcbiAgLyoqXG4gICAqIFRoZSBzdWJMb2NhbGl0eS5cbiAgICovXG4gIHN1YkxvY2FsaXR5OiBzdHJpbmc7XG4gIC8qKlxuICAgKiBUaGUgdGhvcm91Z2hmYXJlLlxuICAgKi9cbiAgdGhvcm91Z2hmYXJlOiBzdHJpbmc7XG4gIC8qKlxuICAgKiBUaGUgc3ViVGhvcm91Z2hmYXJlLlxuICAgKi9cbiAgc3ViVGhvcm91Z2hmYXJlOiBzdHJpbmc7XG4gIC8qKlxuICAgKiBUaGUgYXJlYXNPZkludGVyZXN0XG4gICAqL1xuICBhcmVhc09mSW50ZXJlc3Q6IHN0cmluZ1tdO1xufVxuXG4vKipcbiAqIE9wdGlvbnMgZm9yIHJldmVyc2UgYW5kIGZvcndhcmQgZ2VvY29kaW5nLlxuICovXG5leHBvcnQgaW50ZXJmYWNlIE5hdGl2ZUdlb2NvZGVyT3B0aW9ucyB7XG4gIC8qKlxuICAgKiBUaGUgbG9jYWxlIHRvIHVzZSB3aGVuIHJldHVybmluZyB0aGUgYWRkcmVzcyBpbmZvcm1hdGlvbi5cbiAgICogSWYgc2V0IHRvICdmYWxzZScgdGhlIGxvY2FsZSB3aWxsIGFsd2F5cyBiZSAnZW5fVVMnLlxuICAgKiBEZWZhdWx0IGlzICd0cnVlJ1xuICAgKi9cbiAgdXNlTG9jYWxlOiBib29sZWFuO1xuICAvKipcbiAgICogVGhlIGRlZmF1bHQgbG9jYWxlIHRvIHVzZSB3aGVuIHJldHVybmluZyB0aGUgYWRkcmVzcyBpbmZvcm1hdGlvbi5cbiAgICogZS5nLjogJ2ZhLUlSJyBvciAnZGVfREUnLlxuICAgKi9cbiAgZGVmYXVsdExvY2FsZT86IHN0cmluZztcbiAgLyoqXG4gICAqIFRoZSBtYXhpbXVtIG51bWJlciBvZiByZXN1bHQgdG8gcmV0dXJuIChtYXggaXMgNSkuXG4gICAqIERlZmF1bHQgaXMgMVxuICAgKi9cbiAgbWF4UmVzdWx0czogbnVtYmVyO1xufVxuIl19

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/search-bar1/search-bar1.page.html":
/*!*****************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/search-bar1/search-bar1.page.html ***!
  \*****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header class=\"ion-no-border grey-bg;\">  <ion-toolbar>\n    <ion-title ></ion-title>\n    <ion-col size=\"1\">\n      <ion-button fill=\"clear\" size=\"small\" class=\"ion-no-padding\" (click)=\"goBack()\">\n          <ion-img src=\"/assets/images/back.svg\" class=\"action-icon\"></ion-img></ion-button></ion-col>\n          <ion-col  size=\"9\" style=\"text-align:center;font-size: x-large;position: absolute;;\">Search</ion-col>\n     \n <ion-button style=\"float: right;\" fill=\"clear\" ><ion-icon name=\"filter-outline\"></ion-icon>&nbsp;<ion-select value=\"both\" (ionChange)=\"searchfor($event)\" style=\"padding-left: 0px;text-transform: none;\" interface=\"popover\"  [(ngModel)]=\"Type\">\n   <ion-select-option  #d name=\"Designs\" value=\"design\" >{{'Designs' | lowercase}}</ion-select-option>\n   <ion-select-option #s  name=\"Surveys\" value=\"survey\">{{'Surveys' | lowercase}}</ion-select-option>\n   <ion-select-option  value=\"both\">{{'Both' | lowercase}}</ion-select-option>\n </ion-select></ion-button>\n \n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n<ion-searchbar class=\"searchStyle\" debounce=\"0\" placeholder=\"Search Here\" (ionClear)=\"showHome()\" (ionChange)=\"searchfor($event)\" [(ngModel)]=\"searchElement\"></ion-searchbar>\n<ion-card *ngFor=\"let search of SortedModel\" class=\"custom-card\">\n   <p *ngIf=\"search?.type=='design'\">\n    <span style=\"float: left;font-size: medium;color: black;font-size: medium;font-weight: 100; \"  [routerLink]=\"['/design-details/',search?.id]\">{{search?.name}}</span>\n    <span class=\"chipdetail\" style=\"background-color:rgb(228, 77, 102);\"  [routerLink]=\"['/design-details/',search?.id]\" >design</span>\n    <span class=\"chipdetail\" style=\"background-color:rgb(228, 77, 102);\"  [routerLink]=\"['/design-details/',search?.id]\">{{search?.requesttype}}</span>\n    <span class=\"chipdetail\" style=\"background-color: rgb(246, 77, 10);\" *ngIf=\"search?.status == 'requestdeclined'\"  [routerLink]=\"['/design-details/',search?.id]\">Declined</span>\n    <span class=\"chipdetail\" style=\"background-color: rgb(246, 104, 10);\" *ngIf=\"search?.deliverydate > 0\"  [routerLink]=\"['/design-details/',search?.id]\">Overdue</span>\n    <span class=\"chipdetail\" style=\"background-color: rgb(109, 187, 26);\" *ngIf=\"search?.status == 'requestaccepted'\"  [routerLink]=\"['/design-details/',search?.id]\">Accepted</span>\n    <span class=\"chipdetail\" style=\"background-color: rgb(109, 187, 26);\" *ngIf=\"search?.status == 'reviewpassed'\"  [routerLink]=\"['/design-details/',search?.id]\">Review Passed</span>\n    <span class=\"chipdetail\" style=\"background-color: rgb(109, 187, 26);\" *ngIf=\"search?.status == 'delivered'\"  [routerLink]=\"['/design-details/',search?.id]\">Delivered</span>\n    <span class=\"chipdetail\" style=\"background-color: rgb(109, 187, 26);\" *ngIf=\"search?.status == 'designcompleted'\"  [routerLink]=\"['/design-details/',search?.id]\">Completed</span>\n    <span class=\"chipdetail\" style=\"background-color: rgb(109, 187, 26);\" *ngIf=\"search?.status == 'reviewfailed'\"  [routerLink]=\"['/design-details/',search?.id]\">Review Failed</span>\n    <span class=\"chipdetail\" style=\"background-color: #1289A7;\" *ngIf=\"search?.status == 'created'\"  [routerLink]=\"['/design-details/',search?.id]\">Unassigned</span>\n    <span class=\"chipdetail\" style=\"background-color: #1289A7;;\" *ngIf=\"search?.status == 'designassigned'\"  [routerLink]=\"['/design-details/',search?.id]\">Design Assigned</span>\n    <span class=\"chipdetail\" style=\"background-color: #1289A7;;\" *ngIf=\"search?.status == 'reviewassigned'\"  [routerLink]=\"['/design-details/',search?.id]\">In Review</span>\n    <span class=\"chipdetail\" *ngIf=\"search?.isoutsourced == 'true'\" style=\"background-color: #95AFC0;\"  [routerLink]=\"['/design-details/',search?.id]\">Waiting for acceptance</span>\n    <span *ngIf=\"search?.status=='surveyassigned'\" class=\"chipdetail\" style=\"background-color: #3C78D8;\"  [routerLink]=\"['/design-details/',search?.id]\">\n     pending\n   </span>\n   <span fill=\"clear\" background-border=\"clear\" [routerLink]=\"['/','activity',search?.id,'design']\" style=\"float: right;\"  size=\"small\"  ><ion-icon  src=\"/assets/images/activitylist.svg\" ></ion-icon></span>\n   <br><br>\n     <span style=\"float:left;font-size: smaller;\">{{search?.email}}</span><br>\n     <span style=\"float:left;text-align:left;font-size: smaller;\"> {{search?.address}}</span><br>\n     <span style=\"font-size:small ;float:right;font-style: italic;\"> {{search?.updated_at|date: 'dd MMM yyyy'}}</span><br>\n     <span class=\"chipdetail\" style=\"background-color: #95afc0;\"  [routerLink]=\"['/design-details/',search?.id]\">{{search?.company}}</span>\n     <span class=\"chipdetail\" style=\"background-color: #95afc0;\"  [routerLink]=\"['/design-details/',search?.id]\">{{search?.requesttype}}</span>\n     <span class=\"chipdetail\" style=\"background-color: #95afc0;\"  [routerLink]=\"['/design-details/',search?.id]\">{{search?.formattedjobtype}}</span>\n     <span class=\"chipdetail\" style=\"background-color: #95afc0;\"  [routerLink]=\"['/design-details/',search?.id]\">{{search?.source}}</span>\n     <ion-row class=\"ion-no-margin ion-no-margin\">\n      <ion-col *ngIf=\"segments=='requesttype=prelim&status=created&status=outsourced&status=requestaccepted'\">\n          <span *ngIf=\"search?.status == 'created' || search?.status == 'requestaccepted'\" style=\"float:right !important;\" class=\"ion-text-end action-button-color\" (click)=\"openDesigners(search?.id,search)\"\n          >Assign</span>\n          <span style=\"float: right;\">\n\n              <ion-col size=\"8\"  *ngIf=\"search?.status == 'outsourced'\"  class=\"ion-text-end action-button-color\" (click)=\"accept(search?.id,'requestaccepted')\">\n                 Accept\n              </ion-col>\n              <ion-col size=\"4\" *ngIf=\"search?.status == 'outsourced'\"  class=\"ion-text-end action-button-color\" (click)=\"decline(search?.id)\">\n              Decline\n              </ion-col>\n          </span>\n        \n          <span *ngIf=\"search?.status == 'requestdeclined'\"style=\"float:right !important;\" class=\"ion-text-end action-button-color\" (click)=\"openDesigners(search?.id)\"\n          >Reassign</span>\n      </ion-col>\n\n\n      <ion-col *ngIf=\"search?.requesttype=='prelim'&& search?.status=='designcompleted'\">\n          <span  style=\"float:right !important;\" class=\"ion-text-end action-button-color\" (click)=\"openDesigners(search?.id)\"\n          >Assign Review</span>\n      </ion-col>\n      <ion-col *ngIf=\"segments=='requesttype=prelim&status=designassigned'\">\n          <span *ngIf=\"search?.status == 'reviewpassed'\" style=\"float:right !important;\" class=\"ion-text-end action-button-color\" (click)=\"openDesigners(search?.id)\"\n          >Deliver</span>\n      </ion-col>\n      \n  </ion-row>\n     \n    </p>\n    <p *ngIf=\"search?.type=='survey'\">\n      <span style=\"float: left;font-size: medium;color: black;font-size: medium;font-weight: 100; \">{{search?.name}}</span>\n      <span class=\"chipdetail\" style=\"background-color:rgb(228, 77, 102);\"  [routerLink]=\"['/survey-detail/',search?.id]\" routerDirection=\"forward\">survey</span>\n      <span class=\"chipdetail\" style=\"background-color: rgb(246, 77, 10);\" *ngIf=\"search?.status == 'requestdeclined'\" [routerLink]=\"['/survey-detail/',search?.id]\" routerDirection=\"forward\">Declined</span>\n      <span class=\"chipdetail\" style=\"background-color: rgb(246, 104, 10);\" *ngIf=\"search?.deliverydate > 0\" [routerLink]=\"['/survey-detail/',search?.id]\" routerDirection=\"forward\">Overdue</span>\n      <span class=\"chipdetail\" style=\"background-color: rgb(109, 187, 26);\" *ngIf=\"search?.status == 'requestaccepted'\"\n      [routerLink]=\"['/survey-detail/',search?.id]\" routerDirection=\"forward\">Accepted</span>\n      <span class=\"chipdetail\" style=\"background-color: rgb(109, 187, 26);\" *ngIf=\"search?.status == 'reviewpassed'\" [routerLink]=\"['/survey-detail/',search?.id]\" routerDirection=\"forward\">Review Passed</span>\n      <span class=\"chipdetail\" style=\"background-color: rgb(109, 187, 26);\" *ngIf=\"search?.status == 'delivered'\" [routerLink]=\"['/survey-detail/',search?.id]\" routerDirection=\"forward\">Delivered</span>\n      <span class=\"chipdetail\" style=\"background-color: rgb(109, 187, 26);\" *ngIf=\"search?.status == 'designcompleted'\" [routerLink]=\"['/survey-detail/',search?.id]\" routerDirection=\"forward\">Completed</span>\n      <span class=\"chipdetail\" style=\"background-color: #1289A7;\" *ngIf=\"search?.status == 'created'\"  [routerLink]=\"['/survey-detail/',search?.id]\" routerDirection=\"forward\">Unassigned</span>\n      <span class=\"chipdetail\" style=\"background-color: #1289A7;;\" *ngIf=\"search?.status == 'designassigned'\" [routerLink]=\"['/survey-detail/',search?.id]\" routerDirection=\"forward\">Design Assigned</span>\n      <span class=\"chipdetail\" style=\"background-color: #1289A7;;\" *ngIf=\"search?.status == 'reviewassigned'\" [routerLink]=\"['/survey-detail/',search?.id]\" routerDirection=\"forward\">In Review</span>\n      <span class=\"chipdetail\" *ngIf=\"search?.isoutsourced == 'true'\" style=\"background-color: #95AFC0;\" [routerLink]=\"['/survey-detail/',search?.id]\" routerDirection=\"forward\" >Waiting for acceptance</span>\n      <span *ngIf=\"search?.status=='surveyassigned'\" class=\"chipdetail\" style=\"background-color: #3C78D8;\" [routerLink]=\"['/survey-detail/',search?.id]\" routerDirection=\"forward\">\n       pending\n     </span>\n     <span fill=\"clear\" background-border=\"clear\" [routerLink]=\"['/','activity',search?.id,'survey']\" style=\"float: right;\"  size=\"small\"  ><ion-icon  src=\"/assets/images/activitylist.svg\" ></ion-icon></span><br><br>\n       <span style=\"float:left;font-size: smaller;\">{{search?.email}}</span><br>\n       <span style=\"float:left;font-size: smaller;\"> {{search?.address}}</span><br>\n       <span style=\"font-size:small ;float:right;font-style: italic;\">{{search?.updated_at|date: 'dd MMM yyyy'}}</span><br>\n       <span class=\"chipdetail\" style=\"background-color: #95afc0;\"[routerLink]=\"['/survey-detail/',search?.id]\" routerDirection=\"forward\">{{search?.company}}</span>\n       <span class=\"chipdetail\" style=\"background-color: #95afc0;\"[routerLink]=\"['/survey-detail/',search?.id]\" routerDirection=\"forward\">{{search?.formattedjobtype}}</span>\n       <span class=\"chipdetail\" style=\"background-color: #95afc0;\"[routerLink]=\"['/survey-detail/',search?.id]\" routerDirection=\"forward\">{{search?.source}}</span>\n       <ion-row class=\"ion-no-margin ion-no-margin\">\n        <ion-col *ngIf=\"segments=='requesttype=prelim&status=created&status=outsourced&status=requestaccepted'\">\n            <span *ngIf=\"search?.status == 'created' || search?.status == 'requestaccepted'\" style=\"float:right !important;\" class=\"ion-text-end action-button-color\" (click)=\"openDesigners(search?.id,search)\"\n            >Assign</span>\n            <span style=\"float: right;\">\n\n                <ion-col size=\"8\"  *ngIf=\"search?.status == 'outsourced'\"  class=\"ion-text-end action-button-color\" (click)=\"accept(search?.id,'requestaccepted')\">\n                   Accept\n                </ion-col>\n                <ion-col size=\"4\" *ngIf=\"search?.status == 'outsourced'\"  class=\"ion-text-end action-button-color\" (click)=\"decline(search?.id)\">\n                Decline\n                </ion-col>\n            </span>\n          \n            <span *ngIf=\"search?.status == 'requestdeclined'\"style=\"float:right !important;\" class=\"ion-text-end action-button-color\" (click)=\"openDesigners(search?.id)\"\n            >Reassign</span>\n        </ion-col>\n\n\n        <ion-col *ngIf=\"search?.requesttype=='prelim'&& search?.status=='designcompleted'\">\n            <span  style=\"float:right !important;\" class=\"ion-text-end action-button-color\" (click)=\"openAnalysts(search?.id,search)\"\n            >Assign Review</span>\n        </ion-col>\n        <ion-col *ngIf=\"search?.requesttype=='prelim' && search?.status=='reviewpassed'\">\n            <span *ngIf=\"search?.status == 'reviewpassed'\" style=\"float:right !important;\" class=\"ion-text-end action-button-color\" (click)=\"openreviewPassed(search?.id,search)\"\n            >Deliver</span>\n        </ion-col>\n        \n    </ion-row>\n      </p>\n     \n</ion-card>\n\n</ion-content>\n<ion-bottom-drawer [(state)]=\"drawerState\" minimumHeight=\"0\" dockedHeight=\"400\" draggable=\"false\" disableDrag=\"true\"\n                   shouldBounce=\"true\" distanceTop=\"0\" class=\"drawer\" style=\"z-index: 9999 !important;\">\n    <form [formGroup]=\"assignForm\">\n        <ion-grid class=\"drawer\">\n            <ion-row>\n                <ion-col size=\"12\">\n                    <app-user-selector (assigneeData)=getassignedata($event) placeholder=\"assign\" [assignees]=\"listOfAssignees\"\n                                       formControlName=\"assignedto\"></app-user-selector>\n                </ion-col>\n            </ion-row>\n            <ion-row style=\"margin-left: 8px;\">\n                <ion-col size=\"12\">\n                    <span class=\"input-placeholder\">comments</span>\n                </ion-col>\n                <ion-col size=\"12\" style=\"padding-top: 0px;\">\n                    <ion-textarea style=\"max-width: 98%;\" class=\"ion-no-margin ion-no-padding comment_box\" rows=\"3\"\n                                  formControlName=\"comment\"></ion-textarea>\n                </ion-col>\n            </ion-row>\n            <ion-row style=\"justify-content: flex-end;\">\n                <ion-col size=\"auto\" style=\"padding-top: 0px; margin-right: 6px;\">\n                    <ion-button class=\"buttom-drawer-button\" fill=\"clear\" (click)=\"assignToDesigner()\">\n                        Confirm\n                    </ion-button>\n                </ion-col>\n                <ion-col size=\"auto\">\n                    <ion-button class=\"buttom-drawer-button-cancel\" fill=\"clear\" (click)=\"dismissBottomSheet()\">\n                        Cancel\n                    </ion-button>\n                </ion-col>\n            </ion-row>\n        </ion-grid>\n    </form>\n\n</ion-bottom-drawer>\n");

/***/ }),

/***/ "./src/app/search-bar1/search-bar1-routing.module.ts":
/*!***********************************************************!*\
  !*** ./src/app/search-bar1/search-bar1-routing.module.ts ***!
  \***********************************************************/
/*! exports provided: SearchBar1PageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchBar1PageRoutingModule", function() { return SearchBar1PageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _search_bar1_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./search-bar1.page */ "./src/app/search-bar1/search-bar1.page.ts");




const routes = [
    {
        path: '',
        component: _search_bar1_page__WEBPACK_IMPORTED_MODULE_3__["SearchBar1Page"]
    }
];
let SearchBar1PageRoutingModule = class SearchBar1PageRoutingModule {
};
SearchBar1PageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], SearchBar1PageRoutingModule);



/***/ }),

/***/ "./src/app/search-bar1/search-bar1.module.ts":
/*!***************************************************!*\
  !*** ./src/app/search-bar1/search-bar1.module.ts ***!
  \***************************************************/
/*! exports provided: SearchBar1PageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchBar1PageModule", function() { return SearchBar1PageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _search_bar1_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./search-bar1-routing.module */ "./src/app/search-bar1/search-bar1-routing.module.ts");
/* harmony import */ var _search_bar1_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./search-bar1.page */ "./src/app/search-bar1/search-bar1.page.ts");
/* harmony import */ var ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ion-bottom-drawer */ "./node_modules/ion-bottom-drawer/fesm2015/ion-bottom-drawer.js");
/* harmony import */ var _utilities_utilities_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../utilities/utilities.module */ "./src/app/utilities/utilities.module.ts");
/* harmony import */ var _ionic_native_diagnostic_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic-native/diagnostic/ngx */ "./node_modules/@ionic-native/diagnostic/ngx/index.js");
/* harmony import */ var _ionic_native_native_geocoder_ngx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic-native/native-geocoder/ngx */ "./node_modules/@ionic-native/native-geocoder/ngx/index.js");
/* harmony import */ var _ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic-native/launch-navigator/ngx */ "./node_modules/@ionic-native/launch-navigator/ngx/index.js");












let SearchBar1PageModule = class SearchBar1PageModule {
};
SearchBar1PageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _search_bar1_routing_module__WEBPACK_IMPORTED_MODULE_5__["SearchBar1PageRoutingModule"],
            ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_7__["IonBottomDrawerModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _utilities_utilities_module__WEBPACK_IMPORTED_MODULE_8__["UtilitiesModule"]
        ],
        declarations: [_search_bar1_page__WEBPACK_IMPORTED_MODULE_6__["SearchBar1Page"]],
        providers: [
            _ionic_native_diagnostic_ngx__WEBPACK_IMPORTED_MODULE_9__["Diagnostic"],
            _ionic_native_native_geocoder_ngx__WEBPACK_IMPORTED_MODULE_10__["NativeGeocoder"],
            _ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_11__["LaunchNavigator"]
        ]
    })
], SearchBar1PageModule);



/***/ }),

/***/ "./src/app/search-bar1/search-bar1.page.scss":
/*!***************************************************!*\
  !*** ./src/app/search-bar1/search-bar1.page.scss ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".searchStyle {\n  border-radius: 20px;\n}\n\n.chipdetail {\n  display: inline;\n  vertical-align: middle;\n  background-color: #95afc0;\n  font-size: 0.6em;\n  padding: 4px 10px;\n  border-radius: 10px;\n  text-align: center;\n  color: #fff;\n}\n\n.custom-card {\n  background: white !important;\n  border-radius: 4px !important;\n  box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.3) !important;\n  padding: 8px 12px;\n}\n\n.alertClass {\n  background-color: wheat;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2VhcmNoLWJhcjEvRjpcXG1vYmlsZWFwcC9zcmNcXGFwcFxcc2VhcmNoLWJhcjFcXHNlYXJjaC1iYXIxLnBhZ2Uuc2NzcyIsInNyYy9hcHAvc2VhcmNoLWJhcjEvc2VhcmNoLWJhcjEucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksbUJBQUE7QUNDSjs7QURFQTtFQUNJLGVBQUE7RUFDQSxzQkFBQTtFQUNBLHlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0FDQ0o7O0FEQ0U7RUFFRSw0QkFBQTtFQUNBLDZCQUFBO0VBQ0EscURBQUE7RUFDQSxpQkFBQTtBQ0NKOztBRENFO0VBQ0UsdUJBQUE7QUNFSiIsImZpbGUiOiJzcmMvYXBwL3NlYXJjaC1iYXIxL3NlYXJjaC1iYXIxLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5zZWFyY2hTdHlsZXtcclxuICAgIGJvcmRlci1yYWRpdXM6IDIwcHg7XHJcbn1cclxuXHJcbi5jaGlwZGV0YWlse1xyXG4gICAgZGlzcGxheTogaW5saW5lO1xyXG4gICAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICM5NWFmYzA7XHJcbiAgICBmb250LXNpemU6IDAuNmVtO1xyXG4gICAgcGFkZGluZzogNHB4IDEwcHg7XHJcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgY29sb3I6ICNmZmY7XHJcbiAgfVxyXG4gIC5jdXN0b20tY2FyZCB7XHJcbiAgICBcclxuICAgIGJhY2tncm91bmQ6IHdoaXRlICFpbXBvcnRhbnQ7XHJcbiAgICBib3JkZXItcmFkaXVzOiA0cHggIWltcG9ydGFudDtcclxuICAgIGJveC1zaGFkb3c6IDAgMXB4IDJweCAwIHJnYmEoMCwgMCwgMCwgMC4zKSAhaW1wb3J0YW50O1xyXG4gICAgcGFkZGluZzogOHB4IDEycHg7XHJcbiAgfVxyXG4gIC5hbGVydENsYXNze1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogd2hlYXQ7XHJcbiAgfVxyXG4gXHJcbiAgIiwiLnNlYXJjaFN0eWxlIHtcbiAgYm9yZGVyLXJhZGl1czogMjBweDtcbn1cblxuLmNoaXBkZXRhaWwge1xuICBkaXNwbGF5OiBpbmxpbmU7XG4gIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XG4gIGJhY2tncm91bmQtY29sb3I6ICM5NWFmYzA7XG4gIGZvbnQtc2l6ZTogMC42ZW07XG4gIHBhZGRpbmc6IDRweCAxMHB4O1xuICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGNvbG9yOiAjZmZmO1xufVxuXG4uY3VzdG9tLWNhcmQge1xuICBiYWNrZ3JvdW5kOiB3aGl0ZSAhaW1wb3J0YW50O1xuICBib3JkZXItcmFkaXVzOiA0cHggIWltcG9ydGFudDtcbiAgYm94LXNoYWRvdzogMCAxcHggMnB4IDAgcmdiYSgwLCAwLCAwLCAwLjMpICFpbXBvcnRhbnQ7XG4gIHBhZGRpbmc6IDhweCAxMnB4O1xufVxuXG4uYWxlcnRDbGFzcyB7XG4gIGJhY2tncm91bmQtY29sb3I6IHdoZWF0O1xufSJdfQ== */");

/***/ }),

/***/ "./src/app/search-bar1/search-bar1.page.ts":
/*!*************************************************!*\
  !*** ./src/app/search-bar1/search-bar1.page.ts ***!
  \*************************************************/
/*! exports provided: SearchBar1Page, DesginDataHelper */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchBar1Page", function() { return SearchBar1Page; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DesginDataHelper", function() { return DesginDataHelper; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _api_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../api.service */ "./src/app/api.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _utilities_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../utilities.service */ "./src/app/utilities.service.ts");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm2015/ionic-storage.js");
/* harmony import */ var ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ion-bottom-drawer */ "./node_modules/ion-bottom-drawer/fesm2015/ion-bottom-drawer.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _storage_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../storage.service */ "./src/app/storage.service.ts");
/* harmony import */ var src_app_declinepage_declinepage_page__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/declinepage/declinepage.page */ "./src/app/declinepage/declinepage.page.ts");










let SearchBar1Page = class SearchBar1Page {
    constructor(apiService, navController, formBuilder, storage, storageService, utils, alertController, modalController) {
        this.apiService = apiService;
        this.navController = navController;
        this.formBuilder = formBuilder;
        this.storage = storage;
        this.storageService = storageService;
        this.utils = utils;
        this.alertController = alertController;
        this.modalController = modalController;
        this.searchElement = '';
        this.segments = 'requesttype=prelim&status=created&status=outsourced&status=requestaccepted';
        this.Type = 'both';
        this.listOfAssignees = [];
        this.listOfAssignees2 = [];
        this.drawerState = ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_6__["DrawerState"].Bottom;
        this.showBottomDraw = false;
        this.designId = 0;
        this.assignForm = this.formBuilder.group({
            assignedto: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required]),
            comment: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormControl"]('')
        });
    }
    ngOnInit() {
        this.userData = this.storageService.getUser();
        console.log(this.userData);
    }
    searchfor(event) {
        if (this.searchElement !== '') {
            this.apiService.searchAllDesgin(this.searchElement).subscribe((dataModel) => {
                console.log("inside this", dataModel);
                if (this.Type == "survey") {
                    this.sample = this.fillinDynamicData(dataModel.survey);
                    this.SurveyModel = this.sample;
                    this.SortedModel = this.SurveyModel;
                }
                if (this.Type == "design") {
                    this.sample = this.fillinDynamicData(dataModel.design);
                    this.DesignModel = this.sample;
                    this.SortedModel = this.DesignModel;
                }
                if (this.Type == "both") {
                    this.sample = this.fillinDynamicData(dataModel.survey);
                    this.SurveyModel = this.sample;
                    this.sample1 = this.fillinDynamicData(dataModel.design);
                    this.DesignModel = this.sample1;
                    //this.MixModel=this.SurveyModel.concat(this.DesignModel);
                    this.MixModel = dataModel.survey.concat(dataModel.design);
                    console.log("welcome", this.MixModel);
                    //this.SortedModel=this.MixModel.sort((a,b) => a.id.localecompare(b.id));
                    this.SortedModel = this.MixModel.sort((a, b) => b.id - a.id);
                }
            });
        }
    }
    fillinDynamicData(records) {
        console.log("that", records);
        records.forEach(element => {
            element.formattedjobtype = this.utils.getJobTypeName(element.jobtype);
        });
        return records;
    }
    goBack() {
        this.navController.pop();
    }
    getDesigns(event) {
        debugger;
        let showLoader = true;
        if (event != null && event !== undefined) {
            showLoader = false;
        }
        this.fetchPendingDesigns(event, showLoader);
    }
    fetchPendingDesigns(event, showLoader) {
        console.log("inside fetch Designs");
        this.listOfDesigns = [];
        this.listOfDesignsHelper = [];
        this.utils.showLoadingWithPullRefreshSupport(showLoader, 'Getting Designs').then((success) => {
            this.apiService.getDesignSurveys(this.segments).subscribe((response) => {
                this.utils.hideLoadingWithPullRefreshSupport(showLoader).then(() => {
                    console.log(response);
                    if (event !== null) {
                        event.target.complete();
                    }
                });
            }, responseError => {
                this.utils.hideLoadingWithPullRefreshSupport(showLoader).then(() => {
                    if (event !== null) {
                        event.target.complete();
                    }
                    const error = responseError.error;
                    this.utils.errorSnackBar(error.message[0].messages[0].message);
                });
            });
        });
    }
    openDesigners(id, designData) {
        console.log(designData);
        this.designerData = designData;
        if (this.listOfAssignees.length === 0) {
            if (this.designerData.type == "survey") {
                this.utils.showLoading('Getting Surveyors').then(() => {
                    this.apiService.getSurveyors().subscribe(assignees => {
                        this.utils.hideLoading().then(() => {
                            this.listOfAssignees = [];
                            // this.listOfAssignees.push(this.utils.getDefaultAssignee(this.storage.getUserID()));
                            assignees.forEach(item => this.listOfAssignees.push(item));
                            console.log(this.listOfAssignees);
                            this.showBottomDraw = true;
                            this.designId = id;
                            this.utils.setBottomBarHomepage(false);
                            this.drawerState = ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_6__["DrawerState"].Docked;
                            this.assignForm.patchValue({
                                assignedto: 0
                            });
                        });
                    }, (error) => {
                        this.utils.hideLoading().then(() => {
                            this.utils.errorSnackBar('Some error occurred. Please try again later');
                        });
                    });
                });
            }
            if (this.designerData.type == "design") {
                this.utils.showLoading('Getting Designers').then(() => {
                    this.apiService.getDesigners().subscribe(assignees => {
                        this.utils.hideLoading().then(() => {
                            this.listOfAssignees = [];
                            // this.listOfAssignees.push(this.utils.getDefaultAssignee(this.storage.getUserID()));
                            assignees.forEach(item => this.listOfAssignees.push(item));
                            console.log(this.listOfAssignees);
                            this.showBottomDraw = true;
                            this.designId = id;
                            this.utils.setBottomBarHomepage(false);
                            this.drawerState = ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_6__["DrawerState"].Docked;
                            this.assignForm.patchValue({
                                assignedto: 0
                            });
                        });
                    }, (error) => {
                        this.utils.hideLoading().then(() => {
                            this.utils.errorSnackBar('Some error occurred. Please try again later');
                        });
                    });
                });
            }
        }
        else {
            this.designId = id;
            this.utils.setBottomBarHomepage(false);
            this.drawerState = ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_6__["DrawerState"].Docked;
            this.assignForm.patchValue({
                assignedto: 0
            });
        }
    }
    openAnalysts(id, designData) {
        console.log("this is", designData);
        this.designerData = designData;
        if (this.listOfAssignees.length === 0) {
            this.utils.showLoading('Getting Analysts').then(() => {
                this.apiService.getAnalysts().subscribe(assignees => {
                    this.utils.hideLoading().then(() => {
                        this.listOfAssignees = [];
                        // this.listOfAssignees.push(this.utils.getDefaultAssignee(this.storage.getUserID()));
                        assignees.forEach(item => this.listOfAssignees.push(item));
                        console.log(this.listOfAssignees);
                        this.showBottomDraw = true;
                        this.designId = id;
                        this.utils.setBottomBarHomepage(false);
                        this.drawerState = ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_6__["DrawerState"].Docked;
                        this.assignForm.patchValue({
                            assignedto: 0
                        });
                    });
                }, (error) => {
                    this.utils.hideLoading().then(() => {
                        this.utils.errorSnackBar('Some error occurred. Please try again later');
                    });
                });
            });
        }
        else {
            this.designId = id;
            this.utils.setBottomBarHomepage(false);
            this.drawerState = ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_6__["DrawerState"].Docked;
            this.assignForm.patchValue({
                assignedto: 0
            });
        }
    }
    openreviewPassed(id, designData) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.designId = id;
            const alert = yield this.alertController.create({
                cssClass: 'alertClass',
                header: 'Confirm!',
                message: 'Would you like to  Add Comments!!',
                inputs: [{ name: 'comment',
                        id: 'comment',
                        type: 'textarea',
                        placeholder: 'Enter Comment' }
                ],
                buttons: [
                    {
                        text: 'Cancel',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: (blah) => {
                            console.log('Confirm Cancel: blah');
                        }
                    }, {
                        text: 'deliver',
                        handler: (alertData) => {
                            var postData = {};
                            postData = {
                                status: "delivered",
                                comments: alertData.comment,
                            };
                            console.log(postData);
                            this.apiService.updateDesignForm(postData, this.designId).subscribe((value) => {
                                this.utils.hideLoading().then(() => {
                                    ;
                                    console.log('reach ', value);
                                    this.utils.showSnackBar('Design request has been delivered successfully');
                                    this.utils.setHomepageDesignRefresh(true);
                                });
                            }, (error) => {
                                this.utils.hideLoading();
                                ;
                            });
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    close() {
        if (this.showBottomDraw === true) {
            this.showBottomDraw = false;
            this.drawerState = ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_6__["DrawerState"].Bottom;
            this.utils.setBottomBarHomepage(true);
        }
        else {
            this.showBottomDraw = true;
        }
    }
    getassignedata(asssignedata) {
        this.selectedDesigner = asssignedata;
    }
    accept(id, data) {
        let status = {
            status: data
        };
        this.apiService.updateDesignForm(status, id).subscribe((res) => {
            this.getDesigns(null);
        });
    }
    decline(id) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: src_app_declinepage_declinepage_page__WEBPACK_IMPORTED_MODULE_9__["DeclinepagePage"],
                cssClass: 'my-custom-modal-css',
                componentProps: {
                    id: id
                },
            });
            modal.onDidDismiss().then((data) => {
                console.log(data);
                if (data.data.cancel == 'cancel') {
                }
                else {
                    this.getDesigns(null);
                }
            });
            return yield modal.present();
        });
    }
    dismissBottomSheet() {
        console.log('this', this.drawerState);
        this.drawerState = ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_6__["DrawerState"].Bottom;
        this.utils.setBottomBarHomepage(true);
        this.listOfAssignees = [];
    }
    assignToDesigner() {
        console.log(this.designerData.createdby.id);
        if (this.assignForm.status === 'INVALID') {
            this.utils.errorSnackBar('Please select a designer');
        }
        else {
            var designstarttime = new Date();
            var additonalhours = 0;
            if (this.designerData.requesttype == "prelim") {
                additonalhours = this.selectedDesigner.jobcount * 2;
                designstarttime.setHours(designstarttime.getHours() + additonalhours);
            }
            else {
                additonalhours = this.selectedDesigner.jobcount * 6;
                designstarttime.setHours(designstarttime.getHours() + additonalhours);
            }
            var postData = {};
            if (this.designerData.createdby.id == this.userData.id) {
                if (this.selectedDesigner.company == this.userData.company) {
                    if (this.selectedDesigner.role.type == "qcinspector") {
                        postData = {
                            designassignedto: this.selectedDesigner.id,
                            isoutsourced: "false",
                            status: "reviewassigned",
                            designstarttime: designstarttime
                        };
                    }
                    if (this.selectedDesigner.role.type == "designer") {
                        postData = {
                            designassignedto: this.selectedDesigner.id,
                            isoutsourced: "false",
                            status: "designassigned",
                            designstarttime: designstarttime
                        };
                    }
                }
                else {
                    postData = {
                        outsourcedto: this.selectedDesigner.id,
                        isoutsourced: "true",
                        status: "outsourced"
                    };
                }
            }
            else {
                if (this.selectedDesigner.role.type == "designer") {
                    postData = {
                        designassignedto: this.selectedDesigner.id,
                        status: "designassigned",
                        designstarttime: designstarttime
                    };
                }
                if (this.selectedDesigner.role.type == "qcinspector") {
                    postData = {
                        designassignedto: this.selectedDesigner.id,
                        status: "reviewassigned",
                        designstarttime: designstarttime
                    };
                }
            }
            this.utils.showLoading('Assigning').then(() => {
                this.apiService.updateDesignForm(postData, this.designId).subscribe((value) => {
                    this.utils.hideLoading().then(() => {
                        ;
                        console.log('reach ', value);
                        this.utils.showSnackBar('Design request has been assigned to' + ' ' + value.name + ' ' + 'successfully');
                        this.dismissBottomSheet();
                        this.showBottomDraw = false;
                        this.utils.setHomepageDesignRefresh(true);
                    });
                }, (error) => {
                    this.utils.hideLoading();
                    this.dismissBottomSheet();
                    this.showBottomDraw = false;
                });
            });
        }
    }
};
SearchBar1Page.ctorParameters = () => [
    { type: _api_service__WEBPACK_IMPORTED_MODULE_2__["ApiService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"] },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormBuilder"] },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_5__["Storage"] },
    { type: _storage_service__WEBPACK_IMPORTED_MODULE_8__["StorageService"] },
    { type: _utilities_service__WEBPACK_IMPORTED_MODULE_4__["UtilitiesService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"] }
];
SearchBar1Page = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-search-bar1',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./search-bar1.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/search-bar1/search-bar1.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./search-bar1.page.scss */ "./src/app/search-bar1/search-bar1.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_api_service__WEBPACK_IMPORTED_MODULE_2__["ApiService"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"], _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormBuilder"],
        _ionic_storage__WEBPACK_IMPORTED_MODULE_5__["Storage"],
        _storage_service__WEBPACK_IMPORTED_MODULE_8__["StorageService"],
        _utilities_service__WEBPACK_IMPORTED_MODULE_4__["UtilitiesService"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"]])
], SearchBar1Page);

class DesginDataHelper {
    constructor() {
        this.listOfDesigns = [];
    }
}


/***/ })

}]);
//# sourceMappingURL=search-bar1-search-bar1-module-es2015.js.map