(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["designoverview-designoverview-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/designoverview/completeddesign/completeddesign.component.html":
/*!*********************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/designoverview/completeddesign/completeddesign.component.html ***!
  \*********************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content>\r\n  <ion-refresher slot=\"fixed\" (ionRefresh)=\"getDesigns($event)\">\r\n    <ion-refresher-content pullingIcon=\"arrow-dropdown\" pullingText=\"Pull down to refresh\" refreshingSpinner=\"lines\"></ion-refresher-content>\r\n  </ion-refresher>\r\n  <ion-grid *ngIf=\"listOfDesignDataHelper.length !==0\">\r\n    <ion-row *ngFor=\"let item of listOfDesignDataHelper;let i = index\">\r\n        <ion-col size=\"12\" class=\"ion-margin-top\">\r\n                <span class=\"ion-padding\" *ngIf=\"today === item.date\">\r\n                    Today\r\n                  </span>\r\n            <span class=\"ion-padding\" *ngIf=\"today !== item.date\">\r\n                      {{item.date | date: 'dd MMM yyyy'}}\r\n                </span>\r\n        </ion-col>\r\n        <ion-col *ngFor=\"let designData of item.listOfDesigns;let i = index \" size=\"12\">\r\n            <div class=\"ion-no-padding custom-card\" style=\"height: 100%;\">\r\n                <p class=\"customer-name\" >{{designData.name}}\r\n                      <!-- <span class=\"chipdetail\" style=\"background-color: #1289A7;\" [routerLink]=\"['/survey-detail/',designData.id]\" routerDirection=\"forward\">\r\n                        {{designData.deliverydate | date: 'hh:mm a'}}\r\n                    </span> -->\r\n                    <span [routerLink]=\"['/design-details/',designData.id]\"\r\n                    routerDirection=\"forward\" class=\"chipdetail\" style=\"background-color: rgb(109, 187, 26);\" *ngIf=\"designData.status == 'designcompleted'\">Designing Completed</span>\r\n                    <span [routerLink]=\"['/design-details/',designData.id]\"\r\n                    routerDirection=\"forward\" class=\"chipdetail\" style=\"background-color: rgb(246, 104, 10);\" *ngIf=\"item.lateby > 0\">Overdue</span>\r\n                    <span fill=\"clear\" background-border=\"clear\" [routerLink]=\"['/','activity',designData.id,'design']\" class=\"imagebutton\"  size=\"small\"  ><ion-icon  src=\"/assets/images/activitylist.svg\" ></ion-icon></span>           \r\n                </p>\r\n                <p><span class=\"customer-email\" [routerLink]=\"['/survey-detail/',designData.id]\"\r\n                      routerDirection=\"forward\">{{designData.email}}</span>\r\n                      <span *ngIf=\"item.lateby > 1\" class=\"latebystyle\" style=\"float: right;font-size: 10px;\"><strong>Late by {{item.lateby}} days</strong></span>\r\n                      <span *ngIf=\"item.lateby == 1\" class=\"latebystyle\" style=\"float: right;font-size: 10px;\"><strong>Late by a day</strong></span>\r\n            </p>\r\n                <a href=\"tel:{{designData.phonenumber}}\" style=\"text-decoration: none;\" class=\"z-100\">\r\n                    <span class=\"customer-phone\">{{designData.phonenumber}}</span></a>\r\n                <span style=\"margin:0px\" class=\"customer-address z-100\"\r\n                      (click)=\"openAddressOnMap(designData.address)\">{{(designData.address | slice:0:60) + (designData.address.length > 60 ? '...' : '')}}</span>\r\n\r\n                <ion-row style=\"margin-bottom: 8px;\" [routerLink]=\"['/design-details/',designData.id]\" >\r\n                    <span class=\"chipdetail\" style=\"background-color: #95afc0;\" >Wattmonk</span>\r\n                    <span class=\"chipdetail\" style=\"background-color: #95afc0;\" >{{designData.formattedjobtype}}</span>\r\n                </ion-row>\r\n                <ion-progress-bar [value]=\"1\" mode=\"ios\" color=\"success\" class=\"progress-bar-height\"></ion-progress-bar>\r\n            </div>\r\n        </ion-col>\r\n    </ion-row>\r\n    <ion-row>\r\n        <ion-col size=\"12\" style=\"height: 100px;\">\r\n        </ion-col>\r\n    </ion-row>\r\n</ion-grid>\r\n\r\n<div *ngIf=\"listOfDesignDataHelper.length===0\" class=\"h-100 d-flex flex-column align-center justify-center\">\r\n    <ion-img src=\"/assets/images/blank.png\" class=\"placeholder\"></ion-img>\r\n</div>\r\n</ion-content>\r\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/designoverview/delievereddesign/delievereddesign.component.html":
/*!***********************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/designoverview/delievereddesign/delievereddesign.component.html ***!
  \***********************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content>\r\n  <ion-refresher slot=\"fixed\" (ionRefresh)=\"getDesigns($event)\">\r\n    <ion-refresher-content pullingIcon=\"arrow-dropdown\" pullingText=\"Pull down to refresh\" refreshingSpinner=\"lines\"></ion-refresher-content>\r\n  </ion-refresher>\r\n  <ion-grid *ngIf=\"listofDesignDataHelper.length !== 0\">\r\n    <ion-row *ngFor=\"let item of listofDesignDataHelper;let i = index\">\r\n        <ion-col size=\"12\" class=\"ion-margin-top\">\r\n                <span class=\"ion-padding\" *ngIf=\"today === item.date\">\r\n                    Today\r\n                  </span>\r\n            <span class=\"ion-padding\" *ngIf=\"today !== item.date\">\r\n                      {{item.date | date: 'dd MMM yyyy'}}\r\n                </span>\r\n        </ion-col>\r\n        <ion-col *ngFor=\"let designData of item.listOfDesigns;let i = index \" size=\"12\">\r\n            <div class=\"ion-no-padding custom-card\" style=\"height: 100%;\">\r\n                <p class=\"customer-name\" >{{designData.name}}\r\n                      <!-- <span class=\"chipdetail\" style=\"background-color: #1289A7;\" [routerLink]=\"['/design-details/',designData.id]\" routerDirection=\"forward\">\r\n                        {{designData.deliverydate | date: 'hh:mm a'}}\r\n                    </span> -->\r\n                    <span  [routerLink]=\"['/design-details/',designData.id]\"\r\n                    routerDirection=\"forward\" class=\"chipdetail\" style=\"background-color: rgb(109, 187, 26);\" *ngIf=\"designData.status == 'delivered'\">Delivered</span>\r\n                    <span  [routerLink]=\"['/design-details/',designData.id]\"\r\n                    routerDirection=\"forward\" class=\"chipdetail\" style=\"background-color: rgb(246, 104, 10);\" *ngIf=\"item.lateby > 0\">Overdue</span>\r\n                    <span fill=\"clear\" background-border=\"clear\" [routerLink]=\"['/','activity',designData.id,'design']\" class=\"imagebutton\"  size=\"small\"  ><ion-icon  src=\"/assets/images/activitylist.svg\" ></ion-icon></span>        \r\n                </p>\r\n                <p style=\"margin:0px\">\r\n                <span class=\"customer-email\" [routerLink]=\"['/design-details/',designData.id]\"\r\n                      routerDirection=\"forward\">{{designData.email}}</span>\r\n                      <span *ngIf=\"item.lateby > 1\" class=\"latebystyle\" style=\"float: right;font-size: 10px;\"><strong>Late by {{item.lateby}} days</strong></span>\r\n                      <span *ngIf=\"item.lateby == 1\" class=\"latebystyle\" style=\"float: right;font-size: 10px;\"><strong>Late by a day</strong></span>\r\n            </p>\r\n          \r\n                <a href=\"tel:{{designData.phonenumber}}\" style=\"text-decoration: none;\" class=\"z-100\">\r\n                    <span class=\"customer-phone\">{{designData.phonenumber}}</span></a>\r\n                <span style=\"margin:0px\" class=\"customer-address z-100\"\r\n                      (click)=\"openAddressOnMap(designData.address)\">{{(designData.address | slice:0:60) + (designData.address.length > 60 ? '...' : '')}}</span>\r\n\r\n                <ion-row style=\"margin-bottom: 8px;\" [routerLink]=\"['/design-details/',designData.id]\" >\r\n                    <span class=\"chipdetail\" style=\"background-color: #95afc0;\" >Wattmonk</span>\r\n                    <span class=\"chipdetail\" style=\"background-color: #95afc0;\" >{{designData.formattedjobtype}}</span>\r\n                </ion-row>\r\n                <ion-row class=\"ion-no-margin ion-no-margin\">\r\n                    <ion-col >\r\n                        <span  style=\"float:right !important;\" class=\"ion-text-end action-button-color\" (click)=\"shareWhatsapp(designData)\">\r\n                            <ion-icon name=\"share-social-outline\"></ion-icon></span>&nbsp;\r\n                        <span style=\"float:right !important;margin-right: 8px;\" class=\"ion-text-end action-button-color\" (click)=\"shareViaEmails(designData.id,designData)\">\r\n                            <ion-icon name=\"mail\" ></ion-icon></span>\r\n                    </ion-col>\r\n                </ion-row>\r\n            </div>\r\n        </ion-col>\r\n    </ion-row>\r\n    \r\n\r\n\r\n    <ion-row>\r\n        <ion-col size=\"12\" style=\"height: 100px;\">\r\n        </ion-col>\r\n    </ion-row>\r\n</ion-grid>\r\n\r\n<div *ngIf=\"listofDesignDataHelper.length === 0\" class=\"h-100 d-flex flex-column align-center justify-center\">\r\n    <ion-img src=\"/assets/images/blank.png\" class=\"placeholder\"></ion-img>\r\n</div>\r\n</ion-content>\r\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/designoverview/designoverview.page.html":
/*!***********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/designoverview/designoverview.page.html ***!
  \***********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar>\r\n    <ion-title>Home</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content [forceOverscroll]=\"false\">\r\n  <ion-tabs>\r\n    <ion-tab-bar slot=\"top\">\r\n      <ion-tab-button tab=\"newdesigns\">\r\n        <ion-label class=\"font\">In Designing</ion-label>\r\n      </ion-tab-button>\r\n      <ion-tab-button tab=\"completeddesigns\">\r\n        <ion-label class=\"font\">Completed</ion-label>\r\n      </ion-tab-button>\r\n      <ion-tab-button tab=\"inreviewdesigns\">\r\n        <ion-label class=\"font\">Review</ion-label>\r\n      </ion-tab-button>\r\n      <ion-tab-button tab=\"delivereddesigns\">\r\n        <ion-label class=\"font\">Delivered</ion-label>\r\n      </ion-tab-button>\r\n    </ion-tab-bar>\r\n  </ion-tabs>\r\n</ion-content>\r\n\r\n<ion-footer class=\"ion-no-border white-bg\">\r\n  <div class=\"position-relative\">\r\n    <ion-grid class=\"bottom-bar ion-no-margin ion-no-padding\">\r\n      <ion-row>\r\n        <ion-col size=\"6\">\r\n          <div class=\"tab\">\r\n            <ion-img src=\"/assets/images/home-outline.svg\" class=\"tab-icon\"></ion-img>\r\n            <span class=\"tabText\">Home</span>\r\n          </div>\r\n        </ion-col>\r\n        <!--<ion-col size=\"4\" [routerLink]=\"['/message']\">\r\n          <div class=\"tab\">\r\n            <ion-img src=\"/assets/images/message-outline.svg\" class=\"tab-icon\"></ion-img>\r\n            <span class=\"tabText\">Messages</span>\r\n          </div>\r\n        </ion-col>-->\r\n        <ion-col size=\"6\" [routerLink]=\"['/profile']\" routerDirection=\"forward\">\r\n          <div class=\"tab\">\r\n            <ion-img src=\"/assets/images/account-outline.svg\" class=\"tab-icon\"></ion-img>\r\n            <span class=\"tabText\">Profile</span>\r\n          </div>\r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-grid>\r\n  </div>\r\n</ion-footer>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/designoverview/inreview-design/inreview-design.component.html":
/*!*********************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/designoverview/inreview-design/inreview-design.component.html ***!
  \*********************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content>\r\n  <ion-refresher slot=\"fixed\" (ionRefresh)=\"getDesigns($event)\">\r\n    <ion-refresher-content pullingIcon=\"arrow-dropdown\" pullingText=\"Pull down to refresh\" refreshingSpinner=\"lines\"></ion-refresher-content>\r\n  </ion-refresher>\r\n  <ion-grid *ngIf=\"listOfDesignsHelper.length !== 0\">\r\n    <ion-row *ngFor=\"let item of listOfDesignsHelper;let i = index\">\r\n        <ion-col size=\"12\" class=\"ion-margin-top\">\r\n                <span class=\"ion-padding\" *ngIf=\"today === item.date\">\r\n                    Today\r\n                  </span>\r\n            <span class=\"ion-padding\" *ngIf=\"today !== item.date\">\r\n                      {{item.date | date: 'dd MMM yyyy'}}\r\n                </span>\r\n        </ion-col>\r\n        <ion-col *ngFor=\"let designData of item.listOfDesigns;let i = index \" size=\"12\">\r\n            <div class=\"ion-no-padding custom-card\" style=\"height: 100%;\">\r\n                <p class=\"customer-name\" >{{designData.name}}\r\n                      <!-- <span class=\"chipdetail\" style=\"background-color: #1289A7;\" [routerLink]=\"['/design-details/',designData.id]\" routerDirection=\"forward\">\r\n                        {{designData.deliverydate | date: 'hh:mm a'}}\r\n                    </span> -->\r\n                    <span [routerLink]=\"['/design-details/',designData.id]\"\r\n                    routerDirection=\"forward\" class=\"chipdetail\" style=\"background-color: #1289A7;;\" *ngIf=\"designData.status == 'reviewassigned'\">In Review</span>\r\n                    <span [routerLink]=\"['/design-details/',designData.id]\"\r\n                    routerDirection=\"forward\" class=\"chipdetail\" style=\"background-color: rgb(246, 104, 10);\" *ngIf=\"item.lateby > 0\">Overdue</span>\r\n                    <span fill=\"clear\" background-border=\"clear\" [routerLink]=\"['/','activity',designData.id,'design']\" class=\"imagebutton\"  size=\"small\"  ><ion-icon  src=\"/assets/images/activitylist.svg\" ></ion-icon></span> \r\n                </p>\r\n               <p> <span class=\"customer-email\" [routerLink]=\"['/design-details/',designData.id]\"\r\n                      routerDirection=\"forward\">{{designData.email}}</span>\r\n                      <span *ngIf=\"item.lateby > 1\" class=\"latebystyle\" style=\"float: right;font-size: 10px;\"><strong>Late by {{item.lateby}} days</strong></span>\r\n                      <span *ngIf=\"item.lateby == 1\" class=\"latebystyle\" style=\"float: right;font-size: 10px;\"><strong>Late by a day</strong></span>\r\n            </p>\r\n            \r\n                       <a href=\"tel:{{designData.phonenumber}}\" style=\"text-decoration: none;\" class=\"z-100\">\r\n                    <span class=\"customer-phone\">{{designData.phonenumber}}</span></a>\r\n                <span style=\"margin:0px\" class=\"customer-address z-100\"\r\n                      (click)=\"openAddressOnMap(designData.address)\">{{(designData.address | slice:0:60) + (designData.address.length > 60 ? '...' : '')}}</span>\r\n\r\n                <ion-row style=\"margin-bottom: 8px;\" [routerLink]=\"['/design-details/',designData.id]\" >\r\n                    <span class=\"chipdetail\" style=\"background-color: #95afc0;\" >Wattmonk</span>\r\n                    <span class=\"chipdetail\" style=\"background-color: #95afc0;\" >{{designData.formattedjobtype}}</span>\r\n                      <span class=\"chipdetail\" style=\"background-color: rgb(246, 77, 10);\" *ngIf=\"designData.status == 'reviewfailed'\">Failed</span>\r\n                      <span class=\"chipdetail\" style=\"background-color: rgb(109, 187, 26);\" *ngIf=\"designData.status == 'reviewpassed'\">Passed</span>\r\n                </ion-row>\r\n                <ion-row class=\"ion-no-margin ion-no-margin\" *ngIf=\"designData.status == 'reviewfailed'\">\r\n                    <ion-col></ion-col>\r\n                    <!-- <ion-col class=\"ion-no-margin ion-no-padding\">\r\n                        <ion-button class=\"ion-no-margin ion-no-padding\" fill=\"clear\" [routerLink]=\"['/surveyprocess/' + designData.id + '/' + designData.jobtype + '/' + designData.latitude + '/' + designData.longitude]\"\r\n                        routerDirection=\"forward\">\r\n                            Restart Survey\r\n                        </ion-button>\r\n                    </ion-col> -->\r\n                </ion-row>\r\n                <ion-progress-bar [value]=\"1\" mode=\"ios\" color=\"success\" class=\"progress-bar-height\"></ion-progress-bar>\r\n            </div>\r\n        </ion-col>\r\n    </ion-row>\r\n    <ion-row>\r\n        <ion-col size=\"12\" style=\"height: 100px;\">\r\n        </ion-col>\r\n    </ion-row>\r\n</ion-grid>\r\n\r\n<div *ngIf=\"listOfDesignsHelper.length === 0\" class=\"h-100 d-flex flex-column align-center justify-center\">\r\n    <ion-img src=\"/assets/images/blank.png\" class=\"placeholder\"></ion-img>\r\n</div>\r\n</ion-content>\r\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/designoverview/newdesign/newdesign.component.html":
/*!*********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/designoverview/newdesign/newdesign.component.html ***!
  \*********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content>\r\n  <ion-refresher slot=\"fixed\" (ionRefresh)=\"getDesigns($event)\">\r\n    <ion-refresher-content pullingIcon=\"arrow-dropdown\" pullingText=\"Pull down to refresh\" refreshingSpinner=\"lines\"></ion-refresher-content>\r\n  </ion-refresher>\r\n  <ion-grid *ngIf=\"listOfDesignDataHelper.length !== 0\">\r\n    <ion-row *ngFor=\"let item of listOfDesignDataHelper;let i = index\">\r\n        <ion-col size=\"12\" class=\"ion-margin-top\">\r\n                <span class=\"ion-padding\" *ngIf=\"today === item.date\">\r\n                    Today\r\n                  </span>\r\n            <span class=\"ion-padding\" *ngIf=\"today !== item.date\">\r\n                      {{item.date | date: 'dd MMM yyyy'}}\r\n                </span>\r\n        </ion-col>\r\n        <ion-col *ngFor=\"let designData of item.listOfDesigns;let i = index \" size=\"12\">\r\n            <div class=\"ion-no-padding custom-card\" style=\"height: 100%;\">\r\n                <p class=\"customer-name\">{{designData.name}}\r\n                      <!-- <span class=\"chipdetail\" style=\"background-color: #1289A7;\" [routerLink]=\"['/design-details/',designData.id]\" routerDirection=\"forward\">\r\n                        {{designData.deliverydate | date: 'hh:mm a'}}\r\n                    </span> -->\r\n                    <span [routerLink]=\"['/design-details/',designData.id]\"\r\n                    routerDirection=\"forward\" class=\"chipdetail\" style=\"background-color: #1289A7;;\" *ngIf=\"designData.status == 'designassigned'\">Design Assigned</span>\r\n                    <span [routerLink]=\"['/design-details/',designData.id]\"\r\n                    routerDirection=\"forward\" class=\"chipdetail\" style=\"background-color: rgb(246, 104, 10);\" *ngIf=\"item.lateby > 0\">Overdue</span>\r\n                    <span fill=\"clear\" background-border=\"clear\" [routerLink]=\"['/','activity',designData.id,'design']\" class=\"imagebutton\"  size=\"small\"  ><ion-icon  src=\"/assets/images/activitylist.svg\" ></ion-icon></span>\r\n                </p>\r\n               <p> <span class=\"customer-email\" [routerLink]=\"['/design-details/',designData.id]\"\r\n                      routerDirection=\"forward\">{{designData.email}}</span>\r\n                      <span *ngIf=\"item.lateby > 1\" class=\"latebystyle\" style=\"float: right;font-size: 10px;\"><strong>Late by {{item.lateby}} days</strong></span>\r\n                      <span *ngIf=\"item.lateby == 1\" class=\"latebystyle\" style=\"float: right;font-size: 10px;\"><strong>Late by a day</strong></span>\r\n                    </p>\r\n                <a href=\"tel:{{designData.phonenumber}}\" style=\"text-decoration: none;\" class=\"z-100\">\r\n                    <span class=\"customer-phone\">{{designData.phonenumber}}</span></a>\r\n                <span style=\"margin:0px\" class=\"customer-address z-100\"\r\n                      (click)=\"openAddressOnMap(designData.address)\">{{(designData.address | slice:0:60) + (designData.address.length > 60 ? '...' : '')}}</span>\r\n\r\n                <ion-row style=\"margin-bottom: 8px;\" [routerLink]=\"['/design-details/',designData.id]\">\r\n                    <span class=\"chipdetail\" style=\"background-color: #95afc0;\" >Wattmonk</span>\r\n                    <span class=\"chipdetail\" style=\"background-color: #95afc0;\" >{{designData?.formattedjobtype}}</span>\r\n                   \r\n                      <!-- <span class=\"chipdetail\" style=\"background-color: rgb(246, 77, 10);\" *ngIf=\"designData.isoverdue\">Overdue</span> -->\r\n                </ion-row>\r\n                <ion-row class=\"ion-no-margin ion-no-margin\">\r\n                    <ion-col></ion-col>\r\n                    <!-- <ion-col class=\"ion-no-margin ion-no-padding\"> -->\r\n                    <!-- <ion-col class=\"ion-no-margin ion-no-padding\" *ngIf=\"designData.deliverydate == currentDate\"> -->\r\n                        <!-- <ion-button class=\"ion-no-margin ion-no-padding\" fill=\"clear\" [routerLink]=\"['/surveyprocess/' + designData.id + '/' + designData.jobtype + '/' + designData.latitude + '/' + designData.longitude + '/' + designData.city + '/' + designData.state]\"\r\n                        routerDirection=\"forward\">\r\n                            Start Survey\r\n                        </ion-button> -->\r\n                    <!-- </ion-col> -->\r\n                </ion-row>\r\n                <ion-progress-bar [value]=\"designData.totalpercent\" mode=\"ios\" color=\"success\" class=\"progress-bar-height\"></ion-progress-bar>\r\n            </div>\r\n        </ion-col>\r\n    </ion-row>\r\n    <ion-row>\r\n        <ion-col size=\"12\" style=\"height: 100px;\">\r\n        </ion-col>\r\n    </ion-row>\r\n</ion-grid>\r\n\r\n<div *ngIf=\"listOfDesignDataHelper.length === 0\" class=\"h-100 d-flex flex-column align-center justify-center\">\r\n    <ion-img src=\"/assets/images/blank.png\" class=\"placeholder\"></ion-img>\r\n</div>\r\n</ion-content>\r\n");

/***/ }),

/***/ "./src/app/designoverview/completeddesign/completeddesign.component.scss":
/*!*******************************************************************************!*\
  !*** ./src/app/designoverview/completeddesign/completeddesign.component.scss ***!
  \*******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".custom-card {\n  display: flex;\n  flex-direction: column;\n  background: white;\n  border-radius: 4px;\n  box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.3);\n  padding: 8px 12px;\n}\n\n.customer-name {\n  font-size: 1em;\n  color: #434343;\n  font-weight: bold;\n  display: table;\n  margin: 0px;\n}\n\n.customer-email {\n  font-size: 0.8em;\n  color: #B4B4B4;\n}\n\n.customer-phone {\n  font-size: 0.8em;\n  color: #4272B9;\n}\n\n.customer-address {\n  margin-top: 16px;\n  margin-bottom: 16px;\n  font-size: 0.8em;\n  color: #4272B9;\n}\n\n.timestamp {\n  font-size: 0.7em;\n}\n\n.chipdetail {\n  display: inline;\n  vertical-align: middle;\n  background-color: #95afc0;\n  font-size: 0.6em;\n  padding: 4px 10px;\n  border-radius: 10px;\n  text-align: center;\n  color: #fff;\n}\n\n.imagebutton {\n  float: right;\n  margin-top: 0px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZGVzaWdub3ZlcnZpZXcvY29tcGxldGVkZGVzaWduL0Y6XFxtb2JpbGVhcHAvc3JjXFxhcHBcXGRlc2lnbm92ZXJ2aWV3XFxjb21wbGV0ZWRkZXNpZ25cXGNvbXBsZXRlZGRlc2lnbi5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvZGVzaWdub3ZlcnZpZXcvY29tcGxldGVkZGVzaWduL2NvbXBsZXRlZGRlc2lnbi5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGFBQUE7RUFDQSxzQkFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSwwQ0FBQTtFQUNBLGlCQUFBO0FDQ0o7O0FERUU7RUFDRSxjQUFBO0VBQ0EsY0FBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtFQUNBLFdBQUE7QUNDSjs7QURFRTtFQUNFLGdCQUFBO0VBQ0EsY0FBQTtBQ0NKOztBREVFO0VBQ0UsZ0JBQUE7RUFDQSxjQUFBO0FDQ0o7O0FERUU7RUFDRSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0FDQ0o7O0FERUU7RUFDRSxnQkFBQTtBQ0NKOztBREVFO0VBQ0UsZUFBQTtFQUNBLHNCQUFBO0VBQ0EseUJBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7QUNDSjs7QURDQTtFQUNFLFlBQUE7RUFDQSxlQUFBO0FDRUYiLCJmaWxlIjoic3JjL2FwcC9kZXNpZ25vdmVydmlldy9jb21wbGV0ZWRkZXNpZ24vY29tcGxldGVkZGVzaWduLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmN1c3RvbS1jYXJkIHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gICAgYmFja2dyb3VuZDogd2hpdGU7XHJcbiAgICBib3JkZXItcmFkaXVzOiA0cHg7XHJcbiAgICBib3gtc2hhZG93OiAwIDFweCAycHggMCByZ2JhKDAsIDAsIDAsIDAuMyk7XHJcbiAgICBwYWRkaW5nOiA4cHggMTJweDtcclxuICB9XHJcbiAgXHJcbiAgLmN1c3RvbWVyLW5hbWUge1xyXG4gICAgZm9udC1zaXplOiAxZW07XHJcbiAgICBjb2xvcjogIzQzNDM0MztcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgZGlzcGxheTp0YWJsZTtcclxuICAgIG1hcmdpbjogMHB4O1xyXG4gIH1cclxuICBcclxuICAuY3VzdG9tZXItZW1haWwge1xyXG4gICAgZm9udC1zaXplOiAwLjhlbTtcclxuICAgIGNvbG9yOiAjQjRCNEI0O1xyXG4gIH1cclxuICBcclxuICAuY3VzdG9tZXItcGhvbmUge1xyXG4gICAgZm9udC1zaXplOiAwLjhlbTtcclxuICAgIGNvbG9yOiAjNDI3MkI5O1xyXG4gIH1cclxuICBcclxuICAuY3VzdG9tZXItYWRkcmVzcyB7XHJcbiAgICBtYXJnaW4tdG9wOiAxNnB4O1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMTZweDtcclxuICAgIGZvbnQtc2l6ZTogMC44ZW07XHJcbiAgICBjb2xvcjogIzQyNzJCOTtcclxuICB9XHJcbiAgXHJcbiAgLnRpbWVzdGFtcCB7XHJcbiAgICBmb250LXNpemU6IDAuN2VtO1xyXG4gIH1cclxuICBcclxuICAuY2hpcGRldGFpbHtcclxuICAgIGRpc3BsYXk6IGlubGluZTtcclxuICAgIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjOTVhZmMwO1xyXG4gICAgZm9udC1zaXplOiAwLjZlbTtcclxuICAgIHBhZGRpbmc6IDRweCAxMHB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGNvbG9yOiAjZmZmO1xyXG59XHJcbi5pbWFnZWJ1dHRvbntcclxuICBmbG9hdDpyaWdodDtcclxuICBtYXJnaW4tdG9wOiAwcHg7XHJcbiAgXHJcbiAgXHJcbn0iLCIuY3VzdG9tLWNhcmQge1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICBiYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgYm9yZGVyLXJhZGl1czogNHB4O1xuICBib3gtc2hhZG93OiAwIDFweCAycHggMCByZ2JhKDAsIDAsIDAsIDAuMyk7XG4gIHBhZGRpbmc6IDhweCAxMnB4O1xufVxuXG4uY3VzdG9tZXItbmFtZSB7XG4gIGZvbnQtc2l6ZTogMWVtO1xuICBjb2xvcjogIzQzNDM0MztcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gIGRpc3BsYXk6IHRhYmxlO1xuICBtYXJnaW46IDBweDtcbn1cblxuLmN1c3RvbWVyLWVtYWlsIHtcbiAgZm9udC1zaXplOiAwLjhlbTtcbiAgY29sb3I6ICNCNEI0QjQ7XG59XG5cbi5jdXN0b21lci1waG9uZSB7XG4gIGZvbnQtc2l6ZTogMC44ZW07XG4gIGNvbG9yOiAjNDI3MkI5O1xufVxuXG4uY3VzdG9tZXItYWRkcmVzcyB7XG4gIG1hcmdpbi10b3A6IDE2cHg7XG4gIG1hcmdpbi1ib3R0b206IDE2cHg7XG4gIGZvbnQtc2l6ZTogMC44ZW07XG4gIGNvbG9yOiAjNDI3MkI5O1xufVxuXG4udGltZXN0YW1wIHtcbiAgZm9udC1zaXplOiAwLjdlbTtcbn1cblxuLmNoaXBkZXRhaWwge1xuICBkaXNwbGF5OiBpbmxpbmU7XG4gIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XG4gIGJhY2tncm91bmQtY29sb3I6ICM5NWFmYzA7XG4gIGZvbnQtc2l6ZTogMC42ZW07XG4gIHBhZGRpbmc6IDRweCAxMHB4O1xuICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGNvbG9yOiAjZmZmO1xufVxuXG4uaW1hZ2VidXR0b24ge1xuICBmbG9hdDogcmlnaHQ7XG4gIG1hcmdpbi10b3A6IDBweDtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/designoverview/completeddesign/completeddesign.component.ts":
/*!*****************************************************************************!*\
  !*** ./src/app/designoverview/completeddesign/completeddesign.component.ts ***!
  \*****************************************************************************/
/*! exports provided: CompleteddesignComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CompleteddesignComponent", function() { return CompleteddesignComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic-native/launch-navigator/ngx */ "./node_modules/@ionic-native/launch-navigator/ngx/index.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var src_app_utilities_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/utilities.service */ "./src/app/utilities.service.ts");
/* harmony import */ var src_app_api_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/api.service */ "./src/app/api.service.ts");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm2015/ionic-storage.js");
/* harmony import */ var src_app_homepage_design_design_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/homepage/design/design.component */ "./src/app/homepage/design/design.component.ts");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_8__);









let CompleteddesignComponent = class CompleteddesignComponent {
    constructor(launchNavigator, datePipe, cdr, utils, storage, apiService) {
        this.launchNavigator = launchNavigator;
        this.datePipe = datePipe;
        this.cdr = cdr;
        this.utils = utils;
        this.storage = storage;
        this.apiService = apiService;
        this.listOfDesignData = [];
        this.listOfDesignDataHelper = [];
        this.options = {
            start: '',
            app: this.launchNavigator.APP.GOOGLE_MAPS
        };
        const latestDate = new Date();
        this.today = datePipe.transform(latestDate, 'M/dd/yy');
        console.log('date', this.today);
    }
    ngOnInit() {
        this.designRefreshSubscription = this.utils.getHomepageDesignRefresh().subscribe((result) => {
            this.getDesigns(null);
        });
        this.dataRefreshSubscription = this.utils.getDataRefresh().subscribe((result) => {
            if (this.listOfDesignData != null && this.listOfDesignData.length > 0) {
                this.formatDesignData(this.listOfDesignData);
            }
        });
    }
    getDesigns(event) {
        let showLoader = true;
        if (event != null && event !== undefined) {
            showLoader = false;
        }
        this.fetchPendingDesigns(event, showLoader);
    }
    fetchPendingDesigns(event, showLoader) {
        console.log("inside fetch surveys");
        this.listOfDesignData = [];
        this.listOfDesignDataHelper = [];
        this.utils.showLoadingWithPullRefreshSupport(showLoader, 'Getting Designs').then((success) => {
            this.apiService.getDesignSurveys("status=designcompleted").subscribe((response) => {
                this.utils.hideLoadingWithPullRefreshSupport(showLoader).then(() => {
                    console.log(response);
                    this.formatDesignData(response);
                    if (event !== null) {
                        event.target.complete();
                    }
                });
            }, responseError => {
                this.utils.hideLoadingWithPullRefreshSupport(showLoader).then(() => {
                    if (event !== null) {
                        event.target.complete();
                    }
                    const error = responseError.error;
                    this.utils.errorSnackBar(error.message[0].messages[0].message);
                });
            });
        });
    }
    openAddressOnMap(address) {
        this.launchNavigator.navigate(address, this.options);
    }
    formatDesignData(records) {
        this.listOfDesignData = this.fillinDynamicData(records);
        const tempData = [];
        this.listOfDesignData.forEach((designItem) => {
            if (tempData.length === 0) {
                this.sDatePassed(designItem.updated_at);
                const listOfDesign = new src_app_homepage_design_design_component__WEBPACK_IMPORTED_MODULE_7__["DesginDataHelper"]();
                listOfDesign.date = this.datePipe.transform(designItem.updated_at, 'M/dd/yy');
                listOfDesign.lateby = this.overdue;
                listOfDesign.listOfDesigns.push(designItem);
                tempData.push(listOfDesign);
            }
            else {
                let added = false;
                tempData.forEach((surveyList) => {
                    if (!added) {
                        if (surveyList.date === this.datePipe.transform(designItem.updated_at, 'M/d/yy')) {
                            surveyList.listOfDesigns.push(designItem);
                            this.sDatePassed(designItem.updated_at);
                            added = true;
                        }
                    }
                });
                if (!added) {
                    this.sDatePassed(designItem.updated_at);
                    const listOfDesign = new src_app_homepage_design_design_component__WEBPACK_IMPORTED_MODULE_7__["DesginDataHelper"]();
                    listOfDesign.date = this.datePipe.transform(designItem.updated_at, 'M/dd/yy');
                    listOfDesign.lateby = this.overdue;
                    listOfDesign.listOfDesigns.push(designItem);
                    tempData.push(listOfDesign);
                    added = true;
                }
            }
        });
        this.listOfDesignDataHelper = tempData.sort(function (a, b) {
            var dateA = new Date(a.date).getTime(), dateB = new Date(b.date).getTime();
            return dateB - dateA;
        });
        this.cdr.detectChanges();
    }
    fillinDynamicData(records) {
        records.forEach(element => {
            element.formattedjobtype = this.utils.getJobTypeName(element.jobtype);
            this.storage.get('' + element.id).then((data) => {
                console.log(data);
                if (data) {
                    element.totalpercent = data.currentprogress;
                }
                else {
                    element.totalpercent = 0;
                }
            });
        });
        return records;
    }
    sDatePassed(datestring) {
        var checkdate = moment__WEBPACK_IMPORTED_MODULE_8__(datestring, "YYYYMMDD");
        var todaydate = moment__WEBPACK_IMPORTED_MODULE_8__(new Date(), "YYYYMMDD");
        var lateby = todaydate.diff(checkdate, "days");
        this.overdue = lateby;
    }
};
CompleteddesignComponent.ctorParameters = () => [
    { type: _ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_2__["LaunchNavigator"] },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_3__["DatePipe"] },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"] },
    { type: src_app_utilities_service__WEBPACK_IMPORTED_MODULE_4__["UtilitiesService"] },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_6__["Storage"] },
    { type: src_app_api_service__WEBPACK_IMPORTED_MODULE_5__["ApiService"] }
];
CompleteddesignComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-completeddesign',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./completeddesign.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/designoverview/completeddesign/completeddesign.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./completeddesign.component.scss */ "./src/app/designoverview/completeddesign/completeddesign.component.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_2__["LaunchNavigator"],
        _angular_common__WEBPACK_IMPORTED_MODULE_3__["DatePipe"],
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"],
        src_app_utilities_service__WEBPACK_IMPORTED_MODULE_4__["UtilitiesService"],
        _ionic_storage__WEBPACK_IMPORTED_MODULE_6__["Storage"],
        src_app_api_service__WEBPACK_IMPORTED_MODULE_5__["ApiService"]])
], CompleteddesignComponent);



/***/ }),

/***/ "./src/app/designoverview/delievereddesign/delievereddesign.component.scss":
/*!*********************************************************************************!*\
  !*** ./src/app/designoverview/delievereddesign/delievereddesign.component.scss ***!
  \*********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".custom-card {\n  display: flex;\n  flex-direction: column;\n  background: white;\n  border-radius: 4px;\n  box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.3);\n  padding: 8px 12px;\n}\n\n.customer-name {\n  font-size: 1em;\n  color: #434343;\n  font-weight: bold;\n  display: table;\n  margin: 0px;\n}\n\n.customer-email {\n  font-size: 0.8em;\n  color: #B4B4B4;\n}\n\n.customer-phone {\n  font-size: 0.8em;\n  color: #4272B9;\n}\n\n.customer-address {\n  margin-top: 16px;\n  margin-bottom: 16px;\n  font-size: 0.8em;\n  color: #4272B9;\n}\n\n.timestamp {\n  font-size: 0.7em;\n}\n\n.chipdetail {\n  display: inline;\n  vertical-align: middle;\n  background-color: #95afc0;\n  font-size: 0.6em;\n  padding: 4px 10px;\n  border-radius: 10px;\n  text-align: center;\n  color: #fff;\n}\n\n.imagebutton {\n  float: right;\n  margin-top: 0px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZGVzaWdub3ZlcnZpZXcvZGVsaWV2ZXJlZGRlc2lnbi9GOlxcbW9iaWxlYXBwL3NyY1xcYXBwXFxkZXNpZ25vdmVydmlld1xcZGVsaWV2ZXJlZGRlc2lnblxcZGVsaWV2ZXJlZGRlc2lnbi5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvZGVzaWdub3ZlcnZpZXcvZGVsaWV2ZXJlZGRlc2lnbi9kZWxpZXZlcmVkZGVzaWduLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksYUFBQTtFQUNBLHNCQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLDBDQUFBO0VBQ0EsaUJBQUE7QUNDSjs7QURFRTtFQUNFLGNBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0VBQ0EsV0FBQTtBQ0NKOztBREVFO0VBQ0UsZ0JBQUE7RUFDQSxjQUFBO0FDQ0o7O0FERUU7RUFDRSxnQkFBQTtFQUNBLGNBQUE7QUNDSjs7QURFRTtFQUNFLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7QUNDSjs7QURFRTtFQUNFLGdCQUFBO0FDQ0o7O0FERUU7RUFDRSxlQUFBO0VBQ0Esc0JBQUE7RUFDQSx5QkFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtBQ0NKOztBRENBO0VBQ0UsWUFBQTtFQUNBLGVBQUE7QUNFRiIsImZpbGUiOiJzcmMvYXBwL2Rlc2lnbm92ZXJ2aWV3L2RlbGlldmVyZWRkZXNpZ24vZGVsaWV2ZXJlZGRlc2lnbi5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jdXN0b20tY2FyZCB7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICAgIGJhY2tncm91bmQ6IHdoaXRlO1xyXG4gICAgYm9yZGVyLXJhZGl1czogNHB4O1xyXG4gICAgYm94LXNoYWRvdzogMCAxcHggMnB4IDAgcmdiYSgwLCAwLCAwLCAwLjMpO1xyXG4gICAgcGFkZGluZzogOHB4IDEycHg7XHJcbiAgfVxyXG4gIFxyXG4gIC5jdXN0b21lci1uYW1lIHtcclxuICAgIGZvbnQtc2l6ZTogMWVtO1xyXG4gICAgY29sb3I6ICM0MzQzNDM7XHJcbiAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgIGRpc3BsYXk6dGFibGU7XHJcbiAgICBtYXJnaW46IDBweDtcclxuICB9XHJcbiAgXHJcbiAgLmN1c3RvbWVyLWVtYWlsIHtcclxuICAgIGZvbnQtc2l6ZTogMC44ZW07XHJcbiAgICBjb2xvcjogI0I0QjRCNDtcclxuICB9XHJcbiAgXHJcbiAgLmN1c3RvbWVyLXBob25lIHtcclxuICAgIGZvbnQtc2l6ZTogMC44ZW07XHJcbiAgICBjb2xvcjogIzQyNzJCOTtcclxuICB9XHJcbiAgXHJcbiAgLmN1c3RvbWVyLWFkZHJlc3Mge1xyXG4gICAgbWFyZ2luLXRvcDogMTZweDtcclxuICAgIG1hcmdpbi1ib3R0b206IDE2cHg7XHJcbiAgICBmb250LXNpemU6IDAuOGVtO1xyXG4gICAgY29sb3I6ICM0MjcyQjk7XHJcbiAgfVxyXG4gIFxyXG4gIC50aW1lc3RhbXAge1xyXG4gICAgZm9udC1zaXplOiAwLjdlbTtcclxuICB9XHJcbiAgXHJcbiAgLmNoaXBkZXRhaWx7XHJcbiAgICBkaXNwbGF5OiBpbmxpbmU7XHJcbiAgICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzk1YWZjMDtcclxuICAgIGZvbnQtc2l6ZTogMC42ZW07XHJcbiAgICBwYWRkaW5nOiA0cHggMTBweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBjb2xvcjogI2ZmZjtcclxufVxyXG4uaW1hZ2VidXR0b257XHJcbiAgZmxvYXQ6cmlnaHQ7XHJcbiAgbWFyZ2luLXRvcDogMHB4O1xyXG4gIFxyXG4gIFxyXG59IiwiLmN1c3RvbS1jYXJkIHtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgYmFja2dyb3VuZDogd2hpdGU7XG4gIGJvcmRlci1yYWRpdXM6IDRweDtcbiAgYm94LXNoYWRvdzogMCAxcHggMnB4IDAgcmdiYSgwLCAwLCAwLCAwLjMpO1xuICBwYWRkaW5nOiA4cHggMTJweDtcbn1cblxuLmN1c3RvbWVyLW5hbWUge1xuICBmb250LXNpemU6IDFlbTtcbiAgY29sb3I6ICM0MzQzNDM7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICBkaXNwbGF5OiB0YWJsZTtcbiAgbWFyZ2luOiAwcHg7XG59XG5cbi5jdXN0b21lci1lbWFpbCB7XG4gIGZvbnQtc2l6ZTogMC44ZW07XG4gIGNvbG9yOiAjQjRCNEI0O1xufVxuXG4uY3VzdG9tZXItcGhvbmUge1xuICBmb250LXNpemU6IDAuOGVtO1xuICBjb2xvcjogIzQyNzJCOTtcbn1cblxuLmN1c3RvbWVyLWFkZHJlc3Mge1xuICBtYXJnaW4tdG9wOiAxNnB4O1xuICBtYXJnaW4tYm90dG9tOiAxNnB4O1xuICBmb250LXNpemU6IDAuOGVtO1xuICBjb2xvcjogIzQyNzJCOTtcbn1cblxuLnRpbWVzdGFtcCB7XG4gIGZvbnQtc2l6ZTogMC43ZW07XG59XG5cbi5jaGlwZGV0YWlsIHtcbiAgZGlzcGxheTogaW5saW5lO1xuICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjOTVhZmMwO1xuICBmb250LXNpemU6IDAuNmVtO1xuICBwYWRkaW5nOiA0cHggMTBweDtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBjb2xvcjogI2ZmZjtcbn1cblxuLmltYWdlYnV0dG9uIHtcbiAgZmxvYXQ6IHJpZ2h0O1xuICBtYXJnaW4tdG9wOiAwcHg7XG59Il19 */");

/***/ }),

/***/ "./src/app/designoverview/delievereddesign/delievereddesign.component.ts":
/*!*******************************************************************************!*\
  !*** ./src/app/designoverview/delievereddesign/delievereddesign.component.ts ***!
  \*******************************************************************************/
/*! exports provided: DelievereddesignComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DelievereddesignComponent", function() { return DelievereddesignComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic-native/launch-navigator/ngx */ "./node_modules/@ionic-native/launch-navigator/ngx/index.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var src_app_utilities_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/utilities.service */ "./src/app/utilities.service.ts");
/* harmony import */ var src_app_api_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/api.service */ "./src/app/api.service.ts");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm2015/ionic-storage.js");
/* harmony import */ var src_app_homepage_design_design_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/homepage/design/design.component */ "./src/app/homepage/design/design.component.ts");
/* harmony import */ var src_app_email_model_email_model_page__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/email-model/email-model.page */ "./src/app/email-model/email-model.page.ts");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _ionic_native_social_sharing_ngx__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic-native/social-sharing/ngx */ "./node_modules/@ionic-native/social-sharing/ngx/index.js");












let DelievereddesignComponent = class DelievereddesignComponent {
    constructor(launchNavigator, datePipe, cdr, utils, storage, apiService, socialsharing, modalController) {
        this.launchNavigator = launchNavigator;
        this.datePipe = datePipe;
        this.cdr = cdr;
        this.utils = utils;
        this.storage = storage;
        this.apiService = apiService;
        this.socialsharing = socialsharing;
        this.modalController = modalController;
        this.listofDesignData = [];
        this.listofDesignDataHelper = [];
        this.options = {
            start: '',
            app: this.launchNavigator.APP.GOOGLE_MAPS
        };
        console.log("inside new surveys");
        const latestDate = new Date();
        this.today = datePipe.transform(latestDate, 'M/dd/yy');
        console.log('date', this.today);
    }
    ngOnInit() {
        this.designRefreshSubscription = this.utils.getHomepageDesignRefresh().subscribe((result) => {
            this.getDesigns(null);
        });
        this.dataRefreshSubscription = this.utils.getDataRefresh().subscribe((result) => {
            if (this.listofDesignData != null && this.listofDesignData.length > 0) {
                this.formatDesignData(this.listofDesignData);
            }
        });
    }
    getDesigns(event) {
        let showLoader = true;
        if (event != null && event !== undefined) {
            showLoader = false;
        }
        this.fetchPendingDesigns(event, showLoader);
    }
    fetchPendingDesigns(event, showLoader) {
        this.listofDesignData = [];
        this.listofDesignDataHelper = [];
        this.utils.showLoadingWithPullRefreshSupport(showLoader, 'Getting Designs').then((success) => {
            this.apiService.getDesignSurveys("status=delivered").subscribe((response) => {
                this.utils.hideLoadingWithPullRefreshSupport(showLoader).then(() => {
                    console.log(response);
                    this.formatDesignData(response);
                    if (event !== null) {
                        event.target.complete();
                    }
                });
            }, responseError => {
                this.utils.hideLoadingWithPullRefreshSupport(showLoader).then(() => {
                    if (event !== null) {
                        event.target.complete();
                    }
                    const error = responseError.error;
                    this.utils.errorSnackBar(error.message[0].messages[0].message);
                });
            });
        });
    }
    openAddressOnMap(address) {
        this.launchNavigator.navigate(address, this.options);
    }
    formatDesignData(records) {
        this.listofDesignData = this.fillinDynamicData(records);
        const tempData = [];
        this.listofDesignData.forEach((designItem) => {
            if (tempData.length === 0) {
                this.sDatePassed(designItem.updated_at);
                const listOfDesign = new src_app_homepage_design_design_component__WEBPACK_IMPORTED_MODULE_7__["DesginDataHelper"]();
                listOfDesign.date = this.datePipe.transform(designItem.updated_at, 'M/dd/yy');
                listOfDesign.lateby = this.overdue;
                listOfDesign.listOfDesigns.push(designItem);
                tempData.push(listOfDesign);
            }
            else {
                let added = false;
                tempData.forEach((designList) => {
                    if (!added) {
                        if (designList.date === this.datePipe.transform(designItem.updated_at, 'M/dd/yy')) {
                            designList.listOfDesigns.push(designItem);
                            this.sDatePassed(designItem.updated_at);
                            added = true;
                        }
                    }
                });
                if (!added) {
                    this.sDatePassed(designItem.updated_at);
                    const listOfDesign = new src_app_homepage_design_design_component__WEBPACK_IMPORTED_MODULE_7__["DesginDataHelper"]();
                    listOfDesign.date = this.datePipe.transform(designItem.updated_at, 'M/dd/yy');
                    listOfDesign.lateby = this.overdue;
                    listOfDesign.listOfDesigns.push(designItem);
                    tempData.push(listOfDesign);
                    added = true;
                }
            }
        });
        this.listofDesignDataHelper = tempData.sort(function (a, b) {
            var dateA = new Date(a.date).getTime(), dateB = new Date(b.date).getTime();
            return dateB - dateA;
        });
        this.cdr.detectChanges();
    }
    fillinDynamicData(records) {
        records.forEach(element => {
            element.formattedjobtype = this.utils.getJobTypeName(element.jobtype);
            this.storage.get('' + element.id).then((data) => {
                console.log(data);
                if (data) {
                    element.totalpercent = data.currentprogress;
                }
                else {
                    element.totalpercent = 0;
                }
            });
        });
        return records;
    }
    sDatePassed(datestring) {
        var checkdate = moment__WEBPACK_IMPORTED_MODULE_9__(datestring, "YYYYMMDD");
        var todaydate = moment__WEBPACK_IMPORTED_MODULE_9__(new Date(), "YYYYMMDD");
        var lateby = todaydate.diff(checkdate, "days");
        this.overdue = lateby;
    }
    shareWhatsapp(designData) {
        this.socialsharing.share(designData.prelimdesign.url);
    }
    shareViaEmails(id, designData) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: src_app_email_model_email_model_page__WEBPACK_IMPORTED_MODULE_8__["EmailModelPage"],
                cssClass: 'email-modal-css',
                componentProps: {
                    id: id,
                    designData: designData
                },
            });
            modal.onDidDismiss().then((data) => {
                console.log(data);
                if (data.data.cancel == 'cancel') {
                }
                else {
                    this.getDesigns(null);
                }
            });
            return yield modal.present();
        });
    }
};
DelievereddesignComponent.ctorParameters = () => [
    { type: _ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_2__["LaunchNavigator"] },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_3__["DatePipe"] },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"] },
    { type: src_app_utilities_service__WEBPACK_IMPORTED_MODULE_4__["UtilitiesService"] },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_6__["Storage"] },
    { type: src_app_api_service__WEBPACK_IMPORTED_MODULE_5__["ApiService"] },
    { type: _ionic_native_social_sharing_ngx__WEBPACK_IMPORTED_MODULE_11__["SocialSharing"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_10__["ModalController"] }
];
DelievereddesignComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-delievereddesign',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./delievereddesign.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/designoverview/delievereddesign/delievereddesign.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./delievereddesign.component.scss */ "./src/app/designoverview/delievereddesign/delievereddesign.component.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_2__["LaunchNavigator"],
        _angular_common__WEBPACK_IMPORTED_MODULE_3__["DatePipe"],
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"],
        src_app_utilities_service__WEBPACK_IMPORTED_MODULE_4__["UtilitiesService"],
        _ionic_storage__WEBPACK_IMPORTED_MODULE_6__["Storage"],
        src_app_api_service__WEBPACK_IMPORTED_MODULE_5__["ApiService"],
        _ionic_native_social_sharing_ngx__WEBPACK_IMPORTED_MODULE_11__["SocialSharing"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_10__["ModalController"]])
], DelievereddesignComponent);



/***/ }),

/***/ "./src/app/designoverview/designoverview-routing.module.ts":
/*!*****************************************************************!*\
  !*** ./src/app/designoverview/designoverview-routing.module.ts ***!
  \*****************************************************************/
/*! exports provided: DesignoverviewPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DesignoverviewPageRoutingModule", function() { return DesignoverviewPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _designoverview_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./designoverview.page */ "./src/app/designoverview/designoverview.page.ts");
/* harmony import */ var _newdesign_newdesign_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./newdesign/newdesign.component */ "./src/app/designoverview/newdesign/newdesign.component.ts");
/* harmony import */ var _completeddesign_completeddesign_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./completeddesign/completeddesign.component */ "./src/app/designoverview/completeddesign/completeddesign.component.ts");
/* harmony import */ var _inreview_design_inreview_design_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./inreview-design/inreview-design.component */ "./src/app/designoverview/inreview-design/inreview-design.component.ts");
/* harmony import */ var _delievereddesign_delievereddesign_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./delievereddesign/delievereddesign.component */ "./src/app/designoverview/delievereddesign/delievereddesign.component.ts");








const routes = [
    {
        path: '',
        component: _designoverview_page__WEBPACK_IMPORTED_MODULE_3__["DesignoverviewPage"],
        children: [
            {
                path: 'newdesigns',
                component: _newdesign_newdesign_component__WEBPACK_IMPORTED_MODULE_4__["NewdesignComponent"]
            },
            {
                path: 'completeddesigns',
                component: _completeddesign_completeddesign_component__WEBPACK_IMPORTED_MODULE_5__["CompleteddesignComponent"]
            },
            {
                path: 'inreviewdesigns',
                component: _inreview_design_inreview_design_component__WEBPACK_IMPORTED_MODULE_6__["InreviewDesignComponent"]
            },
            {
                path: 'delivereddesigns',
                component: _delievereddesign_delievereddesign_component__WEBPACK_IMPORTED_MODULE_7__["DelievereddesignComponent"]
            }
        ]
    }
];
let DesignoverviewPageRoutingModule = class DesignoverviewPageRoutingModule {
};
DesignoverviewPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], DesignoverviewPageRoutingModule);



/***/ }),

/***/ "./src/app/designoverview/designoverview.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/designoverview/designoverview.module.ts ***!
  \*********************************************************/
/*! exports provided: DesignoverviewPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DesignoverviewPageModule", function() { return DesignoverviewPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _designoverview_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./designoverview-routing.module */ "./src/app/designoverview/designoverview-routing.module.ts");
/* harmony import */ var _designoverview_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./designoverview.page */ "./src/app/designoverview/designoverview.page.ts");
/* harmony import */ var _ionic_native_diagnostic_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic-native/diagnostic/ngx */ "./node_modules/@ionic-native/diagnostic/ngx/index.js");
/* harmony import */ var _ionic_native_native_geocoder_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic-native/native-geocoder/ngx */ "./node_modules/@ionic-native/native-geocoder/ngx/index.js");
/* harmony import */ var _ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic-native/launch-navigator/ngx */ "./node_modules/@ionic-native/launch-navigator/ngx/index.js");
/* harmony import */ var _newdesign_newdesign_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./newdesign/newdesign.component */ "./src/app/designoverview/newdesign/newdesign.component.ts");
/* harmony import */ var _completeddesign_completeddesign_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./completeddesign/completeddesign.component */ "./src/app/designoverview/completeddesign/completeddesign.component.ts");
/* harmony import */ var _inreview_design_inreview_design_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./inreview-design/inreview-design.component */ "./src/app/designoverview/inreview-design/inreview-design.component.ts");
/* harmony import */ var _delievereddesign_delievereddesign_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./delievereddesign/delievereddesign.component */ "./src/app/designoverview/delievereddesign/delievereddesign.component.ts");
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../shared/shared.module */ "./src/app/shared/shared.module.ts");















let DesignoverviewPageModule = class DesignoverviewPageModule {
};
DesignoverviewPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _designoverview_routing_module__WEBPACK_IMPORTED_MODULE_5__["DesignoverviewPageRoutingModule"],
            _shared_shared_module__WEBPACK_IMPORTED_MODULE_14__["SharedModule"]
        ],
        declarations: [_designoverview_page__WEBPACK_IMPORTED_MODULE_6__["DesignoverviewPage"], _newdesign_newdesign_component__WEBPACK_IMPORTED_MODULE_10__["NewdesignComponent"], _completeddesign_completeddesign_component__WEBPACK_IMPORTED_MODULE_11__["CompleteddesignComponent"], _inreview_design_inreview_design_component__WEBPACK_IMPORTED_MODULE_12__["InreviewDesignComponent"], _delievereddesign_delievereddesign_component__WEBPACK_IMPORTED_MODULE_13__["DelievereddesignComponent"]],
        providers: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["DatePipe"],
            _ionic_native_diagnostic_ngx__WEBPACK_IMPORTED_MODULE_7__["Diagnostic"],
            _ionic_native_native_geocoder_ngx__WEBPACK_IMPORTED_MODULE_8__["NativeGeocoder"],
            _ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_9__["LaunchNavigator"]
        ]
    })
], DesignoverviewPageModule);



/***/ }),

/***/ "./src/app/designoverview/designoverview.page.scss":
/*!*********************************************************!*\
  !*** ./src/app/designoverview/designoverview.page.scss ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".bottom-bar {\n  margin: 8px;\n  border-radius: 50px;\n  box-shadow: 0 -2px 8px 0 rgba(0, 0, 0, 0.1);\n  border: 2px solid white;\n  background: #FFFAEB;\n}\n\n.tab {\n  padding-top: 1em;\n  padding-bottom: 1em;\n  padding-bottom: 1em;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n\n.tabText {\n  margin-left: 8px;\n  font-size: 1em;\n}\n\n.tab-icon {\n  width: 24px;\n  height: 24px;\n}\n\nion-tab-button {\n  font-size: 14px;\n  --color: #9E9E9E;\n  --color-selected: #3c78d8;\n}\n\nion-tab-button[aria-selected=true] {\n  border-bottom: 3px solid #3c78d8;\n  border-bottom-left-radius: 2px;\n  border-bottom-right-radius: 2px;\n}\n\n.custombadge {\n  background-color: #3c78d8;\n  color: #ffffff;\n  border-radius: 50%;\n  width: 16px;\n  height: 16px;\n  font-size: 8px;\n  padding: 4px;\n  position: absolute;\n  margin-left: 4px;\n}\n\n.font {\n  font-size: 10px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZGVzaWdub3ZlcnZpZXcvRjpcXG1vYmlsZWFwcC9zcmNcXGFwcFxcZGVzaWdub3ZlcnZpZXdcXGRlc2lnbm92ZXJ2aWV3LnBhZ2Uuc2NzcyIsInNyYy9hcHAvZGVzaWdub3ZlcnZpZXcvZGVzaWdub3ZlcnZpZXcucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksV0FBQTtFQUNBLG1CQUFBO0VBQ0EsMkNBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0FDQ0o7O0FERUE7RUFDSSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsbUJBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtBQ0NKOztBREVBO0VBQ0ksZ0JBQUE7RUFDQSxjQUFBO0FDQ0o7O0FERUE7RUFDSSxXQUFBO0VBQ0EsWUFBQTtBQ0NKOztBREVBO0VBQ0ksZUFBQTtFQUNBLGdCQUFBO0VBQ0EseUJBQUE7QUNDSjs7QURFQTtFQUNJLGdDQUFBO0VBQ0EsOEJBQUE7RUFDQSwrQkFBQTtBQ0NKOztBREVBO0VBQ0kseUJBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGNBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtBQ0NKOztBREVBO0VBQ0ksZUFBQTtBQ0NKIiwiZmlsZSI6InNyYy9hcHAvZGVzaWdub3ZlcnZpZXcvZGVzaWdub3ZlcnZpZXcucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmJvdHRvbS1iYXIge1xyXG4gICAgbWFyZ2luOiA4cHg7XHJcbiAgICBib3JkZXItcmFkaXVzOiA1MHB4O1xyXG4gICAgYm94LXNoYWRvdzogMCAtMnB4IDhweCAwIHJnYmEoMCwgMCwgMCwgMC4xKTtcclxuICAgIGJvcmRlcjogMnB4IHNvbGlkIHdoaXRlO1xyXG4gICAgYmFja2dyb3VuZDogI0ZGRkFFQjtcclxufVxyXG5cclxuLnRhYiB7XHJcbiAgICBwYWRkaW5nLXRvcDogMWVtO1xyXG4gICAgcGFkZGluZy1ib3R0b206IDFlbTtcclxuICAgIHBhZGRpbmctYm90dG9tOiAxZW07XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG59XHJcblxyXG4udGFiVGV4dCB7XHJcbiAgICBtYXJnaW4tbGVmdDogOHB4O1xyXG4gICAgZm9udC1zaXplOiAxZW07XHJcbn1cclxuXHJcbi50YWItaWNvbiB7XHJcbiAgICB3aWR0aDogMjRweDtcclxuICAgIGhlaWdodDogMjRweDtcclxufVxyXG5cclxuaW9uLXRhYi1idXR0b24ge1xyXG4gICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgLS1jb2xvcjogIzlFOUU5RTtcclxuICAgIC0tY29sb3Itc2VsZWN0ZWQ6ICMzYzc4ZDg7XHJcbn1cclxuXHJcbmlvbi10YWItYnV0dG9uW2FyaWEtc2VsZWN0ZWQ9dHJ1ZV0ge1xyXG4gICAgYm9yZGVyLWJvdHRvbTogM3B4IHNvbGlkICMzYzc4ZDg7XHJcbiAgICBib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiAycHg7XHJcbiAgICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogMnB4O1xyXG59XHJcblxyXG4uY3VzdG9tYmFkZ2V7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjM2M3OGQ4O1xyXG4gICAgY29sb3I6ICNmZmZmZmY7XHJcbiAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICB3aWR0aDogMTZweDtcclxuICAgIGhlaWdodDogMTZweDtcclxuICAgIGZvbnQtc2l6ZTogOHB4O1xyXG4gICAgcGFkZGluZzogNHB4O1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgbWFyZ2luLWxlZnQ6IDRweDtcclxufVxyXG5cclxuLmZvbnR7XHJcbiAgICBmb250LXNpemU6IDEwcHg7XHJcbn0iLCIuYm90dG9tLWJhciB7XG4gIG1hcmdpbjogOHB4O1xuICBib3JkZXItcmFkaXVzOiA1MHB4O1xuICBib3gtc2hhZG93OiAwIC0ycHggOHB4IDAgcmdiYSgwLCAwLCAwLCAwLjEpO1xuICBib3JkZXI6IDJweCBzb2xpZCB3aGl0ZTtcbiAgYmFja2dyb3VuZDogI0ZGRkFFQjtcbn1cblxuLnRhYiB7XG4gIHBhZGRpbmctdG9wOiAxZW07XG4gIHBhZGRpbmctYm90dG9tOiAxZW07XG4gIHBhZGRpbmctYm90dG9tOiAxZW07XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xufVxuXG4udGFiVGV4dCB7XG4gIG1hcmdpbi1sZWZ0OiA4cHg7XG4gIGZvbnQtc2l6ZTogMWVtO1xufVxuXG4udGFiLWljb24ge1xuICB3aWR0aDogMjRweDtcbiAgaGVpZ2h0OiAyNHB4O1xufVxuXG5pb24tdGFiLWJ1dHRvbiB7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgLS1jb2xvcjogIzlFOUU5RTtcbiAgLS1jb2xvci1zZWxlY3RlZDogIzNjNzhkODtcbn1cblxuaW9uLXRhYi1idXR0b25bYXJpYS1zZWxlY3RlZD10cnVlXSB7XG4gIGJvcmRlci1ib3R0b206IDNweCBzb2xpZCAjM2M3OGQ4O1xuICBib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiAycHg7XG4gIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiAycHg7XG59XG5cbi5jdXN0b21iYWRnZSB7XG4gIGJhY2tncm91bmQtY29sb3I6ICMzYzc4ZDg7XG4gIGNvbG9yOiAjZmZmZmZmO1xuICBib3JkZXItcmFkaXVzOiA1MCU7XG4gIHdpZHRoOiAxNnB4O1xuICBoZWlnaHQ6IDE2cHg7XG4gIGZvbnQtc2l6ZTogOHB4O1xuICBwYWRkaW5nOiA0cHg7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgbWFyZ2luLWxlZnQ6IDRweDtcbn1cblxuLmZvbnQge1xuICBmb250LXNpemU6IDEwcHg7XG59Il19 */");

/***/ }),

/***/ "./src/app/designoverview/designoverview.page.ts":
/*!*******************************************************!*\
  !*** ./src/app/designoverview/designoverview.page.ts ***!
  \*******************************************************/
/*! exports provided: DesignoverviewPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DesignoverviewPage", function() { return DesignoverviewPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _cometchat_pro_cordova_ionic_chat__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @cometchat-pro/cordova-ionic-chat */ "./node_modules/@cometchat-pro/cordova-ionic-chat/CometChat.js");
/* harmony import */ var _cometchat_pro_cordova_ionic_chat__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_cometchat_pro_cordova_ionic_chat__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _storage_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../storage.service */ "./src/app/storage.service.ts");
/* harmony import */ var _model_constants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../model/constants */ "./src/app/model/constants.ts");
/* harmony import */ var _api_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../api.service */ "./src/app/api.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_native_social_sharing_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic-native/social-sharing/ngx */ "./node_modules/@ionic-native/social-sharing/ngx/index.js");
/* harmony import */ var src_app_email_model_email_model_page__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/email-model/email-model.page */ "./src/app/email-model/email-model.page.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");










let DesignoverviewPage = class DesignoverviewPage {
    constructor(route, storage, modalController, apiService, socialSharing) {
        this.route = route;
        this.storage = storage;
        this.modalController = modalController;
        this.apiService = apiService;
        this.socialSharing = socialSharing;
    }
    ngOnInit() {
        this.setupCometChatUser();
        this.updateUserPushToken();
        this.route.navigate(['designoverview/newdesigns']);
    }
    ngOnDestroy() {
    }
    setupCometChatUser() {
        const appSetting = new _cometchat_pro_cordova_ionic_chat__WEBPACK_IMPORTED_MODULE_2__["CometChat"].AppSettingsBuilder().subscribePresenceForAllUsers().setRegion(_model_constants__WEBPACK_IMPORTED_MODULE_4__["COMET_CHAT_REGION"]).build();
        _cometchat_pro_cordova_ionic_chat__WEBPACK_IMPORTED_MODULE_2__["CometChat"].init(_model_constants__WEBPACK_IMPORTED_MODULE_4__["COMET_CHAT_APP_ID"], appSetting).then(() => {
            console.log('Initialization completed successfully');
            _cometchat_pro_cordova_ionic_chat__WEBPACK_IMPORTED_MODULE_2__["CometChat"].login(this.storage.getUserID(), _model_constants__WEBPACK_IMPORTED_MODULE_4__["COMET_CHAT_AUTH_KEY"]).then((user) => {
                console.log('Login Successful:', { user });
            }, error => {
                console.log('Login failed with exception:', { error });
            });
        }, error => {
            console.log('Initialization failed with error:', error);
        });
    }
    updateUserPushToken() {
        let token = localStorage.getItem('pushtoken');
        console.log(token);
        let userid = this.storage.getUserID();
        let tokendata = {
            pushtokens: token
        };
        this.apiService.pushtoken(userid, { "newpushtoken": token }).subscribe((data) => {
            console.log(data, "fcm data");
        }, (error) => {
        });
    }
    getDesigns(event) {
        let showLoader = true;
        if (event != null && event !== undefined) {
            showLoader = false;
        }
    }
    shareWhatsapp(designData) {
        this.socialSharing.share(designData.prelimdesign.url);
    }
    shareViaEmails(id, designData) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: src_app_email_model_email_model_page__WEBPACK_IMPORTED_MODULE_8__["EmailModelPage"],
                cssClass: 'email-modal-css',
                componentProps: {
                    id: id,
                    designData: designData
                },
            });
            modal.onDidDismiss().then((data) => {
                console.log(data);
                if (data.data.cancel == 'cancel') {
                }
                else {
                    this.getDesigns(null);
                }
            });
            return yield modal.present();
        });
    }
};
DesignoverviewPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"] },
    { type: _storage_service__WEBPACK_IMPORTED_MODULE_3__["StorageService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__["ModalController"] },
    { type: _api_service__WEBPACK_IMPORTED_MODULE_5__["ApiService"] },
    { type: _ionic_native_social_sharing_ngx__WEBPACK_IMPORTED_MODULE_7__["SocialSharing"] }
];
DesignoverviewPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-designoverview',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./designoverview.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/designoverview/designoverview.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./designoverview.page.scss */ "./src/app/designoverview/designoverview.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"],
        _storage_service__WEBPACK_IMPORTED_MODULE_3__["StorageService"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_9__["ModalController"],
        _api_service__WEBPACK_IMPORTED_MODULE_5__["ApiService"],
        _ionic_native_social_sharing_ngx__WEBPACK_IMPORTED_MODULE_7__["SocialSharing"]])
], DesignoverviewPage);



/***/ }),

/***/ "./src/app/designoverview/inreview-design/inreview-design.component.scss":
/*!*******************************************************************************!*\
  !*** ./src/app/designoverview/inreview-design/inreview-design.component.scss ***!
  \*******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".custom-card {\n  display: flex;\n  flex-direction: column;\n  background: white;\n  border-radius: 4px;\n  box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.3);\n  padding: 8px 12px;\n}\n\n.customer-name {\n  font-size: 1em;\n  color: #434343;\n  font-weight: bold;\n  display: table;\n  margin: 0px;\n}\n\n.customer-email {\n  font-size: 0.8em;\n  color: #B4B4B4;\n}\n\n.customer-phone {\n  font-size: 0.8em;\n  color: #4272B9;\n}\n\n.customer-address {\n  margin-top: 16px;\n  margin-bottom: 16px;\n  font-size: 0.8em;\n  color: #4272B9;\n}\n\n.timestamp {\n  font-size: 0.7em;\n}\n\n.chipdetail {\n  display: inline;\n  vertical-align: middle;\n  background-color: #95afc0;\n  font-size: 0.6em;\n  padding: 4px 10px;\n  border-radius: 10px;\n  text-align: center;\n  color: #fff;\n}\n\n.imagebutton {\n  float: right;\n  margin-top: 0px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZGVzaWdub3ZlcnZpZXcvaW5yZXZpZXctZGVzaWduL0Y6XFxtb2JpbGVhcHAvc3JjXFxhcHBcXGRlc2lnbm92ZXJ2aWV3XFxpbnJldmlldy1kZXNpZ25cXGlucmV2aWV3LWRlc2lnbi5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvZGVzaWdub3ZlcnZpZXcvaW5yZXZpZXctZGVzaWduL2lucmV2aWV3LWRlc2lnbi5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGFBQUE7RUFDQSxzQkFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSwwQ0FBQTtFQUNBLGlCQUFBO0FDQ0o7O0FERUU7RUFDRSxjQUFBO0VBQ0EsY0FBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtFQUNBLFdBQUE7QUNDSjs7QURFRTtFQUNFLGdCQUFBO0VBQ0EsY0FBQTtBQ0NKOztBREVFO0VBQ0UsZ0JBQUE7RUFDQSxjQUFBO0FDQ0o7O0FERUU7RUFDRSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0FDQ0o7O0FERUU7RUFDRSxnQkFBQTtBQ0NKOztBREVFO0VBQ0UsZUFBQTtFQUNBLHNCQUFBO0VBQ0EseUJBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7QUNDSjs7QURDQTtFQUNFLFlBQUE7RUFDQSxlQUFBO0FDRUYiLCJmaWxlIjoic3JjL2FwcC9kZXNpZ25vdmVydmlldy9pbnJldmlldy1kZXNpZ24vaW5yZXZpZXctZGVzaWduLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmN1c3RvbS1jYXJkIHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gICAgYmFja2dyb3VuZDogd2hpdGU7XHJcbiAgICBib3JkZXItcmFkaXVzOiA0cHg7XHJcbiAgICBib3gtc2hhZG93OiAwIDFweCAycHggMCByZ2JhKDAsIDAsIDAsIDAuMyk7XHJcbiAgICBwYWRkaW5nOiA4cHggMTJweDtcclxuICB9XHJcbiAgXHJcbiAgLmN1c3RvbWVyLW5hbWUge1xyXG4gICAgZm9udC1zaXplOiAxZW07XHJcbiAgICBjb2xvcjogIzQzNDM0MztcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgZGlzcGxheTp0YWJsZTtcclxuICAgIG1hcmdpbjogMHB4O1xyXG4gIH1cclxuICBcclxuICAuY3VzdG9tZXItZW1haWwge1xyXG4gICAgZm9udC1zaXplOiAwLjhlbTtcclxuICAgIGNvbG9yOiAjQjRCNEI0O1xyXG4gIH1cclxuICBcclxuICAuY3VzdG9tZXItcGhvbmUge1xyXG4gICAgZm9udC1zaXplOiAwLjhlbTtcclxuICAgIGNvbG9yOiAjNDI3MkI5O1xyXG4gIH1cclxuICBcclxuICAuY3VzdG9tZXItYWRkcmVzcyB7XHJcbiAgICBtYXJnaW4tdG9wOiAxNnB4O1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMTZweDtcclxuICAgIGZvbnQtc2l6ZTogMC44ZW07XHJcbiAgICBjb2xvcjogIzQyNzJCOTtcclxuICB9XHJcbiAgXHJcbiAgLnRpbWVzdGFtcCB7XHJcbiAgICBmb250LXNpemU6IDAuN2VtO1xyXG4gIH1cclxuICBcclxuICAuY2hpcGRldGFpbHtcclxuICAgIGRpc3BsYXk6IGlubGluZTtcclxuICAgIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjOTVhZmMwO1xyXG4gICAgZm9udC1zaXplOiAwLjZlbTtcclxuICAgIHBhZGRpbmc6IDRweCAxMHB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGNvbG9yOiAjZmZmO1xyXG59XHJcbi5pbWFnZWJ1dHRvbntcclxuICBmbG9hdDpyaWdodDtcclxuICBtYXJnaW4tdG9wOiAwcHg7XHJcbiAgXHJcbiAgXHJcbn0iLCIuY3VzdG9tLWNhcmQge1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICBiYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgYm9yZGVyLXJhZGl1czogNHB4O1xuICBib3gtc2hhZG93OiAwIDFweCAycHggMCByZ2JhKDAsIDAsIDAsIDAuMyk7XG4gIHBhZGRpbmc6IDhweCAxMnB4O1xufVxuXG4uY3VzdG9tZXItbmFtZSB7XG4gIGZvbnQtc2l6ZTogMWVtO1xuICBjb2xvcjogIzQzNDM0MztcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gIGRpc3BsYXk6IHRhYmxlO1xuICBtYXJnaW46IDBweDtcbn1cblxuLmN1c3RvbWVyLWVtYWlsIHtcbiAgZm9udC1zaXplOiAwLjhlbTtcbiAgY29sb3I6ICNCNEI0QjQ7XG59XG5cbi5jdXN0b21lci1waG9uZSB7XG4gIGZvbnQtc2l6ZTogMC44ZW07XG4gIGNvbG9yOiAjNDI3MkI5O1xufVxuXG4uY3VzdG9tZXItYWRkcmVzcyB7XG4gIG1hcmdpbi10b3A6IDE2cHg7XG4gIG1hcmdpbi1ib3R0b206IDE2cHg7XG4gIGZvbnQtc2l6ZTogMC44ZW07XG4gIGNvbG9yOiAjNDI3MkI5O1xufVxuXG4udGltZXN0YW1wIHtcbiAgZm9udC1zaXplOiAwLjdlbTtcbn1cblxuLmNoaXBkZXRhaWwge1xuICBkaXNwbGF5OiBpbmxpbmU7XG4gIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XG4gIGJhY2tncm91bmQtY29sb3I6ICM5NWFmYzA7XG4gIGZvbnQtc2l6ZTogMC42ZW07XG4gIHBhZGRpbmc6IDRweCAxMHB4O1xuICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGNvbG9yOiAjZmZmO1xufVxuXG4uaW1hZ2VidXR0b24ge1xuICBmbG9hdDogcmlnaHQ7XG4gIG1hcmdpbi10b3A6IDBweDtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/designoverview/inreview-design/inreview-design.component.ts":
/*!*****************************************************************************!*\
  !*** ./src/app/designoverview/inreview-design/inreview-design.component.ts ***!
  \*****************************************************************************/
/*! exports provided: InreviewDesignComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InreviewDesignComponent", function() { return InreviewDesignComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic-native/launch-navigator/ngx */ "./node_modules/@ionic-native/launch-navigator/ngx/index.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var src_app_utilities_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/utilities.service */ "./src/app/utilities.service.ts");
/* harmony import */ var src_app_api_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/api.service */ "./src/app/api.service.ts");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm2015/ionic-storage.js");
/* harmony import */ var src_app_homepage_design_design_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/homepage/design/design.component */ "./src/app/homepage/design/design.component.ts");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_8__);






// import { DesignStorageModel } from 'src/app/model/Design-storage.model';



let InreviewDesignComponent = class InreviewDesignComponent {
    constructor(launchNavigator, datePipe, cdr, utils, storage, apiService) {
        this.launchNavigator = launchNavigator;
        this.datePipe = datePipe;
        this.cdr = cdr;
        this.utils = utils;
        this.storage = storage;
        this.apiService = apiService;
        this.listOfDesigns = [];
        this.listOfDesignsHelper = [];
        this.options = {
            start: '',
            app: this.launchNavigator.APP.GOOGLE_MAPS
        };
        const latestDate = new Date();
        this.today = datePipe.transform(latestDate, 'M/dd/yy');
        console.log('date', this.today);
    }
    ngOnInit() {
        this.DesignRefreshSubscription = this.utils.getHomepageDesignRefresh().subscribe((result) => {
            this.getDesigns(null);
        });
        this.dataRefreshSubscription = this.utils.getDataRefresh().subscribe((result) => {
            if (this.listOfDesigns != null && this.listOfDesigns.length > 0) {
                this.formatDesignData(this.listOfDesigns);
            }
        });
    }
    getDesigns(event) {
        let showLoader = true;
        if (event != null && event !== undefined) {
            showLoader = false;
        }
        this.fetchPendingDesigns(event, showLoader);
    }
    fetchPendingDesigns(event, showLoader) {
        console.log("inside fetch Designs");
        this.listOfDesigns = [];
        this.listOfDesignsHelper = [];
        this.utils.showLoadingWithPullRefreshSupport(showLoader, 'Getting Designs').then((success) => {
            this.apiService.getDesignSurveys("status=reviewassigned&status=reviewfailed&status=reviewpassed").subscribe((response) => {
                this.utils.hideLoadingWithPullRefreshSupport(showLoader).then(() => {
                    console.log(response);
                    this.formatDesignData(response);
                    if (event !== null) {
                        event.target.complete();
                    }
                });
            }, responseError => {
                this.utils.hideLoadingWithPullRefreshSupport(showLoader).then(() => {
                    if (event !== null) {
                        event.target.complete();
                    }
                    const error = responseError.error;
                    this.utils.errorSnackBar(error.message[0].messages[0].message);
                });
            });
        });
    }
    openAddressOnMap(address) {
        this.launchNavigator.navigate(address, this.options);
    }
    formatDesignData(records) {
        this.listOfDesigns = this.fillinDynamicData(records);
        const tempData = [];
        this.listOfDesigns.forEach((designItem) => {
            if (tempData.length === 0) {
                this.sDatePassed(designItem.updated_at);
                const listOfDesign = new src_app_homepage_design_design_component__WEBPACK_IMPORTED_MODULE_7__["DesginDataHelper"]();
                listOfDesign.date = this.datePipe.transform(designItem.updated_at, 'M/dd/yy');
                listOfDesign.lateby = this.overdue;
                listOfDesign.listOfDesigns.push(designItem);
                tempData.push(listOfDesign);
            }
            else {
                let added = false;
                tempData.forEach((DesignList) => {
                    if (!added) {
                        if (DesignList.date === this.datePipe.transform(designItem.updated_at, 'M/dd/yy')) {
                            DesignList.listOfDesigns.push(designItem);
                            this.sDatePassed(designItem.updated_at);
                            added = true;
                        }
                    }
                });
                if (!added) {
                    this.sDatePassed(designItem.updated_at);
                    const listOfDesign = new src_app_homepage_design_design_component__WEBPACK_IMPORTED_MODULE_7__["DesginDataHelper"]();
                    listOfDesign.date = this.datePipe.transform(designItem.updated_at, 'M/dd/yy');
                    listOfDesign.lateby = this.overdue;
                    listOfDesign.listOfDesigns.push(designItem);
                    tempData.push(listOfDesign);
                    added = true;
                }
            }
        });
        this.listOfDesignsHelper = tempData.sort(function (a, b) {
            var dateA = new Date(a.date).getTime(), dateB = new Date(b.date).getTime();
            return dateB - dateA;
        });
        this.cdr.detectChanges();
    }
    fillinDynamicData(records) {
        records.forEach(element => {
            element.formattedjobtype = this.utils.getJobTypeName(element.jobtype);
            this.storage.get('' + element.id).then((data) => {
                console.log(data);
                if (data) {
                    element.totalpercent = data.currentprogress;
                }
                else {
                    element.totalpercent = 0;
                }
            });
        });
        return records;
    }
    sDatePassed(datestring) {
        var checkdate = moment__WEBPACK_IMPORTED_MODULE_8__(datestring, "YYYYMMDD");
        var todaydate = moment__WEBPACK_IMPORTED_MODULE_8__(new Date(), "YYYYMMDD");
        var lateby = todaydate.diff(checkdate, "days");
        this.overdue = lateby;
    }
};
InreviewDesignComponent.ctorParameters = () => [
    { type: _ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_2__["LaunchNavigator"] },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_3__["DatePipe"] },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"] },
    { type: src_app_utilities_service__WEBPACK_IMPORTED_MODULE_4__["UtilitiesService"] },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_6__["Storage"] },
    { type: src_app_api_service__WEBPACK_IMPORTED_MODULE_5__["ApiService"] }
];
InreviewDesignComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-inreview-design',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./inreview-design.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/designoverview/inreview-design/inreview-design.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./inreview-design.component.scss */ "./src/app/designoverview/inreview-design/inreview-design.component.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_2__["LaunchNavigator"],
        _angular_common__WEBPACK_IMPORTED_MODULE_3__["DatePipe"],
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"],
        src_app_utilities_service__WEBPACK_IMPORTED_MODULE_4__["UtilitiesService"],
        _ionic_storage__WEBPACK_IMPORTED_MODULE_6__["Storage"],
        src_app_api_service__WEBPACK_IMPORTED_MODULE_5__["ApiService"]])
], InreviewDesignComponent);



/***/ }),

/***/ "./src/app/designoverview/newdesign/newdesign.component.scss":
/*!*******************************************************************!*\
  !*** ./src/app/designoverview/newdesign/newdesign.component.scss ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".custom-card {\n  display: flex;\n  flex-direction: column;\n  background: #fff;\n  border-radius: 4px;\n  box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.3);\n  padding: 8px 12px;\n}\n\n.customer-name {\n  font-size: 1em;\n  color: #434343;\n  font-weight: bold;\n  display: table;\n  margin: 0px;\n}\n\n.customer-email {\n  font-size: 0.8em;\n  color: #B4B4B4;\n}\n\n.customer-phone {\n  font-size: 0.8em;\n  color: #4272B9;\n}\n\n.customer-address {\n  margin-top: 16px;\n  margin-bottom: 16px;\n  font-size: 0.8em;\n  color: #4272B9;\n}\n\n.timestamp {\n  font-size: 0.7em;\n}\n\n.chipdetail {\n  display: inline;\n  vertical-align: middle;\n  background-color: #95afc0;\n  font-size: 0.6em;\n  padding: 4px 10px;\n  border-radius: 10px;\n  text-align: center;\n  color: #fff;\n}\n\n.imagebutton {\n  float: right;\n  margin-top: 0px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZGVzaWdub3ZlcnZpZXcvbmV3ZGVzaWduL0Y6XFxtb2JpbGVhcHAvc3JjXFxhcHBcXGRlc2lnbm92ZXJ2aWV3XFxuZXdkZXNpZ25cXG5ld2Rlc2lnbi5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvZGVzaWdub3ZlcnZpZXcvbmV3ZGVzaWduL25ld2Rlc2lnbi5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGFBQUE7RUFDQSxzQkFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSwwQ0FBQTtFQUNBLGlCQUFBO0FDQ0o7O0FERUU7RUFDRSxjQUFBO0VBQ0EsY0FBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtFQUNBLFdBQUE7QUNDSjs7QURFRTtFQUNFLGdCQUFBO0VBQ0EsY0FBQTtBQ0NKOztBREVFO0VBQ0UsZ0JBQUE7RUFDQSxjQUFBO0FDQ0o7O0FERUU7RUFDRSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0FDQ0o7O0FERUU7RUFDRSxnQkFBQTtBQ0NKOztBREVFO0VBQ0UsZUFBQTtFQUNBLHNCQUFBO0VBQ0EseUJBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7QUNDSjs7QURDQTtFQUNFLFlBQUE7RUFDQSxlQUFBO0FDRUYiLCJmaWxlIjoic3JjL2FwcC9kZXNpZ25vdmVydmlldy9uZXdkZXNpZ24vbmV3ZGVzaWduLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmN1c3RvbS1jYXJkIHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gICAgYmFja2dyb3VuZDogI2ZmZjtcclxuICAgIGJvcmRlci1yYWRpdXM6IDRweDtcclxuICAgIGJveC1zaGFkb3c6IDAgMXB4IDJweCAwIHJnYmEoMCwgMCwgMCwgMC4zKTtcclxuICAgIHBhZGRpbmc6IDhweCAxMnB4O1xyXG4gIH1cclxuICBcclxuICAuY3VzdG9tZXItbmFtZSB7XHJcbiAgICBmb250LXNpemU6IDFlbTtcclxuICAgIGNvbG9yOiAjNDM0MzQzO1xyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICBkaXNwbGF5OnRhYmxlO1xyXG4gICAgbWFyZ2luOiAwcHg7XHJcbiAgfVxyXG4gIFxyXG4gIC5jdXN0b21lci1lbWFpbCB7XHJcbiAgICBmb250LXNpemU6IDAuOGVtO1xyXG4gICAgY29sb3I6ICNCNEI0QjQ7XHJcbiAgfVxyXG4gIFxyXG4gIC5jdXN0b21lci1waG9uZSB7XHJcbiAgICBmb250LXNpemU6IDAuOGVtO1xyXG4gICAgY29sb3I6ICM0MjcyQjk7XHJcbiAgfVxyXG4gIFxyXG4gIC5jdXN0b21lci1hZGRyZXNzIHtcclxuICAgIG1hcmdpbi10b3A6IDE2cHg7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAxNnB4O1xyXG4gICAgZm9udC1zaXplOiAwLjhlbTtcclxuICAgIGNvbG9yOiAjNDI3MkI5O1xyXG4gIH1cclxuICBcclxuICAudGltZXN0YW1wIHtcclxuICAgIGZvbnQtc2l6ZTogMC43ZW07XHJcbiAgfVxyXG4gIFxyXG4gIC5jaGlwZGV0YWlse1xyXG4gICAgZGlzcGxheTogaW5saW5lO1xyXG4gICAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICM5NWFmYzA7XHJcbiAgICBmb250LXNpemU6IDAuNmVtO1xyXG4gICAgcGFkZGluZzogNHB4IDEwcHg7XHJcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgY29sb3I6ICNmZmY7XHJcbn1cclxuLmltYWdlYnV0dG9ue1xyXG4gIGZsb2F0OnJpZ2h0O1xyXG4gIG1hcmdpbi10b3A6IDBweDtcclxuICBcclxuICBcclxufSIsIi5jdXN0b20tY2FyZCB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gIGJhY2tncm91bmQ6ICNmZmY7XG4gIGJvcmRlci1yYWRpdXM6IDRweDtcbiAgYm94LXNoYWRvdzogMCAxcHggMnB4IDAgcmdiYSgwLCAwLCAwLCAwLjMpO1xuICBwYWRkaW5nOiA4cHggMTJweDtcbn1cblxuLmN1c3RvbWVyLW5hbWUge1xuICBmb250LXNpemU6IDFlbTtcbiAgY29sb3I6ICM0MzQzNDM7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICBkaXNwbGF5OiB0YWJsZTtcbiAgbWFyZ2luOiAwcHg7XG59XG5cbi5jdXN0b21lci1lbWFpbCB7XG4gIGZvbnQtc2l6ZTogMC44ZW07XG4gIGNvbG9yOiAjQjRCNEI0O1xufVxuXG4uY3VzdG9tZXItcGhvbmUge1xuICBmb250LXNpemU6IDAuOGVtO1xuICBjb2xvcjogIzQyNzJCOTtcbn1cblxuLmN1c3RvbWVyLWFkZHJlc3Mge1xuICBtYXJnaW4tdG9wOiAxNnB4O1xuICBtYXJnaW4tYm90dG9tOiAxNnB4O1xuICBmb250LXNpemU6IDAuOGVtO1xuICBjb2xvcjogIzQyNzJCOTtcbn1cblxuLnRpbWVzdGFtcCB7XG4gIGZvbnQtc2l6ZTogMC43ZW07XG59XG5cbi5jaGlwZGV0YWlsIHtcbiAgZGlzcGxheTogaW5saW5lO1xuICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjOTVhZmMwO1xuICBmb250LXNpemU6IDAuNmVtO1xuICBwYWRkaW5nOiA0cHggMTBweDtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBjb2xvcjogI2ZmZjtcbn1cblxuLmltYWdlYnV0dG9uIHtcbiAgZmxvYXQ6IHJpZ2h0O1xuICBtYXJnaW4tdG9wOiAwcHg7XG59Il19 */");

/***/ }),

/***/ "./src/app/designoverview/newdesign/newdesign.component.ts":
/*!*****************************************************************!*\
  !*** ./src/app/designoverview/newdesign/newdesign.component.ts ***!
  \*****************************************************************/
/*! exports provided: NewdesignComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NewdesignComponent", function() { return NewdesignComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var src_app_homepage_design_design_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/homepage/design/design.component */ "./src/app/homepage/design/design.component.ts");
/* harmony import */ var _ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/launch-navigator/ngx */ "./node_modules/@ionic-native/launch-navigator/ngx/index.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var src_app_utilities_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/utilities.service */ "./src/app/utilities.service.ts");
/* harmony import */ var src_app_api_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/api.service */ "./src/app/api.service.ts");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm2015/ionic-storage.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_8__);







// import { SurveyStorageModel } from 'src/app/model/survey-storage.model';


let NewdesignComponent = class NewdesignComponent {
    constructor(launchNavigator, datePipe, cdr, utils, storage, apiService) {
        this.launchNavigator = launchNavigator;
        this.datePipe = datePipe;
        this.cdr = cdr;
        this.utils = utils;
        this.storage = storage;
        this.apiService = apiService;
        this.listOfDesignData = [];
        this.listOfDesignDataHelper = [];
        this.currentDate = new Date();
        this.options = {
            start: '',
            app: this.launchNavigator.APP.GOOGLE_MAPS
        };
        const latestDate = new Date();
        this.today = datePipe.transform(latestDate, 'M/dd/yy');
        console.log('date', this.today);
        this.apiService._OnMessageReceivedSubject.subscribe((r) => {
            console.log('message received! ', r);
            this.getDesigns();
        });
    }
    ngOnInit() {
        console.log("ngoninit");
        console.log(this.currentDate.toISOString());
    }
    ionViewDidEnter(event) {
        this.getDesigns(event);
        this.designRefreshSubscription = this.utils.getHomepageDesignRefresh().subscribe((result) => {
            this.getDesigns(null);
        });
        this.dataRefreshSubscription = this.utils.getDataRefresh().subscribe((result) => {
            if (this.listOfDesignData != null && this.listOfDesignData.length > 0) {
                this.formatDesignData(this.listOfDesignData);
            }
        });
    }
    getDesigns(event) {
        let showLoader = true;
        if (event != null && event !== undefined) {
            showLoader = false;
        }
        this.fetchPendingDesigns(event);
    }
    fetchPendingDesigns(event, showLoader) {
        this.listOfDesignData = [];
        this.listOfDesignDataHelper = [];
        this.utils.showLoadingWithPullRefreshSupport(showLoader, 'Getting Designs').then((success) => {
            this.apiService.getDesignSurveys("status=designassigned&status=designinprocess").subscribe((response) => {
                this.utils.hideLoadingWithPullRefreshSupport(showLoader).then(() => {
                    console.log(response);
                    this.formatDesignData(response);
                    if (event !== null) {
                        event.target.complete();
                    }
                });
            }, responseError => {
                this.utils.hideLoadingWithPullRefreshSupport(showLoader).then(() => {
                    if (event !== null) {
                        event.target.complete();
                    }
                    const error = responseError.error;
                    this.utils.errorSnackBar(error.message[0].messages[0].message);
                });
            });
        });
    }
    openAddressOnMap(address) {
        this.launchNavigator.navigate(address, this.options);
    }
    formatDesignData(records) {
        this.overdue = [];
        this.listOfDesignData = this.fillinDynamicData(records);
        console.log(this.listOfDesignData);
        const tempData = [];
        this.listOfDesignData.forEach((designItem) => {
            if (tempData.length === 0) {
                this.sDatePassed(designItem.updated_at);
                const listOfDesigns = new src_app_homepage_design_design_component__WEBPACK_IMPORTED_MODULE_2__["DesginDataHelper"]();
                listOfDesigns.date = this.datePipe.transform(designItem.updated_at, 'M/dd/yy');
                listOfDesigns.lateby = this.overdue;
                listOfDesigns.listOfDesigns.push(designItem);
                tempData.push(listOfDesigns);
            }
            else {
                let added = false;
                tempData.forEach((designList) => {
                    if (!added) {
                        if (designList.date === this.datePipe.transform(designItem.updated_at, 'M/dd/yy')) {
                            designList.listOfDesigns.push(designItem);
                            this.sDatePassed(designItem.updated_at);
                            added = true;
                        }
                    }
                });
                if (!added) {
                    this.sDatePassed(designItem.updated_at);
                    const listOfDesigns = new src_app_homepage_design_design_component__WEBPACK_IMPORTED_MODULE_2__["DesginDataHelper"]();
                    listOfDesigns.date = this.datePipe.transform(designItem.updated_at, 'M/dd/yy');
                    listOfDesigns.lateby = this.overdue;
                    listOfDesigns.listOfDesigns.push(designItem);
                    tempData.push(listOfDesigns);
                    added = true;
                }
            }
        });
        this.listOfDesignDataHelper = tempData.sort(function (a, b) {
            var dateA = new Date(a.date).getTime(), dateB = new Date(b.date).getTime();
            return dateB - dateA;
        });
        this.cdr.detectChanges();
    }
    fillinDynamicData(records) {
        records.forEach(element => {
            element.formattedjobtype = this.utils.getJobTypeName(element.jobtype);
            this.storage.get('' + element.id).then((data) => {
                console.log(data);
                if (data) {
                    element.totalpercent = data.currentprogress;
                }
                else {
                    element.totalpercent = 0;
                }
            });
        });
        return records;
    }
    sDatePassed(datestring) {
        var checkdate = moment__WEBPACK_IMPORTED_MODULE_8__(datestring, "YYYYMMDD");
        var todaydate = moment__WEBPACK_IMPORTED_MODULE_8__(new Date(), "YYYYMMDD");
        var lateby = todaydate.diff(checkdate, "days");
        this.overdue = lateby;
    }
};
NewdesignComponent.ctorParameters = () => [
    { type: _ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_3__["LaunchNavigator"] },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_4__["DatePipe"] },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"] },
    { type: src_app_utilities_service__WEBPACK_IMPORTED_MODULE_5__["UtilitiesService"] },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_7__["Storage"] },
    { type: src_app_api_service__WEBPACK_IMPORTED_MODULE_6__["ApiService"] }
];
NewdesignComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-newdesign',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./newdesign.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/designoverview/newdesign/newdesign.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./newdesign.component.scss */ "./src/app/designoverview/newdesign/newdesign.component.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_3__["LaunchNavigator"],
        _angular_common__WEBPACK_IMPORTED_MODULE_4__["DatePipe"],
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"],
        src_app_utilities_service__WEBPACK_IMPORTED_MODULE_5__["UtilitiesService"],
        _ionic_storage__WEBPACK_IMPORTED_MODULE_7__["Storage"],
        src_app_api_service__WEBPACK_IMPORTED_MODULE_6__["ApiService"]])
], NewdesignComponent);



/***/ })

}]);
//# sourceMappingURL=designoverview-designoverview-module-es2015.js.map