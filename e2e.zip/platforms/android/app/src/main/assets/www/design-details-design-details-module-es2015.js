(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["design-details-design-details-module"],{

/***/ "./node_modules/ngx-timer/fesm2015/ngx-timer.js":
/*!******************************************************!*\
  !*** ./node_modules/ngx-timer/fesm2015/ngx-timer.js ***!
  \******************************************************/
/*! exports provided: NgxTimerModule, CountupTimerComponent, CountupTimerService, countUpTimerConfigModel, timerTexts, CountdownTimerComponent, CountdownTimerService, countDownTimerConfigModel, countDownTimerTexts, TimerStaus, ɵa, ɵb */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NgxTimerModule", function() { return NgxTimerModule; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CountupTimerComponent", function() { return CountupTimerComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CountupTimerService", function() { return CountupTimerService; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "countUpTimerConfigModel", function() { return countUpTimerConfigModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "timerTexts", function() { return timerTexts; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CountdownTimerComponent", function() { return CountdownTimerComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CountdownTimerService", function() { return CountdownTimerService; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "countDownTimerConfigModel", function() { return countDownTimerConfigModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "countDownTimerTexts", function() { return countDownTimerTexts; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TimerStaus", function() { return TimerStaus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵa", function() { return StopWatchComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵb", function() { return StopWatchService; });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");




/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class CountupTimerService {
    constructor() {
        //Init
        this.timerValue = {
            seconds: '00',
            mins: '00',
            hours: '00',
        };
        this.isTimerStart = false;
        this.totalSeconds = 0;
        this.currentOperationId = 0;
        //start timer
        this.startTimer = (/**
         * @param {?=} startTime
         * @return {?}
         */
        (startTime) => {
            if (startTime) {
                /** @type {?} */
                let currentDate = new Date();
                /** @type {?} */
                let startedTime = new Date(startTime);
                this.totalSeconds = Math.round((currentDate.getTime() - startedTime.getTime()) / 1000);
            }
            this.isTimerStart = true;
            return true;
        });
        //end timer
        this.pauseTimer = (/**
         * @param {?=} startTime
         * @param {?=} endTime
         * @return {?}
         */
        (startTime, endTime) => {
            if (startTime && endTime) {
                /** @type {?} */
                let endedDate = new Date(endTime);
                /** @type {?} */
                let startedTime = new Date(startTime);
                this.totalSeconds = Math.round((endedDate.getTime() - startedTime.getTime()) / 1000);
            }
            this.isTimerStart = false;
            return false;
        });
        //reset Timer
        this.stopTimer = (/**
         * @return {?}
         */
        () => {
            this.isTimerStart = false;
            this.totalSeconds = 0;
        });
        //get timer value Obj
        this.getTimerValue = (/**
         * @return {?}
         */
        () => {
            return new rxjs__WEBPACK_IMPORTED_MODULE_2__["Observable"]((/**
             * @param {?} obs
             * @return {?}
             */
            obs => {
                if (this.intervalSubscription) {
                    this.intervalSubscription.unsubscribe();
                }
                this.intervalSubscription = this.interval.subscribe((/**
                 * @param {?} int
                 * @return {?}
                 */
                int => {
                    if (this.isTimerStart) {
                        ++this.totalSeconds;
                        this.timerValue.seconds = this.setTimervalue(this.totalSeconds % 60);
                        /** @type {?} */
                        let totalSecondsForMinutes = 0;
                        totalSecondsForMinutes = (Math.trunc(this.totalSeconds / 60) >= 60) ? (this.totalSeconds / 60) % 60 : this.totalSeconds / 60;
                        this.timerValue.mins = this.setTimervalue(Math.trunc(totalSecondsForMinutes));
                        this.timerValue.hours = this.setTimervalue(Math.trunc(this.totalSeconds / 3600));
                        obs.next(this.timerValue);
                        obs.complete();
                    }
                    else {
                        if (this.totalSeconds > 0) {
                            this.timerValue.seconds = this.setTimervalue(this.totalSeconds % 60);
                            /** @type {?} */
                            let totalSecondsForMinutes = 0;
                            totalSecondsForMinutes = (Math.trunc(this.totalSeconds / 60) >= 60) ? (this.totalSeconds / 60) % 60 : this.totalSeconds / 60;
                            this.timerValue.mins = this.setTimervalue(Math.trunc(totalSecondsForMinutes));
                            this.timerValue.hours = this.setTimervalue(Math.trunc(this.totalSeconds / 3600));
                        }
                        else {
                            this.timerValue.hours = "00";
                            this.timerValue.mins = "00";
                            this.timerValue.seconds = "00";
                        }
                        obs.next(this.timerValue);
                        obs.complete();
                    }
                }), (/**
                 * @param {?} error
                 * @return {?}
                 */
                error => {
                    obs.error(error);
                    obs.complete();
                }));
            }));
        });
        //set timer value
        this.setTimervalue = (/**
         * @param {?} val
         * @return {?}
         */
        (val) => {
            /** @type {?} */
            let valString = val + "";
            return (valString.length < 2) ? "0" + valString : valString;
        });
        this.interval = Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["interval"])(1000);
    }
}
CountupTimerService.decorators = [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"], args: [{
                providedIn: 'root'
            },] }
];
/** @nocollapse */
CountupTimerService.ctorParameters = () => [];
/** @nocollapse */ CountupTimerService.ngInjectableDef = Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["defineInjectable"])({ factory: function CountupTimerService_Factory() { return new CountupTimerService(); }, token: CountupTimerService, providedIn: "root" });

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class countUpTimerConfigModel {
}
class timerTexts {
}

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class CountupTimerComponent {
    /**
     * @param {?} countupTimerService
     */
    constructor(countupTimerService) {
        this.countupTimerService = countupTimerService;
        //Init
        this.timerObj = {};
        //get timer value
        this.getTimerValue = (/**
         * @return {?}
         */
        () => {
            this.timerSubscription = this.countupTimerService.getTimerValue().subscribe((/**
             * @param {?} res
             * @return {?}
             */
            res => {
                this.timerObj = Object.assign(res);
            }), (/**
             * @param {?} error
             * @return {?}
             */
            error => {
                console.log(error);
                console.log('Failed to get timer value');
            }));
        });
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        this.getTimerValue();
        this.timerConfig = new countUpTimerConfigModel();
        this.timerTextConfig = new timerTexts();
        this.timerConfig = this.countUpTimerConfig ? Object.assign(this.countUpTimerConfig) : null;
        this.timerTextConfig = this.countUpTimerConfig && this.countUpTimerConfig.timerTexts ? Object.assign(this.countUpTimerConfig.timerTexts) : null;
    }
    /**
     * @return {?}
     */
    ngOnDestroy() {
        this.timerSubscription.unsubscribe();
    }
}
CountupTimerComponent.decorators = [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"], args: [{
                selector: 'countup-timer',
                template: "<div [class]=\"timerConfig?.timerClass ? timerConfig.timerClass : ''\">\n  <span>{{timerObj.hours}}</span><span class=\"time-category\">{{timerTextConfig && timerTextConfig.hourText ? timerTextConfig.hourText : 'hh'}} </span> \n  <span>{{timerObj.mins}}</span><span class=\"time-category\">{{timerTextConfig && timerTextConfig.minuteText ? timerTextConfig.minuteText : 'mm'}}  </span> \n  <span>{{timerObj.seconds}}</span><span class=\"time-category\">{{timerTextConfig && timerTextConfig.secondsText ? timerTextConfig.secondsText : 'ss'}}</span>\n</div>",
                styles: [""]
            }] }
];
/** @nocollapse */
CountupTimerComponent.ctorParameters = () => [
    { type: CountupTimerService }
];
CountupTimerComponent.propDecorators = {
    startTime: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"] }],
    countUpTimerConfig: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class countDownTimerConfigModel {
}
class countDownTimerTexts {
}
/** @enum {string} */
const TimerStaus = {
    START: "START",
    PAUSE: "PAUSE",
    STOP: "STOP",
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class CountdownTimerService {
    constructor() {
        this.onTimerStatusChange = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        //Init
        this.timerValue = {
            seconds: '00',
            mins: '00',
            hours: '00',
        };
        this.isTimerStart = false;
        this.totalSeconds = 0;
        this.currentOperationId = 0;
        //start timer
        this.startTimer = (/**
         * @param {?} startTime
         * @return {?}
         */
        (startTime) => {
            if (startTime) {
                /** @type {?} */
                let currentDate = new Date();
                /** @type {?} */
                let startedTime = new Date(startTime);
                this.totalSeconds = (Math.round((currentDate.getTime() - startedTime.getTime()) / 1000)) * -1;
            }
            this.isTimerStart = true;
            this.onTimerStatusChange.emit(TimerStaus.START);
            return true;
        });
        //end timer
        this.pauseTimer = (/**
         * @param {?=} startTime
         * @param {?=} endTime
         * @return {?}
         */
        (startTime, endTime) => {
            if (startTime && endTime) {
                /** @type {?} */
                let endedDate = new Date(endTime);
                /** @type {?} */
                let startedTime = new Date(startTime);
                this.totalSeconds = Math.round((endedDate.getTime() - startedTime.getTime()) / 1000);
            }
            this.isTimerStart = false;
            this.onTimerStatusChange.emit(TimerStaus.PAUSE);
            return false;
        });
        //reset Timer
        this.stopTimer = (/**
         * @return {?}
         */
        () => {
            this.isTimerStart = false;
            this.totalSeconds = 0;
            this.onTimerStatusChange.emit(TimerStaus.STOP);
        });
        //resume Timer
        this.resumeTimer = (/**
         * @return {?}
         */
        () => {
            this.isTimerStart = true;
        });
        //get timer value Obj
        this.getTimerValue = (/**
         * @return {?}
         */
        () => {
            return new rxjs__WEBPACK_IMPORTED_MODULE_2__["Observable"]((/**
             * @param {?} obs
             * @return {?}
             */
            obs => {
                if (this.intervalSubscription) {
                    this.intervalSubscription.unsubscribe();
                }
                this.intervalSubscription = this.interval.subscribe((/**
                 * @param {?} int
                 * @return {?}
                 */
                int => {
                    if (this.isTimerStart && this.totalSeconds > 0) {
                        --this.totalSeconds;
                        this.timerValue.seconds = this.setTimervalue(this.totalSeconds % 60);
                        /** @type {?} */
                        let totalSecondsForMinutes = 0;
                        totalSecondsForMinutes = (Math.trunc(this.totalSeconds / 60) >= 60) ? (this.totalSeconds / 60) % 60 : this.totalSeconds / 60;
                        this.timerValue.mins = this.setTimervalue(Math.trunc(totalSecondsForMinutes));
                        this.timerValue.hours = this.setTimervalue(Math.trunc(this.totalSeconds / 3600));
                        obs.next(this.timerValue);
                        obs.complete();
                    }
                    else {
                        if (this.totalSeconds > 0) {
                            this.timerValue.seconds = this.setTimervalue(this.totalSeconds % 60);
                            /** @type {?} */
                            let totalSecondsForMinutes = 0;
                            totalSecondsForMinutes = (Math.trunc(this.totalSeconds / 60) >= 60) ? (this.totalSeconds / 60) % 60 : this.totalSeconds / 60;
                            this.timerValue.mins = this.setTimervalue(Math.trunc(totalSecondsForMinutes));
                            this.timerValue.hours = this.setTimervalue(Math.trunc(this.totalSeconds / 3600));
                        }
                        else {
                            this.timerValue.hours = "00";
                            this.timerValue.mins = "00";
                            this.timerValue.seconds = "00";
                            this.stopTimer();
                        }
                        obs.next(this.timerValue);
                        obs.complete();
                    }
                }), (/**
                 * @param {?} error
                 * @return {?}
                 */
                error => {
                    obs.error(error);
                    obs.complete();
                }));
            }));
        });
        //set timer value
        this.setTimervalue = (/**
         * @param {?} val
         * @return {?}
         */
        (val) => {
            /** @type {?} */
            let valString = val + "";
            return (valString.length < 2) ? "0" + valString : valString;
        });
        this.interval = Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["interval"])(1000);
    }
}
CountdownTimerService.decorators = [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"], args: [{
                providedIn: 'root'
            },] }
];
/** @nocollapse */
CountdownTimerService.ctorParameters = () => [];
/** @nocollapse */ CountdownTimerService.ngInjectableDef = Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["defineInjectable"])({ factory: function CountdownTimerService_Factory() { return new CountdownTimerService(); }, token: CountdownTimerService, providedIn: "root" });

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class CountdownTimerComponent {
    /**
     * @param {?} countdownTimerService
     */
    constructor(countdownTimerService) {
        this.countdownTimerService = countdownTimerService;
        this.timerObj = {};
        //get timer value
        this.getTimerValue = (/**
         * @return {?}
         */
        () => {
            this.timerSubscription = this.countdownTimerService.getTimerValue().subscribe((/**
             * @param {?} res
             * @return {?}
             */
            res => {
                this.timerObj = Object.assign(res);
            }), (/**
             * @param {?} error
             * @return {?}
             */
            error => {
                console.log(error);
                console.log('Failed to get timer value');
            }));
        });
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        this.getTimerValue();
        this.timerConfig = new countDownTimerConfigModel();
        this.timerTextConfig = new countDownTimerTexts();
        this.timerConfig = this.countDownTimerConfig ? Object.assign(this.countDownTimerConfig) : null;
        this.timerTextConfig = this.countDownTimerConfig && this.countDownTimerConfig.timerTexts ? Object.assign(this.countDownTimerConfig.timerTexts) : null;
    }
    /**
     * @return {?}
     */
    ngOnDestroy() {
        this.timerSubscription.unsubscribe();
    }
}
CountdownTimerComponent.decorators = [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"], args: [{
                selector: 'countdown-timer',
                template: "<div [class]=\"timerConfig?.timerClass ? timerConfig.timerClass : ''\">\r\n  <span>{{timerObj.hours}}</span><span class=\"time-category\">{{timerTextConfig && timerTextConfig.hourText ? timerTextConfig.hourText : 'hh'}} </span> \r\n  <span>{{timerObj.mins}}</span><span class=\"time-category\">{{timerTextConfig && timerTextConfig.minuteText ? timerTextConfig.minuteText : 'mm'}}  </span> \r\n  <span>{{timerObj.seconds}}</span><span class=\"time-category\">{{timerTextConfig && timerTextConfig.secondsText ? timerTextConfig.secondsText : 'ss'}}</span>\r\n</div>",
                styles: [""]
            }] }
];
/** @nocollapse */
CountdownTimerComponent.ctorParameters = () => [
    { type: CountdownTimerService }
];
CountdownTimerComponent.propDecorators = {
    startTime: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"] }],
    countDownTimerConfig: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class StopWatchService {
    constructor() {
        //Init
        this.timerValue = {
            miliseconds: '00',
            seconds: '00',
            mins: '00',
            hours: '00',
        };
        this.isTimerStart = false;
        this.totalSeconds = 0;
        this.currentOperationId = 0;
        //start timer
        this.startTimer = (/**
         * @return {?}
         */
        () => {
            debugger;
            this.isTimerStart = true;
            return true;
        });
        //end timer
        this.pauseTimer = (/**
         * @param {?=} startTime
         * @param {?=} endTime
         * @return {?}
         */
        (startTime, endTime) => {
            if (startTime && endTime) {
                /** @type {?} */
                let endedDate = new Date(endTime);
                /** @type {?} */
                let startedTime = new Date(startTime);
                this.totalSeconds = Math.round((endedDate.getTime() - startedTime.getTime()) / 1000);
            }
            this.isTimerStart = false;
            return false;
        });
        //reset Timer
        this.stopTimer = (/**
         * @return {?}
         */
        () => {
            this.isTimerStart = false;
            this.totalSeconds = 0;
        });
        //resume Timer
        this.resumeTimer = (/**
         * @return {?}
         */
        () => {
            this.isTimerStart = true;
        });
        //get timer value Obj
        this.getTimerValue = (/**
         * @return {?}
         */
        () => {
            return new rxjs__WEBPACK_IMPORTED_MODULE_2__["Observable"]((/**
             * @param {?} obs
             * @return {?}
             */
            obs => {
                if (this.intervalSubscription) {
                    this.intervalSubscription.unsubscribe();
                }
                this.intervalSubscription = this.interval.subscribe((/**
                 * @param {?} int
                 * @return {?}
                 */
                int => {
                    if (this.isTimerStart && this.totalSeconds > 0) {
                        --this.totalSeconds;
                        this.timerValue.seconds = this.setTimervalue(this.totalSeconds % 60);
                        /** @type {?} */
                        let totalSecondsForMinutes = 0;
                        totalSecondsForMinutes = (Math.trunc(this.totalSeconds / 60) >= 60) ? (this.totalSeconds / 60) % 60 : this.totalSeconds / 60;
                        this.timerValue.mins = this.setTimervalue(Math.trunc(totalSecondsForMinutes));
                        this.timerValue.hours = this.setTimervalue(Math.trunc(this.totalSeconds / 3600));
                        obs.next(this.timerValue);
                        obs.complete();
                    }
                    else {
                        if (this.totalSeconds > 0) {
                            this.timerValue.seconds = this.setTimervalue(this.totalSeconds % 60);
                            /** @type {?} */
                            let totalSecondsForMinutes = 0;
                            totalSecondsForMinutes = (Math.trunc(this.totalSeconds / 60) >= 60) ? (this.totalSeconds / 60) % 60 : this.totalSeconds / 60;
                            this.timerValue.mins = this.setTimervalue(Math.trunc(totalSecondsForMinutes));
                            this.timerValue.hours = this.setTimervalue(Math.trunc(this.totalSeconds / 3600));
                        }
                        else {
                            this.timerValue.hours = "00";
                            this.timerValue.mins = "00";
                            this.timerValue.seconds = "00";
                        }
                        obs.next(this.timerValue);
                        obs.complete();
                    }
                }), (/**
                 * @param {?} error
                 * @return {?}
                 */
                error => {
                    obs.error(error);
                    obs.complete();
                }));
            }));
        });
        //set timer value
        this.setTimervalue = (/**
         * @param {?} val
         * @return {?}
         */
        (val) => {
            /** @type {?} */
            let valString = val + "";
            return (valString.length < 2) ? "0" + valString : valString;
        });
        this.interval = Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["interval"])(10000);
    }
}
StopWatchService.decorators = [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"], args: [{
                providedIn: 'root'
            },] }
];
/** @nocollapse */
StopWatchService.ctorParameters = () => [];
/** @nocollapse */ StopWatchService.ngInjectableDef = Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["defineInjectable"])({ factory: function StopWatchService_Factory() { return new StopWatchService(); }, token: StopWatchService, providedIn: "root" });

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class StopWatchComponent {
    // timerConfig: countDownTimerConfigModel;
    // timerTextConfig: countDownTimerTexts;
    /**
     * @param {?} countdownTimerService
     */
    constructor(countdownTimerService) {
        this.countdownTimerService = countdownTimerService;
        this.timerObj = {};
        //get timer value
        this.getTimerValue = (/**
         * @return {?}
         */
        () => {
            this.timerSubscription = this.countdownTimerService.getTimerValue().subscribe((/**
             * @param {?} res
             * @return {?}
             */
            res => {
                this.timerObj = Object.assign(res);
            }), (/**
             * @param {?} error
             * @return {?}
             */
            error => {
                console.log(error);
                console.log('Failed to get timer value');
            }));
        });
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        this.getTimerValue();
        // this.timerConfig = new countDownTimerConfigModel();
        // this.timerTextConfig = new countDownTimerTexts();
        // this.timerConfig = this.countDownTimerConfig ? Object.assign(this.countDownTimerConfig) : null;
        // this.timerTextConfig = this.countDownTimerConfig && this.countDownTimerConfig.timerTexts ? Object.assign(this.countDownTimerConfig.timerTexts) :  null;
    }
    /**
     * @return {?}
     */
    ngOnDestroy() {
        this.timerSubscription.unsubscribe();
    }
}
StopWatchComponent.decorators = [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"], args: [{
                selector: 'stop-watch',
                template: "<!-- <div [class]=\"timerConfig?.timerClass ? timerConfig.timerClass : ''\">\n  <span>{{timerObj.hours}}</span><span class=\"time-category\">{{timerTextConfig && timerTextConfig.hourText ? timerTextConfig.hourText : 'hh'}} </span> \n  <span>{{timerObj.mins}}</span><span class=\"time-category\">{{timerTextConfig && timerTextConfig.minuteText ? timerTextConfig.minuteText : 'mm'}}  </span> \n  <span>{{timerObj.seconds}}</span><span class=\"time-category\">{{timerTextConfig && timerTextConfig.secondsText ? timerTextConfig.secondsText : 'ss'}}</span>\n  <span>{{timerObj.miliseconds}}</span><span class=\"time-category\">{{timerTextConfig && timerTextConfig.milisecondsText ? timerTextConfig.milisecondsText : 'ss'}}</span>\n</div> -->",
                styles: [""]
            }] }
];
/** @nocollapse */
StopWatchComponent.ctorParameters = () => [
    { type: StopWatchService }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class NgxTimerModule {
}
NgxTimerModule.decorators = [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"], args: [{
                declarations: [
                    CountupTimerComponent,
                    CountdownTimerComponent,
                    StopWatchComponent
                ],
                imports: [
                    _angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"]
                ],
                exports: [
                    CountupTimerComponent,
                    CountdownTimerComponent,
                    StopWatchComponent
                ],
                entryComponents: [
                    CountupTimerComponent,
                    CountdownTimerComponent,
                    StopWatchComponent
                ],
                providers: [
                    CountupTimerService,
                    CountdownTimerService,
                    StopWatchService
                ]
            },] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */



//# sourceMappingURL=ngx-timer.js.map

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/design-details/design-details.page.html":
/*!***********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/design-details/design-details.page.html ***!
  \***********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header class=\"ion-no-border white-bg\" *ngIf=\"design\">\r\n    <ion-grid class=\"ion-padding-top ion-padding-start ion-padding-end header-bg\">\r\n        <ion-row>\r\n            <ion-col size=\"1\">\r\n                <ion-button fill=\"clear\" size=\"small\" class=\"ion-no-padding\" (click)=\"goBack()\">\r\n                    <ion-img src=\"/assets/images/back.svg\" class=\"action-icon\"></ion-img>\r\n                </ion-button>\r\n            </ion-col>\r\n            <!-- <ion-col size=\"auto\">\r\n                <ion-button fill=\"clear\" disabled=\"true\" size=\"small\" class=\"ion-no-padding action-icon\">\r\n                </ion-button>\r\n            </ion-col> -->\r\n            <ion-col class=\"ion-text-center\" size=\"9\" style=\"padding-left: 27px;\">\r\n                <ion-grid class=\"ion-align-items-center ion-justify-content-center\">\r\n                    <ion-row class=\"ion-align-items-center ion-justify-content-center\">\r\n                        <span class=\"survey-name ion-text-center\">{{design?.name}}</span>\r\n                    </ion-row>\r\n                    <ion-row class=\"ion-align-items-center ion-justify-content-center\">\r\n                        <span class=\"survey-email ion-text-center\">{{design?.email}}</span>\r\n                    </ion-row>\r\n                </ion-grid>\r\n            </ion-col>\r\n            <ion-col size=\"1\" *ngIf=\"design.status !='requestaccepted' && user.role.type != 'designer' && user.role.type != 'qcinspector' && design.status !='designcompleted' && (user.role.type=='clientsuperadmin' && design.status=='created') || (user.role.type=='wattmonkadmins' && design.status=='created')\">\r\n                <ion-button fill=\"clear\" size=\"small\" class=\"ion-no-padding\"\r\n                    [routerLink]=\"['/schedule/design/',designId]\" routerDirection=\"forward\">\r\n                    <ion-img src=\"/assets/images/edit.svg\" class=\"action-icon\"></ion-img>\r\n                </ion-button>\r\n            </ion-col>\r\n            <ion-col size=\"1\" *ngIf=\"design.status !='requestaccepted' && user.role.type != 'designer' && user.role.type != 'qcinspector' && design.status !='designcompleted' && (user.role.type=='clientsuperadmin' && design.status=='created') || (user.role.type=='wattmonkadmins' && design.status=='created')\" style=\"float:right\">\r\n                <ion-button fill=\"clear\" size=\"small\" class=\"ion-no-padding\" (click)=\"deleteDesign()\">\r\n                    <ion-img src=\"/assets/images/trash.svg\" class=\"action-icon\"></ion-img>\r\n                </ion-button>\r\n            </ion-col>\r\n        </ion-row>\r\n    </ion-grid>\r\n    <ion-grid class=\"position-relative ion-no-padding\">\r\n        <ion-row class=\"ion-no-padding border-header header-half-height\">\r\n        </ion-row>\r\n        <ion-row class=\"ion-no-padding header-half-height\">\r\n\r\n        </ion-row>\r\n        <ion-row class=\"ion-no-padding position-absolute header-icon-position full-width\">\r\n            <ion-col class=\"flex-center\">\r\n                <ion-img src=\"/assets/images/blueprint.svg\" class=\"header-icon\"></ion-img>\r\n            </ion-col>\r\n        </ion-row>\r\n        <ion-row class=\"ion-no-padding\" *ngIf=\"user.role.type=='designer'\">\r\n            <ion-col class=\"flex-center\">\r\n                <countdown-timer [countDownTimerConfig]=\"timerConfig\"></countdown-timer>\r\n            </ion-col>\r\n        </ion-row>\r\n    </ion-grid>\r\n</ion-header>\r\n\r\n<ion-content class=\"ion-padding page-text-color\" scrollY=\"true\">\r\n    <ion-grid *ngIf=\"design\" class=\"page-text-color\">\r\n        <ion-row>\r\n            <ion-col class=\"font\">\r\n                <span (click)=\"openAddressOnMap(design.address)\" class=\"address\">{{design?.address}}</span>\r\n            </ion-col>\r\n            <ion-col size=\"auto\" class=\"ion-text-end\">\r\n                <ion-grid class=\"ion-no-padding\">\r\n                    <ion-row>\r\n                        <ion-col><span class=\"data-header font\">monthly bill</span></ion-col>\r\n                    </ion-row>\r\n                    <ion-row>\r\n                        <ion-col class=\"font\"><span>{{design?.monthlybill | currency: 'USD'}}</span></ion-col>\r\n                    </ion-row>\r\n                </ion-grid>\r\n\r\n            </ion-col>\r\n        </ion-row>\r\n\r\n        <ion-row class=\"ion-margin-top\">\r\n            <ion-col size=\"12\">\r\n                <span class=\"models font\">Module Details</span>\r\n            </ion-col>\r\n            <ion-col>\r\n                <ion-grid class=\"ion-no-padding\">\r\n                    <ion-row class=\"ion-no-padding\">\r\n                        <ion-col><span class=\"model-type font\">make</span></ion-col>\r\n                        <ion-col size=\"auto\">\r\n                            <span class=\"model-name font\">{{design.solarmake?.name}}</span>\r\n                        </ion-col>\r\n                    </ion-row>\r\n                    <ion-row>\r\n                        <ion-col><span class=\"model-type font\">model</span></ion-col>\r\n                        <ion-col size=\"auto\">\r\n                            <span class=\"model-name font\">{{design.solarmodel?.name}}</span>\r\n                        </ion-col>\r\n                    </ion-row>\r\n                </ion-grid>\r\n            </ion-col>\r\n        </ion-row>\r\n\r\n        <ion-row class=\"ion-margin-top\">\r\n            <ion-col size=\"12\">\r\n                <span class=\"models font\">Inverter Details</span>\r\n            </ion-col>\r\n            <ion-col>\r\n                <ion-grid class=\"ion-no-padding\">\r\n                    <ion-row class=\"ion-no-padding\">\r\n                        <ion-col><span class=\"model-type font\">make</span></ion-col>\r\n                        <ion-col size=\"auto\">\r\n                            <span class=\"model-name font\">{{design.invertermake?.name}}</span>\r\n                        </ion-col>\r\n                    </ion-row>\r\n                    <ion-row>\r\n                        <ion-col><span class=\"model-type font\">model</span></ion-col>\r\n                        <ion-col size=\"auto\">\r\n                            <span class=\"model-name font\">{{design.invertermodel?.name}}</span>\r\n                        </ion-col>\r\n                    </ion-row>\r\n                </ion-grid>\r\n            </ion-col>\r\n        </ion-row>\r\n\r\n        <ion-row class=\"ion-margin-top\">\r\n            <ion-col>\r\n                <ion-grid class=\"ion-no-padding\">\r\n                    <ion-row class=\"ion-no-padding\">\r\n                        <ion-col><span class=\"model-type font\">new construction</span></ion-col>\r\n                        <ion-col size=\"auto\">\r\n                            <span class=\"model-name font\">{{design?.newconstruction}}</span>\r\n                        </ion-col>\r\n                    </ion-row>\r\n                    <ion-row class=\"ion-no-padding font\">\r\n                        <ng-container *ngIf=\"design.attachments !=[]\"> \r\n                            <ion-col><span class=\"model-type font\">Attachments</span></ion-col>\r\n                            <ion-col size=\"auto\" >\r\n                                <div *ngFor=\"let attachment of design.attachments;let i=index\" style=\"display: flex;justify-content: flex-end;\">\r\n                                    <span class=\"model-name font\" style=\"color:#3c78d8 !important\" (click)=\"showurl(i,'attachments')\">{{attachment?.name}}{{attachment?.ext}}</span>\r\n                                </div>\r\n                            </ion-col>\r\n                        </ng-container>\r\n                    </ion-row>\r\n                    <ion-row *ngIf=\"design.newconstruction=='Yes'\" class=\"ion-no-padding font\">\r\n                        <ng-container *ngIf=\"design.architecturaldesign !=[]\"> \r\n                            <ion-col><span class=\"model-type font\">Architectural design</span></ion-col>\r\n                            <ion-col size=\"auto\" *ngFor=\"let archdesign of design.architecturaldesign;let i=index\">\r\n                                <span class=\"model-name font\" (click)=\"showurl(i,'architecturaldesign')\" style=\"color:#3c78d8 !important\">{{archdesign?.name}}{{archdesign?.ext}}</span>\r\n                            </ion-col>\r\n                        </ng-container>\r\n                    </ion-row>\r\n                    <ion-row>\r\n                        <ion-col><span class=\"model-type font\">project type</span></ion-col>\r\n                        <ion-col size=\"auto\">\r\n                            <span class=\"model-name font\">{{design?.projecttype}}</span>\r\n                        </ion-col>\r\n                    </ion-row>\r\n                    <ion-row>\r\n                        <!-- <ion-col><span class=\"model-type\">job type</span></ion-col>\r\n                        <ion-col size=\"auto\">\r\n                            <span class=\"model-name\">{{design.jobtype}}</span>\r\n                        </ion-col> -->\r\n                    </ion-row>\r\n                    <ion-row>\r\n                        <ion-col><span class=\"model-type font\">Mounting Type</span></ion-col>\r\n                        <ion-col size=\"auto\">\r\n                            <span class=\"model-name font\">{{design?.mountingtype}}</span>\r\n                        </ion-col>\r\n                    </ion-row>\r\n                    <ion-row *ngIf=\"design.mountingtype == 'roof' || design.mountingtype =='both'\">\r\n                        <ion-col><span class=\"model-type font\">roof type</span></ion-col>\r\n                        <ion-col size=\"auto\">\r\n                            <span class=\"model-name font\">{{design?.rooftype}}</span>\r\n                        </ion-col>\r\n                    </ion-row>\r\n                    <ion-row *ngIf=\"design.mountingtype=='ground' || design.mountingtype == 'both'\">\r\n                        <ion-col><span class=\"model-type font\">tilt of ground mounting system</span></ion-col>\r\n                        <ion-col size=\"auto\">\r\n                            <span class=\"model-name font\">{{design?.tiltofgroundmountingsystem}}</span>\r\n                        </ion-col>\r\n                    </ion-row>\r\n                </ion-grid>\r\n            </ion-col>\r\n        </ion-row>\r\n\r\n        <ion-row *ngIf=\"design.comments || design.comments !==null  \" class=\"ion-no-padding ion-margin-top\">\r\n            <ion-col size=\"6\">\r\n                <span class=\"models font\">comments</span>\r\n            </ion-col>\r\n            <!-- <div> -->\r\n\r\n            <ion-col size=\"6\"  class=\"ion-no-padding\">\r\n                <div *ngFor=\"let comment of design.comments\">\r\n                    <p class=\"comment font\" style=\"text-align: right;margin:0px\">{{comment?.message}}</p>\r\n                    <p class=\"comment-by\" style=\"text-align: right;margin-top:0px\">Posted by {{comment.createdby?.firstname}}\r\n                        {{comment.createdby?.lastname}}</p>\r\n                </div>\r\n            </ion-col>\r\n            <!-- <ion-col size=\"12\" class=\"ion-no-padding ion-text-end\">\r\n                         \r\n                        </ion-col> -->\r\n\r\n            <!-- </div> -->\r\n\r\n        </ion-row>\r\n\r\n        <ion-row>\r\n            <ion-col><span class=\"model-type font\">created at</span></ion-col>\r\n            <ion-col size=\"auto\">\r\n                <span class=\"model-name font\">{{design.created_at | date: 'dd/MM/yyyy hh:mm a'}}</span>\r\n            </ion-col>\r\n        </ion-row>\r\n        <div *ngIf=\"user.role.type=='designer'  || user.role.type=='qcinspector' || (user.role.type=='clientsuperadmin' && design.status=='delivered')\">\r\n            <form novalidate [formGroup]=\"commentsForm\">\r\n\r\n            <ion-row *ngIf=\"(design.status=='designassigned' || design.status=='reviewfailed'); else showimageName \">\r\n                <!-- <span> -->\r\n\r\n                        <ion-col size=\"3\" class=\"model-type font\">\r\n                           Prelim Design\r\n                        </ion-col>\r\n                            <ion-col size=\"9\"  class=\"model-name font flx\" style=\"justify-content: flex-end;\">\r\n                             \r\n\r\n                                    <input type=\"file\" *ngIf=\"imageName.length==0\"  (change)=\"prelimfiles($event)\" formControlName=\"prelimdesign\" style=\"width: 76px;\"/>\r\n                                   {{imageName}}\r\n                                \r\n                                <!-- <ion-icon name=\"close-circle-outline\" *ngIf=\"imageName.length>0 && !imagebox\" (click)=\"showuploadbox()\" style=\"color:red;font-size: 20px;margin-left: 10px\"></ion-icon> -->\r\n                                <!-- <ion-icon name=\"cloud-upload-outline\" *ngIf=\"imageName.length>0 && imagebox\" (click)=\"uploadpreliumdesign(designId,'prelimdesign')\" style=\"font-size: 20px;margin-left: 10px;color:green\"></ion-icon> -->\r\n                                \r\n                            </ion-col>\r\n                            \r\n                        <!-- </span> -->\r\n                    </ion-row>\r\n                    <div *ngIf=\"user.role.type=='qcinspector' && design.status=='reviewassigned'\">\r\n                        <ion-row *ngIf=\"isSelfUpdate\" style=\"width: max-content;\">\r\n                             <!-- <span> -->\r\n                                         <ion-col size=\"9\" class=\"model-name font flx\" style=\"justify-content: flex-end;\">\r\n                                          \r\n             \r\n                                             <ion-input type=\"file\" readonly (change)=\"prelimfiles($event)\" formControlName=\"prelimdesign\" style=\"border-bottom:1px solid grey; width: max-content; flex: auto;\" multiple=\"false\"> <ion-icon name=\"attach-outline\" style=\"float: right;text-align:right ;\"></ion-icon></ion-input>\r\n                                         \r\n                                                \r\n                                             \r\n                                             <!-- <ion-icon name=\"close-circle-outline\" *ngIf=\"imageName.length>0 && !imagebox\" (click)=\"showuploadbox()\" style=\"color:red;font-size: 20px;margin-left: 10px\"></ion-icon> -->\r\n                                             <!-- <ion-icon name=\"cloud-upload-outline\" *ngIf=\"imageName.length>0 && imagebox\" (click)=\"uploadpreliumdesign(designId,'prelimdesign')\" style=\"font-size: 20px;margin-left: 10px;color:green\"></ion-icon> -->\r\n                                             \r\n                                         </ion-col>\r\n                                         \r\n                                     <!-- </span> --> \r\n                                 </ion-row>\r\n                             </div>\r\n                </form>\r\n            <ng-template #showimageName >\r\n                <ion-col><span class=\"model-type font\">Prelim Design</span></ion-col>\r\n                <ion-button size=\"3\" style=\"width:72px;height: 20px;font-size: x-small;float: right;\" *ngIf=\"user.role.type=='qcinspector' && design.status=='reviewassigned'\" (click)=\"isSelfUpdate = !isSelfUpdate\">Self Update</ion-button>\r\n                <ion-col size=\"auto\"  style=\"float: right;\">\r\n                    <span class=\"model-name font\" style=\"text-align:right;\" (click)=\"showDesignImage()\">{{imageName}}</span>\r\n                        <!-- <ion-icon name=\"close-circle-outline\" *ngIf=\"imageName.length>0 \" (click)=\"showuploadbox()\" style=\"color:red;font-size: 20px;margin-left: 10px\"></ion-icon> -->\r\n                </ion-col>\r\n            </ng-template>\r\n        </div>\r\n\r\n        <ion-row class=\"ion-no-padding ion-margin-top ion-justify-content-center ion-align-items-center\"\r\n        *ngIf=\"assigned\">\r\n        <ion-col class=\"ion-justify-content-center ion-align-items-center\"><span class=\"model-type font\">assigned\r\n                to</span></ion-col>\r\n        <ion-col size=\"auto\">\r\n            <div class=\"selected d-flex\">\r\n                <img *ngIf=\"design.designassignedto.contractorlogo && design.designassignedto.contractorlogo.logo\"\r\n                    [src]=\"design.designassignedto.contractorlogo.logo.url\" class=\"assignee-image\" />\r\n                <div *ngIf=\"!design.designassignedto.contractorlogo || !design.designassignedto.contractorlogo.logo\"\r\n                    class=\"assignee-image d-flex flex-row align-center justify-center\">\r\n                    <div class=\"name_div\">\r\n                        <span\r\n                            style=\"text-transform: capitalize;\">{{design.designassignedto.firstname.substring(0, 1)}}{{design.designassignedto.lastname.substring(0, 1)}}</span>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </ion-col>\r\n    </ion-row>\r\n\r\n\r\n        <ion-row class=\"ion-no-padding ion-margin-top\" *ngIf=\"design && design.type !=='design'\">\r\n            <ion-col size=\"12\">\r\n                <form novalidate [formGroup]=\"assigneeForm\">\r\n                    <ion-item class=\"ion-no-padding no-border\" lines=\"none\">\r\n                        <app-user-selector placeholder=\"assign\" [assignees]=\"listOfAssignees\"\r\n                            formControlName=\"designassignedto\"></app-user-selector>\r\n                    </ion-item>\r\n                </form>\r\n            </ion-col>\r\n        </ion-row>\r\n        <ion-row class=\"ion-no-padding ion-margin-top\" *ngIf=\"user.role.type=='designer' && design && design.status =='designassigned'\">\r\n\r\n            <form novalidate [formGroup]=\"commentsForm\" style=\"width:100%\">\r\n                <ion-col size=\"12\">\r\n                    <span class=\"input-placeholder\">comments</span>\r\n                </ion-col>\r\n                <ion-col size=\"12\" style=\"padding-top: 0px;\">\r\n                    <ion-textarea style=\"max-width: 98%;\" class=\"ion-no-margin ion-no-padding comment_box\" rows=\"3\"\r\n                                  formControlName=\"comments\"></ion-textarea>\r\n                </ion-col>\r\n                </form>\r\n        </ion-row>\r\n\r\n        <!-- For Analyst -->\r\n        <ion-row class=\"ion-no-padding ion-margin-top\" *ngIf=\"user.role.type=='qcinspector' && design && design.status =='reviewassigned'\">\r\n\r\n            <form  [formGroup]=\"reviewIssuesForm\" style=\"width:100%\">\r\n                \r\n                    <ion-col size=\"12\" class=\"ion-no-padding\">\r\n                        <span class=\"input-placeholder\">Issues*</span>\r\n                    </ion-col>\r\n                    <ion-col size=\"12\" class=\"ion-no-padding\">\r\n                        <ion-textarea class=\"ion-no-margin ion-no-padding comment_box\" rows=\"3\"\r\n                                      formControlName=\"reviewIssues\" ></ion-textarea>\r\n                    </ion-col>\r\n                \r\n                </form>\r\n        </ion-row>\r\n    </ion-grid>\r\n</ion-content>\r\n\r\n<ion-footer *ngIf=\"design && design.type !=='design'\" class=\"ion-no-border white-bg\">\r\n    <ion-grid>\r\n        <ion-row class=\"ion-text-end ion-align-items-end ion-justify-content-end\">\r\n            <ion-col size=\"auto\">\r\n                <ion-button class=\"action-button-color\" fill=\"clear\" (click)=\"updateAssignee()\">Save</ion-button>\r\n            </ion-col>\r\n        </ion-row>\r\n    </ion-grid>\r\n\r\n</ion-footer>\r\n<ion-footer *ngIf=\"user.role.type=='designer' && design && design.status=='designassigned'\" class=\"ion-no-border white-bg\">\r\n    <ion-grid>\r\n        <ion-row class=\"ion-text-end ion-align-items-end ion-justify-content-end\">\r\n            <ion-col size=\"auto\">\r\n                <ion-button class=\"action-button-color\" fill=\"clear\" (click)=\"updatecomments()\">Submit</ion-button>\r\n            </ion-col>\r\n        </ion-row>\r\n    </ion-grid>\r\n\r\n</ion-footer>\r\n<ion-footer *ngIf=\"(user.role.type=='qcinspector' && design && design.status=='reviewassigned') \" class=\"ion-no-border white-bg\">\r\n    <ion-grid>\r\n        <ion-row class=\"ion-text-end ion-align-items-end ion-justify-content-end\">\r\n            <ion-col size=\"auto\">\r\n                <ion-button class=\"action-button-color\" fill=\"clear\" style=\"float: left;\" (click)=\"reportDesignReviewFailure()\">Failed</ion-button>\r\n                <ion-button class=\"action-button-color\" fill=\"clear\" style=\"float: right ;\" (click)=\"designReviewSuccess()\">Passed</ion-button>\r\n            </ion-col>\r\n        </ion-row>\r\n    </ion-grid>\r\n\r\n</ion-footer>\r\n\r\n\r\n");

/***/ }),

/***/ "./src/app/design-details/design-details-routing.module.ts":
/*!*****************************************************************!*\
  !*** ./src/app/design-details/design-details-routing.module.ts ***!
  \*****************************************************************/
/*! exports provided: DesignDetailsPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DesignDetailsPageRoutingModule", function() { return DesignDetailsPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _design_details_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./design-details.page */ "./src/app/design-details/design-details.page.ts");




const routes = [
    {
        path: '',
        component: _design_details_page__WEBPACK_IMPORTED_MODULE_3__["DesignDetailsPage"]
    }
];
let DesignDetailsPageRoutingModule = class DesignDetailsPageRoutingModule {
};
DesignDetailsPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], DesignDetailsPageRoutingModule);



/***/ }),

/***/ "./src/app/design-details/design-details.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/design-details/design-details.module.ts ***!
  \*********************************************************/
/*! exports provided: DesignDetailsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DesignDetailsPageModule", function() { return DesignDetailsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _design_details_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./design-details-routing.module */ "./src/app/design-details/design-details-routing.module.ts");
/* harmony import */ var _design_details_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./design-details.page */ "./src/app/design-details/design-details.page.ts");
/* harmony import */ var _utilities_utilities_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../utilities/utilities.module */ "./src/app/utilities/utilities.module.ts");
/* harmony import */ var _ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic-native/launch-navigator/ngx */ "./node_modules/@ionic-native/launch-navigator/ngx/index.js");
/* harmony import */ var ngx_timer__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ngx-timer */ "./node_modules/ngx-timer/fesm2015/ngx-timer.js");










let DesignDetailsPageModule = class DesignDetailsPageModule {
};
DesignDetailsPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _design_details_routing_module__WEBPACK_IMPORTED_MODULE_5__["DesignDetailsPageRoutingModule"],
            _utilities_utilities_module__WEBPACK_IMPORTED_MODULE_7__["UtilitiesModule"],
            ngx_timer__WEBPACK_IMPORTED_MODULE_9__["NgxTimerModule"]
        ],
        declarations: [_design_details_page__WEBPACK_IMPORTED_MODULE_6__["DesignDetailsPage"]],
        providers: [
            _ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_8__["LaunchNavigator"]
        ]
    })
], DesignDetailsPageModule);



/***/ }),

/***/ "./src/app/design-details/design-details.page.scss":
/*!*********************************************************!*\
  !*** ./src/app/design-details/design-details.page.scss ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".survey-email {\n  font-size: 0.8em;\n}\n\n.survey-name {\n  font-size: 1.7em;\n}\n\n.survey-phone {\n  font-size: 0.8em;\n}\n\nion-header {\n  color: #666666;\n}\n\n.page-text-color {\n  color: #666666 !important;\n}\n\n.image-count {\n  width: 48px;\n  height: 48px;\n}\n\n.data-header {\n  font-size: 0.9em;\n  color: #BFBFBF;\n}\n\n.data-point {\n  font-size: 1em;\n  color: black;\n}\n\n.address {\n  color: #3a7be0;\n}\n\n.models {\n  font-size: 18px;\n  color: #B6B6B6;\n}\n\n.model-type {\n  font-size: 18px;\n  color: #B6B6B6;\n}\n\n.model-name {\n  font-size: 15px;\n  text-transform: capitalize;\n}\n\n.comment {\n  font-size: 18px;\n}\n\n.comment-by {\n  font-size: 10px;\n  font-style: italic;\n  color: #666666 !important;\n}\n\n.assignee-image {\n  width: 3.5em;\n  height: 3.5em;\n  border-radius: 50%;\n  -o-object-fit: fill;\n     object-fit: fill;\n  border: 2px solid white;\n  padding: 8px;\n  text-align: center;\n  background: #FFF1CF;\n}\n\n.assignee-margin {\n  margin: 8px;\n  text-align: center;\n}\n\n.selected {\n  border: 3px solid #3c78d8;\n  border-radius: 50%;\n}\n\n.normal {\n  border: 3px solid white;\n}\n\ndiv[scrollx=true], div[scrolly=true] {\n  position: relative;\n  overflow: hidden;\n}\n\ndiv[scrollx=true] ::-webkit-scrollbar, div[scrolly=true] ::-webkit-scrollbar {\n  display: none;\n}\n\ndiv[scrollx=true] {\n  overflow-x: auto;\n}\n\ndiv[scrolly=true] {\n  overflow-y: auto;\n}\n\n.name_div {\n  font-size: 20px;\n}\n\n.font {\n  font-size: 0.7rem;\n}\n\n.flx {\n  display: flex;\n  align-items: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZGVzaWduLWRldGFpbHMvRjpcXG1vYmlsZWFwcC9zcmNcXGFwcFxcZGVzaWduLWRldGFpbHNcXGRlc2lnbi1kZXRhaWxzLnBhZ2Uuc2NzcyIsInNyYy9hcHAvZGVzaWduLWRldGFpbHMvZGVzaWduLWRldGFpbHMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsZ0JBQUE7QUNDRjs7QURFQTtFQUNFLGdCQUFBO0FDQ0Y7O0FERUE7RUFDRSxnQkFBQTtBQ0NGOztBREVBO0VBQ0UsY0FBQTtBQ0NGOztBREVBO0VBQ0UseUJBQUE7QUNDRjs7QURJQTtFQUNFLFdBQUE7RUFDQSxZQUFBO0FDREY7O0FESUE7RUFDRSxnQkFBQTtFQUNBLGNBQUE7QUNERjs7QURJQTtFQUNFLGNBQUE7RUFDQSxZQUFBO0FDREY7O0FESUE7RUFDRSxjQUFBO0FDREY7O0FESUE7RUFDRSxlQUFBO0VBQ0EsY0FBQTtBQ0RGOztBRElBO0VBQ0UsZUFBQTtFQUNBLGNBQUE7QUNERjs7QURJQTtFQUNFLGVBQUE7RUFDQSwwQkFBQTtBQ0RGOztBRElBO0VBQ0UsZUFBQTtBQ0RGOztBRElBO0VBQ0UsZUFBQTtFQUNBLGtCQUFBO0VBQ0EseUJBQUE7QUNERjs7QURJQTtFQUNFLFlBQUE7RUFDQSxhQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtLQUFBLGdCQUFBO0VBQ0EsdUJBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtBQ0RGOztBRElBO0VBQ0UsV0FBQTtFQUNBLGtCQUFBO0FDREY7O0FESUE7RUFDRSx5QkFBQTtFQUNBLGtCQUFBO0FDREY7O0FESUE7RUFDRSx1QkFBQTtBQ0RGOztBRElBO0VBQ0Usa0JBQUE7RUFDQSxnQkFBQTtBQ0RGOztBREdFO0VBQ0UsYUFBQTtBQ0RKOztBREtBO0VBQ0UsZ0JBQUE7QUNGRjs7QURLQTtFQUNFLGdCQUFBO0FDRkY7O0FES0E7RUFDRSxlQUFBO0FDRkY7O0FES0E7RUFDQSxpQkFBQTtBQ0ZBOztBREtBO0VBQ0UsYUFBQTtFQUNBLG1CQUFBO0FDRkYiLCJmaWxlIjoic3JjL2FwcC9kZXNpZ24tZGV0YWlscy9kZXNpZ24tZGV0YWlscy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuc3VydmV5LWVtYWlsIHtcclxuICBmb250LXNpemU6IDAuOGVtO1xyXG59XHJcblxyXG4uc3VydmV5LW5hbWUge1xyXG4gIGZvbnQtc2l6ZTogMS43ZW07XHJcbn1cclxuXHJcbi5zdXJ2ZXktcGhvbmUge1xyXG4gIGZvbnQtc2l6ZTogMC44ZW07XHJcbn1cclxuXHJcbmlvbi1oZWFkZXIge1xyXG4gIGNvbG9yOiAjNjY2NjY2O1xyXG59XHJcblxyXG4ucGFnZS10ZXh0LWNvbG9yIHtcclxuICBjb2xvcjogIzY2NjY2NiAhaW1wb3J0YW50OztcclxufVxyXG5cclxuXHJcblxyXG4uaW1hZ2UtY291bnQge1xyXG4gIHdpZHRoOiA0OHB4O1xyXG4gIGhlaWdodDogNDhweDtcclxufVxyXG5cclxuLmRhdGEtaGVhZGVyIHtcclxuICBmb250LXNpemU6IDAuOWVtO1xyXG4gIGNvbG9yOiAjQkZCRkJGO1xyXG59XHJcblxyXG4uZGF0YS1wb2ludCB7XHJcbiAgZm9udC1zaXplOiAxZW07XHJcbiAgY29sb3I6IGJsYWNrO1xyXG59XHJcblxyXG4uYWRkcmVzcyB7XHJcbiAgY29sb3I6ICMzYTdiZTA7XHJcbn1cclxuXHJcbi5tb2RlbHMge1xyXG4gIGZvbnQtc2l6ZTogMThweDtcclxuICBjb2xvcjogI0I2QjZCNjtcclxufVxyXG5cclxuLm1vZGVsLXR5cGUge1xyXG4gIGZvbnQtc2l6ZTogMThweDtcclxuICBjb2xvcjogI0I2QjZCNjtcclxufVxyXG5cclxuLm1vZGVsLW5hbWUge1xyXG4gIGZvbnQtc2l6ZTogMTVweDtcclxuICB0ZXh0LXRyYW5zZm9ybTogY2FwaXRhbGl6ZTtcclxufVxyXG5cclxuLmNvbW1lbnQge1xyXG4gIGZvbnQtc2l6ZTogMThweDtcclxufVxyXG5cclxuLmNvbW1lbnQtYnkge1xyXG4gIGZvbnQtc2l6ZTogMTBweDtcclxuICBmb250LXN0eWxlOiBpdGFsaWM7XHJcbiAgY29sb3I6ICM2NjY2NjYgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmFzc2lnbmVlLWltYWdlIHtcclxuICB3aWR0aDogMy41ZW07XHJcbiAgaGVpZ2h0OiAzLjVlbTtcclxuICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgb2JqZWN0LWZpdDogZmlsbDtcclxuICBib3JkZXI6IDJweCBzb2xpZCB3aGl0ZTtcclxuICBwYWRkaW5nOiA4cHg7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIGJhY2tncm91bmQ6ICNGRkYxQ0Y7XHJcbn1cclxuXHJcbi5hc3NpZ25lZS1tYXJnaW4ge1xyXG4gIG1hcmdpbjogOHB4O1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxufVxyXG5cclxuLnNlbGVjdGVkIHtcclxuICBib3JkZXI6IDNweCBzb2xpZCAjM2M3OGQ4O1xyXG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcclxufVxyXG5cclxuLm5vcm1hbCB7XHJcbiAgYm9yZGVyOiAzcHggc29saWQgd2hpdGU7XHJcbn1cclxuXHJcbmRpdltzY3JvbGx4PXRydWVdLCBkaXZbc2Nyb2xseT10cnVlXSB7XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIG92ZXJmbG93OiBoaWRkZW47XHJcblxyXG4gIDo6LXdlYmtpdC1zY3JvbGxiYXIge1xyXG4gICAgZGlzcGxheTogbm9uZTtcclxuICB9XHJcbn1cclxuXHJcbmRpdltzY3JvbGx4PXRydWVdIHtcclxuICBvdmVyZmxvdy14OiBhdXRvO1xyXG59XHJcblxyXG5kaXZbc2Nyb2xseT10cnVlXSB7XHJcbiAgb3ZlcmZsb3cteTogYXV0bztcclxufVxyXG5cclxuLm5hbWVfZGl2e1xyXG4gIGZvbnQtc2l6ZTogMjBweDtcclxufVxyXG5cclxuLmZvbnR7XHJcbmZvbnQtc2l6ZTogLjdyZW07XHJcbn1cclxuXHJcbi5mbHh7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG59XHJcblxyXG5cclxuXHJcblxyXG5cclxuIiwiLnN1cnZleS1lbWFpbCB7XG4gIGZvbnQtc2l6ZTogMC44ZW07XG59XG5cbi5zdXJ2ZXktbmFtZSB7XG4gIGZvbnQtc2l6ZTogMS43ZW07XG59XG5cbi5zdXJ2ZXktcGhvbmUge1xuICBmb250LXNpemU6IDAuOGVtO1xufVxuXG5pb24taGVhZGVyIHtcbiAgY29sb3I6ICM2NjY2NjY7XG59XG5cbi5wYWdlLXRleHQtY29sb3Ige1xuICBjb2xvcjogIzY2NjY2NiAhaW1wb3J0YW50O1xufVxuXG4uaW1hZ2UtY291bnQge1xuICB3aWR0aDogNDhweDtcbiAgaGVpZ2h0OiA0OHB4O1xufVxuXG4uZGF0YS1oZWFkZXIge1xuICBmb250LXNpemU6IDAuOWVtO1xuICBjb2xvcjogI0JGQkZCRjtcbn1cblxuLmRhdGEtcG9pbnQge1xuICBmb250LXNpemU6IDFlbTtcbiAgY29sb3I6IGJsYWNrO1xufVxuXG4uYWRkcmVzcyB7XG4gIGNvbG9yOiAjM2E3YmUwO1xufVxuXG4ubW9kZWxzIHtcbiAgZm9udC1zaXplOiAxOHB4O1xuICBjb2xvcjogI0I2QjZCNjtcbn1cblxuLm1vZGVsLXR5cGUge1xuICBmb250LXNpemU6IDE4cHg7XG4gIGNvbG9yOiAjQjZCNkI2O1xufVxuXG4ubW9kZWwtbmFtZSB7XG4gIGZvbnQtc2l6ZTogMTVweDtcbiAgdGV4dC10cmFuc2Zvcm06IGNhcGl0YWxpemU7XG59XG5cbi5jb21tZW50IHtcbiAgZm9udC1zaXplOiAxOHB4O1xufVxuXG4uY29tbWVudC1ieSB7XG4gIGZvbnQtc2l6ZTogMTBweDtcbiAgZm9udC1zdHlsZTogaXRhbGljO1xuICBjb2xvcjogIzY2NjY2NiAhaW1wb3J0YW50O1xufVxuXG4uYXNzaWduZWUtaW1hZ2Uge1xuICB3aWR0aDogMy41ZW07XG4gIGhlaWdodDogMy41ZW07XG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgb2JqZWN0LWZpdDogZmlsbDtcbiAgYm9yZGVyOiAycHggc29saWQgd2hpdGU7XG4gIHBhZGRpbmc6IDhweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBiYWNrZ3JvdW5kOiAjRkZGMUNGO1xufVxuXG4uYXNzaWduZWUtbWFyZ2luIHtcbiAgbWFyZ2luOiA4cHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxuLnNlbGVjdGVkIHtcbiAgYm9yZGVyOiAzcHggc29saWQgIzNjNzhkODtcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xufVxuXG4ubm9ybWFsIHtcbiAgYm9yZGVyOiAzcHggc29saWQgd2hpdGU7XG59XG5cbmRpdltzY3JvbGx4PXRydWVdLCBkaXZbc2Nyb2xseT10cnVlXSB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbn1cbmRpdltzY3JvbGx4PXRydWVdIDo6LXdlYmtpdC1zY3JvbGxiYXIsIGRpdltzY3JvbGx5PXRydWVdIDo6LXdlYmtpdC1zY3JvbGxiYXIge1xuICBkaXNwbGF5OiBub25lO1xufVxuXG5kaXZbc2Nyb2xseD10cnVlXSB7XG4gIG92ZXJmbG93LXg6IGF1dG87XG59XG5cbmRpdltzY3JvbGx5PXRydWVdIHtcbiAgb3ZlcmZsb3cteTogYXV0bztcbn1cblxuLm5hbWVfZGl2IHtcbiAgZm9udC1zaXplOiAyMHB4O1xufVxuXG4uZm9udCB7XG4gIGZvbnQtc2l6ZTogMC43cmVtO1xufVxuXG4uZmx4IHtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/design-details/design-details.page.ts":
/*!*******************************************************!*\
  !*** ./src/app/design-details/design-details.page.ts ***!
  \*******************************************************/
/*! exports provided: DesignDetailsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DesignDetailsPage", function() { return DesignDetailsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _api_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../api.service */ "./src/app/api.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _utilities_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../utilities.service */ "./src/app/utilities.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _storage_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../storage.service */ "./src/app/storage.service.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic-native/launch-navigator/ngx */ "./node_modules/@ionic-native/launch-navigator/ngx/index.js");
/* harmony import */ var ngx_image_compress__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ngx-image-compress */ "./node_modules/ngx-image-compress/fesm2015/ngx-image-compress.js");
/* harmony import */ var ngx_timer__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ngx-timer */ "./node_modules/ngx-timer/fesm2015/ngx-timer.js");
/* harmony import */ var _ionic_native_in_app_browser_ngx__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic-native/in-app-browser/ngx */ "./node_modules/@ionic-native/in-app-browser/ngx/index.js");












let DesignDetailsPage = class DesignDetailsPage {
    // user: import("j:/wattmonk/mobileapp/src/app/model/user.model").User;
    constructor(utilities, apiService, route, navController, alertController, storage, formBuilder, launchNavigator, toastController, imageCompress, countdownservice, iab, router) {
        this.utilities = utilities;
        this.apiService = apiService;
        this.route = route;
        this.navController = navController;
        this.alertController = alertController;
        this.storage = storage;
        this.formBuilder = formBuilder;
        this.launchNavigator = launchNavigator;
        this.toastController = toastController;
        this.imageCompress = imageCompress;
        this.countdownservice = countdownservice;
        this.iab = iab;
        this.router = router;
        this.assigned = false;
        this.listOfAssignees = [];
        this.refreshDataOnPreviousPage = 0;
        this.imageName = [];
        this.imagebox = false;
        this.reviewIssues = '';
        this.options = {
            start: '',
            app: this.launchNavigator.APP.GOOGLE_MAPS
        };
        this.prelimFiles = [];
        this.b64toBlob = (b64Data, contentType = '', sliceSize = 512) => {
            const byteCharacters = atob(b64Data);
            const byteArrays = [];
            for (let offset = 0; offset < byteCharacters.length; offset += sliceSize) {
                const slice = byteCharacters.slice(offset, offset + sliceSize);
                const byteNumbers = new Array(slice.length);
                for (let i = 0; i < slice.length; i++) {
                    byteNumbers[i] = slice.charCodeAt(i);
                }
                const byteArray = new Uint8Array(byteNumbers);
                byteArrays.push(byteArray);
            }
            const blob = new Blob(byteArrays, { type: contentType });
            return blob;
        };
        this.designId = +this.route.snapshot.paramMap.get('id');
        this.assigneeForm = this.formBuilder.group({
            designassignedto: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required]),
            status: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormControl"]('designassigned'),
        });
        this.commentsForm = this.formBuilder.group({
            comments: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormControl"](''),
            status: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormControl"]('designcompleted'),
            prelimdesign: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormControl"](null, [_angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required])
        });
        this.reviewIssuesForm = this.formBuilder.group({
            reviewIssues: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required])
        });
    }
    ngOnInit() {
        console.log(this.imageName);
        this.user = this.storage.getUser();
        console.log(this.user);
        this.dataSubscription = this.utilities.getDesignDetailsRefresh().subscribe((result) => {
            this.refreshDataOnPreviousPage++;
            this.getDesignDetails();
        });
    }
    showDesignImage() {
        const browser = this.iab.create(this.design.prelimdesign.url, '_system', 'location=yes,hardwareback=yes,hidden=yes');
    }
    showurl(i, value) {
        if (value == 'attachments') {
            this.browser = this.iab.create(this.design.attachments[i].url, '_system', 'location=yes,hardwareback=yes,hidden=yes');
        }
        else {
            this.browser = this.iab.create(this.design.architecturaldesign[i].url, '_system', 'location=yes,hardwareback=yes,hidden=yes');
        }
    }
    updatecomments() {
        if (this.commentsForm.status === 'INVALID') {
            this.utilities.errorSnackBar('Please select prelim design');
            return false;
        }
        else {
            this.utilities.showLoading('Submitting').then(() => {
                this.apiService.updateDesignForm(this.commentsForm.value, this.designId).subscribe((success) => {
                    this.uploadpreliumdesign(this.designId, 'prelimdesign');
                    this.utilities.hideLoading().then(() => {
                        console.log("suc", success);
                        this.setData(success);
                        // this.utilities.showSnackBar('Design request has been assigned to' + " " + success.name + " " +'successfully');
                        // this.utilities.setHomepageDesignRefresh(true);
                        this.utilities.getDesignDetailsRefresh();
                        this.router.navigate(['designoverview/completeddesigns']);
                        // this.navController.navigateRoot(['homepage']);
                    });
                }, (error) => {
                    this.utilities.hideLoading().then(() => {
                        this.utilities.errorSnackBar('Some Error Occurred');
                    });
                });
            });
        }
    }
    timer() {
        //countUpTimerConfigModel
        this.timerConfig = new ngx_timer__WEBPACK_IMPORTED_MODULE_10__["countDownTimerConfigModel"]();
        //custom class
        this.timerConfig.timerClass = 'remainingtimerclass';
        //timer text values  
        this.timerConfig.timerTexts = new ngx_timer__WEBPACK_IMPORTED_MODULE_10__["countDownTimerTexts"]();
        this.timerConfig.timerTexts.hourText = " :"; //default - hh
        this.timerConfig.timerTexts.minuteText = " :"; //default - mm
        this.timerConfig.timerTexts.secondsText = " "; //default - ss
        if (this.design.status == "designassigned") {
            let cdate = new Date(this.design.designstarttime);
            console.log(cdate);
            cdate.setHours(cdate.getHours() + 2);
            this.countdownservice.startTimer(cdate);
        }
        else if (this.design.status == "reviewassigned") {
            let cdate = new Date(this.design.reviewstarttime);
            cdate.setMinutes(cdate.getMinutes() + 15);
            this.countdownservice.startTimer(cdate);
        }
        else if (this.design.status == 'designcompleted') {
            this.countdownservice.stopTimer();
        }
    }
    ngOnDestroy() {
        this.dataSubscription.unsubscribe();
        if (this.refreshDataOnPreviousPage > 1) {
            this.utilities.setHomepageDesignRefresh(true);
        }
    }
    getDesignDetails() {
        this.getAssignees();
        this.utilities.showLoading('Getting Design Details').then((success) => {
            this.apiService.getDesginDetail(this.designId).subscribe((result) => {
                this.utilities.hideLoading();
                console.log('re', result);
                this.setData(result);
                this.timer();
            }, (error) => {
                this.utilities.hideLoading();
            });
        });
    }
    goBack() {
        this.navController.pop();
    }
    editDesign() {
    }
    setData(result) {
        this.design = result;
        console.log(this.design, ">>>>>>>>>>>>>>>>");
        this.imageName = result.prelimdesign == null ? '' : result.prelimdesign.name + result.prelimdesign.ext;
        console.log(this.imageName);
        if (this.design.newconstruction == true) {
            this.design.newconstruction = 'Yes';
        }
        else {
            this.design.newconstruction = 'No';
        }
        this.assigned = this.design.designassignedto !== null && this.design.designassignedto !== undefined;
    }
    deleteDesign() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                header: 'Delete Design',
                message: 'Are you sure you want to delete this design?',
                cssClass: 'my-custom-delete-class',
                buttons: [
                    {
                        text: 'Yes',
                        handler: () => {
                            this.deleteDesignFromServer();
                        }
                    }, {
                        text: 'No'
                    }
                ]
            });
            toast.present();
        });
    }
    deleteDesignFromServer() {
        this.utilities.showLoading('Deleting Design').then((success) => {
            this.apiService.deleteDesign(this.designId).subscribe((result) => {
                console.log('result', result);
                this.utilities.hideLoading().then(() => {
                    this.utilities.showSnackBar('Desgin deleted successfully');
                    this.navController.pop();
                });
            }, (error) => {
                this.utilities.hideLoading().then(() => {
                    this.utilities.errorSnackBar('Some Error Occurred');
                });
            });
        });
    }
    getAssignees() {
        this.apiService.getDesigners().subscribe(assignees => {
            this.listOfAssignees = [];
            assignees.forEach(item => this.listOfAssignees.push(item));
            console.log(this.listOfAssignees);
        });
    }
    updateAssignee() {
        if (this.assigneeForm.status === 'INVALID') {
            this.utilities.errorSnackBar('Please select an assignee');
        }
        else {
            this.utilities.showLoading('Updating').then(() => {
                this.apiService.updateDesignForm(this.assigneeForm.value, this.designId).subscribe((success) => {
                    this.utilities.hideLoading().then(() => {
                        console.log("suc", success);
                        this.setData(success);
                        this.utilities.showSnackBar('Design request has been assigned to' + " " + success.name + " " + 'successfully');
                        this.utilities.setHomepageDesignRefresh(true);
                        this.navController.navigateRoot(['homepage']);
                    });
                }, (error) => {
                    this.utilities.hideLoading().then(() => {
                        this.utilities.errorSnackBar('Some Error Occurred');
                    });
                });
            });
        }
    }
    openAddressOnMap(address) {
        this.launchNavigator.navigate(address, this.options);
    }
    showuploadbox() {
        // console.log(this.design.prelimdesign.id);
        this.apiService.deletePrelimImage(this.design.prelimdesign.id).subscribe(_res => { });
        console.log(this.imageName);
        this.imageName = [];
    }
    prelimfiles(event) {
        console.log(this.imageName);
        console.log(event.target.files);
        // for(var i=0; i< event.target.files.length;i++){
        // this.prelimFiles.push(event.target.files) 
        this.prelimFiles = event.target.files;
        this.imageName = event.target.files[0].name;
        this.imagebox = true;
        // }
        console.log(this.prelimFiles);
        this.targetLength = event.target.files.length;
        var reader = new FileReader();
        reader.onload = (event) => {
            var orientation = -1;
            let localUrl = event.target.result;
            // this.imageCompress.compressFile(localUrl,orientation, 1000, 1000).then(res=>{
            // console.log(res,">><><><");
            // this.image= res;  
            this.imageCompress.compressFile(localUrl, orientation, 500, 500).then(result => {
                this.image = result;
                console.warn('Size in bytes is now:', this.imageCompress.byteCount(result));
            });
            // })
        };
        reader.readAsDataURL(event.target.files[0]);
    }
    uploadpreliumdesign(designId, key) {
        // else{
        // const blob = this.utilities.getBlobFromImageData(this.prelimFiles);
        // console.log(blob);
        //  let blob= this.utilities.b64toBlob(this.image);
        //   console.log(blob);
        // console.log(typeof(this.prelimFiles[0]));
        const imageData = new FormData();
        for (var i = 0; i < this.prelimFiles.length; i++) {
            imageData.append("files", this.prelimFiles[i]);
            // if(i ==0){
            imageData.append('path', 'design/' + designId);
            imageData.append('refId', designId + '');
            imageData.append('ref', 'design');
            imageData.append('field', key);
            // }
        }
        this.apiService.uploaddesign(imageData).subscribe(res => {
            this.utilities.hideLoading().then(() => {
                console.log(res);
                this.imagebox = false;
                // this.getDesignDetails();
                // this.updatecomments();
                // this.apiService.updateDesignForm({"status":'designcompleted'},this.designId).subscribe((res)=>{
                //   this.utilities.getDesignDetailsRefresh();
                //   console.log(res,">>");
                // })
            });
        }, err => {
            this.utilities.hideLoading().then(() => {
                console.log(err);
            });
        });
        // })
        // }
    }
    reportDesignReviewFailure() {
        //console.log("Value is" + this.reviewIssuesForm.value);
        if (this.reviewIssuesForm.valid) {
            this.countdownservice.stopTimer();
            let cdate = Date.now();
            this.reviewenddatetime = cdate;
            const postData = {
                status: "reviewfailed",
                reviewissues: this.reviewIssuesForm.get('reviewIssues').value,
                reviewstarttime: this.reviewstartdatetime,
                reviewendtime: this.reviewenddatetime,
            };
            console.log("this is" + this.design.reviewstarttime);
            // console.log("this is"+ this.reviewstartdatetime);
            this.apiService.editDesign(this.design.id, postData)
                .subscribe(response => {
                this.utilities.showSnackBar("Prelim design status has been updated successfully.");
                this.utilities.setHomepageDesignRefresh(true);
                this.navController.navigateRoot(['analystoverview/design']);
                //this.data.triggerEditEvent = false;
                //this.dialogRef.close(this.data);
            }, error => {
                this.utilities.errorSnackBar("Error");
            });
        }
        else {
            this.utilities.errorSnackBar("Please enter issues");
            this.reviewIssuesForm.markAsTouched();
            this.reviewIssuesForm.markAsDirty();
        }
    }
    designReviewSuccess() {
        if (this.isSelfUpdate && this.prelimFiles.length > 0) {
            this.uploadpreliumdesign(this.designId, 'prelimdesign');
            this.reportDesignReviewSuccess();
        }
        else if (this.isSelfUpdate && this.prelimFiles.length == 0) {
            this.utilities.errorSnackBar("error");
        }
        else {
            this.reportDesignReviewSuccess();
        }
    }
    reportDesignReviewSuccess() {
        this.countdownservice.stopTimer();
        let cdate = Date.now();
        this.reviewenddatetime = cdate;
        const postData = {
            status: "reviewpassed",
            reviewIssues: this.reviewIssuesForm.get('reviewIssues').value,
            reviewstarttime: this.reviewstartdatetime,
            reviewendtime: this.reviewenddatetime
        };
        this.apiService
            .editDesign(this.design.id, postData)
            .subscribe(response => {
            this.utilities.showSnackBar("Prelim design status has been updated successfully.");
            this.utilities.setHomepageDesignRefresh(true);
            this.navController.navigateRoot(['analystoverview/design']);
            // this.triggerEditEvent = false;
            //this.dialogRef.close(this.data);
        }, error => {
            this.utilities.errorSnackBar("Error");
        });
    }
};
DesignDetailsPage.ctorParameters = () => [
    { type: _utilities_service__WEBPACK_IMPORTED_MODULE_4__["UtilitiesService"] },
    { type: _api_service__WEBPACK_IMPORTED_MODULE_2__["ApiService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"] },
    { type: _storage_service__WEBPACK_IMPORTED_MODULE_6__["StorageService"] },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormBuilder"] },
    { type: _ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_8__["LaunchNavigator"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ToastController"] },
    { type: ngx_image_compress__WEBPACK_IMPORTED_MODULE_9__["NgxImageCompressService"] },
    { type: ngx_timer__WEBPACK_IMPORTED_MODULE_10__["CountdownTimerService"] },
    { type: _ionic_native_in_app_browser_ngx__WEBPACK_IMPORTED_MODULE_11__["InAppBrowser"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] }
];
DesignDetailsPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-design-details',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./design-details.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/design-details/design-details.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./design-details.page.scss */ "./src/app/design-details/design-details.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_utilities_service__WEBPACK_IMPORTED_MODULE_4__["UtilitiesService"],
        _api_service__WEBPACK_IMPORTED_MODULE_2__["ApiService"],
        _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"],
        _storage_service__WEBPACK_IMPORTED_MODULE_6__["StorageService"],
        _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormBuilder"],
        _ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_8__["LaunchNavigator"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ToastController"],
        ngx_image_compress__WEBPACK_IMPORTED_MODULE_9__["NgxImageCompressService"],
        ngx_timer__WEBPACK_IMPORTED_MODULE_10__["CountdownTimerService"],
        _ionic_native_in_app_browser_ngx__WEBPACK_IMPORTED_MODULE_11__["InAppBrowser"],
        _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"]])
], DesignDetailsPage);



/***/ })

}]);
//# sourceMappingURL=design-details-design-details-module-es2015.js.map