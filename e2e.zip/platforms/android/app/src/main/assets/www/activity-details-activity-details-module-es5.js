function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["activity-details-activity-details-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/activity-details/activity-details.page.html":
  /*!***************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/activity-details/activity-details.page.html ***!
    \***************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppActivityDetailsActivityDetailsPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header  class=\"ion-no-border white-bg\">\r\n  <ion-toolbar>\r\n    <ion-title></ion-title>\r\n    <ion-grid class=\"ion-padding-top ion-padding-start ion-padding-end header-bg\">\r\n      <ion-row  >\r\n    <ion-col size=\"1\">\r\n    <ion-button fill=\"clear\" size=\"small\" class=\"ion-no-padding\" (click)=\"goBack()\">\r\n        <ion-img src=\"/assets/images/back.svg\" class=\"action-icon\"></ion-img>\r\n    </ion-button> \r\n</ion-col>\r\n<ion-col class=\"ion-text-center\" size=\"9\" style=\"padding-left: 27px; text-align: center;\">\r\n  <ion-grid class=\"ion-align-items-center ion-justify-content-center\">\r\n      <ion-row class=\"ion-align-items-center ion-justify-content-center\">\r\n          <span class=\"survey-name ion-text-center\" style=\"font-size:x-large; text-align: center;\">{{activity_details?.name}}</span>\r\n      </ion-row>\r\n     \r\n  </ion-grid>\r\n</ion-col>\r\n\r\n</ion-row>\r\n</ion-grid> <ion-grid class=\"position-relative ion-no-padding\">\r\n  <ion-row class=\"ion-no-padding border-header header-half-height\">\r\n  </ion-row>\r\n  <ion-row class=\"ion-no-padding header-half-height\">\r\n\r\n  </ion-row>\r\n\r\n<ion-row  class=\"ion-no-padding position-absolute header-icon-position full-width\">\r\n<ion-col class=\"flex-center\" *ngIf=\"activity_details?.type=='design'\">\r\n\r\n  <ion-img src=\"/assets/images/blueprint.svg\" class=\"header-icon\"></ion-img>\r\n</ion-col>\r\n<ion-col class=\"flex-center\" *ngIf=\"activity_details?.type=='survey'\">\r\n\r\n  <ion-img src=\"/assets/images/survey.svg\" class=\"header-icon\"></ion-img>\r\n</ion-col></ion-row></ion-grid>\r\n\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content><p style=\"text-align: center; font-size:large; color:black; border:none;margin-bottom:0px ;\"> Activities</p>\r\n <p  style=\"text-align: center; margin-top: 0px;\"><span class=\"chipdetail\" style=\"background-color: rgb(246, 77, 10);\" *ngIf=\"activity_details?.status == 'requestdeclined'\">Declined</span>\r\n <!-- <span class=\"chipdetail\" style=\"background-color: rgb(246, 104, 10);\" >--------{{isDatePassed()}}Overdue</span> -->\r\n <span class=\"chipdetail\" style=\"background-color: rgb(109, 187, 26);\" *ngIf=\"activity_details?.status == 'requestaccepted'\">Accepted</span>\r\n <span class=\"chipdetail\" style=\"background-color: rgb(246, 77, 10);\" *ngIf=\"activity_details?.status == 'reviewfailed'\" >Review Failed</span>\r\n <span class=\"chipdetail\" style=\"background-color: rgb(109, 187, 26);\" *ngIf=\"activity_details?.status == 'reviewpassed'\">Review Passed</span>\r\n <span class=\"chipdetail\" style=\"background-color: rgb(109, 187, 26);\" *ngIf=\"activity_details?.status == 'delivered'\">Delivered</span>\r\n <span class=\"chipdetail\" style=\"background-color: rgb(109, 187, 26);\" *ngIf=\"activity_details?.status == 'designcompleted'\">Completed</span>\r\n <span class=\"chipdetail\" style=\"background-color: #1289A7;;\" *ngIf=\"activity_details?.status == 'created'\">Unassigned</span>\r\n <span class=\"chipdetail\" style=\"background-color: #1289A7;;\" *ngIf=\"activity_details?.status == 'designassigned'\">Design Assigned</span>\r\n <span class=\"chipdetail\" style=\"background-color: #1289A7;;\" *ngIf=\"activity_details?.status == 'reviewassigned'\">In Review</span>\r\n <span class=\"chipdetail\" *ngIf=\"activity_details?.isoutsourced == 'true'\" style=\"background-color: #95AFC0;\" >Waiting for acceptance</span>\r\n <span *ngIf=\"activity_details?.status=='surveyassigned'\" class=\"chipdetail\" style=\"background-color: #3C78D8;\">\r\n  pending\r\n</span>\r\n</p>\r\n  <ion-card  *ngFor=\"let activities of activity_details?.activities\" class=\"custom-card\"  >\r\n  <span style=\"float: left; font-size: smaller;\">{{activities.updated_at | date: 'dd MMM yyyy'}}</span><br><br>\r\n  <span style=\"font-size:medium; float:left; color: black;\">{{activities.activity}}</span><br><br>\r\n<span style=\"float: right !important; font-size: small; font-style: italic;\" *ngIf=\"activities.performer!=null\">{{activities.performer.firstname}} {{activities.performer.lastname}}</span>\r\n\r\n</ion-card>\r\n</ion-content>\r\n";
    /***/
  },

  /***/
  "./src/app/activity-details/activity-details-routing.module.ts":
  /*!*********************************************************************!*\
    !*** ./src/app/activity-details/activity-details-routing.module.ts ***!
    \*********************************************************************/

  /*! exports provided: ActivityDetailsPageRoutingModule */

  /***/
  function srcAppActivityDetailsActivityDetailsRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ActivityDetailsPageRoutingModule", function () {
      return ActivityDetailsPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _activity_details_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./activity-details.page */
    "./src/app/activity-details/activity-details.page.ts");

    var routes = [{
      path: '',
      component: _activity_details_page__WEBPACK_IMPORTED_MODULE_3__["ActivityDetailsPage"]
    }];

    var ActivityDetailsPageRoutingModule = function ActivityDetailsPageRoutingModule() {
      _classCallCheck(this, ActivityDetailsPageRoutingModule);
    };

    ActivityDetailsPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], ActivityDetailsPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/activity-details/activity-details.module.ts":
  /*!*************************************************************!*\
    !*** ./src/app/activity-details/activity-details.module.ts ***!
    \*************************************************************/

  /*! exports provided: ActivityDetailsPageModule */

  /***/
  function srcAppActivityDetailsActivityDetailsModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ActivityDetailsPageModule", function () {
      return ActivityDetailsPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _activity_details_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./activity-details-routing.module */
    "./src/app/activity-details/activity-details-routing.module.ts");
    /* harmony import */


    var _activity_details_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./activity-details.page */
    "./src/app/activity-details/activity-details.page.ts");

    var ActivityDetailsPageModule = function ActivityDetailsPageModule() {
      _classCallCheck(this, ActivityDetailsPageModule);
    };

    ActivityDetailsPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _activity_details_routing_module__WEBPACK_IMPORTED_MODULE_5__["ActivityDetailsPageRoutingModule"]],
      declarations: [_activity_details_page__WEBPACK_IMPORTED_MODULE_6__["ActivityDetailsPage"]],
      providers: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["DatePipe"]]
    })], ActivityDetailsPageModule);
    /***/
  },

  /***/
  "./src/app/activity-details/activity-details.page.scss":
  /*!*************************************************************!*\
    !*** ./src/app/activity-details/activity-details.page.scss ***!
    \*************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppActivityDetailsActivityDetailsPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".chipdetail {\n  display: inline;\n  vertical-align: middle;\n  background-color: #95afc0;\n  font-size: 0.6em;\n  padding: 4px 10px;\n  border-radius: 10px;\n  text-align: center;\n  color: #fff;\n}\n\n.cssclass {\n  --max-height:100% !important;\n}\n\n.custom-card {\n  background: white !important;\n  border-radius: 4px !important;\n  box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.3) !important;\n  padding: 8px 12px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYWN0aXZpdHktZGV0YWlscy9GOlxcbW9iaWxlYXBwL3NyY1xcYXBwXFxhY3Rpdml0eS1kZXRhaWxzXFxhY3Rpdml0eS1kZXRhaWxzLnBhZ2Uuc2NzcyIsInNyYy9hcHAvYWN0aXZpdHktZGV0YWlscy9hY3Rpdml0eS1kZXRhaWxzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGVBQUE7RUFDQSxzQkFBQTtFQUNBLHlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0FDQ0o7O0FEQ0U7RUFDRSw0QkFBQTtBQ0VKOztBREdFO0VBRUUsNEJBQUE7RUFDQSw2QkFBQTtFQUNBLHFEQUFBO0VBQ0EsaUJBQUE7QUNESiIsImZpbGUiOiJzcmMvYXBwL2FjdGl2aXR5LWRldGFpbHMvYWN0aXZpdHktZGV0YWlscy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY2hpcGRldGFpbHtcclxuICAgIGRpc3BsYXk6IGlubGluZTtcclxuICAgIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjOTVhZmMwO1xyXG4gICAgZm9udC1zaXplOiAwLjZlbTtcclxuICAgIHBhZGRpbmc6IDRweCAxMHB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGNvbG9yOiAjZmZmO1xyXG4gIH1cclxuICAuY3NzY2xhc3N7XHJcbiAgICAtLW1heC1oZWlnaHQgOjEwMCUgIWltcG9ydGFudDtcclxuICAgIC8vIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIC8vIGRpc3BsYXk6IGJsb2NrO1xyXG4gIH1cclxuXHJcbiAgLmN1c3RvbS1jYXJkIHtcclxuICAgIFxyXG4gICAgYmFja2dyb3VuZDogd2hpdGUgIWltcG9ydGFudDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDRweCAhaW1wb3J0YW50O1xyXG4gICAgYm94LXNoYWRvdzogMCAxcHggMnB4IDAgcmdiYSgwLCAwLCAwLCAwLjMpICFpbXBvcnRhbnQ7XHJcbiAgICBwYWRkaW5nOiA4cHggMTJweDtcclxuICB9IiwiLmNoaXBkZXRhaWwge1xuICBkaXNwbGF5OiBpbmxpbmU7XG4gIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XG4gIGJhY2tncm91bmQtY29sb3I6ICM5NWFmYzA7XG4gIGZvbnQtc2l6ZTogMC42ZW07XG4gIHBhZGRpbmc6IDRweCAxMHB4O1xuICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGNvbG9yOiAjZmZmO1xufVxuXG4uY3NzY2xhc3Mge1xuICAtLW1heC1oZWlnaHQ6MTAwJSAhaW1wb3J0YW50O1xufVxuXG4uY3VzdG9tLWNhcmQge1xuICBiYWNrZ3JvdW5kOiB3aGl0ZSAhaW1wb3J0YW50O1xuICBib3JkZXItcmFkaXVzOiA0cHggIWltcG9ydGFudDtcbiAgYm94LXNoYWRvdzogMCAxcHggMnB4IDAgcmdiYSgwLCAwLCAwLCAwLjMpICFpbXBvcnRhbnQ7XG4gIHBhZGRpbmc6IDhweCAxMnB4O1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/activity-details/activity-details.page.ts":
  /*!***********************************************************!*\
    !*** ./src/app/activity-details/activity-details.page.ts ***!
    \***********************************************************/

  /*! exports provided: ActivityDetailsPage */

  /***/
  function srcAppActivityDetailsActivityDetailsPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ActivityDetailsPage", function () {
      return ActivityDetailsPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var src_app_api_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! src/app/api.service */
    "./src/app/api.service.ts");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var moment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! moment */
    "./node_modules/moment/moment.js");
    /* harmony import */


    var moment__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_6__);

    var ActivityDetailsPage = /*#__PURE__*/function () {
      function ActivityDetailsPage(apiservice, route, navController, datepipe) {
        var _this = this;

        _classCallCheck(this, ActivityDetailsPage);

        this.apiservice = apiservice;
        this.route = route;
        this.navController = navController;
        this.datepipe = datepipe;
        this.route.paramMap.subscribe(function (params) {
          _this.designId = params.get('id');
          _this.name = params.get('name');
        });
      }

      _createClass(ActivityDetailsPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this2 = this;

          if (this.name == "design") {
            this.apiservice.design_activityDetails(this.designId).subscribe(function (response) {
              _this2.activity_details = response;
              ;
              console.log("inside this", _this2.activity_details);
            });
          }

          if (this.name == "survey") {
            this.apiservice.survey_activityDetails(this.designId).subscribe(function (response) {
              _this2.activity_details = response;
              ;
              console.log("inside this", _this2.activity_details);
            });
          }
        }
      }, {
        key: "goBack",
        value: function goBack() {
          this.navController.pop();
        }
      }, {
        key: "isDatePassed",
        value: function isDatePassed(datestring) {
          var checkdate = moment__WEBPACK_IMPORTED_MODULE_6__(datestring, "YYYYMMDD");
          var todaydate = moment__WEBPACK_IMPORTED_MODULE_6__(new Date(), "YYYYMMDD");
          var lateby = todaydate.diff(checkdate, "days");

          if (lateby > 0) {
            return lateby;
          } else {
            return false;
          }
        }
      }]);

      return ActivityDetailsPage;
    }();

    ActivityDetailsPage.ctorParameters = function () {
      return [{
        type: src_app_api_service__WEBPACK_IMPORTED_MODULE_2__["ApiService"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"]
      }, {
        type: _angular_common__WEBPACK_IMPORTED_MODULE_5__["DatePipe"]
      }];
    };

    ActivityDetailsPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-activity-details',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./activity-details.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/activity-details/activity-details.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./activity-details.page.scss */
      "./src/app/activity-details/activity-details.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_api_service__WEBPACK_IMPORTED_MODULE_2__["ApiService"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"], _angular_common__WEBPACK_IMPORTED_MODULE_5__["DatePipe"]])], ActivityDetailsPage);
    /***/
  }
}]);
//# sourceMappingURL=activity-details-activity-details-module-es5.js.map