(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["add-money-add-money-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/add-money/add-money.page.html":
/*!*************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/add-money/add-money.page.html ***!
  \*************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header  class=\"ion-no-border white-bg\">\n  <ion-toolbar>\n    <ion-title></ion-title>\n    <ion-grid class=\"ion-padding-top ion-padding-start ion-padding-end header-bg\">\n      <ion-row  >\n    <ion-col size=\"1\">\n    <ion-button fill=\"clear\" size=\"small\" class=\"ion-no-padding\" (click)=\"goBack()\">\n        <ion-img src=\"/assets/images/back.svg\" class=\"action-icon\"></ion-img>\n    </ion-button> \n</ion-col>\n<ion-col class=\"ion-text-center\" size=\"9\" style=\"padding-left: 27px; text-align: center;\">\n  <ion-grid class=\"ion-align-items-center ion-justify-content-center\">\n      <ion-row class=\"ion-align-items-center ion-justify-content-center\">\n          <span class=\"survey-name ion-text-center\" style=\"font-size:x-large; text-align: center;\">Add Money</span>\n      </ion-row>\n     \n  </ion-grid>\n</ion-col>\n\n</ion-row>\n</ion-grid> <ion-grid class=\"position-relative ion-no-padding\">\n  <ion-row class=\"ion-no-padding border-header header-half-height\">\n  </ion-row>\n  <ion-row class=\"ion-no-padding header-half-height\">\n\n  </ion-row>\n\n<ion-row  class=\"ion-no-padding position-absolute header-icon-position full-width\">\n<ion-col class=\"flex-center\" *ngIf=\"activity_details?.type=='survey'\">\n\n  \n</ion-col></ion-row></ion-grid>\n\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <form (ngSubmit)=\"addMoney(f)\" #f=\"ngForm\">\n  \n  <ion-input  type=\"number\" name=\"cardNo\" ngModel #cardNo=\"ngModel\" placeholder=\"Enter Card Number\" placeholder-color= 'grey'\n  style='height: 90px; font-size:xx-large; border-bottom:solid thin;font-weight: bolder;' ></ion-input>\n  <ion-input  type=\"number\" name=\"expYear\" ngModel #expYear=\"ngModel\" placeholder=\"Enter Expiry Year\" placeholder-color= 'grey'\n  style='height: 90px; font-size:xx-large; border-bottom:solid thin;font-weight: bolder;' ></ion-input>\n  <ion-input  type=\"number\" name=\"expMonth\" ngModel #expMonth=\"ngModel\" placeholder=\"Enter Expiry Month\" placeholder-color= 'grey'\n  style='height: 90px; font-size:xx-large; border-bottom:solid thin;font-weight: bolder;' ></ion-input>\n  <ion-input  type=\"number\" name=\"cvc\" ngModel #cvc=\"ngModel\" placeholder=\" Enter CVC\" placeholder-color= 'grey'\n  style='height: 90px; font-size:xx-large; border-bottom:solid thin;font-weight: bolder;' ></ion-input>\n  <ion-input  type=\"number\" name=\"amount\" ngModel #amount=\"ngModel\" placeholder=\" Enter Amount\" placeholder-color= 'grey'\n  style='height: 90px; font-size:xx-large; border-bottom:solid thin;font-weight: bolder;' ></ion-input>\n  \n\n<ion-footer style=\"bottom: 30px;\"><ion-button type=\"submit\" style=\"width: 100%; height: 50px; bottom: 20px;\">Proceed</ion-button></ion-footer>\n</form>\n</ion-content>\n");

/***/ }),

/***/ "./src/app/add-money/add-money-routing.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/add-money/add-money-routing.module.ts ***!
  \*******************************************************/
/*! exports provided: AddMoneyPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddMoneyPageRoutingModule", function() { return AddMoneyPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _add_money_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./add-money.page */ "./src/app/add-money/add-money.page.ts");




const routes = [
    {
        path: '',
        component: _add_money_page__WEBPACK_IMPORTED_MODULE_3__["AddMoneyPage"]
    }
];
let AddMoneyPageRoutingModule = class AddMoneyPageRoutingModule {
};
AddMoneyPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], AddMoneyPageRoutingModule);



/***/ }),

/***/ "./src/app/add-money/add-money.module.ts":
/*!***********************************************!*\
  !*** ./src/app/add-money/add-money.module.ts ***!
  \***********************************************/
/*! exports provided: AddMoneyPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddMoneyPageModule", function() { return AddMoneyPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _add_money_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./add-money-routing.module */ "./src/app/add-money/add-money-routing.module.ts");
/* harmony import */ var _add_money_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./add-money.page */ "./src/app/add-money/add-money.page.ts");







let AddMoneyPageModule = class AddMoneyPageModule {
};
AddMoneyPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _add_money_routing_module__WEBPACK_IMPORTED_MODULE_5__["AddMoneyPageRoutingModule"]
        ],
        declarations: [_add_money_page__WEBPACK_IMPORTED_MODULE_6__["AddMoneyPage"]]
    })
], AddMoneyPageModule);



/***/ }),

/***/ "./src/app/add-money/add-money.page.scss":
/*!***********************************************!*\
  !*** ./src/app/add-money/add-money.page.scss ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FkZC1tb25leS9hZGQtbW9uZXkucGFnZS5zY3NzIn0= */");

/***/ }),

/***/ "./src/app/add-money/add-money.page.ts":
/*!*********************************************!*\
  !*** ./src/app/add-money/add-money.page.ts ***!
  \*********************************************/
/*! exports provided: AddMoneyPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddMoneyPage", function() { return AddMoneyPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_native_stripe_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic-native/stripe/ngx */ "./node_modules/@ionic-native/stripe/ngx/index.js");



let AddMoneyPage = class AddMoneyPage {
    constructor(stripe) {
        this.stripe = stripe;
    }
    ngOnInit() {
    }
    addMoney(form) {
        console.log(form.value.cardNo);
        this.stripe.setPublishableKey('pk_test_51HQ4SfBlSfQmxsSfuw13DnL4B9BprtM135rSSoPnKNW7ncjYaIuNLLIajGtILpysRPYX3BvKoIDpxO2pP2SEXnqL00K7GpIR6Z');
        let card = {
            number: form.value.cardNo,
            expYear: form.value.expYear,
            expMonth: form.value.expMonth,
            cvc: form.value.cvc,
            amount: form.value.amount,
        };
        console.log(card);
        this.stripe.createCardToken(card).then(token => alert(token.id)).catch(error => alert(error));
    }
};
AddMoneyPage.ctorParameters = () => [
    { type: _ionic_native_stripe_ngx__WEBPACK_IMPORTED_MODULE_2__["Stripe"] }
];
AddMoneyPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-add-money',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./add-money.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/add-money/add-money.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./add-money.page.scss */ "./src/app/add-money/add-money.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_native_stripe_ngx__WEBPACK_IMPORTED_MODULE_2__["Stripe"]])
], AddMoneyPage);



/***/ })

}]);
//# sourceMappingURL=add-money-add-money-module-es2015.js.map