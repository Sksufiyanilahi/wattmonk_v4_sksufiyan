function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["surveyoroverview-surveyoroverview-module"], {
  /***/
  "./node_modules/@ionic-native/native-geocoder/ngx/index.js":
  /*!*****************************************************************!*\
    !*** ./node_modules/@ionic-native/native-geocoder/ngx/index.js ***!
    \*****************************************************************/

  /*! exports provided: NativeGeocoder */

  /***/
  function node_modulesIonicNativeNativeGeocoderNgxIndexJs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "NativeGeocoder", function () {
      return NativeGeocoder;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _ionic_native_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic-native/core */
    "./node_modules/@ionic-native/core/index.js");

    var NativeGeocoder =
    /** @class */
    function (_super) {
      Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(NativeGeocoder, _super);

      function NativeGeocoder() {
        return _super !== null && _super.apply(this, arguments) || this;
      }

      NativeGeocoder.prototype.reverseGeocode = function (latitude, longitude, options) {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "reverseGeocode", {
          "callbackOrder": "reverse"
        }, arguments);
      };

      NativeGeocoder.prototype.forwardGeocode = function (addressString, options) {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "forwardGeocode", {
          "callbackOrder": "reverse"
        }, arguments);
      };

      NativeGeocoder.pluginName = "NativeGeocoder";
      NativeGeocoder.plugin = "cordova-plugin-nativegeocoder";
      NativeGeocoder.pluginRef = "nativegeocoder";
      NativeGeocoder.repo = "https://github.com/sebastianbaar/cordova-plugin-nativegeocoder";
      NativeGeocoder.platforms = ["iOS", "Android"];
      NativeGeocoder = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])()], NativeGeocoder);
      return NativeGeocoder;
    }(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["IonicNativePlugin"]); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvQGlvbmljLW5hdGl2ZS9wbHVnaW5zL25hdGl2ZS1nZW9jb2Rlci9uZ3gvaW5kZXgudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDM0MsT0FBTyw4QkFBc0MsTUFBTSxvQkFBb0IsQ0FBQzs7SUF3Q3BDLGtDQUFpQjs7OztJQVduRCx1Q0FBYyxhQUNaLFFBQWdCLEVBQ2hCLFNBQWlCLEVBQ2pCLE9BQStCO0lBY2pDLHVDQUFjLGFBQUMsYUFBcUIsRUFBRSxPQUErQjs7Ozs7O0lBNUIxRCxjQUFjO1FBRDFCLFVBQVUsRUFBRTtPQUNBLGNBQWM7eUJBekMzQjtFQXlDb0MsaUJBQWlCO1NBQXhDLGNBQWMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBDb3Jkb3ZhLCBJb25pY05hdGl2ZVBsdWdpbiwgUGx1Z2luIH0gZnJvbSAnQGlvbmljLW5hdGl2ZS9jb3JlJztcblxuLyoqXG4gKiBAbmFtZSBOYXRpdmUgR2VvY29kZXJcbiAqIEBkZXNjcmlwdGlvblxuICogQ29yZG92YSBwbHVnaW4gZm9yIG5hdGl2ZSBmb3J3YXJkIGFuZCByZXZlcnNlIGdlb2NvZGluZ1xuICpcbiAqIEB1c2FnZVxuICogYGBgdHlwZXNjcmlwdFxuICogaW1wb3J0IHsgTmF0aXZlR2VvY29kZXIsIE5hdGl2ZUdlb2NvZGVyUmVzdWx0LCBOYXRpdmVHZW9jb2Rlck9wdGlvbnMgfSBmcm9tICdAaW9uaWMtbmF0aXZlL25hdGl2ZS1nZW9jb2Rlci9uZ3gnO1xuICpcbiAqIGNvbnN0cnVjdG9yKHByaXZhdGUgbmF0aXZlR2VvY29kZXI6IE5hdGl2ZUdlb2NvZGVyKSB7IH1cbiAqXG4gKiAuLi5cbiAqXG4gKiBsZXQgb3B0aW9uczogTmF0aXZlR2VvY29kZXJPcHRpb25zID0ge1xuICogICAgIHVzZUxvY2FsZTogdHJ1ZSxcbiAqICAgICBtYXhSZXN1bHRzOiA1XG4gKiB9O1xuICpcbiAqIHRoaXMubmF0aXZlR2VvY29kZXIucmV2ZXJzZUdlb2NvZGUoNTIuNTA3MjA5NSwgMTMuMTQ1MjgxOCwgb3B0aW9ucylcbiAqICAgLnRoZW4oKHJlc3VsdDogTmF0aXZlR2VvY29kZXJSZXN1bHRbXSkgPT4gY29uc29sZS5sb2coSlNPTi5zdHJpbmdpZnkocmVzdWx0WzBdKSkpXG4gKiAgIC5jYXRjaCgoZXJyb3I6IGFueSkgPT4gY29uc29sZS5sb2coZXJyb3IpKTtcbiAqXG4gKiB0aGlzLm5hdGl2ZUdlb2NvZGVyLmZvcndhcmRHZW9jb2RlKCdCZXJsaW4nLCBvcHRpb25zKVxuICogICAudGhlbigocmVzdWx0OiBOYXRpdmVHZW9jb2RlclJlc3VsdFtdKSA9PiBjb25zb2xlLmxvZygnVGhlIGNvb3JkaW5hdGVzIGFyZSBsYXRpdHVkZT0nICsgcmVzdWx0WzBdLmxhdGl0dWRlICsgJyBhbmQgbG9uZ2l0dWRlPScgKyByZXN1bHRbMF0ubG9uZ2l0dWRlKSlcbiAqICAgLmNhdGNoKChlcnJvcjogYW55KSA9PiBjb25zb2xlLmxvZyhlcnJvcikpO1xuICogYGBgXG4gKiBAaW50ZXJmYWNlc1xuICogTmF0aXZlR2VvY29kZXJSZXN1bHRcbiAqIE5hdGl2ZUdlb2NvZGVyT3B0aW9uc1xuICovXG5AUGx1Z2luKHtcbiAgcGx1Z2luTmFtZTogJ05hdGl2ZUdlb2NvZGVyJyxcbiAgcGx1Z2luOiAnY29yZG92YS1wbHVnaW4tbmF0aXZlZ2VvY29kZXInLFxuICBwbHVnaW5SZWY6ICduYXRpdmVnZW9jb2RlcicsXG4gIHJlcG86ICdodHRwczovL2dpdGh1Yi5jb20vc2ViYXN0aWFuYmFhci9jb3Jkb3ZhLXBsdWdpbi1uYXRpdmVnZW9jb2RlcicsXG4gIHBsYXRmb3JtczogWydpT1MnLCAnQW5kcm9pZCddLFxufSlcbkBJbmplY3RhYmxlKClcbmV4cG9ydCBjbGFzcyBOYXRpdmVHZW9jb2RlciBleHRlbmRzIElvbmljTmF0aXZlUGx1Z2luIHtcbiAgLyoqXG4gICAqIFJldmVyc2UgZ2VvY29kZSBhIGdpdmVuIGxhdGl0dWRlIGFuZCBsb25naXR1ZGUgdG8gZmluZCBsb2NhdGlvbiBhZGRyZXNzXG4gICAqIEBwYXJhbSBsYXRpdHVkZSB7bnVtYmVyfSBUaGUgbGF0aXR1ZGVcbiAgICogQHBhcmFtIGxvbmdpdHVkZSB7bnVtYmVyfSBUaGUgbG9uZ2l0dWRlXG4gICAqIEBwYXJhbSBvcHRpb25zIHtOYXRpdmVHZW9jb2Rlck9wdGlvbnN9IFRoZSBvcHRpb25zXG4gICAqIEByZXR1cm4ge1Byb21pc2U8TmF0aXZlR2VvY29kZXJSZXN1bHRbXT59XG4gICAqL1xuICBAQ29yZG92YSh7XG4gICAgY2FsbGJhY2tPcmRlcjogJ3JldmVyc2UnLFxuICB9KVxuICByZXZlcnNlR2VvY29kZShcbiAgICBsYXRpdHVkZTogbnVtYmVyLFxuICAgIGxvbmdpdHVkZTogbnVtYmVyLFxuICAgIG9wdGlvbnM/OiBOYXRpdmVHZW9jb2Rlck9wdGlvbnNcbiAgKTogUHJvbWlzZTxOYXRpdmVHZW9jb2RlclJlc3VsdFtdPiB7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgLyoqXG4gICAqIEZvcndhcmQgZ2VvY29kZSBhIGdpdmVuIGFkZHJlc3MgdG8gZmluZCBjb29yZGluYXRlc1xuICAgKiBAcGFyYW0gYWRkcmVzc1N0cmluZyB7c3RyaW5nfSBUaGUgYWRkcmVzcyB0byBiZSBnZW9jb2RlZFxuICAgKiBAcGFyYW0gb3B0aW9ucyB7TmF0aXZlR2VvY29kZXJPcHRpb25zfSBUaGUgb3B0aW9uc1xuICAgKiBAcmV0dXJuIHtQcm9taXNlPE5hdGl2ZUdlb2NvZGVyUmVzdWx0W10+fVxuICAgKi9cbiAgQENvcmRvdmEoe1xuICAgIGNhbGxiYWNrT3JkZXI6ICdyZXZlcnNlJyxcbiAgfSlcbiAgZm9yd2FyZEdlb2NvZGUoYWRkcmVzc1N0cmluZzogc3RyaW5nLCBvcHRpb25zPzogTmF0aXZlR2VvY29kZXJPcHRpb25zKTogUHJvbWlzZTxOYXRpdmVHZW9jb2RlclJlc3VsdFtdPiB7XG4gICAgcmV0dXJuO1xuICB9XG59XG5cbi8qKlxuICogRW5jYXBzdWxhdGVzIGZvcm1hdCBpbmZvcm1hdGlvbiBhYm91dCBhIGdlb2NvZGluZyByZXN1bHQuXG4gKiBtb3JlIEluZm86XG4gKiAgLSBodHRwczovL2RldmVsb3Blci5hcHBsZS5jb20vZG9jdW1lbnRhdGlvbi9jb3JlbG9jYXRpb24vY2xwbGFjZW1hcmtcbiAqICAtIGh0dHBzOi8vZGV2ZWxvcGVyLmFuZHJvaWQuY29tL3JlZmVyZW5jZS9hbmRyb2lkL2xvY2F0aW9uL0FkZHJlc3MuaHRtbFxuICovXG5leHBvcnQgaW50ZXJmYWNlIE5hdGl2ZUdlb2NvZGVyUmVzdWx0IHtcbiAgLyoqXG4gICAqIFRoZSBsYXRpdHVkZS5cbiAgICovXG4gIGxhdGl0dWRlOiBzdHJpbmc7XG4gIC8qKlxuICAgKiBUaGUgbG9uZ2l0dWRlLlxuICAgKi9cbiAgbG9uZ2l0dWRlOiBzdHJpbmc7XG4gIC8qKlxuICAgKiBUaGUgY291bnRyeSBjb2RlLlxuICAgKi9cbiAgY291bnRyeUNvZGU6IHN0cmluZztcbiAgLyoqXG4gICAqIFRoZSBjb3VudHJ5IG5hbWUuXG4gICAqL1xuICBjb3VudHJ5TmFtZTogc3RyaW5nO1xuICAvKipcbiAgICogVGhlIHBvc3RhbCBjb2RlLlxuICAgKi9cbiAgcG9zdGFsQ29kZTogc3RyaW5nO1xuICAvKipcbiAgICogVGhlIGFkbWluaXN0cmF0aXZlQXJlYS5cbiAgICovXG4gIGFkbWluaXN0cmF0aXZlQXJlYTogc3RyaW5nO1xuICAvKipcbiAgICogVGhlIHN1YkFkbWluaXN0cmF0aXZlQXJlYS5cbiAgICovXG4gIHN1YkFkbWluaXN0cmF0aXZlQXJlYTogc3RyaW5nO1xuICAvKipcbiAgICogVGhlIGxvY2FsaXR5LlxuICAgKi9cbiAgbG9jYWxpdHk6IHN0cmluZztcbiAgLyoqXG4gICAqIFRoZSBzdWJMb2NhbGl0eS5cbiAgICovXG4gIHN1YkxvY2FsaXR5OiBzdHJpbmc7XG4gIC8qKlxuICAgKiBUaGUgdGhvcm91Z2hmYXJlLlxuICAgKi9cbiAgdGhvcm91Z2hmYXJlOiBzdHJpbmc7XG4gIC8qKlxuICAgKiBUaGUgc3ViVGhvcm91Z2hmYXJlLlxuICAgKi9cbiAgc3ViVGhvcm91Z2hmYXJlOiBzdHJpbmc7XG4gIC8qKlxuICAgKiBUaGUgYXJlYXNPZkludGVyZXN0XG4gICAqL1xuICBhcmVhc09mSW50ZXJlc3Q6IHN0cmluZ1tdO1xufVxuXG4vKipcbiAqIE9wdGlvbnMgZm9yIHJldmVyc2UgYW5kIGZvcndhcmQgZ2VvY29kaW5nLlxuICovXG5leHBvcnQgaW50ZXJmYWNlIE5hdGl2ZUdlb2NvZGVyT3B0aW9ucyB7XG4gIC8qKlxuICAgKiBUaGUgbG9jYWxlIHRvIHVzZSB3aGVuIHJldHVybmluZyB0aGUgYWRkcmVzcyBpbmZvcm1hdGlvbi5cbiAgICogSWYgc2V0IHRvICdmYWxzZScgdGhlIGxvY2FsZSB3aWxsIGFsd2F5cyBiZSAnZW5fVVMnLlxuICAgKiBEZWZhdWx0IGlzICd0cnVlJ1xuICAgKi9cbiAgdXNlTG9jYWxlOiBib29sZWFuO1xuICAvKipcbiAgICogVGhlIGRlZmF1bHQgbG9jYWxlIHRvIHVzZSB3aGVuIHJldHVybmluZyB0aGUgYWRkcmVzcyBpbmZvcm1hdGlvbi5cbiAgICogZS5nLjogJ2ZhLUlSJyBvciAnZGVfREUnLlxuICAgKi9cbiAgZGVmYXVsdExvY2FsZT86IHN0cmluZztcbiAgLyoqXG4gICAqIFRoZSBtYXhpbXVtIG51bWJlciBvZiByZXN1bHQgdG8gcmV0dXJuIChtYXggaXMgNSkuXG4gICAqIERlZmF1bHQgaXMgMVxuICAgKi9cbiAgbWF4UmVzdWx0czogbnVtYmVyO1xufVxuIl19

    /***/

  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/email-model/email-model.page.html":
  /*!*****************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/email-model/email-model.page.html ***!
    \*****************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppEmailModelEmailModelPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\r\n  <h4 style=\"font-weight: bold;margin-bottom:0px !important;padding: 10px;\">Select the Emails</h4>\r\n  \r\n  <ion-content>\r\n    <ion-list>\r\n     <ion-item>\r\n       <ion-label>\r\n       <input type=\"checkbox\" name=\"selectall\" [value]=\"TeamData\" (change)=\"selectAll($event)\" style=\"height: 17px;width: 28px;\">\r\n       Select All</ion-label>\r\n     </ion-item>\r\n     <ion-list>\r\n     <ion-item\r\n      *ngFor=\"let item of example; let i = index \">\r\n         <!-- <input type=\"checkbox\" [(ngModel)]=\"item.Checked\">&nbsp;  -->\r\n         <p class=\"listitem\">{{item?.firstname}}</p>\r\n         <p class=\"listitem\">{{item?.lastname}}</p>\r\n         <p class=\"listitem\">({{item?.email}})</p>\r\n         <ion-checkbox slot=\"start\" [(ngModel)]=\"item.Checked\" ></ion-checkbox>\r\n         \r\n     \r\n     </ion-item>\r\n     </ion-list>\r\n   </ion-list>\r\n   <ion-grid>\r\n         <ion-row>\r\n           <ion-col>\r\n             <h6 style=\"margin-top:0px;padding: 2px;\"></h6>\r\n             <textarea id=\"inputemails\" placeholder=\"eg : john@gmail.com\" type=\"emails\" multiple style=\"width: 100%;\" ></textarea>\r\n           </ion-col>\r\n         </ion-row>\r\n        <!-- <ion-row>\r\n           <ion-col>\r\n             <h6 style=\"margin:0px 0 0px 0;\">Attachment</h6>\r\n           \r\n               <ion-input type=\"text\" placeholder=\"Select Attachment\" [(ngModel)]=\"filename\" readonly (click)=\"selectAttachment()\" style=\"border-bottom:1px solid grey\"  > <ion-icon name=\"attach-outline\" style=\"float: right;text-align:right ;\"></ion-icon></ion-input>\r\n              \r\n            <small *ngIf=\"exceedfileSize > 0\" style=\"color:red\">File size should not be greater than 25MB.</small>\r\n           </ion-col>\r\n         </ion-row>-->\r\n       </ion-grid>\r\n  </ion-content>\r\n    <footer style=\"text-align: right;margin:12px;\">\r\n      <ion-button fill=\"clear\" (click)=\"cancel()\">Cancel</ion-button>\r\n      <ion-button fill=\"clear\" (click)=\"SendMail()\">Send</ion-button>\r\n    </footer>\r\n  <!-- <div class=_padding>\r\n    <p>Decline the design Request</p>\r\n    <textarea placeholder=\"Reason*\" style=\"width: 100%;\"></textarea>\r\n  </div> -->\r\n\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/surveyoroverview/completedsurveys/completedsurveys.component.html":
  /*!*************************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/surveyoroverview/completedsurveys/completedsurveys.component.html ***!
    \*************************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppSurveyoroverviewCompletedsurveysCompletedsurveysComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-content>\r\n  <ion-refresher slot=\"fixed\" (ionRefresh)=\"getSurveys($event)\">\r\n    <ion-refresher-content pullingIcon=\"arrow-dropdown\" pullingText=\"Pull down to refresh\" refreshingSpinner=\"lines\"></ion-refresher-content>\r\n  </ion-refresher>\r\n  <ion-grid *ngIf=\"listOfSurveyDataHelper.length !== 0\">\r\n    <ion-row *ngFor=\"let item of listOfSurveyDataHelper;let i = index\">\r\n        <ion-col size=\"12\" class=\"ion-margin-top\">\r\n                <span class=\"ion-padding\" *ngIf=\"today === item.date\">\r\n                    Today\r\n                  </span>\r\n            <span class=\"ion-padding\" *ngIf=\"today !== item.date\">\r\n                      {{item.date | date: 'dd MMM yyyy'}}\r\n                </span>\r\n        </ion-col>\r\n        <ion-col *ngFor=\"let surveyData of item.listOfSurveys;let i = index \" size=\"12\">\r\n            <div class=\"ion-no-padding custom-card\" style=\"height: 100%;\">\r\n                <p class=\"customer-name\" >{{surveyData.name}}\r\n                      <span class=\"chipdetail\" style=\"background-color: #1289A7;\" [routerLink]=\"['/survey-detail/',surveyData.id]\" routerDirection=\"forward\">\r\n                        {{surveyData.datetime | date: 'hh:mm a'}}\r\n                    </span>\r\n                    <span fill=\"clear\" background-border=\"clear\" [routerLink]=\"['/','activity',surveyData.id,'survey']\" class=\"imagebutton\"  size=\"small\"  ><ion-icon  src=\"/assets/images/activitylist.svg\" ></ion-icon></span>\r\n                    <span *ngIf=\"surveyData.status=='surveycompleted'\" class=\"chipdetail\" style=\"background-color: rgb(109, 187, 26);\" [routerLink]=\"['/survey-detail/',surveyData.id]\" routerDirection=\"forward\">\r\n                        completed\r\n                    </span>\r\n                    <span class=\"chipdetail\" style=\"background-color: rgb(246, 77, 10);\" *ngIf=\"surveyData.lateby > 0\">Overdue</span>\r\n            </p>\r\n            <p style=\"margin:0px\">\r\n\r\n                <span class=\"customer-email\" [routerLink]=\"['/survey-detail/',surveyData.id]\"\r\n                      routerDirection=\"forward\">{{surveyData.email}}</span>\r\n                      <span *ngIf=\"surveyData.lateby > 1\" class=\"latebystyle\" style=\"font-size: 10px;\"><strong>Late by {{surveyData.lateby}} days</strong></span>\r\n                      <span *ngIf=\"surveyData.lateby == 1\" class=\"latebystyle\" style=\"font-size: 10px;\"><strong>Late by a day</strong></span>\r\n            </p>\r\n                <a href=\"tel:{{surveyData.phonenumber}}\" style=\"text-decoration: none;\" class=\"z-100\">\r\n                    <span class=\"customer-phone\">{{surveyData.phonenumber}}</span></a>\r\n                <span class=\"customer-address z-100\"\r\n                      (click)=\"openAddressOnMap(surveyData.address)\">{{(surveyData.address | slice:0:60) + (surveyData.address.length > 60 ? '...' : '')}}</span>\r\n\r\n                <ion-row style=\"margin-bottom: 8px;\"  [routerLink]=\"['/survey-detail/',surveyData.id]\">\r\n                    <span class=\"chipdetail\" style=\"background-color: #95afc0;\" >Wattmonk</span>\r\n                    <span class=\"chipdetail\" style=\"background-color: #95afc0;\" >{{surveyData.formattedjobtype}}</span>\r\n                </ion-row>\r\n                <ion-progress-bar [value]=\"1\" mode=\"ios\" color=\"success\" class=\"progress-bar-height\"></ion-progress-bar>\r\n            </div>\r\n        </ion-col>\r\n    </ion-row>\r\n    <ion-row>\r\n        <ion-col size=\"12\" style=\"height: 100px;\">\r\n        </ion-col>\r\n    </ion-row>\r\n</ion-grid>\r\n\r\n<div *ngIf=\"listOfSurveyDataHelper.length === 0\" class=\"h-100 d-flex flex-column align-center justify-center\">\r\n    <ion-img src=\"/assets/images/blank.png\" class=\"placeholder\"></ion-img>\r\n</div>\r\n</ion-content>\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/surveyoroverview/deliveredsurveys/deliveredsurveys.component.html":
  /*!*************************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/surveyoroverview/deliveredsurveys/deliveredsurveys.component.html ***!
    \*************************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppSurveyoroverviewDeliveredsurveysDeliveredsurveysComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-content>\r\n  <ion-refresher slot=\"fixed\" (ionRefresh)=\"getSurveys($event)\">\r\n    <ion-refresher-content pullingIcon=\"arrow-dropdown\" pullingText=\"Pull down to refresh\" refreshingSpinner=\"lines\"></ion-refresher-content>\r\n  </ion-refresher>\r\n  <ion-grid *ngIf=\"listOfSurveyDataHelper.length !== 0\">\r\n    <ion-row *ngFor=\"let item of listOfSurveyDataHelper;let i = index\">\r\n        <ion-col size=\"12\" class=\"ion-margin-top\">\r\n                <span class=\"ion-padding\" *ngIf=\"today === item.date\">\r\n                    Today\r\n                  </span>\r\n            <span class=\"ion-padding\" *ngIf=\"today !== item.date\">\r\n                      {{item.date | date: 'dd MMM yyyy'}}\r\n                </span>\r\n        </ion-col>\r\n        <ion-col *ngFor=\"let surveyData of item.listOfSurveys;let i = index \" size=\"12\">\r\n            <div class=\"ion-no-padding custom-card\" style=\"height: 100%;\">\r\n                <p class=\"customer-name\" >{{surveyData.name}}\r\n                      <span class=\"chipdetail\" style=\"background-color: #1289A7;\" [routerLink]=\"['/survey-detail/',surveyData.id]\" routerDirection=\"forward\">\r\n                        {{surveyData.datetime | date: 'hh:mm a'}}\r\n                    </span>\r\n                    <span fill=\"clear\" background-border=\"clear\" [routerLink]=\"['/','activity',surveyData.id,'survey']\" class=\"imagebutton\"  size=\"small\"  ><ion-icon  src=\"/assets/images/activitylist.svg\" ></ion-icon></span>\r\n                    <span *ngIf=\"surveyData.status=='delivered'\" class=\"chipdetail\" style=\"background-color:rgb(109, 187, 26);\" [routerLink]=\"['/survey-detail/',surveyData.id]\" routerDirection=\"forward\">\r\n                        delivered\r\n                    </span>\r\n                    <span class=\"chipdetail\" style=\"background-color: rgb(246, 77, 10);\" *ngIf=\"surveyData.lateby > 0\">Overdue</span>\r\n            </p>\r\n            <p style=\"margin:0px\">\r\n\r\n                <span class=\"customer-email\" [routerLink]=\"['/survey-detail/',surveyData.id]\"\r\n                      routerDirection=\"forward\">{{surveyData.email}}</span>\r\n                      <span *ngIf=\"surveyData.lateby > 1\" class=\"latebystyle\" style=\"font-size: 10px;\"><strong>Late by {{surveyData.lateby}} days</strong></span>\r\n                      <span *ngIf=\"surveyData.lateby == 1\" class=\"latebystyle\" style=\"font-size: 10px;\"><strong>Late by a day</strong></span>\r\n            </p>\r\n                <a href=\"tel:{{surveyData.phonenumber}}\" style=\"text-decoration: none;\" class=\"z-100\">\r\n                    <span class=\"customer-phone\">{{surveyData.phonenumber}}</span></a>\r\n                <span class=\"customer-address z-100\"\r\n                      (click)=\"openAddressOnMap(surveyData.address)\">{{(surveyData.address | slice:0:60) + (surveyData.address.length > 60 ? '...' : '')}}</span>\r\n\r\n                <ion-row style=\"margin-bottom: 8px;\"  [routerLink]=\"['/survey-detail/',surveyData.id]\">\r\n                    <span class=\"chipdetail\" style=\"background-color: #95afc0;\" >Wattmonk</span>\r\n                    <span class=\"chipdetail\" style=\"background-color: #95afc0;\" >{{surveyData.formattedjobtype}}</span>\r\n                </ion-row>\r\n            </div>\r\n        </ion-col>\r\n    </ion-row>\r\n    <ion-row>\r\n        <ion-col size=\"12\" style=\"height: 100px;\">\r\n        </ion-col>\r\n    </ion-row>\r\n</ion-grid>\r\n\r\n<div *ngIf=\"listOfSurveyDataHelper.length === 0\" class=\"h-100 d-flex flex-column align-center justify-center\">\r\n    <ion-img src=\"/assets/images/blank.png\" class=\"placeholder\"></ion-img>\r\n</div>\r\n</ion-content>\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/surveyoroverview/inreviewsurveys/inreviewsurveys.component.html":
  /*!***********************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/surveyoroverview/inreviewsurveys/inreviewsurveys.component.html ***!
    \***********************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppSurveyoroverviewInreviewsurveysInreviewsurveysComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-content>\r\n  <ion-refresher slot=\"fixed\" (ionRefresh)=\"getSurveys($event)\">\r\n    <ion-refresher-content pullingIcon=\"arrow-dropdown\" pullingText=\"Pull down to refresh\" refreshingSpinner=\"lines\"></ion-refresher-content>\r\n  </ion-refresher>\r\n  <ion-grid *ngIf=\"listOfSurveyDataHelper.length !== 0\">\r\n    <ion-row *ngFor=\"let item of listOfSurveyDataHelper;let i = index\">\r\n        <ion-col size=\"12\" class=\"ion-margin-top\">\r\n                <span class=\"ion-padding\" *ngIf=\"today === item.date\">\r\n                    Today\r\n                  </span>\r\n            <span class=\"ion-padding\" *ngIf=\"today !== item.date\">\r\n                      {{item.date | date: 'dd MMM yyyy'}}\r\n                </span>\r\n        </ion-col>\r\n        <ion-col *ngFor=\"let surveyData of item.listOfSurveys;let i = index \" size=\"12\">\r\n            <div class=\"ion-no-padding custom-card\" style=\"height: 100%;\">\r\n                <p class=\"customer-name\">{{surveyData.name}}\r\n                      <span class=\"chipdetail\" style=\"background-color: #1289A7;\" [routerLink]=\"['/survey-detail/',surveyData.id]\" routerDirection=\"forward\">\r\n                        {{surveyData.datetime | date: 'hh:mm a'}}\r\n                    </span>\r\n                    <span fill=\"clear\" background-border=\"clear\" [routerLink]=\"['/','activity',surveyData.id,'survey']\" class=\"imagebutton\"  size=\"small\"  ><ion-icon  src=\"/assets/images/activitylist.svg\" ></ion-icon></span>\r\n                    <span *ngIf=\"surveyData.status=='reviewassigned'\" class=\"chipdetail\" style=\"background-color: #1289A7;\" [routerLink]=\"['/survey-detail/',surveyData.id]\" routerDirection=\"forward\">\r\n                        In review\r\n                    </span>\r\n                    <span class=\"chipdetail\" style=\"background-color: rgb(246, 77, 10);\" *ngIf=\"surveyData.lateby > 0\">Overdue</span>\r\n            </p>\r\n            <p style=\"margin:0px\">\r\n\r\n                <span class=\"customer-email\" [routerLink]=\"['/survey-detail/',surveyData.id]\"\r\n                      routerDirection=\"forward\">{{surveyData.email}}</span>\r\n                      <span *ngIf=\"surveyData.lateby > 1\" class=\"latebystyle\" style=\"font-size: 10px;\"><strong>Late by {{surveyData.lateby}} days</strong></span>\r\n                      <span *ngIf=\"surveyData.lateby == 1\" class=\"latebystyle\" style=\"font-size: 10px;\"><strong>Late by a day</strong></span>\r\n            </p>\r\n                <a href=\"tel:{{surveyData.phonenumber}}\" style=\"text-decoration: none;\" class=\"z-100\">\r\n                    <span class=\"customer-phone\">{{surveyData.phonenumber}}</span></a>\r\n                <span class=\"customer-address z-100\"\r\n                      (click)=\"openAddressOnMap(surveyData.address)\">{{(surveyData.address | slice:0:60) + (surveyData.address.length > 60 ? '...' : '')}}</span>\r\n\r\n                <ion-row style=\"margin-bottom: 8px;\" [routerLink]=\"['/survey-detail/',surveyData.id]\">\r\n                    <span class=\"chipdetail\" style=\"background-color: #95afc0;\" >Wattmonk</span>\r\n                    <span class=\"chipdetail\" style=\"background-color: #95afc0;\" >{{surveyData.formattedjobtype}}</span>\r\n                      <span class=\"chipdetail\" style=\"background-color: rgb(246, 77, 10);\" *ngIf=\"surveyData.status == 'reviewfailed'\">Failed</span>\r\n                      <span class=\"chipdetail\" style=\"background-color: rgb(109, 187, 26);\" *ngIf=\"surveyData.status == 'reviewpassed'\">Passed</span>\r\n                </ion-row>\r\n                <ion-row class=\"ion-no-margin ion-no-margin\" *ngIf=\"surveyData.status == 'reviewfailed'\">\r\n                    <ion-col></ion-col>\r\n                    <ion-col class=\"ion-no-margin ion-no-padding\">\r\n                        <ion-button class=\"ion-no-margin ion-no-padding\" fill=\"clear\" [routerLink]=\"['/surveyprocess/' + surveyData.id + '/' + surveyData.jobtype + '/' + surveyData.latitude + '/' + surveyData.longitude]\"\r\n                        routerDirection=\"forward\">\r\n                            Restart Survey\r\n                        </ion-button>\r\n                    </ion-col>\r\n                </ion-row>\r\n                <ion-progress-bar [value]=\"1\" mode=\"ios\" color=\"success\" class=\"progress-bar-height\"></ion-progress-bar>\r\n            </div>\r\n        </ion-col>\r\n    </ion-row>\r\n    <ion-row>\r\n        <ion-col size=\"12\" style=\"height: 100px;\">\r\n        </ion-col>\r\n    </ion-row>\r\n</ion-grid>\r\n\r\n<div *ngIf=\"listOfSurveyDataHelper.length === 0\" class=\"h-100 d-flex flex-column align-center justify-center\">\r\n    <ion-img src=\"/assets/images/blank.png\" class=\"placeholder\"></ion-img>\r\n</div>\r\n</ion-content>\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/surveyoroverview/newsurveys/newsurveys.component.html":
  /*!*************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/surveyoroverview/newsurveys/newsurveys.component.html ***!
    \*************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppSurveyoroverviewNewsurveysNewsurveysComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-content [scrollEvents]=\"true\">\r\n  <ion-refresher slot=\"fixed\" (ionRefresh)=\"getSurveys($event)\">\r\n    <ion-refresher-content pullingIcon=\"arrow-dropdown\" pullingText=\"Pull down to refresh\" refreshingSpinner=\"lines\"></ion-refresher-content>\r\n  </ion-refresher>\r\n  <ion-grid *ngIf=\"listOfSurveyDataHelper.length !== 0\">\r\n    <ion-row *ngFor=\"let item of listOfSurveyDataHelper;let i = index\">\r\n        <ion-col size=\"12\" class=\"ion-margin-top\">\r\n                <span class=\"ion-padding\" *ngIf=\"today == item.date\">\r\n                    Today\r\n                  </span>\r\n            <span class=\"ion-padding\" *ngIf=\"today != item.date\">\r\n                      {{item.date | date: 'dd MMM yyyy'}}\r\n                </span>\r\n        </ion-col>\r\n        <ion-col *ngFor=\"let surveyData of item.listOfSurveys;let i = index \" size=\"12\">\r\n            <div class=\"ion-no-padding custom-card\" style=\"height: 100%;\">\r\n                <p class=\"customer-name\" >{{surveyData.name}}\r\n                      <span class=\"chipdetail\" style=\"background-color: #1289A7;\" [routerLink]=\"['/survey-detail/',surveyData.id]\" routerDirection=\"forward\">\r\n                        {{surveyData.datetime | date: 'hh:mm a'}}\r\n                    </span>\r\n                      <span *ngIf=\"surveyData.status=='surveyassigned'\" class=\"chipdetail\" style=\"background-color: #3C78D8;\" [routerLink]=\"['/survey-detail/',surveyData.id]\" routerDirection=\"forward\">\r\n                        Pending\r\n                    </span>\r\n                    <span class=\"chipdetail\" style=\"background-color: rgb(246, 77, 10);\" *ngIf=\"surveyData.lateby > 0\">Overdue</span>\r\n                    <span fill=\"clear\" background-border=\"clear\" [routerLink]=\"['/','activity',surveyData.id,'survey']\" class=\"imagebutton\"  size=\"small\"  ><ion-icon  src=\"/assets/images/activitylist.svg\" ></ion-icon></span>\r\n                </p>\r\n            <p style=\"margin:0px\">\r\n\r\n                <span class=\"customer-email\" [routerLink]=\"['/survey-detail/',surveyData.id]\"\r\n                      routerDirection=\"forward\">{{surveyData.email}}</span>\r\n                      <span *ngIf=\"surveyData.lateby > 1\" class=\"latebystyle\" style=\"font-size: 10px;\"><strong>Late by {{surveyData.lateby}} days</strong></span>\r\n                      <span *ngIf=\"surveyData.lateby == 1\" class=\"latebystyle\" style=\"font-size: 10px;\"><strong>Late by a day</strong></span>\r\n            </p>\r\n                <a href=\"tel:{{surveyData?.phonenumber}}\" style=\"text-decoration: none;\" class=\"z-100\">\r\n                    <span class=\"customer-phone\">{{surveyData?.phonenumber}}</span></a>\r\n                <span class=\"customer-address z-100\"\r\n                      (click)=\"openAddressOnMap(surveyData.address)\">{{(surveyData.address | slice:0:60) + (surveyData.address?.length > 60 ? '...' : '')}}</span>\r\n\r\n                <ion-row style=\"margin-bottom: 8px;\"  [routerLink]=\"['/survey-detail/',surveyData.id]\">\r\n                    <span class=\"chipdetail\" style=\"background-color: #95afc0;\" >Wattmonk</span>\r\n                    <span class=\"chipdetail\" style=\"background-color: #95afc0;\" >{{surveyData.formattedjobtype}}</span>\r\n                   \r\n                </ion-row>\r\n                <ion-row class=\"ion-no-margin ion-no-margin\">\r\n                    <ion-col></ion-col>\r\n                    <ion-col class=\"ion-no-margin ion-no-padding\">\r\n                    <!-- <ion-col class=\"ion-no-margin ion-no-padding ion-text-end\" *ngIf=\"today==item.date\"> -->\r\n                        <ion-button class=\"ion-no-margin ion-no-padding\" fill=\"clear\" [routerLink]=\"['/surveyprocess/' + surveyData.id + '/' + surveyData.jobtype + '/' + surveyData.latitude + '/' + surveyData.longitude + '/' + surveyData.city + '/' + surveyData.state]\"\r\n                        routerDirection=\"forward\">\r\n                            Start Survey\r\n                        </ion-button>\r\n                    </ion-col>\r\n                </ion-row>\r\n                <ion-progress-bar [value]=\"surveyData.totalpercent\" mode=\"ios\" color=\"success\" class=\"progress-bar-height\"></ion-progress-bar>\r\n            </div>\r\n        </ion-col>\r\n    </ion-row>\r\n    <ion-row>\r\n        <ion-col size=\"12\" style=\"height: 100px;\">\r\n        </ion-col>\r\n    </ion-row>\r\n</ion-grid>\r\n\r\n<div *ngIf=\"listOfSurveyDataHelper.length === 0\" class=\"h-100 d-flex flex-column align-center justify-center\">\r\n    <ion-img src=\"/assets/images/blank.png\" class=\"placeholder\"></ion-img>\r\n</div>\r\n</ion-content>\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/surveyoroverview/surveyoroverview.page.html":
  /*!***************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/surveyoroverview/surveyoroverview.page.html ***!
    \***************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppSurveyoroverviewSurveyoroverviewPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\r\n  <ion-toolbar>\r\n    <ion-title>Home</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content [forceOverscroll]=\"false\">\r\n  <ion-tabs>\r\n    <ion-tab-bar slot=\"top\">\r\n      <ion-tab-button tab=\"newsurveys\">\r\n        <ion-label>Pending</ion-label>\r\n      </ion-tab-button>\r\n      <ion-tab-button tab=\"completedsurveys\">\r\n        <ion-label>Completed</ion-label>\r\n      </ion-tab-button>\r\n      <ion-tab-button tab=\"inreviewsurveys\">\r\n        <ion-label>Review</ion-label>\r\n      </ion-tab-button>\r\n      <ion-tab-button tab=\"deliveredsurveys\">\r\n        <ion-label>Delivered</ion-label>\r\n      </ion-tab-button>\r\n    </ion-tab-bar>\r\n  </ion-tabs>\r\n</ion-content>\r\n\r\n<ion-footer class=\"ion-no-border white-bg\">\r\n  <div class=\"position-relative\">\r\n    <ion-grid class=\"bottom-bar ion-no-margin ion-no-padding\">\r\n      <ion-row>\r\n        <ion-col size=\"4\">\r\n          <div class=\"tab\">\r\n            <ion-img src=\"/assets/images/home-outline.svg\" class=\"tab-icon\"></ion-img>\r\n            <span class=\"tabText\">Home</span>\r\n          </div>\r\n        </ion-col>\r\n        <ion-col size=\"4\" [routerLink]=\"['/message']\">\r\n          <div class=\"tab\">\r\n            <ion-img src=\"/assets/images/message-outline.svg\" class=\"tab-icon\"></ion-img>\r\n            <span class=\"tabText\">Messages</span>\r\n          </div>\r\n        </ion-col>\r\n        <ion-col size=\"4\" [routerLink]=\"['/profile']\" routerDirection=\"forward\">\r\n          <div class=\"tab\">\r\n            <ion-img src=\"/assets/images/account-outline.svg\" class=\"tab-icon\"></ion-img>\r\n            <span class=\"tabText\">Profile</span>\r\n          </div>\r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-grid>\r\n  </div>\r\n</ion-footer>";
    /***/
  },

  /***/
  "./src/app/email-model/email-model.page.scss":
  /*!***************************************************!*\
    !*** ./src/app/email-model/email-model.page.scss ***!
    \***************************************************/

  /*! exports provided: default */

  /***/
  function srcAppEmailModelEmailModelPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".listitem {\n  font-size: 12px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZW1haWwtbW9kZWwvRjpcXG1vYmlsZWFwcC9zcmNcXGFwcFxcZW1haWwtbW9kZWxcXGVtYWlsLW1vZGVsLnBhZ2Uuc2NzcyIsInNyYy9hcHAvZW1haWwtbW9kZWwvZW1haWwtbW9kZWwucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksZUFBQTtBQ0NKIiwiZmlsZSI6InNyYy9hcHAvZW1haWwtbW9kZWwvZW1haWwtbW9kZWwucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmxpc3RpdGVte1xyXG4gICAgZm9udC1zaXplOiAxMnB4O1xyXG59IiwiLmxpc3RpdGVtIHtcbiAgZm9udC1zaXplOiAxMnB4O1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/email-model/email-model.page.ts":
  /*!*************************************************!*\
    !*** ./src/app/email-model/email-model.page.ts ***!
    \*************************************************/

  /*! exports provided: EmailModelPage */

  /***/
  function srcAppEmailModelEmailModelPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "EmailModelPage", function () {
      return EmailModelPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var src_app_contants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! src/app/contants */
    "./src/app/contants.ts");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var src_app_utilities_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! src/app/utilities.service */
    "./src/app/utilities.service.ts");
    /* harmony import */


    var src_app_storage_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! src/app/storage.service */
    "./src/app/storage.service.ts");
    /* harmony import */


    var src_app_api_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! src/app/api.service */
    "./src/app/api.service.ts");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");

    var EmailModelPage = /*#__PURE__*/function () {
      function EmailModelPage(util, http, storage, api, modalctrl, nav) {
        _classCallCheck(this, EmailModelPage);

        this.util = util;
        this.http = http;
        this.storage = storage;
        this.api = api;
        this.modalctrl = modalctrl;
        this.nav = nav;
        this.example = [];
        this.teamMember = [];
        this.TeamData = [];
        this.bodyData = [];
        this.selectedEmails = [];
        this.resp = [];
        this.getTeamData();
      }

      _createClass(EmailModelPage, [{
        key: "validate",
        value: function validate(control) {
          throw new Error("Method not implemented.");
        }
      }, {
        key: "registerOnValidatorChange",
        value: function registerOnValidatorChange(fn) {
          throw new Error("Method not implemented.");
        }
      }, {
        key: "writeValue",
        value: function writeValue(obj) {
          throw new Error("Method not implemented.");
        }
      }, {
        key: "registerOnChange",
        value: function registerOnChange(fn) {
          throw new Error("Method not implemented.");
        }
      }, {
        key: "registerOnTouched",
        value: function registerOnTouched(fn) {
          throw new Error("Method not implemented.");
        }
      }, {
        key: "setDisabledState",
        value: function setDisabledState(isDisabled) {
          throw new Error("Method not implemented.");
        }
      }, {
        key: "ngOnInit",
        value: function ngOnInit() {
          this.id = this.nav.get('id');
          this.data = this.nav.get('designData');
          console.log("hello", this.data);
        }
      }, {
        key: "getTeamData",
        value: function getTeamData() {
          var _this = this;

          this.util.showLoading('Loading emails').then(function () {
            _this.api.getTeamData().subscribe(function (response) {
              _this.util.hideLoading().then(function () {
                _this.teamMember = response;
                _this.example = response;
                _this.TeamData = _this.example;
              });
            });
          });
        } //onCloseClick(){
        // this.dialogRef.close(this.data);
        // }

      }, {
        key: "selectAll",
        value: function selectAll(event) {
          debugger;
          var Checked = event.target.checked;
          this.TeamData.forEach(function (item) {
            return item.Checked = Checked;
          });
        }
      }, {
        key: "SendMail",
        value: function SendMail() {
          var _this2 = this;

          var emails = document.getElementById("inputemails").value;
          this.emailArray = emails.split(',');
          this.emailArray.forEach(function (element) {
            _this2.selectedEmails.push(element);
          });
          this.bodyData = this.TeamData.filter(function (item) {
            return item.Checked;
          });
          this.bodyData.forEach(function (element) {
            _this2.selectedEmails.push(element.email);
          });
          console.log(this.selectedEmails);
          var body = {
            emails: this.selectedEmails,
            id: this.id
          };
          return this.http.post(src_app_contants__WEBPACK_IMPORTED_MODULE_2__["BaseUrl"] + "designs/send-prelim-design", body, {
            headers: this.headers
          }).subscribe(function (response) {
            _this2.resp = response;

            if (_this2.resp.status == 'success') {
              _this2.util.showSnackBar("Email Sent  Successfully");

              _this2.modalctrl.dismiss({
                'dismissed': true
              }); // this.dialogRef.close( );

            }

            _this2.selectedEmails = [];
          }, function (error) {
            _this2.util.errorSnackBar("Something went wrong. Please try again.");

            _this2.selectedEmails = [];
          });
        }
      }, {
        key: "cancel",
        value: function cancel() {
          this.modalctrl.dismiss({
            'dismissed': true,
            cancel: 'cancel'
          });
        }
      }, {
        key: "checkedData",
        value: function checkedData(event) {
          console.log(event.target.checked);
        }
      }]);

      return EmailModelPage;
    }();

    EmailModelPage.ctorParameters = function () {
      return [{
        type: src_app_utilities_service__WEBPACK_IMPORTED_MODULE_4__["UtilitiesService"]
      }, {
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"]
      }, {
        type: src_app_storage_service__WEBPACK_IMPORTED_MODULE_5__["StorageService"]
      }, {
        type: src_app_api_service__WEBPACK_IMPORTED_MODULE_6__["ApiService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["ModalController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["NavParams"]
      }];
    };

    EmailModelPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-email-model',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./email-model.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/email-model/email-model.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./email-model.page.scss */
      "./src/app/email-model/email-model.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_utilities_service__WEBPACK_IMPORTED_MODULE_4__["UtilitiesService"], _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"], src_app_storage_service__WEBPACK_IMPORTED_MODULE_5__["StorageService"], src_app_api_service__WEBPACK_IMPORTED_MODULE_6__["ApiService"], _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["ModalController"], _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["NavParams"]])], EmailModelPage);
    /***/
  },

  /***/
  "./src/app/surveyoroverview/completedsurveys/completedsurveys.component.scss":
  /*!***********************************************************************************!*\
    !*** ./src/app/surveyoroverview/completedsurveys/completedsurveys.component.scss ***!
    \***********************************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppSurveyoroverviewCompletedsurveysCompletedsurveysComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".custom-card {\n  display: flex;\n  flex-direction: column;\n  background: white;\n  border-radius: 4px;\n  box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.3);\n  padding: 8px 12px;\n}\n\n.customer-name {\n  font-size: 1em;\n  color: #434343;\n  font-weight: bold;\n  display: table;\n  margin: 0px;\n}\n\n.customer-email {\n  font-size: 0.8em;\n  color: #B4B4B4;\n}\n\n.customer-phone {\n  font-size: 0.8em;\n  color: #4272B9;\n}\n\n.customer-address {\n  margin-top: 16px;\n  margin-bottom: 16px;\n  font-size: 0.8em;\n  color: #4272B9;\n}\n\n.timestamp {\n  font-size: 0.7em;\n}\n\n.chipdetail {\n  display: inline;\n  vertical-align: middle;\n  background-color: #95afc0;\n  font-size: 0.6em;\n  padding: 4px 10px;\n  border-radius: 10px;\n  text-align: center;\n  color: #fff;\n}\n\n.imagebutton {\n  float: right;\n  margin-top: 0px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc3VydmV5b3JvdmVydmlldy9jb21wbGV0ZWRzdXJ2ZXlzL0Y6XFxtb2JpbGVhcHAvc3JjXFxhcHBcXHN1cnZleW9yb3ZlcnZpZXdcXGNvbXBsZXRlZHN1cnZleXNcXGNvbXBsZXRlZHN1cnZleXMuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL3N1cnZleW9yb3ZlcnZpZXcvY29tcGxldGVkc3VydmV5cy9jb21wbGV0ZWRzdXJ2ZXlzLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksYUFBQTtFQUNBLHNCQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLDBDQUFBO0VBQ0EsaUJBQUE7QUNDSjs7QURFRTtFQUNFLGNBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0VBQ0EsV0FBQTtBQ0NKOztBREVFO0VBQ0UsZ0JBQUE7RUFDQSxjQUFBO0FDQ0o7O0FERUU7RUFDRSxnQkFBQTtFQUNBLGNBQUE7QUNDSjs7QURFRTtFQUNFLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7QUNDSjs7QURFRTtFQUNFLGdCQUFBO0FDQ0o7O0FERUU7RUFDRSxlQUFBO0VBQ0Esc0JBQUE7RUFDQSx5QkFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtBQ0NKOztBRENBO0VBQ0UsWUFBQTtFQUNBLGVBQUE7QUNFRiIsImZpbGUiOiJzcmMvYXBwL3N1cnZleW9yb3ZlcnZpZXcvY29tcGxldGVkc3VydmV5cy9jb21wbGV0ZWRzdXJ2ZXlzLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmN1c3RvbS1jYXJkIHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gICAgYmFja2dyb3VuZDogd2hpdGU7XHJcbiAgICBib3JkZXItcmFkaXVzOiA0cHg7XHJcbiAgICBib3gtc2hhZG93OiAwIDFweCAycHggMCByZ2JhKDAsIDAsIDAsIDAuMyk7XHJcbiAgICBwYWRkaW5nOiA4cHggMTJweDtcclxuICB9XHJcbiAgXHJcbiAgLmN1c3RvbWVyLW5hbWUge1xyXG4gICAgZm9udC1zaXplOiAxZW07XHJcbiAgICBjb2xvcjogIzQzNDM0MztcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgZGlzcGxheTp0YWJsZTtcclxuICAgIG1hcmdpbjogMHB4O1xyXG4gIH1cclxuICBcclxuICAuY3VzdG9tZXItZW1haWwge1xyXG4gICAgZm9udC1zaXplOiAwLjhlbTtcclxuICAgIGNvbG9yOiAjQjRCNEI0O1xyXG4gIH1cclxuICBcclxuICAuY3VzdG9tZXItcGhvbmUge1xyXG4gICAgZm9udC1zaXplOiAwLjhlbTtcclxuICAgIGNvbG9yOiAjNDI3MkI5O1xyXG4gIH1cclxuICBcclxuICAuY3VzdG9tZXItYWRkcmVzcyB7XHJcbiAgICBtYXJnaW4tdG9wOiAxNnB4O1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMTZweDtcclxuICAgIGZvbnQtc2l6ZTogMC44ZW07XHJcbiAgICBjb2xvcjogIzQyNzJCOTtcclxuICB9XHJcbiAgXHJcbiAgLnRpbWVzdGFtcCB7XHJcbiAgICBmb250LXNpemU6IDAuN2VtO1xyXG4gIH1cclxuICBcclxuICAuY2hpcGRldGFpbHtcclxuICAgIGRpc3BsYXk6IGlubGluZTtcclxuICAgIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjOTVhZmMwO1xyXG4gICAgZm9udC1zaXplOiAwLjZlbTtcclxuICAgIHBhZGRpbmc6IDRweCAxMHB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGNvbG9yOiAjZmZmO1xyXG59XHJcbi5pbWFnZWJ1dHRvbntcclxuICBmbG9hdDpyaWdodDtcclxuICBtYXJnaW4tdG9wOiAwcHg7XHJcbiAgXHJcbiAgXHJcbn0iLCIuY3VzdG9tLWNhcmQge1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICBiYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgYm9yZGVyLXJhZGl1czogNHB4O1xuICBib3gtc2hhZG93OiAwIDFweCAycHggMCByZ2JhKDAsIDAsIDAsIDAuMyk7XG4gIHBhZGRpbmc6IDhweCAxMnB4O1xufVxuXG4uY3VzdG9tZXItbmFtZSB7XG4gIGZvbnQtc2l6ZTogMWVtO1xuICBjb2xvcjogIzQzNDM0MztcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gIGRpc3BsYXk6IHRhYmxlO1xuICBtYXJnaW46IDBweDtcbn1cblxuLmN1c3RvbWVyLWVtYWlsIHtcbiAgZm9udC1zaXplOiAwLjhlbTtcbiAgY29sb3I6ICNCNEI0QjQ7XG59XG5cbi5jdXN0b21lci1waG9uZSB7XG4gIGZvbnQtc2l6ZTogMC44ZW07XG4gIGNvbG9yOiAjNDI3MkI5O1xufVxuXG4uY3VzdG9tZXItYWRkcmVzcyB7XG4gIG1hcmdpbi10b3A6IDE2cHg7XG4gIG1hcmdpbi1ib3R0b206IDE2cHg7XG4gIGZvbnQtc2l6ZTogMC44ZW07XG4gIGNvbG9yOiAjNDI3MkI5O1xufVxuXG4udGltZXN0YW1wIHtcbiAgZm9udC1zaXplOiAwLjdlbTtcbn1cblxuLmNoaXBkZXRhaWwge1xuICBkaXNwbGF5OiBpbmxpbmU7XG4gIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XG4gIGJhY2tncm91bmQtY29sb3I6ICM5NWFmYzA7XG4gIGZvbnQtc2l6ZTogMC42ZW07XG4gIHBhZGRpbmc6IDRweCAxMHB4O1xuICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGNvbG9yOiAjZmZmO1xufVxuXG4uaW1hZ2VidXR0b24ge1xuICBmbG9hdDogcmlnaHQ7XG4gIG1hcmdpbi10b3A6IDBweDtcbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/surveyoroverview/completedsurveys/completedsurveys.component.ts":
  /*!*********************************************************************************!*\
    !*** ./src/app/surveyoroverview/completedsurveys/completedsurveys.component.ts ***!
    \*********************************************************************************/

  /*! exports provided: CompletedsurveysComponent */

  /***/
  function srcAppSurveyoroverviewCompletedsurveysCompletedsurveysComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CompletedsurveysComponent", function () {
      return CompletedsurveysComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var src_app_homepage_survey_survey_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! src/app/homepage/survey/survey.component */
    "./src/app/homepage/survey/survey.component.ts");
    /* harmony import */


    var _ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic-native/launch-navigator/ngx */
    "./node_modules/@ionic-native/launch-navigator/ngx/index.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var src_app_utilities_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! src/app/utilities.service */
    "./src/app/utilities.service.ts");
    /* harmony import */


    var src_app_api_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! src/app/api.service */
    "./src/app/api.service.ts");
    /* harmony import */


    var _ionic_storage__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! @ionic/storage */
    "./node_modules/@ionic/storage/fesm2015/ionic-storage.js");
    /* harmony import */


    var moment__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! moment */
    "./node_modules/moment/moment.js");
    /* harmony import */


    var moment__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_8__);

    var CompletedsurveysComponent = /*#__PURE__*/function () {
      function CompletedsurveysComponent(launchNavigator, datePipe, cdr, utils, storage, apiService) {
        _classCallCheck(this, CompletedsurveysComponent);

        this.launchNavigator = launchNavigator;
        this.datePipe = datePipe;
        this.cdr = cdr;
        this.utils = utils;
        this.storage = storage;
        this.apiService = apiService;
        this.listOfSurveyData = [];
        this.listOfSurveyDataHelper = [];
        this.options = {
          start: '',
          app: this.launchNavigator.APP.GOOGLE_MAPS
        };
        console.log("inside new surveys");
        var latestDate = new Date();
        this.today = datePipe.transform(latestDate, 'M/dd/yy');
        console.log('date', this.today);
      }

      _createClass(CompletedsurveysComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this3 = this;

          this.surveyRefreshSubscription = this.utils.getHomepageSurveyRefresh().subscribe(function (result) {
            _this3.getSurveys(null);
          });
          this.dataRefreshSubscription = this.utils.getDataRefresh().subscribe(function (result) {
            if (_this3.listOfSurveyData != null && _this3.listOfSurveyData.length > 0) {
              _this3.formatSurveyData(_this3.listOfSurveyData);
            }
          });
        }
      }, {
        key: "getSurveys",
        value: function getSurveys(event) {
          var showLoader = true;

          if (event != null && event !== undefined) {
            showLoader = false;
          }

          this.fetchPendingSurveys(event, showLoader);
        }
      }, {
        key: "fetchPendingSurveys",
        value: function fetchPendingSurveys(event, showLoader) {
          var _this4 = this;

          console.log("inside fetch surveys");
          this.listOfSurveyData = [];
          this.listOfSurveyDataHelper = [];
          this.utils.showLoadingWithPullRefreshSupport(showLoader, 'Getting Surveys').then(function (success) {
            _this4.apiService.getSurveyorSurveys("status=surveycompleted").subscribe(function (response) {
              _this4.utils.hideLoadingWithPullRefreshSupport(showLoader).then(function () {
                console.log(response);

                _this4.formatSurveyData(response);

                if (event !== null) {
                  event.target.complete();
                }
              });
            }, function (responseError) {
              _this4.utils.hideLoadingWithPullRefreshSupport(showLoader).then(function () {
                if (event !== null) {
                  event.target.complete();
                }

                var error = responseError.error;

                _this4.utils.errorSnackBar(error.message[0].messages[0].message);
              });
            });
          });
        }
      }, {
        key: "openAddressOnMap",
        value: function openAddressOnMap(address) {
          this.launchNavigator.navigate(address, this.options);
        }
      }, {
        key: "formatSurveyData",
        value: function formatSurveyData(records) {
          var _this5 = this;

          this.listOfSurveyData = this.fillinDynamicData(records);
          var tempData = [];
          this.listOfSurveyData.forEach(function (surveyItem, i) {
            _this5.sDatePassed(surveyItem.datetime, i);

            surveyItem.lateby = _this5.overdue;

            if (tempData.length === 0) {
              var listOfSurvey = new src_app_homepage_survey_survey_component__WEBPACK_IMPORTED_MODULE_2__["SurveyDataHelper"]();
              listOfSurvey.date = _this5.datePipe.transform(surveyItem.datetime, 'M/d/yy');
              listOfSurvey.listOfSurveys.push(surveyItem);
              tempData.push(listOfSurvey);
            } else {
              var added = false;
              tempData.forEach(function (surveyList) {
                if (!added) {
                  if (surveyList.date === _this5.datePipe.transform(surveyItem.datetime, 'M/d/yy')) {
                    surveyList.listOfSurveys.push(surveyItem);
                    added = true;
                  }
                }
              });

              if (!added) {
                var _listOfSurvey = new src_app_homepage_survey_survey_component__WEBPACK_IMPORTED_MODULE_2__["SurveyDataHelper"]();

                _listOfSurvey.date = _this5.datePipe.transform(surveyItem.datetime, 'M/d/yy');

                _listOfSurvey.listOfSurveys.push(surveyItem);

                tempData.push(_listOfSurvey);
                added = true;
              }
            }
          });
          this.listOfSurveyDataHelper = tempData.sort(function (a, b) {
            var dateA = new Date(a.date).getTime(),
                dateB = new Date(b.date).getTime();
            return dateA - dateB;
          });
          this.cdr.detectChanges();
        }
      }, {
        key: "fillinDynamicData",
        value: function fillinDynamicData(records) {
          var _this6 = this;

          records.forEach(function (element) {
            element.formattedjobtype = _this6.utils.getJobTypeName(element.jobtype);

            _this6.storage.get('' + element.id).then(function (data) {
              console.log(data);

              if (data) {
                element.totalpercent = data.currentprogress;
              } else {
                element.totalpercent = 0;
              }
            });
          });
          return records;
        }
      }, {
        key: "sDatePassed",
        value: function sDatePassed(datestring, i) {
          var checkdate = moment__WEBPACK_IMPORTED_MODULE_8__(datestring, "YYYYMMDD");
          var todaydate = moment__WEBPACK_IMPORTED_MODULE_8__(new Date(), "YYYYMMDD");
          var lateby = todaydate.diff(checkdate, "days");
          this.overdue = lateby;
          console.log(this.overdue, ">>>>>>>>>>>>>>>>>.");
        }
      }]);

      return CompletedsurveysComponent;
    }();

    CompletedsurveysComponent.ctorParameters = function () {
      return [{
        type: _ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_3__["LaunchNavigator"]
      }, {
        type: _angular_common__WEBPACK_IMPORTED_MODULE_4__["DatePipe"]
      }, {
        type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"]
      }, {
        type: src_app_utilities_service__WEBPACK_IMPORTED_MODULE_5__["UtilitiesService"]
      }, {
        type: _ionic_storage__WEBPACK_IMPORTED_MODULE_7__["Storage"]
      }, {
        type: src_app_api_service__WEBPACK_IMPORTED_MODULE_6__["ApiService"]
      }];
    };

    CompletedsurveysComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-completedsurveys',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./completedsurveys.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/surveyoroverview/completedsurveys/completedsurveys.component.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./completedsurveys.component.scss */
      "./src/app/surveyoroverview/completedsurveys/completedsurveys.component.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_3__["LaunchNavigator"], _angular_common__WEBPACK_IMPORTED_MODULE_4__["DatePipe"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"], src_app_utilities_service__WEBPACK_IMPORTED_MODULE_5__["UtilitiesService"], _ionic_storage__WEBPACK_IMPORTED_MODULE_7__["Storage"], src_app_api_service__WEBPACK_IMPORTED_MODULE_6__["ApiService"]])], CompletedsurveysComponent);
    /***/
  },

  /***/
  "./src/app/surveyoroverview/deliveredsurveys/deliveredsurveys.component.scss":
  /*!***********************************************************************************!*\
    !*** ./src/app/surveyoroverview/deliveredsurveys/deliveredsurveys.component.scss ***!
    \***********************************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppSurveyoroverviewDeliveredsurveysDeliveredsurveysComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".custom-card {\n  display: flex;\n  flex-direction: column;\n  background: white;\n  border-radius: 4px;\n  box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.3);\n  padding: 8px 12px;\n}\n\n.customer-name {\n  font-size: 1em;\n  color: #434343;\n  font-weight: bold;\n  display: table;\n  margin: 0px;\n}\n\n.customer-email {\n  font-size: 0.8em;\n  color: #B4B4B4;\n}\n\n.customer-phone {\n  font-size: 0.8em;\n  color: #4272B9;\n}\n\n.customer-address {\n  margin-top: 16px;\n  margin-bottom: 16px;\n  font-size: 0.8em;\n  color: #4272B9;\n}\n\n.timestamp {\n  font-size: 0.7em;\n}\n\n.chipdetail {\n  display: inline;\n  vertical-align: middle;\n  background-color: #95afc0;\n  font-size: 0.6em;\n  padding: 4px 10px;\n  border-radius: 10px;\n  text-align: center;\n  color: #fff;\n}\n\n.imagebutton {\n  float: right;\n  margin-top: 0px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc3VydmV5b3JvdmVydmlldy9kZWxpdmVyZWRzdXJ2ZXlzL0Y6XFxtb2JpbGVhcHAvc3JjXFxhcHBcXHN1cnZleW9yb3ZlcnZpZXdcXGRlbGl2ZXJlZHN1cnZleXNcXGRlbGl2ZXJlZHN1cnZleXMuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL3N1cnZleW9yb3ZlcnZpZXcvZGVsaXZlcmVkc3VydmV5cy9kZWxpdmVyZWRzdXJ2ZXlzLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksYUFBQTtFQUNBLHNCQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLDBDQUFBO0VBQ0EsaUJBQUE7QUNDSjs7QURFRTtFQUNFLGNBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0VBQ0EsV0FBQTtBQ0NKOztBREVFO0VBQ0UsZ0JBQUE7RUFDQSxjQUFBO0FDQ0o7O0FERUU7RUFDRSxnQkFBQTtFQUNBLGNBQUE7QUNDSjs7QURFRTtFQUNFLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7QUNDSjs7QURFRTtFQUNFLGdCQUFBO0FDQ0o7O0FERUU7RUFDRSxlQUFBO0VBQ0Esc0JBQUE7RUFDQSx5QkFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtBQ0NKOztBRENBO0VBQ0UsWUFBQTtFQUNBLGVBQUE7QUNFRiIsImZpbGUiOiJzcmMvYXBwL3N1cnZleW9yb3ZlcnZpZXcvZGVsaXZlcmVkc3VydmV5cy9kZWxpdmVyZWRzdXJ2ZXlzLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmN1c3RvbS1jYXJkIHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gICAgYmFja2dyb3VuZDogd2hpdGU7XHJcbiAgICBib3JkZXItcmFkaXVzOiA0cHg7XHJcbiAgICBib3gtc2hhZG93OiAwIDFweCAycHggMCByZ2JhKDAsIDAsIDAsIDAuMyk7XHJcbiAgICBwYWRkaW5nOiA4cHggMTJweDtcclxuICB9XHJcbiAgXHJcbiAgLmN1c3RvbWVyLW5hbWUge1xyXG4gICAgZm9udC1zaXplOiAxZW07XHJcbiAgICBjb2xvcjogIzQzNDM0MztcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgZGlzcGxheTp0YWJsZTtcclxuICAgIG1hcmdpbjogMHB4O1xyXG4gIH1cclxuICBcclxuICAuY3VzdG9tZXItZW1haWwge1xyXG4gICAgZm9udC1zaXplOiAwLjhlbTtcclxuICAgIGNvbG9yOiAjQjRCNEI0O1xyXG4gIH1cclxuICBcclxuICAuY3VzdG9tZXItcGhvbmUge1xyXG4gICAgZm9udC1zaXplOiAwLjhlbTtcclxuICAgIGNvbG9yOiAjNDI3MkI5O1xyXG4gIH1cclxuICBcclxuICAuY3VzdG9tZXItYWRkcmVzcyB7XHJcbiAgICBtYXJnaW4tdG9wOiAxNnB4O1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMTZweDtcclxuICAgIGZvbnQtc2l6ZTogMC44ZW07XHJcbiAgICBjb2xvcjogIzQyNzJCOTtcclxuICB9XHJcbiAgXHJcbiAgLnRpbWVzdGFtcCB7XHJcbiAgICBmb250LXNpemU6IDAuN2VtO1xyXG4gIH1cclxuICBcclxuICAuY2hpcGRldGFpbHtcclxuICAgIGRpc3BsYXk6IGlubGluZTtcclxuICAgIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjOTVhZmMwO1xyXG4gICAgZm9udC1zaXplOiAwLjZlbTtcclxuICAgIHBhZGRpbmc6IDRweCAxMHB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGNvbG9yOiAjZmZmO1xyXG59XHJcbi5pbWFnZWJ1dHRvbntcclxuICBmbG9hdDpyaWdodDtcclxuICBtYXJnaW4tdG9wOiAwcHg7XHJcbiAgXHJcbiAgXHJcbn0iLCIuY3VzdG9tLWNhcmQge1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICBiYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgYm9yZGVyLXJhZGl1czogNHB4O1xuICBib3gtc2hhZG93OiAwIDFweCAycHggMCByZ2JhKDAsIDAsIDAsIDAuMyk7XG4gIHBhZGRpbmc6IDhweCAxMnB4O1xufVxuXG4uY3VzdG9tZXItbmFtZSB7XG4gIGZvbnQtc2l6ZTogMWVtO1xuICBjb2xvcjogIzQzNDM0MztcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gIGRpc3BsYXk6IHRhYmxlO1xuICBtYXJnaW46IDBweDtcbn1cblxuLmN1c3RvbWVyLWVtYWlsIHtcbiAgZm9udC1zaXplOiAwLjhlbTtcbiAgY29sb3I6ICNCNEI0QjQ7XG59XG5cbi5jdXN0b21lci1waG9uZSB7XG4gIGZvbnQtc2l6ZTogMC44ZW07XG4gIGNvbG9yOiAjNDI3MkI5O1xufVxuXG4uY3VzdG9tZXItYWRkcmVzcyB7XG4gIG1hcmdpbi10b3A6IDE2cHg7XG4gIG1hcmdpbi1ib3R0b206IDE2cHg7XG4gIGZvbnQtc2l6ZTogMC44ZW07XG4gIGNvbG9yOiAjNDI3MkI5O1xufVxuXG4udGltZXN0YW1wIHtcbiAgZm9udC1zaXplOiAwLjdlbTtcbn1cblxuLmNoaXBkZXRhaWwge1xuICBkaXNwbGF5OiBpbmxpbmU7XG4gIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XG4gIGJhY2tncm91bmQtY29sb3I6ICM5NWFmYzA7XG4gIGZvbnQtc2l6ZTogMC42ZW07XG4gIHBhZGRpbmc6IDRweCAxMHB4O1xuICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGNvbG9yOiAjZmZmO1xufVxuXG4uaW1hZ2VidXR0b24ge1xuICBmbG9hdDogcmlnaHQ7XG4gIG1hcmdpbi10b3A6IDBweDtcbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/surveyoroverview/deliveredsurveys/deliveredsurveys.component.ts":
  /*!*********************************************************************************!*\
    !*** ./src/app/surveyoroverview/deliveredsurveys/deliveredsurveys.component.ts ***!
    \*********************************************************************************/

  /*! exports provided: DeliveredsurveysComponent */

  /***/
  function srcAppSurveyoroverviewDeliveredsurveysDeliveredsurveysComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DeliveredsurveysComponent", function () {
      return DeliveredsurveysComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var src_app_homepage_survey_survey_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! src/app/homepage/survey/survey.component */
    "./src/app/homepage/survey/survey.component.ts");
    /* harmony import */


    var _ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic-native/launch-navigator/ngx */
    "./node_modules/@ionic-native/launch-navigator/ngx/index.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var src_app_utilities_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! src/app/utilities.service */
    "./src/app/utilities.service.ts");
    /* harmony import */


    var src_app_api_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! src/app/api.service */
    "./src/app/api.service.ts");
    /* harmony import */


    var _ionic_storage__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! @ionic/storage */
    "./node_modules/@ionic/storage/fesm2015/ionic-storage.js");
    /* harmony import */


    var moment__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! moment */
    "./node_modules/moment/moment.js");
    /* harmony import */


    var moment__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_8__);

    var DeliveredsurveysComponent = /*#__PURE__*/function () {
      function DeliveredsurveysComponent(launchNavigator, datePipe, cdr, utils, storage, apiService) {
        _classCallCheck(this, DeliveredsurveysComponent);

        this.launchNavigator = launchNavigator;
        this.datePipe = datePipe;
        this.cdr = cdr;
        this.utils = utils;
        this.storage = storage;
        this.apiService = apiService;
        this.listOfSurveyData = [];
        this.listOfSurveyDataHelper = [];
        this.options = {
          start: '',
          app: this.launchNavigator.APP.GOOGLE_MAPS
        };
        console.log("inside new surveys");
        var latestDate = new Date();
        this.today = datePipe.transform(latestDate, 'M/dd/yy');
        console.log('date', this.today);
      }

      _createClass(DeliveredsurveysComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this7 = this;

          this.surveyRefreshSubscription = this.utils.getHomepageSurveyRefresh().subscribe(function (result) {
            _this7.getSurveys(null);
          });
          this.dataRefreshSubscription = this.utils.getDataRefresh().subscribe(function (result) {
            if (_this7.listOfSurveyData != null && _this7.listOfSurveyData.length > 0) {
              _this7.formatSurveyData(_this7.listOfSurveyData);
            }
          });
        }
      }, {
        key: "getSurveys",
        value: function getSurveys(event) {
          var showLoader = true;

          if (event != null && event !== undefined) {
            showLoader = false;
          }

          this.fetchPendingSurveys(event, showLoader);
        }
      }, {
        key: "fetchPendingSurveys",
        value: function fetchPendingSurveys(event, showLoader) {
          var _this8 = this;

          console.log("inside fetch surveys");
          this.listOfSurveyData = [];
          this.listOfSurveyDataHelper = [];
          this.utils.showLoadingWithPullRefreshSupport(showLoader, 'Getting Surveys').then(function (success) {
            _this8.apiService.getSurveyorSurveys("status=delivered").subscribe(function (response) {
              _this8.utils.hideLoadingWithPullRefreshSupport(showLoader).then(function () {
                console.log(response);

                _this8.formatSurveyData(response);

                if (event !== null) {
                  event.target.complete();
                }
              });
            }, function (responseError) {
              _this8.utils.hideLoadingWithPullRefreshSupport(showLoader).then(function () {
                if (event !== null) {
                  event.target.complete();
                }

                var error = responseError.error;

                _this8.utils.errorSnackBar(error.message[0].messages[0].message);
              });
            });
          });
        }
      }, {
        key: "openAddressOnMap",
        value: function openAddressOnMap(address) {
          this.launchNavigator.navigate(address, this.options);
        }
      }, {
        key: "formatSurveyData",
        value: function formatSurveyData(records) {
          var _this9 = this;

          this.listOfSurveyData = this.fillinDynamicData(records);
          var tempData = [];
          this.listOfSurveyData.forEach(function (surveyItem, i) {
            _this9.sDatePassed(surveyItem.datetime, i);

            surveyItem.lateby = _this9.overdue;

            if (tempData.length === 0) {
              var listOfSurvey = new src_app_homepage_survey_survey_component__WEBPACK_IMPORTED_MODULE_2__["SurveyDataHelper"]();
              listOfSurvey.date = _this9.datePipe.transform(surveyItem.datetime, 'M/d/yy');
              listOfSurvey.listOfSurveys.push(surveyItem);
              tempData.push(listOfSurvey);
            } else {
              var added = false;
              tempData.forEach(function (surveyList) {
                if (!added) {
                  if (surveyList.date === _this9.datePipe.transform(surveyItem.datetime, 'M/d/yy')) {
                    surveyList.listOfSurveys.push(surveyItem);
                    added = true;
                  }
                }
              });

              if (!added) {
                var _listOfSurvey2 = new src_app_homepage_survey_survey_component__WEBPACK_IMPORTED_MODULE_2__["SurveyDataHelper"]();

                _listOfSurvey2.date = _this9.datePipe.transform(surveyItem.datetime, 'M/d/yy');

                _listOfSurvey2.listOfSurveys.push(surveyItem);

                tempData.push(_listOfSurvey2);
                added = true;
              }
            }
          });
          this.listOfSurveyDataHelper = tempData.sort(function (a, b) {
            var dateA = new Date(a.date).getTime(),
                dateB = new Date(b.date).getTime();
            return dateA - dateB;
          });
          this.cdr.detectChanges();
        }
      }, {
        key: "fillinDynamicData",
        value: function fillinDynamicData(records) {
          var _this10 = this;

          records.forEach(function (element) {
            element.formattedjobtype = _this10.utils.getJobTypeName(element.jobtype);

            _this10.storage.get('' + element.id).then(function (data) {
              console.log(data);

              if (data) {
                element.totalpercent = data.currentprogress;
              } else {
                element.totalpercent = 0;
              }
            });
          });
          return records;
        }
      }, {
        key: "sDatePassed",
        value: function sDatePassed(datestring, i) {
          var checkdate = moment__WEBPACK_IMPORTED_MODULE_8__(datestring, "YYYYMMDD");
          var todaydate = moment__WEBPACK_IMPORTED_MODULE_8__(new Date(), "YYYYMMDD");
          var lateby = todaydate.diff(checkdate, "days");
          this.overdue = lateby;
          console.log(this.overdue, ">>>>>>>>>>>>>>>>>.");
        }
      }]);

      return DeliveredsurveysComponent;
    }();

    DeliveredsurveysComponent.ctorParameters = function () {
      return [{
        type: _ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_3__["LaunchNavigator"]
      }, {
        type: _angular_common__WEBPACK_IMPORTED_MODULE_4__["DatePipe"]
      }, {
        type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"]
      }, {
        type: src_app_utilities_service__WEBPACK_IMPORTED_MODULE_5__["UtilitiesService"]
      }, {
        type: _ionic_storage__WEBPACK_IMPORTED_MODULE_7__["Storage"]
      }, {
        type: src_app_api_service__WEBPACK_IMPORTED_MODULE_6__["ApiService"]
      }];
    };

    DeliveredsurveysComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-deliveredsurveys',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./deliveredsurveys.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/surveyoroverview/deliveredsurveys/deliveredsurveys.component.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./deliveredsurveys.component.scss */
      "./src/app/surveyoroverview/deliveredsurveys/deliveredsurveys.component.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_3__["LaunchNavigator"], _angular_common__WEBPACK_IMPORTED_MODULE_4__["DatePipe"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"], src_app_utilities_service__WEBPACK_IMPORTED_MODULE_5__["UtilitiesService"], _ionic_storage__WEBPACK_IMPORTED_MODULE_7__["Storage"], src_app_api_service__WEBPACK_IMPORTED_MODULE_6__["ApiService"]])], DeliveredsurveysComponent);
    /***/
  },

  /***/
  "./src/app/surveyoroverview/inreviewsurveys/inreviewsurveys.component.scss":
  /*!*********************************************************************************!*\
    !*** ./src/app/surveyoroverview/inreviewsurveys/inreviewsurveys.component.scss ***!
    \*********************************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppSurveyoroverviewInreviewsurveysInreviewsurveysComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".custom-card {\n  display: flex;\n  flex-direction: column;\n  background: white;\n  border-radius: 4px;\n  box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.3);\n  padding: 8px 12px;\n}\n\n.customer-name {\n  font-size: 1em;\n  color: #434343;\n  font-weight: bold;\n  display: table;\n  margin: 0px;\n}\n\n.customer-email {\n  font-size: 0.8em;\n  color: #B4B4B4;\n}\n\n.customer-phone {\n  font-size: 0.8em;\n  color: #4272B9;\n}\n\n.customer-address {\n  margin-top: 16px;\n  margin-bottom: 16px;\n  font-size: 0.8em;\n  color: #4272B9;\n}\n\n.timestamp {\n  font-size: 0.7em;\n}\n\n.chipdetail {\n  display: inline;\n  vertical-align: middle;\n  background-color: #95afc0;\n  font-size: 0.6em;\n  padding: 4px 10px;\n  border-radius: 10px;\n  text-align: center;\n  color: #fff;\n}\n\n.imagebutton {\n  float: right;\n  margin-top: 0px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc3VydmV5b3JvdmVydmlldy9pbnJldmlld3N1cnZleXMvRjpcXG1vYmlsZWFwcC9zcmNcXGFwcFxcc3VydmV5b3JvdmVydmlld1xcaW5yZXZpZXdzdXJ2ZXlzXFxpbnJldmlld3N1cnZleXMuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL3N1cnZleW9yb3ZlcnZpZXcvaW5yZXZpZXdzdXJ2ZXlzL2lucmV2aWV3c3VydmV5cy5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGFBQUE7RUFDQSxzQkFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSwwQ0FBQTtFQUNBLGlCQUFBO0FDQ0o7O0FERUU7RUFDRSxjQUFBO0VBQ0EsY0FBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtFQUNBLFdBQUE7QUNDSjs7QURFRTtFQUNFLGdCQUFBO0VBQ0EsY0FBQTtBQ0NKOztBREVFO0VBQ0UsZ0JBQUE7RUFDQSxjQUFBO0FDQ0o7O0FERUU7RUFDRSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0FDQ0o7O0FERUU7RUFDRSxnQkFBQTtBQ0NKOztBREVFO0VBQ0UsZUFBQTtFQUNBLHNCQUFBO0VBQ0EseUJBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7QUNDSjs7QURDQTtFQUNFLFlBQUE7RUFDQSxlQUFBO0FDRUYiLCJmaWxlIjoic3JjL2FwcC9zdXJ2ZXlvcm92ZXJ2aWV3L2lucmV2aWV3c3VydmV5cy9pbnJldmlld3N1cnZleXMuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY3VzdG9tLWNhcmQge1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgICBiYWNrZ3JvdW5kOiB3aGl0ZTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDRweDtcclxuICAgIGJveC1zaGFkb3c6IDAgMXB4IDJweCAwIHJnYmEoMCwgMCwgMCwgMC4zKTtcclxuICAgIHBhZGRpbmc6IDhweCAxMnB4O1xyXG4gIH1cclxuICBcclxuICAuY3VzdG9tZXItbmFtZSB7XHJcbiAgICBmb250LXNpemU6IDFlbTtcclxuICAgIGNvbG9yOiAjNDM0MzQzO1xyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICBkaXNwbGF5OnRhYmxlO1xyXG4gICAgbWFyZ2luOiAwcHg7XHJcbiAgfVxyXG4gIFxyXG4gIC5jdXN0b21lci1lbWFpbCB7XHJcbiAgICBmb250LXNpemU6IDAuOGVtO1xyXG4gICAgY29sb3I6ICNCNEI0QjQ7XHJcbiAgfVxyXG4gIFxyXG4gIC5jdXN0b21lci1waG9uZSB7XHJcbiAgICBmb250LXNpemU6IDAuOGVtO1xyXG4gICAgY29sb3I6ICM0MjcyQjk7XHJcbiAgfVxyXG4gIFxyXG4gIC5jdXN0b21lci1hZGRyZXNzIHtcclxuICAgIG1hcmdpbi10b3A6IDE2cHg7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAxNnB4O1xyXG4gICAgZm9udC1zaXplOiAwLjhlbTtcclxuICAgIGNvbG9yOiAjNDI3MkI5O1xyXG4gIH1cclxuICBcclxuICAudGltZXN0YW1wIHtcclxuICAgIGZvbnQtc2l6ZTogMC43ZW07XHJcbiAgfVxyXG4gIFxyXG4gIC5jaGlwZGV0YWlse1xyXG4gICAgZGlzcGxheTogaW5saW5lO1xyXG4gICAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICM5NWFmYzA7XHJcbiAgICBmb250LXNpemU6IDAuNmVtO1xyXG4gICAgcGFkZGluZzogNHB4IDEwcHg7XHJcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgY29sb3I6ICNmZmY7XHJcbn1cclxuLmltYWdlYnV0dG9ue1xyXG4gIGZsb2F0OnJpZ2h0O1xyXG4gIG1hcmdpbi10b3A6IDBweDtcclxuICBcclxuICBcclxufSIsIi5jdXN0b20tY2FyZCB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gIGJhY2tncm91bmQ6IHdoaXRlO1xuICBib3JkZXItcmFkaXVzOiA0cHg7XG4gIGJveC1zaGFkb3c6IDAgMXB4IDJweCAwIHJnYmEoMCwgMCwgMCwgMC4zKTtcbiAgcGFkZGluZzogOHB4IDEycHg7XG59XG5cbi5jdXN0b21lci1uYW1lIHtcbiAgZm9udC1zaXplOiAxZW07XG4gIGNvbG9yOiAjNDM0MzQzO1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgZGlzcGxheTogdGFibGU7XG4gIG1hcmdpbjogMHB4O1xufVxuXG4uY3VzdG9tZXItZW1haWwge1xuICBmb250LXNpemU6IDAuOGVtO1xuICBjb2xvcjogI0I0QjRCNDtcbn1cblxuLmN1c3RvbWVyLXBob25lIHtcbiAgZm9udC1zaXplOiAwLjhlbTtcbiAgY29sb3I6ICM0MjcyQjk7XG59XG5cbi5jdXN0b21lci1hZGRyZXNzIHtcbiAgbWFyZ2luLXRvcDogMTZweDtcbiAgbWFyZ2luLWJvdHRvbTogMTZweDtcbiAgZm9udC1zaXplOiAwLjhlbTtcbiAgY29sb3I6ICM0MjcyQjk7XG59XG5cbi50aW1lc3RhbXAge1xuICBmb250LXNpemU6IDAuN2VtO1xufVxuXG4uY2hpcGRldGFpbCB7XG4gIGRpc3BsYXk6IGlubGluZTtcbiAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzk1YWZjMDtcbiAgZm9udC1zaXplOiAwLjZlbTtcbiAgcGFkZGluZzogNHB4IDEwcHg7XG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgY29sb3I6ICNmZmY7XG59XG5cbi5pbWFnZWJ1dHRvbiB7XG4gIGZsb2F0OiByaWdodDtcbiAgbWFyZ2luLXRvcDogMHB4O1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/surveyoroverview/inreviewsurveys/inreviewsurveys.component.ts":
  /*!*******************************************************************************!*\
    !*** ./src/app/surveyoroverview/inreviewsurveys/inreviewsurveys.component.ts ***!
    \*******************************************************************************/

  /*! exports provided: InreviewsurveysComponent */

  /***/
  function srcAppSurveyoroverviewInreviewsurveysInreviewsurveysComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "InreviewsurveysComponent", function () {
      return InreviewsurveysComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var src_app_homepage_survey_survey_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! src/app/homepage/survey/survey.component */
    "./src/app/homepage/survey/survey.component.ts");
    /* harmony import */


    var _ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic-native/launch-navigator/ngx */
    "./node_modules/@ionic-native/launch-navigator/ngx/index.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var src_app_utilities_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! src/app/utilities.service */
    "./src/app/utilities.service.ts");
    /* harmony import */


    var src_app_api_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! src/app/api.service */
    "./src/app/api.service.ts");
    /* harmony import */


    var _ionic_storage__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! @ionic/storage */
    "./node_modules/@ionic/storage/fesm2015/ionic-storage.js");
    /* harmony import */


    var moment__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! moment */
    "./node_modules/moment/moment.js");
    /* harmony import */


    var moment__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_8__);

    var InreviewsurveysComponent = /*#__PURE__*/function () {
      function InreviewsurveysComponent(launchNavigator, datePipe, cdr, utils, storage, apiService) {
        _classCallCheck(this, InreviewsurveysComponent);

        this.launchNavigator = launchNavigator;
        this.datePipe = datePipe;
        this.cdr = cdr;
        this.utils = utils;
        this.storage = storage;
        this.apiService = apiService;
        this.listOfSurveyData = [];
        this.listOfSurveyDataHelper = [];
        this.options = {
          start: '',
          app: this.launchNavigator.APP.GOOGLE_MAPS
        };
        var latestDate = new Date();
        this.today = datePipe.transform(latestDate, 'M/dd/yy');
        console.log('date', this.today);
      }

      _createClass(InreviewsurveysComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this11 = this;

          this.surveyRefreshSubscription = this.utils.getHomepageSurveyRefresh().subscribe(function (result) {
            _this11.getSurveys(null);
          });
          this.dataRefreshSubscription = this.utils.getDataRefresh().subscribe(function (result) {
            if (_this11.listOfSurveyData != null && _this11.listOfSurveyData.length > 0) {
              _this11.formatSurveyData(_this11.listOfSurveyData);
            }
          });
        }
      }, {
        key: "getSurveys",
        value: function getSurveys(event) {
          var showLoader = true;

          if (event != null && event !== undefined) {
            showLoader = false;
          }

          this.fetchPendingSurveys(event, showLoader);
        }
      }, {
        key: "fetchPendingSurveys",
        value: function fetchPendingSurveys(event, showLoader) {
          var _this12 = this;

          console.log("inside fetch surveys");
          this.listOfSurveyData = [];
          this.listOfSurveyDataHelper = [];
          this.utils.showLoadingWithPullRefreshSupport(showLoader, 'Getting Surveys').then(function (success) {
            _this12.apiService.getSurveyorSurveys("status=reviewassigned&status=reviewfailed&status=reviewpassed").subscribe(function (response) {
              _this12.utils.hideLoadingWithPullRefreshSupport(showLoader).then(function () {
                console.log(response);

                _this12.formatSurveyData(response);

                if (event !== null) {
                  event.target.complete();
                }
              });
            }, function (responseError) {
              _this12.utils.hideLoadingWithPullRefreshSupport(showLoader).then(function () {
                if (event !== null) {
                  event.target.complete();
                }

                var error = responseError.error;

                _this12.utils.errorSnackBar(error.message[0].messages[0].message);
              });
            });
          });
        }
      }, {
        key: "openAddressOnMap",
        value: function openAddressOnMap(address) {
          this.launchNavigator.navigate(address, this.options);
        }
      }, {
        key: "formatSurveyData",
        value: function formatSurveyData(records) {
          var _this13 = this;

          this.listOfSurveyData = this.fillinDynamicData(records);
          var tempData = [];
          this.listOfSurveyData.forEach(function (surveyItem, i) {
            _this13.sDatePassed(surveyItem.datetime, i);

            surveyItem.lateby = _this13.overdue;

            if (tempData.length === 0) {
              var listOfSurvey = new src_app_homepage_survey_survey_component__WEBPACK_IMPORTED_MODULE_2__["SurveyDataHelper"]();
              listOfSurvey.date = _this13.datePipe.transform(surveyItem.datetime, 'M/d/yy');
              listOfSurvey.listOfSurveys.push(surveyItem);
              tempData.push(listOfSurvey);
            } else {
              var added = false;
              tempData.forEach(function (surveyList) {
                if (!added) {
                  if (surveyList.date === _this13.datePipe.transform(surveyItem.datetime, 'M/d/yy')) {
                    surveyList.listOfSurveys.push(surveyItem);
                    added = true;
                  }
                }
              });

              if (!added) {
                var _listOfSurvey3 = new src_app_homepage_survey_survey_component__WEBPACK_IMPORTED_MODULE_2__["SurveyDataHelper"]();

                _listOfSurvey3.date = _this13.datePipe.transform(surveyItem.datetime, 'M/d/yy');

                _listOfSurvey3.listOfSurveys.push(surveyItem);

                tempData.push(_listOfSurvey3);
                added = true;
              }
            }
          });
          this.listOfSurveyDataHelper = tempData.sort(function (a, b) {
            var dateA = new Date(a.date).getTime(),
                dateB = new Date(b.date).getTime();
            return dateA - dateB;
          });
          this.cdr.detectChanges();
        }
      }, {
        key: "fillinDynamicData",
        value: function fillinDynamicData(records) {
          var _this14 = this;

          records.forEach(function (element) {
            element.formattedjobtype = _this14.utils.getJobTypeName(element.jobtype);

            _this14.storage.get('' + element.id).then(function (data) {
              console.log(data);

              if (data) {
                element.totalpercent = data.currentprogress;
              } else {
                element.totalpercent = 0;
              }
            });
          });
          return records;
        }
      }, {
        key: "sDatePassed",
        value: function sDatePassed(datestring, i) {
          var checkdate = moment__WEBPACK_IMPORTED_MODULE_8__(datestring, "YYYYMMDD");
          var todaydate = moment__WEBPACK_IMPORTED_MODULE_8__(new Date(), "YYYYMMDD");
          var lateby = todaydate.diff(checkdate, "days");
          this.overdue = lateby;
          console.log(this.overdue, ">>>>>>>>>>>>>>>>>.");
        }
      }]);

      return InreviewsurveysComponent;
    }();

    InreviewsurveysComponent.ctorParameters = function () {
      return [{
        type: _ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_3__["LaunchNavigator"]
      }, {
        type: _angular_common__WEBPACK_IMPORTED_MODULE_4__["DatePipe"]
      }, {
        type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"]
      }, {
        type: src_app_utilities_service__WEBPACK_IMPORTED_MODULE_5__["UtilitiesService"]
      }, {
        type: _ionic_storage__WEBPACK_IMPORTED_MODULE_7__["Storage"]
      }, {
        type: src_app_api_service__WEBPACK_IMPORTED_MODULE_6__["ApiService"]
      }];
    };

    InreviewsurveysComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-inreviewsurveys',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./inreviewsurveys.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/surveyoroverview/inreviewsurveys/inreviewsurveys.component.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./inreviewsurveys.component.scss */
      "./src/app/surveyoroverview/inreviewsurveys/inreviewsurveys.component.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_3__["LaunchNavigator"], _angular_common__WEBPACK_IMPORTED_MODULE_4__["DatePipe"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"], src_app_utilities_service__WEBPACK_IMPORTED_MODULE_5__["UtilitiesService"], _ionic_storage__WEBPACK_IMPORTED_MODULE_7__["Storage"], src_app_api_service__WEBPACK_IMPORTED_MODULE_6__["ApiService"]])], InreviewsurveysComponent);
    /***/
  },

  /***/
  "./src/app/surveyoroverview/newsurveys/newsurveys.component.scss":
  /*!***********************************************************************!*\
    !*** ./src/app/surveyoroverview/newsurveys/newsurveys.component.scss ***!
    \***********************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppSurveyoroverviewNewsurveysNewsurveysComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".custom-card {\n  display: flex;\n  flex-direction: column;\n  background: #fff;\n  border-radius: 4px;\n  box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.3);\n  padding: 8px 12px;\n}\n\n.customer-name {\n  font-size: 1em;\n  color: #434343;\n  font-weight: bold;\n  display: table;\n  margin: 0px;\n}\n\n.customer-email {\n  font-size: 0.8em;\n  color: #B4B4B4;\n}\n\n.customer-phone {\n  font-size: 0.8em;\n  color: #4272B9;\n}\n\n.customer-address {\n  margin-top: 16px;\n  margin-bottom: 16px;\n  font-size: 0.8em;\n  color: #4272B9;\n}\n\n.timestamp {\n  font-size: 0.7em;\n}\n\n.chipdetail {\n  display: inline;\n  vertical-align: middle;\n  background-color: #95afc0;\n  font-size: 0.6em;\n  padding: 4px 10px;\n  border-radius: 10px;\n  text-align: center;\n  color: #fff;\n}\n\n.latebystyle {\n  float: right;\n  font-size: 10px;\n  color: #3C78DB;\n  text-align: right;\n}\n\n.imagebutton {\n  float: right;\n  margin-top: 0px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc3VydmV5b3JvdmVydmlldy9uZXdzdXJ2ZXlzL0Y6XFxtb2JpbGVhcHAvc3JjXFxhcHBcXHN1cnZleW9yb3ZlcnZpZXdcXG5ld3N1cnZleXNcXG5ld3N1cnZleXMuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL3N1cnZleW9yb3ZlcnZpZXcvbmV3c3VydmV5cy9uZXdzdXJ2ZXlzLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksYUFBQTtFQUNBLHNCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLDBDQUFBO0VBQ0EsaUJBQUE7QUNDSjs7QURFRTtFQUNFLGNBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0VBQ0EsV0FBQTtBQ0NKOztBREVFO0VBQ0UsZ0JBQUE7RUFDQSxjQUFBO0FDQ0o7O0FERUU7RUFDRSxnQkFBQTtFQUNBLGNBQUE7QUNDSjs7QURFRTtFQUNFLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7QUNDSjs7QURFRTtFQUNFLGdCQUFBO0FDQ0o7O0FERUU7RUFDRSxlQUFBO0VBQ0Esc0JBQUE7RUFDQSx5QkFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtBQ0NKOztBREVBO0VBQ0UsWUFBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7QUNDRjs7QURDQTtFQUNFLFlBQUE7RUFDQSxlQUFBO0FDRUYiLCJmaWxlIjoic3JjL2FwcC9zdXJ2ZXlvcm92ZXJ2aWV3L25ld3N1cnZleXMvbmV3c3VydmV5cy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jdXN0b20tY2FyZCB7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICAgIGJhY2tncm91bmQ6ICNmZmY7XHJcbiAgICBib3JkZXItcmFkaXVzOiA0cHg7XHJcbiAgICBib3gtc2hhZG93OiAwIDFweCAycHggMCByZ2JhKDAsIDAsIDAsIDAuMyk7XHJcbiAgICBwYWRkaW5nOiA4cHggMTJweDtcclxuICB9XHJcbiAgXHJcbiAgLmN1c3RvbWVyLW5hbWUge1xyXG4gICAgZm9udC1zaXplOiAxZW07XHJcbiAgICBjb2xvcjogIzQzNDM0MztcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgZGlzcGxheTp0YWJsZTtcclxuICAgIG1hcmdpbjogMHB4O1xyXG4gIH1cclxuICBcclxuICAuY3VzdG9tZXItZW1haWwge1xyXG4gICAgZm9udC1zaXplOiAwLjhlbTtcclxuICAgIGNvbG9yOiAjQjRCNEI0O1xyXG4gIH1cclxuICBcclxuICAuY3VzdG9tZXItcGhvbmUge1xyXG4gICAgZm9udC1zaXplOiAwLjhlbTtcclxuICAgIGNvbG9yOiAjNDI3MkI5O1xyXG4gIH1cclxuICBcclxuICAuY3VzdG9tZXItYWRkcmVzcyB7XHJcbiAgICBtYXJnaW4tdG9wOiAxNnB4O1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMTZweDtcclxuICAgIGZvbnQtc2l6ZTogMC44ZW07XHJcbiAgICBjb2xvcjogIzQyNzJCOTtcclxuICB9XHJcbiAgXHJcbiAgLnRpbWVzdGFtcCB7XHJcbiAgICBmb250LXNpemU6IDAuN2VtO1xyXG4gIH1cclxuICBcclxuICAuY2hpcGRldGFpbHtcclxuICAgIGRpc3BsYXk6IGlubGluZTtcclxuICAgIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjOTVhZmMwO1xyXG4gICAgZm9udC1zaXplOiAwLjZlbTtcclxuICAgIHBhZGRpbmc6IDRweCAxMHB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGNvbG9yOiAjZmZmO1xyXG59XHJcblxyXG4ubGF0ZWJ5c3R5bGV7XHJcbiAgZmxvYXQ6IHJpZ2h0OyBcclxuICBmb250LXNpemU6IDEwcHg7XHJcbiAgY29sb3I6ICMzQzc4REI7XHJcbiAgdGV4dC1hbGlnbjogcmlnaHQ7XHJcbn1cclxuLmltYWdlYnV0dG9ue1xyXG4gIGZsb2F0OnJpZ2h0O1xyXG4gIG1hcmdpbi10b3A6IDBweDtcclxuICBcclxuICBcclxufSIsIi5jdXN0b20tY2FyZCB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gIGJhY2tncm91bmQ6ICNmZmY7XG4gIGJvcmRlci1yYWRpdXM6IDRweDtcbiAgYm94LXNoYWRvdzogMCAxcHggMnB4IDAgcmdiYSgwLCAwLCAwLCAwLjMpO1xuICBwYWRkaW5nOiA4cHggMTJweDtcbn1cblxuLmN1c3RvbWVyLW5hbWUge1xuICBmb250LXNpemU6IDFlbTtcbiAgY29sb3I6ICM0MzQzNDM7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICBkaXNwbGF5OiB0YWJsZTtcbiAgbWFyZ2luOiAwcHg7XG59XG5cbi5jdXN0b21lci1lbWFpbCB7XG4gIGZvbnQtc2l6ZTogMC44ZW07XG4gIGNvbG9yOiAjQjRCNEI0O1xufVxuXG4uY3VzdG9tZXItcGhvbmUge1xuICBmb250LXNpemU6IDAuOGVtO1xuICBjb2xvcjogIzQyNzJCOTtcbn1cblxuLmN1c3RvbWVyLWFkZHJlc3Mge1xuICBtYXJnaW4tdG9wOiAxNnB4O1xuICBtYXJnaW4tYm90dG9tOiAxNnB4O1xuICBmb250LXNpemU6IDAuOGVtO1xuICBjb2xvcjogIzQyNzJCOTtcbn1cblxuLnRpbWVzdGFtcCB7XG4gIGZvbnQtc2l6ZTogMC43ZW07XG59XG5cbi5jaGlwZGV0YWlsIHtcbiAgZGlzcGxheTogaW5saW5lO1xuICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjOTVhZmMwO1xuICBmb250LXNpemU6IDAuNmVtO1xuICBwYWRkaW5nOiA0cHggMTBweDtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBjb2xvcjogI2ZmZjtcbn1cblxuLmxhdGVieXN0eWxlIHtcbiAgZmxvYXQ6IHJpZ2h0O1xuICBmb250LXNpemU6IDEwcHg7XG4gIGNvbG9yOiAjM0M3OERCO1xuICB0ZXh0LWFsaWduOiByaWdodDtcbn1cblxuLmltYWdlYnV0dG9uIHtcbiAgZmxvYXQ6IHJpZ2h0O1xuICBtYXJnaW4tdG9wOiAwcHg7XG59Il19 */";
    /***/
  },

  /***/
  "./src/app/surveyoroverview/newsurveys/newsurveys.component.ts":
  /*!*********************************************************************!*\
    !*** ./src/app/surveyoroverview/newsurveys/newsurveys.component.ts ***!
    \*********************************************************************/

  /*! exports provided: NewsurveysComponent */

  /***/
  function srcAppSurveyoroverviewNewsurveysNewsurveysComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "NewsurveysComponent", function () {
      return NewsurveysComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var src_app_homepage_survey_survey_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! src/app/homepage/survey/survey.component */
    "./src/app/homepage/survey/survey.component.ts");
    /* harmony import */


    var _ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic-native/launch-navigator/ngx */
    "./node_modules/@ionic-native/launch-navigator/ngx/index.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var src_app_utilities_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! src/app/utilities.service */
    "./src/app/utilities.service.ts");
    /* harmony import */


    var src_app_api_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! src/app/api.service */
    "./src/app/api.service.ts");
    /* harmony import */


    var _ionic_storage__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! @ionic/storage */
    "./node_modules/@ionic/storage/fesm2015/ionic-storage.js");
    /* harmony import */


    var moment__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! moment */
    "./node_modules/moment/moment.js");
    /* harmony import */


    var moment__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_8__);
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");

    var NewsurveysComponent = /*#__PURE__*/function () {
      function NewsurveysComponent(launchNavigator, datePipe, cdr, utils, storage, el, apiService) {
        _classCallCheck(this, NewsurveysComponent);

        this.launchNavigator = launchNavigator;
        this.datePipe = datePipe;
        this.cdr = cdr;
        this.utils = utils;
        this.storage = storage;
        this.el = el;
        this.apiService = apiService;
        this.listOfSurveyData = [];
        this.listOfSurveyDataHelper = [];
        this.options = {
          start: '',
          app: this.launchNavigator.APP.GOOGLE_MAPS
        };
      }

      _createClass(NewsurveysComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this15 = this;

          var latestDate = new Date();
          this.today = this.datePipe.transform(latestDate, 'M/dd/yy');
          console.log('date', this.today);

          this.apiService._OnMessageReceivedSubject.subscribe(function (r) {
            console.log('message received! ', r);

            _this15.getSurveys();
          });
        }
      }, {
        key: "scrollTo",
        value: function scrollTo(offsetTop, date) {
          var _this16 = this;

          setTimeout(function () {
            var sectionOffset = _this16.el.nativeElement.getElementsByTagName('ion-grid')[date].offsetTop;

            console.log("sectionOffset == ", sectionOffset);

            _this16.content.scrollToPoint(0, sectionOffset, 1000);
          }, 500);
        }
      }, {
        key: "ionViewDidEnter",
        value: function ionViewDidEnter() {
          var _this17 = this;

          this.surveyRefreshSubscription = this.utils.getHomepageSurveyRefresh().subscribe(function (result) {
            _this17.getSurveys(null);
          });
          this.dataRefreshSubscription = this.utils.getDataRefresh().subscribe(function (result) {
            if (_this17.listOfSurveyData != null && _this17.listOfSurveyData.length > 0) {
              _this17.formatSurveyData(_this17.listOfSurveyData);
            }
          });
        }
      }, {
        key: "getSurveys",
        value: function getSurveys(event) {
          var showLoader = true;

          if (event != null && event !== undefined) {
            showLoader = false;
          }

          this.fetchPendingSurveys(event);
        }
      }, {
        key: "fetchPendingSurveys",
        value: function fetchPendingSurveys(event, showLoader) {
          var _this18 = this;

          this.listOfSurveyData = [];
          this.listOfSurveyDataHelper = [];
          this.utils.showLoadingWithPullRefreshSupport(showLoader, 'Getting Surveys').then(function (success) {
            _this18.utils.showLoading('Getting Surveys').then(function () {
              _this18.apiService.getSurveyorSurveys("status=surveyassigned&status=surveyinprocess").subscribe(function (response) {
                _this18.utils.hideLoading().then(function () {
                  _this18.utils.hideLoadingWithPullRefreshSupport(showLoader).then(function () {
                    console.log(response);

                    _this18.formatSurveyData(response);

                    if (event !== null) {
                      event.target.complete();
                    }
                  });
                });
              }, function (responseError) {
                _this18.utils.hideLoading();

                _this18.utils.hideLoadingWithPullRefreshSupport(showLoader).then(function () {
                  if (event !== null) {
                    event.target.complete();
                  }

                  var error = responseError.error;

                  _this18.utils.errorSnackBar(error.message[0].messages[0].message);
                });
              });
            });
          });
        }
      }, {
        key: "openAddressOnMap",
        value: function openAddressOnMap(address) {
          this.launchNavigator.navigate(address, this.options);
        }
      }, {
        key: "formatSurveyData",
        value: function formatSurveyData(records) {
          var _this19 = this;

          this.listOfSurveyData = this.fillinDynamicData(records);
          var tempData = [];
          this.listOfSurveyData.forEach(function (surveyItem, i) {
            _this19.sDatePassed(surveyItem.datetime, i);

            surveyItem.lateby = _this19.overdue;

            if (tempData.length === 0) {
              var listOfSurvey = new src_app_homepage_survey_survey_component__WEBPACK_IMPORTED_MODULE_2__["SurveyDataHelper"]();
              listOfSurvey.date = _this19.datePipe.transform(surveyItem.datetime, 'M/dd/yy');
              listOfSurvey.listOfSurveys.push(surveyItem);
              tempData.push(listOfSurvey);
              console.log(tempData);
            } else {
              var added = false;
              tempData.forEach(function (surveyList) {
                if (!added) {
                  if (surveyList.date === _this19.datePipe.transform(surveyItem.datetime, 'M/dd/yy')) {
                    surveyList.listOfSurveys.push(surveyItem);
                    added = true;
                    console.log(surveyList.listOfSurveys);
                  }
                }
              });

              if (!added) {
                var _listOfSurvey4 = new src_app_homepage_survey_survey_component__WEBPACK_IMPORTED_MODULE_2__["SurveyDataHelper"]();

                _listOfSurvey4.date = _this19.datePipe.transform(surveyItem.datetime, 'M/dd/yy');

                _listOfSurvey4.listOfSurveys.push(surveyItem);

                tempData.push(_listOfSurvey4);
                added = true;
                console.log(tempData);
              }
            }
          });
          this.listOfSurveyDataHelper = tempData.sort(function (a, b) {
            var dateA = new Date(a.date).getTime(),
                dateB = new Date(b.date).getTime();
            return dateB - dateA;
          });
          this.cdr.detectChanges();
        }
      }, {
        key: "fillinDynamicData",
        value: function fillinDynamicData(records) {
          var _this20 = this;

          records.forEach(function (element) {
            element.formattedjobtype = _this20.utils.getJobTypeName(element.jobtype);

            _this20.storage.get('' + element.id).then(function (data) {
              console.log(data);

              if (data) {
                element.totalpercent = data.currentprogress;
              } else {
                element.totalpercent = 0;
              }
            });
          });
          return records;
        }
      }, {
        key: "sDatePassed",
        value: function sDatePassed(datestring, i) {
          var checkdate = moment__WEBPACK_IMPORTED_MODULE_8__(datestring, "YYYYMMDD");
          var todaydate = moment__WEBPACK_IMPORTED_MODULE_8__(new Date(), "YYYYMMDD");
          var lateby = todaydate.diff(checkdate, "days");
          this.overdue = lateby;
          console.log(this.overdue, ">>>>>>>>>>>>>>>>>.");
        }
      }]);

      return NewsurveysComponent;
    }();

    NewsurveysComponent.ctorParameters = function () {
      return [{
        type: _ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_3__["LaunchNavigator"]
      }, {
        type: _angular_common__WEBPACK_IMPORTED_MODULE_4__["DatePipe"]
      }, {
        type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"]
      }, {
        type: src_app_utilities_service__WEBPACK_IMPORTED_MODULE_5__["UtilitiesService"]
      }, {
        type: _ionic_storage__WEBPACK_IMPORTED_MODULE_7__["Storage"]
      }, {
        type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"]
      }, {
        type: src_app_api_service__WEBPACK_IMPORTED_MODULE_6__["ApiService"]
      }];
    };

    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])(_ionic_angular__WEBPACK_IMPORTED_MODULE_9__["IonContent"], {
      "static": false
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _ionic_angular__WEBPACK_IMPORTED_MODULE_9__["IonContent"])], NewsurveysComponent.prototype, "content", void 0);
    NewsurveysComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-newsurveys',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./newsurveys.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/surveyoroverview/newsurveys/newsurveys.component.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./newsurveys.component.scss */
      "./src/app/surveyoroverview/newsurveys/newsurveys.component.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_3__["LaunchNavigator"], _angular_common__WEBPACK_IMPORTED_MODULE_4__["DatePipe"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"], src_app_utilities_service__WEBPACK_IMPORTED_MODULE_5__["UtilitiesService"], _ionic_storage__WEBPACK_IMPORTED_MODULE_7__["Storage"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], src_app_api_service__WEBPACK_IMPORTED_MODULE_6__["ApiService"]])], NewsurveysComponent);
    /***/
  },

  /***/
  "./src/app/surveyoroverview/surveyoroverview-routing.module.ts":
  /*!*********************************************************************!*\
    !*** ./src/app/surveyoroverview/surveyoroverview-routing.module.ts ***!
    \*********************************************************************/

  /*! exports provided: SurveyoroverviewPageRoutingModule */

  /***/
  function srcAppSurveyoroverviewSurveyoroverviewRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SurveyoroverviewPageRoutingModule", function () {
      return SurveyoroverviewPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _surveyoroverview_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./surveyoroverview.page */
    "./src/app/surveyoroverview/surveyoroverview.page.ts");
    /* harmony import */


    var _newsurveys_newsurveys_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ./newsurveys/newsurveys.component */
    "./src/app/surveyoroverview/newsurveys/newsurveys.component.ts");
    /* harmony import */


    var _completedsurveys_completedsurveys_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./completedsurveys/completedsurveys.component */
    "./src/app/surveyoroverview/completedsurveys/completedsurveys.component.ts");
    /* harmony import */


    var _inreviewsurveys_inreviewsurveys_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./inreviewsurveys/inreviewsurveys.component */
    "./src/app/surveyoroverview/inreviewsurveys/inreviewsurveys.component.ts");
    /* harmony import */


    var _deliveredsurveys_deliveredsurveys_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ./deliveredsurveys/deliveredsurveys.component */
    "./src/app/surveyoroverview/deliveredsurveys/deliveredsurveys.component.ts");

    var routes = [{
      path: '',
      component: _surveyoroverview_page__WEBPACK_IMPORTED_MODULE_3__["SurveyoroverviewPage"],
      children: [{
        path: 'newsurveys',
        component: _newsurveys_newsurveys_component__WEBPACK_IMPORTED_MODULE_4__["NewsurveysComponent"]
      }, {
        path: 'completedsurveys',
        component: _completedsurveys_completedsurveys_component__WEBPACK_IMPORTED_MODULE_5__["CompletedsurveysComponent"]
      }, {
        path: 'inreviewsurveys',
        component: _inreviewsurveys_inreviewsurveys_component__WEBPACK_IMPORTED_MODULE_6__["InreviewsurveysComponent"]
      }, {
        path: 'deliveredsurveys',
        component: _deliveredsurveys_deliveredsurveys_component__WEBPACK_IMPORTED_MODULE_7__["DeliveredsurveysComponent"]
      }]
    }];

    var SurveyoroverviewPageRoutingModule = function SurveyoroverviewPageRoutingModule() {
      _classCallCheck(this, SurveyoroverviewPageRoutingModule);
    };

    SurveyoroverviewPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], SurveyoroverviewPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/surveyoroverview/surveyoroverview.module.ts":
  /*!*************************************************************!*\
    !*** ./src/app/surveyoroverview/surveyoroverview.module.ts ***!
    \*************************************************************/

  /*! exports provided: SurveyoroverviewPageModule */

  /***/
  function srcAppSurveyoroverviewSurveyoroverviewModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SurveyoroverviewPageModule", function () {
      return SurveyoroverviewPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _surveyoroverview_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./surveyoroverview-routing.module */
    "./src/app/surveyoroverview/surveyoroverview-routing.module.ts");
    /* harmony import */


    var _surveyoroverview_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./surveyoroverview.page */
    "./src/app/surveyoroverview/surveyoroverview.page.ts");
    /* harmony import */


    var _newsurveys_newsurveys_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ./newsurveys/newsurveys.component */
    "./src/app/surveyoroverview/newsurveys/newsurveys.component.ts");
    /* harmony import */


    var _completedsurveys_completedsurveys_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! ./completedsurveys/completedsurveys.component */
    "./src/app/surveyoroverview/completedsurveys/completedsurveys.component.ts");
    /* harmony import */


    var _inreviewsurveys_inreviewsurveys_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! ./inreviewsurveys/inreviewsurveys.component */
    "./src/app/surveyoroverview/inreviewsurveys/inreviewsurveys.component.ts");
    /* harmony import */


    var _deliveredsurveys_deliveredsurveys_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
    /*! ./deliveredsurveys/deliveredsurveys.component */
    "./src/app/surveyoroverview/deliveredsurveys/deliveredsurveys.component.ts");
    /* harmony import */


    var _ionic_native_diagnostic_ngx__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
    /*! @ionic-native/diagnostic/ngx */
    "./node_modules/@ionic-native/diagnostic/ngx/index.js");
    /* harmony import */


    var _ionic_native_native_geocoder_ngx__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
    /*! @ionic-native/native-geocoder/ngx */
    "./node_modules/@ionic-native/native-geocoder/ngx/index.js");
    /* harmony import */


    var _ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(
    /*! @ionic-native/launch-navigator/ngx */
    "./node_modules/@ionic-native/launch-navigator/ngx/index.js");

    var SurveyoroverviewPageModule = function SurveyoroverviewPageModule() {
      _classCallCheck(this, SurveyoroverviewPageModule);
    };

    SurveyoroverviewPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _surveyoroverview_routing_module__WEBPACK_IMPORTED_MODULE_5__["SurveyoroverviewPageRoutingModule"]],
      declarations: [_surveyoroverview_page__WEBPACK_IMPORTED_MODULE_6__["SurveyoroverviewPage"], _newsurveys_newsurveys_component__WEBPACK_IMPORTED_MODULE_7__["NewsurveysComponent"], _completedsurveys_completedsurveys_component__WEBPACK_IMPORTED_MODULE_8__["CompletedsurveysComponent"], _inreviewsurveys_inreviewsurveys_component__WEBPACK_IMPORTED_MODULE_9__["InreviewsurveysComponent"], _deliveredsurveys_deliveredsurveys_component__WEBPACK_IMPORTED_MODULE_10__["DeliveredsurveysComponent"]],
      providers: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["DatePipe"], _ionic_native_diagnostic_ngx__WEBPACK_IMPORTED_MODULE_11__["Diagnostic"], _ionic_native_native_geocoder_ngx__WEBPACK_IMPORTED_MODULE_12__["NativeGeocoder"], _ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_13__["LaunchNavigator"]]
    })], SurveyoroverviewPageModule);
    /***/
  },

  /***/
  "./src/app/surveyoroverview/surveyoroverview.page.scss":
  /*!*************************************************************!*\
    !*** ./src/app/surveyoroverview/surveyoroverview.page.scss ***!
    \*************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppSurveyoroverviewSurveyoroverviewPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".bottom-bar {\n  margin: 8px;\n  border-radius: 50px;\n  box-shadow: 0 -2px 8px 0 rgba(0, 0, 0, 0.1);\n  border: 2px solid white;\n  background: #FFFAEB;\n}\n\n.tab {\n  padding-top: 1em;\n  padding-bottom: 1em;\n  padding-bottom: 1em;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n\n.tabText {\n  margin-left: 8px;\n  font-size: 1em;\n}\n\n.tab-icon {\n  width: 24px;\n  height: 24px;\n}\n\nion-tab-button {\n  font-size: 14px;\n  --color: #9E9E9E;\n  --color-selected: #3c78d8;\n}\n\nion-tab-button[aria-selected=true] {\n  border-bottom: 3px solid #3c78d8;\n  border-bottom-left-radius: 2px;\n  border-bottom-right-radius: 2px;\n}\n\n.custombadge {\n  background-color: #3c78d8;\n  color: #ffffff;\n  border-radius: 50%;\n  width: 16px;\n  height: 16px;\n  font-size: 8px;\n  padding: 4px;\n  position: absolute;\n  margin-left: 4px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc3VydmV5b3JvdmVydmlldy9GOlxcbW9iaWxlYXBwL3NyY1xcYXBwXFxzdXJ2ZXlvcm92ZXJ2aWV3XFxzdXJ2ZXlvcm92ZXJ2aWV3LnBhZ2Uuc2NzcyIsInNyYy9hcHAvc3VydmV5b3JvdmVydmlldy9zdXJ2ZXlvcm92ZXJ2aWV3LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFdBQUE7RUFDQSxtQkFBQTtFQUNBLDJDQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQ0NKOztBREVBO0VBQ0ksZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLG1CQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7QUNDSjs7QURFQTtFQUNJLGdCQUFBO0VBQ0EsY0FBQTtBQ0NKOztBREVBO0VBQ0ksV0FBQTtFQUNBLFlBQUE7QUNDSjs7QURFQTtFQUNJLGVBQUE7RUFDQSxnQkFBQTtFQUNBLHlCQUFBO0FDQ0o7O0FERUE7RUFDSSxnQ0FBQTtFQUNBLDhCQUFBO0VBQ0EsK0JBQUE7QUNDSjs7QURFQTtFQUNJLHlCQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxjQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7QUNDSiIsImZpbGUiOiJzcmMvYXBwL3N1cnZleW9yb3ZlcnZpZXcvc3VydmV5b3JvdmVydmlldy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuYm90dG9tLWJhciB7XHJcbiAgICBtYXJnaW46IDhweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDUwcHg7XHJcbiAgICBib3gtc2hhZG93OiAwIC0ycHggOHB4IDAgcmdiYSgwLCAwLCAwLCAwLjEpO1xyXG4gICAgYm9yZGVyOiAycHggc29saWQgd2hpdGU7XHJcbiAgICBiYWNrZ3JvdW5kOiAjRkZGQUVCO1xyXG59XHJcblxyXG4udGFiIHtcclxuICAgIHBhZGRpbmctdG9wOiAxZW07XHJcbiAgICBwYWRkaW5nLWJvdHRvbTogMWVtO1xyXG4gICAgcGFkZGluZy1ib3R0b206IDFlbTtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbn1cclxuXHJcbi50YWJUZXh0IHtcclxuICAgIG1hcmdpbi1sZWZ0OiA4cHg7XHJcbiAgICBmb250LXNpemU6IDFlbTtcclxufVxyXG5cclxuLnRhYi1pY29uIHtcclxuICAgIHdpZHRoOiAyNHB4O1xyXG4gICAgaGVpZ2h0OiAyNHB4O1xyXG59XHJcblxyXG5pb24tdGFiLWJ1dHRvbiB7XHJcbiAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICAtLWNvbG9yOiAjOUU5RTlFO1xyXG4gICAgLS1jb2xvci1zZWxlY3RlZDogIzNjNzhkODtcclxufVxyXG5cclxuaW9uLXRhYi1idXR0b25bYXJpYS1zZWxlY3RlZD10cnVlXSB7XHJcbiAgICBib3JkZXItYm90dG9tOiAzcHggc29saWQgIzNjNzhkODtcclxuICAgIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDJweDtcclxuICAgIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiAycHg7XHJcbn1cclxuXHJcbi5jdXN0b21iYWRnZXtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICMzYzc4ZDg7XHJcbiAgICBjb2xvcjogI2ZmZmZmZjtcclxuICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgIHdpZHRoOiAxNnB4O1xyXG4gICAgaGVpZ2h0OiAxNnB4O1xyXG4gICAgZm9udC1zaXplOiA4cHg7XHJcbiAgICBwYWRkaW5nOiA0cHg7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICBtYXJnaW4tbGVmdDogNHB4O1xyXG59IiwiLmJvdHRvbS1iYXIge1xuICBtYXJnaW46IDhweDtcbiAgYm9yZGVyLXJhZGl1czogNTBweDtcbiAgYm94LXNoYWRvdzogMCAtMnB4IDhweCAwIHJnYmEoMCwgMCwgMCwgMC4xKTtcbiAgYm9yZGVyOiAycHggc29saWQgd2hpdGU7XG4gIGJhY2tncm91bmQ6ICNGRkZBRUI7XG59XG5cbi50YWIge1xuICBwYWRkaW5nLXRvcDogMWVtO1xuICBwYWRkaW5nLWJvdHRvbTogMWVtO1xuICBwYWRkaW5nLWJvdHRvbTogMWVtO1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbn1cblxuLnRhYlRleHQge1xuICBtYXJnaW4tbGVmdDogOHB4O1xuICBmb250LXNpemU6IDFlbTtcbn1cblxuLnRhYi1pY29uIHtcbiAgd2lkdGg6IDI0cHg7XG4gIGhlaWdodDogMjRweDtcbn1cblxuaW9uLXRhYi1idXR0b24ge1xuICBmb250LXNpemU6IDE0cHg7XG4gIC0tY29sb3I6ICM5RTlFOUU7XG4gIC0tY29sb3Itc2VsZWN0ZWQ6ICMzYzc4ZDg7XG59XG5cbmlvbi10YWItYnV0dG9uW2FyaWEtc2VsZWN0ZWQ9dHJ1ZV0ge1xuICBib3JkZXItYm90dG9tOiAzcHggc29saWQgIzNjNzhkODtcbiAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogMnB4O1xuICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogMnB4O1xufVxuXG4uY3VzdG9tYmFkZ2Uge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjM2M3OGQ4O1xuICBjb2xvcjogI2ZmZmZmZjtcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xuICB3aWR0aDogMTZweDtcbiAgaGVpZ2h0OiAxNnB4O1xuICBmb250LXNpemU6IDhweDtcbiAgcGFkZGluZzogNHB4O1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIG1hcmdpbi1sZWZ0OiA0cHg7XG59Il19 */";
    /***/
  },

  /***/
  "./src/app/surveyoroverview/surveyoroverview.page.ts":
  /*!***********************************************************!*\
    !*** ./src/app/surveyoroverview/surveyoroverview.page.ts ***!
    \***********************************************************/

  /*! exports provided: SurveyoroverviewPage */

  /***/
  function srcAppSurveyoroverviewSurveyoroverviewPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SurveyoroverviewPage", function () {
      return SurveyoroverviewPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _cometchat_pro_cordova_ionic_chat__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @cometchat-pro/cordova-ionic-chat */
    "./node_modules/@cometchat-pro/cordova-ionic-chat/CometChat.js");
    /* harmony import */


    var _cometchat_pro_cordova_ionic_chat__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_cometchat_pro_cordova_ionic_chat__WEBPACK_IMPORTED_MODULE_3__);
    /* harmony import */


    var _storage_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ../storage.service */
    "./src/app/storage.service.ts");
    /* harmony import */


    var _model_constants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ../model/constants */
    "./src/app/model/constants.ts");
    /* harmony import */


    var _api_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ../api.service */
    "./src/app/api.service.ts");

    var SurveyoroverviewPage = /*#__PURE__*/function () {
      function SurveyoroverviewPage(route, storage, apiService) {
        _classCallCheck(this, SurveyoroverviewPage);

        this.route = route;
        this.storage = storage;
        this.apiService = apiService;
      }

      _createClass(SurveyoroverviewPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.setupCometChatUser();
          this.updateUserPushToken();
          this.route.navigate(['surveyoroverview/newsurveys']);
        }
      }, {
        key: "ngOnDestroy",
        value: function ngOnDestroy() {}
      }, {
        key: "setupCometChatUser",
        value: function setupCometChatUser() {
          var _this21 = this;

          var appSetting = new _cometchat_pro_cordova_ionic_chat__WEBPACK_IMPORTED_MODULE_3__["CometChat"].AppSettingsBuilder().subscribePresenceForAllUsers().setRegion(_model_constants__WEBPACK_IMPORTED_MODULE_5__["COMET_CHAT_REGION"]).build();

          _cometchat_pro_cordova_ionic_chat__WEBPACK_IMPORTED_MODULE_3__["CometChat"].init(_model_constants__WEBPACK_IMPORTED_MODULE_5__["COMET_CHAT_APP_ID"], appSetting).then(function () {
            console.log('Initialization completed successfully');

            _cometchat_pro_cordova_ionic_chat__WEBPACK_IMPORTED_MODULE_3__["CometChat"].login(_this21.storage.getUserID(), _model_constants__WEBPACK_IMPORTED_MODULE_5__["COMET_CHAT_AUTH_KEY"]).then(function (user) {
              console.log('Login Successful:', {
                user: user
              });
            }, function (error) {
              console.log('Login failed with exception:', {
                error: error
              });
            });
          }, function (error) {
            console.log('Initialization failed with error:', error);
          });
        }
      }, {
        key: "updateUserPushToken",
        value: function updateUserPushToken() {
          this.apiService.pushtoken(this.storage.getUserID(), {
            "newpushtoken": localStorage.getItem("pushtoken")
          }).subscribe(function (data) {
            console.log(data, "fcm data");
          }, function (error) {});
        }
      }]);

      return SurveyoroverviewPage;
    }();

    SurveyoroverviewPage.ctorParameters = function () {
      return [{
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
      }, {
        type: _storage_service__WEBPACK_IMPORTED_MODULE_4__["StorageService"]
      }, {
        type: _api_service__WEBPACK_IMPORTED_MODULE_6__["ApiService"]
      }];
    };

    SurveyoroverviewPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-surveyoroverview',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./surveyoroverview.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/surveyoroverview/surveyoroverview.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./surveyoroverview.page.scss */
      "./src/app/surveyoroverview/surveyoroverview.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _storage_service__WEBPACK_IMPORTED_MODULE_4__["StorageService"], _api_service__WEBPACK_IMPORTED_MODULE_6__["ApiService"]])], SurveyoroverviewPage);
    /***/
  }
}]);
//# sourceMappingURL=surveyoroverview-surveyoroverview-module-es5.js.map