function _get(target, property, receiver) { if (typeof Reflect !== "undefined" && Reflect.get) { _get = Reflect.get; } else { _get = function _get(target, property, receiver) { var base = _superPropBase(target, property); if (!base) return; var desc = Object.getOwnPropertyDescriptor(base, property); if (desc.get) { return desc.get.call(receiver); } return desc.value; }; } return _get(target, property, receiver || target); }

function _superPropBase(object, property) { while (!Object.prototype.hasOwnProperty.call(object, property)) { object = _getPrototypeOf(object); if (object === null) break; } return object; }

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _iterableToArrayLimit(arr, i) { if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return; var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

function _createForOfIteratorHelper(o, allowArrayLike) { var it; if (typeof Symbol === "undefined" || o[Symbol.iterator] == null) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e2) { throw _e2; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = o[Symbol.iterator](); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e3) { didErr = true; err = _e3; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _possibleConstructorReturn(self, call) { if (call && (typeof call === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["surveyprocess-surveyprocess-module"], {
  /***/
  "./node_modules/@angular/cdk/esm2015/bidi.js":
  /*!***************************************************!*\
    !*** ./node_modules/@angular/cdk/esm2015/bidi.js ***!
    \***************************************************/

  /*! exports provided: Directionality, DIR_DOCUMENT, Dir, BidiModule, ɵa */

  /***/
  function node_modulesAngularCdkEsm2015BidiJs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Directionality", function () {
      return Directionality;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DIR_DOCUMENT", function () {
      return DIR_DOCUMENT;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Dir", function () {
      return Dir;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "BidiModule", function () {
      return BidiModule;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ɵa", function () {
      return DIR_DOCUMENT_FACTORY;
    });
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /**
     * @license
     * Copyright Google LLC All Rights Reserved.
     *
     * Use of this source code is governed by an MIT-style license that can be
     * found in the LICENSE file at https://angular.io/license
     */

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    /**
     * Injection token used to inject the document into Directionality.
     * This is used so that the value can be faked in tests.
     *
     * We can't use the real document in tests because changing the real `dir` causes geometry-based
     * tests in Safari to fail.
     *
     * We also can't re-provide the DOCUMENT token from platform-brower because the unit tests
     * themselves use things like `querySelector` in test code.
     *
     * This token is defined in a separate file from Directionality as a workaround for
     * https://github.com/angular/angular/issues/22559
     *
     * \@docs-private
     * @type {?}
     */


    var DIR_DOCUMENT = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["InjectionToken"]('cdk-dir-doc', {
      providedIn: 'root',
      factory: DIR_DOCUMENT_FACTORY
    });
    /**
     * \@docs-private
     * @return {?}
     */

    function DIR_DOCUMENT_FACTORY() {
      return Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["inject"])(_angular_common__WEBPACK_IMPORTED_MODULE_0__["DOCUMENT"]);
    }
    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    /**
     * The directionality (LTR / RTL) context for the application (or a subtree of it).
     * Exposes the current direction and a stream of direction changes.
     */


    var Directionality = /*#__PURE__*/function () {
      /**
       * @param {?=} _document
       */
      function Directionality(_document) {
        _classCallCheck(this, Directionality);

        /**
         * The current 'ltr' or 'rtl' value.
         */
        this.value = 'ltr';
        /**
         * Stream that emits whenever the 'ltr' / 'rtl' state changes.
         */

        this.change = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();

        if (_document) {
          // TODO: handle 'auto' value -
          // We still need to account for dir="auto".
          // It looks like HTMLElemenet.dir is also "auto" when that's set to the attribute,
          // but getComputedStyle return either "ltr" or "rtl". avoiding getComputedStyle for now

          /** @type {?} */
          var bodyDir = _document.body ? _document.body.dir : null;
          /** @type {?} */

          var htmlDir = _document.documentElement ? _document.documentElement.dir : null;
          /** @type {?} */

          var value = bodyDir || htmlDir;
          this.value = value === 'ltr' || value === 'rtl' ? value : 'ltr';
        }
      }
      /**
       * @return {?}
       */


      _createClass(Directionality, [{
        key: "ngOnDestroy",
        value: function ngOnDestroy() {
          this.change.complete();
        }
      }]);

      return Directionality;
    }();

    Directionality.decorators = [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"],
      args: [{
        providedIn: 'root'
      }]
    }];
    /** @nocollapse */

    Directionality.ctorParameters = function () {
      return [{
        type: undefined,
        decorators: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Optional"]
        }, {
          type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"],
          args: [DIR_DOCUMENT]
        }]
      }];
    };
    /** @nocollapse */


    Directionality.ngInjectableDef = Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"])({
      factory: function Directionality_Factory() {
        return new Directionality(Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"])(DIR_DOCUMENT, 8));
      },
      token: Directionality,
      providedIn: "root"
    });
    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    /**
     * Directive to listen for changes of direction of part of the DOM.
     *
     * Provides itself as Directionality such that descendant directives only need to ever inject
     * Directionality to get the closest direction.
     */

    var Dir = /*#__PURE__*/function () {
      function Dir() {
        _classCallCheck(this, Dir);

        /**
         * Normalized direction that accounts for invalid/unsupported values.
         */
        this._dir = 'ltr';
        /**
         * Whether the `value` has been set to its initial value.
         */

        this._isInitialized = false;
        /**
         * Event emitted when the direction changes.
         */

        this.change = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
      }
      /**
       * \@docs-private
       * @return {?}
       */


      _createClass(Dir, [{
        key: "ngAfterContentInit",

        /**
         * Initialize once default value has been set.
         * @return {?}
         */
        value: function ngAfterContentInit() {
          this._isInitialized = true;
        }
        /**
         * @return {?}
         */

      }, {
        key: "ngOnDestroy",
        value: function ngOnDestroy() {
          this.change.complete();
        }
      }, {
        key: "dir",
        get: function get() {
          return this._dir;
        }
        /**
         * @param {?} value
         * @return {?}
         */
        ,
        set: function set(value) {
          /** @type {?} */
          var old = this._dir;
          /** @type {?} */

          var normalizedValue = value ? value.toLowerCase() : value;
          this._rawDir = value;
          this._dir = normalizedValue === 'ltr' || normalizedValue === 'rtl' ? normalizedValue : 'ltr';

          if (old !== this._dir && this._isInitialized) {
            this.change.emit(this._dir);
          }
        }
        /**
         * Current layout direction of the element.
         * @return {?}
         */

      }, {
        key: "value",
        get: function get() {
          return this.dir;
        }
      }]);

      return Dir;
    }();

    Dir.decorators = [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Directive"],
      args: [{
        selector: '[dir]',
        providers: [{
          provide: Directionality,
          useExisting: Dir
        }],
        host: {
          '[attr.dir]': '_rawDir'
        },
        exportAs: 'dir'
      }]
    }];
    Dir.propDecorators = {
      change: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"],
        args: ['dirChange']
      }],
      dir: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"]
      }]
    };
    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    var BidiModule = function BidiModule() {
      _classCallCheck(this, BidiModule);
    };

    BidiModule.decorators = [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"],
      args: [{
        exports: [Dir],
        declarations: [Dir]
      }]
    }];
    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    //# sourceMappingURL=bidi.js.map

    /***/
  },

  /***/
  "./node_modules/@angular/cdk/esm2015/coercion.js":
  /*!*******************************************************!*\
    !*** ./node_modules/@angular/cdk/esm2015/coercion.js ***!
    \*******************************************************/

  /*! exports provided: coerceBooleanProperty, coerceNumberProperty, _isNumberValue, coerceArray, coerceCssPixelValue, coerceElement */

  /***/
  function node_modulesAngularCdkEsm2015CoercionJs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "coerceBooleanProperty", function () {
      return coerceBooleanProperty;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "coerceNumberProperty", function () {
      return coerceNumberProperty;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "_isNumberValue", function () {
      return _isNumberValue;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "coerceArray", function () {
      return coerceArray;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "coerceCssPixelValue", function () {
      return coerceCssPixelValue;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "coerceElement", function () {
      return coerceElement;
    });
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /**
     * @license
     * Copyright Google LLC All Rights Reserved.
     *
     * Use of this source code is governed by an MIT-style license that can be
     * found in the LICENSE file at https://angular.io/license
     */

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    /**
     * Coerces a data-bound value (typically a string) to a boolean.
     * @param {?} value
     * @return {?}
     */


    function coerceBooleanProperty(value) {
      return value != null && "".concat(value) !== 'false';
    }
    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    /**
     * @param {?} value
     * @param {?=} fallbackValue
     * @return {?}
     */


    function coerceNumberProperty(value) {
      var fallbackValue = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
      return _isNumberValue(value) ? Number(value) : fallbackValue;
    }
    /**
     * Whether the provided value is considered a number.
     * \@docs-private
     * @param {?} value
     * @return {?}
     */


    function _isNumberValue(value) {
      // parseFloat(value) handles most of the cases we're interested in (it treats null, empty string,
      // and other non-number values as NaN, where Number just uses 0) but it considers the string
      // '123hello' to be a valid number. Therefore we also check if Number(value) is NaN.
      return !isNaN(parseFloat(
      /** @type {?} */
      value)) && !isNaN(Number(value));
    }
    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    /**
     * Wraps the provided value in an array, unless the provided value is an array.
     * @template T
     * @param {?} value
     * @return {?}
     */


    function coerceArray(value) {
      return Array.isArray(value) ? value : [value];
    }
    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    /**
     * Coerces a value to a CSS pixel value.
     * @param {?} value
     * @return {?}
     */


    function coerceCssPixelValue(value) {
      if (value == null) {
        return '';
      }

      return typeof value === 'string' ? value : "".concat(value, "px");
    }
    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    /**
     * Coerces an ElementRef or an Element into an element.
     * Useful for APIs that can accept either a ref or the native element itself.
     * @template T
     * @param {?} elementOrRef
     * @return {?}
     */


    function coerceElement(elementOrRef) {
      return elementOrRef instanceof _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"] ? elementOrRef.nativeElement : elementOrRef;
    }
    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    //# sourceMappingURL=coercion.js.map

    /***/

  },

  /***/
  "./node_modules/@angular/cdk/esm2015/collections.js":
  /*!**********************************************************!*\
    !*** ./node_modules/@angular/cdk/esm2015/collections.js ***!
    \**********************************************************/

  /*! exports provided: UniqueSelectionDispatcher, ArrayDataSource, isDataSource, DataSource, getMultipleValuesInSingleSelectionError, SelectionModel */

  /***/
  function node_modulesAngularCdkEsm2015CollectionsJs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "UniqueSelectionDispatcher", function () {
      return UniqueSelectionDispatcher;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ArrayDataSource", function () {
      return ArrayDataSource;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "isDataSource", function () {
      return isDataSource;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DataSource", function () {
      return DataSource;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "getMultipleValuesInSingleSelectionError", function () {
      return getMultipleValuesInSingleSelectionError;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SelectionModel", function () {
      return SelectionModel;
    });
    /* harmony import */


    var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! rxjs */
    "./node_modules/rxjs/_esm2015/index.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /**
     * @license
     * Copyright Google LLC All Rights Reserved.
     *
     * Use of this source code is governed by an MIT-style license that can be
     * found in the LICENSE file at https://angular.io/license
     */

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    /**
     * @abstract
     * @template T
     */


    var DataSource = function DataSource() {
      _classCallCheck(this, DataSource);
    };
    /**
     * Checks whether an object is a data source.
     * @param {?} value
     * @return {?}
     */


    function isDataSource(value) {
      // Check if the value is a DataSource by observing if it has a connect function. Cannot
      // be checked as an `instanceof DataSource` since people could create their own sources
      // that match the interface, but don't extend DataSource.
      return value && typeof value.connect === 'function';
    }
    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    /**
     * DataSource wrapper for a native array.
     * @template T
     */


    var ArrayDataSource = /*#__PURE__*/function (_DataSource) {
      _inherits(ArrayDataSource, _DataSource);

      var _super2 = _createSuper(ArrayDataSource);

      /**
       * @param {?} _data
       */
      function ArrayDataSource(_data) {
        var _this2;

        _classCallCheck(this, ArrayDataSource);

        _this2 = _super2.call(this);
        _this2._data = _data;
        return _this2;
      }
      /**
       * @return {?}
       */


      _createClass(ArrayDataSource, [{
        key: "connect",
        value: function connect() {
          return this._data instanceof rxjs__WEBPACK_IMPORTED_MODULE_0__["Observable"] ? this._data : Object(rxjs__WEBPACK_IMPORTED_MODULE_0__["of"])(this._data);
        }
        /**
         * @return {?}
         */

      }, {
        key: "disconnect",
        value: function disconnect() {}
      }]);

      return ArrayDataSource;
    }(DataSource);
    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    /**
     * Class to be used to power selecting one or more options from a list.
     * @template T
     */


    var SelectionModel = /*#__PURE__*/function () {
      /**
       * @param {?=} _multiple
       * @param {?=} initiallySelectedValues
       * @param {?=} _emitChanges
       */
      function SelectionModel() {
        var _this3 = this;

        var _multiple = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : false;

        var initiallySelectedValues = arguments.length > 1 ? arguments[1] : undefined;

        var _emitChanges = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : true;

        _classCallCheck(this, SelectionModel);

        this._multiple = _multiple;
        this._emitChanges = _emitChanges;
        /**
         * Currently-selected values.
         */

        this._selection = new Set();
        /**
         * Keeps track of the deselected options that haven't been emitted by the change event.
         */

        this._deselectedToEmit = [];
        /**
         * Keeps track of the selected options that haven't been emitted by the change event.
         */

        this._selectedToEmit = [];
        /**
         * Event emitted when the value has changed.
         */

        this.changed = new rxjs__WEBPACK_IMPORTED_MODULE_0__["Subject"]();
        /**
         * Event emitted when the value has changed.
         * @deprecated Use `changed` instead.
         * \@breaking-change 8.0.0 To be changed to `changed`
         */

        this.onChange = this.changed;

        if (initiallySelectedValues && initiallySelectedValues.length) {
          if (_multiple) {
            initiallySelectedValues.forEach(
            /**
            * @param {?} value
            * @return {?}
            */
            function (value) {
              return _this3._markSelected(value);
            });
          } else {
            this._markSelected(initiallySelectedValues[0]);
          } // Clear the array in order to avoid firing the change event for preselected values.


          this._selectedToEmit.length = 0;
        }
      }
      /**
       * Selected values.
       * @return {?}
       */


      _createClass(SelectionModel, [{
        key: "select",

        /**
         * Selects a value or an array of values.
         * @param {...?} values
         * @return {?}
         */
        value: function select() {
          var _this4 = this;

          for (var _len = arguments.length, values = new Array(_len), _key = 0; _key < _len; _key++) {
            values[_key] = arguments[_key];
          }

          this._verifyValueAssignment(values);

          values.forEach(
          /**
          * @param {?} value
          * @return {?}
          */
          function (value) {
            return _this4._markSelected(value);
          });

          this._emitChangeEvent();
        }
        /**
         * Deselects a value or an array of values.
         * @param {...?} values
         * @return {?}
         */

      }, {
        key: "deselect",
        value: function deselect() {
          var _this5 = this;

          for (var _len2 = arguments.length, values = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
            values[_key2] = arguments[_key2];
          }

          this._verifyValueAssignment(values);

          values.forEach(
          /**
          * @param {?} value
          * @return {?}
          */
          function (value) {
            return _this5._unmarkSelected(value);
          });

          this._emitChangeEvent();
        }
        /**
         * Toggles a value between selected and deselected.
         * @param {?} value
         * @return {?}
         */

      }, {
        key: "toggle",
        value: function toggle(value) {
          this.isSelected(value) ? this.deselect(value) : this.select(value);
        }
        /**
         * Clears all of the selected values.
         * @return {?}
         */

      }, {
        key: "clear",
        value: function clear() {
          this._unmarkAll();

          this._emitChangeEvent();
        }
        /**
         * Determines whether a value is selected.
         * @param {?} value
         * @return {?}
         */

      }, {
        key: "isSelected",
        value: function isSelected(value) {
          return this._selection.has(value);
        }
        /**
         * Determines whether the model does not have a value.
         * @return {?}
         */

      }, {
        key: "isEmpty",
        value: function isEmpty() {
          return this._selection.size === 0;
        }
        /**
         * Determines whether the model has a value.
         * @return {?}
         */

      }, {
        key: "hasValue",
        value: function hasValue() {
          return !this.isEmpty();
        }
        /**
         * Sorts the selected values based on a predicate function.
         * @param {?=} predicate
         * @return {?}
         */

      }, {
        key: "sort",
        value: function sort(predicate) {
          if (this._multiple && this.selected) {
            /** @type {?} */
            this._selected.sort(predicate);
          }
        }
        /**
         * Gets whether multiple values can be selected.
         * @return {?}
         */

      }, {
        key: "isMultipleSelection",
        value: function isMultipleSelection() {
          return this._multiple;
        }
        /**
         * Emits a change event and clears the records of selected and deselected values.
         * @private
         * @return {?}
         */

      }, {
        key: "_emitChangeEvent",
        value: function _emitChangeEvent() {
          // Clear the selected values so they can be re-cached.
          this._selected = null;

          if (this._selectedToEmit.length || this._deselectedToEmit.length) {
            this.changed.next({
              source: this,
              added: this._selectedToEmit,
              removed: this._deselectedToEmit
            });
            this._deselectedToEmit = [];
            this._selectedToEmit = [];
          }
        }
        /**
         * Selects a value.
         * @private
         * @param {?} value
         * @return {?}
         */

      }, {
        key: "_markSelected",
        value: function _markSelected(value) {
          if (!this.isSelected(value)) {
            if (!this._multiple) {
              this._unmarkAll();
            }

            this._selection.add(value);

            if (this._emitChanges) {
              this._selectedToEmit.push(value);
            }
          }
        }
        /**
         * Deselects a value.
         * @private
         * @param {?} value
         * @return {?}
         */

      }, {
        key: "_unmarkSelected",
        value: function _unmarkSelected(value) {
          if (this.isSelected(value)) {
            this._selection["delete"](value);

            if (this._emitChanges) {
              this._deselectedToEmit.push(value);
            }
          }
        }
        /**
         * Clears out the selected values.
         * @private
         * @return {?}
         */

      }, {
        key: "_unmarkAll",
        value: function _unmarkAll() {
          var _this6 = this;

          if (!this.isEmpty()) {
            this._selection.forEach(
            /**
            * @param {?} value
            * @return {?}
            */
            function (value) {
              return _this6._unmarkSelected(value);
            });
          }
        }
        /**
         * Verifies the value assignment and throws an error if the specified value array is
         * including multiple values while the selection model is not supporting multiple values.
         * @private
         * @param {?} values
         * @return {?}
         */

      }, {
        key: "_verifyValueAssignment",
        value: function _verifyValueAssignment(values) {
          if (values.length > 1 && !this._multiple) {
            throw getMultipleValuesInSingleSelectionError();
          }
        }
      }, {
        key: "selected",
        get: function get() {
          if (!this._selected) {
            this._selected = Array.from(this._selection.values());
          }

          return this._selected;
        }
      }]);

      return SelectionModel;
    }();
    /**
     * Returns an error that reports that multiple values are passed into a selection model
     * with a single value.
     * \@docs-private
     * @return {?}
     */


    function getMultipleValuesInSingleSelectionError() {
      return Error('Cannot pass multiple values into SelectionModel with single-value mode.');
    }
    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    /**
     * Class to coordinate unique selection based on name.
     * Intended to be consumed as an Angular service.
     * This service is needed because native radio change events are only fired on the item currently
     * being selected, and we still need to uncheck the previous selection.
     *
     * This service does not *store* any IDs and names because they may change at any time, so it is
     * less error-prone if they are simply passed through when the events occur.
     */


    var UniqueSelectionDispatcher = /*#__PURE__*/function () {
      function UniqueSelectionDispatcher() {
        _classCallCheck(this, UniqueSelectionDispatcher);

        this._listeners = [];
      }
      /**
       * Notify other items that selection for the given name has been set.
       * @param {?} id ID of the item.
       * @param {?} name Name of the item.
       * @return {?}
       */


      _createClass(UniqueSelectionDispatcher, [{
        key: "notify",
        value: function notify(id, name) {
          var _iterator = _createForOfIteratorHelper(this._listeners),
              _step;

          try {
            for (_iterator.s(); !(_step = _iterator.n()).done;) {
              var listener = _step.value;
              listener(id, name);
            }
          } catch (err) {
            _iterator.e(err);
          } finally {
            _iterator.f();
          }
        }
        /**
         * Listen for future changes to item selection.
         * @param {?} listener
         * @return {?} Function used to deregister listener
         */

      }, {
        key: "listen",
        value: function listen(listener) {
          var _this7 = this;

          this._listeners.push(listener);

          return (
            /**
            * @return {?}
            */
            function () {
              _this7._listeners = _this7._listeners.filter(
              /**
              * @param {?} registered
              * @return {?}
              */
              function (registered) {
                return listener !== registered;
              });
            }
          );
        }
        /**
         * @return {?}
         */

      }, {
        key: "ngOnDestroy",
        value: function ngOnDestroy() {
          this._listeners = [];
        }
      }]);

      return UniqueSelectionDispatcher;
    }();

    UniqueSelectionDispatcher.decorators = [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"],
      args: [{
        providedIn: 'root'
      }]
    }];
    /** @nocollapse */

    UniqueSelectionDispatcher.ngInjectableDef = Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"])({
      factory: function UniqueSelectionDispatcher_Factory() {
        return new UniqueSelectionDispatcher();
      },
      token: UniqueSelectionDispatcher,
      providedIn: "root"
    });
    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    //# sourceMappingURL=collections.js.map

    /***/
  },

  /***/
  "./node_modules/@angular/cdk/esm2015/drag-drop.js":
  /*!********************************************************!*\
    !*** ./node_modules/@angular/cdk/esm2015/drag-drop.js ***!
    \********************************************************/

  /*! exports provided: DragDrop, DragRef, DropListRef, CdkDropList, CDK_DROP_LIST, CDK_DROP_LIST_CONTAINER, moveItemInArray, transferArrayItem, copyArrayItem, DragDropModule, DragDropRegistry, CdkDropListGroup, CDK_DRAG_CONFIG_FACTORY, CDK_DRAG_CONFIG, CdkDrag, CdkDragHandle, CdkDragPreview, CdkDragPlaceholder, ɵb */

  /***/
  function node_modulesAngularCdkEsm2015DragDropJs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DragDrop", function () {
      return DragDrop;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DragRef", function () {
      return DragRef;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DropListRef", function () {
      return DropListRef;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CdkDropList", function () {
      return CdkDropList;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CDK_DROP_LIST", function () {
      return CDK_DROP_LIST;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CDK_DROP_LIST_CONTAINER", function () {
      return CDK_DROP_LIST_CONTAINER;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "moveItemInArray", function () {
      return moveItemInArray;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "transferArrayItem", function () {
      return transferArrayItem;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "copyArrayItem", function () {
      return copyArrayItem;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DragDropModule", function () {
      return DragDropModule;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DragDropRegistry", function () {
      return DragDropRegistry;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CdkDropListGroup", function () {
      return CdkDropListGroup;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CDK_DRAG_CONFIG_FACTORY", function () {
      return CDK_DRAG_CONFIG_FACTORY;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CDK_DRAG_CONFIG", function () {
      return CDK_DRAG_CONFIG;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CdkDrag", function () {
      return CdkDrag;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CdkDragHandle", function () {
      return CdkDragHandle;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CdkDragPreview", function () {
      return CdkDragPreview;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CdkDragPlaceholder", function () {
      return CdkDragPlaceholder;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ɵb", function () {
      return CDK_DRAG_PARENT;
    });
    /* harmony import */


    var _angular_cdk_platform__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! @angular/cdk/platform */
    "./node_modules/@angular/cdk/esm2015/platform.js");
    /* harmony import */


    var _angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/cdk/coercion */
    "./node_modules/@angular/cdk/esm2015/coercion.js");
    /* harmony import */


    var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! rxjs */
    "./node_modules/rxjs/_esm2015/index.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_cdk_scrolling__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @angular/cdk/scrolling */
    "./node_modules/@angular/cdk/esm2015/scrolling.js");
    /* harmony import */


    var _angular_cdk_bidi__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! @angular/cdk/bidi */
    "./node_modules/@angular/cdk/esm2015/bidi.js");
    /**
     * @license
     * Copyright Google LLC All Rights Reserved.
     *
     * Use of this source code is governed by an MIT-style license that can be
     * found in the LICENSE file at https://angular.io/license
     */

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    /**
     * Shallow-extends a stylesheet object with another stylesheet object.
     * \@docs-private
     * @param {?} dest
     * @param {?} source
     * @return {?}
     */


    function extendStyles(dest, source) {
      for (var key in source) {
        if (source.hasOwnProperty(key)) {
          dest[key] =
          /** @type {?} */
          source[key];
        }
      }

      return dest;
    }
    /**
     * Toggles whether the native drag interactions should be enabled for an element.
     * \@docs-private
     * @param {?} element Element on which to toggle the drag interactions.
     * @param {?} enable Whether the drag interactions should be enabled.
     * @return {?}
     */


    function toggleNativeDragInteractions(element, enable) {
      /** @type {?} */
      var userSelect = enable ? '' : 'none';
      extendStyles(element.style, {
        touchAction: enable ? '' : 'none',
        webkitUserDrag: enable ? '' : 'none',
        webkitTapHighlightColor: enable ? '' : 'transparent',
        userSelect: userSelect,
        msUserSelect: userSelect,
        webkitUserSelect: userSelect,
        MozUserSelect: userSelect
      });
    }
    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    /**
     * Parses a CSS time value to milliseconds.
     * @param {?} value
     * @return {?}
     */


    function parseCssTimeUnitsToMs(value) {
      // Some browsers will return it in seconds, whereas others will return milliseconds.

      /** @type {?} */
      var multiplier = value.toLowerCase().indexOf('ms') > -1 ? 1 : 1000;
      return parseFloat(value) * multiplier;
    }
    /**
     * Gets the transform transition duration, including the delay, of an element in milliseconds.
     * @param {?} element
     * @return {?}
     */


    function getTransformTransitionDurationInMs(element) {
      /** @type {?} */
      var computedStyle = getComputedStyle(element);
      /** @type {?} */

      var transitionedProperties = parseCssPropertyValue(computedStyle, 'transition-property');
      /** @type {?} */

      var property = transitionedProperties.find(
      /**
      * @param {?} prop
      * @return {?}
      */
      function (prop) {
        return prop === 'transform' || prop === 'all';
      }); // If there's no transition for `all` or `transform`, we shouldn't do anything.

      if (!property) {
        return 0;
      } // Get the index of the property that we're interested in and match
      // it up to the same index in `transition-delay` and `transition-duration`.

      /** @type {?} */


      var propertyIndex = transitionedProperties.indexOf(property);
      /** @type {?} */

      var rawDurations = parseCssPropertyValue(computedStyle, 'transition-duration');
      /** @type {?} */

      var rawDelays = parseCssPropertyValue(computedStyle, 'transition-delay');
      return parseCssTimeUnitsToMs(rawDurations[propertyIndex]) + parseCssTimeUnitsToMs(rawDelays[propertyIndex]);
    }
    /**
     * Parses out multiple values from a computed style into an array.
     * @param {?} computedStyle
     * @param {?} name
     * @return {?}
     */


    function parseCssPropertyValue(computedStyle, name) {
      /** @type {?} */
      var value = computedStyle.getPropertyValue(name);
      return value.split(',').map(
      /**
      * @param {?} part
      * @return {?}
      */
      function (part) {
        return part.trim();
      });
    }
    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    /**
     * Options that can be used to bind a passive event listener.
     * @type {?}
     */


    var passiveEventListenerOptions = Object(_angular_cdk_platform__WEBPACK_IMPORTED_MODULE_0__["normalizePassiveListenerOptions"])({
      passive: true
    });
    /**
     * Options that can be used to bind an active event listener.
     * @type {?}
     */

    var activeEventListenerOptions = Object(_angular_cdk_platform__WEBPACK_IMPORTED_MODULE_0__["normalizePassiveListenerOptions"])({
      passive: false
    });
    /**
     * Time in milliseconds for which to ignore mouse events, after
     * receiving a touch event. Used to avoid doing double work for
     * touch devices where the browser fires fake mouse events, in
     * addition to touch events.
     * @type {?}
     */

    var MOUSE_EVENT_IGNORE_TIME = 800;
    /**
     * Reference to a draggable item. Used to manipulate or dispose of the item.
     * \@docs-private
     * @template T
     */

    var DragRef = /*#__PURE__*/function () {
      /**
       * @param {?} element
       * @param {?} _config
       * @param {?} _document
       * @param {?} _ngZone
       * @param {?} _viewportRuler
       * @param {?} _dragDropRegistry
       */
      function DragRef(element, _config, _document, _ngZone, _viewportRuler, _dragDropRegistry) {
        var _this8 = this;

        _classCallCheck(this, DragRef);

        this._config = _config;
        this._document = _document;
        this._ngZone = _ngZone;
        this._viewportRuler = _viewportRuler;
        this._dragDropRegistry = _dragDropRegistry;
        /**
         * CSS `transform` applied to the element when it isn't being dragged. We need a
         * passive transform in order for the dragged element to retain its new position
         * after the user has stopped dragging and because we need to know the relative
         * position in case they start dragging again. This corresponds to `element.style.transform`.
         */

        this._passiveTransform = {
          x: 0,
          y: 0
        };
        /**
         * CSS `transform` that is applied to the element while it's being dragged.
         */

        this._activeTransform = {
          x: 0,
          y: 0
        };
        /**
         * Emits when the item is being moved.
         */

        this._moveEvents = new rxjs__WEBPACK_IMPORTED_MODULE_2__["Subject"]();
        /**
         * Subscription to pointer movement events.
         */

        this._pointerMoveSubscription = rxjs__WEBPACK_IMPORTED_MODULE_2__["Subscription"].EMPTY;
        /**
         * Subscription to the event that is dispatched when the user lifts their pointer.
         */

        this._pointerUpSubscription = rxjs__WEBPACK_IMPORTED_MODULE_2__["Subscription"].EMPTY;
        /**
         * Subscription to the viewport being scrolled.
         */

        this._scrollSubscription = rxjs__WEBPACK_IMPORTED_MODULE_2__["Subscription"].EMPTY;
        /**
         * Subscription to the viewport being resized.
         */

        this._resizeSubscription = rxjs__WEBPACK_IMPORTED_MODULE_2__["Subscription"].EMPTY;
        /**
         * Cached reference to the boundary element.
         */

        this._boundaryElement = null;
        /**
         * Whether the native dragging interactions have been enabled on the root element.
         */

        this._nativeInteractionsEnabled = true;
        /**
         * Elements that can be used to drag the draggable item.
         */

        this._handles = [];
        /**
         * Registered handles that are currently disabled.
         */

        this._disabledHandles = new Set();
        /**
         * Layout direction of the item.
         */

        this._direction = 'ltr';
        /**
         * Amount of milliseconds to wait after the user has put their
         * pointer down before starting to drag the element.
         */

        this.dragStartDelay = 0;
        this._disabled = false;
        /**
         * Emits as the drag sequence is being prepared.
         */

        this.beforeStarted = new rxjs__WEBPACK_IMPORTED_MODULE_2__["Subject"]();
        /**
         * Emits when the user starts dragging the item.
         */

        this.started = new rxjs__WEBPACK_IMPORTED_MODULE_2__["Subject"]();
        /**
         * Emits when the user has released a drag item, before any animations have started.
         */

        this.released = new rxjs__WEBPACK_IMPORTED_MODULE_2__["Subject"]();
        /**
         * Emits when the user stops dragging an item in the container.
         */

        this.ended = new rxjs__WEBPACK_IMPORTED_MODULE_2__["Subject"]();
        /**
         * Emits when the user has moved the item into a new container.
         */

        this.entered = new rxjs__WEBPACK_IMPORTED_MODULE_2__["Subject"]();
        /**
         * Emits when the user removes the item its container by dragging it into another container.
         */

        this.exited = new rxjs__WEBPACK_IMPORTED_MODULE_2__["Subject"]();
        /**
         * Emits when the user drops the item inside a container.
         */

        this.dropped = new rxjs__WEBPACK_IMPORTED_MODULE_2__["Subject"]();
        /**
         * Emits as the user is dragging the item. Use with caution,
         * because this event will fire for every pixel that the user has dragged.
         */

        this.moved = this._moveEvents.asObservable();
        /**
         * Handler for the `mousedown`/`touchstart` events.
         */

        this._pointerDown =
        /**
        * @param {?} event
        * @return {?}
        */
        function (event) {
          _this8.beforeStarted.next(); // Delegate the event based on whether it started from a handle or the element itself.


          if (_this8._handles.length) {
            /** @type {?} */
            var targetHandle = _this8._handles.find(
            /**
            * @param {?} handle
            * @return {?}
            */
            function (handle) {
              /** @type {?} */
              var target = event.target;
              return !!target && (target === handle || handle.contains(
              /** @type {?} */
              target));
            });

            if (targetHandle && !_this8._disabledHandles.has(targetHandle) && !_this8.disabled) {
              _this8._initializeDragSequence(targetHandle, event);
            }
          } else if (!_this8.disabled) {
            _this8._initializeDragSequence(_this8._rootElement, event);
          }
        };
        /**
         * Handler that is invoked when the user moves their pointer after they've initiated a drag.
         */


        this._pointerMove =
        /**
        * @param {?} event
        * @return {?}
        */
        function (event) {
          if (!_this8._hasStartedDragging) {
            /** @type {?} */
            var pointerPosition = _this8._getPointerPositionOnPage(event);
            /** @type {?} */


            var distanceX = Math.abs(pointerPosition.x - _this8._pickupPositionOnPage.x);
            /** @type {?} */

            var distanceY = Math.abs(pointerPosition.y - _this8._pickupPositionOnPage.y);
            /** @type {?} */

            var isOverThreshold = distanceX + distanceY >= _this8._config.dragStartThreshold; // Only start dragging after the user has moved more than the minimum distance in either
            // direction. Note that this is preferrable over doing something like `skip(minimumDistance)`
            // in the `pointerMove` subscription, because we're not guaranteed to have one move event
            // per pixel of movement (e.g. if the user moves their pointer quickly).

            if (isOverThreshold) {
              /** @type {?} */
              var isDelayElapsed = Date.now() >= _this8._dragStartTime + (_this8.dragStartDelay || 0);

              if (!isDelayElapsed) {
                _this8._endDragSequence(event);

                return;
              } // Prevent other drag sequences from starting while something in the container is still
              // being dragged. This can happen while we're waiting for the drop animation to finish
              // and can cause errors, because some elements might still be moving around.


              if (!_this8._dropContainer || !_this8._dropContainer.isDragging()) {
                _this8._hasStartedDragging = true;

                _this8._ngZone.run(
                /**
                * @return {?}
                */
                function () {
                  return _this8._startDragSequence(event);
                });
              }
            }

            return;
          } // We only need the preview dimensions if we have a boundary element.


          if (_this8._boundaryElement) {
            // Cache the preview element rect if we haven't cached it already or if
            // we cached it too early before the element dimensions were computed.
            if (!_this8._previewRect || !_this8._previewRect.width && !_this8._previewRect.height) {
              _this8._previewRect = (_this8._preview || _this8._rootElement).getBoundingClientRect();
            }
          }
          /** @type {?} */


          var constrainedPointerPosition = _this8._getConstrainedPointerPosition(event);

          _this8._hasMoved = true;
          event.preventDefault();

          _this8._updatePointerDirectionDelta(constrainedPointerPosition);

          if (_this8._dropContainer) {
            _this8._updateActiveDropContainer(constrainedPointerPosition);
          } else {
            /** @type {?} */
            var activeTransform = _this8._activeTransform;
            activeTransform.x = constrainedPointerPosition.x - _this8._pickupPositionOnPage.x + _this8._passiveTransform.x;
            activeTransform.y = constrainedPointerPosition.y - _this8._pickupPositionOnPage.y + _this8._passiveTransform.y;

            _this8._applyRootElementTransform(activeTransform.x, activeTransform.y); // Apply transform as attribute if dragging and svg element to work for IE


            if (typeof SVGElement !== 'undefined' && _this8._rootElement instanceof SVGElement) {
              /** @type {?} */
              var appliedTransform = "translate(".concat(activeTransform.x, " ").concat(activeTransform.y, ")");

              _this8._rootElement.setAttribute('transform', appliedTransform);
            }
          } // Since this event gets fired for every pixel while dragging, we only
          // want to fire it if the consumer opted into it. Also we have to
          // re-enter the zone because we run all of the events on the outside.


          if (_this8._moveEvents.observers.length) {
            _this8._ngZone.run(
            /**
            * @return {?}
            */
            function () {
              _this8._moveEvents.next({
                source: _this8,
                pointerPosition: constrainedPointerPosition,
                event: event,
                distance: _this8._getDragDistance(constrainedPointerPosition),
                delta: _this8._pointerDirectionDelta
              });
            });
          }
        };
        /**
         * Handler that is invoked when the user lifts their pointer up, after initiating a drag.
         */


        this._pointerUp =
        /**
        * @param {?} event
        * @return {?}
        */
        function (event) {
          _this8._endDragSequence(event);
        };

        this.withRootElement(element);

        _dragDropRegistry.registerDragItem(this);
      }
      /**
       * Whether starting to drag this element is disabled.
       * @return {?}
       */


      _createClass(DragRef, [{
        key: "getPlaceholderElement",

        /**
         * Returns the element that is being used as a placeholder
         * while the current element is being dragged.
         * @return {?}
         */
        value: function getPlaceholderElement() {
          return this._placeholder;
        }
        /**
         * Returns the root draggable element.
         * @return {?}
         */

      }, {
        key: "getRootElement",
        value: function getRootElement() {
          return this._rootElement;
        }
        /**
         * Registers the handles that can be used to drag the element.
         * @template THIS
         * @this {THIS}
         * @param {?} handles
         * @return {THIS}
         */

      }, {
        key: "withHandles",
        value: function withHandles(handles) {
          /** @type {?} */
          this._handles = handles.map(
          /**
          * @param {?} handle
          * @return {?}
          */
          function (handle) {
            return Object(_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_1__["coerceElement"])(handle);
          });

          /** @type {?} */
          this._handles.forEach(
          /**
          * @param {?} handle
          * @return {?}
          */
          function (handle) {
            return toggleNativeDragInteractions(handle, false);
          });

          /** @type {?} */
          this._toggleNativeDragInteractions();

          return (
            /** @type {?} */
            this
          );
        }
        /**
         * Registers the template that should be used for the drag preview.
         * @template THIS
         * @this {THIS}
         * @param {?} template Template that from which to stamp out the preview.
         * @return {THIS}
         */

      }, {
        key: "withPreviewTemplate",
        value: function withPreviewTemplate(template) {
          /** @type {?} */
          this._previewTemplate = template;
          return (
            /** @type {?} */
            this
          );
        }
        /**
         * Registers the template that should be used for the drag placeholder.
         * @template THIS
         * @this {THIS}
         * @param {?} template Template that from which to stamp out the placeholder.
         * @return {THIS}
         */

      }, {
        key: "withPlaceholderTemplate",
        value: function withPlaceholderTemplate(template) {
          /** @type {?} */
          this._placeholderTemplate = template;
          return (
            /** @type {?} */
            this
          );
        }
        /**
         * Sets an alternate drag root element. The root element is the element that will be moved as
         * the user is dragging. Passing an alternate root element is useful when trying to enable
         * dragging on an element that you might not have access to.
         * @template THIS
         * @this {THIS}
         * @param {?} rootElement
         * @return {THIS}
         */

      }, {
        key: "withRootElement",
        value: function withRootElement(rootElement) {
          /** @type {?} */
          var element = Object(_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_1__["coerceElement"])(rootElement);

          if (element !==
          /** @type {?} */
          this._rootElement) {
            if (
            /** @type {?} */
            this._rootElement) {
              /** @type {?} */
              this._removeRootElementListeners(
              /** @type {?} */
              this._rootElement);
            }

            element.addEventListener('mousedown',
            /** @type {?} */
            this._pointerDown, activeEventListenerOptions);
            element.addEventListener('touchstart',
            /** @type {?} */
            this._pointerDown, passiveEventListenerOptions);

            /** @type {?} */
            this._initialTransform = undefined;

            /** @type {?} */
            this._rootElement = element;
          }

          return (
            /** @type {?} */
            this
          );
        }
        /**
         * Element to which the draggable's position will be constrained.
         * @template THIS
         * @this {THIS}
         * @param {?} boundaryElement
         * @return {THIS}
         */

      }, {
        key: "withBoundaryElement",
        value: function withBoundaryElement(boundaryElement) {
          var _this9 = this;

          /** @type {?} */
          this._boundaryElement = boundaryElement ? Object(_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_1__["coerceElement"])(boundaryElement) : null;

          /** @type {?} */
          this._resizeSubscription.unsubscribe();

          if (boundaryElement) {
            /** @type {?} */
            this._resizeSubscription =
            /** @type {?} */
            this._viewportRuler.change(10).subscribe(
            /**
            * @return {?}
            */
            function () {
              return (
                /** @type {?} */
                _this9._containInsideBoundaryOnResize()
              );
            });
          }

          return (
            /** @type {?} */
            this
          );
        }
        /**
         * Removes the dragging functionality from the DOM element.
         * @return {?}
         */

      }, {
        key: "dispose",
        value: function dispose() {
          this._removeRootElementListeners(this._rootElement); // Do this check before removing from the registry since it'll
          // stop being considered as dragged once it is removed.


          if (this.isDragging()) {
            // Since we move out the element to the end of the body while it's being
            // dragged, we have to make sure that it's removed if it gets destroyed.
            removeElement(this._rootElement);
          }

          this._destroyPreview();

          this._destroyPlaceholder();

          this._dragDropRegistry.removeDragItem(this);

          this._removeSubscriptions();

          this.beforeStarted.complete();
          this.started.complete();
          this.released.complete();
          this.ended.complete();
          this.entered.complete();
          this.exited.complete();
          this.dropped.complete();

          this._moveEvents.complete();

          this._handles = [];

          this._disabledHandles.clear();

          this._dropContainer = undefined;
          this._boundaryElement = this._rootElement = this._placeholderTemplate = this._previewTemplate = this._nextSibling =
          /** @type {?} */
          null;
        }
        /**
         * Checks whether the element is currently being dragged.
         * @return {?}
         */

      }, {
        key: "isDragging",
        value: function isDragging() {
          return this._hasStartedDragging && this._dragDropRegistry.isDragging(this);
        }
        /**
         * Resets a standalone drag item to its initial position.
         * @return {?}
         */

      }, {
        key: "reset",
        value: function reset() {
          this._rootElement.style.transform = this._initialTransform || '';
          this._activeTransform = {
            x: 0,
            y: 0
          };
          this._passiveTransform = {
            x: 0,
            y: 0
          };
        }
        /**
         * Sets a handle as disabled. While a handle is disabled, it'll capture and interrupt dragging.
         * @param {?} handle Handle element that should be disabled.
         * @return {?}
         */

      }, {
        key: "disableHandle",
        value: function disableHandle(handle) {
          if (this._handles.indexOf(handle) > -1) {
            this._disabledHandles.add(handle);
          }
        }
        /**
         * Enables a handle, if it has been disabled.
         * @param {?} handle Handle element to be enabled.
         * @return {?}
         */

      }, {
        key: "enableHandle",
        value: function enableHandle(handle) {
          this._disabledHandles["delete"](handle);
        }
        /**
         * Sets the layout direction of the draggable item.
         * @template THIS
         * @this {THIS}
         * @param {?} direction
         * @return {THIS}
         */

      }, {
        key: "withDirection",
        value: function withDirection(direction) {
          /** @type {?} */
          this._direction = direction;
          return (
            /** @type {?} */
            this
          );
        }
        /**
         * Sets the container that the item is part of.
         * @param {?} container
         * @return {?}
         */

      }, {
        key: "_withDropContainer",
        value: function _withDropContainer(container) {
          this._dropContainer = container;
        }
        /**
         * Gets the current position in pixels the draggable outside of a drop container.
         * @return {?}
         */

      }, {
        key: "getFreeDragPosition",
        value: function getFreeDragPosition() {
          /** @type {?} */
          var position = this.isDragging() ? this._activeTransform : this._passiveTransform;
          return {
            x: position.x,
            y: position.y
          };
        }
        /**
         * Sets the current position in pixels the draggable outside of a drop container.
         * @template THIS
         * @this {THIS}
         * @param {?} value New position to be set.
         * @return {THIS}
         */

      }, {
        key: "setFreeDragPosition",
        value: function setFreeDragPosition(value) {
          /** @type {?} */
          this._activeTransform = {
            x: 0,
            y: 0
          };

          /** @type {?} */
          this._passiveTransform.x = value.x;

          /** @type {?} */
          this._passiveTransform.y = value.y;

          if (!
          /** @type {?} */
          this._dropContainer) {
            /** @type {?} */
            this._applyRootElementTransform(value.x, value.y);
          }

          return (
            /** @type {?} */
            this
          );
        }
        /**
         * Updates the item's sort order based on the last-known pointer position.
         * @return {?}
         */

      }, {
        key: "_sortFromLastPointerPosition",
        value: function _sortFromLastPointerPosition() {
          /** @type {?} */
          var position = this._pointerPositionAtLastDirectionChange;

          if (position && this._dropContainer) {
            this._updateActiveDropContainer(position);
          }
        }
        /**
         * Unsubscribes from the global subscriptions.
         * @private
         * @return {?}
         */

      }, {
        key: "_removeSubscriptions",
        value: function _removeSubscriptions() {
          this._pointerMoveSubscription.unsubscribe();

          this._pointerUpSubscription.unsubscribe();

          this._scrollSubscription.unsubscribe();
        }
        /**
         * Destroys the preview element and its ViewRef.
         * @private
         * @return {?}
         */

      }, {
        key: "_destroyPreview",
        value: function _destroyPreview() {
          if (this._preview) {
            removeElement(this._preview);
          }

          if (this._previewRef) {
            this._previewRef.destroy();
          }

          this._preview = this._previewRef =
          /** @type {?} */
          null;
        }
        /**
         * Destroys the placeholder element and its ViewRef.
         * @private
         * @return {?}
         */

      }, {
        key: "_destroyPlaceholder",
        value: function _destroyPlaceholder() {
          if (this._placeholder) {
            removeElement(this._placeholder);
          }

          if (this._placeholderRef) {
            this._placeholderRef.destroy();
          }

          this._placeholder = this._placeholderRef =
          /** @type {?} */
          null;
        }
        /**
         * Clears subscriptions and stops the dragging sequence.
         * @private
         * @param {?} event Browser event object that ended the sequence.
         * @return {?}
         */

      }, {
        key: "_endDragSequence",
        value: function _endDragSequence(event) {
          var _this10 = this;

          // Note that here we use `isDragging` from the service, rather than from `this`.
          // The difference is that the one from the service reflects whether a dragging sequence
          // has been initiated, whereas the one on `this` includes whether the user has passed
          // the minimum dragging threshold.
          if (!this._dragDropRegistry.isDragging(this)) {
            return;
          }

          this._removeSubscriptions();

          this._dragDropRegistry.stopDragging(this);

          this._toggleNativeDragInteractions();

          if (this._handles) {
            this._rootElement.style.webkitTapHighlightColor = this._rootElementTapHighlight;
          }

          if (!this._hasStartedDragging) {
            return;
          }

          this.released.next({
            source: this
          });

          if (this._dropContainer) {
            // Stop scrolling immediately, instead of waiting for the animation to finish.
            this._dropContainer._stopScrolling();

            this._animatePreviewToPlaceholder().then(
            /**
            * @return {?}
            */
            function () {
              _this10._cleanupDragArtifacts(event);

              _this10._cleanupCachedDimensions();

              _this10._dragDropRegistry.stopDragging(_this10);
            });
          } else {
            // Convert the active transform into a passive one. This means that next time
            // the user starts dragging the item, its position will be calculated relatively
            // to the new passive transform.
            this._passiveTransform.x = this._activeTransform.x;
            this._passiveTransform.y = this._activeTransform.y;

            this._ngZone.run(
            /**
            * @return {?}
            */
            function () {
              _this10.ended.next({
                source: _this10,
                distance: _this10._getDragDistance(_this10._getPointerPositionOnPage(event))
              });
            });

            this._cleanupCachedDimensions();

            this._dragDropRegistry.stopDragging(this);
          }
        }
        /**
         * Starts the dragging sequence.
         * @private
         * @param {?} event
         * @return {?}
         */

      }, {
        key: "_startDragSequence",
        value: function _startDragSequence(event) {
          // Emit the event on the item before the one on the container.
          this.started.next({
            source: this
          });

          if (isTouchEvent(event)) {
            this._lastTouchEventTime = Date.now();
          }

          this._toggleNativeDragInteractions();

          if (this._dropContainer) {
            /** @type {?} */
            var element = this._rootElement; // Grab the `nextSibling` before the preview and placeholder
            // have been created so we don't get the preview by accident.

            this._nextSibling = element.nextSibling;
            /** @type {?} */

            var preview = this._preview = this._createPreviewElement();
            /** @type {?} */


            var placeholder = this._placeholder = this._createPlaceholderElement(); // We move the element out at the end of the body and we make it hidden, because keeping it in
            // place will throw off the consumer's `:last-child` selectors. We can't remove the element
            // from the DOM completely, because iOS will stop firing all subsequent events in the chain.


            element.style.display = 'none';

            this._document.body.appendChild(
            /** @type {?} */
            element.parentNode.replaceChild(placeholder, element));

            getPreviewInsertionPoint(this._document).appendChild(preview);

            this._dropContainer.start();
          }
        }
        /**
         * Sets up the different variables and subscriptions
         * that will be necessary for the dragging sequence.
         * @private
         * @param {?} referenceElement Element that started the drag sequence.
         * @param {?} event Browser event object that started the sequence.
         * @return {?}
         */

      }, {
        key: "_initializeDragSequence",
        value: function _initializeDragSequence(referenceElement, event) {
          var _this11 = this;

          // Always stop propagation for the event that initializes
          // the dragging sequence, in order to prevent it from potentially
          // starting another sequence for a draggable parent somewhere up the DOM tree.
          event.stopPropagation();
          /** @type {?} */

          var isDragging = this.isDragging();
          /** @type {?} */

          var isTouchSequence = isTouchEvent(event);
          /** @type {?} */

          var isAuxiliaryMouseButton = !isTouchSequence &&
          /** @type {?} */
          event.button !== 0;
          /** @type {?} */

          var rootElement = this._rootElement;
          /** @type {?} */

          var isSyntheticEvent = !isTouchSequence && this._lastTouchEventTime && this._lastTouchEventTime + MOUSE_EVENT_IGNORE_TIME > Date.now(); // If the event started from an element with the native HTML drag&drop, it'll interfere
          // with our own dragging (e.g. `img` tags do it by default). Prevent the default action
          // to stop it from happening. Note that preventing on `dragstart` also seems to work, but
          // it's flaky and it fails if the user drags it away quickly. Also note that we only want
          // to do this for `mousedown` since doing the same for `touchstart` will stop any `click`
          // events from firing on touch devices.

          if (event.target &&
          /** @type {?} */
          event.target.draggable && event.type === 'mousedown') {
            event.preventDefault();
          } // Abort if the user is already dragging or is using a mouse button other than the primary one.


          if (isDragging || isAuxiliaryMouseButton || isSyntheticEvent) {
            return;
          } // If we've got handles, we need to disable the tap highlight on the entire root element,
          // otherwise iOS will still add it, even though all the drag interactions on the handle
          // are disabled.


          if (this._handles.length) {
            this._rootElementTapHighlight = rootElement.style.webkitTapHighlightColor;
            rootElement.style.webkitTapHighlightColor = 'transparent';
          }

          this._hasStartedDragging = this._hasMoved = false;
          this._initialContainer =
          /** @type {?} */
          this._dropContainer; // Avoid multiple subscriptions and memory leaks when multi touch
          // (isDragging check above isn't enough because of possible temporal and/or dimensional delays)

          this._removeSubscriptions();

          this._pointerMoveSubscription = this._dragDropRegistry.pointerMove.subscribe(this._pointerMove);
          this._pointerUpSubscription = this._dragDropRegistry.pointerUp.subscribe(this._pointerUp);
          this._scrollSubscription = this._dragDropRegistry.scroll.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["startWith"])(null)).subscribe(
          /**
          * @return {?}
          */
          function () {
            _this11._scrollPosition = _this11._viewportRuler.getViewportScrollPosition();
          });

          if (this._boundaryElement) {
            this._boundaryRect = this._boundaryElement.getBoundingClientRect();
          } // If we have a custom preview template, the element won't be visible anyway so we avoid the
          // extra `getBoundingClientRect` calls and just move the preview next to the cursor.


          this._pickupPositionInElement = this._previewTemplate && this._previewTemplate.template ? {
            x: 0,
            y: 0
          } : this._getPointerPositionInElement(referenceElement, event);
          /** @type {?} */

          var pointerPosition = this._pickupPositionOnPage = this._getPointerPositionOnPage(event);

          this._pointerDirectionDelta = {
            x: 0,
            y: 0
          };
          this._pointerPositionAtLastDirectionChange = {
            x: pointerPosition.x,
            y: pointerPosition.y
          };
          this._dragStartTime = Date.now();

          this._dragDropRegistry.startDragging(this, event);
        }
        /**
         * Cleans up the DOM artifacts that were added to facilitate the element being dragged.
         * @private
         * @param {?} event
         * @return {?}
         */

      }, {
        key: "_cleanupDragArtifacts",
        value: function _cleanupDragArtifacts(event) {
          var _this12 = this;

          // Restore the element's visibility and insert it at its old position in the DOM.
          // It's important that we maintain the position, because moving the element around in the DOM
          // can throw off `NgFor` which does smart diffing and re-creates elements only when necessary,
          // while moving the existing elements in all other cases.
          this._rootElement.style.display = '';

          if (this._nextSibling) {
            /** @type {?} */
            this._nextSibling.parentNode.insertBefore(this._rootElement, this._nextSibling);
          } else {
            Object(_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_1__["coerceElement"])(this._initialContainer.element).appendChild(this._rootElement);
          }

          this._destroyPreview();

          this._destroyPlaceholder();

          this._boundaryRect = this._previewRect = undefined; // Re-enter the NgZone since we bound `document` events on the outside.

          this._ngZone.run(
          /**
          * @return {?}
          */
          function () {
            /** @type {?} */
            var container =
            /** @type {?} */
            _this12._dropContainer;
            /** @type {?} */

            var currentIndex = container.getItemIndex(_this12);
            /** @type {?} */

            var pointerPosition = _this12._getPointerPositionOnPage(event);
            /** @type {?} */


            var distance = _this12._getDragDistance(_this12._getPointerPositionOnPage(event));
            /** @type {?} */


            var isPointerOverContainer = container._isOverContainer(pointerPosition.x, pointerPosition.y);

            _this12.ended.next({
              source: _this12,
              distance: distance
            });

            _this12.dropped.next({
              item: _this12,
              currentIndex: currentIndex,
              previousIndex: _this12._initialContainer.getItemIndex(_this12),
              container: container,
              previousContainer: _this12._initialContainer,
              isPointerOverContainer: isPointerOverContainer,
              distance: distance
            });

            container.drop(_this12, currentIndex, _this12._initialContainer, isPointerOverContainer, distance);
            _this12._dropContainer = _this12._initialContainer;
          });
        }
        /**
         * Updates the item's position in its drop container, or moves it
         * into a new one, depending on its current drag position.
         * @private
         * @param {?} __0
         * @return {?}
         */

      }, {
        key: "_updateActiveDropContainer",
        value: function _updateActiveDropContainer(_ref) {
          var _this13 = this;

          var x = _ref.x,
              y = _ref.y;

          // Drop container that draggable has been moved into.

          /** @type {?} */
          var newContainer = this._initialContainer._getSiblingContainerFromPosition(this, x, y); // If we couldn't find a new container to move the item into, and the item has left its
          // initial container, check whether the it's over the initial container. This handles the
          // case where two containers are connected one way and the user tries to undo dragging an
          // item into a new container.


          if (!newContainer && this._dropContainer !== this._initialContainer && this._initialContainer._isOverContainer(x, y)) {
            newContainer = this._initialContainer;
          }

          if (newContainer && newContainer !== this._dropContainer) {
            this._ngZone.run(
            /**
            * @return {?}
            */
            function () {
              // Notify the old container that the item has left.
              _this13.exited.next({
                item: _this13,
                container:
                /** @type {?} */
                _this13._dropContainer
              });

              /** @type {?} */
              _this13._dropContainer.exit(_this13); // Notify the new container that the item has entered.


              _this13._dropContainer =
              /** @type {?} */
              newContainer;

              _this13._dropContainer.enter(_this13, x, y);

              _this13.entered.next({
                item: _this13,
                container:
                /** @type {?} */
                newContainer,
                currentIndex:
                /** @type {?} */
                newContainer.getItemIndex(_this13)
              });
            });
          }

          /** @type {?} */
          this._dropContainer._startScrollingIfNecessary(x, y);

          /** @type {?} */
          this._dropContainer._sortItem(this, x, y, this._pointerDirectionDelta);

          this._preview.style.transform = getTransform(x - this._pickupPositionInElement.x, y - this._pickupPositionInElement.y);
        }
        /**
         * Creates the element that will be rendered next to the user's pointer
         * and will be used as a preview of the element that is being dragged.
         * @private
         * @return {?}
         */

      }, {
        key: "_createPreviewElement",
        value: function _createPreviewElement() {
          /** @type {?} */
          var previewConfig = this._previewTemplate;
          /** @type {?} */

          var previewTemplate = previewConfig ? previewConfig.template : null;
          /** @type {?} */

          var preview;

          if (previewTemplate) {
            /** @type {?} */
            var viewRef =
            /** @type {?} */
            previewConfig.viewContainer.createEmbeddedView(previewTemplate,
            /** @type {?} */
            previewConfig.context);
            preview = getRootNode(viewRef, this._document);
            this._previewRef = viewRef;
            preview.style.transform = getTransform(this._pickupPositionOnPage.x, this._pickupPositionOnPage.y);
          } else {
            /** @type {?} */
            var element = this._rootElement;
            /** @type {?} */

            var elementRect = element.getBoundingClientRect();
            preview = deepCloneNode(element);
            preview.style.width = "".concat(elementRect.width, "px");
            preview.style.height = "".concat(elementRect.height, "px");
            preview.style.transform = getTransform(elementRect.left, elementRect.top);
          }

          extendStyles(preview.style, {
            // It's important that we disable the pointer events on the preview, because
            // it can throw off the `document.elementFromPoint` calls in the `CdkDropList`.
            pointerEvents: 'none',
            // We have to reset the margin, because can throw off positioning relative to the viewport.
            margin: '0',
            position: 'fixed',
            top: '0',
            left: '0',
            zIndex: '1000'
          });
          toggleNativeDragInteractions(preview, false);
          preview.classList.add('cdk-drag-preview');
          preview.setAttribute('dir', this._direction);
          return preview;
        }
        /**
         * Animates the preview element from its current position to the location of the drop placeholder.
         * @private
         * @return {?} Promise that resolves when the animation completes.
         */

      }, {
        key: "_animatePreviewToPlaceholder",
        value: function _animatePreviewToPlaceholder() {
          var _this14 = this;

          // If the user hasn't moved yet, the transitionend event won't fire.
          if (!this._hasMoved) {
            return Promise.resolve();
          }
          /** @type {?} */


          var placeholderRect = this._placeholder.getBoundingClientRect(); // Apply the class that adds a transition to the preview.


          this._preview.classList.add('cdk-drag-animating'); // Move the preview to the placeholder position.


          this._preview.style.transform = getTransform(placeholderRect.left, placeholderRect.top); // If the element doesn't have a `transition`, the `transitionend` event won't fire. Since
          // we need to trigger a style recalculation in order for the `cdk-drag-animating` class to
          // apply its style, we take advantage of the available info to figure out whether we need to
          // bind the event in the first place.

          /** @type {?} */

          var duration = getTransformTransitionDurationInMs(this._preview);

          if (duration === 0) {
            return Promise.resolve();
          }

          return this._ngZone.runOutsideAngular(
          /**
          * @return {?}
          */
          function () {
            return new Promise(
            /**
            * @param {?} resolve
            * @return {?}
            */
            function (resolve) {
              /** @type {?} */
              var handler =
              /** @type {?} */

              /**
              * @param {?} event
              * @return {?}
              */
              function handler(event) {
                if (!event || event.target === _this14._preview && event.propertyName === 'transform') {
                  _this14._preview.removeEventListener('transitionend', handler);

                  resolve();
                  clearTimeout(timeout);
                }
              }; // If a transition is short enough, the browser might not fire the `transitionend` event.
              // Since we know how long it's supposed to take, add a timeout with a 50% buffer that'll
              // fire if the transition hasn't completed when it was supposed to.

              /** @type {?} */


              var timeout = setTimeout(
              /** @type {?} */
              handler, duration * 1.5);

              _this14._preview.addEventListener('transitionend', handler);
            });
          });
        }
        /**
         * Creates an element that will be shown instead of the current element while dragging.
         * @private
         * @return {?}
         */

      }, {
        key: "_createPlaceholderElement",
        value: function _createPlaceholderElement() {
          /** @type {?} */
          var placeholderConfig = this._placeholderTemplate;
          /** @type {?} */

          var placeholderTemplate = placeholderConfig ? placeholderConfig.template : null;
          /** @type {?} */

          var placeholder;

          if (placeholderTemplate) {
            this._placeholderRef =
            /** @type {?} */
            placeholderConfig.viewContainer.createEmbeddedView(placeholderTemplate,
            /** @type {?} */
            placeholderConfig.context);
            placeholder = getRootNode(this._placeholderRef, this._document);
          } else {
            placeholder = deepCloneNode(this._rootElement);
          }

          placeholder.classList.add('cdk-drag-placeholder');
          return placeholder;
        }
        /**
         * Figures out the coordinates at which an element was picked up.
         * @private
         * @param {?} referenceElement Element that initiated the dragging.
         * @param {?} event Event that initiated the dragging.
         * @return {?}
         */

      }, {
        key: "_getPointerPositionInElement",
        value: function _getPointerPositionInElement(referenceElement, event) {
          /** @type {?} */
          var elementRect = this._rootElement.getBoundingClientRect();
          /** @type {?} */


          var handleElement = referenceElement === this._rootElement ? null : referenceElement;
          /** @type {?} */

          var referenceRect = handleElement ? handleElement.getBoundingClientRect() : elementRect;
          /** @type {?} */

          var point = isTouchEvent(event) ? event.targetTouches[0] : event;
          /** @type {?} */

          var x = point.pageX - referenceRect.left - this._scrollPosition.left;
          /** @type {?} */

          var y = point.pageY - referenceRect.top - this._scrollPosition.top;
          return {
            x: referenceRect.left - elementRect.left + x,
            y: referenceRect.top - elementRect.top + y
          };
        }
        /**
         * Determines the point of the page that was touched by the user.
         * @private
         * @param {?} event
         * @return {?}
         */

      }, {
        key: "_getPointerPositionOnPage",
        value: function _getPointerPositionOnPage(event) {
          // `touches` will be empty for start/end events so we have to fall back to `changedTouches`.

          /** @type {?} */
          var point = isTouchEvent(event) ? event.touches[0] || event.changedTouches[0] : event;
          return {
            x: point.pageX - this._scrollPosition.left,
            y: point.pageY - this._scrollPosition.top
          };
        }
        /**
         * Gets the pointer position on the page, accounting for any position constraints.
         * @private
         * @param {?} event
         * @return {?}
         */

      }, {
        key: "_getConstrainedPointerPosition",
        value: function _getConstrainedPointerPosition(event) {
          /** @type {?} */
          var point = this._getPointerPositionOnPage(event);
          /** @type {?} */


          var constrainedPoint = this.constrainPosition ? this.constrainPosition(point, this) : point;
          /** @type {?} */

          var dropContainerLock = this._dropContainer ? this._dropContainer.lockAxis : null;

          if (this.lockAxis === 'x' || dropContainerLock === 'x') {
            constrainedPoint.y = this._pickupPositionOnPage.y;
          } else if (this.lockAxis === 'y' || dropContainerLock === 'y') {
            constrainedPoint.x = this._pickupPositionOnPage.x;
          }

          if (this._boundaryRect) {
            var _this$_pickupPosition = this._pickupPositionInElement,
                pickupX = _this$_pickupPosition.x,
                pickupY = _this$_pickupPosition.y;
            /** @type {?} */

            var boundaryRect = this._boundaryRect;
            /** @type {?} */

            var previewRect =
            /** @type {?} */
            this._previewRect;
            /** @type {?} */

            var minY = boundaryRect.top + pickupY;
            /** @type {?} */

            var maxY = boundaryRect.bottom - (previewRect.height - pickupY);
            /** @type {?} */

            var minX = boundaryRect.left + pickupX;
            /** @type {?} */

            var maxX = boundaryRect.right - (previewRect.width - pickupX);
            constrainedPoint.x = clamp(constrainedPoint.x, minX, maxX);
            constrainedPoint.y = clamp(constrainedPoint.y, minY, maxY);
          }

          return constrainedPoint;
        }
        /**
         * Updates the current drag delta, based on the user's current pointer position on the page.
         * @private
         * @param {?} pointerPositionOnPage
         * @return {?}
         */

      }, {
        key: "_updatePointerDirectionDelta",
        value: function _updatePointerDirectionDelta(pointerPositionOnPage) {
          var x = pointerPositionOnPage.x,
              y = pointerPositionOnPage.y;
          /** @type {?} */

          var delta = this._pointerDirectionDelta;
          /** @type {?} */

          var positionSinceLastChange = this._pointerPositionAtLastDirectionChange; // Amount of pixels the user has dragged since the last time the direction changed.

          /** @type {?} */

          var changeX = Math.abs(x - positionSinceLastChange.x);
          /** @type {?} */

          var changeY = Math.abs(y - positionSinceLastChange.y); // Because we handle pointer events on a per-pixel basis, we don't want the delta
          // to change for every pixel, otherwise anything that depends on it can look erratic.
          // To make the delta more consistent, we track how much the user has moved since the last
          // delta change and we only update it after it has reached a certain threshold.

          if (changeX > this._config.pointerDirectionChangeThreshold) {
            delta.x = x > positionSinceLastChange.x ? 1 : -1;
            positionSinceLastChange.x = x;
          }

          if (changeY > this._config.pointerDirectionChangeThreshold) {
            delta.y = y > positionSinceLastChange.y ? 1 : -1;
            positionSinceLastChange.y = y;
          }

          return delta;
        }
        /**
         * Toggles the native drag interactions, based on how many handles are registered.
         * @private
         * @return {?}
         */

      }, {
        key: "_toggleNativeDragInteractions",
        value: function _toggleNativeDragInteractions() {
          if (!this._rootElement || !this._handles) {
            return;
          }
          /** @type {?} */


          var shouldEnable = this._handles.length > 0 || !this.isDragging();

          if (shouldEnable !== this._nativeInteractionsEnabled) {
            this._nativeInteractionsEnabled = shouldEnable;
            toggleNativeDragInteractions(this._rootElement, shouldEnable);
          }
        }
        /**
         * Removes the manually-added event listeners from the root element.
         * @private
         * @param {?} element
         * @return {?}
         */

      }, {
        key: "_removeRootElementListeners",
        value: function _removeRootElementListeners(element) {
          element.removeEventListener('mousedown', this._pointerDown, activeEventListenerOptions);
          element.removeEventListener('touchstart', this._pointerDown, passiveEventListenerOptions);
        }
        /**
         * Applies a `transform` to the root element, taking into account any existing transforms on it.
         * @private
         * @param {?} x New transform value along the X axis.
         * @param {?} y New transform value along the Y axis.
         * @return {?}
         */

      }, {
        key: "_applyRootElementTransform",
        value: function _applyRootElementTransform(x, y) {
          /** @type {?} */
          var transform = getTransform(x, y); // Cache the previous transform amount only after the first drag sequence, because
          // we don't want our own transforms to stack on top of each other.

          if (this._initialTransform == null) {
            this._initialTransform = this._rootElement.style.transform || '';
          } // Preserve the previous `transform` value, if there was one. Note that we apply our own
          // transform before the user's, because things like rotation can affect which direction
          // the element will be translated towards.


          this._rootElement.style.transform = this._initialTransform ? transform + ' ' + this._initialTransform : transform;
        }
        /**
         * Gets the distance that the user has dragged during the current drag sequence.
         * @private
         * @param {?} currentPosition Current position of the user's pointer.
         * @return {?}
         */

      }, {
        key: "_getDragDistance",
        value: function _getDragDistance(currentPosition) {
          /** @type {?} */
          var pickupPosition = this._pickupPositionOnPage;

          if (pickupPosition) {
            return {
              x: currentPosition.x - pickupPosition.x,
              y: currentPosition.y - pickupPosition.y
            };
          }

          return {
            x: 0,
            y: 0
          };
        }
        /**
         * Cleans up any cached element dimensions that we don't need after dragging has stopped.
         * @private
         * @return {?}
         */

      }, {
        key: "_cleanupCachedDimensions",
        value: function _cleanupCachedDimensions() {
          this._boundaryRect = this._previewRect = undefined;
        }
        /**
         * Checks whether the element is still inside its boundary after the viewport has been resized.
         * If not, the position is adjusted so that the element fits again.
         * @private
         * @return {?}
         */

      }, {
        key: "_containInsideBoundaryOnResize",
        value: function _containInsideBoundaryOnResize() {
          var _this$_passiveTransfo = this._passiveTransform,
              x = _this$_passiveTransfo.x,
              y = _this$_passiveTransfo.y;

          if (x === 0 && y === 0 || this.isDragging() || !this._boundaryElement) {
            return;
          }
          /** @type {?} */


          var boundaryRect = this._boundaryElement.getBoundingClientRect();
          /** @type {?} */


          var elementRect = this._rootElement.getBoundingClientRect();
          /** @type {?} */


          var leftOverflow = boundaryRect.left - elementRect.left;
          /** @type {?} */

          var rightOverflow = elementRect.right - boundaryRect.right;
          /** @type {?} */

          var topOverflow = boundaryRect.top - elementRect.top;
          /** @type {?} */

          var bottomOverflow = elementRect.bottom - boundaryRect.bottom; // If the element has become wider than the boundary, we can't
          // do much to make it fit so we just anchor it to the left.

          if (boundaryRect.width > elementRect.width) {
            if (leftOverflow > 0) {
              x += leftOverflow;
            }

            if (rightOverflow > 0) {
              x -= rightOverflow;
            }
          } else {
            x = 0;
          } // If the element has become taller than the boundary, we can't
          // do much to make it fit so we just anchor it to the top.


          if (boundaryRect.height > elementRect.height) {
            if (topOverflow > 0) {
              y += topOverflow;
            }

            if (bottomOverflow > 0) {
              y -= bottomOverflow;
            }
          } else {
            y = 0;
          }

          if (x !== this._passiveTransform.x || y !== this._passiveTransform.y) {
            this.setFreeDragPosition({
              y: y,
              x: x
            });
          }
        }
      }, {
        key: "disabled",
        get: function get() {
          return this._disabled || !!(this._dropContainer && this._dropContainer.disabled);
        }
        /**
         * @param {?} value
         * @return {?}
         */
        ,
        set: function set(value) {
          /** @type {?} */
          var newValue = Object(_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_1__["coerceBooleanProperty"])(value);

          if (newValue !== this._disabled) {
            this._disabled = newValue;

            this._toggleNativeDragInteractions();
          }
        }
      }]);

      return DragRef;
    }();
    /**
     * Gets a 3d `transform` that can be applied to an element.
     * @param {?} x Desired position of the element along the X axis.
     * @param {?} y Desired position of the element along the Y axis.
     * @return {?}
     */


    function getTransform(x, y) {
      // Round the transforms since some browsers will
      // blur the elements for sub-pixel transforms.
      return "translate3d(".concat(Math.round(x), "px, ").concat(Math.round(y), "px, 0)");
    }
    /**
     * Creates a deep clone of an element.
     * @param {?} node
     * @return {?}
     */


    function deepCloneNode(node) {
      /** @type {?} */
      var clone =
      /** @type {?} */
      node.cloneNode(true);
      /** @type {?} */

      var descendantsWithId = clone.querySelectorAll('[id]');
      /** @type {?} */

      var descendantCanvases = node.querySelectorAll('canvas'); // Remove the `id` to avoid having multiple elements with the same id on the page.

      clone.removeAttribute('id');

      for (var i = 0; i < descendantsWithId.length; i++) {
        descendantsWithId[i].removeAttribute('id');
      } // `cloneNode` won't transfer the content of `canvas` elements so we have to do it ourselves.
      // We match up the cloned canvas to their sources using their index in the DOM.


      if (descendantCanvases.length) {
        /** @type {?} */
        var cloneCanvases = clone.querySelectorAll('canvas');

        for (var _i2 = 0; _i2 < descendantCanvases.length; _i2++) {
          /** @type {?} */
          var correspondingCloneContext = cloneCanvases[_i2].getContext('2d');

          if (correspondingCloneContext) {
            correspondingCloneContext.drawImage(descendantCanvases[_i2], 0, 0);
          }
        }
      }

      return clone;
    }
    /**
     * Clamps a value between a minimum and a maximum.
     * @param {?} value
     * @param {?} min
     * @param {?} max
     * @return {?}
     */


    function clamp(value, min, max) {
      return Math.max(min, Math.min(max, value));
    }
    /**
     * Helper to remove an element from the DOM and to do all the necessary null checks.
     * @param {?} element Element to be removed.
     * @return {?}
     */


    function removeElement(element) {
      if (element && element.parentNode) {
        element.parentNode.removeChild(element);
      }
    }
    /**
     * Determines whether an event is a touch event.
     * @param {?} event
     * @return {?}
     */


    function isTouchEvent(event) {
      // This function is called for every pixel that the user has dragged so we need it to be
      // as fast as possible. Since we only bind mouse events and touch events, we can assume
      // that if the event's name starts with `t`, it's a touch event.
      return event.type[0] === 't';
    }
    /**
     * Gets the element into which the drag preview should be inserted.
     * @param {?} documentRef
     * @return {?}
     */


    function getPreviewInsertionPoint(documentRef) {
      // We can't use the body if the user is in fullscreen mode,
      // because the preview will render under the fullscreen element.
      // TODO(crisbeto): dedupe this with the `FullscreenOverlayContainer` eventually.
      return documentRef.fullscreenElement || documentRef.webkitFullscreenElement || documentRef.mozFullScreenElement || documentRef.msFullscreenElement || documentRef.body;
    }
    /**
     * Gets the root HTML element of an embedded view.
     * If the root is not an HTML element it gets wrapped in one.
     * @param {?} viewRef
     * @param {?} _document
     * @return {?}
     */


    function getRootNode(viewRef, _document) {
      /** @type {?} */
      var rootNode = viewRef.rootNodes[0];

      if (rootNode.nodeType !== _document.ELEMENT_NODE) {
        /** @type {?} */
        var wrapper = _document.createElement('div');

        wrapper.appendChild(rootNode);
        return wrapper;
      }

      return (
        /** @type {?} */
        rootNode
      );
    }
    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    /**
     * Moves an item one index in an array to another.
     * @template T
     * @param {?} array Array in which to move the item.
     * @param {?} fromIndex Starting index of the item.
     * @param {?} toIndex Index to which the item should be moved.
     * @return {?}
     */


    function moveItemInArray(array, fromIndex, toIndex) {
      /** @type {?} */
      var from = clamp$1(fromIndex, array.length - 1);
      /** @type {?} */

      var to = clamp$1(toIndex, array.length - 1);

      if (from === to) {
        return;
      }
      /** @type {?} */


      var target = array[from];
      /** @type {?} */

      var delta = to < from ? -1 : 1;

      for (var i = from; i !== to; i += delta) {
        array[i] = array[i + delta];
      }

      array[to] = target;
    }
    /**
     * Moves an item from one array to another.
     * @template T
     * @param {?} currentArray Array from which to transfer the item.
     * @param {?} targetArray Array into which to put the item.
     * @param {?} currentIndex Index of the item in its current array.
     * @param {?} targetIndex Index at which to insert the item.
     * @return {?}
     */


    function transferArrayItem(currentArray, targetArray, currentIndex, targetIndex) {
      /** @type {?} */
      var from = clamp$1(currentIndex, currentArray.length - 1);
      /** @type {?} */

      var to = clamp$1(targetIndex, targetArray.length);

      if (currentArray.length) {
        targetArray.splice(to, 0, currentArray.splice(from, 1)[0]);
      }
    }
    /**
     * Copies an item from one array to another, leaving it in its
     * original position in current array.
     * @template T
     * @param {?} currentArray Array from which to copy the item.
     * @param {?} targetArray Array into which is copy the item.
     * @param {?} currentIndex Index of the item in its current array.
     * @param {?} targetIndex Index at which to insert the item.
     *
     * @return {?}
     */


    function copyArrayItem(currentArray, targetArray, currentIndex, targetIndex) {
      /** @type {?} */
      var to = clamp$1(targetIndex, targetArray.length);

      if (currentArray.length) {
        targetArray.splice(to, 0, currentArray[currentIndex]);
      }
    }
    /**
     * Clamps a number between zero and a maximum.
     * @param {?} value
     * @param {?} max
     * @return {?}
     */


    function clamp$1(value, max) {
      return Math.max(0, Math.min(max, value));
    }
    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    /**
     * Counter used to generate unique ids for drop refs.
     * @type {?}
     */


    var _uniqueIdCounter = 0;
    /**
     * Proximity, as a ratio to width/height, at which a
     * dragged item will affect the drop container.
     * @type {?}
     */

    var DROP_PROXIMITY_THRESHOLD = 0.05;
    /**
     * Proximity, as a ratio to width/height at which to start auto-scrolling the drop list or the
     * viewport. The value comes from trying it out manually until it feels right.
     * @type {?}
     */

    var SCROLL_PROXIMITY_THRESHOLD = 0.05;
    /**
     * Number of pixels to scroll for each frame when auto-scrolling an element.
     * The value comes from trying it out manually until it feels right.
     * @type {?}
     */

    var AUTO_SCROLL_STEP = 2;
    /**
     * Reference to a drop list. Used to manipulate or dispose of the container.
     * \@docs-private
     * @template T
     */

    var DropListRef = /*#__PURE__*/function () {
      /**
       * @param {?} element
       * @param {?} _dragDropRegistry
       * @param {?} _document
       * @param {?=} _ngZone
       * @param {?=} _viewportRuler
       */
      function DropListRef(element, _dragDropRegistry, _document, _ngZone, _viewportRuler) {
        var _this15 = this;

        _classCallCheck(this, DropListRef);

        this._dragDropRegistry = _dragDropRegistry;
        this._ngZone = _ngZone;
        this._viewportRuler = _viewportRuler;
        /**
         * Unique ID for the drop list.
         * @deprecated No longer being used. To be removed.
         * \@breaking-change 8.0.0
         */

        this.id = "cdk-drop-list-ref-".concat(_uniqueIdCounter++);
        /**
         * Whether starting a dragging sequence from this container is disabled.
         */

        this.disabled = false;
        /**
         * Whether sorting items within the list is disabled.
         */

        this.sortingDisabled = false;
        /**
         * Whether auto-scrolling the view when the user
         * moves their pointer close to the edges is disabled.
         */

        this.autoScrollDisabled = false;
        /**
         * Function that is used to determine whether an item
         * is allowed to be moved into a drop container.
         */

        this.enterPredicate =
        /**
        * @return {?}
        */
        function () {
          return true;
        };
        /**
         * Emits right before dragging has started.
         */


        this.beforeStarted = new rxjs__WEBPACK_IMPORTED_MODULE_2__["Subject"]();
        /**
         * Emits when the user has moved a new drag item into this container.
         */

        this.entered = new rxjs__WEBPACK_IMPORTED_MODULE_2__["Subject"]();
        /**
         * Emits when the user removes an item from the container
         * by dragging it into another container.
         */

        this.exited = new rxjs__WEBPACK_IMPORTED_MODULE_2__["Subject"]();
        /**
         * Emits when the user drops an item inside the container.
         */

        this.dropped = new rxjs__WEBPACK_IMPORTED_MODULE_2__["Subject"]();
        /**
         * Emits as the user is swapping items while actively dragging.
         */

        this.sorted = new rxjs__WEBPACK_IMPORTED_MODULE_2__["Subject"]();
        /**
         * Whether an item in the list is being dragged.
         */

        this._isDragging = false;
        /**
         * Cache of the dimensions of all the items inside the container.
         */

        this._itemPositions = [];
        /**
         * Keeps track of the container's scroll position.
         */

        this._scrollPosition = {
          top: 0,
          left: 0
        };
        /**
         * Keeps track of the scroll position of the viewport.
         */

        this._viewportScrollPosition = {
          top: 0,
          left: 0
        };
        /**
         * Keeps track of the item that was last swapped with the dragged item, as
         * well as what direction the pointer was moving in when the swap occured.
         */

        this._previousSwap = {
          drag:
          /** @type {?} */
          null,
          delta: 0
        };
        /**
         * Drop lists that are connected to the current one.
         */

        this._siblings = [];
        /**
         * Direction in which the list is oriented.
         */

        this._orientation = 'vertical';
        /**
         * Connected siblings that currently have a dragged item.
         */

        this._activeSiblings = new Set();
        /**
         * Layout direction of the drop list.
         */

        this._direction = 'ltr';
        /**
         * Subscription to the window being scrolled.
         */

        this._viewportScrollSubscription = rxjs__WEBPACK_IMPORTED_MODULE_2__["Subscription"].EMPTY;
        /**
         * Vertical direction in which the list is currently scrolling.
         */

        this._verticalScrollDirection = 0
        /* NONE */
        ;
        /**
         * Horizontal direction in which the list is currently scrolling.
         */

        this._horizontalScrollDirection = 0
        /* NONE */
        ;
        /**
         * Used to signal to the current auto-scroll sequence when to stop.
         */

        this._stopScrollTimers = new rxjs__WEBPACK_IMPORTED_MODULE_2__["Subject"]();
        /**
         * Handles the container being scrolled. Has to be an arrow function to preserve the context.
         */

        this._handleScroll =
        /**
        * @return {?}
        */
        function () {
          if (!_this15.isDragging()) {
            return;
          }
          /** @type {?} */


          var element = Object(_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_1__["coerceElement"])(_this15.element);

          _this15._updateAfterScroll(_this15._scrollPosition, element.scrollTop, element.scrollLeft);
        };
        /**
         * Starts the interval that'll auto-scroll the element.
         */


        this._startScrollInterval =
        /**
        * @return {?}
        */
        function () {
          _this15._stopScrolling();

          Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["interval"])(0, rxjs__WEBPACK_IMPORTED_MODULE_2__["animationFrameScheduler"]).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["takeUntil"])(_this15._stopScrollTimers)).subscribe(
          /**
          * @return {?}
          */
          function () {
            /** @type {?} */
            var node = _this15._scrollNode;

            if (_this15._verticalScrollDirection === 1
            /* UP */
            ) {
                incrementVerticalScroll(node, -AUTO_SCROLL_STEP);
              } else if (_this15._verticalScrollDirection === 2
            /* DOWN */
            ) {
                incrementVerticalScroll(node, AUTO_SCROLL_STEP);
              }

            if (_this15._horizontalScrollDirection === 1
            /* LEFT */
            ) {
                incrementHorizontalScroll(node, -AUTO_SCROLL_STEP);
              } else if (_this15._horizontalScrollDirection === 2
            /* RIGHT */
            ) {
                incrementHorizontalScroll(node, AUTO_SCROLL_STEP);
              }
          });
        };
        /** @type {?} */


        var nativeNode = this.element = Object(_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_1__["coerceElement"])(element);
        this._shadowRoot = getShadowRoot(nativeNode) || _document;

        _dragDropRegistry.registerDropContainer(this);
      }
      /**
       * Removes the drop list functionality from the DOM element.
       * @return {?}
       */


      _createClass(DropListRef, [{
        key: "dispose",
        value: function dispose() {
          this._stopScrolling();

          this._stopScrollTimers.complete();

          this._removeListeners();

          this.beforeStarted.complete();
          this.entered.complete();
          this.exited.complete();
          this.dropped.complete();
          this.sorted.complete();

          this._activeSiblings.clear();

          this._scrollNode =
          /** @type {?} */
          null;

          this._dragDropRegistry.removeDropContainer(this);
        }
        /**
         * Whether an item from this list is currently being dragged.
         * @return {?}
         */

      }, {
        key: "isDragging",
        value: function isDragging() {
          return this._isDragging;
        }
        /**
         * Starts dragging an item.
         * @return {?}
         */

      }, {
        key: "start",
        value: function start() {
          var _this16 = this;

          /** @type {?} */
          var element = Object(_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_1__["coerceElement"])(this.element);
          this.beforeStarted.next();
          this._isDragging = true;

          this._cacheItems();

          this._siblings.forEach(
          /**
          * @param {?} sibling
          * @return {?}
          */
          function (sibling) {
            return sibling._startReceiving(_this16);
          });

          this._removeListeners(); // @breaking-change 9.0.0 Remove check for _ngZone once it's marked as a required param.


          if (this._ngZone) {
            this._ngZone.runOutsideAngular(
            /**
            * @return {?}
            */
            function () {
              return element.addEventListener('scroll', _this16._handleScroll);
            });
          } else {
            element.addEventListener('scroll', this._handleScroll);
          } // @breaking-change 9.0.0 Remove check for _viewportRuler once it's marked as a required param.


          if (this._viewportRuler) {
            this._listenToScrollEvents();
          }
        }
        /**
         * Emits an event to indicate that the user moved an item into the container.
         * @param {?} item Item that was moved into the container.
         * @param {?} pointerX Position of the item along the X axis.
         * @param {?} pointerY Position of the item along the Y axis.
         * @return {?}
         */

      }, {
        key: "enter",
        value: function enter(item, pointerX, pointerY) {
          this.start(); // If sorting is disabled, we want the item to return to its starting
          // position if the user is returning it to its initial container.

          /** @type {?} */

          var newIndex = this.sortingDisabled ? this._draggables.indexOf(item) : -1;

          if (newIndex === -1) {
            // We use the coordinates of where the item entered the drop
            // zone to figure out at which index it should be inserted.
            newIndex = this._getItemIndexFromPointerPosition(item, pointerX, pointerY);
          }
          /** @type {?} */


          var activeDraggables = this._activeDraggables;
          /** @type {?} */

          var currentIndex = activeDraggables.indexOf(item);
          /** @type {?} */

          var placeholder = item.getPlaceholderElement();
          /** @type {?} */

          var newPositionReference = activeDraggables[newIndex]; // If the item at the new position is the same as the item that is being dragged,
          // it means that we're trying to restore the item to its initial position. In this
          // case we should use the next item from the list as the reference.

          if (newPositionReference === item) {
            newPositionReference = activeDraggables[newIndex + 1];
          } // Since the item may be in the `activeDraggables` already (e.g. if the user dragged it
          // into another container and back again), we have to ensure that it isn't duplicated.


          if (currentIndex > -1) {
            activeDraggables.splice(currentIndex, 1);
          } // Don't use items that are being dragged as a reference, because
          // their element has been moved down to the bottom of the body.


          if (newPositionReference && !this._dragDropRegistry.isDragging(newPositionReference)) {
            /** @type {?} */
            var element = newPositionReference.getRootElement();

            /** @type {?} */
            element.parentElement.insertBefore(placeholder, element);
            activeDraggables.splice(newIndex, 0, item);
          } else {
            Object(_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_1__["coerceElement"])(this.element).appendChild(placeholder);
            activeDraggables.push(item);
          } // The transform needs to be cleared so it doesn't throw off the measurements.


          placeholder.style.transform = ''; // Note that the positions were already cached when we called `start` above,
          // but we need to refresh them since the amount of items has changed.

          this._cacheItemPositions();

          this.entered.next({
            item: item,
            container: this,
            currentIndex: this.getItemIndex(item)
          });
        }
        /**
         * Removes an item from the container after it was dragged into another container by the user.
         * @param {?} item Item that was dragged out.
         * @return {?}
         */

      }, {
        key: "exit",
        value: function exit(item) {
          this._reset();

          this.exited.next({
            item: item,
            container: this
          });
        }
        /**
         * Drops an item into this container.
         * \@breaking-change 9.0.0 `distance` parameter to become required.
         * @param {?} item Item being dropped into the container.
         * @param {?} currentIndex Index at which the item should be inserted.
         * @param {?} previousContainer Container from which the item got dragged in.
         * @param {?} isPointerOverContainer Whether the user's pointer was over the
         *    container when the item was dropped.
         * @param {?=} distance Distance the user has dragged since the start of the dragging sequence.
         * @return {?}
         */

      }, {
        key: "drop",
        value: function drop(item, currentIndex, previousContainer, isPointerOverContainer) {
          var distance = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : {
            x: 0,
            y: 0
          };

          this._reset();

          this.dropped.next({
            item: item,
            currentIndex: currentIndex,
            previousIndex: previousContainer.getItemIndex(item),
            container: this,
            previousContainer: previousContainer,
            isPointerOverContainer: isPointerOverContainer,
            distance: distance
          });
        }
        /**
         * Sets the draggable items that are a part of this list.
         * @template THIS
         * @this {THIS}
         * @param {?} items Items that are a part of this list.
         * @return {THIS}
         */

      }, {
        key: "withItems",
        value: function withItems(items) {
          var _this17 = this;

          /** @type {?} */
          this._draggables = items;
          items.forEach(
          /**
          * @param {?} item
          * @return {?}
          */
          function (item) {
            return item._withDropContainer(
            /** @type {?} */
            _this17);
          });

          if (
          /** @type {?} */
          this.isDragging()) {
            /** @type {?} */
            this._cacheItems();
          }

          return (
            /** @type {?} */
            this
          );
        }
        /**
         * Sets the layout direction of the drop list.
         * @template THIS
         * @this {THIS}
         * @param {?} direction
         * @return {THIS}
         */

      }, {
        key: "withDirection",
        value: function withDirection(direction) {
          /** @type {?} */
          this._direction = direction;
          return (
            /** @type {?} */
            this
          );
        }
        /**
         * Sets the containers that are connected to this one. When two or more containers are
         * connected, the user will be allowed to transfer items between them.
         * @template THIS
         * @this {THIS}
         * @param {?} connectedTo Other containers that the current containers should be connected to.
         * @return {THIS}
         */

      }, {
        key: "connectedTo",
        value: function connectedTo(_connectedTo) {
          /** @type {?} */
          this._siblings = _connectedTo.slice();
          return (
            /** @type {?} */
            this
          );
        }
        /**
         * Sets the orientation of the container.
         * @template THIS
         * @this {THIS}
         * @param {?} orientation New orientation for the container.
         * @return {THIS}
         */

      }, {
        key: "withOrientation",
        value: function withOrientation(orientation) {
          /** @type {?} */
          this._orientation = orientation;
          return (
            /** @type {?} */
            this
          );
        }
        /**
         * Figures out the index of an item in the container.
         * @param {?} item Item whose index should be determined.
         * @return {?}
         */

      }, {
        key: "getItemIndex",
        value: function getItemIndex(item) {
          if (!this._isDragging) {
            return this._draggables.indexOf(item);
          } // Items are sorted always by top/left in the cache, however they flow differently in RTL.
          // The rest of the logic still stands no matter what orientation we're in, however
          // we need to invert the array when determining the index.

          /** @type {?} */


          var items = this._orientation === 'horizontal' && this._direction === 'rtl' ? this._itemPositions.slice().reverse() : this._itemPositions;
          return findIndex(items,
          /**
          * @param {?} currentItem
          * @return {?}
          */
          function (currentItem) {
            return currentItem.drag === item;
          });
        }
        /**
         * Whether the list is able to receive the item that
         * is currently being dragged inside a connected drop list.
         * @return {?}
         */

      }, {
        key: "isReceiving",
        value: function isReceiving() {
          return this._activeSiblings.size > 0;
        }
        /**
         * Sorts an item inside the container based on its position.
         * @param {?} item Item to be sorted.
         * @param {?} pointerX Position of the item along the X axis.
         * @param {?} pointerY Position of the item along the Y axis.
         * @param {?} pointerDelta Direction in which the pointer is moving along each axis.
         * @return {?}
         */

      }, {
        key: "_sortItem",
        value: function _sortItem(item, pointerX, pointerY, pointerDelta) {
          // Don't sort the item if sorting is disabled or it's out of range.
          if (this.sortingDisabled || !this._isPointerNearDropContainer(pointerX, pointerY)) {
            return;
          }
          /** @type {?} */


          var siblings = this._itemPositions;
          /** @type {?} */

          var newIndex = this._getItemIndexFromPointerPosition(item, pointerX, pointerY, pointerDelta);

          if (newIndex === -1 && siblings.length > 0) {
            return;
          }
          /** @type {?} */


          var isHorizontal = this._orientation === 'horizontal';
          /** @type {?} */

          var currentIndex = findIndex(siblings,
          /**
          * @param {?} currentItem
          * @return {?}
          */
          function (currentItem) {
            return currentItem.drag === item;
          });
          /** @type {?} */

          var siblingAtNewPosition = siblings[newIndex];
          /** @type {?} */

          var currentPosition = siblings[currentIndex].clientRect;
          /** @type {?} */

          var newPosition = siblingAtNewPosition.clientRect;
          /** @type {?} */

          var delta = currentIndex > newIndex ? 1 : -1;
          this._previousSwap.drag = siblingAtNewPosition.drag;
          this._previousSwap.delta = isHorizontal ? pointerDelta.x : pointerDelta.y; // How many pixels the item's placeholder should be offset.

          /** @type {?} */

          var itemOffset = this._getItemOffsetPx(currentPosition, newPosition, delta); // How many pixels all the other items should be offset.

          /** @type {?} */


          var siblingOffset = this._getSiblingOffsetPx(currentIndex, siblings, delta); // Save the previous order of the items before moving the item to its new index.
          // We use this to check whether an item has been moved as a result of the sorting.

          /** @type {?} */


          var oldOrder = siblings.slice(); // Shuffle the array in place.

          moveItemInArray(siblings, currentIndex, newIndex);
          this.sorted.next({
            previousIndex: currentIndex,
            currentIndex: newIndex,
            container: this,
            item: item
          });
          siblings.forEach(
          /**
          * @param {?} sibling
          * @param {?} index
          * @return {?}
          */
          function (sibling, index) {
            // Don't do anything if the position hasn't changed.
            if (oldOrder[index] === sibling) {
              return;
            }
            /** @type {?} */


            var isDraggedItem = sibling.drag === item;
            /** @type {?} */

            var offset = isDraggedItem ? itemOffset : siblingOffset;
            /** @type {?} */

            var elementToOffset = isDraggedItem ? item.getPlaceholderElement() : sibling.drag.getRootElement(); // Update the offset to reflect the new position.

            sibling.offset += offset; // Since we're moving the items with a `transform`, we need to adjust their cached
            // client rects to reflect their new position, as well as swap their positions in the cache.
            // Note that we shouldn't use `getBoundingClientRect` here to update the cache, because the
            // elements may be mid-animation which will give us a wrong result.

            if (isHorizontal) {
              // Round the transforms since some browsers will
              // blur the elements, for sub-pixel transforms.
              elementToOffset.style.transform = "translate3d(".concat(Math.round(sibling.offset), "px, 0, 0)");
              adjustClientRect(sibling.clientRect, 0, offset);
            } else {
              elementToOffset.style.transform = "translate3d(0, ".concat(Math.round(sibling.offset), "px, 0)");
              adjustClientRect(sibling.clientRect, offset, 0);
            }
          });
        }
        /**
         * Checks whether the user's pointer is close to the edges of either the
         * viewport or the drop list and starts the auto-scroll sequence.
         * @param {?} pointerX User's pointer position along the x axis.
         * @param {?} pointerY User's pointer position along the y axis.
         * @return {?}
         */

      }, {
        key: "_startScrollingIfNecessary",
        value: function _startScrollingIfNecessary(pointerX, pointerY) {
          if (this.autoScrollDisabled) {
            return;
          }
          /** @type {?} */


          var scrollNode;
          /** @type {?} */

          var verticalScrollDirection = 0
          /* NONE */
          ;
          /** @type {?} */

          var horizontalScrollDirection = 0
          /* NONE */
          ; // Check whether we should start scrolling the container.

          if (this._isPointerNearDropContainer(pointerX, pointerY)) {
            /** @type {?} */
            var element = Object(_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_1__["coerceElement"])(this.element);

            var _getElementScrollDire = getElementScrollDirections(element, this._clientRect, pointerX, pointerY);

            var _getElementScrollDire2 = _slicedToArray(_getElementScrollDire, 2);

            verticalScrollDirection = _getElementScrollDire2[0];
            horizontalScrollDirection = _getElementScrollDire2[1];

            if (verticalScrollDirection || horizontalScrollDirection) {
              scrollNode = element;
            }
          } // @breaking-change 9.0.0 Remove null check for _viewportRuler once it's a required parameter.
          // Otherwise check if we can start scrolling the viewport.


          if (this._viewportRuler && !verticalScrollDirection && !horizontalScrollDirection) {
            var _this$_viewportRuler$ = this._viewportRuler.getViewportSize(),
                width = _this$_viewportRuler$.width,
                height = _this$_viewportRuler$.height;
            /** @type {?} */


            var clientRect = {
              width: width,
              height: height,
              top: 0,
              right: width,
              bottom: height,
              left: 0
            };
            verticalScrollDirection = getVerticalScrollDirection(clientRect, pointerY);
            horizontalScrollDirection = getHorizontalScrollDirection(clientRect, pointerX);
            scrollNode = window;
          }

          if (scrollNode && (verticalScrollDirection !== this._verticalScrollDirection || horizontalScrollDirection !== this._horizontalScrollDirection || scrollNode !== this._scrollNode)) {
            this._verticalScrollDirection = verticalScrollDirection;
            this._horizontalScrollDirection = horizontalScrollDirection;
            this._scrollNode = scrollNode;

            if ((verticalScrollDirection || horizontalScrollDirection) && scrollNode) {
              // @breaking-change 9.0.0 Remove null check for `_ngZone` once it is made required.
              if (this._ngZone) {
                this._ngZone.runOutsideAngular(this._startScrollInterval);
              } else {
                this._startScrollInterval();
              }
            } else {
              this._stopScrolling();
            }
          }
        }
        /**
         * Stops any currently-running auto-scroll sequences.
         * @return {?}
         */

      }, {
        key: "_stopScrolling",
        value: function _stopScrolling() {
          this._stopScrollTimers.next();
        }
        /**
         * Caches the position of the drop list.
         * @private
         * @return {?}
         */

      }, {
        key: "_cacheOwnPosition",
        value: function _cacheOwnPosition() {
          /** @type {?} */
          var element = Object(_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_1__["coerceElement"])(this.element);
          this._clientRect = getMutableClientRect(element);
          this._scrollPosition = {
            top: element.scrollTop,
            left: element.scrollLeft
          };
        }
        /**
         * Refreshes the position cache of the items and sibling containers.
         * @private
         * @return {?}
         */

      }, {
        key: "_cacheItemPositions",
        value: function _cacheItemPositions() {
          var _this18 = this;

          /** @type {?} */
          var isHorizontal = this._orientation === 'horizontal';
          this._itemPositions = this._activeDraggables.map(
          /**
          * @param {?} drag
          * @return {?}
          */
          function (drag) {
            /** @type {?} */
            var elementToMeasure = _this18._dragDropRegistry.isDragging(drag) ? // If the element is being dragged, we have to measure the
            // placeholder, because the element is hidden.
            drag.getPlaceholderElement() : drag.getRootElement();
            return {
              drag: drag,
              offset: 0,
              clientRect: getMutableClientRect(elementToMeasure)
            };
          }).sort(
          /**
          * @param {?} a
          * @param {?} b
          * @return {?}
          */
          function (a, b) {
            return isHorizontal ? a.clientRect.left - b.clientRect.left : a.clientRect.top - b.clientRect.top;
          });
        }
        /**
         * Resets the container to its initial state.
         * @private
         * @return {?}
         */

      }, {
        key: "_reset",
        value: function _reset() {
          var _this19 = this;

          this._isDragging = false; // TODO(crisbeto): may have to wait for the animations to finish.

          this._activeDraggables.forEach(
          /**
          * @param {?} item
          * @return {?}
          */
          function (item) {
            return item.getRootElement().style.transform = '';
          });

          this._siblings.forEach(
          /**
          * @param {?} sibling
          * @return {?}
          */
          function (sibling) {
            return sibling._stopReceiving(_this19);
          });

          this._activeDraggables = [];
          this._itemPositions = [];
          this._previousSwap.drag = null;
          this._previousSwap.delta = 0;

          this._stopScrolling();

          this._removeListeners();
        }
        /**
         * Gets the offset in pixels by which the items that aren't being dragged should be moved.
         * @private
         * @param {?} currentIndex Index of the item currently being dragged.
         * @param {?} siblings All of the items in the list.
         * @param {?} delta Direction in which the user is moving.
         * @return {?}
         */

      }, {
        key: "_getSiblingOffsetPx",
        value: function _getSiblingOffsetPx(currentIndex, siblings, delta) {
          /** @type {?} */
          var isHorizontal = this._orientation === 'horizontal';
          /** @type {?} */

          var currentPosition = siblings[currentIndex].clientRect;
          /** @type {?} */

          var immediateSibling = siblings[currentIndex + delta * -1];
          /** @type {?} */

          var siblingOffset = currentPosition[isHorizontal ? 'width' : 'height'] * delta;

          if (immediateSibling) {
            /** @type {?} */
            var start = isHorizontal ? 'left' : 'top';
            /** @type {?} */

            var end = isHorizontal ? 'right' : 'bottom'; // Get the spacing between the start of the current item and the end of the one immediately
            // after it in the direction in which the user is dragging, or vice versa. We add it to the
            // offset in order to push the element to where it will be when it's inline and is influenced
            // by the `margin` of its siblings.

            if (delta === -1) {
              siblingOffset -= immediateSibling.clientRect[start] - currentPosition[end];
            } else {
              siblingOffset += currentPosition[start] - immediateSibling.clientRect[end];
            }
          }

          return siblingOffset;
        }
        /**
         * Checks whether the pointer coordinates are close to the drop container.
         * @private
         * @param {?} pointerX Coordinates along the X axis.
         * @param {?} pointerY Coordinates along the Y axis.
         * @return {?}
         */

      }, {
        key: "_isPointerNearDropContainer",
        value: function _isPointerNearDropContainer(pointerX, pointerY) {
          var _this$_clientRect = this._clientRect,
              top = _this$_clientRect.top,
              right = _this$_clientRect.right,
              bottom = _this$_clientRect.bottom,
              left = _this$_clientRect.left,
              width = _this$_clientRect.width,
              height = _this$_clientRect.height;
          /** @type {?} */

          var xThreshold = width * DROP_PROXIMITY_THRESHOLD;
          /** @type {?} */

          var yThreshold = height * DROP_PROXIMITY_THRESHOLD;
          return pointerY > top - yThreshold && pointerY < bottom + yThreshold && pointerX > left - xThreshold && pointerX < right + xThreshold;
        }
        /**
         * Gets the offset in pixels by which the item that is being dragged should be moved.
         * @private
         * @param {?} currentPosition Current position of the item.
         * @param {?} newPosition Position of the item where the current item should be moved.
         * @param {?} delta Direction in which the user is moving.
         * @return {?}
         */

      }, {
        key: "_getItemOffsetPx",
        value: function _getItemOffsetPx(currentPosition, newPosition, delta) {
          /** @type {?} */
          var isHorizontal = this._orientation === 'horizontal';
          /** @type {?} */

          var itemOffset = isHorizontal ? newPosition.left - currentPosition.left : newPosition.top - currentPosition.top; // Account for differences in the item width/height.

          if (delta === -1) {
            itemOffset += isHorizontal ? newPosition.width - currentPosition.width : newPosition.height - currentPosition.height;
          }

          return itemOffset;
        }
        /**
         * Gets the index of an item in the drop container, based on the position of the user's pointer.
         * @private
         * @param {?} item Item that is being sorted.
         * @param {?} pointerX Position of the user's pointer along the X axis.
         * @param {?} pointerY Position of the user's pointer along the Y axis.
         * @param {?=} delta Direction in which the user is moving their pointer.
         * @return {?}
         */

      }, {
        key: "_getItemIndexFromPointerPosition",
        value: function _getItemIndexFromPointerPosition(item, pointerX, pointerY, delta) {
          var _this20 = this;

          /** @type {?} */
          var isHorizontal = this._orientation === 'horizontal';
          return findIndex(this._itemPositions,
          /**
          * @param {?} __0
          * @param {?} _
          * @param {?} array
          * @return {?}
          */
          function (_ref2, _, array) {
            var drag = _ref2.drag,
                clientRect = _ref2.clientRect;

            if (drag === item) {
              // If there's only one item left in the container, it must be
              // the dragged item itself so we use it as a reference.
              return array.length < 2;
            }

            if (delta) {
              /** @type {?} */
              var direction = isHorizontal ? delta.x : delta.y; // If the user is still hovering over the same item as last time, and they didn't change
              // the direction in which they're dragging, we don't consider it a direction swap.

              if (drag === _this20._previousSwap.drag && direction === _this20._previousSwap.delta) {
                return false;
              }
            }

            return isHorizontal ? // Round these down since most browsers report client rects with
            // sub-pixel precision, whereas the pointer coordinates are rounded to pixels.
            pointerX >= Math.floor(clientRect.left) && pointerX <= Math.floor(clientRect.right) : pointerY >= Math.floor(clientRect.top) && pointerY <= Math.floor(clientRect.bottom);
          });
        }
        /**
         * Caches the current items in the list and their positions.
         * @private
         * @return {?}
         */

      }, {
        key: "_cacheItems",
        value: function _cacheItems() {
          this._activeDraggables = this._draggables.slice();

          this._cacheItemPositions();

          this._cacheOwnPosition();
        }
        /**
         * Updates the internal state of the container after a scroll event has happened.
         * @private
         * @param {?} scrollPosition Object that is keeping track of the scroll position.
         * @param {?} newTop New top scroll position.
         * @param {?} newLeft New left scroll position.
         * @param {?=} extraClientRect Extra `ClientRect` object that should be updated, in addition to the
         *  ones of the drag items. Useful when the viewport has been scrolled and we also need to update
         *  the `ClientRect` of the list.
         * @return {?}
         */

      }, {
        key: "_updateAfterScroll",
        value: function _updateAfterScroll(scrollPosition, newTop, newLeft, extraClientRect) {
          var _this21 = this;

          /** @type {?} */
          var topDifference = scrollPosition.top - newTop;
          /** @type {?} */

          var leftDifference = scrollPosition.left - newLeft;

          if (extraClientRect) {
            adjustClientRect(extraClientRect, topDifference, leftDifference);
          } // Since we know the amount that the user has scrolled we can shift all of the client rectangles
          // ourselves. This is cheaper than re-measuring everything and we can avoid inconsistent
          // behavior where we might be measuring the element before its position has changed.


          this._itemPositions.forEach(
          /**
          * @param {?} __0
          * @return {?}
          */
          function (_ref3) {
            var clientRect = _ref3.clientRect;
            adjustClientRect(clientRect, topDifference, leftDifference);
          }); // We need two loops for this, because we want all of the cached
          // positions to be up-to-date before we re-sort the item.


          this._itemPositions.forEach(
          /**
          * @param {?} __0
          * @return {?}
          */
          function (_ref4) {
            var drag = _ref4.drag;

            if (_this21._dragDropRegistry.isDragging(drag)) {
              // We need to re-sort the item manually, because the pointer move
              // events won't be dispatched while the user is scrolling.
              drag._sortFromLastPointerPosition();
            }
          });

          scrollPosition.top = newTop;
          scrollPosition.left = newLeft;
        }
        /**
         * Removes the event listeners associated with this drop list.
         * @private
         * @return {?}
         */

      }, {
        key: "_removeListeners",
        value: function _removeListeners() {
          Object(_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_1__["coerceElement"])(this.element).removeEventListener('scroll', this._handleScroll);

          this._viewportScrollSubscription.unsubscribe();
        }
        /**
         * Checks whether the user's pointer is positioned over the container.
         * @param {?} x Pointer position along the X axis.
         * @param {?} y Pointer position along the Y axis.
         * @return {?}
         */

      }, {
        key: "_isOverContainer",
        value: function _isOverContainer(x, y) {
          return isInsideClientRect(this._clientRect, x, y);
        }
        /**
         * Figures out whether an item should be moved into a sibling
         * drop container, based on its current position.
         * @param {?} item Drag item that is being moved.
         * @param {?} x Position of the item along the X axis.
         * @param {?} y Position of the item along the Y axis.
         * @return {?}
         */

      }, {
        key: "_getSiblingContainerFromPosition",
        value: function _getSiblingContainerFromPosition(item, x, y) {
          return this._siblings.find(
          /**
          * @param {?} sibling
          * @return {?}
          */
          function (sibling) {
            return sibling._canReceive(item, x, y);
          });
        }
        /**
         * Checks whether the drop list can receive the passed-in item.
         * @param {?} item Item that is being dragged into the list.
         * @param {?} x Position of the item along the X axis.
         * @param {?} y Position of the item along the Y axis.
         * @return {?}
         */

      }, {
        key: "_canReceive",
        value: function _canReceive(item, x, y) {
          if (!this.enterPredicate(item, this) || !isInsideClientRect(this._clientRect, x, y)) {
            return false;
          }
          /** @type {?} */


          var elementFromPoint =
          /** @type {?} */
          this._shadowRoot.elementFromPoint(x, y); // If there's no element at the pointer position, then
          // the client rect is probably scrolled out of the view.


          if (!elementFromPoint) {
            return false;
          }
          /** @type {?} */


          var nativeElement = Object(_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_1__["coerceElement"])(this.element); // The `ClientRect`, that we're using to find the container over which the user is
          // hovering, doesn't give us any information on whether the element has been scrolled
          // out of the view or whether it's overlapping with other containers. This means that
          // we could end up transferring the item into a container that's invisible or is positioned
          // below another one. We use the result from `elementFromPoint` to get the top-most element
          // at the pointer position and to find whether it's one of the intersecting drop containers.

          return elementFromPoint === nativeElement || nativeElement.contains(elementFromPoint);
        }
        /**
         * Called by one of the connected drop lists when a dragging sequence has started.
         * @param {?} sibling Sibling in which dragging has started.
         * @return {?}
         */

      }, {
        key: "_startReceiving",
        value: function _startReceiving(sibling) {
          /** @type {?} */
          var activeSiblings = this._activeSiblings;

          if (!activeSiblings.has(sibling)) {
            activeSiblings.add(sibling);

            this._cacheOwnPosition();

            this._listenToScrollEvents();
          }
        }
        /**
         * Called by a connected drop list when dragging has stopped.
         * @param {?} sibling Sibling whose dragging has stopped.
         * @return {?}
         */

      }, {
        key: "_stopReceiving",
        value: function _stopReceiving(sibling) {
          this._activeSiblings["delete"](sibling);

          this._viewportScrollSubscription.unsubscribe();
        }
        /**
         * Starts listening to scroll events on the viewport.
         * Used for updating the internal state of the list.
         * @private
         * @return {?}
         */

      }, {
        key: "_listenToScrollEvents",
        value: function _listenToScrollEvents() {
          var _this22 = this;

          this._viewportScrollPosition =
          /** @type {?} */
          this._viewportRuler.getViewportScrollPosition();
          this._viewportScrollSubscription = this._dragDropRegistry.scroll.subscribe(
          /**
          * @return {?}
          */
          function () {
            if (_this22.isDragging()) {
              /** @type {?} */
              var newPosition =
              /** @type {?} */
              _this22._viewportRuler.getViewportScrollPosition();

              _this22._updateAfterScroll(_this22._viewportScrollPosition, newPosition.top, newPosition.left, _this22._clientRect);
            } else if (_this22.isReceiving()) {
              _this22._cacheOwnPosition();
            }
          });
        }
      }]);

      return DropListRef;
    }();
    /**
     * Updates the top/left positions of a `ClientRect`, as well as their bottom/right counterparts.
     * @param {?} clientRect `ClientRect` that should be updated.
     * @param {?} top Amount to add to the `top` position.
     * @param {?} left Amount to add to the `left` position.
     * @return {?}
     */


    function adjustClientRect(clientRect, top, left) {
      clientRect.top += top;
      clientRect.bottom = clientRect.top + clientRect.height;
      clientRect.left += left;
      clientRect.right = clientRect.left + clientRect.width;
    }
    /**
     * Finds the index of an item that matches a predicate function. Used as an equivalent
     * of `Array.prototype.findIndex` which isn't part of the standard Google typings.
     * @template T
     * @param {?} array Array in which to look for matches.
     * @param {?} predicate Function used to determine whether an item is a match.
     * @return {?}
     */


    function findIndex(array, predicate) {
      for (var i = 0; i < array.length; i++) {
        if (predicate(array[i], i, array)) {
          return i;
        }
      }

      return -1;
    }
    /**
     * Checks whether some coordinates are within a `ClientRect`.
     * @param {?} clientRect ClientRect that is being checked.
     * @param {?} x Coordinates along the X axis.
     * @param {?} y Coordinates along the Y axis.
     * @return {?}
     */


    function isInsideClientRect(clientRect, x, y) {
      var top = clientRect.top,
          bottom = clientRect.bottom,
          left = clientRect.left,
          right = clientRect.right;
      return y >= top && y <= bottom && x >= left && x <= right;
    }
    /**
     * Gets a mutable version of an element's bounding `ClientRect`.
     * @param {?} element
     * @return {?}
     */


    function getMutableClientRect(element) {
      /** @type {?} */
      var clientRect = element.getBoundingClientRect(); // We need to clone the `clientRect` here, because all the values on it are readonly
      // and we need to be able to update them. Also we can't use a spread here, because
      // the values on a `ClientRect` aren't own properties. See:
      // https://developer.mozilla.org/en-US/docs/Web/API/Element/getBoundingClientRect#Notes

      return {
        top: clientRect.top,
        right: clientRect.right,
        bottom: clientRect.bottom,
        left: clientRect.left,
        width: clientRect.width,
        height: clientRect.height
      };
    }
    /**
     * Increments the vertical scroll position of a node.
     * @param {?} node Node whose scroll position should change.
     * @param {?} amount Amount of pixels that the `node` should be scrolled.
     * @return {?}
     */


    function incrementVerticalScroll(node, amount) {
      if (node === window) {
        /** @type {?} */
        node.scrollBy(0, amount);
      } else {
        // Ideally we could use `Element.scrollBy` here as well, but IE and Edge don't support it.

        /** @type {?} */
        node.scrollTop += amount;
      }
    }
    /**
     * Increments the horizontal scroll position of a node.
     * @param {?} node Node whose scroll position should change.
     * @param {?} amount Amount of pixels that the `node` should be scrolled.
     * @return {?}
     */


    function incrementHorizontalScroll(node, amount) {
      if (node === window) {
        /** @type {?} */
        node.scrollBy(amount, 0);
      } else {
        // Ideally we could use `Element.scrollBy` here as well, but IE and Edge don't support it.

        /** @type {?} */
        node.scrollLeft += amount;
      }
    }
    /**
     * Gets whether the vertical auto-scroll direction of a node.
     * @param {?} clientRect Dimensions of the node.
     * @param {?} pointerY Position of the user's pointer along the y axis.
     * @return {?}
     */


    function getVerticalScrollDirection(clientRect, pointerY) {
      var top = clientRect.top,
          bottom = clientRect.bottom,
          height = clientRect.height;
      /** @type {?} */

      var yThreshold = height * SCROLL_PROXIMITY_THRESHOLD;

      if (pointerY >= top - yThreshold && pointerY <= top + yThreshold) {
        return 1
        /* UP */
        ;
      } else if (pointerY >= bottom - yThreshold && pointerY <= bottom + yThreshold) {
        return 2
        /* DOWN */
        ;
      }

      return 0
      /* NONE */
      ;
    }
    /**
     * Gets whether the horizontal auto-scroll direction of a node.
     * @param {?} clientRect Dimensions of the node.
     * @param {?} pointerX Position of the user's pointer along the x axis.
     * @return {?}
     */


    function getHorizontalScrollDirection(clientRect, pointerX) {
      var left = clientRect.left,
          right = clientRect.right,
          width = clientRect.width;
      /** @type {?} */

      var xThreshold = width * SCROLL_PROXIMITY_THRESHOLD;

      if (pointerX >= left - xThreshold && pointerX <= left + xThreshold) {
        return 1
        /* LEFT */
        ;
      } else if (pointerX >= right - xThreshold && pointerX <= right + xThreshold) {
        return 2
        /* RIGHT */
        ;
      }

      return 0
      /* NONE */
      ;
    }
    /**
     * Gets the directions in which an element node should be scrolled,
     * assuming that the user's pointer is already within it scrollable region.
     * @param {?} element Element for which we should calculate the scroll direction.
     * @param {?} clientRect Bounding client rectangle of the element.
     * @param {?} pointerX Position of the user's pointer along the x axis.
     * @param {?} pointerY Position of the user's pointer along the y axis.
     * @return {?}
     */


    function getElementScrollDirections(element, clientRect, pointerX, pointerY) {
      /** @type {?} */
      var computedVertical = getVerticalScrollDirection(clientRect, pointerY);
      /** @type {?} */

      var computedHorizontal = getHorizontalScrollDirection(clientRect, pointerX);
      /** @type {?} */

      var verticalScrollDirection = 0
      /* NONE */
      ;
      /** @type {?} */

      var horizontalScrollDirection = 0
      /* NONE */
      ; // Note that we here we do some extra checks for whether the element is actually scrollable in
      // a certain direction and we only assign the scroll direction if it is. We do this so that we
      // can allow other elements to be scrolled, if the current element can't be scrolled anymore.
      // This allows us to handle cases where the scroll regions of two scrollable elements overlap.

      if (computedVertical) {
        /** @type {?} */
        var scrollTop = element.scrollTop;

        if (computedVertical === 1
        /* UP */
        ) {
            if (scrollTop > 0) {
              verticalScrollDirection = 1
              /* UP */
              ;
            }
          } else if (element.scrollHeight - scrollTop > element.clientHeight) {
          verticalScrollDirection = 2
          /* DOWN */
          ;
        }
      }

      if (computedHorizontal) {
        /** @type {?} */
        var scrollLeft = element.scrollLeft;

        if (computedHorizontal === 1
        /* LEFT */
        ) {
            if (scrollLeft > 0) {
              horizontalScrollDirection = 1
              /* LEFT */
              ;
            }
          } else if (element.scrollWidth - scrollLeft > element.clientWidth) {
          horizontalScrollDirection = 2
          /* RIGHT */
          ;
        }
      }

      return [verticalScrollDirection, horizontalScrollDirection];
    }
    /**
     * Gets the shadow root of an element, if any.
     * @param {?} element
     * @return {?}
     */


    function getShadowRoot(element) {
      if (Object(_angular_cdk_platform__WEBPACK_IMPORTED_MODULE_0__["_supportsShadowDom"])()) {
        /** @type {?} */
        var rootNode = element.getRootNode ? element.getRootNode() : null;

        if (rootNode instanceof ShadowRoot) {
          return rootNode;
        }
      }

      return null;
    }
    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    /**
     * Event options that can be used to bind an active, capturing event.
     * @type {?}
     */


    var activeCapturingEventOptions = Object(_angular_cdk_platform__WEBPACK_IMPORTED_MODULE_0__["normalizePassiveListenerOptions"])({
      passive: false,
      capture: true
    });
    /**
     * Service that keeps track of all the drag item and drop container
     * instances, and manages global event listeners on the `document`.
     * \@docs-private
     * @template I, C
     */
    // Note: this class is generic, rather than referencing CdkDrag and CdkDropList directly, in order
    // to avoid circular imports. If we were to reference them here, importing the registry into the
    // classes that are registering themselves will introduce a circular import.

    var DragDropRegistry = /*#__PURE__*/function () {
      /**
       * @param {?} _ngZone
       * @param {?} _document
       */
      function DragDropRegistry(_ngZone, _document) {
        var _this23 = this;

        _classCallCheck(this, DragDropRegistry);

        this._ngZone = _ngZone;
        /**
         * Registered drop container instances.
         */

        this._dropInstances = new Set();
        /**
         * Registered drag item instances.
         */

        this._dragInstances = new Set();
        /**
         * Drag item instances that are currently being dragged.
         */

        this._activeDragInstances = new Set();
        /**
         * Keeps track of the event listeners that we've bound to the `document`.
         */

        this._globalListeners = new Map();
        /**
         * Emits the `touchmove` or `mousemove` events that are dispatched
         * while the user is dragging a drag item instance.
         */

        this.pointerMove = new rxjs__WEBPACK_IMPORTED_MODULE_2__["Subject"]();
        /**
         * Emits the `touchend` or `mouseup` events that are dispatched
         * while the user is dragging a drag item instance.
         */

        this.pointerUp = new rxjs__WEBPACK_IMPORTED_MODULE_2__["Subject"]();
        /**
         * Emits when the viewport has been scrolled while the user is dragging an item.
         */

        this.scroll = new rxjs__WEBPACK_IMPORTED_MODULE_2__["Subject"]();
        /**
         * Event listener that will prevent the default browser action while the user is dragging.
         * @param event Event whose default action should be prevented.
         */

        this._preventDefaultWhileDragging =
        /**
        * @param {?} event
        * @return {?}
        */
        function (event) {
          if (_this23._activeDragInstances.size) {
            event.preventDefault();
          }
        };

        this._document = _document;
      }
      /**
       * Adds a drop container to the registry.
       * @param {?} drop
       * @return {?}
       */


      _createClass(DragDropRegistry, [{
        key: "registerDropContainer",
        value: function registerDropContainer(drop) {
          if (!this._dropInstances.has(drop)) {
            if (this.getDropContainer(drop.id)) {
              throw Error("Drop instance with id \"".concat(drop.id, "\" has already been registered."));
            }

            this._dropInstances.add(drop);
          }
        }
        /**
         * Adds a drag item instance to the registry.
         * @param {?} drag
         * @return {?}
         */

      }, {
        key: "registerDragItem",
        value: function registerDragItem(drag) {
          var _this24 = this;

          this._dragInstances.add(drag); // The `touchmove` event gets bound once, ahead of time, because WebKit
          // won't preventDefault on a dynamically-added `touchmove` listener.
          // See https://bugs.webkit.org/show_bug.cgi?id=184250.


          if (this._dragInstances.size === 1) {
            this._ngZone.runOutsideAngular(
            /**
            * @return {?}
            */
            function () {
              // The event handler has to be explicitly active,
              // because newer browsers make it passive by default.
              _this24._document.addEventListener('touchmove', _this24._preventDefaultWhileDragging, activeCapturingEventOptions);
            });
          }
        }
        /**
         * Removes a drop container from the registry.
         * @param {?} drop
         * @return {?}
         */

      }, {
        key: "removeDropContainer",
        value: function removeDropContainer(drop) {
          this._dropInstances["delete"](drop);
        }
        /**
         * Removes a drag item instance from the registry.
         * @param {?} drag
         * @return {?}
         */

      }, {
        key: "removeDragItem",
        value: function removeDragItem(drag) {
          this._dragInstances["delete"](drag);

          this.stopDragging(drag);

          if (this._dragInstances.size === 0) {
            this._document.removeEventListener('touchmove', this._preventDefaultWhileDragging, activeCapturingEventOptions);
          }
        }
        /**
         * Starts the dragging sequence for a drag instance.
         * @param {?} drag Drag instance which is being dragged.
         * @param {?} event Event that initiated the dragging.
         * @return {?}
         */

      }, {
        key: "startDragging",
        value: function startDragging(drag, event) {
          var _this25 = this;

          // Do not process the same drag twice to avoid memory leaks and redundant listeners
          if (this._activeDragInstances.has(drag)) {
            return;
          }

          this._activeDragInstances.add(drag);

          if (this._activeDragInstances.size === 1) {
            /** @type {?} */
            var _isTouchEvent = event.type.startsWith('touch');
            /** @type {?} */


            var moveEvent = _isTouchEvent ? 'touchmove' : 'mousemove';
            /** @type {?} */

            var upEvent = _isTouchEvent ? 'touchend' : 'mouseup'; // We explicitly bind __active__ listeners here, because newer browsers will default to
            // passive ones for `mousemove` and `touchmove`. The events need to be active, because we
            // use `preventDefault` to prevent the page from scrolling while the user is dragging.

            this._globalListeners.set(moveEvent, {
              handler:
              /**
              * @param {?} e
              * @return {?}
              */
              function handler(e) {
                return _this25.pointerMove.next(
                /** @type {?} */
                e);
              },
              options: activeCapturingEventOptions
            }).set(upEvent, {
              handler:
              /**
              * @param {?} e
              * @return {?}
              */
              function handler(e) {
                return _this25.pointerUp.next(
                /** @type {?} */
                e);
              },
              options: true
            }).set('scroll', {
              handler:
              /**
              * @param {?} e
              * @return {?}
              */
              function handler(e) {
                return _this25.scroll.next(e);
              },
              // Use capturing so that we pick up scroll changes in any scrollable nodes that aren't
              // the document. See https://github.com/angular/components/issues/17144.
              options: true
            }) // Preventing the default action on `mousemove` isn't enough to disable text selection
            // on Safari so we need to prevent the selection event as well. Alternatively this can
            // be done by setting `user-select: none` on the `body`, however it has causes a style
            // recalculation which can be expensive on pages with a lot of elements.
            .set('selectstart', {
              handler: this._preventDefaultWhileDragging,
              options: activeCapturingEventOptions
            });

            this._ngZone.runOutsideAngular(
            /**
            * @return {?}
            */
            function () {
              _this25._globalListeners.forEach(
              /**
              * @param {?} config
              * @param {?} name
              * @return {?}
              */
              function (config, name) {
                _this25._document.addEventListener(name, config.handler, config.options);
              });
            });
          }
        }
        /**
         * Stops dragging a drag item instance.
         * @param {?} drag
         * @return {?}
         */

      }, {
        key: "stopDragging",
        value: function stopDragging(drag) {
          this._activeDragInstances["delete"](drag);

          if (this._activeDragInstances.size === 0) {
            this._clearGlobalListeners();
          }
        }
        /**
         * Gets whether a drag item instance is currently being dragged.
         * @param {?} drag
         * @return {?}
         */

      }, {
        key: "isDragging",
        value: function isDragging(drag) {
          return this._activeDragInstances.has(drag);
        }
        /**
         * Gets a drop container by its id.
         * @deprecated No longer being used. To be removed.
         * \@breaking-change 8.0.0
         * @param {?} id
         * @return {?}
         */

      }, {
        key: "getDropContainer",
        value: function getDropContainer(id) {
          return Array.from(this._dropInstances).find(
          /**
          * @param {?} instance
          * @return {?}
          */
          function (instance) {
            return instance.id === id;
          });
        }
        /**
         * @return {?}
         */

      }, {
        key: "ngOnDestroy",
        value: function ngOnDestroy() {
          var _this26 = this;

          this._dragInstances.forEach(
          /**
          * @param {?} instance
          * @return {?}
          */
          function (instance) {
            return _this26.removeDragItem(instance);
          });

          this._dropInstances.forEach(
          /**
          * @param {?} instance
          * @return {?}
          */
          function (instance) {
            return _this26.removeDropContainer(instance);
          });

          this._clearGlobalListeners();

          this.pointerMove.complete();
          this.pointerUp.complete();
        }
        /**
         * Clears out the global event listeners from the `document`.
         * @private
         * @return {?}
         */

      }, {
        key: "_clearGlobalListeners",
        value: function _clearGlobalListeners() {
          var _this27 = this;

          this._globalListeners.forEach(
          /**
          * @param {?} config
          * @param {?} name
          * @return {?}
          */
          function (config, name) {
            _this27._document.removeEventListener(name, config.handler, config.options);
          });

          this._globalListeners.clear();
        }
      }]);

      return DragDropRegistry;
    }();

    DragDropRegistry.decorators = [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Injectable"],
      args: [{
        providedIn: 'root'
      }]
    }];
    /** @nocollapse */

    DragDropRegistry.ctorParameters = function () {
      return [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["NgZone"]
      }, {
        type: undefined,
        decorators: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Inject"],
          args: [_angular_common__WEBPACK_IMPORTED_MODULE_5__["DOCUMENT"]]
        }]
      }];
    };
    /** @nocollapse */


    DragDropRegistry.ngInjectableDef = Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineInjectable"])({
      factory: function DragDropRegistry_Factory() {
        return new DragDropRegistry(Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵinject"])(_angular_core__WEBPACK_IMPORTED_MODULE_4__["NgZone"]), Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵinject"])(_angular_common__WEBPACK_IMPORTED_MODULE_5__["DOCUMENT"]));
      },
      token: DragDropRegistry,
      providedIn: "root"
    });
    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    /**
     * Default configuration to be used when creating a `DragRef`.
     * @type {?}
     */

    var DEFAULT_CONFIG = {
      dragStartThreshold: 5,
      pointerDirectionChangeThreshold: 5
    };
    /**
     * Service that allows for drag-and-drop functionality to be attached to DOM elements.
     */

    var DragDrop = /*#__PURE__*/function () {
      /**
       * @param {?} _document
       * @param {?} _ngZone
       * @param {?} _viewportRuler
       * @param {?} _dragDropRegistry
       */
      function DragDrop(_document, _ngZone, _viewportRuler, _dragDropRegistry) {
        _classCallCheck(this, DragDrop);

        this._document = _document;
        this._ngZone = _ngZone;
        this._viewportRuler = _viewportRuler;
        this._dragDropRegistry = _dragDropRegistry;
      }
      /**
       * Turns an element into a draggable item.
       * @template T
       * @param {?} element Element to which to attach the dragging functionality.
       * @param {?=} config Object used to configure the dragging behavior.
       * @return {?}
       */


      _createClass(DragDrop, [{
        key: "createDrag",
        value: function createDrag(element) {
          var config = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : DEFAULT_CONFIG;
          return new DragRef(element, config, this._document, this._ngZone, this._viewportRuler, this._dragDropRegistry);
        }
        /**
         * Turns an element into a drop list.
         * @template T
         * @param {?} element Element to which to attach the drop list functionality.
         * @return {?}
         */

      }, {
        key: "createDropList",
        value: function createDropList(element) {
          return new DropListRef(element, this._dragDropRegistry, this._document, this._ngZone, this._viewportRuler);
        }
      }]);

      return DragDrop;
    }();

    DragDrop.decorators = [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Injectable"],
      args: [{
        providedIn: 'root'
      }]
    }];
    /** @nocollapse */

    DragDrop.ctorParameters = function () {
      return [{
        type: undefined,
        decorators: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Inject"],
          args: [_angular_common__WEBPACK_IMPORTED_MODULE_5__["DOCUMENT"]]
        }]
      }, {
        type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["NgZone"]
      }, {
        type: _angular_cdk_scrolling__WEBPACK_IMPORTED_MODULE_6__["ViewportRuler"]
      }, {
        type: DragDropRegistry
      }];
    };
    /** @nocollapse */


    DragDrop.ngInjectableDef = Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineInjectable"])({
      factory: function DragDrop_Factory() {
        return new DragDrop(Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵinject"])(_angular_common__WEBPACK_IMPORTED_MODULE_5__["DOCUMENT"]), Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵinject"])(_angular_core__WEBPACK_IMPORTED_MODULE_4__["NgZone"]), Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵinject"])(_angular_cdk_scrolling__WEBPACK_IMPORTED_MODULE_6__["ViewportRuler"]), Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵinject"])(DragDropRegistry));
      },
      token: DragDrop,
      providedIn: "root"
    });
    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    /**
     * Injection token that is used to provide a CdkDropList instance to CdkDrag.
     * Used for avoiding circular imports.
     * @type {?}
     */

    var CDK_DROP_LIST = new _angular_core__WEBPACK_IMPORTED_MODULE_4__["InjectionToken"]('CDK_DROP_LIST');
    /**
     * Injection token that is used to provide a CdkDropList instance to CdkDrag.
     * Used for avoiding circular imports.
     * @deprecated Use `CDK_DROP_LIST` instead.
     * \@breaking-change 8.0.0
     * @type {?}
     */

    var CDK_DROP_LIST_CONTAINER = CDK_DROP_LIST;
    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    /**
     * Injection token that can be used for a `CdkDrag` to provide itself as a parent to the
     * drag-specific child directive (`CdkDragHandle`, `CdkDragPreview` etc.). Used primarily
     * to avoid circular imports.
     * \@docs-private
     * @type {?}
     */

    var CDK_DRAG_PARENT = new _angular_core__WEBPACK_IMPORTED_MODULE_4__["InjectionToken"]('CDK_DRAG_PARENT');
    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    /**
     * Handle that can be used to drag and CdkDrag instance.
     */

    var CdkDragHandle = /*#__PURE__*/function () {
      /**
       * @param {?} element
       * @param {?=} parentDrag
       */
      function CdkDragHandle(element, parentDrag) {
        _classCallCheck(this, CdkDragHandle);

        this.element = element;
        /**
         * Emits when the state of the handle has changed.
         */

        this._stateChanges = new rxjs__WEBPACK_IMPORTED_MODULE_2__["Subject"]();
        this._disabled = false;
        this._parentDrag = parentDrag;
        toggleNativeDragInteractions(element.nativeElement, false);
      }
      /**
       * Whether starting to drag through this handle is disabled.
       * @return {?}
       */


      _createClass(CdkDragHandle, [{
        key: "ngOnDestroy",

        /**
         * @return {?}
         */
        value: function ngOnDestroy() {
          this._stateChanges.complete();
        }
      }, {
        key: "disabled",
        get: function get() {
          return this._disabled;
        }
        /**
         * @param {?} value
         * @return {?}
         */
        ,
        set: function set(value) {
          this._disabled = Object(_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_1__["coerceBooleanProperty"])(value);

          this._stateChanges.next(this);
        }
      }]);

      return CdkDragHandle;
    }();

    CdkDragHandle.decorators = [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Directive"],
      args: [{
        selector: '[cdkDragHandle]',
        host: {
          'class': 'cdk-drag-handle'
        }
      }]
    }];
    /** @nocollapse */

    CdkDragHandle.ctorParameters = function () {
      return [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["ElementRef"]
      }, {
        type: undefined,
        decorators: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Inject"],
          args: [CDK_DRAG_PARENT]
        }, {
          type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Optional"]
        }]
      }];
    };

    CdkDragHandle.propDecorators = {
      disabled: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"],
        args: ['cdkDragHandleDisabled']
      }]
    };
    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    /**
     * Element that will be used as a template for the placeholder of a CdkDrag when
     * it is being dragged. The placeholder is displayed in place of the element being dragged.
     * @template T
     */

    var CdkDragPlaceholder =
    /**
     * @param {?} templateRef
     */
    function CdkDragPlaceholder(templateRef) {
      _classCallCheck(this, CdkDragPlaceholder);

      this.templateRef = templateRef;
    };

    CdkDragPlaceholder.decorators = [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Directive"],
      args: [{
        selector: 'ng-template[cdkDragPlaceholder]'
      }]
    }];
    /** @nocollapse */

    CdkDragPlaceholder.ctorParameters = function () {
      return [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["TemplateRef"]
      }];
    };

    CdkDragPlaceholder.propDecorators = {
      data: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"]
      }]
    };
    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    /**
     * Element that will be used as a template for the preview
     * of a CdkDrag when it is being dragged.
     * @template T
     */

    var CdkDragPreview =
    /**
     * @param {?} templateRef
     */
    function CdkDragPreview(templateRef) {
      _classCallCheck(this, CdkDragPreview);

      this.templateRef = templateRef;
    };

    CdkDragPreview.decorators = [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Directive"],
      args: [{
        selector: 'ng-template[cdkDragPreview]'
      }]
    }];
    /** @nocollapse */

    CdkDragPreview.ctorParameters = function () {
      return [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["TemplateRef"]
      }];
    };

    CdkDragPreview.propDecorators = {
      data: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"]
      }]
    };
    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    /**
     * Injection token that can be used to configure the behavior of `CdkDrag`.
     * @type {?}
     */

    var CDK_DRAG_CONFIG = new _angular_core__WEBPACK_IMPORTED_MODULE_4__["InjectionToken"]('CDK_DRAG_CONFIG', {
      providedIn: 'root',
      factory: CDK_DRAG_CONFIG_FACTORY
    });
    /**
     * \@docs-private
     * @return {?}
     */

    function CDK_DRAG_CONFIG_FACTORY() {
      return {
        dragStartThreshold: 5,
        pointerDirectionChangeThreshold: 5
      };
    }
    /**
     * Element that can be moved inside a CdkDropList container.
     * @template T
     */


    var CdkDrag = /*#__PURE__*/function () {
      /**
       * @param {?} element
       * @param {?} dropContainer
       * @param {?} _document
       * @param {?} _ngZone
       * @param {?} _viewContainerRef
       * @param {?} config
       * @param {?} _dir
       * @param {?} dragDrop
       * @param {?} _changeDetectorRef
       */
      function CdkDrag(element, dropContainer, _document, _ngZone, _viewContainerRef, config, _dir, dragDrop, _changeDetectorRef) {
        var _this28 = this;

        _classCallCheck(this, CdkDrag);

        this.element = element;
        this.dropContainer = dropContainer;
        this._document = _document;
        this._ngZone = _ngZone;
        this._viewContainerRef = _viewContainerRef;
        this._dir = _dir;
        this._changeDetectorRef = _changeDetectorRef;
        this._destroyed = new rxjs__WEBPACK_IMPORTED_MODULE_2__["Subject"]();
        /**
         * Amount of milliseconds to wait after the user has put their
         * pointer down before starting to drag the element.
         */

        this.dragStartDelay = 0;
        this._disabled = false;
        /**
         * Emits when the user starts dragging the item.
         */

        this.started = new _angular_core__WEBPACK_IMPORTED_MODULE_4__["EventEmitter"]();
        /**
         * Emits when the user has released a drag item, before any animations have started.
         */

        this.released = new _angular_core__WEBPACK_IMPORTED_MODULE_4__["EventEmitter"]();
        /**
         * Emits when the user stops dragging an item in the container.
         */

        this.ended = new _angular_core__WEBPACK_IMPORTED_MODULE_4__["EventEmitter"]();
        /**
         * Emits when the user has moved the item into a new container.
         */

        this.entered = new _angular_core__WEBPACK_IMPORTED_MODULE_4__["EventEmitter"]();
        /**
         * Emits when the user removes the item its container by dragging it into another container.
         */

        this.exited = new _angular_core__WEBPACK_IMPORTED_MODULE_4__["EventEmitter"]();
        /**
         * Emits when the user drops the item inside a container.
         */

        this.dropped = new _angular_core__WEBPACK_IMPORTED_MODULE_4__["EventEmitter"]();
        /**
         * Emits as the user is dragging the item. Use with caution,
         * because this event will fire for every pixel that the user has dragged.
         */

        this.moved = new rxjs__WEBPACK_IMPORTED_MODULE_2__["Observable"](
        /**
        * @param {?} observer
        * @return {?}
        */
        function (observer) {
          /** @type {?} */
          var subscription = _this28._dragRef.moved.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(
          /**
          * @param {?} movedEvent
          * @return {?}
          */
          function (movedEvent) {
            return {
              source: _this28,
              pointerPosition: movedEvent.pointerPosition,
              event: movedEvent.event,
              delta: movedEvent.delta,
              distance: movedEvent.distance
            };
          })).subscribe(observer);

          return (
            /**
            * @return {?}
            */
            function () {
              subscription.unsubscribe();
            }
          );
        });
        this._dragRef = dragDrop.createDrag(element, config);
        this._dragRef.data = this;

        this._syncInputs(this._dragRef);

        this._handleEvents(this._dragRef);
      }
      /**
       * Selector that will be used to determine the element to which the draggable's position will
       * be constrained. Matching starts from the element's parent and goes up the DOM until a matching
       * element has been found
       * @deprecated Use `boundaryElement` instead.
       * \@breaking-change 9.0.0
       * @return {?}
       */


      _createClass(CdkDrag, [{
        key: "getPlaceholderElement",

        /**
         * Returns the element that is being used as a placeholder
         * while the current element is being dragged.
         * @return {?}
         */
        value: function getPlaceholderElement() {
          return this._dragRef.getPlaceholderElement();
        }
        /**
         * Returns the root draggable element.
         * @return {?}
         */

      }, {
        key: "getRootElement",
        value: function getRootElement() {
          return this._dragRef.getRootElement();
        }
        /**
         * Resets a standalone drag item to its initial position.
         * @return {?}
         */

      }, {
        key: "reset",
        value: function reset() {
          this._dragRef.reset();
        }
        /**
         * Gets the pixel coordinates of the draggable outside of a drop container.
         * @return {?}
         */

      }, {
        key: "getFreeDragPosition",
        value: function getFreeDragPosition() {
          return this._dragRef.getFreeDragPosition();
        }
        /**
         * @return {?}
         */

      }, {
        key: "ngAfterViewInit",
        value: function ngAfterViewInit() {
          var _this29 = this;

          // We need to wait for the zone to stabilize, in order for the reference
          // element to be in the proper place in the DOM. This is mostly relevant
          // for draggable elements inside portals since they get stamped out in
          // their original DOM position and then they get transferred to the portal.
          this._ngZone.onStable.asObservable().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["takeUntil"])(this._destroyed)).subscribe(
          /**
          * @return {?}
          */
          function () {
            _this29._updateRootElement(); // Listen for any newly-added handles.


            _this29._handles.changes.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["startWith"])(_this29._handles), // Sync the new handles with the DragRef.
            Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])(
            /**
            * @param {?} handles
            * @return {?}
            */
            function (handles) {
              /** @type {?} */
              var childHandleElements = handles.filter(
              /**
              * @param {?} handle
              * @return {?}
              */
              function (handle) {
                return handle._parentDrag === _this29;
              }).map(
              /**
              * @param {?} handle
              * @return {?}
              */
              function (handle) {
                return handle.element;
              });

              _this29._dragRef.withHandles(childHandleElements);
            }), // Listen if the state of any of the handles changes.
            Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["switchMap"])(
            /**
            * @param {?} handles
            * @return {?}
            */
            function (handles) {
              return Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["merge"]).apply(void 0, _toConsumableArray(handles.map(
              /**
              * @param {?} item
              * @return {?}
              */
              function (item) {
                return item._stateChanges;
              })));
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["takeUntil"])(_this29._destroyed)).subscribe(
            /**
            * @param {?} handleInstance
            * @return {?}
            */
            function (handleInstance) {
              // Enabled/disable the handle that changed in the DragRef.

              /** @type {?} */
              var dragRef = _this29._dragRef;
              /** @type {?} */

              var handle = handleInstance.element.nativeElement;
              handleInstance.disabled ? dragRef.disableHandle(handle) : dragRef.enableHandle(handle);
            });

            if (_this29.freeDragPosition) {
              _this29._dragRef.setFreeDragPosition(_this29.freeDragPosition);
            }
          });
        }
        /**
         * @param {?} changes
         * @return {?}
         */

      }, {
        key: "ngOnChanges",
        value: function ngOnChanges(changes) {
          /** @type {?} */
          var rootSelectorChange = changes['rootElementSelector'];
          /** @type {?} */

          var positionChange = changes['freeDragPosition']; // We don't have to react to the first change since it's being
          // handled in `ngAfterViewInit` where it needs to be deferred.

          if (rootSelectorChange && !rootSelectorChange.firstChange) {
            this._updateRootElement();
          } // Skip the first change since it's being handled in `ngAfterViewInit`.


          if (positionChange && !positionChange.firstChange && this.freeDragPosition) {
            this._dragRef.setFreeDragPosition(this.freeDragPosition);
          }
        }
        /**
         * @return {?}
         */

      }, {
        key: "ngOnDestroy",
        value: function ngOnDestroy() {
          this._destroyed.next();

          this._destroyed.complete();

          this._dragRef.dispose();
        }
        /**
         * Syncs the root element with the `DragRef`.
         * @private
         * @return {?}
         */

      }, {
        key: "_updateRootElement",
        value: function _updateRootElement() {
          /** @type {?} */
          var element = this.element.nativeElement;
          /** @type {?} */

          var rootElement = this.rootElementSelector ? getClosestMatchingAncestor(element, this.rootElementSelector) : element;

          if (rootElement && rootElement.nodeType !== this._document.ELEMENT_NODE) {
            throw Error("cdkDrag must be attached to an element node. " + "Currently attached to \"".concat(rootElement.nodeName, "\"."));
          }

          this._dragRef.withRootElement(rootElement || element);
        }
        /**
         * Gets the boundary element, based on the `boundaryElement` value.
         * @private
         * @return {?}
         */

      }, {
        key: "_getBoundaryElement",
        value: function _getBoundaryElement() {
          /** @type {?} */
          var boundary = this.boundaryElement;

          if (!boundary) {
            return null;
          }

          if (typeof boundary === 'string') {
            return getClosestMatchingAncestor(this.element.nativeElement, boundary);
          }
          /** @type {?} */


          var element = Object(_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_1__["coerceElement"])(boundary);

          if (Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["isDevMode"])() && !element.contains(this.element.nativeElement)) {
            throw Error('Draggable element is not inside of the node passed into cdkDragBoundary.');
          }

          return element;
        }
        /**
         * Syncs the inputs of the CdkDrag with the options of the underlying DragRef.
         * @private
         * @param {?} ref
         * @return {?}
         */

      }, {
        key: "_syncInputs",
        value: function _syncInputs(ref) {
          var _this30 = this;

          ref.beforeStarted.subscribe(
          /**
          * @return {?}
          */
          function () {
            if (!ref.isDragging()) {
              /** @type {?} */
              var dir = _this30._dir;
              /** @type {?} */

              var placeholder = _this30._placeholderTemplate ? {
                template: _this30._placeholderTemplate.templateRef,
                context: _this30._placeholderTemplate.data,
                viewContainer: _this30._viewContainerRef
              } : null;
              /** @type {?} */

              var preview = _this30._previewTemplate ? {
                template: _this30._previewTemplate.templateRef,
                context: _this30._previewTemplate.data,
                viewContainer: _this30._viewContainerRef
              } : null;
              ref.disabled = _this30.disabled;
              ref.lockAxis = _this30.lockAxis;
              ref.dragStartDelay = Object(_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_1__["coerceNumberProperty"])(_this30.dragStartDelay);
              ref.constrainPosition = _this30.constrainPosition;
              ref.withBoundaryElement(_this30._getBoundaryElement()).withPlaceholderTemplate(placeholder).withPreviewTemplate(preview);

              if (dir) {
                ref.withDirection(dir.value);
              }
            }
          });
        }
        /**
         * Handles the events from the underlying `DragRef`.
         * @private
         * @param {?} ref
         * @return {?}
         */

      }, {
        key: "_handleEvents",
        value: function _handleEvents(ref) {
          var _this31 = this;

          ref.started.subscribe(
          /**
          * @return {?}
          */
          function () {
            _this31.started.emit({
              source: _this31
            }); // Since all of these events run outside of change detection,
            // we need to ensure that everything is marked correctly.


            _this31._changeDetectorRef.markForCheck();
          });
          ref.released.subscribe(
          /**
          * @return {?}
          */
          function () {
            _this31.released.emit({
              source: _this31
            });
          });
          ref.ended.subscribe(
          /**
          * @param {?} event
          * @return {?}
          */
          function (event) {
            _this31.ended.emit({
              source: _this31,
              distance: event.distance
            }); // Since all of these events run outside of change detection,
            // we need to ensure that everything is marked correctly.


            _this31._changeDetectorRef.markForCheck();
          });
          ref.entered.subscribe(
          /**
          * @param {?} event
          * @return {?}
          */
          function (event) {
            _this31.entered.emit({
              container: event.container.data,
              item: _this31,
              currentIndex: event.currentIndex
            });
          });
          ref.exited.subscribe(
          /**
          * @param {?} event
          * @return {?}
          */
          function (event) {
            _this31.exited.emit({
              container: event.container.data,
              item: _this31
            });
          });
          ref.dropped.subscribe(
          /**
          * @param {?} event
          * @return {?}
          */
          function (event) {
            _this31.dropped.emit({
              previousIndex: event.previousIndex,
              currentIndex: event.currentIndex,
              previousContainer: event.previousContainer.data,
              container: event.container.data,
              isPointerOverContainer: event.isPointerOverContainer,
              item: _this31,
              distance: event.distance
            });
          });
        }
      }, {
        key: "boundaryElementSelector",
        get: function get() {
          return typeof this.boundaryElement === 'string' ? this.boundaryElement :
          /** @type {?} */
          undefined;
        }
        /**
         * @param {?} selector
         * @return {?}
         */
        ,
        set: function set(selector) {
          this.boundaryElement = selector;
        }
        /**
         * Whether starting to drag this element is disabled.
         * @return {?}
         */

      }, {
        key: "disabled",
        get: function get() {
          return this._disabled || this.dropContainer && this.dropContainer.disabled;
        }
        /**
         * @param {?} value
         * @return {?}
         */
        ,
        set: function set(value) {
          this._disabled = Object(_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_1__["coerceBooleanProperty"])(value);
          this._dragRef.disabled = this._disabled;
        }
      }]);

      return CdkDrag;
    }();

    CdkDrag.decorators = [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Directive"],
      args: [{
        selector: '[cdkDrag]',
        exportAs: 'cdkDrag',
        host: {
          'class': 'cdk-drag',
          '[class.cdk-drag-disabled]': 'disabled',
          '[class.cdk-drag-dragging]': '_dragRef.isDragging()'
        },
        providers: [{
          provide: CDK_DRAG_PARENT,
          useExisting: CdkDrag
        }]
      }]
    }];
    /** @nocollapse */

    CdkDrag.ctorParameters = function () {
      return [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["ElementRef"]
      }, {
        type: undefined,
        decorators: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Inject"],
          args: [CDK_DROP_LIST]
        }, {
          type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Optional"]
        }, {
          type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["SkipSelf"]
        }]
      }, {
        type: undefined,
        decorators: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Inject"],
          args: [_angular_common__WEBPACK_IMPORTED_MODULE_5__["DOCUMENT"]]
        }]
      }, {
        type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["NgZone"]
      }, {
        type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["ViewContainerRef"]
      }, {
        type: undefined,
        decorators: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Inject"],
          args: [CDK_DRAG_CONFIG]
        }]
      }, {
        type: _angular_cdk_bidi__WEBPACK_IMPORTED_MODULE_7__["Directionality"],
        decorators: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Optional"]
        }]
      }, {
        type: DragDrop
      }, {
        type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["ChangeDetectorRef"]
      }];
    };

    CdkDrag.propDecorators = {
      _handles: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["ContentChildren"],
        args: [CdkDragHandle, {
          descendants: true
        }]
      }],
      _previewTemplate: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["ContentChild"],
        args: [CdkDragPreview, {
          "static": false
        }]
      }],
      _placeholderTemplate: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["ContentChild"],
        args: [CdkDragPlaceholder, {
          "static": false
        }]
      }],
      data: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"],
        args: ['cdkDragData']
      }],
      lockAxis: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"],
        args: ['cdkDragLockAxis']
      }],
      rootElementSelector: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"],
        args: ['cdkDragRootElement']
      }],
      boundaryElement: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"],
        args: ['cdkDragBoundary']
      }],
      dragStartDelay: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"],
        args: ['cdkDragStartDelay']
      }],
      freeDragPosition: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"],
        args: ['cdkDragFreeDragPosition']
      }],
      disabled: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"],
        args: ['cdkDragDisabled']
      }],
      constrainPosition: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"],
        args: ['cdkDragConstrainPosition']
      }],
      started: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Output"],
        args: ['cdkDragStarted']
      }],
      released: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Output"],
        args: ['cdkDragReleased']
      }],
      ended: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Output"],
        args: ['cdkDragEnded']
      }],
      entered: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Output"],
        args: ['cdkDragEntered']
      }],
      exited: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Output"],
        args: ['cdkDragExited']
      }],
      dropped: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Output"],
        args: ['cdkDragDropped']
      }],
      moved: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Output"],
        args: ['cdkDragMoved']
      }]
    };
    /**
     * Gets the closest ancestor of an element that matches a selector.
     * @param {?} element
     * @param {?} selector
     * @return {?}
     */

    function getClosestMatchingAncestor(element, selector) {
      /** @type {?} */
      var currentElement =
      /** @type {?} */
      element.parentElement;

      while (currentElement) {
        // IE doesn't support `matches` so we have to fall back to `msMatchesSelector`.
        if (currentElement.matches ? currentElement.matches(selector) :
        /** @type {?} */
        currentElement.msMatchesSelector(selector)) {
          return currentElement;
        }

        currentElement = currentElement.parentElement;
      }

      return null;
    }
    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    /**
     * Declaratively connects sibling `cdkDropList` instances together. All of the `cdkDropList`
     * elements that are placed inside a `cdkDropListGroup` will be connected to each other
     * automatically. Can be used as an alternative to the `cdkDropListConnectedTo` input
     * from `cdkDropList`.
     * @template T
     */


    var CdkDropListGroup = /*#__PURE__*/function () {
      function CdkDropListGroup() {
        _classCallCheck(this, CdkDropListGroup);

        /**
         * Drop lists registered inside the group.
         */
        this._items = new Set();
        this._disabled = false;
      }
      /**
       * Whether starting a dragging sequence from inside this group is disabled.
       * @return {?}
       */


      _createClass(CdkDropListGroup, [{
        key: "ngOnDestroy",

        /**
         * @return {?}
         */
        value: function ngOnDestroy() {
          this._items.clear();
        }
      }, {
        key: "disabled",
        get: function get() {
          return this._disabled;
        }
        /**
         * @param {?} value
         * @return {?}
         */
        ,
        set: function set(value) {
          this._disabled = Object(_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_1__["coerceBooleanProperty"])(value);
        }
      }]);

      return CdkDropListGroup;
    }();

    CdkDropListGroup.decorators = [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Directive"],
      args: [{
        selector: '[cdkDropListGroup]',
        exportAs: 'cdkDropListGroup'
      }]
    }];
    CdkDropListGroup.propDecorators = {
      disabled: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"],
        args: ['cdkDropListGroupDisabled']
      }]
    };
    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    /**
     * Counter used to generate unique ids for drop zones.
     * @type {?}
     */

    var _uniqueIdCounter$1 = 0;
    var ɵ0 = undefined; // @breaking-change 8.0.0 `CdkDropList` implements `CdkDropListContainer` for backwards
    // compatiblity. The implements clause, as well as all the methods that it enforces can
    // be removed when `CdkDropListContainer` is deleted.

    /**
     * Container that wraps a set of draggable items.
     * @template T
     */

    var CdkDropList = /*#__PURE__*/function () {
      /**
       * @param {?} element
       * @param {?} dragDrop
       * @param {?} _changeDetectorRef
       * @param {?=} _dir
       * @param {?=} _group
       */
      function CdkDropList(element, dragDrop, _changeDetectorRef, _dir, _group) {
        var _this32 = this;

        _classCallCheck(this, CdkDropList);

        this.element = element;
        this._changeDetectorRef = _changeDetectorRef;
        this._dir = _dir;
        this._group = _group;
        /**
         * Emits when the list has been destroyed.
         */

        this._destroyed = new rxjs__WEBPACK_IMPORTED_MODULE_2__["Subject"]();
        /**
         * Other draggable containers that this container is connected to and into which the
         * container's items can be transferred. Can either be references to other drop containers,
         * or their unique IDs.
         */

        this.connectedTo = [];
        /**
         * Direction in which the list is oriented.
         */

        this.orientation = 'vertical';
        /**
         * Unique ID for the drop zone. Can be used as a reference
         * in the `connectedTo` of another `CdkDropList`.
         */

        this.id = "cdk-drop-list-".concat(_uniqueIdCounter$1++);
        this._disabled = false;
        this._sortingDisabled = false;
        /**
         * Function that is used to determine whether an item
         * is allowed to be moved into a drop container.
         */

        this.enterPredicate =
        /**
        * @return {?}
        */
        function () {
          return true;
        };
        /**
         * Whether to auto-scroll the view when the user moves their pointer close to the edges.
         */


        this.autoScrollDisabled = false;
        /**
         * Emits when the user drops an item inside the container.
         */

        this.dropped = new _angular_core__WEBPACK_IMPORTED_MODULE_4__["EventEmitter"]();
        /**
         * Emits when the user has moved a new drag item into this container.
         */

        this.entered = new _angular_core__WEBPACK_IMPORTED_MODULE_4__["EventEmitter"]();
        /**
         * Emits when the user removes an item from the container
         * by dragging it into another container.
         */

        this.exited = new _angular_core__WEBPACK_IMPORTED_MODULE_4__["EventEmitter"]();
        /**
         * Emits as the user is swapping items while actively dragging.
         */

        this.sorted = new _angular_core__WEBPACK_IMPORTED_MODULE_4__["EventEmitter"]();
        this._dropListRef = dragDrop.createDropList(element);
        this._dropListRef.data = this;

        this._dropListRef.enterPredicate =
        /**
        * @param {?} drag
        * @param {?} drop
        * @return {?}
        */
        function (drag, drop) {
          return _this32.enterPredicate(drag.data, drop.data);
        };

        this._syncInputs(this._dropListRef);

        this._handleEvents(this._dropListRef);

        CdkDropList._dropLists.push(this);

        if (_group) {
          _group._items.add(this);
        }
      }
      /**
       * Whether starting a dragging sequence from this container is disabled.
       * @return {?}
       */


      _createClass(CdkDropList, [{
        key: "ngAfterContentInit",

        /**
         * @return {?}
         */
        value: function ngAfterContentInit() {
          var _this33 = this;

          this._draggables.changes.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["startWith"])(this._draggables), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["takeUntil"])(this._destroyed)).subscribe(
          /**
          * @param {?} items
          * @return {?}
          */
          function (items) {
            _this33._dropListRef.withItems(items.map(
            /**
            * @param {?} drag
            * @return {?}
            */
            function (drag) {
              return drag._dragRef;
            }));
          });
        }
        /**
         * @return {?}
         */

      }, {
        key: "ngOnDestroy",
        value: function ngOnDestroy() {
          /** @type {?} */
          var index = CdkDropList._dropLists.indexOf(this);

          if (index > -1) {
            CdkDropList._dropLists.splice(index, 1);
          }

          if (this._group) {
            this._group._items["delete"](this);
          }

          this._dropListRef.dispose();

          this._destroyed.next();

          this._destroyed.complete();
        }
        /**
         * Starts dragging an item.
         * @return {?}
         */

      }, {
        key: "start",
        value: function start() {
          this._dropListRef.start();
        }
        /**
         * Drops an item into this container.
         * @param {?} item Item being dropped into the container.
         * @param {?} currentIndex Index at which the item should be inserted.
         * @param {?} previousContainer Container from which the item got dragged in.
         * @param {?} isPointerOverContainer Whether the user's pointer was over the
         *    container when the item was dropped.
         * @return {?}
         */

      }, {
        key: "drop",
        value: function drop(item, currentIndex, previousContainer, isPointerOverContainer) {
          this._dropListRef.drop(item._dragRef, currentIndex,
          /** @type {?} */
          previousContainer._dropListRef, isPointerOverContainer);
        }
        /**
         * Emits an event to indicate that the user moved an item into the container.
         * @param {?} item Item that was moved into the container.
         * @param {?} pointerX Position of the item along the X axis.
         * @param {?} pointerY Position of the item along the Y axis.
         * @return {?}
         */

      }, {
        key: "enter",
        value: function enter(item, pointerX, pointerY) {
          this._dropListRef.enter(item._dragRef, pointerX, pointerY);
        }
        /**
         * Removes an item from the container after it was dragged into another container by the user.
         * @param {?} item Item that was dragged out.
         * @return {?}
         */

      }, {
        key: "exit",
        value: function exit(item) {
          this._dropListRef.exit(item._dragRef);
        }
        /**
         * Figures out the index of an item in the container.
         * @param {?} item Item whose index should be determined.
         * @return {?}
         */

      }, {
        key: "getItemIndex",
        value: function getItemIndex(item) {
          return this._dropListRef.getItemIndex(item._dragRef);
        }
        /**
         * Sorts an item inside the container based on its position.
         * @param {?} item Item to be sorted.
         * @param {?} pointerX Position of the item along the X axis.
         * @param {?} pointerY Position of the item along the Y axis.
         * @param {?} pointerDelta Direction in which the pointer is moving along each axis.
         * @return {?}
         */

      }, {
        key: "_sortItem",
        value: function _sortItem(item, pointerX, pointerY, pointerDelta) {
          return this._dropListRef._sortItem(item._dragRef, pointerX, pointerY, pointerDelta);
        }
        /**
         * Figures out whether an item should be moved into a sibling
         * drop container, based on its current position.
         * @param {?} item Drag item that is being moved.
         * @param {?} x Position of the item along the X axis.
         * @param {?} y Position of the item along the Y axis.
         * @return {?}
         */

      }, {
        key: "_getSiblingContainerFromPosition",
        value: function _getSiblingContainerFromPosition(item, x, y) {
          /** @type {?} */
          var result = this._dropListRef._getSiblingContainerFromPosition(item._dragRef, x, y);

          return result ? result.data : null;
        }
        /**
         * Checks whether the user's pointer is positioned over the container.
         * @param {?} x Pointer position along the X axis.
         * @param {?} y Pointer position along the Y axis.
         * @return {?}
         */

      }, {
        key: "_isOverContainer",
        value: function _isOverContainer(x, y) {
          return this._dropListRef._isOverContainer(x, y);
        }
        /**
         * Syncs the inputs of the CdkDropList with the options of the underlying DropListRef.
         * @private
         * @param {?} ref
         * @return {?}
         */

      }, {
        key: "_syncInputs",
        value: function _syncInputs(ref) {
          var _this34 = this;

          if (this._dir) {
            this._dir.change.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["startWith"])(this._dir.value), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["takeUntil"])(this._destroyed)).subscribe(
            /**
            * @param {?} value
            * @return {?}
            */
            function (value) {
              return ref.withDirection(value);
            });
          }

          ref.beforeStarted.subscribe(
          /**
          * @return {?}
          */
          function () {
            /** @type {?} */
            var siblings = Object(_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_1__["coerceArray"])(_this34.connectedTo).map(
            /**
            * @param {?} drop
            * @return {?}
            */
            function (drop) {
              return typeof drop === 'string' ?
              /** @type {?} */
              CdkDropList._dropLists.find(
              /**
              * @param {?} list
              * @return {?}
              */
              function (list) {
                return list.id === drop;
              }) : drop;
            });

            if (_this34._group) {
              _this34._group._items.forEach(
              /**
              * @param {?} drop
              * @return {?}
              */
              function (drop) {
                if (siblings.indexOf(drop) === -1) {
                  siblings.push(drop);
                }
              });
            }

            ref.disabled = _this34.disabled;
            ref.lockAxis = _this34.lockAxis;
            ref.sortingDisabled = _this34.sortingDisabled;
            ref.autoScrollDisabled = _this34.autoScrollDisabled;
            ref.connectedTo(siblings.filter(
            /**
            * @param {?} drop
            * @return {?}
            */
            function (drop) {
              return drop && drop !== _this34;
            }).map(
            /**
            * @param {?} list
            * @return {?}
            */
            function (list) {
              return list._dropListRef;
            })).withOrientation(_this34.orientation);
          });
        }
        /**
         * Handles events from the underlying DropListRef.
         * @private
         * @param {?} ref
         * @return {?}
         */

      }, {
        key: "_handleEvents",
        value: function _handleEvents(ref) {
          var _this35 = this;

          ref.beforeStarted.subscribe(
          /**
          * @return {?}
          */
          function () {
            _this35._changeDetectorRef.markForCheck();
          });
          ref.entered.subscribe(
          /**
          * @param {?} event
          * @return {?}
          */
          function (event) {
            _this35.entered.emit({
              container: _this35,
              item: event.item.data,
              currentIndex: event.currentIndex
            });
          });
          ref.exited.subscribe(
          /**
          * @param {?} event
          * @return {?}
          */
          function (event) {
            _this35.exited.emit({
              container: _this35,
              item: event.item.data
            });

            _this35._changeDetectorRef.markForCheck();
          });
          ref.sorted.subscribe(
          /**
          * @param {?} event
          * @return {?}
          */
          function (event) {
            _this35.sorted.emit({
              previousIndex: event.previousIndex,
              currentIndex: event.currentIndex,
              container: _this35,
              item: event.item.data
            });
          });
          ref.dropped.subscribe(
          /**
          * @param {?} event
          * @return {?}
          */
          function (event) {
            _this35.dropped.emit({
              previousIndex: event.previousIndex,
              currentIndex: event.currentIndex,
              previousContainer: event.previousContainer.data,
              container: event.container.data,
              item: event.item.data,
              isPointerOverContainer: event.isPointerOverContainer,
              distance: event.distance
            }); // Mark for check since all of these events run outside of change
            // detection and we're not guaranteed for something else to have triggered it.


            _this35._changeDetectorRef.markForCheck();
          });
        }
      }, {
        key: "disabled",
        get: function get() {
          return this._disabled || !!this._group && this._group.disabled;
        }
        /**
         * @param {?} value
         * @return {?}
         */
        ,
        set: function set(value) {
          this._disabled = Object(_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_1__["coerceBooleanProperty"])(value);
        }
        /**
         * Whether sorting within this drop list is disabled.
         * @return {?}
         */

      }, {
        key: "sortingDisabled",
        get: function get() {
          return this._sortingDisabled;
        }
        /**
         * @param {?} value
         * @return {?}
         */
        ,
        set: function set(value) {
          this._sortingDisabled = Object(_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_1__["coerceBooleanProperty"])(value);
        }
      }]);

      return CdkDropList;
    }();
    /**
     * Keeps track of the drop lists that are currently on the page.
     */


    CdkDropList._dropLists = [];
    CdkDropList.decorators = [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Directive"],
      args: [{
        selector: '[cdkDropList], cdk-drop-list',
        exportAs: 'cdkDropList',
        providers: [// Prevent child drop lists from picking up the same group as their parent.
        {
          provide: CdkDropListGroup,
          useValue: ɵ0
        }, {
          provide: CDK_DROP_LIST_CONTAINER,
          useExisting: CdkDropList
        }],
        host: {
          'class': 'cdk-drop-list',
          '[id]': 'id',
          '[class.cdk-drop-list-disabled]': 'disabled',
          '[class.cdk-drop-list-dragging]': '_dropListRef.isDragging()',
          '[class.cdk-drop-list-receiving]': '_dropListRef.isReceiving()'
        }
      }]
    }];
    /** @nocollapse */

    CdkDropList.ctorParameters = function () {
      return [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["ElementRef"]
      }, {
        type: DragDrop
      }, {
        type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["ChangeDetectorRef"]
      }, {
        type: _angular_cdk_bidi__WEBPACK_IMPORTED_MODULE_7__["Directionality"],
        decorators: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Optional"]
        }]
      }, {
        type: CdkDropListGroup,
        decorators: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Optional"]
        }, {
          type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["SkipSelf"]
        }]
      }];
    };

    CdkDropList.propDecorators = {
      _draggables: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["ContentChildren"],
        args: [Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["forwardRef"])(
        /**
        * @return {?}
        */
        function () {
          return CdkDrag;
        }), {
          // Explicitly set to false since some of the logic below makes assumptions about it.
          // The `.withItems` call below should be updated if we ever need to switch this to `true`.
          descendants: false
        }]
      }],
      connectedTo: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"],
        args: ['cdkDropListConnectedTo']
      }],
      data: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"],
        args: ['cdkDropListData']
      }],
      orientation: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"],
        args: ['cdkDropListOrientation']
      }],
      id: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"]
      }],
      lockAxis: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"],
        args: ['cdkDropListLockAxis']
      }],
      disabled: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"],
        args: ['cdkDropListDisabled']
      }],
      sortingDisabled: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"],
        args: ['cdkDropListSortingDisabled']
      }],
      enterPredicate: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"],
        args: ['cdkDropListEnterPredicate']
      }],
      autoScrollDisabled: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"],
        args: ['cdkDropListAutoScrollDisabled']
      }],
      dropped: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Output"],
        args: ['cdkDropListDropped']
      }],
      entered: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Output"],
        args: ['cdkDropListEntered']
      }],
      exited: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Output"],
        args: ['cdkDropListExited']
      }],
      sorted: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Output"],
        args: ['cdkDropListSorted']
      }]
    };
    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    var DragDropModule = function DragDropModule() {
      _classCallCheck(this, DragDropModule);
    };

    DragDropModule.decorators = [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["NgModule"],
      args: [{
        declarations: [CdkDropList, CdkDropListGroup, CdkDrag, CdkDragHandle, CdkDragPreview, CdkDragPlaceholder],
        exports: [CdkDropList, CdkDropListGroup, CdkDrag, CdkDragHandle, CdkDragPreview, CdkDragPlaceholder],
        providers: [DragDrop]
      }]
    }];
    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    //# sourceMappingURL=drag-drop.js.map

    /***/
  },

  /***/
  "./node_modules/@angular/cdk/esm2015/platform.js":
  /*!*******************************************************!*\
    !*** ./node_modules/@angular/cdk/esm2015/platform.js ***!
    \*******************************************************/

  /*! exports provided: Platform, PlatformModule, getSupportedInputTypes, supportsPassiveEventListeners, normalizePassiveListenerOptions, supportsScrollBehavior, getRtlScrollAxisType, RtlScrollAxisType, _supportsShadowDom */

  /***/
  function node_modulesAngularCdkEsm2015PlatformJs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Platform", function () {
      return Platform;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "PlatformModule", function () {
      return PlatformModule;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "getSupportedInputTypes", function () {
      return getSupportedInputTypes;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "supportsPassiveEventListeners", function () {
      return supportsPassiveEventListeners;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "normalizePassiveListenerOptions", function () {
      return normalizePassiveListenerOptions;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "supportsScrollBehavior", function () {
      return supportsScrollBehavior;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "getRtlScrollAxisType", function () {
      return getRtlScrollAxisType;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "RtlScrollAxisType", function () {
      return RtlScrollAxisType;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "_supportsShadowDom", function () {
      return _supportsShadowDom;
    });
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /**
     * @license
     * Copyright Google LLC All Rights Reserved.
     *
     * Use of this source code is governed by an MIT-style license that can be
     * found in the LICENSE file at https://angular.io/license
     */

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    // Whether the current platform supports the V8 Break Iterator. The V8 check
    // is necessary to detect all Blink based browsers.

    /** @type {?} */


    var hasV8BreakIterator; // We need a try/catch around the reference to `Intl`, because accessing it in some cases can
    // cause IE to throw. These cases are tied to particular versions of Windows and can happen if
    // the consumer is providing a polyfilled `Map`. See:
    // https://github.com/Microsoft/ChakraCore/issues/3189
    // https://github.com/angular/components/issues/15687

    try {
      hasV8BreakIterator = typeof Intl !== 'undefined' &&
      /** @type {?} */
      Intl.v8BreakIterator;
    } catch (_a) {
      hasV8BreakIterator = false;
    }
    /**
     * Service to detect the current platform by comparing the userAgent strings and
     * checking browser-specific global properties.
     */


    var Platform =
    /**
     * \@breaking-change 8.0.0 remove optional decorator
     * @param {?=} _platformId
     */
    function Platform(_platformId) {
      _classCallCheck(this, Platform);

      this._platformId = _platformId;
      /**
       * Whether the Angular application is being rendered in the browser.
       * We want to use the Angular platform check because if the Document is shimmed
       * without the navigator, the following checks will fail. This is preferred because
       * sometimes the Document may be shimmed without the user's knowledge or intention
       */

      this.isBrowser = this._platformId ? Object(_angular_common__WEBPACK_IMPORTED_MODULE_1__["isPlatformBrowser"])(this._platformId) : typeof document === 'object' && !!document;
      /**
       * Whether the current browser is Microsoft Edge.
       */

      this.EDGE = this.isBrowser && /(edge)/i.test(navigator.userAgent);
      /**
       * Whether the current rendering engine is Microsoft Trident.
       */

      this.TRIDENT = this.isBrowser && /(msie|trident)/i.test(navigator.userAgent);
      /**
       * Whether the current rendering engine is Blink.
       */
      // EdgeHTML and Trident mock Blink specific things and need to be excluded from this check.

      this.BLINK = this.isBrowser && !!(
      /** @type {?} */
      window.chrome || hasV8BreakIterator) && typeof CSS !== 'undefined' && !this.EDGE && !this.TRIDENT;
      /**
       * Whether the current rendering engine is WebKit.
       */
      // Webkit is part of the userAgent in EdgeHTML, Blink and Trident. Therefore we need to
      // ensure that Webkit runs standalone and is not used as another engine's base.

      this.WEBKIT = this.isBrowser && /AppleWebKit/i.test(navigator.userAgent) && !this.BLINK && !this.EDGE && !this.TRIDENT;
      /**
       * Whether the current platform is Apple iOS.
       */

      this.IOS = this.isBrowser && /iPad|iPhone|iPod/.test(navigator.userAgent) && !('MSStream' in window);
      /**
       * Whether the current browser is Firefox.
       */
      // It's difficult to detect the plain Gecko engine, because most of the browsers identify
      // them self as Gecko-like browsers and modify the userAgent's according to that.
      // Since we only cover one explicit Firefox case, we can simply check for Firefox
      // instead of having an unstable check for Gecko.

      this.FIREFOX = this.isBrowser && /(firefox|minefield)/i.test(navigator.userAgent);
      /**
       * Whether the current platform is Android.
       */
      // Trident on mobile adds the android platform to the userAgent to trick detections.

      this.ANDROID = this.isBrowser && /android/i.test(navigator.userAgent) && !this.TRIDENT;
      /**
       * Whether the current browser is Safari.
       */
      // Safari browsers will include the Safari keyword in their userAgent. Some browsers may fake
      // this and just place the Safari keyword in the userAgent. To be more safe about Safari every
      // Safari browser should also use Webkit as its layout engine.

      this.SAFARI = this.isBrowser && /safari/i.test(navigator.userAgent) && this.WEBKIT;
    };

    Platform.decorators = [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"],
      args: [{
        providedIn: 'root'
      }]
    }];
    /** @nocollapse */

    Platform.ctorParameters = function () {
      return [{
        type: Object,
        decorators: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Optional"]
        }, {
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"],
          args: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["PLATFORM_ID"]]
        }]
      }];
    };
    /** @nocollapse */


    Platform.ngInjectableDef = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"])({
      factory: function Platform_Factory() {
        return new Platform(Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"])(_angular_core__WEBPACK_IMPORTED_MODULE_0__["PLATFORM_ID"], 8));
      },
      token: Platform,
      providedIn: "root"
    });
    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    var PlatformModule = function PlatformModule() {
      _classCallCheck(this, PlatformModule);
    };

    PlatformModule.decorators = [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"],
      args: [{}]
    }];
    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    /**
     * Cached result Set of input types support by the current browser.
     * @type {?}
     */

    var supportedInputTypes;
    /**
     * Types of `<input>` that *might* be supported.
     * @type {?}
     */

    var candidateInputTypes = [// `color` must come first. Chrome 56 shows a warning if we change the type to `color` after
    // first changing it to something else:
    // The specified value "" does not conform to the required format.
    // The format is "#rrggbb" where rr, gg, bb are two-digit hexadecimal numbers.
    'color', 'button', 'checkbox', 'date', 'datetime-local', 'email', 'file', 'hidden', 'image', 'month', 'number', 'password', 'radio', 'range', 'reset', 'search', 'submit', 'tel', 'text', 'time', 'url', 'week'];
    /**
     * @return {?} The input types supported by this browser.
     */

    function getSupportedInputTypes() {
      // Result is cached.
      if (supportedInputTypes) {
        return supportedInputTypes;
      } // We can't check if an input type is not supported until we're on the browser, so say that
      // everything is supported when not on the browser. We don't use `Platform` here since it's
      // just a helper function and can't inject it.


      if (typeof document !== 'object' || !document) {
        supportedInputTypes = new Set(candidateInputTypes);
        return supportedInputTypes;
      }
      /** @type {?} */


      var featureTestInput = document.createElement('input');
      supportedInputTypes = new Set(candidateInputTypes.filter(
      /**
      * @param {?} value
      * @return {?}
      */
      function (value) {
        featureTestInput.setAttribute('type', value);
        return featureTestInput.type === value;
      }));
      return supportedInputTypes;
    }
    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    /**
     * Cached result of whether the user's browser supports passive event listeners.
     * @type {?}
     */


    var supportsPassiveEvents;
    /**
     * Checks whether the user's browser supports passive event listeners.
     * See: https://github.com/WICG/EventListenerOptions/blob/gh-pages/explainer.md
     * @return {?}
     */

    function supportsPassiveEventListeners() {
      if (supportsPassiveEvents == null && typeof window !== 'undefined') {
        try {
          window.addEventListener('test',
          /** @type {?} */
          null, Object.defineProperty({}, 'passive', {
            get:
            /**
            * @return {?}
            */
            function get() {
              return supportsPassiveEvents = true;
            }
          }));
        } finally {
          supportsPassiveEvents = supportsPassiveEvents || false;
        }
      }

      return supportsPassiveEvents;
    }
    /**
     * Normalizes an `AddEventListener` object to something that can be passed
     * to `addEventListener` on any browser, no matter whether it supports the
     * `options` parameter.
     * @param {?} options Object to be normalized.
     * @return {?}
     */


    function normalizePassiveListenerOptions(options) {
      return supportsPassiveEventListeners() ? options : !!options.capture;
    }
    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    /** @enum {number} */


    var RtlScrollAxisType = {
      /**
       * scrollLeft is 0 when scrolled all the way left and (scrollWidth - clientWidth) when scrolled
       * all the way right.
       */
      NORMAL: 0,

      /**
       * scrollLeft is -(scrollWidth - clientWidth) when scrolled all the way left and 0 when scrolled
       * all the way right.
       */
      NEGATED: 1,

      /**
       * scrollLeft is (scrollWidth - clientWidth) when scrolled all the way left and 0 when scrolled
       * all the way right.
       */
      INVERTED: 2
    };
    RtlScrollAxisType[RtlScrollAxisType.NORMAL] = 'NORMAL';
    RtlScrollAxisType[RtlScrollAxisType.NEGATED] = 'NEGATED';
    RtlScrollAxisType[RtlScrollAxisType.INVERTED] = 'INVERTED';
    /**
     * Cached result of the way the browser handles the horizontal scroll axis in RTL mode.
     * @type {?}
     */

    var rtlScrollAxisType;
    /**
     * Check whether the browser supports scroll behaviors.
     * @return {?}
     */

    function supportsScrollBehavior() {
      return !!(typeof document == 'object' && 'scrollBehavior' in
      /** @type {?} */
      document.documentElement.style);
    }
    /**
     * Checks the type of RTL scroll axis used by this browser. As of time of writing, Chrome is NORMAL,
     * Firefox & Safari are NEGATED, and IE & Edge are INVERTED.
     * @return {?}
     */


    function getRtlScrollAxisType() {
      // We can't check unless we're on the browser. Just assume 'normal' if we're not.
      if (typeof document !== 'object' || !document) {
        return RtlScrollAxisType.NORMAL;
      }

      if (!rtlScrollAxisType) {
        // Create a 1px wide scrolling container and a 2px wide content element.

        /** @type {?} */
        var scrollContainer = document.createElement('div');
        /** @type {?} */

        var containerStyle = scrollContainer.style;
        scrollContainer.dir = 'rtl';
        containerStyle.height = '1px';
        containerStyle.width = '1px';
        containerStyle.overflow = 'auto';
        containerStyle.visibility = 'hidden';
        containerStyle.pointerEvents = 'none';
        containerStyle.position = 'absolute';
        /** @type {?} */

        var content = document.createElement('div');
        /** @type {?} */

        var contentStyle = content.style;
        contentStyle.width = '2px';
        contentStyle.height = '1px';
        scrollContainer.appendChild(content);
        document.body.appendChild(scrollContainer);
        rtlScrollAxisType = RtlScrollAxisType.NORMAL; // The viewport starts scrolled all the way to the right in RTL mode. If we are in a NORMAL
        // browser this would mean that the scrollLeft should be 1. If it's zero instead we know we're
        // dealing with one of the other two types of browsers.

        if (scrollContainer.scrollLeft === 0) {
          // In a NEGATED browser the scrollLeft is always somewhere in [-maxScrollAmount, 0]. For an
          // INVERTED browser it is always somewhere in [0, maxScrollAmount]. We can determine which by
          // setting to the scrollLeft to 1. This is past the max for a NEGATED browser, so it will
          // return 0 when we read it again.
          scrollContainer.scrollLeft = 1;
          rtlScrollAxisType = scrollContainer.scrollLeft === 0 ? RtlScrollAxisType.NEGATED : RtlScrollAxisType.INVERTED;
        }

        /** @type {?} */
        scrollContainer.parentNode.removeChild(scrollContainer);
      }

      return rtlScrollAxisType;
    }
    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    /** @type {?} */


    var shadowDomIsSupported;
    /**
     * Checks whether the user's browser support Shadow DOM.
     * @return {?}
     */

    function _supportsShadowDom() {
      if (shadowDomIsSupported == null) {
        /** @type {?} */
        var head = typeof document !== 'undefined' ? document.head : null;
        shadowDomIsSupported = !!(head && (
        /** @type {?} */
        head.createShadowRoot || head.attachShadow));
      }

      return shadowDomIsSupported;
    }
    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    //# sourceMappingURL=platform.js.map

    /***/

  },

  /***/
  "./node_modules/@angular/cdk/esm2015/scrolling.js":
  /*!********************************************************!*\
    !*** ./node_modules/@angular/cdk/esm2015/scrolling.js ***!
    \********************************************************/

  /*! exports provided: _fixedSizeVirtualScrollStrategyFactory, FixedSizeVirtualScrollStrategy, CdkFixedSizeVirtualScroll, SCROLL_DISPATCHER_PROVIDER_FACTORY, DEFAULT_SCROLL_TIME, ScrollDispatcher, SCROLL_DISPATCHER_PROVIDER, CdkScrollable, ScrollingModule, ScrollDispatchModule, VIEWPORT_RULER_PROVIDER_FACTORY, DEFAULT_RESIZE_TIME, ViewportRuler, VIEWPORT_RULER_PROVIDER, CdkVirtualForOf, VIRTUAL_SCROLL_STRATEGY, CdkVirtualScrollViewport */

  /***/
  function node_modulesAngularCdkEsm2015ScrollingJs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "_fixedSizeVirtualScrollStrategyFactory", function () {
      return _fixedSizeVirtualScrollStrategyFactory;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "FixedSizeVirtualScrollStrategy", function () {
      return FixedSizeVirtualScrollStrategy;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CdkFixedSizeVirtualScroll", function () {
      return CdkFixedSizeVirtualScroll;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SCROLL_DISPATCHER_PROVIDER_FACTORY", function () {
      return SCROLL_DISPATCHER_PROVIDER_FACTORY;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DEFAULT_SCROLL_TIME", function () {
      return DEFAULT_SCROLL_TIME;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ScrollDispatcher", function () {
      return ScrollDispatcher;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SCROLL_DISPATCHER_PROVIDER", function () {
      return SCROLL_DISPATCHER_PROVIDER;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CdkScrollable", function () {
      return CdkScrollable;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ScrollingModule", function () {
      return ScrollingModule;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ScrollDispatchModule", function () {
      return ScrollDispatchModule;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "VIEWPORT_RULER_PROVIDER_FACTORY", function () {
      return VIEWPORT_RULER_PROVIDER_FACTORY;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DEFAULT_RESIZE_TIME", function () {
      return DEFAULT_RESIZE_TIME;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ViewportRuler", function () {
      return ViewportRuler;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "VIEWPORT_RULER_PROVIDER", function () {
      return VIEWPORT_RULER_PROVIDER;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CdkVirtualForOf", function () {
      return CdkVirtualForOf;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "VIRTUAL_SCROLL_STRATEGY", function () {
      return VIRTUAL_SCROLL_STRATEGY;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CdkVirtualScrollViewport", function () {
      return CdkVirtualScrollViewport;
    });
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/cdk/coercion */
    "./node_modules/@angular/cdk/esm2015/coercion.js");
    /* harmony import */


    var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! rxjs */
    "./node_modules/rxjs/_esm2015/index.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var _angular_cdk_platform__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/cdk/platform */
    "./node_modules/@angular/cdk/esm2015/platform.js");
    /* harmony import */


    var _angular_cdk_bidi__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/cdk/bidi */
    "./node_modules/@angular/cdk/esm2015/bidi.js");
    /* harmony import */


    var _angular_cdk_collections__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @angular/cdk/collections */
    "./node_modules/@angular/cdk/esm2015/collections.js");
    /**
     * @license
     * Copyright Google LLC All Rights Reserved.
     *
     * Use of this source code is governed by an MIT-style license that can be
     * found in the LICENSE file at https://angular.io/license
     */

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    /**
     * The injection token used to specify the virtual scrolling strategy.
     * @type {?}
     */


    var VIRTUAL_SCROLL_STRATEGY = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["InjectionToken"]('VIRTUAL_SCROLL_STRATEGY');
    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    /**
     * Virtual scrolling strategy for lists with items of known fixed size.
     */

    var FixedSizeVirtualScrollStrategy = /*#__PURE__*/function () {
      /**
       * @param {?} itemSize The size of the items in the virtually scrolling list.
       * @param {?} minBufferPx The minimum amount of buffer (in pixels) before needing to render more
       * @param {?} maxBufferPx The amount of buffer (in pixels) to render when rendering more.
       */
      function FixedSizeVirtualScrollStrategy(itemSize, minBufferPx, maxBufferPx) {
        _classCallCheck(this, FixedSizeVirtualScrollStrategy);

        this._scrolledIndexChange = new rxjs__WEBPACK_IMPORTED_MODULE_2__["Subject"]();
        /**
         * \@docs-private Implemented as part of VirtualScrollStrategy.
         */

        this.scrolledIndexChange = this._scrolledIndexChange.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["distinctUntilChanged"])());
        /**
         * The attached viewport.
         */

        this._viewport = null;
        this._itemSize = itemSize;
        this._minBufferPx = minBufferPx;
        this._maxBufferPx = maxBufferPx;
      }
      /**
       * Attaches this scroll strategy to a viewport.
       * @param {?} viewport The viewport to attach this strategy to.
       * @return {?}
       */


      _createClass(FixedSizeVirtualScrollStrategy, [{
        key: "attach",
        value: function attach(viewport) {
          this._viewport = viewport;

          this._updateTotalContentSize();

          this._updateRenderedRange();
        }
        /**
         * Detaches this scroll strategy from the currently attached viewport.
         * @return {?}
         */

      }, {
        key: "detach",
        value: function detach() {
          this._scrolledIndexChange.complete();

          this._viewport = null;
        }
        /**
         * Update the item size and buffer size.
         * @param {?} itemSize The size of the items in the virtually scrolling list.
         * @param {?} minBufferPx The minimum amount of buffer (in pixels) before needing to render more
         * @param {?} maxBufferPx The amount of buffer (in pixels) to render when rendering more.
         * @return {?}
         */

      }, {
        key: "updateItemAndBufferSize",
        value: function updateItemAndBufferSize(itemSize, minBufferPx, maxBufferPx) {
          if (maxBufferPx < minBufferPx) {
            throw Error('CDK virtual scroll: maxBufferPx must be greater than or equal to minBufferPx');
          }

          this._itemSize = itemSize;
          this._minBufferPx = minBufferPx;
          this._maxBufferPx = maxBufferPx;

          this._updateTotalContentSize();

          this._updateRenderedRange();
        }
        /**
         * \@docs-private Implemented as part of VirtualScrollStrategy.
         * @return {?}
         */

      }, {
        key: "onContentScrolled",
        value: function onContentScrolled() {
          this._updateRenderedRange();
        }
        /**
         * \@docs-private Implemented as part of VirtualScrollStrategy.
         * @return {?}
         */

      }, {
        key: "onDataLengthChanged",
        value: function onDataLengthChanged() {
          this._updateTotalContentSize();

          this._updateRenderedRange();
        }
        /**
         * \@docs-private Implemented as part of VirtualScrollStrategy.
         * @return {?}
         */

      }, {
        key: "onContentRendered",
        value: function onContentRendered() {}
        /**
         * \@docs-private Implemented as part of VirtualScrollStrategy.
         * @return {?}
         */

      }, {
        key: "onRenderedOffsetChanged",
        value: function onRenderedOffsetChanged() {}
        /**
         * Scroll to the offset for the given index.
         * @param {?} index The index of the element to scroll to.
         * @param {?} behavior The ScrollBehavior to use when scrolling.
         * @return {?}
         */

      }, {
        key: "scrollToIndex",
        value: function scrollToIndex(index, behavior) {
          if (this._viewport) {
            this._viewport.scrollToOffset(index * this._itemSize, behavior);
          }
        }
        /**
         * Update the viewport's total content size.
         * @private
         * @return {?}
         */

      }, {
        key: "_updateTotalContentSize",
        value: function _updateTotalContentSize() {
          if (!this._viewport) {
            return;
          }

          this._viewport.setTotalContentSize(this._viewport.getDataLength() * this._itemSize);
        }
        /**
         * Update the viewport's rendered range.
         * @private
         * @return {?}
         */

      }, {
        key: "_updateRenderedRange",
        value: function _updateRenderedRange() {
          if (!this._viewport) {
            return;
          }
          /** @type {?} */


          var scrollOffset = this._viewport.measureScrollOffset();
          /** @type {?} */


          var firstVisibleIndex = scrollOffset / this._itemSize;
          /** @type {?} */

          var renderedRange = this._viewport.getRenderedRange();
          /** @type {?} */


          var newRange = {
            start: renderedRange.start,
            end: renderedRange.end
          };
          /** @type {?} */

          var viewportSize = this._viewport.getViewportSize();
          /** @type {?} */


          var dataLength = this._viewport.getDataLength();
          /** @type {?} */


          var startBuffer = scrollOffset - newRange.start * this._itemSize;

          if (startBuffer < this._minBufferPx && newRange.start != 0) {
            /** @type {?} */
            var expandStart = Math.ceil((this._maxBufferPx - startBuffer) / this._itemSize);
            newRange.start = Math.max(0, newRange.start - expandStart);
            newRange.end = Math.min(dataLength, Math.ceil(firstVisibleIndex + (viewportSize + this._minBufferPx) / this._itemSize));
          } else {
            /** @type {?} */
            var endBuffer = newRange.end * this._itemSize - (scrollOffset + viewportSize);

            if (endBuffer < this._minBufferPx && newRange.end != dataLength) {
              /** @type {?} */
              var expandEnd = Math.ceil((this._maxBufferPx - endBuffer) / this._itemSize);

              if (expandEnd > 0) {
                newRange.end = Math.min(dataLength, newRange.end + expandEnd);
                newRange.start = Math.max(0, Math.floor(firstVisibleIndex - this._minBufferPx / this._itemSize));
              }
            }
          }

          this._viewport.setRenderedRange(newRange);

          this._viewport.setRenderedContentOffset(this._itemSize * newRange.start);

          this._scrolledIndexChange.next(Math.floor(firstVisibleIndex));
        }
      }]);

      return FixedSizeVirtualScrollStrategy;
    }();
    /**
     * Provider factory for `FixedSizeVirtualScrollStrategy` that simply extracts the already created
     * `FixedSizeVirtualScrollStrategy` from the given directive.
     * @param {?} fixedSizeDir The instance of `CdkFixedSizeVirtualScroll` to extract the
     *     `FixedSizeVirtualScrollStrategy` from.
     * @return {?}
     */


    function _fixedSizeVirtualScrollStrategyFactory(fixedSizeDir) {
      return fixedSizeDir._scrollStrategy;
    }
    /**
     * A virtual scroll strategy that supports fixed-size items.
     */


    var CdkFixedSizeVirtualScroll = /*#__PURE__*/function () {
      function CdkFixedSizeVirtualScroll() {
        _classCallCheck(this, CdkFixedSizeVirtualScroll);

        this._itemSize = 20;
        this._minBufferPx = 100;
        this._maxBufferPx = 200;
        /**
         * The scroll strategy used by this directive.
         */

        this._scrollStrategy = new FixedSizeVirtualScrollStrategy(this.itemSize, this.minBufferPx, this.maxBufferPx);
      }
      /**
       * The size of the items in the list (in pixels).
       * @return {?}
       */


      _createClass(CdkFixedSizeVirtualScroll, [{
        key: "ngOnChanges",

        /**
         * @return {?}
         */
        value: function ngOnChanges() {
          this._scrollStrategy.updateItemAndBufferSize(this.itemSize, this.minBufferPx, this.maxBufferPx);
        }
      }, {
        key: "itemSize",
        get: function get() {
          return this._itemSize;
        }
        /**
         * @param {?} value
         * @return {?}
         */
        ,
        set: function set(value) {
          this._itemSize = Object(_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_1__["coerceNumberProperty"])(value);
        }
        /**
         * The minimum amount of buffer rendered beyond the viewport (in pixels).
         * If the amount of buffer dips below this number, more items will be rendered. Defaults to 100px.
         * @return {?}
         */

      }, {
        key: "minBufferPx",
        get: function get() {
          return this._minBufferPx;
        }
        /**
         * @param {?} value
         * @return {?}
         */
        ,
        set: function set(value) {
          this._minBufferPx = Object(_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_1__["coerceNumberProperty"])(value);
        }
        /**
         * The number of pixels worth of buffer to render for when rendering new items. Defaults to 200px.
         * @return {?}
         */

      }, {
        key: "maxBufferPx",
        get: function get() {
          return this._maxBufferPx;
        }
        /**
         * @param {?} value
         * @return {?}
         */
        ,
        set: function set(value) {
          this._maxBufferPx = Object(_angular_cdk_coercion__WEBPACK_IMPORTED_MODULE_1__["coerceNumberProperty"])(value);
        }
      }]);

      return CdkFixedSizeVirtualScroll;
    }();

    CdkFixedSizeVirtualScroll.decorators = [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Directive"],
      args: [{
        selector: 'cdk-virtual-scroll-viewport[itemSize]',
        providers: [{
          provide: VIRTUAL_SCROLL_STRATEGY,
          useFactory: _fixedSizeVirtualScrollStrategyFactory,
          deps: [Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["forwardRef"])(
          /**
          * @return {?}
          */
          function () {
            return CdkFixedSizeVirtualScroll;
          })]
        }]
      }]
    }];
    CdkFixedSizeVirtualScroll.propDecorators = {
      itemSize: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
      }],
      minBufferPx: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
      }],
      maxBufferPx: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
      }]
    };
    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    /**
     * Time in ms to throttle the scrolling events by default.
     * @type {?}
     */

    var DEFAULT_SCROLL_TIME = 20;
    /**
     * Service contained all registered Scrollable references and emits an event when any one of the
     * Scrollable references emit a scrolled event.
     */

    var ScrollDispatcher = /*#__PURE__*/function () {
      /**
       * @param {?} _ngZone
       * @param {?} _platform
       */
      function ScrollDispatcher(_ngZone, _platform) {
        _classCallCheck(this, ScrollDispatcher);

        this._ngZone = _ngZone;
        this._platform = _platform;
        /**
         * Subject for notifying that a registered scrollable reference element has been scrolled.
         */

        this._scrolled = new rxjs__WEBPACK_IMPORTED_MODULE_2__["Subject"]();
        /**
         * Keeps track of the global `scroll` and `resize` subscriptions.
         */

        this._globalSubscription = null;
        /**
         * Keeps track of the amount of subscriptions to `scrolled`. Used for cleaning up afterwards.
         */

        this._scrolledCount = 0;
        /**
         * Map of all the scrollable references that are registered with the service and their
         * scroll event subscriptions.
         */

        this.scrollContainers = new Map();
      }
      /**
       * Registers a scrollable instance with the service and listens for its scrolled events. When the
       * scrollable is scrolled, the service emits the event to its scrolled observable.
       * @param {?} scrollable Scrollable instance to be registered.
       * @return {?}
       */


      _createClass(ScrollDispatcher, [{
        key: "register",
        value: function register(scrollable) {
          var _this36 = this;

          if (!this.scrollContainers.has(scrollable)) {
            this.scrollContainers.set(scrollable, scrollable.elementScrolled().subscribe(
            /**
            * @return {?}
            */
            function () {
              return _this36._scrolled.next(scrollable);
            }));
          }
        }
        /**
         * Deregisters a Scrollable reference and unsubscribes from its scroll event observable.
         * @param {?} scrollable Scrollable instance to be deregistered.
         * @return {?}
         */

      }, {
        key: "deregister",
        value: function deregister(scrollable) {
          /** @type {?} */
          var scrollableReference = this.scrollContainers.get(scrollable);

          if (scrollableReference) {
            scrollableReference.unsubscribe();
            this.scrollContainers["delete"](scrollable);
          }
        }
        /**
         * Returns an observable that emits an event whenever any of the registered Scrollable
         * references (or window, document, or body) fire a scrolled event. Can provide a time in ms
         * to override the default "throttle" time.
         *
         * **Note:** in order to avoid hitting change detection for every scroll event,
         * all of the events emitted from this stream will be run outside the Angular zone.
         * If you need to update any data bindings as a result of a scroll event, you have
         * to run the callback using `NgZone.run`.
         * @param {?=} auditTimeInMs
         * @return {?}
         */

      }, {
        key: "scrolled",
        value: function scrolled() {
          var _this37 = this;

          var auditTimeInMs = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : DEFAULT_SCROLL_TIME;

          if (!this._platform.isBrowser) {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["of"])();
          }

          return new rxjs__WEBPACK_IMPORTED_MODULE_2__["Observable"](
          /**
          * @param {?} observer
          * @return {?}
          */
          function (observer) {
            if (!_this37._globalSubscription) {
              _this37._addGlobalListener();
            } // In the case of a 0ms delay, use an observable without auditTime
            // since it does add a perceptible delay in processing overhead.

            /** @type {?} */


            var subscription = auditTimeInMs > 0 ? _this37._scrolled.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["auditTime"])(auditTimeInMs)).subscribe(observer) : _this37._scrolled.subscribe(observer);
            _this37._scrolledCount++;
            return (
              /**
              * @return {?}
              */
              function () {
                subscription.unsubscribe();
                _this37._scrolledCount--;

                if (!_this37._scrolledCount) {
                  _this37._removeGlobalListener();
                }
              }
            );
          });
        }
        /**
         * @return {?}
         */

      }, {
        key: "ngOnDestroy",
        value: function ngOnDestroy() {
          var _this38 = this;

          this._removeGlobalListener();

          this.scrollContainers.forEach(
          /**
          * @param {?} _
          * @param {?} container
          * @return {?}
          */
          function (_, container) {
            return _this38.deregister(container);
          });

          this._scrolled.complete();
        }
        /**
         * Returns an observable that emits whenever any of the
         * scrollable ancestors of an element are scrolled.
         * @param {?} elementRef Element whose ancestors to listen for.
         * @param {?=} auditTimeInMs Time to throttle the scroll events.
         * @return {?}
         */

      }, {
        key: "ancestorScrolled",
        value: function ancestorScrolled(elementRef, auditTimeInMs) {
          /** @type {?} */
          var ancestors = this.getAncestorScrollContainers(elementRef);
          return this.scrolled(auditTimeInMs).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["filter"])(
          /**
          * @param {?} target
          * @return {?}
          */
          function (target) {
            return !target || ancestors.indexOf(target) > -1;
          }));
        }
        /**
         * Returns all registered Scrollables that contain the provided element.
         * @param {?} elementRef
         * @return {?}
         */

      }, {
        key: "getAncestorScrollContainers",
        value: function getAncestorScrollContainers(elementRef) {
          var _this39 = this;

          /** @type {?} */
          var scrollingContainers = [];
          this.scrollContainers.forEach(
          /**
          * @param {?} _subscription
          * @param {?} scrollable
          * @return {?}
          */
          function (_subscription, scrollable) {
            if (_this39._scrollableContainsElement(scrollable, elementRef)) {
              scrollingContainers.push(scrollable);
            }
          });
          return scrollingContainers;
        }
        /**
         * Returns true if the element is contained within the provided Scrollable.
         * @private
         * @param {?} scrollable
         * @param {?} elementRef
         * @return {?}
         */

      }, {
        key: "_scrollableContainsElement",
        value: function _scrollableContainsElement(scrollable, elementRef) {
          /** @type {?} */
          var element = elementRef.nativeElement;
          /** @type {?} */

          var scrollableElement = scrollable.getElementRef().nativeElement; // Traverse through the element parents until we reach null, checking if any of the elements
          // are the scrollable's element.

          do {
            if (element == scrollableElement) {
              return true;
            }
          } while (element =
          /** @type {?} */
          element.parentElement);

          return false;
        }
        /**
         * Sets up the global scroll listeners.
         * @private
         * @return {?}
         */

      }, {
        key: "_addGlobalListener",
        value: function _addGlobalListener() {
          var _this40 = this;

          this._globalSubscription = this._ngZone.runOutsideAngular(
          /**
          * @return {?}
          */
          function () {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["fromEvent"])(window.document, 'scroll').subscribe(
            /**
            * @return {?}
            */
            function () {
              return _this40._scrolled.next();
            });
          });
        }
        /**
         * Cleans up the global scroll listener.
         * @private
         * @return {?}
         */

      }, {
        key: "_removeGlobalListener",
        value: function _removeGlobalListener() {
          if (this._globalSubscription) {
            this._globalSubscription.unsubscribe();

            this._globalSubscription = null;
          }
        }
      }]);

      return ScrollDispatcher;
    }();

    ScrollDispatcher.decorators = [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"],
      args: [{
        providedIn: 'root'
      }]
    }];
    /** @nocollapse */

    ScrollDispatcher.ctorParameters = function () {
      return [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgZone"]
      }, {
        type: _angular_cdk_platform__WEBPACK_IMPORTED_MODULE_4__["Platform"]
      }];
    };
    /** @nocollapse */


    ScrollDispatcher.ngInjectableDef = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"])({
      factory: function ScrollDispatcher_Factory() {
        return new ScrollDispatcher(Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"])(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgZone"]), Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"])(_angular_cdk_platform__WEBPACK_IMPORTED_MODULE_4__["Platform"]));
      },
      token: ScrollDispatcher,
      providedIn: "root"
    });
    /**
     * \@docs-private \@deprecated \@breaking-change 8.0.0
     * @param {?} parentDispatcher
     * @param {?} ngZone
     * @param {?} platform
     * @return {?}
     */

    function SCROLL_DISPATCHER_PROVIDER_FACTORY(parentDispatcher, ngZone, platform) {
      return parentDispatcher || new ScrollDispatcher(ngZone, platform);
    }
    /**
     * \@docs-private \@deprecated \@breaking-change 8.0.0
     * @type {?}
     */


    var SCROLL_DISPATCHER_PROVIDER = {
      // If there is already a ScrollDispatcher available, use that. Otherwise, provide a new one.
      provide: ScrollDispatcher,
      deps: [[new _angular_core__WEBPACK_IMPORTED_MODULE_0__["Optional"](), new _angular_core__WEBPACK_IMPORTED_MODULE_0__["SkipSelf"](), ScrollDispatcher], _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgZone"], _angular_cdk_platform__WEBPACK_IMPORTED_MODULE_4__["Platform"]],
      useFactory: SCROLL_DISPATCHER_PROVIDER_FACTORY
    };
    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    /**
     * Sends an event when the directive's element is scrolled. Registers itself with the
     * ScrollDispatcher service to include itself as part of its collection of scrolling events that it
     * can be listened to through the service.
     */

    var CdkScrollable = /*#__PURE__*/function () {
      /**
       * @param {?} elementRef
       * @param {?} scrollDispatcher
       * @param {?} ngZone
       * @param {?=} dir
       */
      function CdkScrollable(elementRef, scrollDispatcher, ngZone, dir) {
        var _this41 = this;

        _classCallCheck(this, CdkScrollable);

        this.elementRef = elementRef;
        this.scrollDispatcher = scrollDispatcher;
        this.ngZone = ngZone;
        this.dir = dir;
        this._destroyed = new rxjs__WEBPACK_IMPORTED_MODULE_2__["Subject"]();
        this._elementScrolled = new rxjs__WEBPACK_IMPORTED_MODULE_2__["Observable"](
        /**
        * @param {?} observer
        * @return {?}
        */
        function (observer) {
          return _this41.ngZone.runOutsideAngular(
          /**
          * @return {?}
          */
          function () {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["fromEvent"])(_this41.elementRef.nativeElement, 'scroll').pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["takeUntil"])(_this41._destroyed)).subscribe(observer);
          });
        });
      }
      /**
       * @return {?}
       */


      _createClass(CdkScrollable, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.scrollDispatcher.register(this);
        }
        /**
         * @return {?}
         */

      }, {
        key: "ngOnDestroy",
        value: function ngOnDestroy() {
          this.scrollDispatcher.deregister(this);

          this._destroyed.next();

          this._destroyed.complete();
        }
        /**
         * Returns observable that emits when a scroll event is fired on the host element.
         * @return {?}
         */

      }, {
        key: "elementScrolled",
        value: function elementScrolled() {
          return this._elementScrolled;
        }
        /**
         * Gets the ElementRef for the viewport.
         * @return {?}
         */

      }, {
        key: "getElementRef",
        value: function getElementRef() {
          return this.elementRef;
        }
        /**
         * Scrolls to the specified offsets. This is a normalized version of the browser's native scrollTo
         * method, since browsers are not consistent about what scrollLeft means in RTL. For this method
         * left and right always refer to the left and right side of the scrolling container irrespective
         * of the layout direction. start and end refer to left and right in an LTR context and vice-versa
         * in an RTL context.
         * @param {?} options specified the offsets to scroll to.
         * @return {?}
         */

      }, {
        key: "scrollTo",
        value: function scrollTo(options) {
          /** @type {?} */
          var el = this.elementRef.nativeElement;
          /** @type {?} */

          var isRtl = this.dir && this.dir.value == 'rtl'; // Rewrite start & end offsets as right or left offsets.

          options.left = options.left == null ? isRtl ? options.end : options.start : options.left;
          options.right = options.right == null ? isRtl ? options.start : options.end : options.right; // Rewrite the bottom offset as a top offset.

          if (options.bottom != null) {
            /** @type {?} */
            options.top = el.scrollHeight - el.clientHeight - options.bottom;
          } // Rewrite the right offset as a left offset.


          if (isRtl && Object(_angular_cdk_platform__WEBPACK_IMPORTED_MODULE_4__["getRtlScrollAxisType"])() != _angular_cdk_platform__WEBPACK_IMPORTED_MODULE_4__["RtlScrollAxisType"].NORMAL) {
            if (options.left != null) {
              /** @type {?} */
              options.right = el.scrollWidth - el.clientWidth - options.left;
            }

            if (Object(_angular_cdk_platform__WEBPACK_IMPORTED_MODULE_4__["getRtlScrollAxisType"])() == _angular_cdk_platform__WEBPACK_IMPORTED_MODULE_4__["RtlScrollAxisType"].INVERTED) {
              options.left = options.right;
            } else if (Object(_angular_cdk_platform__WEBPACK_IMPORTED_MODULE_4__["getRtlScrollAxisType"])() == _angular_cdk_platform__WEBPACK_IMPORTED_MODULE_4__["RtlScrollAxisType"].NEGATED) {
              options.left = options.right ? -options.right : options.right;
            }
          } else {
            if (options.right != null) {
              /** @type {?} */
              options.left = el.scrollWidth - el.clientWidth - options.right;
            }
          }

          this._applyScrollToOptions(options);
        }
        /**
         * @private
         * @param {?} options
         * @return {?}
         */

      }, {
        key: "_applyScrollToOptions",
        value: function _applyScrollToOptions(options) {
          /** @type {?} */
          var el = this.elementRef.nativeElement;

          if (Object(_angular_cdk_platform__WEBPACK_IMPORTED_MODULE_4__["supportsScrollBehavior"])()) {
            el.scrollTo(options);
          } else {
            if (options.top != null) {
              el.scrollTop = options.top;
            }

            if (options.left != null) {
              el.scrollLeft = options.left;
            }
          }
        }
        /**
         * Measures the scroll offset relative to the specified edge of the viewport. This method can be
         * used instead of directly checking scrollLeft or scrollTop, since browsers are not consistent
         * about what scrollLeft means in RTL. The values returned by this method are normalized such that
         * left and right always refer to the left and right side of the scrolling container irrespective
         * of the layout direction. start and end refer to left and right in an LTR context and vice-versa
         * in an RTL context.
         * @param {?} from The edge to measure from.
         * @return {?}
         */

      }, {
        key: "measureScrollOffset",
        value: function measureScrollOffset(from) {
          /** @type {?} */
          var LEFT = 'left';
          /** @type {?} */

          var RIGHT = 'right';
          /** @type {?} */

          var el = this.elementRef.nativeElement;

          if (from == 'top') {
            return el.scrollTop;
          }

          if (from == 'bottom') {
            return el.scrollHeight - el.clientHeight - el.scrollTop;
          } // Rewrite start & end as left or right offsets.

          /** @type {?} */


          var isRtl = this.dir && this.dir.value == 'rtl';

          if (from == 'start') {
            from = isRtl ? RIGHT : LEFT;
          } else if (from == 'end') {
            from = isRtl ? LEFT : RIGHT;
          }

          if (isRtl && Object(_angular_cdk_platform__WEBPACK_IMPORTED_MODULE_4__["getRtlScrollAxisType"])() == _angular_cdk_platform__WEBPACK_IMPORTED_MODULE_4__["RtlScrollAxisType"].INVERTED) {
            // For INVERTED, scrollLeft is (scrollWidth - clientWidth) when scrolled all the way left and
            // 0 when scrolled all the way right.
            if (from == LEFT) {
              return el.scrollWidth - el.clientWidth - el.scrollLeft;
            } else {
              return el.scrollLeft;
            }
          } else if (isRtl && Object(_angular_cdk_platform__WEBPACK_IMPORTED_MODULE_4__["getRtlScrollAxisType"])() == _angular_cdk_platform__WEBPACK_IMPORTED_MODULE_4__["RtlScrollAxisType"].NEGATED) {
            // For NEGATED, scrollLeft is -(scrollWidth - clientWidth) when scrolled all the way left and
            // 0 when scrolled all the way right.
            if (from == LEFT) {
              return el.scrollLeft + el.scrollWidth - el.clientWidth;
            } else {
              return -el.scrollLeft;
            }
          } else {
            // For NORMAL, as well as non-RTL contexts, scrollLeft is 0 when scrolled all the way left and
            // (scrollWidth - clientWidth) when scrolled all the way right.
            if (from == LEFT) {
              return el.scrollLeft;
            } else {
              return el.scrollWidth - el.clientWidth - el.scrollLeft;
            }
          }
        }
      }]);

      return CdkScrollable;
    }();

    CdkScrollable.decorators = [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Directive"],
      args: [{
        selector: '[cdk-scrollable], [cdkScrollable]'
      }]
    }];
    /** @nocollapse */

    CdkScrollable.ctorParameters = function () {
      return [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"]
      }, {
        type: ScrollDispatcher
      }, {
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgZone"]
      }, {
        type: _angular_cdk_bidi__WEBPACK_IMPORTED_MODULE_5__["Directionality"],
        decorators: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Optional"]
        }]
      }];
    };
    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    /**
     * Checks if the given ranges are equal.
     * @param {?} r1
     * @param {?} r2
     * @return {?}
     */


    function rangesEqual(r1, r2) {
      return r1.start == r2.start && r1.end == r2.end;
    }
    /**
     * Scheduler to be used for scroll events. Needs to fall back to
     * something that doesn't rely on requestAnimationFrame on environments
     * that don't support it (e.g. server-side rendering).
     * @type {?}
     */


    var SCROLL_SCHEDULER = typeof requestAnimationFrame !== 'undefined' ? rxjs__WEBPACK_IMPORTED_MODULE_2__["animationFrameScheduler"] : rxjs__WEBPACK_IMPORTED_MODULE_2__["asapScheduler"];
    /**
     * A viewport that virtualizes its scrolling with the help of `CdkVirtualForOf`.
     */

    var CdkVirtualScrollViewport = /*#__PURE__*/function (_CdkScrollable) {
      _inherits(CdkVirtualScrollViewport, _CdkScrollable);

      var _super3 = _createSuper(CdkVirtualScrollViewport);

      /**
       * @param {?} elementRef
       * @param {?} _changeDetectorRef
       * @param {?} ngZone
       * @param {?} _scrollStrategy
       * @param {?} dir
       * @param {?} scrollDispatcher
       */
      function CdkVirtualScrollViewport(elementRef, _changeDetectorRef, ngZone, _scrollStrategy, dir, scrollDispatcher) {
        var _this42;

        _classCallCheck(this, CdkVirtualScrollViewport);

        _this42 = _super3.call(this, elementRef, scrollDispatcher, ngZone, dir);
        _this42.elementRef = elementRef;
        _this42._changeDetectorRef = _changeDetectorRef;
        _this42._scrollStrategy = _scrollStrategy;
        /**
         * Emits when the viewport is detached from a CdkVirtualForOf.
         */

        _this42._detachedSubject = new rxjs__WEBPACK_IMPORTED_MODULE_2__["Subject"]();
        /**
         * Emits when the rendered range changes.
         */

        _this42._renderedRangeSubject = new rxjs__WEBPACK_IMPORTED_MODULE_2__["Subject"]();
        _this42._orientation = 'vertical'; // Note: we don't use the typical EventEmitter here because we need to subscribe to the scroll
        // strategy lazily (i.e. only if the user is actually listening to the events). We do this because
        // depending on how the strategy calculates the scrolled index, it may come at a cost to
        // performance.

        /**
         * Emits when the index of the first element visible in the viewport changes.
         */

        _this42.scrolledIndexChange = new rxjs__WEBPACK_IMPORTED_MODULE_2__["Observable"](
        /**
        * @param {?} observer
        * @return {?}
        */
        function (observer) {
          return _this42._scrollStrategy.scrolledIndexChange.subscribe(
          /**
          * @param {?} index
          * @return {?}
          */
          function (index) {
            return Promise.resolve().then(
            /**
            * @return {?}
            */
            function () {
              return _this42.ngZone.run(
              /**
              * @return {?}
              */
              function () {
                return observer.next(index);
              });
            });
          });
        });
        /**
         * A stream that emits whenever the rendered range changes.
         */

        _this42.renderedRangeStream = _this42._renderedRangeSubject.asObservable();
        /**
         * The total size of all content (in pixels), including content that is not currently rendered.
         */

        _this42._totalContentSize = 0;
        /**
         * A string representing the `style.width` property value to be used for the spacer element.
         */

        _this42._totalContentWidth = '';
        /**
         * A string representing the `style.height` property value to be used for the spacer element.
         */

        _this42._totalContentHeight = '';
        /**
         * The currently rendered range of indices.
         */

        _this42._renderedRange = {
          start: 0,
          end: 0
        };
        /**
         * The length of the data bound to this viewport (in number of items).
         */

        _this42._dataLength = 0;
        /**
         * The size of the viewport (in pixels).
         */

        _this42._viewportSize = 0;
        /**
         * The last rendered content offset that was set.
         */

        _this42._renderedContentOffset = 0;
        /**
         * Whether the last rendered content offset was to the end of the content (and therefore needs to
         * be rewritten as an offset to the start of the content).
         */

        _this42._renderedContentOffsetNeedsRewrite = false;
        /**
         * Whether there is a pending change detection cycle.
         */

        _this42._isChangeDetectionPending = false;
        /**
         * A list of functions to run after the next change detection cycle.
         */

        _this42._runAfterChangeDetection = [];

        if (!_scrollStrategy) {
          throw Error('Error: cdk-virtual-scroll-viewport requires the "itemSize" property to be set.');
        }

        return _this42;
      }
      /**
       * The direction the viewport scrolls.
       * @return {?}
       */


      _createClass(CdkVirtualScrollViewport, [{
        key: "ngOnInit",

        /**
         * @return {?}
         */
        value: function ngOnInit() {
          var _this43 = this;

          _get(_getPrototypeOf(CdkVirtualScrollViewport.prototype), "ngOnInit", this).call(this); // It's still too early to measure the viewport at this point. Deferring with a promise allows
          // the Viewport to be rendered with the correct size before we measure. We run this outside the
          // zone to avoid causing more change detection cycles. We handle the change detection loop
          // ourselves instead.


          this.ngZone.runOutsideAngular(
          /**
          * @return {?}
          */
          function () {
            return Promise.resolve().then(
            /**
            * @return {?}
            */
            function () {
              _this43._measureViewportSize();

              _this43._scrollStrategy.attach(_this43);

              _this43.elementScrolled().pipe( // Start off with a fake scroll event so we properly detect our initial position.
              Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["startWith"])(
              /** @type {?} */
              null), // Collect multiple events into one until the next animation frame. This way if
              // there are multiple scroll events in the same frame we only need to recheck
              // our layout once.
              Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["auditTime"])(0, SCROLL_SCHEDULER)).subscribe(
              /**
              * @return {?}
              */
              function () {
                return _this43._scrollStrategy.onContentScrolled();
              });

              _this43._markChangeDetectionNeeded();
            });
          });
        }
        /**
         * @return {?}
         */

      }, {
        key: "ngOnDestroy",
        value: function ngOnDestroy() {
          this.detach();

          this._scrollStrategy.detach(); // Complete all subjects


          this._renderedRangeSubject.complete();

          this._detachedSubject.complete();

          _get(_getPrototypeOf(CdkVirtualScrollViewport.prototype), "ngOnDestroy", this).call(this);
        }
        /**
         * Attaches a `CdkVirtualForOf` to this viewport.
         * @param {?} forOf
         * @return {?}
         */

      }, {
        key: "attach",
        value: function attach(forOf) {
          var _this44 = this;

          if (this._forOf) {
            throw Error('CdkVirtualScrollViewport is already attached.');
          } // Subscribe to the data stream of the CdkVirtualForOf to keep track of when the data length
          // changes. Run outside the zone to avoid triggering change detection, since we're managing the
          // change detection loop ourselves.


          this.ngZone.runOutsideAngular(
          /**
          * @return {?}
          */
          function () {
            _this44._forOf = forOf;

            _this44._forOf.dataStream.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["takeUntil"])(_this44._detachedSubject)).subscribe(
            /**
            * @param {?} data
            * @return {?}
            */
            function (data) {
              /** @type {?} */
              var newLength = data.length;

              if (newLength !== _this44._dataLength) {
                _this44._dataLength = newLength;

                _this44._scrollStrategy.onDataLengthChanged();
              }

              _this44._doChangeDetection();
            });
          });
        }
        /**
         * Detaches the current `CdkVirtualForOf`.
         * @return {?}
         */

      }, {
        key: "detach",
        value: function detach() {
          this._forOf = null;

          this._detachedSubject.next();
        }
        /**
         * Gets the length of the data bound to this viewport (in number of items).
         * @return {?}
         */

      }, {
        key: "getDataLength",
        value: function getDataLength() {
          return this._dataLength;
        }
        /**
         * Gets the size of the viewport (in pixels).
         * @return {?}
         */

      }, {
        key: "getViewportSize",
        value: function getViewportSize() {
          return this._viewportSize;
        } // TODO(mmalerba): This is technically out of sync with what's really rendered until a render
        // cycle happens. I'm being careful to only call it after the render cycle is complete and before
        // setting it to something else, but its error prone and should probably be split into
        // `pendingRange` and `renderedRange`, the latter reflecting whats actually in the DOM.

        /**
         * Get the current rendered range of items.
         * @return {?}
         */

      }, {
        key: "getRenderedRange",
        value: function getRenderedRange() {
          return this._renderedRange;
        }
        /**
         * Sets the total size of all content (in pixels), including content that is not currently
         * rendered.
         * @param {?} size
         * @return {?}
         */

      }, {
        key: "setTotalContentSize",
        value: function setTotalContentSize(size) {
          if (this._totalContentSize !== size) {
            this._totalContentSize = size;

            this._calculateSpacerSize();

            this._markChangeDetectionNeeded();
          }
        }
        /**
         * Sets the currently rendered range of indices.
         * @param {?} range
         * @return {?}
         */

      }, {
        key: "setRenderedRange",
        value: function setRenderedRange(range) {
          var _this45 = this;

          if (!rangesEqual(this._renderedRange, range)) {
            this._renderedRangeSubject.next(this._renderedRange = range);

            this._markChangeDetectionNeeded(
            /**
            * @return {?}
            */
            function () {
              return _this45._scrollStrategy.onContentRendered();
            });
          }
        }
        /**
         * Gets the offset from the start of the viewport to the start of the rendered data (in pixels).
         * @return {?}
         */

      }, {
        key: "getOffsetToRenderedContentStart",
        value: function getOffsetToRenderedContentStart() {
          return this._renderedContentOffsetNeedsRewrite ? null : this._renderedContentOffset;
        }
        /**
         * Sets the offset from the start of the viewport to either the start or end of the rendered data
         * (in pixels).
         * @param {?} offset
         * @param {?=} to
         * @return {?}
         */

      }, {
        key: "setRenderedContentOffset",
        value: function setRenderedContentOffset(offset) {
          var _this46 = this;

          var to = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'to-start';
          // For a horizontal viewport in a right-to-left language we need to translate along the x-axis
          // in the negative direction.

          /** @type {?} */
          var isRtl = this.dir && this.dir.value == 'rtl';
          /** @type {?} */

          var isHorizontal = this.orientation == 'horizontal';
          /** @type {?} */

          var axis = isHorizontal ? 'X' : 'Y';
          /** @type {?} */

          var axisDirection = isHorizontal && isRtl ? -1 : 1;
          /** @type {?} */

          var transform = "translate".concat(axis, "(").concat(Number(axisDirection * offset), "px)");
          this._renderedContentOffset = offset;

          if (to === 'to-end') {
            transform += " translate".concat(axis, "(-100%)"); // The viewport should rewrite this as a `to-start` offset on the next render cycle. Otherwise
            // elements will appear to expand in the wrong direction (e.g. `mat-expansion-panel` would
            // expand upward).

            this._renderedContentOffsetNeedsRewrite = true;
          }

          if (this._renderedContentTransform != transform) {
            // We know this value is safe because we parse `offset` with `Number()` before passing it
            // into the string.
            this._renderedContentTransform = transform;

            this._markChangeDetectionNeeded(
            /**
            * @return {?}
            */
            function () {
              if (_this46._renderedContentOffsetNeedsRewrite) {
                _this46._renderedContentOffset -= _this46.measureRenderedContentSize();
                _this46._renderedContentOffsetNeedsRewrite = false;

                _this46.setRenderedContentOffset(_this46._renderedContentOffset);
              } else {
                _this46._scrollStrategy.onRenderedOffsetChanged();
              }
            });
          }
        }
        /**
         * Scrolls to the given offset from the start of the viewport. Please note that this is not always
         * the same as setting `scrollTop` or `scrollLeft`. In a horizontal viewport with right-to-left
         * direction, this would be the equivalent of setting a fictional `scrollRight` property.
         * @param {?} offset The offset to scroll to.
         * @param {?=} behavior The ScrollBehavior to use when scrolling. Default is behavior is `auto`.
         * @return {?}
         */

      }, {
        key: "scrollToOffset",
        value: function scrollToOffset(offset) {
          var behavior = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'auto';

          /** @type {?} */
          var options = {
            behavior: behavior
          };

          if (this.orientation === 'horizontal') {
            options.start = offset;
          } else {
            options.top = offset;
          }

          this.scrollTo(options);
        }
        /**
         * Scrolls to the offset for the given index.
         * @param {?} index The index of the element to scroll to.
         * @param {?=} behavior The ScrollBehavior to use when scrolling. Default is behavior is `auto`.
         * @return {?}
         */

      }, {
        key: "scrollToIndex",
        value: function scrollToIndex(index) {
          var behavior = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'auto';

          this._scrollStrategy.scrollToIndex(index, behavior);
        }
        /**
         * Gets the current scroll offset from the start of the viewport (in pixels).
         * @param {?=} from The edge to measure the offset from. Defaults to 'top' in vertical mode and 'start'
         *     in horizontal mode.
         * @return {?}
         */

      }, {
        key: "measureScrollOffset",
        value: function measureScrollOffset(from) {
          return _get(_getPrototypeOf(CdkVirtualScrollViewport.prototype), "measureScrollOffset", this).call(this, from ? from : this.orientation === 'horizontal' ? 'start' : 'top');
        }
        /**
         * Measure the combined size of all of the rendered items.
         * @return {?}
         */

      }, {
        key: "measureRenderedContentSize",
        value: function measureRenderedContentSize() {
          /** @type {?} */
          var contentEl = this._contentWrapper.nativeElement;
          return this.orientation === 'horizontal' ? contentEl.offsetWidth : contentEl.offsetHeight;
        }
        /**
         * Measure the total combined size of the given range. Throws if the range includes items that are
         * not rendered.
         * @param {?} range
         * @return {?}
         */

      }, {
        key: "measureRangeSize",
        value: function measureRangeSize(range) {
          if (!this._forOf) {
            return 0;
          }

          return this._forOf.measureRangeSize(range, this.orientation);
        }
        /**
         * Update the viewport dimensions and re-render.
         * @return {?}
         */

      }, {
        key: "checkViewportSize",
        value: function checkViewportSize() {
          // TODO: Cleanup later when add logic for handling content resize
          this._measureViewportSize();

          this._scrollStrategy.onDataLengthChanged();
        }
        /**
         * Measure the viewport size.
         * @private
         * @return {?}
         */

      }, {
        key: "_measureViewportSize",
        value: function _measureViewportSize() {
          /** @type {?} */
          var viewportEl = this.elementRef.nativeElement;
          this._viewportSize = this.orientation === 'horizontal' ? viewportEl.clientWidth : viewportEl.clientHeight;
        }
        /**
         * Queue up change detection to run.
         * @private
         * @param {?=} runAfter
         * @return {?}
         */

      }, {
        key: "_markChangeDetectionNeeded",
        value: function _markChangeDetectionNeeded(runAfter) {
          var _this47 = this;

          if (runAfter) {
            this._runAfterChangeDetection.push(runAfter);
          } // Use a Promise to batch together calls to `_doChangeDetection`. This way if we set a bunch of
          // properties sequentially we only have to run `_doChangeDetection` once at the end.


          if (!this._isChangeDetectionPending) {
            this._isChangeDetectionPending = true;
            this.ngZone.runOutsideAngular(
            /**
            * @return {?}
            */
            function () {
              return Promise.resolve().then(
              /**
              * @return {?}
              */
              function () {
                _this47._doChangeDetection();
              });
            });
          }
        }
        /**
         * Run change detection.
         * @private
         * @return {?}
         */

      }, {
        key: "_doChangeDetection",
        value: function _doChangeDetection() {
          var _this48 = this;

          this._isChangeDetectionPending = false; // Apply changes to Angular bindings. Note: We must call `markForCheck` to run change detection
          // from the root, since the repeated items are content projected in. Calling `detectChanges`
          // instead does not properly check the projected content.

          this.ngZone.run(
          /**
          * @return {?}
          */
          function () {
            return _this48._changeDetectorRef.markForCheck();
          }); // Apply the content transform. The transform can't be set via an Angular binding because
          // bypassSecurityTrustStyle is banned in Google. However the value is safe, it's composed of
          // string literals, a variable that can only be 'X' or 'Y', and user input that is run through
          // the `Number` function first to coerce it to a numeric value.

          this._contentWrapper.nativeElement.style.transform = this._renderedContentTransform;
          /** @type {?} */

          var runAfterChangeDetection = this._runAfterChangeDetection;
          this._runAfterChangeDetection = [];

          var _iterator2 = _createForOfIteratorHelper(runAfterChangeDetection),
              _step2;

          try {
            for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
              var fn = _step2.value;
              fn();
            }
          } catch (err) {
            _iterator2.e(err);
          } finally {
            _iterator2.f();
          }
        }
        /**
         * Calculates the `style.width` and `style.height` for the spacer element.
         * @private
         * @return {?}
         */

      }, {
        key: "_calculateSpacerSize",
        value: function _calculateSpacerSize() {
          this._totalContentHeight = this.orientation === 'horizontal' ? '' : "".concat(this._totalContentSize, "px");
          this._totalContentWidth = this.orientation === 'horizontal' ? "".concat(this._totalContentSize, "px") : '';
        }
      }, {
        key: "orientation",
        get: function get() {
          return this._orientation;
        }
        /**
         * @param {?} orientation
         * @return {?}
         */
        ,
        set: function set(orientation) {
          if (this._orientation !== orientation) {
            this._orientation = orientation;

            this._calculateSpacerSize();
          }
        }
      }]);

      return CdkVirtualScrollViewport;
    }(CdkScrollable);

    CdkVirtualScrollViewport.decorators = [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
      args: [{
        selector: 'cdk-virtual-scroll-viewport',
        template: "<div #contentWrapper class=\"cdk-virtual-scroll-content-wrapper\"><ng-content></ng-content></div><div class=\"cdk-virtual-scroll-spacer\" [style.width]=\"_totalContentWidth\" [style.height]=\"_totalContentHeight\"></div>",
        styles: ["cdk-virtual-scroll-viewport{display:block;position:relative;overflow:auto;contain:strict;transform:translateZ(0);will-change:scroll-position;-webkit-overflow-scrolling:touch}.cdk-virtual-scroll-content-wrapper{position:absolute;top:0;left:0;contain:content}[dir=rtl] .cdk-virtual-scroll-content-wrapper{right:0;left:auto}.cdk-virtual-scroll-orientation-horizontal .cdk-virtual-scroll-content-wrapper{min-height:100%}.cdk-virtual-scroll-orientation-horizontal .cdk-virtual-scroll-content-wrapper>dl:not([cdkVirtualFor]),.cdk-virtual-scroll-orientation-horizontal .cdk-virtual-scroll-content-wrapper>ol:not([cdkVirtualFor]),.cdk-virtual-scroll-orientation-horizontal .cdk-virtual-scroll-content-wrapper>table:not([cdkVirtualFor]),.cdk-virtual-scroll-orientation-horizontal .cdk-virtual-scroll-content-wrapper>ul:not([cdkVirtualFor]){padding-left:0;padding-right:0;margin-left:0;margin-right:0;border-left-width:0;border-right-width:0;outline:0}.cdk-virtual-scroll-orientation-vertical .cdk-virtual-scroll-content-wrapper{min-width:100%}.cdk-virtual-scroll-orientation-vertical .cdk-virtual-scroll-content-wrapper>dl:not([cdkVirtualFor]),.cdk-virtual-scroll-orientation-vertical .cdk-virtual-scroll-content-wrapper>ol:not([cdkVirtualFor]),.cdk-virtual-scroll-orientation-vertical .cdk-virtual-scroll-content-wrapper>table:not([cdkVirtualFor]),.cdk-virtual-scroll-orientation-vertical .cdk-virtual-scroll-content-wrapper>ul:not([cdkVirtualFor]){padding-top:0;padding-bottom:0;margin-top:0;margin-bottom:0;border-top-width:0;border-bottom-width:0;outline:0}.cdk-virtual-scroll-spacer{position:absolute;top:0;left:0;height:1px;width:1px;transform-origin:0 0}[dir=rtl] .cdk-virtual-scroll-spacer{right:0;left:auto;transform-origin:100% 0}"],
        host: {
          'class': 'cdk-virtual-scroll-viewport',
          '[class.cdk-virtual-scroll-orientation-horizontal]': 'orientation === "horizontal"',
          '[class.cdk-virtual-scroll-orientation-vertical]': 'orientation !== "horizontal"'
        },
        encapsulation: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewEncapsulation"].None,
        changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ChangeDetectionStrategy"].OnPush,
        providers: [{
          provide: CdkScrollable,
          useExisting: CdkVirtualScrollViewport
        }]
      }]
    }];
    /** @nocollapse */

    CdkVirtualScrollViewport.ctorParameters = function () {
      return [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"]
      }, {
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ChangeDetectorRef"]
      }, {
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgZone"]
      }, {
        type: undefined,
        decorators: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Optional"]
        }, {
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"],
          args: [VIRTUAL_SCROLL_STRATEGY]
        }]
      }, {
        type: _angular_cdk_bidi__WEBPACK_IMPORTED_MODULE_5__["Directionality"],
        decorators: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Optional"]
        }]
      }, {
        type: ScrollDispatcher
      }];
    };

    CdkVirtualScrollViewport.propDecorators = {
      orientation: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
      }],
      scrolledIndexChange: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"]
      }],
      _contentWrapper: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"],
        args: ['contentWrapper', {
          "static": true
        }]
      }]
    };
    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    /**
     * Helper to extract size from a DOM Node.
     * @param {?} orientation
     * @param {?} node
     * @return {?}
     */

    function getSize(orientation, node) {
      /** @type {?} */
      var el =
      /** @type {?} */
      node;

      if (!el.getBoundingClientRect) {
        return 0;
      }
      /** @type {?} */


      var rect = el.getBoundingClientRect();
      return orientation == 'horizontal' ? rect.width : rect.height;
    }
    /**
     * A directive similar to `ngForOf` to be used for rendering data inside a virtual scrolling
     * container.
     * @template T
     */


    var CdkVirtualForOf = /*#__PURE__*/function () {
      /**
       * @param {?} _viewContainerRef
       * @param {?} _template
       * @param {?} _differs
       * @param {?} _viewport
       * @param {?} ngZone
       */
      function CdkVirtualForOf(_viewContainerRef, _template, _differs, _viewport, ngZone) {
        var _this49 = this;

        _classCallCheck(this, CdkVirtualForOf);

        this._viewContainerRef = _viewContainerRef;
        this._template = _template;
        this._differs = _differs;
        this._viewport = _viewport;
        /**
         * Emits when the rendered view of the data changes.
         */

        this.viewChange = new rxjs__WEBPACK_IMPORTED_MODULE_2__["Subject"]();
        /**
         * Subject that emits when a new DataSource instance is given.
         */

        this._dataSourceChanges = new rxjs__WEBPACK_IMPORTED_MODULE_2__["Subject"]();
        /**
         * The size of the cache used to store templates that are not being used for re-use later.
         * Setting the cache size to `0` will disable caching. Defaults to 20 templates.
         */

        this.cdkVirtualForTemplateCacheSize = 20;
        /**
         * Emits whenever the data in the current DataSource changes.
         */

        this.dataStream = this._dataSourceChanges.pipe( // Start off with null `DataSource`.
        Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["startWith"])(
        /** @type {?} */
        null), // Bundle up the previous and current data sources so we can work with both.
        Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["pairwise"])(), // Use `_changeDataSource` to disconnect from the previous data source and connect to the
        // new one, passing back a stream of data changes which we run through `switchMap` to give
        // us a data stream that emits the latest data from whatever the current `DataSource` is.
        Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["switchMap"])(
        /**
        * @param {?} __0
        * @return {?}
        */
        function (_ref5) {
          var _ref6 = _slicedToArray(_ref5, 2),
              prev = _ref6[0],
              cur = _ref6[1];

          return _this49._changeDataSource(prev, cur);
        }), // Replay the last emitted data when someone subscribes.
        Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["shareReplay"])(1));
        /**
         * The differ used to calculate changes to the data.
         */

        this._differ = null;
        /**
         * The template cache used to hold on ot template instancess that have been stamped out, but don't
         * currently need to be rendered. These instances will be reused in the future rather than
         * stamping out brand new ones.
         */

        this._templateCache = [];
        /**
         * Whether the rendered data should be updated during the next ngDoCheck cycle.
         */

        this._needsUpdate = false;
        this._destroyed = new rxjs__WEBPACK_IMPORTED_MODULE_2__["Subject"]();
        this.dataStream.subscribe(
        /**
        * @param {?} data
        * @return {?}
        */
        function (data) {
          _this49._data = data;

          _this49._onRenderedDataChange();
        });

        this._viewport.renderedRangeStream.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["takeUntil"])(this._destroyed)).subscribe(
        /**
        * @param {?} range
        * @return {?}
        */
        function (range) {
          _this49._renderedRange = range;
          ngZone.run(
          /**
          * @return {?}
          */
          function () {
            return _this49.viewChange.next(_this49._renderedRange);
          });

          _this49._onRenderedDataChange();
        });

        this._viewport.attach(this);
      }
      /**
       * The DataSource to display.
       * @return {?}
       */


      _createClass(CdkVirtualForOf, [{
        key: "measureRangeSize",

        /**
         * Measures the combined size (width for horizontal orientation, height for vertical) of all items
         * in the specified range. Throws an error if the range includes items that are not currently
         * rendered.
         * @param {?} range
         * @param {?} orientation
         * @return {?}
         */
        value: function measureRangeSize(range, orientation) {
          if (range.start >= range.end) {
            return 0;
          }

          if (range.start < this._renderedRange.start || range.end > this._renderedRange.end) {
            throw Error("Error: attempted to measure an item that isn't rendered.");
          } // The index into the list of rendered views for the first item in the range.

          /** @type {?} */


          var renderedStartIndex = range.start - this._renderedRange.start; // The length of the range we're measuring.

          /** @type {?} */

          var rangeLen = range.end - range.start; // Loop over all root nodes for all items in the range and sum up their size.

          /** @type {?} */

          var totalSize = 0;
          /** @type {?} */

          var i = rangeLen;

          while (i--) {
            /** @type {?} */
            var view =
            /** @type {?} */
            this._viewContainerRef.get(i + renderedStartIndex);
            /** @type {?} */


            var j = view ? view.rootNodes.length : 0;

            while (j--) {
              totalSize += getSize(orientation,
              /** @type {?} */
              view.rootNodes[j]);
            }
          }

          return totalSize;
        }
        /**
         * @return {?}
         */

      }, {
        key: "ngDoCheck",
        value: function ngDoCheck() {
          if (this._differ && this._needsUpdate) {
            // TODO(mmalerba): We should differentiate needs update due to scrolling and a new portion of
            // this list being rendered (can use simpler algorithm) vs needs update due to data actually
            // changing (need to do this diff).

            /** @type {?} */
            var changes = this._differ.diff(this._renderedItems);

            if (!changes) {
              this._updateContext();
            } else {
              this._applyChanges(changes);
            }

            this._needsUpdate = false;
          }
        }
        /**
         * @return {?}
         */

      }, {
        key: "ngOnDestroy",
        value: function ngOnDestroy() {
          this._viewport.detach();

          this._dataSourceChanges.next();

          this._dataSourceChanges.complete();

          this.viewChange.complete();

          this._destroyed.next();

          this._destroyed.complete();

          var _iterator3 = _createForOfIteratorHelper(this._templateCache),
              _step3;

          try {
            for (_iterator3.s(); !(_step3 = _iterator3.n()).done;) {
              var view = _step3.value;
              view.destroy();
            }
          } catch (err) {
            _iterator3.e(err);
          } finally {
            _iterator3.f();
          }
        }
        /**
         * React to scroll state changes in the viewport.
         * @private
         * @return {?}
         */

      }, {
        key: "_onRenderedDataChange",
        value: function _onRenderedDataChange() {
          if (!this._renderedRange) {
            return;
          }

          this._renderedItems = this._data.slice(this._renderedRange.start, this._renderedRange.end);

          if (!this._differ) {
            this._differ = this._differs.find(this._renderedItems).create(this.cdkVirtualForTrackBy);
          }

          this._needsUpdate = true;
        }
        /**
         * Swap out one `DataSource` for another.
         * @private
         * @param {?} oldDs
         * @param {?} newDs
         * @return {?}
         */

      }, {
        key: "_changeDataSource",
        value: function _changeDataSource(oldDs, newDs) {
          if (oldDs) {
            oldDs.disconnect(this);
          }

          this._needsUpdate = true;
          return newDs ? newDs.connect(this) : Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["of"])();
        }
        /**
         * Update the `CdkVirtualForOfContext` for all views.
         * @private
         * @return {?}
         */

      }, {
        key: "_updateContext",
        value: function _updateContext() {
          /** @type {?} */
          var count = this._data.length;
          /** @type {?} */

          var i = this._viewContainerRef.length;

          while (i--) {
            /** @type {?} */
            var view =
            /** @type {?} */
            this._viewContainerRef.get(i);

            view.context.index = this._renderedRange.start + i;
            view.context.count = count;

            this._updateComputedContextProperties(view.context);

            view.detectChanges();
          }
        }
        /**
         * Apply changes to the DOM.
         * @private
         * @param {?} changes
         * @return {?}
         */

      }, {
        key: "_applyChanges",
        value: function _applyChanges(changes) {
          var _this50 = this;

          // Rearrange the views to put them in the right location.
          changes.forEachOperation(
          /**
          * @param {?} record
          * @param {?} adjustedPreviousIndex
          * @param {?} currentIndex
          * @return {?}
          */
          function (record, adjustedPreviousIndex, currentIndex) {
            if (record.previousIndex == null) {
              // Item added.
              // Item added.

              /** @type {?} */
              var view = _this50._insertViewForNewItem(
              /** @type {?} */
              currentIndex);

              view.context.$implicit = record.item;
            } else if (currentIndex == null) {
              // Item removed.
              _this50._cacheView(_this50._detachView(
              /** @type {?} */
              adjustedPreviousIndex));
            } else {
              // Item moved.
              // Item moved.

              /** @type {?} */
              var _view =
              /** @type {?} */
              _this50._viewContainerRef.get(
              /** @type {?} */
              adjustedPreviousIndex);

              _this50._viewContainerRef.move(_view, currentIndex);

              _view.context.$implicit = record.item;
            }
          }); // Update $implicit for any items that had an identity change.

          changes.forEachIdentityChange(
          /**
          * @param {?} record
          * @return {?}
          */
          function (record) {
            /** @type {?} */
            var view =
            /** @type {?} */
            _this50._viewContainerRef.get(
            /** @type {?} */
            record.currentIndex);

            view.context.$implicit = record.item;
          }); // Update the context variables on all items.

          /** @type {?} */

          var count = this._data.length;
          /** @type {?} */

          var i = this._viewContainerRef.length;

          while (i--) {
            /** @type {?} */
            var view =
            /** @type {?} */
            this._viewContainerRef.get(i);

            view.context.index = this._renderedRange.start + i;
            view.context.count = count;

            this._updateComputedContextProperties(view.context);
          }
        }
        /**
         * Cache the given detached view.
         * @private
         * @param {?} view
         * @return {?}
         */

      }, {
        key: "_cacheView",
        value: function _cacheView(view) {
          if (this._templateCache.length < this.cdkVirtualForTemplateCacheSize) {
            this._templateCache.push(view);
          } else {
            /** @type {?} */
            var index = this._viewContainerRef.indexOf(view); // It's very unlikely that the index will ever be -1, but just in case,
            // destroy the view on its own, otherwise destroy it through the
            // container to ensure that all the references are removed.


            if (index === -1) {
              view.destroy();
            } else {
              this._viewContainerRef.remove(index);
            }
          }
        }
        /**
         * Inserts a view for a new item, either from the cache or by creating a new one.
         * @private
         * @param {?} index
         * @return {?}
         */

      }, {
        key: "_insertViewForNewItem",
        value: function _insertViewForNewItem(index) {
          return this._insertViewFromCache(index) || this._createEmbeddedViewAt(index);
        }
        /**
         * Update the computed properties on the `CdkVirtualForOfContext`.
         * @private
         * @param {?} context
         * @return {?}
         */

      }, {
        key: "_updateComputedContextProperties",
        value: function _updateComputedContextProperties(context) {
          context.first = context.index === 0;
          context.last = context.index === context.count - 1;
          context.even = context.index % 2 === 0;
          context.odd = !context.even;
        }
        /**
         * Creates a new embedded view and moves it to the given index
         * @private
         * @param {?} index
         * @return {?}
         */

      }, {
        key: "_createEmbeddedViewAt",
        value: function _createEmbeddedViewAt(index) {
          // Note that it's important that we insert the item directly at the proper index,
          // rather than inserting it and the moving it in place, because if there's a directive
          // on the same node that injects the `ViewContainerRef`, Angular will insert another
          // comment node which can throw off the move when it's being repeated for all items.
          return this._viewContainerRef.createEmbeddedView(this._template, {
            $implicit:
            /** @type {?} */
            null,
            cdkVirtualForOf: this._cdkVirtualForOf,
            index: -1,
            count: -1,
            first: false,
            last: false,
            odd: false,
            even: false
          }, index);
        }
        /**
         * Inserts a recycled view from the cache at the given index.
         * @private
         * @param {?} index
         * @return {?}
         */

      }, {
        key: "_insertViewFromCache",
        value: function _insertViewFromCache(index) {
          /** @type {?} */
          var cachedView = this._templateCache.pop();

          if (cachedView) {
            this._viewContainerRef.insert(cachedView, index);
          }

          return cachedView || null;
        }
        /**
         * Detaches the embedded view at the given index.
         * @private
         * @param {?} index
         * @return {?}
         */

      }, {
        key: "_detachView",
        value: function _detachView(index) {
          return (
            /** @type {?} */
            this._viewContainerRef.detach(index)
          );
        }
      }, {
        key: "cdkVirtualForOf",
        get: function get() {
          return this._cdkVirtualForOf;
        }
        /**
         * @param {?} value
         * @return {?}
         */
        ,
        set: function set(value) {
          this._cdkVirtualForOf = value;
          /** @type {?} */

          var ds = Object(_angular_cdk_collections__WEBPACK_IMPORTED_MODULE_6__["isDataSource"])(value) ? value : // Slice the value if its an NgIterable to ensure we're working with an array.
          new _angular_cdk_collections__WEBPACK_IMPORTED_MODULE_6__["ArrayDataSource"](value instanceof rxjs__WEBPACK_IMPORTED_MODULE_2__["Observable"] ? value : Array.prototype.slice.call(value || []));

          this._dataSourceChanges.next(ds);
        }
        /**
         * The `TrackByFunction` to use for tracking changes. The `TrackByFunction` takes the index and
         * the item and produces a value to be used as the item's identity when tracking changes.
         * @return {?}
         */

      }, {
        key: "cdkVirtualForTrackBy",
        get: function get() {
          return this._cdkVirtualForTrackBy;
        }
        /**
         * @param {?} fn
         * @return {?}
         */
        ,
        set: function set(fn) {
          var _this51 = this;

          this._needsUpdate = true;
          this._cdkVirtualForTrackBy = fn ?
          /**
          * @param {?} index
          * @param {?} item
          * @return {?}
          */
          function (index, item) {
            return fn(index + (_this51._renderedRange ? _this51._renderedRange.start : 0), item);
          } : undefined;
        }
        /**
         * The template used to stamp out new elements.
         * @param {?} value
         * @return {?}
         */

      }, {
        key: "cdkVirtualForTemplate",
        set: function set(value) {
          if (value) {
            this._needsUpdate = true;
            this._template = value;
          }
        }
      }]);

      return CdkVirtualForOf;
    }();

    CdkVirtualForOf.decorators = [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Directive"],
      args: [{
        selector: '[cdkVirtualFor][cdkVirtualForOf]'
      }]
    }];
    /** @nocollapse */

    CdkVirtualForOf.ctorParameters = function () {
      return [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewContainerRef"]
      }, {
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"]
      }, {
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["IterableDiffers"]
      }, {
        type: CdkVirtualScrollViewport,
        decorators: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["SkipSelf"]
        }]
      }, {
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgZone"]
      }];
    };

    CdkVirtualForOf.propDecorators = {
      cdkVirtualForOf: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
      }],
      cdkVirtualForTrackBy: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
      }],
      cdkVirtualForTemplate: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
      }],
      cdkVirtualForTemplateCacheSize: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
      }]
    };
    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    var ScrollingModule = function ScrollingModule() {
      _classCallCheck(this, ScrollingModule);
    };

    ScrollingModule.decorators = [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"],
      args: [{
        imports: [_angular_cdk_bidi__WEBPACK_IMPORTED_MODULE_5__["BidiModule"], _angular_cdk_platform__WEBPACK_IMPORTED_MODULE_4__["PlatformModule"]],
        exports: [_angular_cdk_bidi__WEBPACK_IMPORTED_MODULE_5__["BidiModule"], CdkFixedSizeVirtualScroll, CdkScrollable, CdkVirtualForOf, CdkVirtualScrollViewport],
        declarations: [CdkFixedSizeVirtualScroll, CdkScrollable, CdkVirtualForOf, CdkVirtualScrollViewport]
      }]
    }];
    /**
     * @deprecated ScrollDispatchModule has been renamed to ScrollingModule.
     * \@breaking-change 8.0.0 delete this alias
     */

    var ScrollDispatchModule = function ScrollDispatchModule() {
      _classCallCheck(this, ScrollDispatchModule);
    };

    ScrollDispatchModule.decorators = [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"],
      args: [{
        imports: [ScrollingModule],
        exports: [ScrollingModule]
      }]
    }];
    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    /**
     * Time in ms to throttle the resize events by default.
     * @type {?}
     */

    var DEFAULT_RESIZE_TIME = 20;
    /**
     * Simple utility for getting the bounds of the browser viewport.
     * \@docs-private
     */

    var ViewportRuler = /*#__PURE__*/function () {
      /**
       * @param {?} _platform
       * @param {?} ngZone
       */
      function ViewportRuler(_platform, ngZone) {
        var _this52 = this;

        _classCallCheck(this, ViewportRuler);

        this._platform = _platform;
        ngZone.runOutsideAngular(
        /**
        * @return {?}
        */
        function () {
          _this52._change = _platform.isBrowser ? Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["merge"])(Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["fromEvent"])(window, 'resize'), Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["fromEvent"])(window, 'orientationchange')) : Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["of"])(); // Note that we need to do the subscription inside `runOutsideAngular`
          // since subscribing is what causes the event listener to be added.

          _this52._invalidateCache = _this52.change().subscribe(
          /**
          * @return {?}
          */
          function () {
            return _this52._updateViewportSize();
          });
        });
      }
      /**
       * @return {?}
       */


      _createClass(ViewportRuler, [{
        key: "ngOnDestroy",
        value: function ngOnDestroy() {
          this._invalidateCache.unsubscribe();
        }
        /**
         * Returns the viewport's width and height.
         * @return {?}
         */

      }, {
        key: "getViewportSize",
        value: function getViewportSize() {
          if (!this._viewportSize) {
            this._updateViewportSize();
          }
          /** @type {?} */


          var output = {
            width: this._viewportSize.width,
            height: this._viewportSize.height
          }; // If we're not on a browser, don't cache the size since it'll be mocked out anyway.

          if (!this._platform.isBrowser) {
            this._viewportSize =
            /** @type {?} */
            null;
          }

          return output;
        }
        /**
         * Gets a ClientRect for the viewport's bounds.
         * @return {?}
         */

      }, {
        key: "getViewportRect",
        value: function getViewportRect() {
          // Use the document element's bounding rect rather than the window scroll properties
          // (e.g. pageYOffset, scrollY) due to in issue in Chrome and IE where window scroll
          // properties and client coordinates (boundingClientRect, clientX/Y, etc.) are in different
          // conceptual viewports. Under most circumstances these viewports are equivalent, but they
          // can disagree when the page is pinch-zoomed (on devices that support touch).
          // See https://bugs.chromium.org/p/chromium/issues/detail?id=489206#c4
          // We use the documentElement instead of the body because, by default (without a css reset)
          // browsers typically give the document body an 8px margin, which is not included in
          // getBoundingClientRect().

          /** @type {?} */
          var scrollPosition = this.getViewportScrollPosition();

          var _this$getViewportSize = this.getViewportSize(),
              width = _this$getViewportSize.width,
              height = _this$getViewportSize.height;

          return {
            top: scrollPosition.top,
            left: scrollPosition.left,
            bottom: scrollPosition.top + height,
            right: scrollPosition.left + width,
            height: height,
            width: width
          };
        }
        /**
         * Gets the (top, left) scroll position of the viewport.
         * @return {?}
         */

      }, {
        key: "getViewportScrollPosition",
        value: function getViewportScrollPosition() {
          // While we can get a reference to the fake document
          // during SSR, it doesn't have getBoundingClientRect.
          if (!this._platform.isBrowser) {
            return {
              top: 0,
              left: 0
            };
          } // The top-left-corner of the viewport is determined by the scroll position of the document
          // body, normally just (scrollLeft, scrollTop). However, Chrome and Firefox disagree about
          // whether `document.body` or `document.documentElement` is the scrolled element, so reading
          // `scrollTop` and `scrollLeft` is inconsistent. However, using the bounding rect of
          // `document.documentElement` works consistently, where the `top` and `left` values will
          // equal negative the scroll position.

          /** @type {?} */


          var documentElement =
          /** @type {?} */
          document.documentElement;
          /** @type {?} */

          var documentRect = documentElement.getBoundingClientRect();
          /** @type {?} */

          var top = -documentRect.top || document.body.scrollTop || window.scrollY || documentElement.scrollTop || 0;
          /** @type {?} */

          var left = -documentRect.left || document.body.scrollLeft || window.scrollX || documentElement.scrollLeft || 0;
          return {
            top: top,
            left: left
          };
        }
        /**
         * Returns a stream that emits whenever the size of the viewport changes.
         * @param {?=} throttleTime Time in milliseconds to throttle the stream.
         * @return {?}
         */

      }, {
        key: "change",
        value: function change() {
          var throttleTime = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : DEFAULT_RESIZE_TIME;
          return throttleTime > 0 ? this._change.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["auditTime"])(throttleTime)) : this._change;
        }
        /**
         * Updates the cached viewport size.
         * @private
         * @return {?}
         */

      }, {
        key: "_updateViewportSize",
        value: function _updateViewportSize() {
          this._viewportSize = this._platform.isBrowser ? {
            width: window.innerWidth,
            height: window.innerHeight
          } : {
            width: 0,
            height: 0
          };
        }
      }]);

      return ViewportRuler;
    }();

    ViewportRuler.decorators = [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"],
      args: [{
        providedIn: 'root'
      }]
    }];
    /** @nocollapse */

    ViewportRuler.ctorParameters = function () {
      return [{
        type: _angular_cdk_platform__WEBPACK_IMPORTED_MODULE_4__["Platform"]
      }, {
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgZone"]
      }];
    };
    /** @nocollapse */


    ViewportRuler.ngInjectableDef = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"])({
      factory: function ViewportRuler_Factory() {
        return new ViewportRuler(Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"])(_angular_cdk_platform__WEBPACK_IMPORTED_MODULE_4__["Platform"]), Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"])(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgZone"]));
      },
      token: ViewportRuler,
      providedIn: "root"
    });
    /**
     * \@docs-private \@deprecated \@breaking-change 8.0.0
     * @param {?} parentRuler
     * @param {?} platform
     * @param {?} ngZone
     * @return {?}
     */

    function VIEWPORT_RULER_PROVIDER_FACTORY(parentRuler, platform, ngZone) {
      return parentRuler || new ViewportRuler(platform, ngZone);
    }
    /**
     * \@docs-private \@deprecated \@breaking-change 8.0.0
     * @type {?}
     */


    var VIEWPORT_RULER_PROVIDER = {
      // If there is already a ViewportRuler available, use that. Otherwise, provide a new one.
      provide: ViewportRuler,
      deps: [[new _angular_core__WEBPACK_IMPORTED_MODULE_0__["Optional"](), new _angular_core__WEBPACK_IMPORTED_MODULE_0__["SkipSelf"](), ViewportRuler], _angular_cdk_platform__WEBPACK_IMPORTED_MODULE_4__["Platform"], _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgZone"]],
      useFactory: VIEWPORT_RULER_PROVIDER_FACTORY
    };
    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    //# sourceMappingURL=scrolling.js.map

    /***/
  },

  /***/
  "./node_modules/@ionic-native/camera-preview/ngx/index.js":
  /*!****************************************************************!*\
    !*** ./node_modules/@ionic-native/camera-preview/ngx/index.js ***!
    \****************************************************************/

  /*! exports provided: CameraPreview */

  /***/
  function node_modulesIonicNativeCameraPreviewNgxIndexJs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CameraPreview", function () {
      return CameraPreview;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _ionic_native_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic-native/core */
    "./node_modules/@ionic-native/core/index.js");

    var CameraPreview =
    /** @class */
    function (_super) {
      Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(CameraPreview, _super);

      function CameraPreview() {
        var _this = _super !== null && _super.apply(this, arguments) || this;

        _this.FOCUS_MODE = {
          FIXED: 'fixed',
          AUTO: 'auto',
          CONTINUOUS: 'continuous',
          CONTINUOUS_PICTURE: 'continuous-picture',
          CONTINUOUS_VIDEO: 'continuous-video',
          EDOF: 'edof',
          INFINITY: 'infinity',
          MACRO: 'macro'
        };
        _this.EXPOSURE_MODE = {
          LOCK: 'lock',
          AUTO: 'auto',
          CONTINUOUS: 'continuous',
          CUSTOM: 'custom'
        };
        _this.FLASH_MODE = {
          OFF: 'off',
          ON: 'on',
          AUTO: 'auto',
          RED_EYE: 'red-eye',
          TORCH: 'torch'
        };
        _this.COLOR_EFFECT = {
          AQUA: 'aqua',
          BLACKBOARD: 'blackboard',
          MONO: 'mono',
          NEGATIVE: 'negative',
          NONE: 'none',
          POSTERIZE: 'posterize',
          SEPIA: 'sepia',
          SOLARIZE: 'solarize',
          WHITEBOARD: 'whiteboard'
        };
        _this.CAMERA_DIRECTION = {
          BACK: 'back',
          FRONT: 'front'
        };
        return _this;
      }

      CameraPreview.prototype.startCamera = function (options) {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "startCamera", {
          "successIndex": 1,
          "errorIndex": 2
        }, arguments);
      };

      CameraPreview.prototype.startRecordVideo = function (options) {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "startRecordVideo", {
          "successIndex": 1,
          "errorIndex": 2
        }, arguments);
      };

      CameraPreview.prototype.stopCamera = function () {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "stopCamera", {}, arguments);
      };

      CameraPreview.prototype.stopRecordVideo = function () {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "stopRecordVideo", {}, arguments);
      };

      CameraPreview.prototype.switchCamera = function () {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "switchCamera", {}, arguments);
      };

      CameraPreview.prototype.hide = function () {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "hide", {}, arguments);
      };

      CameraPreview.prototype.show = function () {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "show", {}, arguments);
      };

      CameraPreview.prototype.takePicture = function (options) {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "takePicture", {
          "successIndex": 1,
          "errorIndex": 2
        }, arguments);
      };

      CameraPreview.prototype.takeSnapshot = function (options) {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "takeSnapshot", {
          "successIndex": 1,
          "errorIndex": 2
        }, arguments);
      };

      CameraPreview.prototype.setColorEffect = function (effect) {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "setColorEffect", {
          "successIndex": 1,
          "errorIndex": 2
        }, arguments);
      };

      CameraPreview.prototype.setZoom = function (zoom) {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "setZoom", {
          "successIndex": 1,
          "errorIndex": 2
        }, arguments);
      };

      CameraPreview.prototype.getMaxZoom = function () {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "getMaxZoom", {}, arguments);
      };

      CameraPreview.prototype.getZoom = function () {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "getZoom", {}, arguments);
      };

      CameraPreview.prototype.setPreviewSize = function (dimensions) {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "setPreviewSize", {
          "successIndex": 1,
          "errorIndex": 2
        }, arguments);
      };

      CameraPreview.prototype.getFocusMode = function () {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "getFocusMode", {}, arguments);
      };

      CameraPreview.prototype.setFocusMode = function (focusMode) {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "setFocusMode", {
          "successIndex": 1,
          "errorIndex": 2
        }, arguments);
      };

      CameraPreview.prototype.getSupportedFocusModes = function () {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "getSupportedFocusModes", {}, arguments);
      };

      CameraPreview.prototype.getFlashMode = function () {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "getFlashMode", {}, arguments);
      };

      CameraPreview.prototype.setFlashMode = function (flashMode) {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "setFlashMode", {
          "successIndex": 1,
          "errorIndex": 2
        }, arguments);
      };

      CameraPreview.prototype.getSupportedFlashModes = function () {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "getSupportedFlashModes", {}, arguments);
      };

      CameraPreview.prototype.getSupportedPictureSizes = function () {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "getSupportedPictureSizes", {}, arguments);
      };

      CameraPreview.prototype.getExposureMode = function () {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "getExposureMode", {}, arguments);
      };

      CameraPreview.prototype.getExposureModes = function () {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "getExposureModes", {}, arguments);
      };

      CameraPreview.prototype.setExposureMode = function (lock) {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "setExposureMode", {
          "successIndex": 1,
          "errorIndex": 2
        }, arguments);
      };

      CameraPreview.prototype.getExposureCompensation = function () {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "getExposureCompensation", {}, arguments);
      };

      CameraPreview.prototype.setExposureCompensation = function (exposureCompensation) {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "setExposureCompensation", {
          "successIndex": 1,
          "errorIndex": 2
        }, arguments);
      };

      CameraPreview.prototype.getExposureCompensationRange = function () {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "getExposureCompensationRange", {}, arguments);
      };

      CameraPreview.prototype.tapToFocus = function (xPoint, yPoint) {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "tapToFocus", {}, arguments);
      };

      CameraPreview.prototype.onBackButton = function () {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "onBackButton", {}, arguments);
      };

      CameraPreview.prototype.getHorizontalFOV = function () {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "getHorizontalFOV", {}, arguments);
      };

      CameraPreview.prototype.getCameraCharacteristics = function () {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "getCameraCharacteristics", {}, arguments);
      };

      CameraPreview.pluginName = "CameraPreview";
      CameraPreview.plugin = "cordova-plugin-camera-preview";
      CameraPreview.pluginRef = "CameraPreview";
      CameraPreview.repo = "https://github.com/cordova-plugin-camera-preview/cordova-plugin-camera-preview";
      CameraPreview.platforms = ["Android", "iOS"];
      CameraPreview = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])()], CameraPreview);
      return CameraPreview;
    }(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["IonicNativePlugin"]); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvQGlvbmljLW5hdGl2ZS9wbHVnaW5zL2NhbWVyYS1wcmV2aWV3L25neC9pbmRleC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUMzQyxPQUFPLDhCQUFzQyxNQUFNLG9CQUFvQixDQUFDOztJQW1KckMsaUNBQWlCOzs7UUFDbEQsZ0JBQVUsR0FBRztZQUNYLEtBQUssRUFBRSxPQUFPO1lBQ2QsSUFBSSxFQUFFLE1BQU07WUFDWixVQUFVLEVBQUUsWUFBWTtZQUN4QixrQkFBa0IsRUFBRSxvQkFBb0I7WUFDeEMsZ0JBQWdCLEVBQUUsa0JBQWtCO1lBQ3BDLElBQUksRUFBRSxNQUFNO1lBQ1osUUFBUSxFQUFFLFVBQVU7WUFDcEIsS0FBSyxFQUFFLE9BQU87U0FDZixDQUFDO1FBRUYsbUJBQWEsR0FBRztZQUNkLElBQUksRUFBRSxNQUFNO1lBQ1osSUFBSSxFQUFFLE1BQU07WUFDWixVQUFVLEVBQUUsWUFBWTtZQUN4QixNQUFNLEVBQUUsUUFBUTtTQUNqQixDQUFDO1FBRUYsZ0JBQVUsR0FBRztZQUNYLEdBQUcsRUFBRSxLQUFLO1lBQ1YsRUFBRSxFQUFFLElBQUk7WUFDUixJQUFJLEVBQUUsTUFBTTtZQUNaLE9BQU8sRUFBRSxTQUFTO1lBQ2xCLEtBQUssRUFBRSxPQUFPO1NBQ2YsQ0FBQztRQUVGLGtCQUFZLEdBQUc7WUFDYixJQUFJLEVBQUUsTUFBTTtZQUNaLFVBQVUsRUFBRSxZQUFZO1lBQ3hCLElBQUksRUFBRSxNQUFNO1lBQ1osUUFBUSxFQUFFLFVBQVU7WUFDcEIsSUFBSSxFQUFFLE1BQU07WUFDWixTQUFTLEVBQUUsV0FBVztZQUN0QixLQUFLLEVBQUUsT0FBTztZQUNkLFFBQVEsRUFBRSxVQUFVO1lBQ3BCLFVBQVUsRUFBRSxZQUFZO1NBQ3pCLENBQUM7UUFFRixzQkFBZ0IsR0FBRztZQUNqQixJQUFJLEVBQUUsTUFBTTtZQUNaLEtBQUssRUFBRSxPQUFPO1NBQ2YsQ0FBQzs7O0lBV0YsbUNBQVcsYUFBQyxPQUE2QjtJQWF6Qyx3Q0FBZ0IsYUFBQyxPQUFZO0lBVTdCLGtDQUFVO0lBU1YsdUNBQWU7SUFTZixvQ0FBWTtJQVNaLDRCQUFJO0lBU0osNEJBQUk7SUFhSixtQ0FBVyxhQUFDLE9BQXFDO0lBYWpELG9DQUFZLGFBQUMsT0FBcUM7SUFlbEQsc0NBQWMsYUFBQyxNQUFjO0lBYTdCLCtCQUFPLGFBQUMsSUFBYTtJQVNyQixrQ0FBVTtJQVNWLCtCQUFPO0lBYVAsc0NBQWMsYUFBQyxVQUFvQztJQVNuRCxvQ0FBWTtJQWFaLG9DQUFZLGFBQUMsU0FBa0I7SUFTL0IsOENBQXNCO0lBU3RCLG9DQUFZO0lBYVosb0NBQVksYUFBQyxTQUFrQjtJQVMvQiw4Q0FBc0I7SUFTdEIsZ0RBQXdCO0lBU3hCLHVDQUFlO0lBU2Ysd0NBQWdCO0lBYWhCLHVDQUFlLGFBQUMsSUFBYTtJQVM3QiwrQ0FBdUI7SUFhdkIsK0NBQXVCLGFBQUMsb0JBQTZCO0lBU3JELG9EQUE0QjtJQVc1QixrQ0FBVSxhQUFDLE1BQWMsRUFBRSxNQUFjO0lBU3pDLG9DQUFZO0lBU1osd0NBQWdCO0lBU2hCLGdEQUF3Qjs7Ozs7O0lBaFhiLGFBQWE7UUFEekIsVUFBVSxFQUFFO09BQ0EsYUFBYTt3QkFwSjFCO0VBb0ptQyxpQkFBaUI7U0FBdkMsYUFBYSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IENvcmRvdmEsIElvbmljTmF0aXZlUGx1Z2luLCBQbHVnaW4gfSBmcm9tICdAaW9uaWMtbmF0aXZlL2NvcmUnO1xuXG5leHBvcnQgaW50ZXJmYWNlIENhbWVyYVByZXZpZXdEaW1lbnNpb25zIHtcbiAgLyoqIFRoZSB3aWR0aCBvZiB0aGUgY2FtZXJhIHByZXZpZXcsIGRlZmF1bHQgdG8gd2luZG93LnNjcmVlbi53aWR0aCAqL1xuICB3aWR0aD86IG51bWJlcjtcblxuICAvKiogVGhlIGhlaWdodCBvZiB0aGUgY2FtZXJhIHByZXZpZXcsIGRlZmF1bHQgdG8gd2luZG93LnNjcmVlbi5oZWlnaHQgKi9cbiAgaGVpZ2h0PzogbnVtYmVyO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIENhbWVyYVByZXZpZXdPcHRpb25zIHtcbiAgLyoqIFRoZSBsZWZ0IGVkZ2UgaW4gcGl4ZWxzLCBkZWZhdWx0IDAgKi9cbiAgeD86IG51bWJlcjtcblxuICAvKiogVGhlIHRvcCBlZGdlIGluIHBpeGVscywgZGVmYXVsdCAwICovXG4gIHk/OiBudW1iZXI7XG5cbiAgLyoqIFRoZSB3aWR0aCBpbiBwaXhlbHMsIGRlZmF1bHQgd2luZG93LnNjcmVlbi53aWR0aCAqL1xuICB3aWR0aD86IG51bWJlcjtcblxuICAvKiogVGhlIGhlaWdodCBpbiBwaXhlbHMsIGRlZmF1bHQgd2luZG93LnNjcmVlbi5oZWlnaHQgKi9cbiAgaGVpZ2h0PzogbnVtYmVyO1xuXG4gIC8qKiBDaG9vc2UgdGhlIGNhbWVyYSB0byB1c2UgJ2Zyb250JyBvciAncmVhcicsIGRlZmF1bHQgJ2Zyb250JyAqL1xuICBjYW1lcmE/OiBzdHJpbmc7XG5cbiAgLyoqIFRhcCB0byB0YWtlIGEgcGhvdG8sIGRlZmF1bHQgdHJ1ZSAocGljdHVyZSBxdWFsaXR5IGJ5IGRlZmF1bHQgOiA4NSkgKi9cbiAgdGFwUGhvdG8/OiBib29sZWFuO1xuXG4gIC8qKiBQcmV2aWV3IGJveCBkcmFnIGFjcm9zcyB0aGUgc2NyZWVuLCBkZWZhdWx0ICdmYWxzZScgKi9cbiAgcHJldmlld0RyYWc/OiBib29sZWFuO1xuXG4gIC8qKiBQcmV2aWV3IGJveCB0byB0aGUgYmFjayBvZiB0aGUgd2VidmlldyAodHJ1ZSA9PiBiYWNrLCBmYWxzZSA9PiBmcm9udCkgLCBkZWZhdWx0IGZhbHNlICovXG4gIHRvQmFjaz86IGJvb2xlYW47XG5cbiAgLyoqIEFscGhhIGNoYW5uZWwgb2YgdGhlIHByZXZpZXcgYm94LCBmbG9hdCwgWzAsMV0sIGRlZmF1bHQgMSAqL1xuICBhbHBoYT86IG51bWJlcjtcblxuICAvKiogVGFwIHRvIHNldCBzcGVjaWZpYyBmb2N1cyBwb2ludC4gTm90ZSwgdGhpcyBhc3N1bWVzIHRoZSBjYW1lcmEgaXMgZnVsbC1zY3JlZW4uIGRlZmF1bHQgZmFsc2UgKi9cbiAgdGFwRm9jdXM/OiBib29sZWFuO1xuXG4gIC8qKiBPbiBBbmRyb2lkIGRpc2FibGUgYXV0b21hdGljIHJvdGF0aW9uIG9mIHRoZSBpbWFnZSBhbmQgc3RyaXBwaW5nIG9mIEV4aXQgaGVhZGVyLiBkZWZhdWx0IGZhbHNlICovXG4gIGRpc2FibGVFeGlmSGVhZGVyU3RyaXBwaW5nPzogYm9vbGVhbjtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBDYW1lcmFQcmV2aWV3UGljdHVyZU9wdGlvbnMge1xuICAvKiogVGhlIHdpZHRoIGluIHBpeGVscywgZGVmYXVsdCAwICovXG4gIHdpZHRoPzogbnVtYmVyO1xuICAvKiogVGhlIGhlaWdodCBpbiBwaXhlbHMsIGRlZmF1bHQgMCAqL1xuICBoZWlnaHQ/OiBudW1iZXI7XG4gIC8qKiBUaGUgcGljdHVyZSBxdWFsaXR5LCAwIC0gMTAwLCBkZWZhdWx0IDg1ICovXG4gIHF1YWxpdHk/OiBudW1iZXI7XG59XG5cbi8qKlxuICogQGJldGFcbiAqIEBuYW1lIENhbWVyYSBQcmV2aWV3XG4gKiBAZGVzY3JpcHRpb25cbiAqIFNob3dpbmcgY2FtZXJhIHByZXZpZXcgaW4gSFRNTFxuICpcbiAqIFJlcXVpcmVzIENvcmRvdmEgcGx1Z2luOiBgaHR0cHM6Ly9naXRodWIuY29tL2NvcmRvdmEtcGx1Z2luLWNhbWVyYS1wcmV2aWV3L2NvcmRvdmEtcGx1Z2luLWNhbWVyYS1wcmV2aWV3LmdpdGAuIEZvciBtb3JlIGluZm8sIHBsZWFzZSBzZWUgdGhlIFtDb3Jkb3ZhIENhbWVyYSBQcmV2aWV3IGRvY3NdKGh0dHBzOi8vZ2l0aHViLmNvbS9jb3Jkb3ZhLXBsdWdpbi1jYW1lcmEtcHJldmlldy9jb3Jkb3ZhLXBsdWdpbi1jYW1lcmEtcHJldmlldykuXG4gKlxuICogQHVzYWdlXG4gKiBgYGB0eXBlc2NyaXB0XG4gKiBpbXBvcnQgeyBDYW1lcmFQcmV2aWV3LCBDYW1lcmFQcmV2aWV3UGljdHVyZU9wdGlvbnMsIENhbWVyYVByZXZpZXdPcHRpb25zLCBDYW1lcmFQcmV2aWV3RGltZW5zaW9ucyB9IGZyb20gJ0Bpb25pYy1uYXRpdmUvY2FtZXJhLXByZXZpZXcvbmd4JztcbiAqXG4gKiBjb25zdHJ1Y3Rvcihwcml2YXRlIGNhbWVyYVByZXZpZXc6IENhbWVyYVByZXZpZXcpIHsgfVxuICpcbiAqIC4uLlxuICpcbiAqIC8vIGNhbWVyYSBvcHRpb25zIChTaXplIGFuZCBsb2NhdGlvbikuIEluIHRoZSBmb2xsb3dpbmcgZXhhbXBsZSwgdGhlIHByZXZpZXcgdXNlcyB0aGUgcmVhciBjYW1lcmEgYW5kIGRpc3BsYXkgdGhlIHByZXZpZXcgaW4gdGhlIGJhY2sgb2YgdGhlIHdlYnZpZXdcbiAqIGNvbnN0IGNhbWVyYVByZXZpZXdPcHRzOiBDYW1lcmFQcmV2aWV3T3B0aW9ucyA9IHtcbiAqICAgeDogMCxcbiAqICAgeTogMCxcbiAqICAgd2lkdGg6IHdpbmRvdy5zY3JlZW4ud2lkdGgsXG4gKiAgIGhlaWdodDogd2luZG93LnNjcmVlbi5oZWlnaHQsXG4gKiAgIGNhbWVyYTogJ3JlYXInLFxuICogICB0YXBQaG90bzogdHJ1ZSxcbiAqICAgcHJldmlld0RyYWc6IHRydWUsXG4gKiAgIHRvQmFjazogdHJ1ZSxcbiAqICAgYWxwaGE6IDFcbiAqIH1cbiAqXG4gKiAvLyBzdGFydCBjYW1lcmFcbiAqIHRoaXMuY2FtZXJhUHJldmlldy5zdGFydENhbWVyYShjYW1lcmFQcmV2aWV3T3B0cykudGhlbihcbiAqICAgKHJlcykgPT4ge1xuICogICAgIGNvbnNvbGUubG9nKHJlcylcbiAqICAgfSxcbiAqICAgKGVycikgPT4ge1xuICogICAgIGNvbnNvbGUubG9nKGVycilcbiAqICAgfSk7XG4gKlxuICogLy8gU2V0IHRoZSBoYW5kbGVyIHRvIHJ1biBldmVyeSB0aW1lIHdlIHRha2UgYSBwaWN0dXJlXG4gKiB0aGlzLmNhbWVyYVByZXZpZXcuc2V0T25QaWN0dXJlVGFrZW5IYW5kbGVyKCkuc3Vic2NyaWJlKChyZXN1bHQpID0+IHtcbiAqICAgY29uc29sZS5sb2cocmVzdWx0KTtcbiAqICAgLy8gZG8gc29tZXRoaW5nIHdpdGggdGhlIHJlc3VsdFxuICogfSk7XG4gKlxuICpcbiAqIC8vIHBpY3R1cmUgb3B0aW9uc1xuICogY29uc3QgcGljdHVyZU9wdHM6IENhbWVyYVByZXZpZXdQaWN0dXJlT3B0aW9ucyA9IHtcbiAqICAgd2lkdGg6IDEyODAsXG4gKiAgIGhlaWdodDogMTI4MCxcbiAqICAgcXVhbGl0eTogODVcbiAqIH1cbiAqXG4gKiAvLyB0YWtlIGEgcGljdHVyZVxuICogdGhpcy5jYW1lcmFQcmV2aWV3LnRha2VQaWN0dXJlKHRoaXMucGljdHVyZU9wdHMpLnRoZW4oKGltYWdlRGF0YSkgPT4ge1xuICogICB0aGlzLnBpY3R1cmUgPSAnZGF0YTppbWFnZS9qcGVnO2Jhc2U2NCwnICsgaW1hZ2VEYXRhO1xuICogfSwgKGVycikgPT4ge1xuICogICBjb25zb2xlLmxvZyhlcnIpO1xuICogICB0aGlzLnBpY3R1cmUgPSAnYXNzZXRzL2ltZy90ZXN0LmpwZyc7XG4gKiB9KTtcbiAqXG4gKiAvLyB0YWtlIGEgc25hcCBzaG90XG4gKiB0aGlzLmNhbWVyYVByZXZpZXcudGFrZVNuYXBzaG90KHRoaXMucGljdHVyZU9wdHMpLnRoZW4oKGltYWdlRGF0YSkgPT4ge1xuICogICB0aGlzLnBpY3R1cmUgPSAnZGF0YTppbWFnZS9qcGVnO2Jhc2U2NCwnICsgaW1hZ2VEYXRhO1xuICogfSwgKGVycikgPT4ge1xuICogICBjb25zb2xlLmxvZyhlcnIpO1xuICogICB0aGlzLnBpY3R1cmUgPSAnYXNzZXRzL2ltZy90ZXN0LmpwZyc7XG4gKiB9KTtcbiAqXG4gKlxuICogLy8gU3dpdGNoIGNhbWVyYVxuICogdGhpcy5jYW1lcmFQcmV2aWV3LnN3aXRjaENhbWVyYSgpO1xuICpcbiAqIC8vIHNldCBjb2xvciBlZmZlY3QgdG8gbmVnYXRpdmVcbiAqIHRoaXMuY2FtZXJhUHJldmlldy5zZXRDb2xvckVmZmVjdCgnbmVnYXRpdmUnKTtcbiAqXG4gKiAvLyBTdG9wIHRoZSBjYW1lcmEgcHJldmlld1xuICogdGhpcy5jYW1lcmFQcmV2aWV3LnN0b3BDYW1lcmEoKTtcbiAqXG4gKiBgYGBcbiAqXG4gKiBAaW50ZXJmYWNlc1xuICogQ2FtZXJhUHJldmlld09wdGlvbnNcbiAqIENhbWVyYVByZXZpZXdQaWN0dXJlT3B0aW9uc1xuICogQ2FtZXJhUHJldmlld0RpbWVuc2lvbnNcbiAqL1xuQFBsdWdpbih7XG4gIHBsdWdpbk5hbWU6ICdDYW1lcmFQcmV2aWV3JyxcbiAgcGx1Z2luOiAnY29yZG92YS1wbHVnaW4tY2FtZXJhLXByZXZpZXcnLFxuICBwbHVnaW5SZWY6ICdDYW1lcmFQcmV2aWV3JyxcbiAgcmVwbzogJ2h0dHBzOi8vZ2l0aHViLmNvbS9jb3Jkb3ZhLXBsdWdpbi1jYW1lcmEtcHJldmlldy9jb3Jkb3ZhLXBsdWdpbi1jYW1lcmEtcHJldmlldycsXG4gIHBsYXRmb3JtczogWydBbmRyb2lkJywgJ2lPUyddLFxufSlcbkBJbmplY3RhYmxlKClcbmV4cG9ydCBjbGFzcyBDYW1lcmFQcmV2aWV3IGV4dGVuZHMgSW9uaWNOYXRpdmVQbHVnaW4ge1xuICBGT0NVU19NT0RFID0ge1xuICAgIEZJWEVEOiAnZml4ZWQnLFxuICAgIEFVVE86ICdhdXRvJyxcbiAgICBDT05USU5VT1VTOiAnY29udGludW91cycsIC8vIElPUyBPbmx5XG4gICAgQ09OVElOVU9VU19QSUNUVVJFOiAnY29udGludW91cy1waWN0dXJlJywgLy8gQW5kcm9pZCBPbmx5XG4gICAgQ09OVElOVU9VU19WSURFTzogJ2NvbnRpbnVvdXMtdmlkZW8nLCAvLyBBbmRyb2lkIE9ubHlcbiAgICBFRE9GOiAnZWRvZicsIC8vIEFuZHJvaWQgT25seVxuICAgIElORklOSVRZOiAnaW5maW5pdHknLCAvLyBBbmRyb2lkIE9ubHlcbiAgICBNQUNSTzogJ21hY3JvJywgLy8gQW5kcm9pZCBPbmx5XG4gIH07XG5cbiAgRVhQT1NVUkVfTU9ERSA9IHtcbiAgICBMT0NLOiAnbG9jaycsIC8vIElPUyBPbmx5XG4gICAgQVVUTzogJ2F1dG8nLCAvLyBJT1MgT25seVxuICAgIENPTlRJTlVPVVM6ICdjb250aW51b3VzJyxcbiAgICBDVVNUT006ICdjdXN0b20nLFxuICB9O1xuXG4gIEZMQVNIX01PREUgPSB7XG4gICAgT0ZGOiAnb2ZmJyxcbiAgICBPTjogJ29uJyxcbiAgICBBVVRPOiAnYXV0bycsXG4gICAgUkVEX0VZRTogJ3JlZC1leWUnLFxuICAgIFRPUkNIOiAndG9yY2gnLCAvLyBBbmRyb2lkIE9ubHlcbiAgfTtcblxuICBDT0xPUl9FRkZFQ1QgPSB7XG4gICAgQVFVQTogJ2FxdWEnLCAvLyBBbmRyb2lkIE9ubHlcbiAgICBCTEFDS0JPQVJEOiAnYmxhY2tib2FyZCcsIC8vIEFuZHJvaWQgT25seVxuICAgIE1PTk86ICdtb25vJyxcbiAgICBORUdBVElWRTogJ25lZ2F0aXZlJyxcbiAgICBOT05FOiAnbm9uZScsXG4gICAgUE9TVEVSSVpFOiAncG9zdGVyaXplJyxcbiAgICBTRVBJQTogJ3NlcGlhJyxcbiAgICBTT0xBUklaRTogJ3NvbGFyaXplJywgLy8gQW5kcm9pZCBPbmx5XG4gICAgV0hJVEVCT0FSRDogJ3doaXRlYm9hcmQnLCAvLyBBbmRyb2lkIE9ubHlcbiAgfTtcblxuICBDQU1FUkFfRElSRUNUSU9OID0ge1xuICAgIEJBQ0s6ICdiYWNrJyxcbiAgICBGUk9OVDogJ2Zyb250JyxcbiAgfTtcblxuICAvKipcbiAgICogU3RhcnRzIHRoZSBjYW1lcmEgcHJldmlldyBpbnN0YW5jZS5cbiAgICogQHBhcmFtIHtDYW1lcmFQcmV2aWV3T3B0aW9uc30gb3B0aW9uc1xuICAgKiBAcmV0dXJuIHtQcm9taXNlPGFueT59XG4gICAqL1xuICBAQ29yZG92YSh7XG4gICAgc3VjY2Vzc0luZGV4OiAxLFxuICAgIGVycm9ySW5kZXg6IDIsXG4gIH0pXG4gIHN0YXJ0Q2FtZXJhKG9wdGlvbnM6IENhbWVyYVByZXZpZXdPcHRpb25zKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cbiAgXG4gIC8qKlxuICAgKiBTdGFydHMgdGhlIGNhbWVyYSB2aWRlbyBpbnN0YW5jZS5cbiAgICogQHBhcmFtIHthbnl9IG9wdGlvbnNcbiAgICogQHJldHVybiB7UHJvbWlzZTxhbnk+fVxuICAgKi9cbiAgQENvcmRvdmEoe1xuICAgIHN1Y2Nlc3NJbmRleDogMSxcbiAgICBlcnJvckluZGV4OiAyLFxuICB9KVxuICBzdGFydFJlY29yZFZpZGVvKG9wdGlvbnM6IGFueSk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG4gIFxuXG4gIC8qKlxuICAgKiBTdG9wcyB0aGUgY2FtZXJhIHByZXZpZXcgaW5zdGFuY2UuIChpT1MgJiBBbmRyb2lkKVxuICAgKiBAcmV0dXJuIHtQcm9taXNlPGFueT59XG4gICAqL1xuICBAQ29yZG92YSgpXG4gIHN0b3BDYW1lcmEoKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cbiAgXG4gIC8qKlxuICAgKiBTdG9wcyB0aGUgY2FtZXJhIHZpZGVvIGluc3RhbmNlLiAoaU9TICYgQW5kcm9pZClcbiAgICogQHJldHVybiB7UHJvbWlzZTxhbnk+fVxuICAgKi9cbiAgQENvcmRvdmEoKVxuICBzdG9wUmVjb3JkVmlkZW8oKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cblxuICAvKipcbiAgICogU3dpdGNoIGZyb20gdGhlIHJlYXIgY2FtZXJhIGFuZCBmcm9udCBjYW1lcmEsIGlmIGF2YWlsYWJsZS5cbiAgICogQHJldHVybiB7UHJvbWlzZTxhbnk+fVxuICAgKi9cbiAgQENvcmRvdmEoKVxuICBzd2l0Y2hDYW1lcmEoKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cblxuICAvKipcbiAgICogSGlkZSB0aGUgY2FtZXJhIHByZXZpZXcgYm94LlxuICAgKiBAcmV0dXJuIHtQcm9taXNlPGFueT59XG4gICAqL1xuICBAQ29yZG92YSgpXG4gIGhpZGUoKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cblxuICAvKipcbiAgICogU2hvdyB0aGUgY2FtZXJhIHByZXZpZXcgYm94LlxuICAgKiBAcmV0dXJuIHtQcm9taXNlPGFueT59XG4gICAqL1xuICBAQ29yZG92YSgpXG4gIHNob3coKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cblxuICAvKipcbiAgICogVGFrZSB0aGUgcGljdHVyZSAoYmFzZTY0KVxuICAgKiBAcGFyYW0ge0NhbWVyYVByZXZpZXdQaWN0dXJlT3B0aW9uc30gW29wdGlvbnNdIHNpemUgYW5kIHF1YWxpdHkgb2YgdGhlIHBpY3R1cmUgdG8gdGFrZVxuICAgKiBAcmV0dXJuIHtQcm9taXNlPGFueT59XG4gICAqL1xuICBAQ29yZG92YSh7XG4gICAgc3VjY2Vzc0luZGV4OiAxLFxuICAgIGVycm9ySW5kZXg6IDIsXG4gIH0pXG4gIHRha2VQaWN0dXJlKG9wdGlvbnM/OiBDYW1lcmFQcmV2aWV3UGljdHVyZU9wdGlvbnMpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuXG4gIC8qKlxuICAgKiBUYWtlIGEgc25hcHNob3Qgb2YgcHJldmlldyB3aW5kb3cgKHNpemUgc3BlY2lmaWVkIGluIHN0YXJ0Q2FtZXJhIG9wdGlvbnMpXG4gICAqIEBwYXJhbSB7Q2FtZXJhUHJldmlld1BpY3R1cmVPcHRpb25zfSBbb3B0aW9uc10gcXVhbGl0eSBvZiB0aGUgcGljdHVyZSB0byB0YWtlXG4gICAqIEByZXR1cm4ge1Byb21pc2U8YW55Pn1cbiAgICovXG4gIEBDb3Jkb3ZhKHtcbiAgICBzdWNjZXNzSW5kZXg6IDEsXG4gICAgZXJyb3JJbmRleDogMixcbiAgfSlcbiAgdGFrZVNuYXBzaG90KG9wdGlvbnM/OiBDYW1lcmFQcmV2aWV3UGljdHVyZU9wdGlvbnMpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKiBTZXQgY2FtZXJhIGNvbG9yIGVmZmVjdC5cbiAgICogQHN0YXRpY1xuICAgKiBAcGFyYW0ge3N0cmluZ30gZWZmZWN0IG5hbWUgOiAnbm9uZScgKGlPUyAmIEFuZHJvaWQpLCAnYXF1YScgKEFuZHJvaWQpLCAnYmxhY2tib2FyZCcgKEFuZHJvaWQpLCAnbW9ubycgKGlPUyAmIEFuZHJvaWQpLCAnbmVnYXRpdmUnIChpT1MgJiBBbmRyb2lkKSwgJ3Bvc3Rlcml6ZScgKGlPUyAmIEFuZHJvaWQpLCAnc2VwaWEnIChpT1MgJiBBbmRyb2lkKSwgJ3NvbGFyaXplJyAoQW5kcm9pZCkgb3IgJ3doaXRlYm9hcmQnIChBbmRyb2lkKVxuICAgKiBAcmV0dXJuIHtQcm9taXNlPGFueT59XG4gICAqL1xuICBAQ29yZG92YSh7XG4gICAgc3VjY2Vzc0luZGV4OiAxLFxuICAgIGVycm9ySW5kZXg6IDIsXG4gIH0pXG4gIHNldENvbG9yRWZmZWN0KGVmZmVjdDogc3RyaW5nKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cblxuICAvKipcbiAgICogU2V0IHRoZSB6b29tIChBbmRyb2lkKVxuICAgKiBAcGFyYW0gW3pvb21dIHtudW1iZXJ9IFpvb20gdmFsdWVcbiAgICogQHJldHVybiB7UHJvbWlzZTxhbnk+fVxuICAgKi9cbiAgQENvcmRvdmEoe1xuICAgIHN1Y2Nlc3NJbmRleDogMSxcbiAgICBlcnJvckluZGV4OiAyLFxuICB9KVxuICBzZXRab29tKHpvb20/OiBudW1iZXIpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuXG4gIC8qKlxuICAgKiBHZXQgdGhlIG1heGltdW0gem9vbSAoQW5kcm9pZClcbiAgICogQHJldHVybiB7UHJvbWlzZTxhbnk+fVxuICAgKi9cbiAgQENvcmRvdmEoKVxuICBnZXRNYXhab29tKCk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgLyoqXG4gICAqIEdldCBjdXJyZW50IHpvb20gKEFuZHJvaWQpXG4gICAqIEByZXR1cm4ge1Byb21pc2U8YW55Pn1cbiAgICovXG4gIEBDb3Jkb3ZhKClcbiAgZ2V0Wm9vbSgpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuXG4gIC8qKlxuICAgKiBTZXQgdGhlIHByZXZpZXcgU2l6ZVxuICAgKiBAcGFyYW0ge0NhbWVyYVByZXZpZXdEaW1lbnNpb25zfSBbZGltZW5zaW9uc11cbiAgICogQHJldHVybiB7UHJvbWlzZTxhbnk+fVxuICAgKi9cbiAgQENvcmRvdmEoe1xuICAgIHN1Y2Nlc3NJbmRleDogMSxcbiAgICBlcnJvckluZGV4OiAyLFxuICB9KVxuICBzZXRQcmV2aWV3U2l6ZShkaW1lbnNpb25zPzogQ2FtZXJhUHJldmlld0RpbWVuc2lvbnMpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuXG4gIC8qKlxuICAgKiBHZXQgZm9jdXMgbW9kZVxuICAgKiBAcmV0dXJuIHtQcm9taXNlPGFueT59XG4gICAqL1xuICBAQ29yZG92YSgpXG4gIGdldEZvY3VzTW9kZSgpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuXG4gIC8qKlxuICAgKiBTZXQgdGhlIGZvY3VzIG1vZGVcbiAgICogQHBhcmFtIHtzdHJpbmd9IFtmb2N1c01vZGVdICdmaXhlZCcsICdhdXRvJywgJ2NvbnRpbnVvdXMtcGljdHVyZScsICdjb250aW51b3VzLXZpZGVvJyAoaU9TICYgQW5kcm9pZCksICdlZG9mJywgJ2luZmluaXR5JywgJ21hY3JvJyAoQW5kcm9pZCBPbmx5KVxuICAgKiBAcmV0dXJuIHtQcm9taXNlPGFueT59XG4gICAqL1xuICBAQ29yZG92YSh7XG4gICAgc3VjY2Vzc0luZGV4OiAxLFxuICAgIGVycm9ySW5kZXg6IDIsXG4gIH0pXG4gIHNldEZvY3VzTW9kZShmb2N1c01vZGU/OiBzdHJpbmcpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuXG4gIC8qKlxuICAgKiBHZXQgc3VwcG9ydGVkIGZvY3VzIG1vZGVzXG4gICAqIEByZXR1cm4ge1Byb21pc2U8YW55Pn1cbiAgICovXG4gIEBDb3Jkb3ZhKClcbiAgZ2V0U3VwcG9ydGVkRm9jdXNNb2RlcygpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuXG4gIC8qKlxuICAgKiBHZXQgdGhlIGN1cnJlbnQgZmxhc2ggbW9kZVxuICAgKiBAcmV0dXJuIHtQcm9taXNlPGFueT59XG4gICAqL1xuICBAQ29yZG92YSgpXG4gIGdldEZsYXNoTW9kZSgpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuXG4gIC8qKlxuICAgKiBTZXQgdGhlIGZsYXNoIG1vZGVcbiAgICogQHBhcmFtIHtzdHJpbmd9IFtmbGFzaE1vZGVdICdvZmYnIChpT1MgJiBBbmRyb2lkKSwgJ29uJyAoaU9TICYgQW5kcm9pZCksICdhdXRvJyAoaU9TICYgQW5kcm9pZCksICd0b3JjaCcgKEFuZHJvaWQpXG4gICAqIEByZXR1cm4ge1Byb21pc2U8YW55Pn1cbiAgICovXG4gIEBDb3Jkb3ZhKHtcbiAgICBzdWNjZXNzSW5kZXg6IDEsXG4gICAgZXJyb3JJbmRleDogMixcbiAgfSlcbiAgc2V0Rmxhc2hNb2RlKGZsYXNoTW9kZT86IHN0cmluZyk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgLyoqXG4gICAqIEdldCBzdXBwb3J0ZWQgZmxhc2ggbW9kZXNcbiAgICogQHJldHVybiB7UHJvbWlzZTxhbnk+fVxuICAgKi9cbiAgQENvcmRvdmEoKVxuICBnZXRTdXBwb3J0ZWRGbGFzaE1vZGVzKCk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgLyoqXG4gICAqIEdldCBzdXBwb3J0ZWQgcGljdHVyZSBzaXplc1xuICAgKiBAcmV0dXJuIHtQcm9taXNlPGFueT59XG4gICAqL1xuICBAQ29yZG92YSgpXG4gIGdldFN1cHBvcnRlZFBpY3R1cmVTaXplcygpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuXG4gIC8qKlxuICAgKiBHZXQgZXhwb3N1cmUgbW9kZVxuICAgKiBAcmV0dXJuIHtQcm9taXNlPGFueT59XG4gICAqL1xuICBAQ29yZG92YSgpXG4gIGdldEV4cG9zdXJlTW9kZSgpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuXG4gIC8qKlxuICAgKiBHZXQgZXhwb3N1cmUgbW9kZXNcbiAgICogQHJldHVybiB7UHJvbWlzZTxhbnk+fVxuICAgKi9cbiAgQENvcmRvdmEoKVxuICBnZXRFeHBvc3VyZU1vZGVzKCk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgLyoqXG4gICAqIFNldCBleHBvc3VyZSBtb2RlXG4gICAqIEBwYXJhbSB7c3RyaW5nfSBbbG9ja11cbiAgICogQHJldHVybiB7UHJvbWlzZTxhbnk+fVxuICAgKi9cbiAgQENvcmRvdmEoe1xuICAgIHN1Y2Nlc3NJbmRleDogMSxcbiAgICBlcnJvckluZGV4OiAyLFxuICB9KVxuICBzZXRFeHBvc3VyZU1vZGUobG9jaz86IHN0cmluZyk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgLyoqXG4gICAqIEdldCBleHBvc3VyZSBjb21wZW5zYXRpb24gKEFuZHJvaWQpXG4gICAqIEByZXR1cm4ge1Byb21pc2U8YW55Pn1cbiAgICovXG4gIEBDb3Jkb3ZhKClcbiAgZ2V0RXhwb3N1cmVDb21wZW5zYXRpb24oKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cblxuICAvKipcbiAgICogU2V0IGV4cG9zdXJlIGNvbXBlbnNhdGlvbiAoQW5kcm9pZClcbiAgICogQHBhcmFtIHtudW1iZXJ9IFtleHBvc3VyZUNvbXBlbnNhdGlvbl1cbiAgICogQHJldHVybiB7UHJvbWlzZTxhbnk+fVxuICAgKi9cbiAgQENvcmRvdmEoe1xuICAgIHN1Y2Nlc3NJbmRleDogMSxcbiAgICBlcnJvckluZGV4OiAyLFxuICB9KVxuICBzZXRFeHBvc3VyZUNvbXBlbnNhdGlvbihleHBvc3VyZUNvbXBlbnNhdGlvbj86IG51bWJlcik6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgLyoqXG4gICAqIEdldCBleHBvc3VyZSBjb21wZW5zYXRpb24gcmFuZ2UgKEFuZHJvaWQpXG4gICAqIEByZXR1cm4ge1Byb21pc2U8YW55Pn1cbiAgICovXG4gIEBDb3Jkb3ZhKClcbiAgZ2V0RXhwb3N1cmVDb21wZW5zYXRpb25SYW5nZSgpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuXG4gIC8qKlxuICAgKiBTZXQgc3BlY2lmaWMgZm9jdXMgcG9pbnQuIE5vdGUsIHRoaXMgYXNzdW1lcyB0aGUgY2FtZXJhIGlzIGZ1bGwtc2NyZWVuLlxuICAgKiBAcGFyYW0ge251bWJlcn0geFBvaW50XG4gICAqIEBwYXJhbSB7bnVtYmVyfSB5UG9pbnRcbiAgICogQHJldHVybiB7UHJvbWlzZTxhbnk+fVxuICAgKi9cbiAgQENvcmRvdmEoKVxuICB0YXBUb0ZvY3VzKHhQb2ludDogbnVtYmVyLCB5UG9pbnQ6IG51bWJlcik6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgLyoqXG4gICAqIEFkZCBhIGxpc3RlbmVyIGZvciB0aGUgYmFjayBldmVudCBmb3IgdGhlIHByZXZpZXdcbiAgICogQHJldHVybiB7UHJvbWlzZTxhbnk+fSBpZiBiYWNrIGJ1dHRvbiBwcmVzc2VkXG4gICAqL1xuICBAQ29yZG92YSgpXG4gIG9uQmFja0J1dHRvbigpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm4gaW4gdXNlIGRldmljZSBjYW1lcmEgZm92XG4gICAqIEByZXR1cm4ge1Byb21pc2U8YW55Pn1cbiAgICovXG4gIEBDb3Jkb3ZhKClcbiAgZ2V0SG9yaXpvbnRhbEZPVigpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuXG4gIC8qKlxuICAgKiBHZXQgdGhlIGNoYXJhY3RlcmlzdGljcyBvZiBhbGwgYXZhaWxhYmxlIGNhbWVyYXNcbiAgICogQHJldHVybiB7UHJvbWlzZTxhbnk+fVxuICAgKi9cbiAgQENvcmRvdmEoKVxuICBnZXRDYW1lcmFDaGFyYWN0ZXJpc3RpY3MoKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cbn1cbiJdfQ==

    /***/

  },

  /***/
  "./node_modules/@ionic-native/insomnia/ngx/index.js":
  /*!**********************************************************!*\
    !*** ./node_modules/@ionic-native/insomnia/ngx/index.js ***!
    \**********************************************************/

  /*! exports provided: Insomnia */

  /***/
  function node_modulesIonicNativeInsomniaNgxIndexJs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Insomnia", function () {
      return Insomnia;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _ionic_native_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic-native/core */
    "./node_modules/@ionic-native/core/index.js");

    var Insomnia =
    /** @class */
    function (_super) {
      Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(Insomnia, _super);

      function Insomnia() {
        return _super !== null && _super.apply(this, arguments) || this;
      }

      Insomnia.prototype.keepAwake = function () {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "keepAwake", {}, arguments);
      };

      Insomnia.prototype.allowSleepAgain = function () {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "allowSleepAgain", {}, arguments);
      };

      Insomnia.pluginName = "Insomnia";
      Insomnia.plugin = "cordova-plugin-insomnia";
      Insomnia.pluginRef = "plugins.insomnia";
      Insomnia.repo = "https://github.com/EddyVerbruggen/Insomnia-PhoneGap-Plugin";
      Insomnia.platforms = ["Android", "Browser", "Firefox OS", "iOS", "Windows", "Windows Phone 8"];
      Insomnia = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])()], Insomnia);
      return Insomnia;
    }(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["IonicNativePlugin"]); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvQGlvbmljLW5hdGl2ZS9wbHVnaW5zL2luc29tbmlhL25neC9pbmRleC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUMzQyxPQUFPLDhCQUFzQyxNQUFNLG9CQUFvQixDQUFDOztJQXFDMUMsNEJBQWlCOzs7O0lBTTdDLDRCQUFTO0lBU1Qsa0NBQWU7Ozs7OztJQWZKLFFBQVE7UUFEcEIsVUFBVSxFQUFFO09BQ0EsUUFBUTttQkF0Q3JCO0VBc0M4QixpQkFBaUI7U0FBbEMsUUFBUSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IENvcmRvdmEsIElvbmljTmF0aXZlUGx1Z2luLCBQbHVnaW4gfSBmcm9tICdAaW9uaWMtbmF0aXZlL2NvcmUnO1xuXG4vKipcbiAqIEBuYW1lIEluc29tbmlhXG4gKiBAZGVzY3JpcHRpb25cbiAqIFByZXZlbnQgdGhlIHNjcmVlbiBvZiB0aGUgbW9iaWxlIGRldmljZSBmcm9tIGZhbGxpbmcgYXNsZWVwLlxuICpcbiAqIEB1c2FnZVxuICogYGBgdHlwZXNjcmlwdFxuICogaW1wb3J0IHsgSW5zb21uaWEgfSBmcm9tICdAaW9uaWMtbmF0aXZlL2luc29tbmlhL25neCc7XG4gKlxuICogY29uc3RydWN0b3IocHJpdmF0ZSBpbnNvbW5pYTogSW5zb21uaWEpIHsgfVxuICpcbiAqIC4uLlxuICpcbiAqIHRoaXMuaW5zb21uaWEua2VlcEF3YWtlKClcbiAqICAgLnRoZW4oXG4gKiAgICAgKCkgPT4gY29uc29sZS5sb2coJ3N1Y2Nlc3MnKSxcbiAqICAgICAoKSA9PiBjb25zb2xlLmxvZygnZXJyb3InKVxuICogICApO1xuICpcbiAqIHRoaXMuaW5zb21uaWEuYWxsb3dTbGVlcEFnYWluKClcbiAqICAgLnRoZW4oXG4gKiAgICAgKCkgPT4gY29uc29sZS5sb2coJ3N1Y2Nlc3MnKSxcbiAqICAgICAoKSA9PiBjb25zb2xlLmxvZygnZXJyb3InKVxuICogICApO1xuICogYGBgXG4gKlxuICovXG5AUGx1Z2luKHtcbiAgcGx1Z2luTmFtZTogJ0luc29tbmlhJyxcbiAgcGx1Z2luOiAnY29yZG92YS1wbHVnaW4taW5zb21uaWEnLFxuICBwbHVnaW5SZWY6ICdwbHVnaW5zLmluc29tbmlhJyxcbiAgcmVwbzogJ2h0dHBzOi8vZ2l0aHViLmNvbS9FZGR5VmVyYnJ1Z2dlbi9JbnNvbW5pYS1QaG9uZUdhcC1QbHVnaW4nLFxuICBwbGF0Zm9ybXM6IFsnQW5kcm9pZCcsICdCcm93c2VyJywgJ0ZpcmVmb3ggT1MnLCAnaU9TJywgJ1dpbmRvd3MnLCAnV2luZG93cyBQaG9uZSA4J10sXG59KVxuQEluamVjdGFibGUoKVxuZXhwb3J0IGNsYXNzIEluc29tbmlhIGV4dGVuZHMgSW9uaWNOYXRpdmVQbHVnaW4ge1xuICAvKipcbiAgICogS2VlcHMgYXdha2UgdGhlIGFwcGxpY2F0aW9uXG4gICAqIEByZXR1cm5zIHtQcm9taXNlPGFueT59XG4gICAqL1xuICBAQ29yZG92YSgpXG4gIGtlZXBBd2FrZSgpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuXG4gIC8qKlxuICAgKiBBbGxvd3MgdGhlIGFwcGxpY2F0aW9uIHRvIHNsZWVwIGFnYWluXG4gICAqIEByZXR1cm5zIHtQcm9taXNlPGFueT59XG4gICAqL1xuICBAQ29yZG92YSgpXG4gIGFsbG93U2xlZXBBZ2FpbigpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxufVxuIl19

    /***/

  },

  /***/
  "./node_modules/dom-to-image/src/dom-to-image.js":
  /*!*******************************************************!*\
    !*** ./node_modules/dom-to-image/src/dom-to-image.js ***!
    \*******************************************************/

  /*! no static exports found */

  /***/
  function node_modulesDomToImageSrcDomToImageJs(module, exports, __webpack_require__) {
    (function (global) {
      'use strict';

      var util = newUtil();
      var inliner = newInliner();
      var fontFaces = newFontFaces();
      var images = newImages(); // Default impl options

      var defaultOptions = {
        // Default is to fail on error, no placeholder
        imagePlaceholder: undefined,
        // Default cache bust is false, it will use the cache
        cacheBust: false
      };
      var domtoimage = {
        toSvg: toSvg,
        toPng: toPng,
        toJpeg: toJpeg,
        toBlob: toBlob,
        toPixelData: toPixelData,
        impl: {
          fontFaces: fontFaces,
          images: images,
          util: util,
          inliner: inliner,
          options: {}
        }
      };
      if (true) module.exports = domtoimage;else {}
      /**
       * @param {Node} node - The DOM Node object to render
       * @param {Object} options - Rendering options
       * @param {Function} options.filter - Should return true if passed node should be included in the output
       *          (excluding node means excluding it's children as well). Not called on the root node.
       * @param {String} options.bgcolor - color for the background, any valid CSS color value.
       * @param {Number} options.width - width to be applied to node before rendering.
       * @param {Number} options.height - height to be applied to node before rendering.
       * @param {Object} options.style - an object whose properties to be copied to node's style before rendering.
       * @param {Number} options.quality - a Number between 0 and 1 indicating image quality (applicable to JPEG only),
                  defaults to 1.0.
       * @param {String} options.imagePlaceholder - dataURL to use as a placeholder for failed images, default behaviour is to fail fast on images we can't fetch
       * @param {Boolean} options.cacheBust - set to true to cache bust by appending the time to the request url
       * @return {Promise} - A promise that is fulfilled with a SVG image data URL
       * */

      function toSvg(node, options) {
        options = options || {};
        copyOptions(options);
        return Promise.resolve(node).then(function (node) {
          return cloneNode(node, options.filter, true);
        }).then(embedFonts).then(inlineImages).then(applyOptions).then(function (clone) {
          return makeSvgDataUri(clone, options.width || util.width(node), options.height || util.height(node));
        });

        function applyOptions(clone) {
          if (options.bgcolor) clone.style.backgroundColor = options.bgcolor;
          if (options.width) clone.style.width = options.width + 'px';
          if (options.height) clone.style.height = options.height + 'px';
          if (options.style) Object.keys(options.style).forEach(function (property) {
            clone.style[property] = options.style[property];
          });
          return clone;
        }
      }
      /**
       * @param {Node} node - The DOM Node object to render
       * @param {Object} options - Rendering options, @see {@link toSvg}
       * @return {Promise} - A promise that is fulfilled with a Uint8Array containing RGBA pixel data.
       * */


      function toPixelData(node, options) {
        return draw(node, options || {}).then(function (canvas) {
          return canvas.getContext('2d').getImageData(0, 0, util.width(node), util.height(node)).data;
        });
      }
      /**
       * @param {Node} node - The DOM Node object to render
       * @param {Object} options - Rendering options, @see {@link toSvg}
       * @return {Promise} - A promise that is fulfilled with a PNG image data URL
       * */


      function toPng(node, options) {
        return draw(node, options || {}).then(function (canvas) {
          return canvas.toDataURL();
        });
      }
      /**
       * @param {Node} node - The DOM Node object to render
       * @param {Object} options - Rendering options, @see {@link toSvg}
       * @return {Promise} - A promise that is fulfilled with a JPEG image data URL
       * */


      function toJpeg(node, options) {
        options = options || {};
        return draw(node, options).then(function (canvas) {
          return canvas.toDataURL('image/jpeg', options.quality || 1.0);
        });
      }
      /**
       * @param {Node} node - The DOM Node object to render
       * @param {Object} options - Rendering options, @see {@link toSvg}
       * @return {Promise} - A promise that is fulfilled with a PNG image blob
       * */


      function toBlob(node, options) {
        return draw(node, options || {}).then(util.canvasToBlob);
      }

      function copyOptions(options) {
        // Copy options to impl options for use in impl
        if (typeof options.imagePlaceholder === 'undefined') {
          domtoimage.impl.options.imagePlaceholder = defaultOptions.imagePlaceholder;
        } else {
          domtoimage.impl.options.imagePlaceholder = options.imagePlaceholder;
        }

        if (typeof options.cacheBust === 'undefined') {
          domtoimage.impl.options.cacheBust = defaultOptions.cacheBust;
        } else {
          domtoimage.impl.options.cacheBust = options.cacheBust;
        }
      }

      function draw(domNode, options) {
        return toSvg(domNode, options).then(util.makeImage).then(util.delay(100)).then(function (image) {
          var canvas = newCanvas(domNode);
          canvas.getContext('2d').drawImage(image, 0, 0);
          return canvas;
        });

        function newCanvas(domNode) {
          var canvas = document.createElement('canvas');
          canvas.width = options.width || util.width(domNode);
          canvas.height = options.height || util.height(domNode);

          if (options.bgcolor) {
            var ctx = canvas.getContext('2d');
            ctx.fillStyle = options.bgcolor;
            ctx.fillRect(0, 0, canvas.width, canvas.height);
          }

          return canvas;
        }
      }

      function cloneNode(node, filter, root) {
        if (!root && filter && !filter(node)) return Promise.resolve();
        return Promise.resolve(node).then(makeNodeCopy).then(function (clone) {
          return cloneChildren(node, clone, filter);
        }).then(function (clone) {
          return processClone(node, clone);
        });

        function makeNodeCopy(node) {
          if (node instanceof HTMLCanvasElement) return util.makeImage(node.toDataURL());
          return node.cloneNode(false);
        }

        function cloneChildren(original, clone, filter) {
          var children = original.childNodes;
          if (children.length === 0) return Promise.resolve(clone);
          return cloneChildrenInOrder(clone, util.asArray(children), filter).then(function () {
            return clone;
          });

          function cloneChildrenInOrder(parent, children, filter) {
            var done = Promise.resolve();
            children.forEach(function (child) {
              done = done.then(function () {
                return cloneNode(child, filter);
              }).then(function (childClone) {
                if (childClone) parent.appendChild(childClone);
              });
            });
            return done;
          }
        }

        function processClone(original, clone) {
          if (!(clone instanceof Element)) return clone;
          return Promise.resolve().then(cloneStyle).then(clonePseudoElements).then(copyUserInput).then(fixSvg).then(function () {
            return clone;
          });

          function cloneStyle() {
            copyStyle(window.getComputedStyle(original), clone.style);

            function copyStyle(source, target) {
              if (source.cssText) target.cssText = source.cssText;else copyProperties(source, target);

              function copyProperties(source, target) {
                util.asArray(source).forEach(function (name) {
                  target.setProperty(name, source.getPropertyValue(name), source.getPropertyPriority(name));
                });
              }
            }
          }

          function clonePseudoElements() {
            [':before', ':after'].forEach(function (element) {
              clonePseudoElement(element);
            });

            function clonePseudoElement(element) {
              var style = window.getComputedStyle(original, element);
              var content = style.getPropertyValue('content');
              if (content === '' || content === 'none') return;
              var className = util.uid();
              clone.className = clone.className + ' ' + className;
              var styleElement = document.createElement('style');
              styleElement.appendChild(formatPseudoElementStyle(className, element, style));
              clone.appendChild(styleElement);

              function formatPseudoElementStyle(className, element, style) {
                var selector = '.' + className + ':' + element;
                var cssText = style.cssText ? formatCssText(style) : formatCssProperties(style);
                return document.createTextNode(selector + '{' + cssText + '}');

                function formatCssText(style) {
                  var content = style.getPropertyValue('content');
                  return style.cssText + ' content: ' + content + ';';
                }

                function formatCssProperties(style) {
                  return util.asArray(style).map(formatProperty).join('; ') + ';';

                  function formatProperty(name) {
                    return name + ': ' + style.getPropertyValue(name) + (style.getPropertyPriority(name) ? ' !important' : '');
                  }
                }
              }
            }
          }

          function copyUserInput() {
            if (original instanceof HTMLTextAreaElement) clone.innerHTML = original.value;
            if (original instanceof HTMLInputElement) clone.setAttribute("value", original.value);
          }

          function fixSvg() {
            if (!(clone instanceof SVGElement)) return;
            clone.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
            if (!(clone instanceof SVGRectElement)) return;
            ['width', 'height'].forEach(function (attribute) {
              var value = clone.getAttribute(attribute);
              if (!value) return;
              clone.style.setProperty(attribute, value);
            });
          }
        }
      }

      function embedFonts(node) {
        return fontFaces.resolveAll().then(function (cssText) {
          var styleNode = document.createElement('style');
          node.appendChild(styleNode);
          styleNode.appendChild(document.createTextNode(cssText));
          return node;
        });
      }

      function inlineImages(node) {
        return images.inlineAll(node).then(function () {
          return node;
        });
      }

      function makeSvgDataUri(node, width, height) {
        return Promise.resolve(node).then(function (node) {
          node.setAttribute('xmlns', 'http://www.w3.org/1999/xhtml');
          return new XMLSerializer().serializeToString(node);
        }).then(util.escapeXhtml).then(function (xhtml) {
          return '<foreignObject x="0" y="0" width="100%" height="100%">' + xhtml + '</foreignObject>';
        }).then(function (foreignObject) {
          return '<svg xmlns="http://www.w3.org/2000/svg" width="' + width + '" height="' + height + '">' + foreignObject + '</svg>';
        }).then(function (svg) {
          return 'data:image/svg+xml;charset=utf-8,' + svg;
        });
      }

      function newUtil() {
        return {
          escape: escape,
          parseExtension: parseExtension,
          mimeType: mimeType,
          dataAsUrl: dataAsUrl,
          isDataUrl: isDataUrl,
          canvasToBlob: canvasToBlob,
          resolveUrl: resolveUrl,
          getAndEncode: getAndEncode,
          uid: uid(),
          delay: delay,
          asArray: asArray,
          escapeXhtml: escapeXhtml,
          makeImage: makeImage,
          width: width,
          height: height
        };

        function mimes() {
          /*
           * Only WOFF and EOT mime types for fonts are 'real'
           * see http://www.iana.org/assignments/media-types/media-types.xhtml
           */
          var WOFF = 'application/font-woff';
          var JPEG = 'image/jpeg';
          return {
            'woff': WOFF,
            'woff2': WOFF,
            'ttf': 'application/font-truetype',
            'eot': 'application/vnd.ms-fontobject',
            'png': 'image/png',
            'jpg': JPEG,
            'jpeg': JPEG,
            'gif': 'image/gif',
            'tiff': 'image/tiff',
            'svg': 'image/svg+xml'
          };
        }

        function parseExtension(url) {
          var match = /\.([^\.\/]*?)$/g.exec(url);
          if (match) return match[1];else return '';
        }

        function mimeType(url) {
          var extension = parseExtension(url).toLowerCase();
          return mimes()[extension] || '';
        }

        function isDataUrl(url) {
          return url.search(/^(data:)/) !== -1;
        }

        function toBlob(canvas) {
          return new Promise(function (resolve) {
            var binaryString = window.atob(canvas.toDataURL().split(',')[1]);
            var length = binaryString.length;
            var binaryArray = new Uint8Array(length);

            for (var i = 0; i < length; i++) {
              binaryArray[i] = binaryString.charCodeAt(i);
            }

            resolve(new Blob([binaryArray], {
              type: 'image/png'
            }));
          });
        }

        function canvasToBlob(canvas) {
          if (canvas.toBlob) return new Promise(function (resolve) {
            canvas.toBlob(resolve);
          });
          return toBlob(canvas);
        }

        function resolveUrl(url, baseUrl) {
          var doc = document.implementation.createHTMLDocument();
          var base = doc.createElement('base');
          doc.head.appendChild(base);
          var a = doc.createElement('a');
          doc.body.appendChild(a);
          base.href = baseUrl;
          a.href = url;
          return a.href;
        }

        function uid() {
          var index = 0;
          return function () {
            return 'u' + fourRandomChars() + index++;

            function fourRandomChars() {
              /* see http://stackoverflow.com/a/6248722/2519373 */
              return ('0000' + (Math.random() * Math.pow(36, 4) << 0).toString(36)).slice(-4);
            }
          };
        }

        function makeImage(uri) {
          return new Promise(function (resolve, reject) {
            var image = new Image();

            image.onload = function () {
              resolve(image);
            };

            image.onerror = reject;
            image.src = uri;
          });
        }

        function getAndEncode(url) {
          var TIMEOUT = 30000;

          if (domtoimage.impl.options.cacheBust) {
            // Cache bypass so we dont have CORS issues with cached images
            // Source: https://developer.mozilla.org/en/docs/Web/API/XMLHttpRequest/Using_XMLHttpRequest#Bypassing_the_cache
            url += (/\?/.test(url) ? "&" : "?") + new Date().getTime();
          }

          return new Promise(function (resolve) {
            var request = new XMLHttpRequest();
            request.onreadystatechange = done;
            request.ontimeout = timeout;
            request.responseType = 'blob';
            request.timeout = TIMEOUT;
            request.open('GET', url, true);
            request.send();
            var placeholder;

            if (domtoimage.impl.options.imagePlaceholder) {
              var split = domtoimage.impl.options.imagePlaceholder.split(/,/);

              if (split && split[1]) {
                placeholder = split[1];
              }
            }

            function done() {
              if (request.readyState !== 4) return;

              if (request.status !== 200) {
                if (placeholder) {
                  resolve(placeholder);
                } else {
                  fail('cannot fetch resource: ' + url + ', status: ' + request.status);
                }

                return;
              }

              var encoder = new FileReader();

              encoder.onloadend = function () {
                var content = encoder.result.split(/,/)[1];
                resolve(content);
              };

              encoder.readAsDataURL(request.response);
            }

            function timeout() {
              if (placeholder) {
                resolve(placeholder);
              } else {
                fail('timeout of ' + TIMEOUT + 'ms occured while fetching resource: ' + url);
              }
            }

            function fail(message) {
              console.error(message);
              resolve('');
            }
          });
        }

        function dataAsUrl(content, type) {
          return 'data:' + type + ';base64,' + content;
        }

        function escape(string) {
          return string.replace(/([.*+?^${}()|\[\]\/\\])/g, '\\$1');
        }

        function delay(ms) {
          return function (arg) {
            return new Promise(function (resolve) {
              setTimeout(function () {
                resolve(arg);
              }, ms);
            });
          };
        }

        function asArray(arrayLike) {
          var array = [];
          var length = arrayLike.length;

          for (var i = 0; i < length; i++) {
            array.push(arrayLike[i]);
          }

          return array;
        }

        function escapeXhtml(string) {
          return string.replace(/#/g, '%23').replace(/\n/g, '%0A');
        }

        function width(node) {
          var leftBorder = px(node, 'border-left-width');
          var rightBorder = px(node, 'border-right-width');
          return node.scrollWidth + leftBorder + rightBorder;
        }

        function height(node) {
          var topBorder = px(node, 'border-top-width');
          var bottomBorder = px(node, 'border-bottom-width');
          return node.scrollHeight + topBorder + bottomBorder;
        }

        function px(node, styleProperty) {
          var value = window.getComputedStyle(node).getPropertyValue(styleProperty);
          return parseFloat(value.replace('px', ''));
        }
      }

      function newInliner() {
        var URL_REGEX = /url\(['"]?([^'"]+?)['"]?\)/g;
        return {
          inlineAll: inlineAll,
          shouldProcess: shouldProcess,
          impl: {
            readUrls: readUrls,
            inline: inline
          }
        };

        function shouldProcess(string) {
          return string.search(URL_REGEX) !== -1;
        }

        function readUrls(string) {
          var result = [];
          var match;

          while ((match = URL_REGEX.exec(string)) !== null) {
            result.push(match[1]);
          }

          return result.filter(function (url) {
            return !util.isDataUrl(url);
          });
        }

        function inline(string, url, baseUrl, get) {
          return Promise.resolve(url).then(function (url) {
            return baseUrl ? util.resolveUrl(url, baseUrl) : url;
          }).then(get || util.getAndEncode).then(function (data) {
            return util.dataAsUrl(data, util.mimeType(url));
          }).then(function (dataUrl) {
            return string.replace(urlAsRegex(url), '$1' + dataUrl + '$3');
          });

          function urlAsRegex(url) {
            return new RegExp('(url\\([\'"]?)(' + util.escape(url) + ')([\'"]?\\))', 'g');
          }
        }

        function inlineAll(string, baseUrl, get) {
          if (nothingToInline()) return Promise.resolve(string);
          return Promise.resolve(string).then(readUrls).then(function (urls) {
            var done = Promise.resolve(string);
            urls.forEach(function (url) {
              done = done.then(function (string) {
                return inline(string, url, baseUrl, get);
              });
            });
            return done;
          });

          function nothingToInline() {
            return !shouldProcess(string);
          }
        }
      }

      function newFontFaces() {
        return {
          resolveAll: resolveAll,
          impl: {
            readAll: readAll
          }
        };

        function resolveAll() {
          return readAll(document).then(function (webFonts) {
            return Promise.all(webFonts.map(function (webFont) {
              return webFont.resolve();
            }));
          }).then(function (cssStrings) {
            return cssStrings.join('\n');
          });
        }

        function readAll() {
          return Promise.resolve(util.asArray(document.styleSheets)).then(getCssRules).then(selectWebFontRules).then(function (rules) {
            return rules.map(newWebFont);
          });

          function selectWebFontRules(cssRules) {
            return cssRules.filter(function (rule) {
              return rule.type === CSSRule.FONT_FACE_RULE;
            }).filter(function (rule) {
              return inliner.shouldProcess(rule.style.getPropertyValue('src'));
            });
          }

          function getCssRules(styleSheets) {
            var cssRules = [];
            styleSheets.forEach(function (sheet) {
              try {
                util.asArray(sheet.cssRules || []).forEach(cssRules.push.bind(cssRules));
              } catch (e) {
                console.log('Error while reading CSS rules from ' + sheet.href, e.toString());
              }
            });
            return cssRules;
          }

          function newWebFont(webFontRule) {
            return {
              resolve: function resolve() {
                var baseUrl = (webFontRule.parentStyleSheet || {}).href;
                return inliner.inlineAll(webFontRule.cssText, baseUrl);
              },
              src: function src() {
                return webFontRule.style.getPropertyValue('src');
              }
            };
          }
        }
      }

      function newImages() {
        return {
          inlineAll: inlineAll,
          impl: {
            newImage: newImage
          }
        };

        function newImage(element) {
          return {
            inline: inline
          };

          function inline(get) {
            if (util.isDataUrl(element.src)) return Promise.resolve();
            return Promise.resolve(element.src).then(get || util.getAndEncode).then(function (data) {
              return util.dataAsUrl(data, util.mimeType(element.src));
            }).then(function (dataUrl) {
              return new Promise(function (resolve, reject) {
                element.onload = resolve;
                element.onerror = reject;
                element.src = dataUrl;
              });
            });
          }
        }

        function inlineAll(node) {
          if (!(node instanceof Element)) return Promise.resolve(node);
          return inlineBackground(node).then(function () {
            if (node instanceof HTMLImageElement) return newImage(node).inline();else return Promise.all(util.asArray(node.childNodes).map(function (child) {
              return inlineAll(child);
            }));
          });

          function inlineBackground(node) {
            var background = node.style.getPropertyValue('background');
            if (!background) return Promise.resolve(node);
            return inliner.inlineAll(background).then(function (inlined) {
              node.style.setProperty('background', inlined, node.style.getPropertyPriority('background'));
            }).then(function () {
              return node;
            });
          }
        }
      }
    })(this);
    /***/

  },

  /***/
  "./node_modules/html2canvas/dist/html2canvas.js":
  /*!******************************************************!*\
    !*** ./node_modules/html2canvas/dist/html2canvas.js ***!
    \******************************************************/

  /*! no static exports found */

  /***/
  function node_modulesHtml2canvasDistHtml2canvasJs(module, exports, __webpack_require__) {
    /*!
     * html2canvas 1.0.0-rc.7 <https://html2canvas.hertzen.com>
     * Copyright (c) 2020 Niklas von Hertzen <https://hertzen.com>
     * Released under MIT License
     */
    (function (global, factory) {
      true ? module.exports = factory() : undefined;
    })(this, function () {
      'use strict';
      /*! *****************************************************************************
      Copyright (c) Microsoft Corporation. All rights reserved.
      Licensed under the Apache License, Version 2.0 (the "License"); you may not use
      this file except in compliance with the License. You may obtain a copy of the
      License at http://www.apache.org/licenses/LICENSE-2.0
        THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
      KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
      WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
      MERCHANTABLITY OR NON-INFRINGEMENT.
        See the Apache Version 2.0 License for specific language governing permissions
      and limitations under the License.
      ***************************************************************************** */

      /* global Reflect, Promise */

      var _extendStatics = function extendStatics(d, b) {
        _extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return _extendStatics(d, b);
      };

      function __extends(d, b) {
        _extendStatics(d, b);

        function __() {
          this.constructor = d;
        }

        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
      }

      var _assign = function __assign() {
        _assign = Object.assign || function __assign(t) {
          for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];

            for (var p in s) {
              if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
            }
          }

          return t;
        };

        return _assign.apply(this, arguments);
      };

      function __awaiter(thisArg, _arguments, P, generator) {
        return new (P || (P = Promise))(function (resolve, reject) {
          function fulfilled(value) {
            try {
              step(generator.next(value));
            } catch (e) {
              reject(e);
            }
          }

          function rejected(value) {
            try {
              step(generator["throw"](value));
            } catch (e) {
              reject(e);
            }
          }

          function step(result) {
            result.done ? resolve(result.value) : new P(function (resolve) {
              resolve(result.value);
            }).then(fulfilled, rejected);
          }

          step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
      }

      function __generator(thisArg, body) {
        var _ = {
          label: 0,
          sent: function sent() {
            if (t[0] & 1) throw t[1];
            return t[1];
          },
          trys: [],
          ops: []
        },
            f,
            y,
            t,
            g;
        return g = {
          next: verb(0),
          "throw": verb(1),
          "return": verb(2)
        }, typeof Symbol === "function" && (g[Symbol.iterator] = function () {
          return this;
        }), g;

        function verb(n) {
          return function (v) {
            return step([n, v]);
          };
        }

        function step(op) {
          if (f) throw new TypeError("Generator is already executing.");

          while (_) {
            try {
              if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
              if (y = 0, t) op = [op[0] & 2, t.value];

              switch (op[0]) {
                case 0:
                case 1:
                  t = op;
                  break;

                case 4:
                  _.label++;
                  return {
                    value: op[1],
                    done: false
                  };

                case 5:
                  _.label++;
                  y = op[1];
                  op = [0];
                  continue;

                case 7:
                  op = _.ops.pop();

                  _.trys.pop();

                  continue;

                default:
                  if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                    _ = 0;
                    continue;
                  }

                  if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                    _.label = op[1];
                    break;
                  }

                  if (op[0] === 6 && _.label < t[1]) {
                    _.label = t[1];
                    t = op;
                    break;
                  }

                  if (t && _.label < t[2]) {
                    _.label = t[2];

                    _.ops.push(op);

                    break;
                  }

                  if (t[2]) _.ops.pop();

                  _.trys.pop();

                  continue;
              }

              op = body.call(thisArg, _);
            } catch (e) {
              op = [6, e];
              y = 0;
            } finally {
              f = t = 0;
            }
          }

          if (op[0] & 5) throw op[1];
          return {
            value: op[0] ? op[1] : void 0,
            done: true
          };
        }
      }

      var Bounds =
      /** @class */
      function () {
        function Bounds(x, y, w, h) {
          this.left = x;
          this.top = y;
          this.width = w;
          this.height = h;
        }

        Bounds.prototype.add = function (x, y, w, h) {
          return new Bounds(this.left + x, this.top + y, this.width + w, this.height + h);
        };

        Bounds.fromClientRect = function (clientRect) {
          return new Bounds(clientRect.left, clientRect.top, clientRect.width, clientRect.height);
        };

        return Bounds;
      }();

      var parseBounds = function parseBounds(node) {
        return Bounds.fromClientRect(node.getBoundingClientRect());
      };

      var parseDocumentSize = function parseDocumentSize(document) {
        var body = document.body;
        var documentElement = document.documentElement;

        if (!body || !documentElement) {
          throw new Error("Unable to get document size");
        }

        var width = Math.max(Math.max(body.scrollWidth, documentElement.scrollWidth), Math.max(body.offsetWidth, documentElement.offsetWidth), Math.max(body.clientWidth, documentElement.clientWidth));
        var height = Math.max(Math.max(body.scrollHeight, documentElement.scrollHeight), Math.max(body.offsetHeight, documentElement.offsetHeight), Math.max(body.clientHeight, documentElement.clientHeight));
        return new Bounds(0, 0, width, height);
      };
      /*
       * css-line-break 1.1.1 <https://github.com/niklasvh/css-line-break#readme>
       * Copyright (c) 2019 Niklas von Hertzen <https://hertzen.com>
       * Released under MIT License
       */


      var toCodePoints = function toCodePoints(str) {
        var codePoints = [];
        var i = 0;
        var length = str.length;

        while (i < length) {
          var value = str.charCodeAt(i++);

          if (value >= 0xd800 && value <= 0xdbff && i < length) {
            var extra = str.charCodeAt(i++);

            if ((extra & 0xfc00) === 0xdc00) {
              codePoints.push(((value & 0x3ff) << 10) + (extra & 0x3ff) + 0x10000);
            } else {
              codePoints.push(value);
              i--;
            }
          } else {
            codePoints.push(value);
          }
        }

        return codePoints;
      };

      var fromCodePoint = function fromCodePoint() {
        var codePoints = [];

        for (var _i = 0; _i < arguments.length; _i++) {
          codePoints[_i] = arguments[_i];
        }

        if (String.fromCodePoint) {
          return String.fromCodePoint.apply(String, codePoints);
        }

        var length = codePoints.length;

        if (!length) {
          return '';
        }

        var codeUnits = [];
        var index = -1;
        var result = '';

        while (++index < length) {
          var codePoint = codePoints[index];

          if (codePoint <= 0xffff) {
            codeUnits.push(codePoint);
          } else {
            codePoint -= 0x10000;
            codeUnits.push((codePoint >> 10) + 0xd800, codePoint % 0x400 + 0xdc00);
          }

          if (index + 1 === length || codeUnits.length > 0x4000) {
            result += String.fromCharCode.apply(String, codeUnits);
            codeUnits.length = 0;
          }
        }

        return result;
      };

      var chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'; // Use a lookup table to find the index.

      var lookup = typeof Uint8Array === 'undefined' ? [] : new Uint8Array(256);

      for (var i = 0; i < chars.length; i++) {
        lookup[chars.charCodeAt(i)] = i;
      }

      var decode = function decode(base64) {
        var bufferLength = base64.length * 0.75,
            len = base64.length,
            i,
            p = 0,
            encoded1,
            encoded2,
            encoded3,
            encoded4;

        if (base64[base64.length - 1] === '=') {
          bufferLength--;

          if (base64[base64.length - 2] === '=') {
            bufferLength--;
          }
        }

        var buffer = typeof ArrayBuffer !== 'undefined' && typeof Uint8Array !== 'undefined' && typeof Uint8Array.prototype.slice !== 'undefined' ? new ArrayBuffer(bufferLength) : new Array(bufferLength);
        var bytes = Array.isArray(buffer) ? buffer : new Uint8Array(buffer);

        for (i = 0; i < len; i += 4) {
          encoded1 = lookup[base64.charCodeAt(i)];
          encoded2 = lookup[base64.charCodeAt(i + 1)];
          encoded3 = lookup[base64.charCodeAt(i + 2)];
          encoded4 = lookup[base64.charCodeAt(i + 3)];
          bytes[p++] = encoded1 << 2 | encoded2 >> 4;
          bytes[p++] = (encoded2 & 15) << 4 | encoded3 >> 2;
          bytes[p++] = (encoded3 & 3) << 6 | encoded4 & 63;
        }

        return buffer;
      };

      var polyUint16Array = function polyUint16Array(buffer) {
        var length = buffer.length;
        var bytes = [];

        for (var i = 0; i < length; i += 2) {
          bytes.push(buffer[i + 1] << 8 | buffer[i]);
        }

        return bytes;
      };

      var polyUint32Array = function polyUint32Array(buffer) {
        var length = buffer.length;
        var bytes = [];

        for (var i = 0; i < length; i += 4) {
          bytes.push(buffer[i + 3] << 24 | buffer[i + 2] << 16 | buffer[i + 1] << 8 | buffer[i]);
        }

        return bytes;
      };
      /** Shift size for getting the index-2 table offset. */


      var UTRIE2_SHIFT_2 = 5;
      /** Shift size for getting the index-1 table offset. */

      var UTRIE2_SHIFT_1 = 6 + 5;
      /**
       * Shift size for shifting left the index array values.
       * Increases possible data size with 16-bit index values at the cost
       * of compactability.
       * This requires data blocks to be aligned by UTRIE2_DATA_GRANULARITY.
       */

      var UTRIE2_INDEX_SHIFT = 2;
      /**
       * Difference between the two shift sizes,
       * for getting an index-1 offset from an index-2 offset. 6=11-5
       */

      var UTRIE2_SHIFT_1_2 = UTRIE2_SHIFT_1 - UTRIE2_SHIFT_2;
      /**
       * The part of the index-2 table for U+D800..U+DBFF stores values for
       * lead surrogate code _units_ not code _points_.
       * Values for lead surrogate code _points_ are indexed with this portion of the table.
       * Length=32=0x20=0x400>>UTRIE2_SHIFT_2. (There are 1024=0x400 lead surrogates.)
       */

      var UTRIE2_LSCP_INDEX_2_OFFSET = 0x10000 >> UTRIE2_SHIFT_2;
      /** Number of entries in a data block. 32=0x20 */

      var UTRIE2_DATA_BLOCK_LENGTH = 1 << UTRIE2_SHIFT_2;
      /** Mask for getting the lower bits for the in-data-block offset. */

      var UTRIE2_DATA_MASK = UTRIE2_DATA_BLOCK_LENGTH - 1;
      var UTRIE2_LSCP_INDEX_2_LENGTH = 0x400 >> UTRIE2_SHIFT_2;
      /** Count the lengths of both BMP pieces. 2080=0x820 */

      var UTRIE2_INDEX_2_BMP_LENGTH = UTRIE2_LSCP_INDEX_2_OFFSET + UTRIE2_LSCP_INDEX_2_LENGTH;
      /**
       * The 2-byte UTF-8 version of the index-2 table follows at offset 2080=0x820.
       * Length 32=0x20 for lead bytes C0..DF, regardless of UTRIE2_SHIFT_2.
       */

      var UTRIE2_UTF8_2B_INDEX_2_OFFSET = UTRIE2_INDEX_2_BMP_LENGTH;
      var UTRIE2_UTF8_2B_INDEX_2_LENGTH = 0x800 >> 6;
      /* U+0800 is the first code point after 2-byte UTF-8 */

      /**
       * The index-1 table, only used for supplementary code points, at offset 2112=0x840.
       * Variable length, for code points up to highStart, where the last single-value range starts.
       * Maximum length 512=0x200=0x100000>>UTRIE2_SHIFT_1.
       * (For 0x100000 supplementary code points U+10000..U+10ffff.)
       *
       * The part of the index-2 table for supplementary code points starts
       * after this index-1 table.
       *
       * Both the index-1 table and the following part of the index-2 table
       * are omitted completely if there is only BMP data.
       */

      var UTRIE2_INDEX_1_OFFSET = UTRIE2_UTF8_2B_INDEX_2_OFFSET + UTRIE2_UTF8_2B_INDEX_2_LENGTH;
      /**
       * Number of index-1 entries for the BMP. 32=0x20
       * This part of the index-1 table is omitted from the serialized form.
       */

      var UTRIE2_OMITTED_BMP_INDEX_1_LENGTH = 0x10000 >> UTRIE2_SHIFT_1;
      /** Number of entries in an index-2 block. 64=0x40 */

      var UTRIE2_INDEX_2_BLOCK_LENGTH = 1 << UTRIE2_SHIFT_1_2;
      /** Mask for getting the lower bits for the in-index-2-block offset. */

      var UTRIE2_INDEX_2_MASK = UTRIE2_INDEX_2_BLOCK_LENGTH - 1;

      var slice16 = function slice16(view, start, end) {
        if (view.slice) {
          return view.slice(start, end);
        }

        return new Uint16Array(Array.prototype.slice.call(view, start, end));
      };

      var slice32 = function slice32(view, start, end) {
        if (view.slice) {
          return view.slice(start, end);
        }

        return new Uint32Array(Array.prototype.slice.call(view, start, end));
      };

      var createTrieFromBase64 = function createTrieFromBase64(base64) {
        var buffer = decode(base64);
        var view32 = Array.isArray(buffer) ? polyUint32Array(buffer) : new Uint32Array(buffer);
        var view16 = Array.isArray(buffer) ? polyUint16Array(buffer) : new Uint16Array(buffer);
        var headerLength = 24;
        var index = slice16(view16, headerLength / 2, view32[4] / 2);
        var data = view32[5] === 2 ? slice16(view16, (headerLength + view32[4]) / 2) : slice32(view32, Math.ceil((headerLength + view32[4]) / 4));
        return new Trie(view32[0], view32[1], view32[2], view32[3], index, data);
      };

      var Trie =
      /** @class */
      function () {
        function Trie(initialValue, errorValue, highStart, highValueIndex, index, data) {
          this.initialValue = initialValue;
          this.errorValue = errorValue;
          this.highStart = highStart;
          this.highValueIndex = highValueIndex;
          this.index = index;
          this.data = data;
        }
        /**
         * Get the value for a code point as stored in the Trie.
         *
         * @param codePoint the code point
         * @return the value
         */


        Trie.prototype.get = function (codePoint) {
          var ix;

          if (codePoint >= 0) {
            if (codePoint < 0x0d800 || codePoint > 0x0dbff && codePoint <= 0x0ffff) {
              // Ordinary BMP code point, excluding leading surrogates.
              // BMP uses a single level lookup.  BMP index starts at offset 0 in the Trie2 index.
              // 16 bit data is stored in the index array itself.
              ix = this.index[codePoint >> UTRIE2_SHIFT_2];
              ix = (ix << UTRIE2_INDEX_SHIFT) + (codePoint & UTRIE2_DATA_MASK);
              return this.data[ix];
            }

            if (codePoint <= 0xffff) {
              // Lead Surrogate Code Point.  A Separate index section is stored for
              // lead surrogate code units and code points.
              //   The main index has the code unit data.
              //   For this function, we need the code point data.
              // Note: this expression could be refactored for slightly improved efficiency, but
              //       surrogate code points will be so rare in practice that it's not worth it.
              ix = this.index[UTRIE2_LSCP_INDEX_2_OFFSET + (codePoint - 0xd800 >> UTRIE2_SHIFT_2)];
              ix = (ix << UTRIE2_INDEX_SHIFT) + (codePoint & UTRIE2_DATA_MASK);
              return this.data[ix];
            }

            if (codePoint < this.highStart) {
              // Supplemental code point, use two-level lookup.
              ix = UTRIE2_INDEX_1_OFFSET - UTRIE2_OMITTED_BMP_INDEX_1_LENGTH + (codePoint >> UTRIE2_SHIFT_1);
              ix = this.index[ix];
              ix += codePoint >> UTRIE2_SHIFT_2 & UTRIE2_INDEX_2_MASK;
              ix = this.index[ix];
              ix = (ix << UTRIE2_INDEX_SHIFT) + (codePoint & UTRIE2_DATA_MASK);
              return this.data[ix];
            }

            if (codePoint <= 0x10ffff) {
              return this.data[this.highValueIndex];
            }
          } // Fall through.  The code point is outside of the legal range of 0..0x10ffff.


          return this.errorValue;
        };

        return Trie;
      }();

      var base64 = 'KwAAAAAAAAAACA4AIDoAAPAfAAACAAAAAAAIABAAGABAAEgAUABYAF4AZgBeAGYAYABoAHAAeABeAGYAfACEAIAAiACQAJgAoACoAK0AtQC9AMUAXgBmAF4AZgBeAGYAzQDVAF4AZgDRANkA3gDmAOwA9AD8AAQBDAEUARoBIgGAAIgAJwEvATcBPwFFAU0BTAFUAVwBZAFsAXMBewGDATAAiwGTAZsBogGkAawBtAG8AcIBygHSAdoB4AHoAfAB+AH+AQYCDgIWAv4BHgImAi4CNgI+AkUCTQJTAlsCYwJrAnECeQKBAk0CiQKRApkCoQKoArACuALAAsQCzAIwANQC3ALkAjAA7AL0AvwCAQMJAxADGAMwACADJgMuAzYDPgOAAEYDSgNSA1IDUgNaA1oDYANiA2IDgACAAGoDgAByA3YDfgOAAIQDgACKA5IDmgOAAIAAogOqA4AAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAK8DtwOAAIAAvwPHA88D1wPfAyAD5wPsA/QD/AOAAIAABAQMBBIEgAAWBB4EJgQuBDMEIAM7BEEEXgBJBCADUQRZBGEEaQQwADAAcQQ+AXkEgQSJBJEEgACYBIAAoASoBK8EtwQwAL8ExQSAAIAAgACAAIAAgACgAM0EXgBeAF4AXgBeAF4AXgBeANUEXgDZBOEEXgDpBPEE+QQBBQkFEQUZBSEFKQUxBTUFPQVFBUwFVAVcBV4AYwVeAGsFcwV7BYMFiwWSBV4AmgWgBacFXgBeAF4AXgBeAKsFXgCyBbEFugW7BcIFwgXIBcIFwgXQBdQF3AXkBesF8wX7BQMGCwYTBhsGIwYrBjMGOwZeAD8GRwZNBl4AVAZbBl4AXgBeAF4AXgBeAF4AXgBeAF4AXgBeAGMGXgBqBnEGXgBeAF4AXgBeAF4AXgBeAF4AXgB5BoAG4wSGBo4GkwaAAIADHgR5AF4AXgBeAJsGgABGA4AAowarBrMGswagALsGwwbLBjAA0wbaBtoG3QbaBtoG2gbaBtoG2gblBusG8wb7BgMHCwcTBxsHCwcjBysHMAc1BzUHOgdCB9oGSgdSB1oHYAfaBloHaAfaBlIH2gbaBtoG2gbaBtoG2gbaBjUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHbQdeAF4ANQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQd1B30HNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1B4MH2gaKB68EgACAAIAAgACAAIAAgACAAI8HlwdeAJ8HpweAAIAArwe3B14AXgC/B8UHygcwANAH2AfgB4AA6AfwBz4B+AcACFwBCAgPCBcIogEYAR8IJwiAAC8INwg/CCADRwhPCFcIXwhnCEoDGgSAAIAAgABvCHcIeAh5CHoIewh8CH0Idwh4CHkIegh7CHwIfQh3CHgIeQh6CHsIfAh9CHcIeAh5CHoIewh8CH0Idwh4CHkIegh7CHwIfQh3CHgIeQh6CHsIfAh9CHcIeAh5CHoIewh8CH0Idwh4CHkIegh7CHwIfQh3CHgIeQh6CHsIfAh9CHcIeAh5CHoIewh8CH0Idwh4CHkIegh7CHwIfQh3CHgIeQh6CHsIfAh9CHcIeAh5CHoIewh8CH0Idwh4CHkIegh7CHwIfQh3CHgIeQh6CHsIfAh9CHcIeAh5CHoIewh8CH0Idwh4CHkIegh7CHwIfQh3CHgIeQh6CHsIfAh9CHcIeAh5CHoIewh8CH0Idwh4CHkIegh7CHwIfQh3CHgIeQh6CHsIfAh9CHcIeAh5CHoIewh8CH0Idwh4CHkIegh7CHwIfQh3CHgIeQh6CHsIfAh9CHcIeAh5CHoIewh8CH0Idwh4CHkIegh7CHwIfQh3CHgIeQh6CHsIfAh9CHcIeAh5CHoIewh8CH0Idwh4CHkIegh7CHwIfQh3CHgIeQh6CHsIfAh9CHcIeAh5CHoIewh8CH0Idwh4CHkIegh7CHwIfQh3CHgIeQh6CHsIfAh9CHcIeAh5CHoIewh8CH0Idwh4CHkIegh7CHwIfQh3CHgIeQh6CHsIfAh9CHcIeAh5CHoIewh8CH0Idwh4CHkIegh7CHwIfQh3CHgIeQh6CHsIfAh9CHcIeAh5CHoIewh8CH0Idwh4CHkIegh7CHwIfQh3CHgIeQh6CHsIfAh9CHcIeAh5CHoIewh8CH0Idwh4CHkIegh7CHwIfQh3CHgIeQh6CHsIfAh9CHcIeAh5CHoIewh8CH0Idwh4CHkIegh7CHwIfQh3CHgIeQh6CHsIfAh9CHcIeAh5CHoIewh8CH0Idwh4CHkIegh7CHwIhAiLCI4IMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwAJYIlgiWCJYIlgiWCJYIlgiWCJYIlgiWCJYIlgiWCJYIlgiWCJYIlgiWCJYIlgiWCJYIlgiWCJYIlgiWCJYIlggwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAANQc1BzUHNQc1BzUHNQc1BzUHNQc1B54INQc1B6II2gaqCLIIugiAAIAAvgjGCIAAgACAAIAAgACAAIAAgACAAIAAywiHAYAA0wiAANkI3QjlCO0I9Aj8CIAAgACAAAIJCgkSCRoJIgknCTYHLwk3CZYIlgiWCJYIlgiWCJYIlgiWCJYIlgiWCJYIlgiWCJYIlgiWCJYIlgiWCJYIlgiWCJYIlgiWCJYIlgiWCJYIlgiAAIAAAAFAAXgBeAGAAcABeAHwAQACQAKAArQC9AJ4AXgBeAE0A3gBRAN4A7AD8AMwBGgEAAKcBNwEFAUwBXAF4QkhCmEKnArcCgAHHAsABz4LAAcABwAHAAd+C6ABoAG+C/4LAAcABwAHAAc+DF4MAAcAB54M3gweDV4Nng3eDaABoAGgAaABoAGgAaABoAGgAaABoAGgAaABoAGgAaABoAGgAaABoAEeDqABVg6WDqABoQ6gAaABoAHXDvcONw/3DvcO9w73DvcO9w73DvcO9w73DvcO9w73DvcO9w73DvcO9w73DvcO9w73DvcO9w73DvcO9w73DvcO9w73DncPAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcAB7cPPwlGCU4JMACAAIAAgABWCV4JYQmAAGkJcAl4CXwJgAkwADAAMAAwAIgJgACLCZMJgACZCZ8JowmrCYAAswkwAF4AXgB8AIAAuwkABMMJyQmAAM4JgADVCTAAMAAwADAAgACAAIAAgACAAIAAgACAAIAAqwYWBNkIMAAwADAAMADdCeAJ6AnuCR4E9gkwAP4JBQoNCjAAMACAABUK0wiAAB0KJAosCjQKgAAwADwKQwqAAEsKvQmdCVMKWwowADAAgACAALcEMACAAGMKgABrCjAAMAAwADAAMAAwADAAMAAwADAAMAAeBDAAMAAwADAAMAAwADAAMAAwADAAMAAwAIkEPQFzCnoKiQSCCooKkAqJBJgKoAqkCokEGAGsCrQKvArBCjAAMADJCtEKFQHZCuEK/gHpCvEKMAAwADAAMACAAIwE+QowAIAAPwEBCzAAMAAwADAAMACAAAkLEQswAIAAPwEZCyELgAAOCCkLMAAxCzkLMAAwADAAMAAwADAAXgBeAEELMAAwADAAMAAwADAAMAAwAEkLTQtVC4AAXAtkC4AAiQkwADAAMAAwADAAMAAwADAAbAtxC3kLgAuFC4sLMAAwAJMLlwufCzAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAApwswADAAMACAAIAAgACvC4AAgACAAIAAgACAALcLMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAvwuAAMcLgACAAIAAgACAAIAAyguAAIAAgACAAIAA0QswADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAANkLgACAAIAA4AswADAAMAAwADAAMAAwADAAMAAwADAAMAAwAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACJCR4E6AswADAAhwHwC4AA+AsADAgMEAwwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMACAAIAAGAwdDCUMMAAwAC0MNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQw1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHPQwwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADUHNQc1BzUHNQc1BzUHNQc2BzAAMAA5DDUHNQc1BzUHNQc1BzUHNQc1BzUHNQdFDDAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAgACAAIAATQxSDFoMMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwAF4AXgBeAF4AXgBeAF4AYgxeAGoMXgBxDHkMfwxeAIUMXgBeAI0MMAAwADAAMAAwAF4AXgCVDJ0MMAAwADAAMABeAF4ApQxeAKsMswy7DF4Awgy9DMoMXgBeAF4AXgBeAF4AXgBeAF4AXgDRDNkMeQBqCeAM3Ax8AOYM7Az0DPgMXgBeAF4AXgBeAF4AXgBeAF4AXgBeAF4AXgBeAF4AXgCgAAANoAAHDQ4NFg0wADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAeDSYNMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwAIAAgACAAIAAgACAAC4NMABeAF4ANg0wADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwAD4NRg1ODVYNXg1mDTAAbQ0wADAAMAAwADAAMAAwADAA2gbaBtoG2gbaBtoG2gbaBnUNeg3CBYANwgWFDdoGjA3aBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gaUDZwNpA2oDdoG2gawDbcNvw3HDdoG2gbPDdYN3A3fDeYN2gbsDfMN2gbaBvoN/g3aBgYODg7aBl4AXgBeABYOXgBeACUG2gYeDl4AJA5eACwO2w3aBtoGMQ45DtoG2gbaBtoGQQ7aBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gZJDjUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1B1EO2gY1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQdZDjUHNQc1BzUHNQc1B2EONQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHaA41BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1B3AO2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gY1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1BzUHNQc1B2EO2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gZJDtoG2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gbaBtoG2gbaBkkOeA6gAKAAoAAwADAAMAAwAKAAoACgAKAAoACgAKAAgA4wADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAD//wQABAAEAAQABAAEAAQABAAEAA0AAwABAAEAAgAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAKABMAFwAeABsAGgAeABcAFgASAB4AGwAYAA8AGAAcAEsASwBLAEsASwBLAEsASwBLAEsAGAAYAB4AHgAeABMAHgBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAFgAbABIAHgAeAB4AUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQABYADQARAB4ABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsABAAEAAQABAAEAAUABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAkAFgAaABsAGwAbAB4AHQAdAB4ATwAXAB4ADQAeAB4AGgAbAE8ATwAOAFAAHQAdAB0ATwBPABcATwBPAE8AFgBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAHQAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB0AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgBQAB4AHgAeAB4AUABQAFAAUAAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAeAB4AHgAeAFAATwBAAE8ATwBPAEAATwBQAFAATwBQAB4AHgAeAB4AHgAeAB0AHQAdAB0AHgAdAB4ADgBQAFAAUABQAFAAHgAeAB4AHgAeAB4AHgBQAB4AUAAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4ABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAJAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAkACQAJAAkACQAJAAkABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAeAB4AHgAeAFAAHgAeAB4AKwArAFAAUABQAFAAGABQACsAKwArACsAHgAeAFAAHgBQAFAAUAArAFAAKwAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AKwAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4ABAAEAAQABAAEAAQABAAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAUAAeAB4AHgAeAB4AHgArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwAYAA0AKwArAB4AHgAbACsABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQADQAEAB4ABAAEAB4ABAAEABMABAArACsAKwArACsAKwArACsAVgBWAFYAVgBWAFYAVgBWAFYAVgBWAFYAVgBWAFYAVgBWAFYAVgBWAFYAVgBWAFYAVgBWAFYAKwArACsAKwArAFYAVgBWAB4AHgArACsAKwArACsAKwArACsAKwArACsAHgAeAB4AHgAeAB4AHgAeAB4AGgAaABoAGAAYAB4AHgAEAAQABAAEAAQABAAEAAQABAAEAAQAEwAEACsAEwATAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABABLAEsASwBLAEsASwBLAEsASwBLABoAGQAZAB4AUABQAAQAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQABMAUAAEAAQABAAEAAQABAAEAB4AHgAEAAQABAAEAAQABABQAFAABAAEAB4ABAAEAAQABABQAFAASwBLAEsASwBLAEsASwBLAEsASwBQAFAAUAAeAB4AUAAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AKwAeAFAABABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAABAAEAAQABAAEAAQABAAEAAQABAAEAFAAKwArACsAKwArACsAKwArACsAKwArACsAKwArAEsASwBLAEsASwBLAEsASwBLAEsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAABAAEAAQABAAEAAQABAAEAAQAUABQAB4AHgAYABMAUAArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAFAABAAEAAQABAAEAFAABAAEAAQAUAAEAAQABAAEAAQAKwArAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAArACsAHgArAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAeAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABABQAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAFAABAAEAAQABAAEAAQABABQAFAAUABQAFAAUABQAFAAUABQAAQABAANAA0ASwBLAEsASwBLAEsASwBLAEsASwAeAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAABAAEAAQAKwBQAFAAUABQAFAAUABQAFAAKwArAFAAUAArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAUABQAFAAUABQAFAAUAArAFAAKwArACsAUABQAFAAUAArACsABABQAAQABAAEAAQABAAEAAQAKwArAAQABAArACsABAAEAAQAUAArACsAKwArACsAKwArACsABAArACsAKwArAFAAUAArAFAAUABQAAQABAArACsASwBLAEsASwBLAEsASwBLAEsASwBQAFAAGgAaAFAAUABQAFAAUABMAB4AGwBQAB4AKwArACsABAAEAAQAKwBQAFAAUABQAFAAUAArACsAKwArAFAAUAArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAUABQAFAAUABQAFAAUAArAFAAUAArAFAAUAArAFAAUAArACsABAArAAQABAAEAAQABAArACsAKwArAAQABAArACsABAAEAAQAKwArACsABAArACsAKwArACsAKwArAFAAUABQAFAAKwBQACsAKwArACsAKwArACsASwBLAEsASwBLAEsASwBLAEsASwAEAAQAUABQAFAABAArACsAKwArACsAKwArACsAKwArACsABAAEAAQAKwBQAFAAUABQAFAAUABQAFAAUAArAFAAUABQACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAUABQAFAAUABQAFAAUAArAFAAUAArAFAAUABQAFAAUAArACsABABQAAQABAAEAAQABAAEAAQABAArAAQABAAEACsABAAEAAQAKwArAFAAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAUABQAAQABAArACsASwBLAEsASwBLAEsASwBLAEsASwAeABsAKwArACsAKwArACsAKwBQAAQABAAEAAQABAAEACsABAAEAAQAKwBQAFAAUABQAFAAUABQAFAAKwArAFAAUAArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQAKwArAAQABAArACsABAAEAAQAKwArACsAKwArACsAKwArAAQABAArACsAKwArAFAAUAArAFAAUABQAAQABAArACsASwBLAEsASwBLAEsASwBLAEsASwAeAFAAUABQAFAAUABQAFAAKwArACsAKwArACsAKwArACsAKwAEAFAAKwBQAFAAUABQAFAAUAArACsAKwBQAFAAUAArAFAAUABQAFAAKwArACsAUABQACsAUAArAFAAUAArACsAKwBQAFAAKwArACsAUABQAFAAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArACsAKwAEAAQABAAEAAQAKwArACsABAAEAAQAKwAEAAQABAAEACsAKwBQACsAKwArACsAKwArAAQAKwArACsAKwArACsAKwArACsAKwBLAEsASwBLAEsASwBLAEsASwBLAFAAUABQAB4AHgAeAB4AHgAeABsAHgArACsAKwArACsABAAEAAQABAArAFAAUABQAFAAUABQAFAAUAArAFAAUABQACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArAFAABAAEAAQABAAEAAQABAArAAQABAAEACsABAAEAAQABAArACsAKwArACsAKwArAAQABAArAFAAUABQACsAKwArACsAKwBQAFAABAAEACsAKwBLAEsASwBLAEsASwBLAEsASwBLACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQAB4AUAAEAAQABAArAFAAUABQAFAAUABQAFAAUAArAFAAUABQACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwBQAFAAUABQAFAAUABQAFAAUABQACsAUABQAFAAUABQACsAKwAEAFAABAAEAAQABAAEAAQABAArAAQABAAEACsABAAEAAQABAArACsAKwArACsAKwArAAQABAArACsAKwArACsAKwArAFAAKwBQAFAABAAEACsAKwBLAEsASwBLAEsASwBLAEsASwBLACsAUABQACsAKwArACsAKwArACsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAABAAEAFAABAAEAAQABAAEAAQABAArAAQABAAEACsABAAEAAQABABQAB4AKwArACsAKwBQAFAAUAAEAFAAUABQAFAAUABQAFAAUABQAFAABAAEACsAKwBLAEsASwBLAEsASwBLAEsASwBLAFAAUABQAFAAUABQAFAAUABQABoAUABQAFAAUABQAFAAKwArAAQABAArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArAFAAUABQAFAAUABQAFAAUABQACsAUAArACsAUABQAFAAUABQAFAAUAArACsAKwAEACsAKwArACsABAAEAAQABAAEAAQAKwAEACsABAAEAAQABAAEAAQABAAEACsAKwArACsAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArAAQABAAeACsAKwArACsAKwArACsAKwArACsAKwArAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXAAqAFwAXAAqACoAKgAqACoAKgAqACsAKwArACsAGwBcAFwAXABcAFwAXABcACoAKgAqACoAKgAqACoAKgAeAEsASwBLAEsASwBLAEsASwBLAEsADQANACsAKwArACsAKwBcAFwAKwBcACsAKwBcAFwAKwBcACsAKwBcACsAKwArACsAKwArAFwAXABcAFwAKwBcAFwAXABcAFwAXABcACsAXABcAFwAKwBcACsAXAArACsAXABcACsAXABcAFwAXAAqAFwAXAAqACoAKgAqACoAKgArACoAKgBcACsAKwBcAFwAXABcAFwAKwBcACsAKgAqACoAKgAqACoAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArAFwAXABcAFwAUAAOAA4ADgAOAB4ADgAOAAkADgAOAA0ACQATABMAEwATABMACQAeABMAHgAeAB4ABAAEAB4AHgAeAB4AHgAeAEsASwBLAEsASwBLAEsASwBLAEsAUABQAFAAUABQAFAAUABQAFAAUAANAAQAHgAEAB4ABAAWABEAFgARAAQABABQAFAAUABQAFAAUABQAFAAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAANAAQABAAEAAQABAANAAQABABQAFAAUABQAFAABAAEAAQABAAEAAQABAAEAAQABAAEACsABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEACsADQANAB4AHgAeAB4AHgAeAAQAHgAeAB4AHgAeAB4AKwAeAB4ADgAOAA0ADgAeAB4AHgAeAB4ACQAJACsAKwArACsAKwBcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqAFwASwBLAEsASwBLAEsASwBLAEsASwANAA0AHgAeAB4AHgBcAFwAXABcAFwAXAAqACoAKgAqAFwAXABcAFwAKgAqACoAXAAqACoAKgBcAFwAKgAqACoAKgAqACoAKgBcAFwAXAAqACoAKgAqAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAKgAqACoAKgAqACoAKgAqACoAKgAqACoAXAAqAEsASwBLAEsASwBLAEsASwBLAEsAKgAqACoAKgAqACoAUABQAFAAUABQAFAAKwBQACsAKwArACsAKwBQACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAeAFAAUABQAFAAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFkAWQBZAFkAWQBZAFkAWQBZAFkAWQBZAFkAWQBZAFkAWQBZAFkAWQBZAFkAWQBZAFkAWQBZAFkAWQBZAFkAWQBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAUABQAFAAUABQAFAAUABQAFAAKwBQAFAAUABQACsAKwBQAFAAUABQAFAAUABQACsAUAArAFAAUABQAFAAKwArAFAAUABQAFAAUABQAFAAUABQACsAUABQAFAAUAArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAUABQAFAAUAArACsAUABQAFAAUABQAFAAUAArAFAAKwBQAFAAUABQACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArAFAAUABQAFAAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwAEAAQABAAeAA0AHgAeAB4AHgAeAB4AHgBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAeAB4AHgAeAB4AHgAeAB4AHgAeACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArAFAAUABQAFAAUABQACsAKwANAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAeAB4AUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAA0AUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQABYAEQArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAADQANAA0AUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArAFAAUABQAFAABAAEAAQAKwArACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAQABAAEAA0ADQArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQAKwArACsAKwArACsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArAFAAUABQACsABAAEACsAKwArACsAKwArACsAKwArACsAKwArAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXAAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoADQANABUAXAANAB4ADQAbAFwAKgArACsASwBLAEsASwBLAEsASwBLAEsASwArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQACsAKwArACsAKwArAB4AHgATABMADQANAA4AHgATABMAHgAEAAQABAAJACsASwBLAEsASwBLAEsASwBLAEsASwArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArACsAUABQAFAAUABQAAQABABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAABABQACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArACsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArAAQABAAEAAQABAAEAAQABAAEAAQABAAEACsAKwArACsABAAEAAQABAAEAAQABAAEAAQABAAEAAQAKwArACsAKwAeACsAKwArABMAEwBLAEsASwBLAEsASwBLAEsASwBLAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcACsAKwBcAFwAXABcAFwAKwArACsAKwArACsAKwArACsAKwArAFwAXABcAFwAXABcAFwAXABcAFwAXABcACsAKwArACsAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAKwArACsAKwArACsASwBLAEsASwBLAEsASwBLAEsASwBcACsAKwArACoAKgBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAABAAEAAQABAAEACsAKwAeAB4AXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAKgAqACoAKgAqACoAKgAqACoAKgArACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgArACsABABLAEsASwBLAEsASwBLAEsASwBLACsAKwArACsAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwArACsAKgAqACoAKgAqACoAKgBcACoAKgAqACoAKgAqACsAKwAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAArAAQABAAEAAQABABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQAUABQAFAAUABQAFAAUAArACsAKwArAEsASwBLAEsASwBLAEsASwBLAEsADQANAB4ADQANAA0ADQAeAB4AHgAeAB4AHgAeAB4AHgAeAAQABAAEAAQABAAEAAQABAAEAB4AHgAeAB4AHgAeAB4AHgAeACsAKwArAAQABAAEAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQAUABQAEsASwBLAEsASwBLAEsASwBLAEsAUABQAFAAUABQAFAAUABQAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAArACsAKwArACsAKwArACsAHgAeAB4AHgBQAFAAUABQAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAArACsAKwANAA0ADQANAA0ASwBLAEsASwBLAEsASwBLAEsASwArACsAKwBQAFAAUABLAEsASwBLAEsASwBLAEsASwBLAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAANAA0AUABQAFAAUABQAFAAUABQAFAAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAB4AHgAeAB4AHgAeAB4AHgArACsAKwArACsAKwArACsABAAEAAQAHgAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAFAAUABQAFAABABQAFAAUABQAAQABAAEAFAAUAAEAAQABAArACsAKwArACsAKwAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQAKwAEAAQABAAEAAQAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgArACsAUABQAFAAUABQAFAAKwArAFAAUABQAFAAUABQAFAAUAArAFAAKwBQACsAUAArAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AKwArAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeACsAHgAeAB4AHgAeAB4AHgAeAFAAHgAeAB4AUABQAFAAKwAeAB4AHgAeAB4AHgAeAB4AHgAeAFAAUABQAFAAKwArAB4AHgAeAB4AHgAeACsAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgArACsAUABQAFAAKwAeAB4AHgAeAB4AHgAeAA4AHgArAA0ADQANAA0ADQANAA0ACQANAA0ADQAIAAQACwAEAAQADQAJAA0ADQAMAB0AHQAeABcAFwAWABcAFwAXABYAFwAdAB0AHgAeABQAFAAUAA0AAQABAAQABAAEAAQABAAJABoAGgAaABoAGgAaABoAGgAeABcAFwAdABUAFQAeAB4AHgAeAB4AHgAYABYAEQAVABUAFQAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgANAB4ADQANAA0ADQAeAA0ADQANAAcAHgAeAB4AHgArAAQABAAEAAQABAAEAAQABAAEAAQAUABQACsAKwBPAFAAUABQAFAAUAAeAB4AHgAWABEATwBQAE8ATwBPAE8AUABQAFAAUABQAB4AHgAeABYAEQArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArACsAGwAbABsAGwAbABsAGwAaABsAGwAbABsAGwAbABsAGwAbABsAGwAbABsAGwAaABsAGwAbABsAGgAbABsAGgAbABsAGwAbABsAGwAbABsAGwAbABsAGwAbABsAGwAbABsABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAB4AHgBQABoAHgAdAB4AUAAeABoAHgAeAB4AHgAeAB4AHgAeAB4ATwAeAFAAGwAeAB4AUABQAFAAUABQAB4AHgAeAB0AHQAeAFAAHgBQAB4AUAAeAFAATwBQAFAAHgAeAB4AHgAeAB4AHgBQAFAAUABQAFAAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgBQAB4AUABQAFAAUABPAE8AUABQAFAAUABQAE8AUABQAE8AUABPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBQAFAAUABQAE8ATwBPAE8ATwBPAE8ATwBPAE8AUABQAFAAUABQAFAAUABQAFAAHgAeAFAAUABQAFAATwAeAB4AKwArACsAKwAdAB0AHQAdAB0AHQAdAB0AHQAdAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAdAB4AHQAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHQAeAB0AHQAeAB4AHgAdAB0AHgAeAB0AHgAeAB4AHQAeAB0AGwAbAB4AHQAeAB4AHgAeAB0AHgAeAB0AHQAdAB0AHgAeAB0AHgAdAB4AHQAdAB0AHQAdAB0AHgAdAB4AHgAeAB4AHgAdAB0AHQAdAB4AHgAeAB4AHQAdAB4AHgAeAB4AHgAeAB4AHgAeAB4AHQAeAB4AHgAdAB4AHgAeAB4AHgAdAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHQAdAB4AHgAdAB0AHQAdAB4AHgAdAB0AHgAeAB0AHQAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAdAB0AHgAeAB0AHQAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB0AHgAeAB4AHQAeAB4AHgAeAB4AHgAeAB0AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAdAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeABQAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAWABEAFgARAB4AHgAeAB4AHgAeAB0AHgAeAB4AHgAeAB4AHgAlACUAHgAeAB4AHgAeAB4AHgAeAB4AFgARAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeACUAJQAlACUAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBQAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB4AHgAeAB4AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHgAeAB0AHQAdAB0AHgAeAB4AHgAeAB4AHgAeAB4AHgAdAB0AHgAdAB0AHQAdAB0AHQAdAB4AHgAeAB4AHgAeAB4AHgAdAB0AHgAeAB0AHQAeAB4AHgAeAB0AHQAeAB4AHgAeAB0AHQAdAB4AHgAdAB4AHgAdAB0AHQAdAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHQAdAB0AHQAeAB4AHgAeAB4AHgAeAB4AHgAdAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AJQAlACUAJQAeAB0AHQAeAB4AHQAeAB4AHgAeAB0AHQAeAB4AHgAeACUAJQAdAB0AJQAeACUAJQAlACAAJQAlAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AJQAlACUAHgAeAB4AHgAdAB4AHQAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHQAdAB4AHQAdAB0AHgAdACUAHQAdAB4AHQAdAB4AHQAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAlAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB0AHQAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AJQAlACUAJQAlACUAJQAlACUAJQAlACUAHQAdAB0AHQAlAB4AJQAlACUAHQAlACUAHQAdAB0AJQAlAB0AHQAlAB0AHQAlACUAJQAeAB0AHgAeAB4AHgAdAB0AJQAdAB0AHQAdAB0AHQAlACUAJQAlACUAHQAlACUAIAAlAB0AHQAlACUAJQAlACUAJQAlACUAHgAeAB4AJQAlACAAIAAgACAAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAdAB4AHgAeABcAFwAXABcAFwAXAB4AEwATACUAHgAeAB4AFgARABYAEQAWABEAFgARABYAEQAWABEAFgARAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAWABEAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AFgARABYAEQAWABEAFgARABYAEQAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeABYAEQAWABEAFgARABYAEQAWABEAFgARABYAEQAWABEAFgARABYAEQAWABEAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AFgARABYAEQAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeABYAEQAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHQAdAB0AHQAdAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AKwArAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AKwArACsAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AKwAeAB4AHgAeAB4AHgAeAB4AHgArACsAKwArACsAKwArACsAKwArACsAKwArAB4AHgAeAB4AKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAEAAQABAAeAB4AKwArACsAKwArABMADQANAA0AUAATAA0AUABQAFAAUABQAFAAUABQACsAKwArACsAKwArACsAUAANACsAKwArACsAKwArACsAKwArACsAKwArACsAKwAEAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQACsAUABQAFAAUABQAFAAUAArAFAAUABQAFAAUABQAFAAKwBQAFAAUABQAFAAUABQACsAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXAA0ADQANAA0ADQANAA0ADQAeAA0AFgANAB4AHgAXABcAHgAeABcAFwAWABEAFgARABYAEQAWABEADQANAA0ADQATAFAADQANAB4ADQANAB4AHgAeAB4AHgAMAAwADQANAA0AHgANAA0AFgANAA0ADQANAA0ADQANACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACsAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAKwArACsAKwArACsAKwArACsAKwArACsAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwAlACUAJQAlACUAJQAlACUAJQAlACUAJQArACsAKwArAA0AEQARACUAJQBHAFcAVwAWABEAFgARABYAEQAWABEAFgARACUAJQAWABEAFgARABYAEQAWABEAFQAWABEAEQAlAFcAVwBXAFcAVwBXAFcAVwBXAAQABAAEAAQABAAEACUAVwBXAFcAVwA2ACUAJQBXAFcAVwBHAEcAJQAlACUAKwBRAFcAUQBXAFEAVwBRAFcAUQBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFEAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBRAFcAUQBXAFEAVwBXAFcAVwBXAFcAUQBXAFcAVwBXAFcAVwBRAFEAKwArAAQABAAVABUARwBHAFcAFQBRAFcAUQBXAFEAVwBRAFcAUQBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFEAVwBRAFcAUQBXAFcAVwBXAFcAVwBRAFcAVwBXAFcAVwBXAFEAUQBXAFcAVwBXABUAUQBHAEcAVwArACsAKwArACsAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAKwArAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwArACUAJQBXAFcAVwBXACUAJQAlACUAJQAlACUAJQAlACUAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAKwArACsAKwArACUAJQAlACUAKwArACsAKwArACsAKwArACsAKwArACsAUQBRAFEAUQBRAFEAUQBRAFEAUQBRAFEAUQBRAFEAUQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACsAVwBXAFcAVwBXAFcAVwBXAFcAVwAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlAE8ATwBPAE8ATwBPAE8ATwAlAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXACUAJQAlACUAJQAlACUAJQAlACUAVwBXAFcAVwBXAFcAVwBXAFcAVwBXACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAEcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAKwArACsAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAADQATAA0AUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABLAEsASwBLAEsASwBLAEsASwBLAFAAUAArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAFAABAAEAAQABAAeAAQABAAEAAQABAAEAAQABAAEAAQAHgBQAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AUABQAAQABABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAQABAAeAA0ADQANAA0ADQArACsAKwArACsAKwArACsAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAFAAUABQAFAAUABQAFAAUABQAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AUAAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgBQAB4AHgAeAB4AHgAeAFAAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgArAB4AHgAeAB4AHgAeAB4AHgArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAAQAUABQAFAABABQAFAAUABQAAQAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAQABAAEAAQABAAeAB4AHgAeACsAKwArACsAUABQAFAAUABQAFAAHgAeABoAHgArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAADgAOABMAEwArACsAKwArACsAKwArACsABAAEAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAQABAAEAAQABAAEACsAKwArACsAKwArACsAKwANAA0ASwBLAEsASwBLAEsASwBLAEsASwArACsAKwArACsAKwAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABABQAFAAUABQAFAAUAAeAB4AHgBQAA4AUAArACsAUABQAFAAUABQAFAABAAEAAQABAAEAAQABAAEAA0ADQBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQAKwArACsAKwArACsAKwArACsAKwArAB4AWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYACsAKwArAAQAHgAeAB4AHgAeAB4ADQANAA0AHgAeAB4AHgArAFAASwBLAEsASwBLAEsASwBLAEsASwArACsAKwArAB4AHgBcAFwAXABcAFwAKgBcAFwAXABcAFwAXABcAFwAXABcAEsASwBLAEsASwBLAEsASwBLAEsAXABcAFwAXABcACsAUABQAFAAUABQAFAAUABQAFAABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEACsAKwArACsAKwArACsAKwArAFAAUABQAAQAUABQAFAAUABQAFAAUABQAAQABAArACsASwBLAEsASwBLAEsASwBLAEsASwArACsAHgANAA0ADQBcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAKgAqACoAXAAqACoAKgBcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXAAqAFwAKgAqACoAXABcACoAKgBcAFwAXABcAFwAKgAqAFwAKgBcACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAFwAXABcACoAKgBQAFAAUABQAFAAUABQAFAAUABQAFAABAAEAAQABAAEAA0ADQBQAFAAUAAEAAQAKwArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUAArACsAUABQAFAAUABQAFAAKwArAFAAUABQAFAAUABQACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAKwBQAFAAUABQAFAAUABQACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQABAAEAAQADQAEAAQAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwArACsAVABVAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBUAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBVACsAKwArACsAKwArACsAKwArACsAKwArAFkAWQBZAFkAWQBZAFkAWQBZAFkAWQBZAFkAWQBZAFkAWQBZAFkAKwArACsAKwBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAKwArACsAKwAGAAYABgAGAAYABgAGAAYABgAGAAYABgAGAAYABgAGAAYABgAGAAYABgAGAAYABgAGAAYABgAGAAYABgAGAAYAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXACUAJQBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAJQAlACUAJQAlACUAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAKwArACsAKwArAFYABABWAFYAVgBWAFYAVgBWAFYAVgBWAB4AVgBWAFYAVgBWAFYAVgBWAFYAVgBWAFYAVgArAFYAVgBWAFYAVgArAFYAKwBWAFYAKwBWAFYAKwBWAFYAVgBWAFYAVgBWAFYAVgBWAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAEQAWAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUAAaAB4AKwArAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQAGAARABEAGAAYABMAEwAWABEAFAArACsAKwArACsAKwAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEACUAJQAlACUAJQAWABEAFgARABYAEQAWABEAFgARABYAEQAlACUAFgARACUAJQAlACUAJQAlACUAEQAlABEAKwAVABUAEwATACUAFgARABYAEQAWABEAJQAlACUAJQAlACUAJQAlACsAJQAbABoAJQArACsAKwArAFAAUABQAFAAUAArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArAAcAKwATACUAJQAbABoAJQAlABYAEQAlACUAEQAlABEAJQBXAFcAVwBXAFcAVwBXAFcAVwBXABUAFQAlACUAJQATACUAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXABYAJQARACUAJQAlAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwAWACUAEQAlABYAEQARABYAEQARABUAVwBRAFEAUQBRAFEAUQBRAFEAUQBRAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAEcARwArACsAVwBXAFcAVwBXAFcAKwArAFcAVwBXAFcAVwBXACsAKwBXAFcAVwBXAFcAVwArACsAVwBXAFcAKwArACsAGgAbACUAJQAlABsAGwArAB4AHgAeAB4AHgAeAB4AKwArACsAKwArACsAKwArACsAKwAEAAQABAAQAB0AKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwBQAFAAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsADQANAA0AKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArAB4AHgAeAB4AHgAeAB4AHgAeAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgBQAFAAHgAeAB4AKwAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgArACsAKwArAB4AKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4ABAArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAAQAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArACsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsADQBQAFAAUABQACsAKwArACsAUABQAFAAUABQAFAAUABQAA0AUABQAFAAUABQACsAKwArACsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArACsAKwArACsAKwArACsAKwArAB4AKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUAArACsAUAArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAUABQACsAKwArAFAAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArAA0AUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAB4AHgBQAFAAUABQAFAAUABQACsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAUABQACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArACsADQBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArACsAKwArAB4AUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArACsAKwBQAFAAUABQAFAABAAEAAQAKwAEAAQAKwArACsAKwArAAQABAAEAAQAUABQAFAAUAArAFAAUABQACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArACsABAAEAAQAKwArACsAKwAEAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArACsADQANAA0ADQANAA0ADQANAB4AKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAB4AUABQAFAAUABQAFAAUABQAB4AUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAABAAEACsAKwArACsAUABQAFAAUABQAA0ADQANAA0ADQANABQAKwArACsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwANAA0ADQANAA0ADQANAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArACsAKwArACsAHgAeAB4AHgArACsAKwArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArACsAKwArACsAKwBQAFAAUABQAFAAUAAEAAQABAAEAAQABAAEAA0ADQAeAB4AHgAeAB4AKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsABABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAQABAAEAAQABAAEAAQABAAEAAQABAAeAB4AHgANAA0ADQANACsAKwArACsAKwArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArACsAKwArACsAKwBLAEsASwBLAEsASwBLAEsASwBLACsAKwArACsAKwArAFAAUABQAFAAUABQAFAABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEACsASwBLAEsASwBLAEsASwBLAEsASwANAA0ADQANACsAKwArACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAABAAeAA4AUAArACsAKwArACsAKwArACsAKwAEAFAAUABQAFAADQANAB4ADQAeAAQABAAEAB4AKwArAEsASwBLAEsASwBLAEsASwBLAEsAUAAOAFAADQANAA0AKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQABAAEAAQABAAEAAQABAANAA0AHgANAA0AHgAEACsAUABQAFAAUABQAFAAUAArAFAAKwBQAFAAUABQACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwBQAFAAUABQAFAAUABQAFAAUABQAA0AKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQABAAEAAQABAAEAAQAKwArACsAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwArACsABAAEAAQABAArAFAAUABQAFAAUABQAFAAUAArACsAUABQACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAQABAAEAAQABAArACsABAAEACsAKwAEAAQABAArACsAUAArACsAKwArACsAKwAEACsAKwArACsAKwBQAFAAUABQAFAABAAEACsAKwAEAAQABAAEAAQABAAEACsAKwArAAQABAAEAAQABAArACsAKwArACsAKwArACsAKwArACsABAAEAAQABAAEAAQABABQAFAAUABQAA0ADQANAA0AHgBLAEsASwBLAEsASwBLAEsASwBLACsADQArAB4AKwArAAQABAAEAAQAUABQAB4AUAArACsAKwArACsAKwArACsASwBLAEsASwBLAEsASwBLAEsASwArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQABAAEACsAKwAEAAQABAAEAAQABAAEAAQABAAOAA0ADQATABMAHgAeAB4ADQANAA0ADQANAA0ADQANAA0ADQANAA0ADQANAA0AUABQAFAAUAAEAAQAKwArAAQADQANAB4AUAArACsAKwArACsAKwArACsAKwArACsASwBLAEsASwBLAEsASwBLAEsASwArACsAKwArACsAKwAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsASwBLAEsASwBLAEsASwBLAEsASwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXAArACsAKwAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgArACsAKwArAEsASwBLAEsASwBLAEsASwBLAEsAXABcAA0ADQANACoASwBLAEsASwBLAEsASwBLAEsASwBQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwArACsAKwBQAFAABAAEAAQABAAEAAQABAAEAAQABABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQABAAEAFAABAAEAAQABAAOAB4ADQANAA0ADQAOAB4ABAArACsAKwArACsAKwArACsAUAAEAAQABAAEAAQABAAEAAQABAAEAAQAUABQAFAAUAArACsAUABQAFAAUAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAA0ADQANACsADgAOAA4ADQANACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUAArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAABAAEAAQABAAEAAQABAAEACsABAAEAAQABAAEAAQABAAEAFAADQANAA0ADQANACsAKwArACsAKwArACsAKwArACsASwBLAEsASwBLAEsASwBLAEsASwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwAOABMAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAArAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQACsAUABQACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQABAArACsAKwAEACsABAAEACsABAAEAAQABAAEAAQABABQAAQAKwArACsAKwArACsAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsADQANAA0ADQANACsAKwArACsAKwArACsAKwArACsAKwBQAFAAUABQACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAASABIAEgAQwBDAEMAUABQAFAAUABDAFAAUABQAEgAQwBIAEMAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAASABDAEMAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABIAEMAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwANAA0AKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArAAQABAAEAAQABAANACsAKwArACsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQABAAEAA0ADQANAB4AHgAeAB4AHgAeAFAAUABQAFAADQAeACsAKwArACsAKwArACsAKwArACsASwBLAEsASwBLAEsASwBLAEsASwArAFAAUABQAFAAUABQAFAAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwArACsAUAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsABAAEAAQABABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAEcARwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwArACsAKwArACsAKwArACsAKwArACsAKwArAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQACsAKwAeAAQABAANAAQABAAEAAQAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeACsAKwArACsAKwArACsAKwArACsAHgAeAB4AHgAeAB4AHgArACsAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4ABAAEAAQABAAEAB4AHgAeAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQAHgAeAAQABAAEAAQABAAEAAQAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAEAAQABAAEAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAB4AHgAEAAQABAAeACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AKwArACsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArACsAKwArACsAKwArACsAKwArACsAKwArAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeACsAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgArAFAAUAArACsAUAArACsAUABQACsAKwBQAFAAUABQACsAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AKwBQACsAUABQAFAAUABQAFAAUAArAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgArAFAAUABQAFAAKwArAFAAUABQAFAAUABQAFAAUAArAFAAUABQAFAAUABQAFAAKwAeAB4AUABQAFAAUABQACsAUAArACsAKwBQAFAAUABQAFAAUABQACsAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAeAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAFAAUABQAFAAUABQAFAAUABQAFAAUAAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAHgAeAB4AHgAeAB4AHgAeAB4AKwArAEsASwBLAEsASwBLAEsASwBLAEsASwBLAEsASwBLAEsASwBLAEsASwBLAEsASwBLAEsASwBLAEsASwBLAEsASwBLAEsABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAB4AHgAeAB4ABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAB4AHgAeAB4AHgAeAB4AHgAEAB4AHgAeAB4AHgAeAB4AHgAeAB4ABAAeAB4ADQANAA0ADQAeACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAAQABAAEAAQABAArAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsABAAEAAQABAAEAAQABAArAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAArACsABAAEAAQABAAEAAQABAArAAQABAArAAQABAAEAAQABAArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAKwArAFAAUABQAFAAUABQAFAAUABQAAQABAAEAAQABAAEAAQAKwArACsAKwArACsAKwArACsAHgAeAB4AHgAEAAQABAAEAAQABAAEACsAKwArACsAKwBLAEsASwBLAEsASwBLAEsASwBLACsAKwArACsAFgAWAFAAUABQAFAAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArAFAAUAArAFAAKwArAFAAKwBQAFAAUABQAFAAUABQAFAAUABQACsAUABQAFAAUAArAFAAKwBQACsAKwArACsAKwArAFAAKwArACsAKwBQACsAUAArAFAAKwBQAFAAUAArAFAAUAArAFAAKwArAFAAKwBQACsAUAArAFAAKwBQACsAUABQACsAUAArACsAUABQAFAAUAArAFAAUABQAFAAUABQAFAAKwBQAFAAUABQACsAUABQAFAAUAArAFAAKwBQAFAAUABQAFAAUABQAFAAUABQACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArACsAKwBQAFAAUAArAFAAUABQAFAAUAArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAB4AHgArACsAKwArACsAKwArACsAKwArACsAKwArACsATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwAlACUAJQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAeACUAHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHgAeACUAJQAlACUAHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACkAKQApACkAKQApACkAKQApACkAKQApACkAKQApACkAKQApACkAKQApACkAKQApACkAKQAlACUAJQAlACUAIAAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlAB4AHgAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAHgAeACUAJQAlACUAJQAeACUAJQAlACUAJQAgACAAIAAlACUAIAAlACUAIAAgACAAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAIQAhACEAIQAhACUAJQAgACAAJQAlACAAIAAgACAAIAAgACAAIAAgACAAIAAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAIAAgACAAIAAlACUAJQAlACAAJQAgACAAIAAgACAAIAAgACAAIAAlACUAJQAgACUAJQAlACUAIAAgACAAJQAgACAAIAAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAeACUAHgAlAB4AJQAlACUAJQAlACAAJQAlACUAJQAeACUAHgAeACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAHgAeAB4AHgAeAB4AHgAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlAB4AHgAeAB4AHgAeAB4AHgAeAB4AJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAIAAgACUAJQAlACUAIAAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAIAAlACUAJQAlACAAIAAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAeAB4AHgAeAB4AHgAeAB4AJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlAB4AHgAeAB4AHgAeACUAJQAlACUAJQAlACUAIAAgACAAJQAlACUAIAAgACAAIAAgAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AFwAXABcAFQAVABUAHgAeAB4AHgAlACUAJQAgACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAIAAgACAAJQAlACUAJQAlACUAJQAlACUAIAAlACUAJQAlACUAJQAlACUAJQAlACUAIAAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAlACUAJQAlACUAJQAlACUAJQAlACUAJQAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAlACUAJQAlAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AJQAlACUAJQAlACUAJQAlAB4AHgAeAB4AHgAeAB4AHgAeAB4AJQAlACUAJQAlACUAHgAeAB4AHgAeAB4AHgAeACUAJQAlACUAJQAlACUAJQAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeACUAJQAlACUAJQAlACUAJQAlACUAJQAlACAAIAAgACAAIAAlACAAIAAlACUAJQAlACUAJQAgACUAJQAlACUAJQAlACUAJQAlACAAIAAgACAAIAAgACAAIAAgACAAJQAlACUAIAAgACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACsAKwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAJQAlACUAJQAlACUAJQAlACUAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAJQAlACUAJQAlACUAJQAlACUAJQAlAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQArAAQAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsA';
      /* @flow */

      var LETTER_NUMBER_MODIFIER = 50; // Non-tailorable Line Breaking Classes

      var BK = 1; //  Cause a line break (after)

      var CR = 2; //  Cause a line break (after), except between CR and LF

      var LF = 3; //  Cause a line break (after)

      var CM = 4; //  Prohibit a line break between the character and the preceding character

      var NL = 5; //  Cause a line break (after)

      var WJ = 7; //  Prohibit line breaks before and after

      var ZW = 8; //  Provide a break opportunity

      var GL = 9; //  Prohibit line breaks before and after

      var SP = 10; // Enable indirect line breaks

      var ZWJ = 11; // Prohibit line breaks within joiner sequences
      // Break Opportunities

      var B2 = 12; //  Provide a line break opportunity before and after the character

      var BA = 13; //  Generally provide a line break opportunity after the character

      var BB = 14; //  Generally provide a line break opportunity before the character

      var HY = 15; //  Provide a line break opportunity after the character, except in numeric context

      var CB = 16; //   Provide a line break opportunity contingent on additional information
      // Characters Prohibiting Certain Breaks

      var CL = 17; //  Prohibit line breaks before

      var CP = 18; //  Prohibit line breaks before

      var EX = 19; //  Prohibit line breaks before

      var IN = 20; //  Allow only indirect line breaks between pairs

      var NS = 21; //  Allow only indirect line breaks before

      var OP = 22; //  Prohibit line breaks after

      var QU = 23; //  Act like they are both opening and closing
      // Numeric Context

      var IS = 24; //  Prevent breaks after any and before numeric

      var NU = 25; //  Form numeric expressions for line breaking purposes

      var PO = 26; //  Do not break following a numeric expression

      var PR = 27; //  Do not break in front of a numeric expression

      var SY = 28; //  Prevent a break before; and allow a break after
      // Other Characters

      var AI = 29; //  Act like AL when the resolvedEAW is N; otherwise; act as ID

      var AL = 30; //  Are alphabetic characters or symbols that are used with alphabetic characters

      var CJ = 31; //  Treat as NS or ID for strict or normal breaking.

      var EB = 32; //  Do not break from following Emoji Modifier

      var EM = 33; //  Do not break from preceding Emoji Base

      var H2 = 34; //  Form Korean syllable blocks

      var H3 = 35; //  Form Korean syllable blocks

      var HL = 36; //  Do not break around a following hyphen; otherwise act as Alphabetic

      var ID = 37; //  Break before or after; except in some numeric context

      var JL = 38; //  Form Korean syllable blocks

      var JV = 39; //  Form Korean syllable blocks

      var JT = 40; //  Form Korean syllable blocks

      var RI = 41; //  Keep pairs together. For pairs; break before and after other classes

      var SA = 42; //  Provide a line break opportunity contingent on additional, language-specific context analysis

      var XX = 43; //  Have as yet unknown line breaking behavior or unassigned code positions

      var BREAK_MANDATORY = '!';
      var BREAK_NOT_ALLOWED = '×';
      var BREAK_ALLOWED = '÷';
      var UnicodeTrie = createTrieFromBase64(base64);
      var ALPHABETICS = [AL, HL];
      var HARD_LINE_BREAKS = [BK, CR, LF, NL];
      var SPACE = [SP, ZW];
      var PREFIX_POSTFIX = [PR, PO];
      var LINE_BREAKS = HARD_LINE_BREAKS.concat(SPACE);
      var KOREAN_SYLLABLE_BLOCK = [JL, JV, JT, H2, H3];
      var HYPHEN = [HY, BA];

      var codePointsToCharacterClasses = function codePointsToCharacterClasses(codePoints, lineBreak) {
        if (lineBreak === void 0) {
          lineBreak = 'strict';
        }

        var types = [];
        var indicies = [];
        var categories = [];
        codePoints.forEach(function (codePoint, index) {
          var classType = UnicodeTrie.get(codePoint);

          if (classType > LETTER_NUMBER_MODIFIER) {
            categories.push(true);
            classType -= LETTER_NUMBER_MODIFIER;
          } else {
            categories.push(false);
          }

          if (['normal', 'auto', 'loose'].indexOf(lineBreak) !== -1) {
            // U+2010, – U+2013, 〜 U+301C, ゠ U+30A0
            if ([0x2010, 0x2013, 0x301c, 0x30a0].indexOf(codePoint) !== -1) {
              indicies.push(index);
              return types.push(CB);
            }
          }

          if (classType === CM || classType === ZWJ) {
            // LB10 Treat any remaining combining mark or ZWJ as AL.
            if (index === 0) {
              indicies.push(index);
              return types.push(AL);
            } // LB9 Do not break a combining character sequence; treat it as if it has the line breaking class of
            // the base character in all of the following rules. Treat ZWJ as if it were CM.


            var prev = types[index - 1];

            if (LINE_BREAKS.indexOf(prev) === -1) {
              indicies.push(indicies[index - 1]);
              return types.push(prev);
            }

            indicies.push(index);
            return types.push(AL);
          }

          indicies.push(index);

          if (classType === CJ) {
            return types.push(lineBreak === 'strict' ? NS : ID);
          }

          if (classType === SA) {
            return types.push(AL);
          }

          if (classType === AI) {
            return types.push(AL);
          } // For supplementary characters, a useful default is to treat characters in the range 10000..1FFFD as AL
          // and characters in the ranges 20000..2FFFD and 30000..3FFFD as ID, until the implementation can be revised
          // to take into account the actual line breaking properties for these characters.


          if (classType === XX) {
            if (codePoint >= 0x20000 && codePoint <= 0x2fffd || codePoint >= 0x30000 && codePoint <= 0x3fffd) {
              return types.push(ID);
            } else {
              return types.push(AL);
            }
          }

          types.push(classType);
        });
        return [indicies, types, categories];
      };

      var isAdjacentWithSpaceIgnored = function isAdjacentWithSpaceIgnored(a, b, currentIndex, classTypes) {
        var current = classTypes[currentIndex];

        if (Array.isArray(a) ? a.indexOf(current) !== -1 : a === current) {
          var i = currentIndex;

          while (i <= classTypes.length) {
            i++;
            var next = classTypes[i];

            if (next === b) {
              return true;
            }

            if (next !== SP) {
              break;
            }
          }
        }

        if (current === SP) {
          var i = currentIndex;

          while (i > 0) {
            i--;
            var prev = classTypes[i];

            if (Array.isArray(a) ? a.indexOf(prev) !== -1 : a === prev) {
              var n = currentIndex;

              while (n <= classTypes.length) {
                n++;
                var next = classTypes[n];

                if (next === b) {
                  return true;
                }

                if (next !== SP) {
                  break;
                }
              }
            }

            if (prev !== SP) {
              break;
            }
          }
        }

        return false;
      };

      var previousNonSpaceClassType = function previousNonSpaceClassType(currentIndex, classTypes) {
        var i = currentIndex;

        while (i >= 0) {
          var type = classTypes[i];

          if (type === SP) {
            i--;
          } else {
            return type;
          }
        }

        return 0;
      };

      var _lineBreakAtIndex = function _lineBreakAtIndex(codePoints, classTypes, indicies, index, forbiddenBreaks) {
        if (indicies[index] === 0) {
          return BREAK_NOT_ALLOWED;
        }

        var currentIndex = index - 1;

        if (Array.isArray(forbiddenBreaks) && forbiddenBreaks[currentIndex] === true) {
          return BREAK_NOT_ALLOWED;
        }

        var beforeIndex = currentIndex - 1;
        var afterIndex = currentIndex + 1;
        var current = classTypes[currentIndex]; // LB4 Always break after hard line breaks.
        // LB5 Treat CR followed by LF, as well as CR, LF, and NL as hard line breaks.

        var before = beforeIndex >= 0 ? classTypes[beforeIndex] : 0;
        var next = classTypes[afterIndex];

        if (current === CR && next === LF) {
          return BREAK_NOT_ALLOWED;
        }

        if (HARD_LINE_BREAKS.indexOf(current) !== -1) {
          return BREAK_MANDATORY;
        } // LB6 Do not break before hard line breaks.


        if (HARD_LINE_BREAKS.indexOf(next) !== -1) {
          return BREAK_NOT_ALLOWED;
        } // LB7 Do not break before spaces or zero width space.


        if (SPACE.indexOf(next) !== -1) {
          return BREAK_NOT_ALLOWED;
        } // LB8 Break before any character following a zero-width space, even if one or more spaces intervene.


        if (previousNonSpaceClassType(currentIndex, classTypes) === ZW) {
          return BREAK_ALLOWED;
        } // LB8a Do not break between a zero width joiner and an ideograph, emoji base or emoji modifier.


        if (UnicodeTrie.get(codePoints[currentIndex]) === ZWJ && (next === ID || next === EB || next === EM)) {
          return BREAK_NOT_ALLOWED;
        } // LB11 Do not break before or after Word joiner and related characters.


        if (current === WJ || next === WJ) {
          return BREAK_NOT_ALLOWED;
        } // LB12 Do not break after NBSP and related characters.


        if (current === GL) {
          return BREAK_NOT_ALLOWED;
        } // LB12a Do not break before NBSP and related characters, except after spaces and hyphens.


        if ([SP, BA, HY].indexOf(current) === -1 && next === GL) {
          return BREAK_NOT_ALLOWED;
        } // LB13 Do not break before ‘]’ or ‘!’ or ‘;’ or ‘/’, even after spaces.


        if ([CL, CP, EX, IS, SY].indexOf(next) !== -1) {
          return BREAK_NOT_ALLOWED;
        } // LB14 Do not break after ‘[’, even after spaces.


        if (previousNonSpaceClassType(currentIndex, classTypes) === OP) {
          return BREAK_NOT_ALLOWED;
        } // LB15 Do not break within ‘”[’, even with intervening spaces.


        if (isAdjacentWithSpaceIgnored(QU, OP, currentIndex, classTypes)) {
          return BREAK_NOT_ALLOWED;
        } // LB16 Do not break between closing punctuation and a nonstarter (lb=NS), even with intervening spaces.


        if (isAdjacentWithSpaceIgnored([CL, CP], NS, currentIndex, classTypes)) {
          return BREAK_NOT_ALLOWED;
        } // LB17 Do not break within ‘——’, even with intervening spaces.


        if (isAdjacentWithSpaceIgnored(B2, B2, currentIndex, classTypes)) {
          return BREAK_NOT_ALLOWED;
        } // LB18 Break after spaces.


        if (current === SP) {
          return BREAK_ALLOWED;
        } // LB19 Do not break before or after quotation marks, such as ‘ ” ’.


        if (current === QU || next === QU) {
          return BREAK_NOT_ALLOWED;
        } // LB20 Break before and after unresolved CB.


        if (next === CB || current === CB) {
          return BREAK_ALLOWED;
        } // LB21 Do not break before hyphen-minus, other hyphens, fixed-width spaces, small kana, and other non-starters, or after acute accents.


        if ([BA, HY, NS].indexOf(next) !== -1 || current === BB) {
          return BREAK_NOT_ALLOWED;
        } // LB21a Don't break after Hebrew + Hyphen.


        if (before === HL && HYPHEN.indexOf(current) !== -1) {
          return BREAK_NOT_ALLOWED;
        } // LB21b Don’t break between Solidus and Hebrew letters.


        if (current === SY && next === HL) {
          return BREAK_NOT_ALLOWED;
        } // LB22 Do not break between two ellipses, or between letters, numbers or exclamations and ellipsis.


        if (next === IN && ALPHABETICS.concat(IN, EX, NU, ID, EB, EM).indexOf(current) !== -1) {
          return BREAK_NOT_ALLOWED;
        } // LB23 Do not break between digits and letters.


        if (ALPHABETICS.indexOf(next) !== -1 && current === NU || ALPHABETICS.indexOf(current) !== -1 && next === NU) {
          return BREAK_NOT_ALLOWED;
        } // LB23a Do not break between numeric prefixes and ideographs, or between ideographs and numeric postfixes.


        if (current === PR && [ID, EB, EM].indexOf(next) !== -1 || [ID, EB, EM].indexOf(current) !== -1 && next === PO) {
          return BREAK_NOT_ALLOWED;
        } // LB24 Do not break between numeric prefix/postfix and letters, or between letters and prefix/postfix.


        if (ALPHABETICS.indexOf(current) !== -1 && PREFIX_POSTFIX.indexOf(next) !== -1 || PREFIX_POSTFIX.indexOf(current) !== -1 && ALPHABETICS.indexOf(next) !== -1) {
          return BREAK_NOT_ALLOWED;
        } // LB25 Do not break between the following pairs of classes relevant to numbers:


        if ( // (PR | PO) × ( OP | HY )? NU
        [PR, PO].indexOf(current) !== -1 && (next === NU || [OP, HY].indexOf(next) !== -1 && classTypes[afterIndex + 1] === NU) || // ( OP | HY ) × NU
        [OP, HY].indexOf(current) !== -1 && next === NU || // NU ×	(NU | SY | IS)
        current === NU && [NU, SY, IS].indexOf(next) !== -1) {
          return BREAK_NOT_ALLOWED;
        } // NU (NU | SY | IS)* × (NU | SY | IS | CL | CP)


        if ([NU, SY, IS, CL, CP].indexOf(next) !== -1) {
          var prevIndex = currentIndex;

          while (prevIndex >= 0) {
            var type = classTypes[prevIndex];

            if (type === NU) {
              return BREAK_NOT_ALLOWED;
            } else if ([SY, IS].indexOf(type) !== -1) {
              prevIndex--;
            } else {
              break;
            }
          }
        } // NU (NU | SY | IS)* (CL | CP)? × (PO | PR))


        if ([PR, PO].indexOf(next) !== -1) {
          var prevIndex = [CL, CP].indexOf(current) !== -1 ? beforeIndex : currentIndex;

          while (prevIndex >= 0) {
            var type = classTypes[prevIndex];

            if (type === NU) {
              return BREAK_NOT_ALLOWED;
            } else if ([SY, IS].indexOf(type) !== -1) {
              prevIndex--;
            } else {
              break;
            }
          }
        } // LB26 Do not break a Korean syllable.


        if (JL === current && [JL, JV, H2, H3].indexOf(next) !== -1 || [JV, H2].indexOf(current) !== -1 && [JV, JT].indexOf(next) !== -1 || [JT, H3].indexOf(current) !== -1 && next === JT) {
          return BREAK_NOT_ALLOWED;
        } // LB27 Treat a Korean Syllable Block the same as ID.


        if (KOREAN_SYLLABLE_BLOCK.indexOf(current) !== -1 && [IN, PO].indexOf(next) !== -1 || KOREAN_SYLLABLE_BLOCK.indexOf(next) !== -1 && current === PR) {
          return BREAK_NOT_ALLOWED;
        } // LB28 Do not break between alphabetics (“at”).


        if (ALPHABETICS.indexOf(current) !== -1 && ALPHABETICS.indexOf(next) !== -1) {
          return BREAK_NOT_ALLOWED;
        } // LB29 Do not break between numeric punctuation and alphabetics (“e.g.”).


        if (current === IS && ALPHABETICS.indexOf(next) !== -1) {
          return BREAK_NOT_ALLOWED;
        } // LB30 Do not break between letters, numbers, or ordinary symbols and opening or closing parentheses.


        if (ALPHABETICS.concat(NU).indexOf(current) !== -1 && next === OP || ALPHABETICS.concat(NU).indexOf(next) !== -1 && current === CP) {
          return BREAK_NOT_ALLOWED;
        } // LB30a Break between two regional indicator symbols if and only if there are an even number of regional
        // indicators preceding the position of the break.


        if (current === RI && next === RI) {
          var i = indicies[currentIndex];
          var count = 1;

          while (i > 0) {
            i--;

            if (classTypes[i] === RI) {
              count++;
            } else {
              break;
            }
          }

          if (count % 2 !== 0) {
            return BREAK_NOT_ALLOWED;
          }
        } // LB30b Do not break between an emoji base and an emoji modifier.


        if (current === EB && next === EM) {
          return BREAK_NOT_ALLOWED;
        }

        return BREAK_ALLOWED;
      };

      var cssFormattedClasses = function cssFormattedClasses(codePoints, options) {
        if (!options) {
          options = {
            lineBreak: 'normal',
            wordBreak: 'normal'
          };
        }

        var _a = codePointsToCharacterClasses(codePoints, options.lineBreak),
            indicies = _a[0],
            classTypes = _a[1],
            isLetterNumber = _a[2];

        if (options.wordBreak === 'break-all' || options.wordBreak === 'break-word') {
          classTypes = classTypes.map(function (type) {
            return [NU, AL, SA].indexOf(type) !== -1 ? ID : type;
          });
        }

        var forbiddenBreakpoints = options.wordBreak === 'keep-all' ? isLetterNumber.map(function (letterNumber, i) {
          return letterNumber && codePoints[i] >= 0x4e00 && codePoints[i] <= 0x9fff;
        }) : undefined;
        return [indicies, classTypes, forbiddenBreakpoints];
      };

      var Break =
      /** @class */
      function () {
        function Break(codePoints, lineBreak, start, end) {
          this.codePoints = codePoints;
          this.required = lineBreak === BREAK_MANDATORY;
          this.start = start;
          this.end = end;
        }

        Break.prototype.slice = function () {
          return fromCodePoint.apply(void 0, this.codePoints.slice(this.start, this.end));
        };

        return Break;
      }();

      var LineBreaker = function LineBreaker(str, options) {
        var codePoints = toCodePoints(str);

        var _a = cssFormattedClasses(codePoints, options),
            indicies = _a[0],
            classTypes = _a[1],
            forbiddenBreakpoints = _a[2];

        var length = codePoints.length;
        var lastEnd = 0;
        var nextIndex = 0;
        return {
          next: function next() {
            if (nextIndex >= length) {
              return {
                done: true,
                value: null
              };
            }

            var lineBreak = BREAK_NOT_ALLOWED;

            while (nextIndex < length && (lineBreak = _lineBreakAtIndex(codePoints, classTypes, indicies, ++nextIndex, forbiddenBreakpoints)) === BREAK_NOT_ALLOWED) {}

            if (lineBreak !== BREAK_NOT_ALLOWED || nextIndex === length) {
              var value = new Break(codePoints, lineBreak, lastEnd, nextIndex);
              lastEnd = nextIndex;
              return {
                value: value,
                done: false
              };
            }

            return {
              done: true,
              value: null
            };
          }
        };
      }; // https://www.w3.org/TR/css-syntax-3


      var TokenType;

      (function (TokenType) {
        TokenType[TokenType["STRING_TOKEN"] = 0] = "STRING_TOKEN";
        TokenType[TokenType["BAD_STRING_TOKEN"] = 1] = "BAD_STRING_TOKEN";
        TokenType[TokenType["LEFT_PARENTHESIS_TOKEN"] = 2] = "LEFT_PARENTHESIS_TOKEN";
        TokenType[TokenType["RIGHT_PARENTHESIS_TOKEN"] = 3] = "RIGHT_PARENTHESIS_TOKEN";
        TokenType[TokenType["COMMA_TOKEN"] = 4] = "COMMA_TOKEN";
        TokenType[TokenType["HASH_TOKEN"] = 5] = "HASH_TOKEN";
        TokenType[TokenType["DELIM_TOKEN"] = 6] = "DELIM_TOKEN";
        TokenType[TokenType["AT_KEYWORD_TOKEN"] = 7] = "AT_KEYWORD_TOKEN";
        TokenType[TokenType["PREFIX_MATCH_TOKEN"] = 8] = "PREFIX_MATCH_TOKEN";
        TokenType[TokenType["DASH_MATCH_TOKEN"] = 9] = "DASH_MATCH_TOKEN";
        TokenType[TokenType["INCLUDE_MATCH_TOKEN"] = 10] = "INCLUDE_MATCH_TOKEN";
        TokenType[TokenType["LEFT_CURLY_BRACKET_TOKEN"] = 11] = "LEFT_CURLY_BRACKET_TOKEN";
        TokenType[TokenType["RIGHT_CURLY_BRACKET_TOKEN"] = 12] = "RIGHT_CURLY_BRACKET_TOKEN";
        TokenType[TokenType["SUFFIX_MATCH_TOKEN"] = 13] = "SUFFIX_MATCH_TOKEN";
        TokenType[TokenType["SUBSTRING_MATCH_TOKEN"] = 14] = "SUBSTRING_MATCH_TOKEN";
        TokenType[TokenType["DIMENSION_TOKEN"] = 15] = "DIMENSION_TOKEN";
        TokenType[TokenType["PERCENTAGE_TOKEN"] = 16] = "PERCENTAGE_TOKEN";
        TokenType[TokenType["NUMBER_TOKEN"] = 17] = "NUMBER_TOKEN";
        TokenType[TokenType["FUNCTION"] = 18] = "FUNCTION";
        TokenType[TokenType["FUNCTION_TOKEN"] = 19] = "FUNCTION_TOKEN";
        TokenType[TokenType["IDENT_TOKEN"] = 20] = "IDENT_TOKEN";
        TokenType[TokenType["COLUMN_TOKEN"] = 21] = "COLUMN_TOKEN";
        TokenType[TokenType["URL_TOKEN"] = 22] = "URL_TOKEN";
        TokenType[TokenType["BAD_URL_TOKEN"] = 23] = "BAD_URL_TOKEN";
        TokenType[TokenType["CDC_TOKEN"] = 24] = "CDC_TOKEN";
        TokenType[TokenType["CDO_TOKEN"] = 25] = "CDO_TOKEN";
        TokenType[TokenType["COLON_TOKEN"] = 26] = "COLON_TOKEN";
        TokenType[TokenType["SEMICOLON_TOKEN"] = 27] = "SEMICOLON_TOKEN";
        TokenType[TokenType["LEFT_SQUARE_BRACKET_TOKEN"] = 28] = "LEFT_SQUARE_BRACKET_TOKEN";
        TokenType[TokenType["RIGHT_SQUARE_BRACKET_TOKEN"] = 29] = "RIGHT_SQUARE_BRACKET_TOKEN";
        TokenType[TokenType["UNICODE_RANGE_TOKEN"] = 30] = "UNICODE_RANGE_TOKEN";
        TokenType[TokenType["WHITESPACE_TOKEN"] = 31] = "WHITESPACE_TOKEN";
        TokenType[TokenType["EOF_TOKEN"] = 32] = "EOF_TOKEN";
      })(TokenType || (TokenType = {}));

      var FLAG_UNRESTRICTED = 1 << 0;
      var FLAG_ID = 1 << 1;
      var FLAG_INTEGER = 1 << 2;
      var FLAG_NUMBER = 1 << 3;
      var LINE_FEED = 0x000a;
      var SOLIDUS = 0x002f;
      var REVERSE_SOLIDUS = 0x005c;
      var CHARACTER_TABULATION = 0x0009;
      var SPACE$1 = 0x0020;
      var QUOTATION_MARK = 0x0022;
      var EQUALS_SIGN = 0x003d;
      var NUMBER_SIGN = 0x0023;
      var DOLLAR_SIGN = 0x0024;
      var PERCENTAGE_SIGN = 0x0025;
      var APOSTROPHE = 0x0027;
      var LEFT_PARENTHESIS = 0x0028;
      var RIGHT_PARENTHESIS = 0x0029;
      var LOW_LINE = 0x005f;
      var HYPHEN_MINUS = 0x002d;
      var EXCLAMATION_MARK = 0x0021;
      var LESS_THAN_SIGN = 0x003c;
      var GREATER_THAN_SIGN = 0x003e;
      var COMMERCIAL_AT = 0x0040;
      var LEFT_SQUARE_BRACKET = 0x005b;
      var RIGHT_SQUARE_BRACKET = 0x005d;
      var CIRCUMFLEX_ACCENT = 0x003d;
      var LEFT_CURLY_BRACKET = 0x007b;
      var QUESTION_MARK = 0x003f;
      var RIGHT_CURLY_BRACKET = 0x007d;
      var VERTICAL_LINE = 0x007c;
      var TILDE = 0x007e;
      var CONTROL = 0x0080;
      var REPLACEMENT_CHARACTER = 0xfffd;
      var ASTERISK = 0x002a;
      var PLUS_SIGN = 0x002b;
      var COMMA = 0x002c;
      var COLON = 0x003a;
      var SEMICOLON = 0x003b;
      var FULL_STOP = 0x002e;
      var NULL = 0x0000;
      var BACKSPACE = 0x0008;
      var LINE_TABULATION = 0x000b;
      var SHIFT_OUT = 0x000e;
      var INFORMATION_SEPARATOR_ONE = 0x001f;
      var DELETE = 0x007f;
      var EOF = -1;
      var ZERO = 0x0030;
      var a = 0x0061;
      var e = 0x0065;
      var f = 0x0066;
      var u = 0x0075;
      var z = 0x007a;
      var A = 0x0041;
      var E = 0x0045;
      var F = 0x0046;
      var U = 0x0055;
      var Z = 0x005a;

      var isDigit = function isDigit(codePoint) {
        return codePoint >= ZERO && codePoint <= 0x0039;
      };

      var isSurrogateCodePoint = function isSurrogateCodePoint(codePoint) {
        return codePoint >= 0xd800 && codePoint <= 0xdfff;
      };

      var isHex = function isHex(codePoint) {
        return isDigit(codePoint) || codePoint >= A && codePoint <= F || codePoint >= a && codePoint <= f;
      };

      var isLowerCaseLetter = function isLowerCaseLetter(codePoint) {
        return codePoint >= a && codePoint <= z;
      };

      var isUpperCaseLetter = function isUpperCaseLetter(codePoint) {
        return codePoint >= A && codePoint <= Z;
      };

      var isLetter = function isLetter(codePoint) {
        return isLowerCaseLetter(codePoint) || isUpperCaseLetter(codePoint);
      };

      var isNonASCIICodePoint = function isNonASCIICodePoint(codePoint) {
        return codePoint >= CONTROL;
      };

      var isWhiteSpace = function isWhiteSpace(codePoint) {
        return codePoint === LINE_FEED || codePoint === CHARACTER_TABULATION || codePoint === SPACE$1;
      };

      var isNameStartCodePoint = function isNameStartCodePoint(codePoint) {
        return isLetter(codePoint) || isNonASCIICodePoint(codePoint) || codePoint === LOW_LINE;
      };

      var isNameCodePoint = function isNameCodePoint(codePoint) {
        return isNameStartCodePoint(codePoint) || isDigit(codePoint) || codePoint === HYPHEN_MINUS;
      };

      var isNonPrintableCodePoint = function isNonPrintableCodePoint(codePoint) {
        return codePoint >= NULL && codePoint <= BACKSPACE || codePoint === LINE_TABULATION || codePoint >= SHIFT_OUT && codePoint <= INFORMATION_SEPARATOR_ONE || codePoint === DELETE;
      };

      var isValidEscape = function isValidEscape(c1, c2) {
        if (c1 !== REVERSE_SOLIDUS) {
          return false;
        }

        return c2 !== LINE_FEED;
      };

      var isIdentifierStart = function isIdentifierStart(c1, c2, c3) {
        if (c1 === HYPHEN_MINUS) {
          return isNameStartCodePoint(c2) || isValidEscape(c2, c3);
        } else if (isNameStartCodePoint(c1)) {
          return true;
        } else if (c1 === REVERSE_SOLIDUS && isValidEscape(c1, c2)) {
          return true;
        }

        return false;
      };

      var isNumberStart = function isNumberStart(c1, c2, c3) {
        if (c1 === PLUS_SIGN || c1 === HYPHEN_MINUS) {
          if (isDigit(c2)) {
            return true;
          }

          return c2 === FULL_STOP && isDigit(c3);
        }

        if (c1 === FULL_STOP) {
          return isDigit(c2);
        }

        return isDigit(c1);
      };

      var stringToNumber = function stringToNumber(codePoints) {
        var c = 0;
        var sign = 1;

        if (codePoints[c] === PLUS_SIGN || codePoints[c] === HYPHEN_MINUS) {
          if (codePoints[c] === HYPHEN_MINUS) {
            sign = -1;
          }

          c++;
        }

        var integers = [];

        while (isDigit(codePoints[c])) {
          integers.push(codePoints[c++]);
        }

        var _int = integers.length ? parseInt(fromCodePoint.apply(void 0, integers), 10) : 0;

        if (codePoints[c] === FULL_STOP) {
          c++;
        }

        var fraction = [];

        while (isDigit(codePoints[c])) {
          fraction.push(codePoints[c++]);
        }

        var fracd = fraction.length;
        var frac = fracd ? parseInt(fromCodePoint.apply(void 0, fraction), 10) : 0;

        if (codePoints[c] === E || codePoints[c] === e) {
          c++;
        }

        var expsign = 1;

        if (codePoints[c] === PLUS_SIGN || codePoints[c] === HYPHEN_MINUS) {
          if (codePoints[c] === HYPHEN_MINUS) {
            expsign = -1;
          }

          c++;
        }

        var exponent = [];

        while (isDigit(codePoints[c])) {
          exponent.push(codePoints[c++]);
        }

        var exp = exponent.length ? parseInt(fromCodePoint.apply(void 0, exponent), 10) : 0;
        return sign * (_int + frac * Math.pow(10, -fracd)) * Math.pow(10, expsign * exp);
      };

      var LEFT_PARENTHESIS_TOKEN = {
        type: TokenType.LEFT_PARENTHESIS_TOKEN
      };
      var RIGHT_PARENTHESIS_TOKEN = {
        type: TokenType.RIGHT_PARENTHESIS_TOKEN
      };
      var COMMA_TOKEN = {
        type: TokenType.COMMA_TOKEN
      };
      var SUFFIX_MATCH_TOKEN = {
        type: TokenType.SUFFIX_MATCH_TOKEN
      };
      var PREFIX_MATCH_TOKEN = {
        type: TokenType.PREFIX_MATCH_TOKEN
      };
      var COLUMN_TOKEN = {
        type: TokenType.COLUMN_TOKEN
      };
      var DASH_MATCH_TOKEN = {
        type: TokenType.DASH_MATCH_TOKEN
      };
      var INCLUDE_MATCH_TOKEN = {
        type: TokenType.INCLUDE_MATCH_TOKEN
      };
      var LEFT_CURLY_BRACKET_TOKEN = {
        type: TokenType.LEFT_CURLY_BRACKET_TOKEN
      };
      var RIGHT_CURLY_BRACKET_TOKEN = {
        type: TokenType.RIGHT_CURLY_BRACKET_TOKEN
      };
      var SUBSTRING_MATCH_TOKEN = {
        type: TokenType.SUBSTRING_MATCH_TOKEN
      };
      var BAD_URL_TOKEN = {
        type: TokenType.BAD_URL_TOKEN
      };
      var BAD_STRING_TOKEN = {
        type: TokenType.BAD_STRING_TOKEN
      };
      var CDO_TOKEN = {
        type: TokenType.CDO_TOKEN
      };
      var CDC_TOKEN = {
        type: TokenType.CDC_TOKEN
      };
      var COLON_TOKEN = {
        type: TokenType.COLON_TOKEN
      };
      var SEMICOLON_TOKEN = {
        type: TokenType.SEMICOLON_TOKEN
      };
      var LEFT_SQUARE_BRACKET_TOKEN = {
        type: TokenType.LEFT_SQUARE_BRACKET_TOKEN
      };
      var RIGHT_SQUARE_BRACKET_TOKEN = {
        type: TokenType.RIGHT_SQUARE_BRACKET_TOKEN
      };
      var WHITESPACE_TOKEN = {
        type: TokenType.WHITESPACE_TOKEN
      };
      var EOF_TOKEN = {
        type: TokenType.EOF_TOKEN
      };

      var Tokenizer =
      /** @class */
      function () {
        function Tokenizer() {
          this._value = [];
        }

        Tokenizer.prototype.write = function (chunk) {
          this._value = this._value.concat(toCodePoints(chunk));
        };

        Tokenizer.prototype.read = function () {
          var tokens = [];
          var token = this.consumeToken();

          while (token !== EOF_TOKEN) {
            tokens.push(token);
            token = this.consumeToken();
          }

          return tokens;
        };

        Tokenizer.prototype.consumeToken = function () {
          var codePoint = this.consumeCodePoint();

          switch (codePoint) {
            case QUOTATION_MARK:
              return this.consumeStringToken(QUOTATION_MARK);

            case NUMBER_SIGN:
              var c1 = this.peekCodePoint(0);
              var c2 = this.peekCodePoint(1);
              var c3 = this.peekCodePoint(2);

              if (isNameCodePoint(c1) || isValidEscape(c2, c3)) {
                var flags = isIdentifierStart(c1, c2, c3) ? FLAG_ID : FLAG_UNRESTRICTED;
                var value = this.consumeName();
                return {
                  type: TokenType.HASH_TOKEN,
                  value: value,
                  flags: flags
                };
              }

              break;

            case DOLLAR_SIGN:
              if (this.peekCodePoint(0) === EQUALS_SIGN) {
                this.consumeCodePoint();
                return SUFFIX_MATCH_TOKEN;
              }

              break;

            case APOSTROPHE:
              return this.consumeStringToken(APOSTROPHE);

            case LEFT_PARENTHESIS:
              return LEFT_PARENTHESIS_TOKEN;

            case RIGHT_PARENTHESIS:
              return RIGHT_PARENTHESIS_TOKEN;

            case ASTERISK:
              if (this.peekCodePoint(0) === EQUALS_SIGN) {
                this.consumeCodePoint();
                return SUBSTRING_MATCH_TOKEN;
              }

              break;

            case PLUS_SIGN:
              if (isNumberStart(codePoint, this.peekCodePoint(0), this.peekCodePoint(1))) {
                this.reconsumeCodePoint(codePoint);
                return this.consumeNumericToken();
              }

              break;

            case COMMA:
              return COMMA_TOKEN;

            case HYPHEN_MINUS:
              var e1 = codePoint;
              var e2 = this.peekCodePoint(0);
              var e3 = this.peekCodePoint(1);

              if (isNumberStart(e1, e2, e3)) {
                this.reconsumeCodePoint(codePoint);
                return this.consumeNumericToken();
              }

              if (isIdentifierStart(e1, e2, e3)) {
                this.reconsumeCodePoint(codePoint);
                return this.consumeIdentLikeToken();
              }

              if (e2 === HYPHEN_MINUS && e3 === GREATER_THAN_SIGN) {
                this.consumeCodePoint();
                this.consumeCodePoint();
                return CDC_TOKEN;
              }

              break;

            case FULL_STOP:
              if (isNumberStart(codePoint, this.peekCodePoint(0), this.peekCodePoint(1))) {
                this.reconsumeCodePoint(codePoint);
                return this.consumeNumericToken();
              }

              break;

            case SOLIDUS:
              if (this.peekCodePoint(0) === ASTERISK) {
                this.consumeCodePoint();

                while (true) {
                  var c = this.consumeCodePoint();

                  if (c === ASTERISK) {
                    c = this.consumeCodePoint();

                    if (c === SOLIDUS) {
                      return this.consumeToken();
                    }
                  }

                  if (c === EOF) {
                    return this.consumeToken();
                  }
                }
              }

              break;

            case COLON:
              return COLON_TOKEN;

            case SEMICOLON:
              return SEMICOLON_TOKEN;

            case LESS_THAN_SIGN:
              if (this.peekCodePoint(0) === EXCLAMATION_MARK && this.peekCodePoint(1) === HYPHEN_MINUS && this.peekCodePoint(2) === HYPHEN_MINUS) {
                this.consumeCodePoint();
                this.consumeCodePoint();
                return CDO_TOKEN;
              }

              break;

            case COMMERCIAL_AT:
              var a1 = this.peekCodePoint(0);
              var a2 = this.peekCodePoint(1);
              var a3 = this.peekCodePoint(2);

              if (isIdentifierStart(a1, a2, a3)) {
                var value = this.consumeName();
                return {
                  type: TokenType.AT_KEYWORD_TOKEN,
                  value: value
                };
              }

              break;

            case LEFT_SQUARE_BRACKET:
              return LEFT_SQUARE_BRACKET_TOKEN;

            case REVERSE_SOLIDUS:
              if (isValidEscape(codePoint, this.peekCodePoint(0))) {
                this.reconsumeCodePoint(codePoint);
                return this.consumeIdentLikeToken();
              }

              break;

            case RIGHT_SQUARE_BRACKET:
              return RIGHT_SQUARE_BRACKET_TOKEN;

            case CIRCUMFLEX_ACCENT:
              if (this.peekCodePoint(0) === EQUALS_SIGN) {
                this.consumeCodePoint();
                return PREFIX_MATCH_TOKEN;
              }

              break;

            case LEFT_CURLY_BRACKET:
              return LEFT_CURLY_BRACKET_TOKEN;

            case RIGHT_CURLY_BRACKET:
              return RIGHT_CURLY_BRACKET_TOKEN;

            case u:
            case U:
              var u1 = this.peekCodePoint(0);
              var u2 = this.peekCodePoint(1);

              if (u1 === PLUS_SIGN && (isHex(u2) || u2 === QUESTION_MARK)) {
                this.consumeCodePoint();
                this.consumeUnicodeRangeToken();
              }

              this.reconsumeCodePoint(codePoint);
              return this.consumeIdentLikeToken();

            case VERTICAL_LINE:
              if (this.peekCodePoint(0) === EQUALS_SIGN) {
                this.consumeCodePoint();
                return DASH_MATCH_TOKEN;
              }

              if (this.peekCodePoint(0) === VERTICAL_LINE) {
                this.consumeCodePoint();
                return COLUMN_TOKEN;
              }

              break;

            case TILDE:
              if (this.peekCodePoint(0) === EQUALS_SIGN) {
                this.consumeCodePoint();
                return INCLUDE_MATCH_TOKEN;
              }

              break;

            case EOF:
              return EOF_TOKEN;
          }

          if (isWhiteSpace(codePoint)) {
            this.consumeWhiteSpace();
            return WHITESPACE_TOKEN;
          }

          if (isDigit(codePoint)) {
            this.reconsumeCodePoint(codePoint);
            return this.consumeNumericToken();
          }

          if (isNameStartCodePoint(codePoint)) {
            this.reconsumeCodePoint(codePoint);
            return this.consumeIdentLikeToken();
          }

          return {
            type: TokenType.DELIM_TOKEN,
            value: fromCodePoint(codePoint)
          };
        };

        Tokenizer.prototype.consumeCodePoint = function () {
          var value = this._value.shift();

          return typeof value === 'undefined' ? -1 : value;
        };

        Tokenizer.prototype.reconsumeCodePoint = function (codePoint) {
          this._value.unshift(codePoint);
        };

        Tokenizer.prototype.peekCodePoint = function (delta) {
          if (delta >= this._value.length) {
            return -1;
          }

          return this._value[delta];
        };

        Tokenizer.prototype.consumeUnicodeRangeToken = function () {
          var digits = [];
          var codePoint = this.consumeCodePoint();

          while (isHex(codePoint) && digits.length < 6) {
            digits.push(codePoint);
            codePoint = this.consumeCodePoint();
          }

          var questionMarks = false;

          while (codePoint === QUESTION_MARK && digits.length < 6) {
            digits.push(codePoint);
            codePoint = this.consumeCodePoint();
            questionMarks = true;
          }

          if (questionMarks) {
            var start_1 = parseInt(fromCodePoint.apply(void 0, digits.map(function (digit) {
              return digit === QUESTION_MARK ? ZERO : digit;
            })), 16);
            var end = parseInt(fromCodePoint.apply(void 0, digits.map(function (digit) {
              return digit === QUESTION_MARK ? F : digit;
            })), 16);
            return {
              type: TokenType.UNICODE_RANGE_TOKEN,
              start: start_1,
              end: end
            };
          }

          var start = parseInt(fromCodePoint.apply(void 0, digits), 16);

          if (this.peekCodePoint(0) === HYPHEN_MINUS && isHex(this.peekCodePoint(1))) {
            this.consumeCodePoint();
            codePoint = this.consumeCodePoint();
            var endDigits = [];

            while (isHex(codePoint) && endDigits.length < 6) {
              endDigits.push(codePoint);
              codePoint = this.consumeCodePoint();
            }

            var end = parseInt(fromCodePoint.apply(void 0, endDigits), 16);
            return {
              type: TokenType.UNICODE_RANGE_TOKEN,
              start: start,
              end: end
            };
          } else {
            return {
              type: TokenType.UNICODE_RANGE_TOKEN,
              start: start,
              end: start
            };
          }
        };

        Tokenizer.prototype.consumeIdentLikeToken = function () {
          var value = this.consumeName();

          if (value.toLowerCase() === 'url' && this.peekCodePoint(0) === LEFT_PARENTHESIS) {
            this.consumeCodePoint();
            return this.consumeUrlToken();
          } else if (this.peekCodePoint(0) === LEFT_PARENTHESIS) {
            this.consumeCodePoint();
            return {
              type: TokenType.FUNCTION_TOKEN,
              value: value
            };
          }

          return {
            type: TokenType.IDENT_TOKEN,
            value: value
          };
        };

        Tokenizer.prototype.consumeUrlToken = function () {
          var value = [];
          this.consumeWhiteSpace();

          if (this.peekCodePoint(0) === EOF) {
            return {
              type: TokenType.URL_TOKEN,
              value: ''
            };
          }

          var next = this.peekCodePoint(0);

          if (next === APOSTROPHE || next === QUOTATION_MARK) {
            var stringToken = this.consumeStringToken(this.consumeCodePoint());

            if (stringToken.type === TokenType.STRING_TOKEN) {
              this.consumeWhiteSpace();

              if (this.peekCodePoint(0) === EOF || this.peekCodePoint(0) === RIGHT_PARENTHESIS) {
                this.consumeCodePoint();
                return {
                  type: TokenType.URL_TOKEN,
                  value: stringToken.value
                };
              }
            }

            this.consumeBadUrlRemnants();
            return BAD_URL_TOKEN;
          }

          while (true) {
            var codePoint = this.consumeCodePoint();

            if (codePoint === EOF || codePoint === RIGHT_PARENTHESIS) {
              return {
                type: TokenType.URL_TOKEN,
                value: fromCodePoint.apply(void 0, value)
              };
            } else if (isWhiteSpace(codePoint)) {
              this.consumeWhiteSpace();

              if (this.peekCodePoint(0) === EOF || this.peekCodePoint(0) === RIGHT_PARENTHESIS) {
                this.consumeCodePoint();
                return {
                  type: TokenType.URL_TOKEN,
                  value: fromCodePoint.apply(void 0, value)
                };
              }

              this.consumeBadUrlRemnants();
              return BAD_URL_TOKEN;
            } else if (codePoint === QUOTATION_MARK || codePoint === APOSTROPHE || codePoint === LEFT_PARENTHESIS || isNonPrintableCodePoint(codePoint)) {
              this.consumeBadUrlRemnants();
              return BAD_URL_TOKEN;
            } else if (codePoint === REVERSE_SOLIDUS) {
              if (isValidEscape(codePoint, this.peekCodePoint(0))) {
                value.push(this.consumeEscapedCodePoint());
              } else {
                this.consumeBadUrlRemnants();
                return BAD_URL_TOKEN;
              }
            } else {
              value.push(codePoint);
            }
          }
        };

        Tokenizer.prototype.consumeWhiteSpace = function () {
          while (isWhiteSpace(this.peekCodePoint(0))) {
            this.consumeCodePoint();
          }
        };

        Tokenizer.prototype.consumeBadUrlRemnants = function () {
          while (true) {
            var codePoint = this.consumeCodePoint();

            if (codePoint === RIGHT_PARENTHESIS || codePoint === EOF) {
              return;
            }

            if (isValidEscape(codePoint, this.peekCodePoint(0))) {
              this.consumeEscapedCodePoint();
            }
          }
        };

        Tokenizer.prototype.consumeStringSlice = function (count) {
          var SLICE_STACK_SIZE = 60000;
          var value = '';

          while (count > 0) {
            var amount = Math.min(SLICE_STACK_SIZE, count);
            value += fromCodePoint.apply(void 0, this._value.splice(0, amount));
            count -= amount;
          }

          this._value.shift();

          return value;
        };

        Tokenizer.prototype.consumeStringToken = function (endingCodePoint) {
          var value = '';
          var i = 0;

          do {
            var codePoint = this._value[i];

            if (codePoint === EOF || codePoint === undefined || codePoint === endingCodePoint) {
              value += this.consumeStringSlice(i);
              return {
                type: TokenType.STRING_TOKEN,
                value: value
              };
            }

            if (codePoint === LINE_FEED) {
              this._value.splice(0, i);

              return BAD_STRING_TOKEN;
            }

            if (codePoint === REVERSE_SOLIDUS) {
              var next = this._value[i + 1];

              if (next !== EOF && next !== undefined) {
                if (next === LINE_FEED) {
                  value += this.consumeStringSlice(i);
                  i = -1;

                  this._value.shift();
                } else if (isValidEscape(codePoint, next)) {
                  value += this.consumeStringSlice(i);
                  value += fromCodePoint(this.consumeEscapedCodePoint());
                  i = -1;
                }
              }
            }

            i++;
          } while (true);
        };

        Tokenizer.prototype.consumeNumber = function () {
          var repr = [];
          var type = FLAG_INTEGER;
          var c1 = this.peekCodePoint(0);

          if (c1 === PLUS_SIGN || c1 === HYPHEN_MINUS) {
            repr.push(this.consumeCodePoint());
          }

          while (isDigit(this.peekCodePoint(0))) {
            repr.push(this.consumeCodePoint());
          }

          c1 = this.peekCodePoint(0);
          var c2 = this.peekCodePoint(1);

          if (c1 === FULL_STOP && isDigit(c2)) {
            repr.push(this.consumeCodePoint(), this.consumeCodePoint());
            type = FLAG_NUMBER;

            while (isDigit(this.peekCodePoint(0))) {
              repr.push(this.consumeCodePoint());
            }
          }

          c1 = this.peekCodePoint(0);
          c2 = this.peekCodePoint(1);
          var c3 = this.peekCodePoint(2);

          if ((c1 === E || c1 === e) && ((c2 === PLUS_SIGN || c2 === HYPHEN_MINUS) && isDigit(c3) || isDigit(c2))) {
            repr.push(this.consumeCodePoint(), this.consumeCodePoint());
            type = FLAG_NUMBER;

            while (isDigit(this.peekCodePoint(0))) {
              repr.push(this.consumeCodePoint());
            }
          }

          return [stringToNumber(repr), type];
        };

        Tokenizer.prototype.consumeNumericToken = function () {
          var _a = this.consumeNumber(),
              number = _a[0],
              flags = _a[1];

          var c1 = this.peekCodePoint(0);
          var c2 = this.peekCodePoint(1);
          var c3 = this.peekCodePoint(2);

          if (isIdentifierStart(c1, c2, c3)) {
            var unit = this.consumeName();
            return {
              type: TokenType.DIMENSION_TOKEN,
              number: number,
              flags: flags,
              unit: unit
            };
          }

          if (c1 === PERCENTAGE_SIGN) {
            this.consumeCodePoint();
            return {
              type: TokenType.PERCENTAGE_TOKEN,
              number: number,
              flags: flags
            };
          }

          return {
            type: TokenType.NUMBER_TOKEN,
            number: number,
            flags: flags
          };
        };

        Tokenizer.prototype.consumeEscapedCodePoint = function () {
          var codePoint = this.consumeCodePoint();

          if (isHex(codePoint)) {
            var hex = fromCodePoint(codePoint);

            while (isHex(this.peekCodePoint(0)) && hex.length < 6) {
              hex += fromCodePoint(this.consumeCodePoint());
            }

            if (isWhiteSpace(this.peekCodePoint(0))) {
              this.consumeCodePoint();
            }

            var hexCodePoint = parseInt(hex, 16);

            if (hexCodePoint === 0 || isSurrogateCodePoint(hexCodePoint) || hexCodePoint > 0x10ffff) {
              return REPLACEMENT_CHARACTER;
            }

            return hexCodePoint;
          }

          if (codePoint === EOF) {
            return REPLACEMENT_CHARACTER;
          }

          return codePoint;
        };

        Tokenizer.prototype.consumeName = function () {
          var result = '';

          while (true) {
            var codePoint = this.consumeCodePoint();

            if (isNameCodePoint(codePoint)) {
              result += fromCodePoint(codePoint);
            } else if (isValidEscape(codePoint, this.peekCodePoint(0))) {
              result += fromCodePoint(this.consumeEscapedCodePoint());
            } else {
              this.reconsumeCodePoint(codePoint);
              return result;
            }
          }
        };

        return Tokenizer;
      }();

      var Parser =
      /** @class */
      function () {
        function Parser(tokens) {
          this._tokens = tokens;
        }

        Parser.create = function (value) {
          var tokenizer = new Tokenizer();
          tokenizer.write(value);
          return new Parser(tokenizer.read());
        };

        Parser.parseValue = function (value) {
          return Parser.create(value).parseComponentValue();
        };

        Parser.parseValues = function (value) {
          return Parser.create(value).parseComponentValues();
        };

        Parser.prototype.parseComponentValue = function () {
          var token = this.consumeToken();

          while (token.type === TokenType.WHITESPACE_TOKEN) {
            token = this.consumeToken();
          }

          if (token.type === TokenType.EOF_TOKEN) {
            throw new SyntaxError("Error parsing CSS component value, unexpected EOF");
          }

          this.reconsumeToken(token);
          var value = this.consumeComponentValue();

          do {
            token = this.consumeToken();
          } while (token.type === TokenType.WHITESPACE_TOKEN);

          if (token.type === TokenType.EOF_TOKEN) {
            return value;
          }

          throw new SyntaxError("Error parsing CSS component value, multiple values found when expecting only one");
        };

        Parser.prototype.parseComponentValues = function () {
          var values = [];

          while (true) {
            var value = this.consumeComponentValue();

            if (value.type === TokenType.EOF_TOKEN) {
              return values;
            }

            values.push(value);
            values.push();
          }
        };

        Parser.prototype.consumeComponentValue = function () {
          var token = this.consumeToken();

          switch (token.type) {
            case TokenType.LEFT_CURLY_BRACKET_TOKEN:
            case TokenType.LEFT_SQUARE_BRACKET_TOKEN:
            case TokenType.LEFT_PARENTHESIS_TOKEN:
              return this.consumeSimpleBlock(token.type);

            case TokenType.FUNCTION_TOKEN:
              return this.consumeFunction(token);
          }

          return token;
        };

        Parser.prototype.consumeSimpleBlock = function (type) {
          var block = {
            type: type,
            values: []
          };
          var token = this.consumeToken();

          while (true) {
            if (token.type === TokenType.EOF_TOKEN || isEndingTokenFor(token, type)) {
              return block;
            }

            this.reconsumeToken(token);
            block.values.push(this.consumeComponentValue());
            token = this.consumeToken();
          }
        };

        Parser.prototype.consumeFunction = function (functionToken) {
          var cssFunction = {
            name: functionToken.value,
            values: [],
            type: TokenType.FUNCTION
          };

          while (true) {
            var token = this.consumeToken();

            if (token.type === TokenType.EOF_TOKEN || token.type === TokenType.RIGHT_PARENTHESIS_TOKEN) {
              return cssFunction;
            }

            this.reconsumeToken(token);
            cssFunction.values.push(this.consumeComponentValue());
          }
        };

        Parser.prototype.consumeToken = function () {
          var token = this._tokens.shift();

          return typeof token === 'undefined' ? EOF_TOKEN : token;
        };

        Parser.prototype.reconsumeToken = function (token) {
          this._tokens.unshift(token);
        };

        return Parser;
      }();

      var isDimensionToken = function isDimensionToken(token) {
        return token.type === TokenType.DIMENSION_TOKEN;
      };

      var isNumberToken = function isNumberToken(token) {
        return token.type === TokenType.NUMBER_TOKEN;
      };

      var isIdentToken = function isIdentToken(token) {
        return token.type === TokenType.IDENT_TOKEN;
      };

      var isStringToken = function isStringToken(token) {
        return token.type === TokenType.STRING_TOKEN;
      };

      var isIdentWithValue = function isIdentWithValue(token, value) {
        return isIdentToken(token) && token.value === value;
      };

      var nonWhiteSpace = function nonWhiteSpace(token) {
        return token.type !== TokenType.WHITESPACE_TOKEN;
      };

      var nonFunctionArgSeparator = function nonFunctionArgSeparator(token) {
        return token.type !== TokenType.WHITESPACE_TOKEN && token.type !== TokenType.COMMA_TOKEN;
      };

      var parseFunctionArgs = function parseFunctionArgs(tokens) {
        var args = [];
        var arg = [];
        tokens.forEach(function (token) {
          if (token.type === TokenType.COMMA_TOKEN) {
            if (arg.length === 0) {
              throw new Error("Error parsing function args, zero tokens for arg");
            }

            args.push(arg);
            arg = [];
            return;
          }

          if (token.type !== TokenType.WHITESPACE_TOKEN) {
            arg.push(token);
          }
        });

        if (arg.length) {
          args.push(arg);
        }

        return args;
      };

      var isEndingTokenFor = function isEndingTokenFor(token, type) {
        if (type === TokenType.LEFT_CURLY_BRACKET_TOKEN && token.type === TokenType.RIGHT_CURLY_BRACKET_TOKEN) {
          return true;
        }

        if (type === TokenType.LEFT_SQUARE_BRACKET_TOKEN && token.type === TokenType.RIGHT_SQUARE_BRACKET_TOKEN) {
          return true;
        }

        return type === TokenType.LEFT_PARENTHESIS_TOKEN && token.type === TokenType.RIGHT_PARENTHESIS_TOKEN;
      };

      var isLength = function isLength(token) {
        return token.type === TokenType.NUMBER_TOKEN || token.type === TokenType.DIMENSION_TOKEN;
      };

      var isLengthPercentage = function isLengthPercentage(token) {
        return token.type === TokenType.PERCENTAGE_TOKEN || isLength(token);
      };

      var parseLengthPercentageTuple = function parseLengthPercentageTuple(tokens) {
        return tokens.length > 1 ? [tokens[0], tokens[1]] : [tokens[0]];
      };

      var ZERO_LENGTH = {
        type: TokenType.NUMBER_TOKEN,
        number: 0,
        flags: FLAG_INTEGER
      };
      var FIFTY_PERCENT = {
        type: TokenType.PERCENTAGE_TOKEN,
        number: 50,
        flags: FLAG_INTEGER
      };
      var HUNDRED_PERCENT = {
        type: TokenType.PERCENTAGE_TOKEN,
        number: 100,
        flags: FLAG_INTEGER
      };

      var getAbsoluteValueForTuple = function getAbsoluteValueForTuple(tuple, width, height) {
        var x = tuple[0],
            y = tuple[1];
        return [getAbsoluteValue(x, width), getAbsoluteValue(typeof y !== 'undefined' ? y : x, height)];
      };

      var getAbsoluteValue = function getAbsoluteValue(token, parent) {
        if (token.type === TokenType.PERCENTAGE_TOKEN) {
          return token.number / 100 * parent;
        }

        if (isDimensionToken(token)) {
          switch (token.unit) {
            case 'rem':
            case 'em':
              return 16 * token.number;
            // TODO use correct font-size

            case 'px':
            default:
              return token.number;
          }
        }

        return token.number;
      };

      var DEG = 'deg';
      var GRAD = 'grad';
      var RAD = 'rad';
      var TURN = 'turn';
      var angle = {
        name: 'angle',
        parse: function parse(value) {
          if (value.type === TokenType.DIMENSION_TOKEN) {
            switch (value.unit) {
              case DEG:
                return Math.PI * value.number / 180;

              case GRAD:
                return Math.PI / 200 * value.number;

              case RAD:
                return value.number;

              case TURN:
                return Math.PI * 2 * value.number;
            }
          }

          throw new Error("Unsupported angle type");
        }
      };

      var isAngle = function isAngle(value) {
        if (value.type === TokenType.DIMENSION_TOKEN) {
          if (value.unit === DEG || value.unit === GRAD || value.unit === RAD || value.unit === TURN) {
            return true;
          }
        }

        return false;
      };

      var parseNamedSide = function parseNamedSide(tokens) {
        var sideOrCorner = tokens.filter(isIdentToken).map(function (ident) {
          return ident.value;
        }).join(' ');

        switch (sideOrCorner) {
          case 'to bottom right':
          case 'to right bottom':
          case 'left top':
          case 'top left':
            return [ZERO_LENGTH, ZERO_LENGTH];

          case 'to top':
          case 'bottom':
            return deg(0);

          case 'to bottom left':
          case 'to left bottom':
          case 'right top':
          case 'top right':
            return [ZERO_LENGTH, HUNDRED_PERCENT];

          case 'to right':
          case 'left':
            return deg(90);

          case 'to top left':
          case 'to left top':
          case 'right bottom':
          case 'bottom right':
            return [HUNDRED_PERCENT, HUNDRED_PERCENT];

          case 'to bottom':
          case 'top':
            return deg(180);

          case 'to top right':
          case 'to right top':
          case 'left bottom':
          case 'bottom left':
            return [HUNDRED_PERCENT, ZERO_LENGTH];

          case 'to left':
          case 'right':
            return deg(270);
        }

        return 0;
      };

      var deg = function deg(_deg) {
        return Math.PI * _deg / 180;
      };

      var color = {
        name: 'color',
        parse: function parse(value) {
          if (value.type === TokenType.FUNCTION) {
            var colorFunction = SUPPORTED_COLOR_FUNCTIONS[value.name];

            if (typeof colorFunction === 'undefined') {
              throw new Error("Attempting to parse an unsupported color function \"" + value.name + "\"");
            }

            return colorFunction(value.values);
          }

          if (value.type === TokenType.HASH_TOKEN) {
            if (value.value.length === 3) {
              var r = value.value.substring(0, 1);
              var g = value.value.substring(1, 2);
              var b = value.value.substring(2, 3);
              return pack(parseInt(r + r, 16), parseInt(g + g, 16), parseInt(b + b, 16), 1);
            }

            if (value.value.length === 4) {
              var r = value.value.substring(0, 1);
              var g = value.value.substring(1, 2);
              var b = value.value.substring(2, 3);
              var a = value.value.substring(3, 4);
              return pack(parseInt(r + r, 16), parseInt(g + g, 16), parseInt(b + b, 16), parseInt(a + a, 16) / 255);
            }

            if (value.value.length === 6) {
              var r = value.value.substring(0, 2);
              var g = value.value.substring(2, 4);
              var b = value.value.substring(4, 6);
              return pack(parseInt(r, 16), parseInt(g, 16), parseInt(b, 16), 1);
            }

            if (value.value.length === 8) {
              var r = value.value.substring(0, 2);
              var g = value.value.substring(2, 4);
              var b = value.value.substring(4, 6);
              var a = value.value.substring(6, 8);
              return pack(parseInt(r, 16), parseInt(g, 16), parseInt(b, 16), parseInt(a, 16) / 255);
            }
          }

          if (value.type === TokenType.IDENT_TOKEN) {
            var namedColor = COLORS[value.value.toUpperCase()];

            if (typeof namedColor !== 'undefined') {
              return namedColor;
            }
          }

          return COLORS.TRANSPARENT;
        }
      };

      var isTransparent = function isTransparent(color) {
        return (0xff & color) === 0;
      };

      var asString = function asString(color) {
        var alpha = 0xff & color;
        var blue = 0xff & color >> 8;
        var green = 0xff & color >> 16;
        var red = 0xff & color >> 24;
        return alpha < 255 ? "rgba(" + red + "," + green + "," + blue + "," + alpha / 255 + ")" : "rgb(" + red + "," + green + "," + blue + ")";
      };

      var pack = function pack(r, g, b, a) {
        return (r << 24 | g << 16 | b << 8 | Math.round(a * 255) << 0) >>> 0;
      };

      var getTokenColorValue = function getTokenColorValue(token, i) {
        if (token.type === TokenType.NUMBER_TOKEN) {
          return token.number;
        }

        if (token.type === TokenType.PERCENTAGE_TOKEN) {
          var max = i === 3 ? 1 : 255;
          return i === 3 ? token.number / 100 * max : Math.round(token.number / 100 * max);
        }

        return 0;
      };

      var rgb = function rgb(args) {
        var tokens = args.filter(nonFunctionArgSeparator);

        if (tokens.length === 3) {
          var _a = tokens.map(getTokenColorValue),
              r = _a[0],
              g = _a[1],
              b = _a[2];

          return pack(r, g, b, 1);
        }

        if (tokens.length === 4) {
          var _b = tokens.map(getTokenColorValue),
              r = _b[0],
              g = _b[1],
              b = _b[2],
              a = _b[3];

          return pack(r, g, b, a);
        }

        return 0;
      };

      function hue2rgb(t1, t2, hue) {
        if (hue < 0) {
          hue += 1;
        }

        if (hue >= 1) {
          hue -= 1;
        }

        if (hue < 1 / 6) {
          return (t2 - t1) * hue * 6 + t1;
        } else if (hue < 1 / 2) {
          return t2;
        } else if (hue < 2 / 3) {
          return (t2 - t1) * 6 * (2 / 3 - hue) + t1;
        } else {
          return t1;
        }
      }

      var hsl = function hsl(args) {
        var tokens = args.filter(nonFunctionArgSeparator);
        var hue = tokens[0],
            saturation = tokens[1],
            lightness = tokens[2],
            alpha = tokens[3];
        var h = (hue.type === TokenType.NUMBER_TOKEN ? deg(hue.number) : angle.parse(hue)) / (Math.PI * 2);
        var s = isLengthPercentage(saturation) ? saturation.number / 100 : 0;
        var l = isLengthPercentage(lightness) ? lightness.number / 100 : 0;
        var a = typeof alpha !== 'undefined' && isLengthPercentage(alpha) ? getAbsoluteValue(alpha, 1) : 1;

        if (s === 0) {
          return pack(l * 255, l * 255, l * 255, 1);
        }

        var t2 = l <= 0.5 ? l * (s + 1) : l + s - l * s;
        var t1 = l * 2 - t2;
        var r = hue2rgb(t1, t2, h + 1 / 3);
        var g = hue2rgb(t1, t2, h);
        var b = hue2rgb(t1, t2, h - 1 / 3);
        return pack(r * 255, g * 255, b * 255, a);
      };

      var SUPPORTED_COLOR_FUNCTIONS = {
        hsl: hsl,
        hsla: hsl,
        rgb: rgb,
        rgba: rgb
      };
      var COLORS = {
        ALICEBLUE: 0xf0f8ffff,
        ANTIQUEWHITE: 0xfaebd7ff,
        AQUA: 0x00ffffff,
        AQUAMARINE: 0x7fffd4ff,
        AZURE: 0xf0ffffff,
        BEIGE: 0xf5f5dcff,
        BISQUE: 0xffe4c4ff,
        BLACK: 0x000000ff,
        BLANCHEDALMOND: 0xffebcdff,
        BLUE: 0x0000ffff,
        BLUEVIOLET: 0x8a2be2ff,
        BROWN: 0xa52a2aff,
        BURLYWOOD: 0xdeb887ff,
        CADETBLUE: 0x5f9ea0ff,
        CHARTREUSE: 0x7fff00ff,
        CHOCOLATE: 0xd2691eff,
        CORAL: 0xff7f50ff,
        CORNFLOWERBLUE: 0x6495edff,
        CORNSILK: 0xfff8dcff,
        CRIMSON: 0xdc143cff,
        CYAN: 0x00ffffff,
        DARKBLUE: 0x00008bff,
        DARKCYAN: 0x008b8bff,
        DARKGOLDENROD: 0xb886bbff,
        DARKGRAY: 0xa9a9a9ff,
        DARKGREEN: 0x006400ff,
        DARKGREY: 0xa9a9a9ff,
        DARKKHAKI: 0xbdb76bff,
        DARKMAGENTA: 0x8b008bff,
        DARKOLIVEGREEN: 0x556b2fff,
        DARKORANGE: 0xff8c00ff,
        DARKORCHID: 0x9932ccff,
        DARKRED: 0x8b0000ff,
        DARKSALMON: 0xe9967aff,
        DARKSEAGREEN: 0x8fbc8fff,
        DARKSLATEBLUE: 0x483d8bff,
        DARKSLATEGRAY: 0x2f4f4fff,
        DARKSLATEGREY: 0x2f4f4fff,
        DARKTURQUOISE: 0x00ced1ff,
        DARKVIOLET: 0x9400d3ff,
        DEEPPINK: 0xff1493ff,
        DEEPSKYBLUE: 0x00bfffff,
        DIMGRAY: 0x696969ff,
        DIMGREY: 0x696969ff,
        DODGERBLUE: 0x1e90ffff,
        FIREBRICK: 0xb22222ff,
        FLORALWHITE: 0xfffaf0ff,
        FORESTGREEN: 0x228b22ff,
        FUCHSIA: 0xff00ffff,
        GAINSBORO: 0xdcdcdcff,
        GHOSTWHITE: 0xf8f8ffff,
        GOLD: 0xffd700ff,
        GOLDENROD: 0xdaa520ff,
        GRAY: 0x808080ff,
        GREEN: 0x008000ff,
        GREENYELLOW: 0xadff2fff,
        GREY: 0x808080ff,
        HONEYDEW: 0xf0fff0ff,
        HOTPINK: 0xff69b4ff,
        INDIANRED: 0xcd5c5cff,
        INDIGO: 0x4b0082ff,
        IVORY: 0xfffff0ff,
        KHAKI: 0xf0e68cff,
        LAVENDER: 0xe6e6faff,
        LAVENDERBLUSH: 0xfff0f5ff,
        LAWNGREEN: 0x7cfc00ff,
        LEMONCHIFFON: 0xfffacdff,
        LIGHTBLUE: 0xadd8e6ff,
        LIGHTCORAL: 0xf08080ff,
        LIGHTCYAN: 0xe0ffffff,
        LIGHTGOLDENRODYELLOW: 0xfafad2ff,
        LIGHTGRAY: 0xd3d3d3ff,
        LIGHTGREEN: 0x90ee90ff,
        LIGHTGREY: 0xd3d3d3ff,
        LIGHTPINK: 0xffb6c1ff,
        LIGHTSALMON: 0xffa07aff,
        LIGHTSEAGREEN: 0x20b2aaff,
        LIGHTSKYBLUE: 0x87cefaff,
        LIGHTSLATEGRAY: 0x778899ff,
        LIGHTSLATEGREY: 0x778899ff,
        LIGHTSTEELBLUE: 0xb0c4deff,
        LIGHTYELLOW: 0xffffe0ff,
        LIME: 0x00ff00ff,
        LIMEGREEN: 0x32cd32ff,
        LINEN: 0xfaf0e6ff,
        MAGENTA: 0xff00ffff,
        MAROON: 0x800000ff,
        MEDIUMAQUAMARINE: 0x66cdaaff,
        MEDIUMBLUE: 0x0000cdff,
        MEDIUMORCHID: 0xba55d3ff,
        MEDIUMPURPLE: 0x9370dbff,
        MEDIUMSEAGREEN: 0x3cb371ff,
        MEDIUMSLATEBLUE: 0x7b68eeff,
        MEDIUMSPRINGGREEN: 0x00fa9aff,
        MEDIUMTURQUOISE: 0x48d1ccff,
        MEDIUMVIOLETRED: 0xc71585ff,
        MIDNIGHTBLUE: 0x191970ff,
        MINTCREAM: 0xf5fffaff,
        MISTYROSE: 0xffe4e1ff,
        MOCCASIN: 0xffe4b5ff,
        NAVAJOWHITE: 0xffdeadff,
        NAVY: 0x000080ff,
        OLDLACE: 0xfdf5e6ff,
        OLIVE: 0x808000ff,
        OLIVEDRAB: 0x6b8e23ff,
        ORANGE: 0xffa500ff,
        ORANGERED: 0xff4500ff,
        ORCHID: 0xda70d6ff,
        PALEGOLDENROD: 0xeee8aaff,
        PALEGREEN: 0x98fb98ff,
        PALETURQUOISE: 0xafeeeeff,
        PALEVIOLETRED: 0xdb7093ff,
        PAPAYAWHIP: 0xffefd5ff,
        PEACHPUFF: 0xffdab9ff,
        PERU: 0xcd853fff,
        PINK: 0xffc0cbff,
        PLUM: 0xdda0ddff,
        POWDERBLUE: 0xb0e0e6ff,
        PURPLE: 0x800080ff,
        REBECCAPURPLE: 0x663399ff,
        RED: 0xff0000ff,
        ROSYBROWN: 0xbc8f8fff,
        ROYALBLUE: 0x4169e1ff,
        SADDLEBROWN: 0x8b4513ff,
        SALMON: 0xfa8072ff,
        SANDYBROWN: 0xf4a460ff,
        SEAGREEN: 0x2e8b57ff,
        SEASHELL: 0xfff5eeff,
        SIENNA: 0xa0522dff,
        SILVER: 0xc0c0c0ff,
        SKYBLUE: 0x87ceebff,
        SLATEBLUE: 0x6a5acdff,
        SLATEGRAY: 0x708090ff,
        SLATEGREY: 0x708090ff,
        SNOW: 0xfffafaff,
        SPRINGGREEN: 0x00ff7fff,
        STEELBLUE: 0x4682b4ff,
        TAN: 0xd2b48cff,
        TEAL: 0x008080ff,
        THISTLE: 0xd8bfd8ff,
        TOMATO: 0xff6347ff,
        TRANSPARENT: 0x00000000,
        TURQUOISE: 0x40e0d0ff,
        VIOLET: 0xee82eeff,
        WHEAT: 0xf5deb3ff,
        WHITE: 0xffffffff,
        WHITESMOKE: 0xf5f5f5ff,
        YELLOW: 0xffff00ff,
        YELLOWGREEN: 0x9acd32ff
      };
      var PropertyDescriptorParsingType;

      (function (PropertyDescriptorParsingType) {
        PropertyDescriptorParsingType[PropertyDescriptorParsingType["VALUE"] = 0] = "VALUE";
        PropertyDescriptorParsingType[PropertyDescriptorParsingType["LIST"] = 1] = "LIST";
        PropertyDescriptorParsingType[PropertyDescriptorParsingType["IDENT_VALUE"] = 2] = "IDENT_VALUE";
        PropertyDescriptorParsingType[PropertyDescriptorParsingType["TYPE_VALUE"] = 3] = "TYPE_VALUE";
        PropertyDescriptorParsingType[PropertyDescriptorParsingType["TOKEN_VALUE"] = 4] = "TOKEN_VALUE";
      })(PropertyDescriptorParsingType || (PropertyDescriptorParsingType = {}));

      var BACKGROUND_CLIP;

      (function (BACKGROUND_CLIP) {
        BACKGROUND_CLIP[BACKGROUND_CLIP["BORDER_BOX"] = 0] = "BORDER_BOX";
        BACKGROUND_CLIP[BACKGROUND_CLIP["PADDING_BOX"] = 1] = "PADDING_BOX";
        BACKGROUND_CLIP[BACKGROUND_CLIP["CONTENT_BOX"] = 2] = "CONTENT_BOX";
      })(BACKGROUND_CLIP || (BACKGROUND_CLIP = {}));

      var backgroundClip = {
        name: 'background-clip',
        initialValue: 'border-box',
        prefix: false,
        type: PropertyDescriptorParsingType.LIST,
        parse: function parse(tokens) {
          return tokens.map(function (token) {
            if (isIdentToken(token)) {
              switch (token.value) {
                case 'padding-box':
                  return BACKGROUND_CLIP.PADDING_BOX;

                case 'content-box':
                  return BACKGROUND_CLIP.CONTENT_BOX;
              }
            }

            return BACKGROUND_CLIP.BORDER_BOX;
          });
        }
      };
      var backgroundColor = {
        name: "background-color",
        initialValue: 'transparent',
        prefix: false,
        type: PropertyDescriptorParsingType.TYPE_VALUE,
        format: 'color'
      };

      var parseColorStop = function parseColorStop(args) {
        var color$1 = color.parse(args[0]);
        var stop = args[1];
        return stop && isLengthPercentage(stop) ? {
          color: color$1,
          stop: stop
        } : {
          color: color$1,
          stop: null
        };
      };

      var processColorStops = function processColorStops(stops, lineLength) {
        var first = stops[0];
        var last = stops[stops.length - 1];

        if (first.stop === null) {
          first.stop = ZERO_LENGTH;
        }

        if (last.stop === null) {
          last.stop = HUNDRED_PERCENT;
        }

        var processStops = [];
        var previous = 0;

        for (var i = 0; i < stops.length; i++) {
          var stop_1 = stops[i].stop;

          if (stop_1 !== null) {
            var absoluteValue = getAbsoluteValue(stop_1, lineLength);

            if (absoluteValue > previous) {
              processStops.push(absoluteValue);
            } else {
              processStops.push(previous);
            }

            previous = absoluteValue;
          } else {
            processStops.push(null);
          }
        }

        var gapBegin = null;

        for (var i = 0; i < processStops.length; i++) {
          var stop_2 = processStops[i];

          if (stop_2 === null) {
            if (gapBegin === null) {
              gapBegin = i;
            }
          } else if (gapBegin !== null) {
            var gapLength = i - gapBegin;
            var beforeGap = processStops[gapBegin - 1];
            var gapValue = (stop_2 - beforeGap) / (gapLength + 1);

            for (var g = 1; g <= gapLength; g++) {
              processStops[gapBegin + g - 1] = gapValue * g;
            }

            gapBegin = null;
          }
        }

        return stops.map(function (_a, i) {
          var color = _a.color;
          return {
            color: color,
            stop: Math.max(Math.min(1, processStops[i] / lineLength), 0)
          };
        });
      };

      var getAngleFromCorner = function getAngleFromCorner(corner, width, height) {
        var centerX = width / 2;
        var centerY = height / 2;
        var x = getAbsoluteValue(corner[0], width) - centerX;
        var y = centerY - getAbsoluteValue(corner[1], height);
        return (Math.atan2(y, x) + Math.PI * 2) % (Math.PI * 2);
      };

      var calculateGradientDirection = function calculateGradientDirection(angle, width, height) {
        var radian = typeof angle === 'number' ? angle : getAngleFromCorner(angle, width, height);
        var lineLength = Math.abs(width * Math.sin(radian)) + Math.abs(height * Math.cos(radian));
        var halfWidth = width / 2;
        var halfHeight = height / 2;
        var halfLineLength = lineLength / 2;
        var yDiff = Math.sin(radian - Math.PI / 2) * halfLineLength;
        var xDiff = Math.cos(radian - Math.PI / 2) * halfLineLength;
        return [lineLength, halfWidth - xDiff, halfWidth + xDiff, halfHeight - yDiff, halfHeight + yDiff];
      };

      var distance = function distance(a, b) {
        return Math.sqrt(a * a + b * b);
      };

      var findCorner = function findCorner(width, height, x, y, closest) {
        var corners = [[0, 0], [0, height], [width, 0], [width, height]];
        return corners.reduce(function (stat, corner) {
          var cx = corner[0],
              cy = corner[1];
          var d = distance(x - cx, y - cy);

          if (closest ? d < stat.optimumDistance : d > stat.optimumDistance) {
            return {
              optimumCorner: corner,
              optimumDistance: d
            };
          }

          return stat;
        }, {
          optimumDistance: closest ? Infinity : -Infinity,
          optimumCorner: null
        }).optimumCorner;
      };

      var calculateRadius = function calculateRadius(gradient, x, y, width, height) {
        var rx = 0;
        var ry = 0;

        switch (gradient.size) {
          case CSSRadialExtent.CLOSEST_SIDE:
            // The ending shape is sized so that that it exactly meets the side of the gradient box closest to the gradient’s center.
            // If the shape is an ellipse, it exactly meets the closest side in each dimension.
            if (gradient.shape === CSSRadialShape.CIRCLE) {
              rx = ry = Math.min(Math.abs(x), Math.abs(x - width), Math.abs(y), Math.abs(y - height));
            } else if (gradient.shape === CSSRadialShape.ELLIPSE) {
              rx = Math.min(Math.abs(x), Math.abs(x - width));
              ry = Math.min(Math.abs(y), Math.abs(y - height));
            }

            break;

          case CSSRadialExtent.CLOSEST_CORNER:
            // The ending shape is sized so that that it passes through the corner of the gradient box closest to the gradient’s center.
            // If the shape is an ellipse, the ending shape is given the same aspect-ratio it would have if closest-side were specified.
            if (gradient.shape === CSSRadialShape.CIRCLE) {
              rx = ry = Math.min(distance(x, y), distance(x, y - height), distance(x - width, y), distance(x - width, y - height));
            } else if (gradient.shape === CSSRadialShape.ELLIPSE) {
              // Compute the ratio ry/rx (which is to be the same as for "closest-side")
              var c = Math.min(Math.abs(y), Math.abs(y - height)) / Math.min(Math.abs(x), Math.abs(x - width));

              var _a = findCorner(width, height, x, y, true),
                  cx = _a[0],
                  cy = _a[1];

              rx = distance(cx - x, (cy - y) / c);
              ry = c * rx;
            }

            break;

          case CSSRadialExtent.FARTHEST_SIDE:
            // Same as closest-side, except the ending shape is sized based on the farthest side(s)
            if (gradient.shape === CSSRadialShape.CIRCLE) {
              rx = ry = Math.max(Math.abs(x), Math.abs(x - width), Math.abs(y), Math.abs(y - height));
            } else if (gradient.shape === CSSRadialShape.ELLIPSE) {
              rx = Math.max(Math.abs(x), Math.abs(x - width));
              ry = Math.max(Math.abs(y), Math.abs(y - height));
            }

            break;

          case CSSRadialExtent.FARTHEST_CORNER:
            // Same as closest-corner, except the ending shape is sized based on the farthest corner.
            // If the shape is an ellipse, the ending shape is given the same aspect ratio it would have if farthest-side were specified.
            if (gradient.shape === CSSRadialShape.CIRCLE) {
              rx = ry = Math.max(distance(x, y), distance(x, y - height), distance(x - width, y), distance(x - width, y - height));
            } else if (gradient.shape === CSSRadialShape.ELLIPSE) {
              // Compute the ratio ry/rx (which is to be the same as for "farthest-side")
              var c = Math.max(Math.abs(y), Math.abs(y - height)) / Math.max(Math.abs(x), Math.abs(x - width));

              var _b = findCorner(width, height, x, y, false),
                  cx = _b[0],
                  cy = _b[1];

              rx = distance(cx - x, (cy - y) / c);
              ry = c * rx;
            }

            break;
        }

        if (Array.isArray(gradient.size)) {
          rx = getAbsoluteValue(gradient.size[0], width);
          ry = gradient.size.length === 2 ? getAbsoluteValue(gradient.size[1], height) : rx;
        }

        return [rx, ry];
      };

      var linearGradient = function linearGradient(tokens) {
        var angle$1 = deg(180);
        var stops = [];
        parseFunctionArgs(tokens).forEach(function (arg, i) {
          if (i === 0) {
            var firstToken = arg[0];

            if (firstToken.type === TokenType.IDENT_TOKEN && firstToken.value === 'to') {
              angle$1 = parseNamedSide(arg);
              return;
            } else if (isAngle(firstToken)) {
              angle$1 = angle.parse(firstToken);
              return;
            }
          }

          var colorStop = parseColorStop(arg);
          stops.push(colorStop);
        });
        return {
          angle: angle$1,
          stops: stops,
          type: CSSImageType.LINEAR_GRADIENT
        };
      };

      var prefixLinearGradient = function prefixLinearGradient(tokens) {
        var angle$1 = deg(180);
        var stops = [];
        parseFunctionArgs(tokens).forEach(function (arg, i) {
          if (i === 0) {
            var firstToken = arg[0];

            if (firstToken.type === TokenType.IDENT_TOKEN && ['top', 'left', 'right', 'bottom'].indexOf(firstToken.value) !== -1) {
              angle$1 = parseNamedSide(arg);
              return;
            } else if (isAngle(firstToken)) {
              angle$1 = (angle.parse(firstToken) + deg(270)) % deg(360);
              return;
            }
          }

          var colorStop = parseColorStop(arg);
          stops.push(colorStop);
        });
        return {
          angle: angle$1,
          stops: stops,
          type: CSSImageType.LINEAR_GRADIENT
        };
      };

      var testRangeBounds = function testRangeBounds(document) {
        var TEST_HEIGHT = 123;

        if (document.createRange) {
          var range = document.createRange();

          if (range.getBoundingClientRect) {
            var testElement = document.createElement('boundtest');
            testElement.style.height = TEST_HEIGHT + "px";
            testElement.style.display = 'block';
            document.body.appendChild(testElement);
            range.selectNode(testElement);
            var rangeBounds = range.getBoundingClientRect();
            var rangeHeight = Math.round(rangeBounds.height);
            document.body.removeChild(testElement);

            if (rangeHeight === TEST_HEIGHT) {
              return true;
            }
          }
        }

        return false;
      };

      var testCORS = function testCORS() {
        return typeof new Image().crossOrigin !== 'undefined';
      };

      var testResponseType = function testResponseType() {
        return typeof new XMLHttpRequest().responseType === 'string';
      };

      var testSVG = function testSVG(document) {
        var img = new Image();
        var canvas = document.createElement('canvas');
        var ctx = canvas.getContext('2d');

        if (!ctx) {
          return false;
        }

        img.src = "data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg'></svg>";

        try {
          ctx.drawImage(img, 0, 0);
          canvas.toDataURL();
        } catch (e) {
          return false;
        }

        return true;
      };

      var isGreenPixel = function isGreenPixel(data) {
        return data[0] === 0 && data[1] === 255 && data[2] === 0 && data[3] === 255;
      };

      var testForeignObject = function testForeignObject(document) {
        var canvas = document.createElement('canvas');
        var size = 100;
        canvas.width = size;
        canvas.height = size;
        var ctx = canvas.getContext('2d');

        if (!ctx) {
          return Promise.reject(false);
        }

        ctx.fillStyle = 'rgb(0, 255, 0)';
        ctx.fillRect(0, 0, size, size);
        var img = new Image();
        var greenImageSrc = canvas.toDataURL();
        img.src = greenImageSrc;
        var svg = createForeignObjectSVG(size, size, 0, 0, img);
        ctx.fillStyle = 'red';
        ctx.fillRect(0, 0, size, size);
        return loadSerializedSVG(svg).then(function (img) {
          ctx.drawImage(img, 0, 0);
          var data = ctx.getImageData(0, 0, size, size).data;
          ctx.fillStyle = 'red';
          ctx.fillRect(0, 0, size, size);
          var node = document.createElement('div');
          node.style.backgroundImage = "url(" + greenImageSrc + ")";
          node.style.height = size + "px"; // Firefox 55 does not render inline <img /> tags

          return isGreenPixel(data) ? loadSerializedSVG(createForeignObjectSVG(size, size, 0, 0, node)) : Promise.reject(false);
        }).then(function (img) {
          ctx.drawImage(img, 0, 0); // Edge does not render background-images

          return isGreenPixel(ctx.getImageData(0, 0, size, size).data);
        })["catch"](function () {
          return false;
        });
      };

      var createForeignObjectSVG = function createForeignObjectSVG(width, height, x, y, node) {
        var xmlns = 'http://www.w3.org/2000/svg';
        var svg = document.createElementNS(xmlns, 'svg');
        var foreignObject = document.createElementNS(xmlns, 'foreignObject');
        svg.setAttributeNS(null, 'width', width.toString());
        svg.setAttributeNS(null, 'height', height.toString());
        foreignObject.setAttributeNS(null, 'width', '100%');
        foreignObject.setAttributeNS(null, 'height', '100%');
        foreignObject.setAttributeNS(null, 'x', x.toString());
        foreignObject.setAttributeNS(null, 'y', y.toString());
        foreignObject.setAttributeNS(null, 'externalResourcesRequired', 'true');
        svg.appendChild(foreignObject);
        foreignObject.appendChild(node);
        return svg;
      };

      var loadSerializedSVG = function loadSerializedSVG(svg) {
        return new Promise(function (resolve, reject) {
          var img = new Image();

          img.onload = function () {
            return resolve(img);
          };

          img.onerror = reject;
          img.src = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(new XMLSerializer().serializeToString(svg));
        });
      };

      var FEATURES = {
        get SUPPORT_RANGE_BOUNDS() {
          var value = testRangeBounds(document);
          Object.defineProperty(FEATURES, 'SUPPORT_RANGE_BOUNDS', {
            value: value
          });
          return value;
        },

        get SUPPORT_SVG_DRAWING() {
          var value = testSVG(document);
          Object.defineProperty(FEATURES, 'SUPPORT_SVG_DRAWING', {
            value: value
          });
          return value;
        },

        get SUPPORT_FOREIGNOBJECT_DRAWING() {
          var value = typeof Array.from === 'function' && typeof window.fetch === 'function' ? testForeignObject(document) : Promise.resolve(false);
          Object.defineProperty(FEATURES, 'SUPPORT_FOREIGNOBJECT_DRAWING', {
            value: value
          });
          return value;
        },

        get SUPPORT_CORS_IMAGES() {
          var value = testCORS();
          Object.defineProperty(FEATURES, 'SUPPORT_CORS_IMAGES', {
            value: value
          });
          return value;
        },

        get SUPPORT_RESPONSE_TYPE() {
          var value = testResponseType();
          Object.defineProperty(FEATURES, 'SUPPORT_RESPONSE_TYPE', {
            value: value
          });
          return value;
        },

        get SUPPORT_CORS_XHR() {
          var value = ('withCredentials' in new XMLHttpRequest());
          Object.defineProperty(FEATURES, 'SUPPORT_CORS_XHR', {
            value: value
          });
          return value;
        }

      };

      var Logger =
      /** @class */
      function () {
        function Logger(_a) {
          var id = _a.id,
              enabled = _a.enabled;
          this.id = id;
          this.enabled = enabled;
          this.start = Date.now();
        } // eslint-disable-next-line @typescript-eslint/no-explicit-any


        Logger.prototype.debug = function () {
          var args = [];

          for (var _i = 0; _i < arguments.length; _i++) {
            args[_i] = arguments[_i];
          }

          if (this.enabled) {
            // eslint-disable-next-line no-console
            if (typeof window !== 'undefined' && window.console && typeof console.debug === 'function') {
              // eslint-disable-next-line no-console
              console.debug.apply(console, [this.id, this.getTime() + "ms"].concat(args));
            } else {
              this.info.apply(this, args);
            }
          }
        };

        Logger.prototype.getTime = function () {
          return Date.now() - this.start;
        };

        Logger.create = function (options) {
          Logger.instances[options.id] = new Logger(options);
        };

        Logger.destroy = function (id) {
          delete Logger.instances[id];
        };

        Logger.getInstance = function (id) {
          var instance = Logger.instances[id];

          if (typeof instance === 'undefined') {
            throw new Error("No logger instance found with id " + id);
          }

          return instance;
        }; // eslint-disable-next-line @typescript-eslint/no-explicit-any


        Logger.prototype.info = function () {
          var args = [];

          for (var _i = 0; _i < arguments.length; _i++) {
            args[_i] = arguments[_i];
          }

          if (this.enabled) {
            // eslint-disable-next-line no-console
            if (typeof window !== 'undefined' && window.console && typeof console.info === 'function') {
              // eslint-disable-next-line no-console
              console.info.apply(console, [this.id, this.getTime() + "ms"].concat(args));
            }
          }
        }; // eslint-disable-next-line @typescript-eslint/no-explicit-any


        Logger.prototype.error = function () {
          var args = [];

          for (var _i = 0; _i < arguments.length; _i++) {
            args[_i] = arguments[_i];
          }

          if (this.enabled) {
            // eslint-disable-next-line no-console
            if (typeof window !== 'undefined' && window.console && typeof console.error === 'function') {
              // eslint-disable-next-line no-console
              console.error.apply(console, [this.id, this.getTime() + "ms"].concat(args));
            } else {
              this.info.apply(this, args);
            }
          }
        };

        Logger.instances = {};
        return Logger;
      }();

      var CacheStorage =
      /** @class */
      function () {
        function CacheStorage() {}

        CacheStorage.create = function (name, options) {
          return CacheStorage._caches[name] = new Cache(name, options);
        };

        CacheStorage.destroy = function (name) {
          delete CacheStorage._caches[name];
        };

        CacheStorage.open = function (name) {
          var cache = CacheStorage._caches[name];

          if (typeof cache !== 'undefined') {
            return cache;
          }

          throw new Error("Cache with key \"" + name + "\" not found");
        };

        CacheStorage.getOrigin = function (url) {
          var link = CacheStorage._link;

          if (!link) {
            return 'about:blank';
          }

          link.href = url;
          link.href = link.href; // IE9, LOL! - http://jsfiddle.net/niklasvh/2e48b/

          return link.protocol + link.hostname + link.port;
        };

        CacheStorage.isSameOrigin = function (src) {
          return CacheStorage.getOrigin(src) === CacheStorage._origin;
        };

        CacheStorage.setContext = function (window) {
          CacheStorage._link = window.document.createElement('a');
          CacheStorage._origin = CacheStorage.getOrigin(window.location.href);
        };

        CacheStorage.getInstance = function () {
          var current = CacheStorage._current;

          if (current === null) {
            throw new Error("No cache instance attached");
          }

          return current;
        };

        CacheStorage.attachInstance = function (cache) {
          CacheStorage._current = cache;
        };

        CacheStorage.detachInstance = function () {
          CacheStorage._current = null;
        };

        CacheStorage._caches = {};
        CacheStorage._origin = 'about:blank';
        CacheStorage._current = null;
        return CacheStorage;
      }();

      var Cache =
      /** @class */
      function () {
        function Cache(id, options) {
          this.id = id;
          this._options = options;
          this._cache = {};
        }

        Cache.prototype.addImage = function (src) {
          var result = Promise.resolve();

          if (this.has(src)) {
            return result;
          }

          if (isBlobImage(src) || isRenderable(src)) {
            this._cache[src] = this.loadImage(src);
            return result;
          }

          return result;
        }; // eslint-disable-next-line @typescript-eslint/no-explicit-any


        Cache.prototype.match = function (src) {
          return this._cache[src];
        };

        Cache.prototype.loadImage = function (key) {
          return __awaiter(this, void 0, void 0, function () {
            var isSameOrigin, useCORS, useProxy, src;

            var _this = this;

            return __generator(this, function (_a) {
              switch (_a.label) {
                case 0:
                  isSameOrigin = CacheStorage.isSameOrigin(key);
                  useCORS = !isInlineImage(key) && this._options.useCORS === true && FEATURES.SUPPORT_CORS_IMAGES && !isSameOrigin;
                  useProxy = !isInlineImage(key) && !isSameOrigin && typeof this._options.proxy === 'string' && FEATURES.SUPPORT_CORS_XHR && !useCORS;

                  if (!isSameOrigin && this._options.allowTaint === false && !isInlineImage(key) && !useProxy && !useCORS) {
                    return [2
                    /*return*/
                    ];
                  }

                  src = key;
                  if (!useProxy) return [3
                  /*break*/
                  , 2];
                  return [4
                  /*yield*/
                  , this.proxy(src)];

                case 1:
                  src = _a.sent();
                  _a.label = 2;

                case 2:
                  Logger.getInstance(this.id).debug("Added image " + key.substring(0, 256));
                  return [4
                  /*yield*/
                  , new Promise(function (resolve, reject) {
                    var img = new Image();

                    img.onload = function () {
                      return resolve(img);
                    };

                    img.onerror = reject; //ios safari 10.3 taints canvas with data urls unless crossOrigin is set to anonymous

                    if (isInlineBase64Image(src) || useCORS) {
                      img.crossOrigin = 'anonymous';
                    }

                    img.src = src;

                    if (img.complete === true) {
                      // Inline XML images may fail to parse, throwing an Error later on
                      setTimeout(function () {
                        return resolve(img);
                      }, 500);
                    }

                    if (_this._options.imageTimeout > 0) {
                      setTimeout(function () {
                        return reject("Timed out (" + _this._options.imageTimeout + "ms) loading image");
                      }, _this._options.imageTimeout);
                    }
                  })];

                case 3:
                  return [2
                  /*return*/
                  , _a.sent()];
              }
            });
          });
        };

        Cache.prototype.has = function (key) {
          return typeof this._cache[key] !== 'undefined';
        };

        Cache.prototype.keys = function () {
          return Promise.resolve(Object.keys(this._cache));
        };

        Cache.prototype.proxy = function (src) {
          var _this = this;

          var proxy = this._options.proxy;

          if (!proxy) {
            throw new Error('No proxy defined');
          }

          var key = src.substring(0, 256);
          return new Promise(function (resolve, reject) {
            var responseType = FEATURES.SUPPORT_RESPONSE_TYPE ? 'blob' : 'text';
            var xhr = new XMLHttpRequest();

            xhr.onload = function () {
              if (xhr.status === 200) {
                if (responseType === 'text') {
                  resolve(xhr.response);
                } else {
                  var reader_1 = new FileReader();
                  reader_1.addEventListener('load', function () {
                    return resolve(reader_1.result);
                  }, false);
                  reader_1.addEventListener('error', function (e) {
                    return reject(e);
                  }, false);
                  reader_1.readAsDataURL(xhr.response);
                }
              } else {
                reject("Failed to proxy resource " + key + " with status code " + xhr.status);
              }
            };

            xhr.onerror = reject;
            xhr.open('GET', proxy + "?url=" + encodeURIComponent(src) + "&responseType=" + responseType);

            if (responseType !== 'text' && xhr instanceof XMLHttpRequest) {
              xhr.responseType = responseType;
            }

            if (_this._options.imageTimeout) {
              var timeout_1 = _this._options.imageTimeout;
              xhr.timeout = timeout_1;

              xhr.ontimeout = function () {
                return reject("Timed out (" + timeout_1 + "ms) proxying " + key);
              };
            }

            xhr.send();
          });
        };

        return Cache;
      }();

      var INLINE_SVG = /^data:image\/svg\+xml/i;
      var INLINE_BASE64 = /^data:image\/.*;base64,/i;
      var INLINE_IMG = /^data:image\/.*/i;

      var isRenderable = function isRenderable(src) {
        return FEATURES.SUPPORT_SVG_DRAWING || !isSVG(src);
      };

      var isInlineImage = function isInlineImage(src) {
        return INLINE_IMG.test(src);
      };

      var isInlineBase64Image = function isInlineBase64Image(src) {
        return INLINE_BASE64.test(src);
      };

      var isBlobImage = function isBlobImage(src) {
        return src.substr(0, 4) === 'blob';
      };

      var isSVG = function isSVG(src) {
        return src.substr(-3).toLowerCase() === 'svg' || INLINE_SVG.test(src);
      };

      var webkitGradient = function webkitGradient(tokens) {
        var angle = deg(180);
        var stops = [];
        var type = CSSImageType.LINEAR_GRADIENT;
        var shape = CSSRadialShape.CIRCLE;
        var size = CSSRadialExtent.FARTHEST_CORNER;
        var position = [];
        parseFunctionArgs(tokens).forEach(function (arg, i) {
          var firstToken = arg[0];

          if (i === 0) {
            if (isIdentToken(firstToken) && firstToken.value === 'linear') {
              type = CSSImageType.LINEAR_GRADIENT;
              return;
            } else if (isIdentToken(firstToken) && firstToken.value === 'radial') {
              type = CSSImageType.RADIAL_GRADIENT;
              return;
            }
          }

          if (firstToken.type === TokenType.FUNCTION) {
            if (firstToken.name === 'from') {
              var color$1 = color.parse(firstToken.values[0]);
              stops.push({
                stop: ZERO_LENGTH,
                color: color$1
              });
            } else if (firstToken.name === 'to') {
              var color$1 = color.parse(firstToken.values[0]);
              stops.push({
                stop: HUNDRED_PERCENT,
                color: color$1
              });
            } else if (firstToken.name === 'color-stop') {
              var values = firstToken.values.filter(nonFunctionArgSeparator);

              if (values.length === 2) {
                var color$1 = color.parse(values[1]);
                var stop_1 = values[0];

                if (isNumberToken(stop_1)) {
                  stops.push({
                    stop: {
                      type: TokenType.PERCENTAGE_TOKEN,
                      number: stop_1.number * 100,
                      flags: stop_1.flags
                    },
                    color: color$1
                  });
                }
              }
            }
          }
        });
        return type === CSSImageType.LINEAR_GRADIENT ? {
          angle: (angle + deg(180)) % deg(360),
          stops: stops,
          type: type
        } : {
          size: size,
          shape: shape,
          stops: stops,
          position: position,
          type: type
        };
      };

      var CLOSEST_SIDE = 'closest-side';
      var FARTHEST_SIDE = 'farthest-side';
      var CLOSEST_CORNER = 'closest-corner';
      var FARTHEST_CORNER = 'farthest-corner';
      var CIRCLE = 'circle';
      var ELLIPSE = 'ellipse';
      var COVER = 'cover';
      var CONTAIN = 'contain';

      var radialGradient = function radialGradient(tokens) {
        var shape = CSSRadialShape.CIRCLE;
        var size = CSSRadialExtent.FARTHEST_CORNER;
        var stops = [];
        var position = [];
        parseFunctionArgs(tokens).forEach(function (arg, i) {
          var isColorStop = true;

          if (i === 0) {
            var isAtPosition_1 = false;
            isColorStop = arg.reduce(function (acc, token) {
              if (isAtPosition_1) {
                if (isIdentToken(token)) {
                  switch (token.value) {
                    case 'center':
                      position.push(FIFTY_PERCENT);
                      return acc;

                    case 'top':
                    case 'left':
                      position.push(ZERO_LENGTH);
                      return acc;

                    case 'right':
                    case 'bottom':
                      position.push(HUNDRED_PERCENT);
                      return acc;
                  }
                } else if (isLengthPercentage(token) || isLength(token)) {
                  position.push(token);
                }
              } else if (isIdentToken(token)) {
                switch (token.value) {
                  case CIRCLE:
                    shape = CSSRadialShape.CIRCLE;
                    return false;

                  case ELLIPSE:
                    shape = CSSRadialShape.ELLIPSE;
                    return false;

                  case 'at':
                    isAtPosition_1 = true;
                    return false;

                  case CLOSEST_SIDE:
                    size = CSSRadialExtent.CLOSEST_SIDE;
                    return false;

                  case COVER:
                  case FARTHEST_SIDE:
                    size = CSSRadialExtent.FARTHEST_SIDE;
                    return false;

                  case CONTAIN:
                  case CLOSEST_CORNER:
                    size = CSSRadialExtent.CLOSEST_CORNER;
                    return false;

                  case FARTHEST_CORNER:
                    size = CSSRadialExtent.FARTHEST_CORNER;
                    return false;
                }
              } else if (isLength(token) || isLengthPercentage(token)) {
                if (!Array.isArray(size)) {
                  size = [];
                }

                size.push(token);
                return false;
              }

              return acc;
            }, isColorStop);
          }

          if (isColorStop) {
            var colorStop = parseColorStop(arg);
            stops.push(colorStop);
          }
        });
        return {
          size: size,
          shape: shape,
          stops: stops,
          position: position,
          type: CSSImageType.RADIAL_GRADIENT
        };
      };

      var prefixRadialGradient = function prefixRadialGradient(tokens) {
        var shape = CSSRadialShape.CIRCLE;
        var size = CSSRadialExtent.FARTHEST_CORNER;
        var stops = [];
        var position = [];
        parseFunctionArgs(tokens).forEach(function (arg, i) {
          var isColorStop = true;

          if (i === 0) {
            isColorStop = arg.reduce(function (acc, token) {
              if (isIdentToken(token)) {
                switch (token.value) {
                  case 'center':
                    position.push(FIFTY_PERCENT);
                    return false;

                  case 'top':
                  case 'left':
                    position.push(ZERO_LENGTH);
                    return false;

                  case 'right':
                  case 'bottom':
                    position.push(HUNDRED_PERCENT);
                    return false;
                }
              } else if (isLengthPercentage(token) || isLength(token)) {
                position.push(token);
                return false;
              }

              return acc;
            }, isColorStop);
          } else if (i === 1) {
            isColorStop = arg.reduce(function (acc, token) {
              if (isIdentToken(token)) {
                switch (token.value) {
                  case CIRCLE:
                    shape = CSSRadialShape.CIRCLE;
                    return false;

                  case ELLIPSE:
                    shape = CSSRadialShape.ELLIPSE;
                    return false;

                  case CONTAIN:
                  case CLOSEST_SIDE:
                    size = CSSRadialExtent.CLOSEST_SIDE;
                    return false;

                  case FARTHEST_SIDE:
                    size = CSSRadialExtent.FARTHEST_SIDE;
                    return false;

                  case CLOSEST_CORNER:
                    size = CSSRadialExtent.CLOSEST_CORNER;
                    return false;

                  case COVER:
                  case FARTHEST_CORNER:
                    size = CSSRadialExtent.FARTHEST_CORNER;
                    return false;
                }
              } else if (isLength(token) || isLengthPercentage(token)) {
                if (!Array.isArray(size)) {
                  size = [];
                }

                size.push(token);
                return false;
              }

              return acc;
            }, isColorStop);
          }

          if (isColorStop) {
            var colorStop = parseColorStop(arg);
            stops.push(colorStop);
          }
        });
        return {
          size: size,
          shape: shape,
          stops: stops,
          position: position,
          type: CSSImageType.RADIAL_GRADIENT
        };
      };

      var CSSImageType;

      (function (CSSImageType) {
        CSSImageType[CSSImageType["URL"] = 0] = "URL";
        CSSImageType[CSSImageType["LINEAR_GRADIENT"] = 1] = "LINEAR_GRADIENT";
        CSSImageType[CSSImageType["RADIAL_GRADIENT"] = 2] = "RADIAL_GRADIENT";
      })(CSSImageType || (CSSImageType = {}));

      var isLinearGradient = function isLinearGradient(background) {
        return background.type === CSSImageType.LINEAR_GRADIENT;
      };

      var isRadialGradient = function isRadialGradient(background) {
        return background.type === CSSImageType.RADIAL_GRADIENT;
      };

      var CSSRadialShape;

      (function (CSSRadialShape) {
        CSSRadialShape[CSSRadialShape["CIRCLE"] = 0] = "CIRCLE";
        CSSRadialShape[CSSRadialShape["ELLIPSE"] = 1] = "ELLIPSE";
      })(CSSRadialShape || (CSSRadialShape = {}));

      var CSSRadialExtent;

      (function (CSSRadialExtent) {
        CSSRadialExtent[CSSRadialExtent["CLOSEST_SIDE"] = 0] = "CLOSEST_SIDE";
        CSSRadialExtent[CSSRadialExtent["FARTHEST_SIDE"] = 1] = "FARTHEST_SIDE";
        CSSRadialExtent[CSSRadialExtent["CLOSEST_CORNER"] = 2] = "CLOSEST_CORNER";
        CSSRadialExtent[CSSRadialExtent["FARTHEST_CORNER"] = 3] = "FARTHEST_CORNER";
      })(CSSRadialExtent || (CSSRadialExtent = {}));

      var image = {
        name: 'image',
        parse: function parse(value) {
          if (value.type === TokenType.URL_TOKEN) {
            var image_1 = {
              url: value.value,
              type: CSSImageType.URL
            };
            CacheStorage.getInstance().addImage(value.value);
            return image_1;
          }

          if (value.type === TokenType.FUNCTION) {
            var imageFunction = SUPPORTED_IMAGE_FUNCTIONS[value.name];

            if (typeof imageFunction === 'undefined') {
              throw new Error("Attempting to parse an unsupported image function \"" + value.name + "\"");
            }

            return imageFunction(value.values);
          }

          throw new Error("Unsupported image type");
        }
      };

      function isSupportedImage(value) {
        return value.type !== TokenType.FUNCTION || SUPPORTED_IMAGE_FUNCTIONS[value.name];
      }

      var SUPPORTED_IMAGE_FUNCTIONS = {
        'linear-gradient': linearGradient,
        '-moz-linear-gradient': prefixLinearGradient,
        '-ms-linear-gradient': prefixLinearGradient,
        '-o-linear-gradient': prefixLinearGradient,
        '-webkit-linear-gradient': prefixLinearGradient,
        'radial-gradient': radialGradient,
        '-moz-radial-gradient': prefixRadialGradient,
        '-ms-radial-gradient': prefixRadialGradient,
        '-o-radial-gradient': prefixRadialGradient,
        '-webkit-radial-gradient': prefixRadialGradient,
        '-webkit-gradient': webkitGradient
      };
      var backgroundImage = {
        name: 'background-image',
        initialValue: 'none',
        type: PropertyDescriptorParsingType.LIST,
        prefix: false,
        parse: function parse(tokens) {
          if (tokens.length === 0) {
            return [];
          }

          var first = tokens[0];

          if (first.type === TokenType.IDENT_TOKEN && first.value === 'none') {
            return [];
          }

          return tokens.filter(function (value) {
            return nonFunctionArgSeparator(value) && isSupportedImage(value);
          }).map(image.parse);
        }
      };
      var backgroundOrigin = {
        name: 'background-origin',
        initialValue: 'border-box',
        prefix: false,
        type: PropertyDescriptorParsingType.LIST,
        parse: function parse(tokens) {
          return tokens.map(function (token) {
            if (isIdentToken(token)) {
              switch (token.value) {
                case 'padding-box':
                  return 1
                  /* PADDING_BOX */
                  ;

                case 'content-box':
                  return 2
                  /* CONTENT_BOX */
                  ;
              }
            }

            return 0
            /* BORDER_BOX */
            ;
          });
        }
      };
      var backgroundPosition = {
        name: 'background-position',
        initialValue: '0% 0%',
        type: PropertyDescriptorParsingType.LIST,
        prefix: false,
        parse: function parse(tokens) {
          return parseFunctionArgs(tokens).map(function (values) {
            return values.filter(isLengthPercentage);
          }).map(parseLengthPercentageTuple);
        }
      };
      var BACKGROUND_REPEAT;

      (function (BACKGROUND_REPEAT) {
        BACKGROUND_REPEAT[BACKGROUND_REPEAT["REPEAT"] = 0] = "REPEAT";
        BACKGROUND_REPEAT[BACKGROUND_REPEAT["NO_REPEAT"] = 1] = "NO_REPEAT";
        BACKGROUND_REPEAT[BACKGROUND_REPEAT["REPEAT_X"] = 2] = "REPEAT_X";
        BACKGROUND_REPEAT[BACKGROUND_REPEAT["REPEAT_Y"] = 3] = "REPEAT_Y";
      })(BACKGROUND_REPEAT || (BACKGROUND_REPEAT = {}));

      var backgroundRepeat = {
        name: 'background-repeat',
        initialValue: 'repeat',
        prefix: false,
        type: PropertyDescriptorParsingType.LIST,
        parse: function parse(tokens) {
          return parseFunctionArgs(tokens).map(function (values) {
            return values.filter(isIdentToken).map(function (token) {
              return token.value;
            }).join(' ');
          }).map(parseBackgroundRepeat);
        }
      };

      var parseBackgroundRepeat = function parseBackgroundRepeat(value) {
        switch (value) {
          case 'no-repeat':
            return BACKGROUND_REPEAT.NO_REPEAT;

          case 'repeat-x':
          case 'repeat no-repeat':
            return BACKGROUND_REPEAT.REPEAT_X;

          case 'repeat-y':
          case 'no-repeat repeat':
            return BACKGROUND_REPEAT.REPEAT_Y;

          case 'repeat':
          default:
            return BACKGROUND_REPEAT.REPEAT;
        }
      };

      var BACKGROUND_SIZE;

      (function (BACKGROUND_SIZE) {
        BACKGROUND_SIZE["AUTO"] = "auto";
        BACKGROUND_SIZE["CONTAIN"] = "contain";
        BACKGROUND_SIZE["COVER"] = "cover";
      })(BACKGROUND_SIZE || (BACKGROUND_SIZE = {}));

      var backgroundSize = {
        name: 'background-size',
        initialValue: '0',
        prefix: false,
        type: PropertyDescriptorParsingType.LIST,
        parse: function parse(tokens) {
          return parseFunctionArgs(tokens).map(function (values) {
            return values.filter(isBackgroundSizeInfoToken);
          });
        }
      };

      var isBackgroundSizeInfoToken = function isBackgroundSizeInfoToken(value) {
        return isIdentToken(value) || isLengthPercentage(value);
      };

      var borderColorForSide = function borderColorForSide(side) {
        return {
          name: "border-" + side + "-color",
          initialValue: 'transparent',
          prefix: false,
          type: PropertyDescriptorParsingType.TYPE_VALUE,
          format: 'color'
        };
      };

      var borderTopColor = borderColorForSide('top');
      var borderRightColor = borderColorForSide('right');
      var borderBottomColor = borderColorForSide('bottom');
      var borderLeftColor = borderColorForSide('left');

      var borderRadiusForSide = function borderRadiusForSide(side) {
        return {
          name: "border-radius-" + side,
          initialValue: '0 0',
          prefix: false,
          type: PropertyDescriptorParsingType.LIST,
          parse: function parse(tokens) {
            return parseLengthPercentageTuple(tokens.filter(isLengthPercentage));
          }
        };
      };

      var borderTopLeftRadius = borderRadiusForSide('top-left');
      var borderTopRightRadius = borderRadiusForSide('top-right');
      var borderBottomRightRadius = borderRadiusForSide('bottom-right');
      var borderBottomLeftRadius = borderRadiusForSide('bottom-left');
      var BORDER_STYLE;

      (function (BORDER_STYLE) {
        BORDER_STYLE[BORDER_STYLE["NONE"] = 0] = "NONE";
        BORDER_STYLE[BORDER_STYLE["SOLID"] = 1] = "SOLID";
      })(BORDER_STYLE || (BORDER_STYLE = {}));

      var borderStyleForSide = function borderStyleForSide(side) {
        return {
          name: "border-" + side + "-style",
          initialValue: 'solid',
          prefix: false,
          type: PropertyDescriptorParsingType.IDENT_VALUE,
          parse: function parse(style) {
            switch (style) {
              case 'none':
                return BORDER_STYLE.NONE;
            }

            return BORDER_STYLE.SOLID;
          }
        };
      };

      var borderTopStyle = borderStyleForSide('top');
      var borderRightStyle = borderStyleForSide('right');
      var borderBottomStyle = borderStyleForSide('bottom');
      var borderLeftStyle = borderStyleForSide('left');

      var borderWidthForSide = function borderWidthForSide(side) {
        return {
          name: "border-" + side + "-width",
          initialValue: '0',
          type: PropertyDescriptorParsingType.VALUE,
          prefix: false,
          parse: function parse(token) {
            if (isDimensionToken(token)) {
              return token.number;
            }

            return 0;
          }
        };
      };

      var borderTopWidth = borderWidthForSide('top');
      var borderRightWidth = borderWidthForSide('right');
      var borderBottomWidth = borderWidthForSide('bottom');
      var borderLeftWidth = borderWidthForSide('left');
      var color$1 = {
        name: "color",
        initialValue: 'transparent',
        prefix: false,
        type: PropertyDescriptorParsingType.TYPE_VALUE,
        format: 'color'
      };
      var display = {
        name: 'display',
        initialValue: 'inline-block',
        prefix: false,
        type: PropertyDescriptorParsingType.LIST,
        parse: function parse(tokens) {
          return tokens.filter(isIdentToken).reduce(function (bit, token) {
            return bit | parseDisplayValue(token.value);
          }, 0
          /* NONE */
          );
        }
      };

      var parseDisplayValue = function parseDisplayValue(display) {
        switch (display) {
          case 'block':
            return 2
            /* BLOCK */
            ;

          case 'inline':
            return 4
            /* INLINE */
            ;

          case 'run-in':
            return 8
            /* RUN_IN */
            ;

          case 'flow':
            return 16
            /* FLOW */
            ;

          case 'flow-root':
            return 32
            /* FLOW_ROOT */
            ;

          case 'table':
            return 64
            /* TABLE */
            ;

          case 'flex':
          case '-webkit-flex':
            return 128
            /* FLEX */
            ;

          case 'grid':
          case '-ms-grid':
            return 256
            /* GRID */
            ;

          case 'ruby':
            return 512
            /* RUBY */
            ;

          case 'subgrid':
            return 1024
            /* SUBGRID */
            ;

          case 'list-item':
            return 2048
            /* LIST_ITEM */
            ;

          case 'table-row-group':
            return 4096
            /* TABLE_ROW_GROUP */
            ;

          case 'table-header-group':
            return 8192
            /* TABLE_HEADER_GROUP */
            ;

          case 'table-footer-group':
            return 16384
            /* TABLE_FOOTER_GROUP */
            ;

          case 'table-row':
            return 32768
            /* TABLE_ROW */
            ;

          case 'table-cell':
            return 65536
            /* TABLE_CELL */
            ;

          case 'table-column-group':
            return 131072
            /* TABLE_COLUMN_GROUP */
            ;

          case 'table-column':
            return 262144
            /* TABLE_COLUMN */
            ;

          case 'table-caption':
            return 524288
            /* TABLE_CAPTION */
            ;

          case 'ruby-base':
            return 1048576
            /* RUBY_BASE */
            ;

          case 'ruby-text':
            return 2097152
            /* RUBY_TEXT */
            ;

          case 'ruby-base-container':
            return 4194304
            /* RUBY_BASE_CONTAINER */
            ;

          case 'ruby-text-container':
            return 8388608
            /* RUBY_TEXT_CONTAINER */
            ;

          case 'contents':
            return 16777216
            /* CONTENTS */
            ;

          case 'inline-block':
            return 33554432
            /* INLINE_BLOCK */
            ;

          case 'inline-list-item':
            return 67108864
            /* INLINE_LIST_ITEM */
            ;

          case 'inline-table':
            return 134217728
            /* INLINE_TABLE */
            ;

          case 'inline-flex':
            return 268435456
            /* INLINE_FLEX */
            ;

          case 'inline-grid':
            return 536870912
            /* INLINE_GRID */
            ;
        }

        return 0
        /* NONE */
        ;
      };

      var FLOAT;

      (function (FLOAT) {
        FLOAT[FLOAT["NONE"] = 0] = "NONE";
        FLOAT[FLOAT["LEFT"] = 1] = "LEFT";
        FLOAT[FLOAT["RIGHT"] = 2] = "RIGHT";
        FLOAT[FLOAT["INLINE_START"] = 3] = "INLINE_START";
        FLOAT[FLOAT["INLINE_END"] = 4] = "INLINE_END";
      })(FLOAT || (FLOAT = {}));

      var _float = {
        name: 'float',
        initialValue: 'none',
        prefix: false,
        type: PropertyDescriptorParsingType.IDENT_VALUE,
        parse: function parse(_float2) {
          switch (_float2) {
            case 'left':
              return FLOAT.LEFT;

            case 'right':
              return FLOAT.RIGHT;

            case 'inline-start':
              return FLOAT.INLINE_START;

            case 'inline-end':
              return FLOAT.INLINE_END;
          }

          return FLOAT.NONE;
        }
      };
      var letterSpacing = {
        name: 'letter-spacing',
        initialValue: '0',
        prefix: false,
        type: PropertyDescriptorParsingType.VALUE,
        parse: function parse(token) {
          if (token.type === TokenType.IDENT_TOKEN && token.value === 'normal') {
            return 0;
          }

          if (token.type === TokenType.NUMBER_TOKEN) {
            return token.number;
          }

          if (token.type === TokenType.DIMENSION_TOKEN) {
            return token.number;
          }

          return 0;
        }
      };
      var LINE_BREAK;

      (function (LINE_BREAK) {
        LINE_BREAK["NORMAL"] = "normal";
        LINE_BREAK["STRICT"] = "strict";
      })(LINE_BREAK || (LINE_BREAK = {}));

      var lineBreak = {
        name: 'line-break',
        initialValue: 'normal',
        prefix: false,
        type: PropertyDescriptorParsingType.IDENT_VALUE,
        parse: function parse(lineBreak) {
          switch (lineBreak) {
            case 'strict':
              return LINE_BREAK.STRICT;

            case 'normal':
            default:
              return LINE_BREAK.NORMAL;
          }
        }
      };
      var lineHeight = {
        name: 'line-height',
        initialValue: 'normal',
        prefix: false,
        type: PropertyDescriptorParsingType.TOKEN_VALUE
      };

      var computeLineHeight = function computeLineHeight(token, fontSize) {
        if (isIdentToken(token) && token.value === 'normal') {
          return 1.2 * fontSize;
        } else if (token.type === TokenType.NUMBER_TOKEN) {
          return fontSize * token.number;
        } else if (isLengthPercentage(token)) {
          return getAbsoluteValue(token, fontSize);
        }

        return fontSize;
      };

      var listStyleImage = {
        name: 'list-style-image',
        initialValue: 'none',
        type: PropertyDescriptorParsingType.VALUE,
        prefix: false,
        parse: function parse(token) {
          if (token.type === TokenType.IDENT_TOKEN && token.value === 'none') {
            return null;
          }

          return image.parse(token);
        }
      };
      var LIST_STYLE_POSITION;

      (function (LIST_STYLE_POSITION) {
        LIST_STYLE_POSITION[LIST_STYLE_POSITION["INSIDE"] = 0] = "INSIDE";
        LIST_STYLE_POSITION[LIST_STYLE_POSITION["OUTSIDE"] = 1] = "OUTSIDE";
      })(LIST_STYLE_POSITION || (LIST_STYLE_POSITION = {}));

      var listStylePosition = {
        name: 'list-style-position',
        initialValue: 'outside',
        prefix: false,
        type: PropertyDescriptorParsingType.IDENT_VALUE,
        parse: function parse(position) {
          switch (position) {
            case 'inside':
              return LIST_STYLE_POSITION.INSIDE;

            case 'outside':
            default:
              return LIST_STYLE_POSITION.OUTSIDE;
          }
        }
      };
      var LIST_STYLE_TYPE;

      (function (LIST_STYLE_TYPE) {
        LIST_STYLE_TYPE[LIST_STYLE_TYPE["NONE"] = -1] = "NONE";
        LIST_STYLE_TYPE[LIST_STYLE_TYPE["DISC"] = 0] = "DISC";
        LIST_STYLE_TYPE[LIST_STYLE_TYPE["CIRCLE"] = 1] = "CIRCLE";
        LIST_STYLE_TYPE[LIST_STYLE_TYPE["SQUARE"] = 2] = "SQUARE";
        LIST_STYLE_TYPE[LIST_STYLE_TYPE["DECIMAL"] = 3] = "DECIMAL";
        LIST_STYLE_TYPE[LIST_STYLE_TYPE["CJK_DECIMAL"] = 4] = "CJK_DECIMAL";
        LIST_STYLE_TYPE[LIST_STYLE_TYPE["DECIMAL_LEADING_ZERO"] = 5] = "DECIMAL_LEADING_ZERO";
        LIST_STYLE_TYPE[LIST_STYLE_TYPE["LOWER_ROMAN"] = 6] = "LOWER_ROMAN";
        LIST_STYLE_TYPE[LIST_STYLE_TYPE["UPPER_ROMAN"] = 7] = "UPPER_ROMAN";
        LIST_STYLE_TYPE[LIST_STYLE_TYPE["LOWER_GREEK"] = 8] = "LOWER_GREEK";
        LIST_STYLE_TYPE[LIST_STYLE_TYPE["LOWER_ALPHA"] = 9] = "LOWER_ALPHA";
        LIST_STYLE_TYPE[LIST_STYLE_TYPE["UPPER_ALPHA"] = 10] = "UPPER_ALPHA";
        LIST_STYLE_TYPE[LIST_STYLE_TYPE["ARABIC_INDIC"] = 11] = "ARABIC_INDIC";
        LIST_STYLE_TYPE[LIST_STYLE_TYPE["ARMENIAN"] = 12] = "ARMENIAN";
        LIST_STYLE_TYPE[LIST_STYLE_TYPE["BENGALI"] = 13] = "BENGALI";
        LIST_STYLE_TYPE[LIST_STYLE_TYPE["CAMBODIAN"] = 14] = "CAMBODIAN";
        LIST_STYLE_TYPE[LIST_STYLE_TYPE["CJK_EARTHLY_BRANCH"] = 15] = "CJK_EARTHLY_BRANCH";
        LIST_STYLE_TYPE[LIST_STYLE_TYPE["CJK_HEAVENLY_STEM"] = 16] = "CJK_HEAVENLY_STEM";
        LIST_STYLE_TYPE[LIST_STYLE_TYPE["CJK_IDEOGRAPHIC"] = 17] = "CJK_IDEOGRAPHIC";
        LIST_STYLE_TYPE[LIST_STYLE_TYPE["DEVANAGARI"] = 18] = "DEVANAGARI";
        LIST_STYLE_TYPE[LIST_STYLE_TYPE["ETHIOPIC_NUMERIC"] = 19] = "ETHIOPIC_NUMERIC";
        LIST_STYLE_TYPE[LIST_STYLE_TYPE["GEORGIAN"] = 20] = "GEORGIAN";
        LIST_STYLE_TYPE[LIST_STYLE_TYPE["GUJARATI"] = 21] = "GUJARATI";
        LIST_STYLE_TYPE[LIST_STYLE_TYPE["GURMUKHI"] = 22] = "GURMUKHI";
        LIST_STYLE_TYPE[LIST_STYLE_TYPE["HEBREW"] = 22] = "HEBREW";
        LIST_STYLE_TYPE[LIST_STYLE_TYPE["HIRAGANA"] = 23] = "HIRAGANA";
        LIST_STYLE_TYPE[LIST_STYLE_TYPE["HIRAGANA_IROHA"] = 24] = "HIRAGANA_IROHA";
        LIST_STYLE_TYPE[LIST_STYLE_TYPE["JAPANESE_FORMAL"] = 25] = "JAPANESE_FORMAL";
        LIST_STYLE_TYPE[LIST_STYLE_TYPE["JAPANESE_INFORMAL"] = 26] = "JAPANESE_INFORMAL";
        LIST_STYLE_TYPE[LIST_STYLE_TYPE["KANNADA"] = 27] = "KANNADA";
        LIST_STYLE_TYPE[LIST_STYLE_TYPE["KATAKANA"] = 28] = "KATAKANA";
        LIST_STYLE_TYPE[LIST_STYLE_TYPE["KATAKANA_IROHA"] = 29] = "KATAKANA_IROHA";
        LIST_STYLE_TYPE[LIST_STYLE_TYPE["KHMER"] = 30] = "KHMER";
        LIST_STYLE_TYPE[LIST_STYLE_TYPE["KOREAN_HANGUL_FORMAL"] = 31] = "KOREAN_HANGUL_FORMAL";
        LIST_STYLE_TYPE[LIST_STYLE_TYPE["KOREAN_HANJA_FORMAL"] = 32] = "KOREAN_HANJA_FORMAL";
        LIST_STYLE_TYPE[LIST_STYLE_TYPE["KOREAN_HANJA_INFORMAL"] = 33] = "KOREAN_HANJA_INFORMAL";
        LIST_STYLE_TYPE[LIST_STYLE_TYPE["LAO"] = 34] = "LAO";
        LIST_STYLE_TYPE[LIST_STYLE_TYPE["LOWER_ARMENIAN"] = 35] = "LOWER_ARMENIAN";
        LIST_STYLE_TYPE[LIST_STYLE_TYPE["MALAYALAM"] = 36] = "MALAYALAM";
        LIST_STYLE_TYPE[LIST_STYLE_TYPE["MONGOLIAN"] = 37] = "MONGOLIAN";
        LIST_STYLE_TYPE[LIST_STYLE_TYPE["MYANMAR"] = 38] = "MYANMAR";
        LIST_STYLE_TYPE[LIST_STYLE_TYPE["ORIYA"] = 39] = "ORIYA";
        LIST_STYLE_TYPE[LIST_STYLE_TYPE["PERSIAN"] = 40] = "PERSIAN";
        LIST_STYLE_TYPE[LIST_STYLE_TYPE["SIMP_CHINESE_FORMAL"] = 41] = "SIMP_CHINESE_FORMAL";
        LIST_STYLE_TYPE[LIST_STYLE_TYPE["SIMP_CHINESE_INFORMAL"] = 42] = "SIMP_CHINESE_INFORMAL";
        LIST_STYLE_TYPE[LIST_STYLE_TYPE["TAMIL"] = 43] = "TAMIL";
        LIST_STYLE_TYPE[LIST_STYLE_TYPE["TELUGU"] = 44] = "TELUGU";
        LIST_STYLE_TYPE[LIST_STYLE_TYPE["THAI"] = 45] = "THAI";
        LIST_STYLE_TYPE[LIST_STYLE_TYPE["TIBETAN"] = 46] = "TIBETAN";
        LIST_STYLE_TYPE[LIST_STYLE_TYPE["TRAD_CHINESE_FORMAL"] = 47] = "TRAD_CHINESE_FORMAL";
        LIST_STYLE_TYPE[LIST_STYLE_TYPE["TRAD_CHINESE_INFORMAL"] = 48] = "TRAD_CHINESE_INFORMAL";
        LIST_STYLE_TYPE[LIST_STYLE_TYPE["UPPER_ARMENIAN"] = 49] = "UPPER_ARMENIAN";
        LIST_STYLE_TYPE[LIST_STYLE_TYPE["DISCLOSURE_OPEN"] = 50] = "DISCLOSURE_OPEN";
        LIST_STYLE_TYPE[LIST_STYLE_TYPE["DISCLOSURE_CLOSED"] = 51] = "DISCLOSURE_CLOSED";
      })(LIST_STYLE_TYPE || (LIST_STYLE_TYPE = {}));

      var listStyleType = {
        name: 'list-style-type',
        initialValue: 'none',
        prefix: false,
        type: PropertyDescriptorParsingType.IDENT_VALUE,
        parse: function parse(type) {
          switch (type) {
            case 'disc':
              return LIST_STYLE_TYPE.DISC;

            case 'circle':
              return LIST_STYLE_TYPE.CIRCLE;

            case 'square':
              return LIST_STYLE_TYPE.SQUARE;

            case 'decimal':
              return LIST_STYLE_TYPE.DECIMAL;

            case 'cjk-decimal':
              return LIST_STYLE_TYPE.CJK_DECIMAL;

            case 'decimal-leading-zero':
              return LIST_STYLE_TYPE.DECIMAL_LEADING_ZERO;

            case 'lower-roman':
              return LIST_STYLE_TYPE.LOWER_ROMAN;

            case 'upper-roman':
              return LIST_STYLE_TYPE.UPPER_ROMAN;

            case 'lower-greek':
              return LIST_STYLE_TYPE.LOWER_GREEK;

            case 'lower-alpha':
              return LIST_STYLE_TYPE.LOWER_ALPHA;

            case 'upper-alpha':
              return LIST_STYLE_TYPE.UPPER_ALPHA;

            case 'arabic-indic':
              return LIST_STYLE_TYPE.ARABIC_INDIC;

            case 'armenian':
              return LIST_STYLE_TYPE.ARMENIAN;

            case 'bengali':
              return LIST_STYLE_TYPE.BENGALI;

            case 'cambodian':
              return LIST_STYLE_TYPE.CAMBODIAN;

            case 'cjk-earthly-branch':
              return LIST_STYLE_TYPE.CJK_EARTHLY_BRANCH;

            case 'cjk-heavenly-stem':
              return LIST_STYLE_TYPE.CJK_HEAVENLY_STEM;

            case 'cjk-ideographic':
              return LIST_STYLE_TYPE.CJK_IDEOGRAPHIC;

            case 'devanagari':
              return LIST_STYLE_TYPE.DEVANAGARI;

            case 'ethiopic-numeric':
              return LIST_STYLE_TYPE.ETHIOPIC_NUMERIC;

            case 'georgian':
              return LIST_STYLE_TYPE.GEORGIAN;

            case 'gujarati':
              return LIST_STYLE_TYPE.GUJARATI;

            case 'gurmukhi':
              return LIST_STYLE_TYPE.GURMUKHI;

            case 'hebrew':
              return LIST_STYLE_TYPE.HEBREW;

            case 'hiragana':
              return LIST_STYLE_TYPE.HIRAGANA;

            case 'hiragana-iroha':
              return LIST_STYLE_TYPE.HIRAGANA_IROHA;

            case 'japanese-formal':
              return LIST_STYLE_TYPE.JAPANESE_FORMAL;

            case 'japanese-informal':
              return LIST_STYLE_TYPE.JAPANESE_INFORMAL;

            case 'kannada':
              return LIST_STYLE_TYPE.KANNADA;

            case 'katakana':
              return LIST_STYLE_TYPE.KATAKANA;

            case 'katakana-iroha':
              return LIST_STYLE_TYPE.KATAKANA_IROHA;

            case 'khmer':
              return LIST_STYLE_TYPE.KHMER;

            case 'korean-hangul-formal':
              return LIST_STYLE_TYPE.KOREAN_HANGUL_FORMAL;

            case 'korean-hanja-formal':
              return LIST_STYLE_TYPE.KOREAN_HANJA_FORMAL;

            case 'korean-hanja-informal':
              return LIST_STYLE_TYPE.KOREAN_HANJA_INFORMAL;

            case 'lao':
              return LIST_STYLE_TYPE.LAO;

            case 'lower-armenian':
              return LIST_STYLE_TYPE.LOWER_ARMENIAN;

            case 'malayalam':
              return LIST_STYLE_TYPE.MALAYALAM;

            case 'mongolian':
              return LIST_STYLE_TYPE.MONGOLIAN;

            case 'myanmar':
              return LIST_STYLE_TYPE.MYANMAR;

            case 'oriya':
              return LIST_STYLE_TYPE.ORIYA;

            case 'persian':
              return LIST_STYLE_TYPE.PERSIAN;

            case 'simp-chinese-formal':
              return LIST_STYLE_TYPE.SIMP_CHINESE_FORMAL;

            case 'simp-chinese-informal':
              return LIST_STYLE_TYPE.SIMP_CHINESE_INFORMAL;

            case 'tamil':
              return LIST_STYLE_TYPE.TAMIL;

            case 'telugu':
              return LIST_STYLE_TYPE.TELUGU;

            case 'thai':
              return LIST_STYLE_TYPE.THAI;

            case 'tibetan':
              return LIST_STYLE_TYPE.TIBETAN;

            case 'trad-chinese-formal':
              return LIST_STYLE_TYPE.TRAD_CHINESE_FORMAL;

            case 'trad-chinese-informal':
              return LIST_STYLE_TYPE.TRAD_CHINESE_INFORMAL;

            case 'upper-armenian':
              return LIST_STYLE_TYPE.UPPER_ARMENIAN;

            case 'disclosure-open':
              return LIST_STYLE_TYPE.DISCLOSURE_OPEN;

            case 'disclosure-closed':
              return LIST_STYLE_TYPE.DISCLOSURE_CLOSED;

            case 'none':
            default:
              return LIST_STYLE_TYPE.NONE;
          }
        }
      };

      var marginForSide = function marginForSide(side) {
        return {
          name: "margin-" + side,
          initialValue: '0',
          prefix: false,
          type: PropertyDescriptorParsingType.TOKEN_VALUE
        };
      };

      var marginTop = marginForSide('top');
      var marginRight = marginForSide('right');
      var marginBottom = marginForSide('bottom');
      var marginLeft = marginForSide('left');
      var OVERFLOW;

      (function (OVERFLOW) {
        OVERFLOW[OVERFLOW["VISIBLE"] = 0] = "VISIBLE";
        OVERFLOW[OVERFLOW["HIDDEN"] = 1] = "HIDDEN";
        OVERFLOW[OVERFLOW["SCROLL"] = 2] = "SCROLL";
        OVERFLOW[OVERFLOW["AUTO"] = 3] = "AUTO";
      })(OVERFLOW || (OVERFLOW = {}));

      var overflow = {
        name: 'overflow',
        initialValue: 'visible',
        prefix: false,
        type: PropertyDescriptorParsingType.LIST,
        parse: function parse(tokens) {
          return tokens.filter(isIdentToken).map(function (overflow) {
            switch (overflow.value) {
              case 'hidden':
                return OVERFLOW.HIDDEN;

              case 'scroll':
                return OVERFLOW.SCROLL;

              case 'auto':
                return OVERFLOW.AUTO;

              case 'visible':
              default:
                return OVERFLOW.VISIBLE;
            }
          });
        }
      };
      var OVERFLOW_WRAP;

      (function (OVERFLOW_WRAP) {
        OVERFLOW_WRAP["NORMAL"] = "normal";
        OVERFLOW_WRAP["BREAK_WORD"] = "break-word";
      })(OVERFLOW_WRAP || (OVERFLOW_WRAP = {}));

      var overflowWrap = {
        name: 'overflow-wrap',
        initialValue: 'normal',
        prefix: false,
        type: PropertyDescriptorParsingType.IDENT_VALUE,
        parse: function parse(overflow) {
          switch (overflow) {
            case 'break-word':
              return OVERFLOW_WRAP.BREAK_WORD;

            case 'normal':
            default:
              return OVERFLOW_WRAP.NORMAL;
          }
        }
      };

      var paddingForSide = function paddingForSide(side) {
        return {
          name: "padding-" + side,
          initialValue: '0',
          prefix: false,
          type: PropertyDescriptorParsingType.TYPE_VALUE,
          format: 'length-percentage'
        };
      };

      var paddingTop = paddingForSide('top');
      var paddingRight = paddingForSide('right');
      var paddingBottom = paddingForSide('bottom');
      var paddingLeft = paddingForSide('left');
      var TEXT_ALIGN;

      (function (TEXT_ALIGN) {
        TEXT_ALIGN[TEXT_ALIGN["LEFT"] = 0] = "LEFT";
        TEXT_ALIGN[TEXT_ALIGN["CENTER"] = 1] = "CENTER";
        TEXT_ALIGN[TEXT_ALIGN["RIGHT"] = 2] = "RIGHT";
      })(TEXT_ALIGN || (TEXT_ALIGN = {}));

      var textAlign = {
        name: 'text-align',
        initialValue: 'left',
        prefix: false,
        type: PropertyDescriptorParsingType.IDENT_VALUE,
        parse: function parse(textAlign) {
          switch (textAlign) {
            case 'right':
              return TEXT_ALIGN.RIGHT;

            case 'center':
            case 'justify':
              return TEXT_ALIGN.CENTER;

            case 'left':
            default:
              return TEXT_ALIGN.LEFT;
          }
        }
      };
      var POSITION;

      (function (POSITION) {
        POSITION[POSITION["STATIC"] = 0] = "STATIC";
        POSITION[POSITION["RELATIVE"] = 1] = "RELATIVE";
        POSITION[POSITION["ABSOLUTE"] = 2] = "ABSOLUTE";
        POSITION[POSITION["FIXED"] = 3] = "FIXED";
        POSITION[POSITION["STICKY"] = 4] = "STICKY";
      })(POSITION || (POSITION = {}));

      var position = {
        name: 'position',
        initialValue: 'static',
        prefix: false,
        type: PropertyDescriptorParsingType.IDENT_VALUE,
        parse: function parse(position) {
          switch (position) {
            case 'relative':
              return POSITION.RELATIVE;

            case 'absolute':
              return POSITION.ABSOLUTE;

            case 'fixed':
              return POSITION.FIXED;

            case 'sticky':
              return POSITION.STICKY;
          }

          return POSITION.STATIC;
        }
      };
      var textShadow = {
        name: 'text-shadow',
        initialValue: 'none',
        type: PropertyDescriptorParsingType.LIST,
        prefix: false,
        parse: function parse(tokens) {
          if (tokens.length === 1 && isIdentWithValue(tokens[0], 'none')) {
            return [];
          }

          return parseFunctionArgs(tokens).map(function (values) {
            var shadow = {
              color: COLORS.TRANSPARENT,
              offsetX: ZERO_LENGTH,
              offsetY: ZERO_LENGTH,
              blur: ZERO_LENGTH
            };
            var c = 0;

            for (var i = 0; i < values.length; i++) {
              var token = values[i];

              if (isLength(token)) {
                if (c === 0) {
                  shadow.offsetX = token;
                } else if (c === 1) {
                  shadow.offsetY = token;
                } else {
                  shadow.blur = token;
                }

                c++;
              } else {
                shadow.color = color.parse(token);
              }
            }

            return shadow;
          });
        }
      };
      var TEXT_TRANSFORM;

      (function (TEXT_TRANSFORM) {
        TEXT_TRANSFORM[TEXT_TRANSFORM["NONE"] = 0] = "NONE";
        TEXT_TRANSFORM[TEXT_TRANSFORM["LOWERCASE"] = 1] = "LOWERCASE";
        TEXT_TRANSFORM[TEXT_TRANSFORM["UPPERCASE"] = 2] = "UPPERCASE";
        TEXT_TRANSFORM[TEXT_TRANSFORM["CAPITALIZE"] = 3] = "CAPITALIZE";
      })(TEXT_TRANSFORM || (TEXT_TRANSFORM = {}));

      var textTransform = {
        name: 'text-transform',
        initialValue: 'none',
        prefix: false,
        type: PropertyDescriptorParsingType.IDENT_VALUE,
        parse: function parse(textTransform) {
          switch (textTransform) {
            case 'uppercase':
              return TEXT_TRANSFORM.UPPERCASE;

            case 'lowercase':
              return TEXT_TRANSFORM.LOWERCASE;

            case 'capitalize':
              return TEXT_TRANSFORM.CAPITALIZE;
          }

          return TEXT_TRANSFORM.NONE;
        }
      };
      var transform = {
        name: 'transform',
        initialValue: 'none',
        prefix: true,
        type: PropertyDescriptorParsingType.VALUE,
        parse: function parse(token) {
          if (token.type === TokenType.IDENT_TOKEN && token.value === 'none') {
            return null;
          }

          if (token.type === TokenType.FUNCTION) {
            var transformFunction = SUPPORTED_TRANSFORM_FUNCTIONS[token.name];

            if (typeof transformFunction === 'undefined') {
              throw new Error("Attempting to parse an unsupported transform function \"" + token.name + "\"");
            }

            return transformFunction(token.values);
          }

          return null;
        }
      };

      var matrix = function matrix(args) {
        var values = args.filter(function (arg) {
          return arg.type === TokenType.NUMBER_TOKEN;
        }).map(function (arg) {
          return arg.number;
        });
        return values.length === 6 ? values : null;
      }; // doesn't support 3D transforms at the moment


      var matrix3d = function matrix3d(args) {
        var values = args.filter(function (arg) {
          return arg.type === TokenType.NUMBER_TOKEN;
        }).map(function (arg) {
          return arg.number;
        });
        var a1 = values[0],
            b1 = values[1],
            _a = values[2],
            _b = values[3],
            a2 = values[4],
            b2 = values[5],
            _c = values[6],
            _d = values[7],
            _e = values[8],
            _f = values[9],
            _g = values[10],
            _h = values[11],
            a4 = values[12],
            b4 = values[13],
            _j = values[14],
            _k = values[15];
        return values.length === 16 ? [a1, b1, a2, b2, a4, b4] : null;
      };

      var SUPPORTED_TRANSFORM_FUNCTIONS = {
        matrix: matrix,
        matrix3d: matrix3d
      };
      var DEFAULT_VALUE = {
        type: TokenType.PERCENTAGE_TOKEN,
        number: 50,
        flags: FLAG_INTEGER
      };
      var DEFAULT = [DEFAULT_VALUE, DEFAULT_VALUE];
      var transformOrigin = {
        name: 'transform-origin',
        initialValue: '50% 50%',
        prefix: true,
        type: PropertyDescriptorParsingType.LIST,
        parse: function parse(tokens) {
          var origins = tokens.filter(isLengthPercentage);

          if (origins.length !== 2) {
            return DEFAULT;
          }

          return [origins[0], origins[1]];
        }
      };
      var VISIBILITY;

      (function (VISIBILITY) {
        VISIBILITY[VISIBILITY["VISIBLE"] = 0] = "VISIBLE";
        VISIBILITY[VISIBILITY["HIDDEN"] = 1] = "HIDDEN";
        VISIBILITY[VISIBILITY["COLLAPSE"] = 2] = "COLLAPSE";
      })(VISIBILITY || (VISIBILITY = {}));

      var visibility = {
        name: 'visible',
        initialValue: 'none',
        prefix: false,
        type: PropertyDescriptorParsingType.IDENT_VALUE,
        parse: function parse(visibility) {
          switch (visibility) {
            case 'hidden':
              return VISIBILITY.HIDDEN;

            case 'collapse':
              return VISIBILITY.COLLAPSE;

            case 'visible':
            default:
              return VISIBILITY.VISIBLE;
          }
        }
      };
      var WORD_BREAK;

      (function (WORD_BREAK) {
        WORD_BREAK["NORMAL"] = "normal";
        WORD_BREAK["BREAK_ALL"] = "break-all";
        WORD_BREAK["KEEP_ALL"] = "keep-all";
      })(WORD_BREAK || (WORD_BREAK = {}));

      var wordBreak = {
        name: 'word-break',
        initialValue: 'normal',
        prefix: false,
        type: PropertyDescriptorParsingType.IDENT_VALUE,
        parse: function parse(wordBreak) {
          switch (wordBreak) {
            case 'break-all':
              return WORD_BREAK.BREAK_ALL;

            case 'keep-all':
              return WORD_BREAK.KEEP_ALL;

            case 'normal':
            default:
              return WORD_BREAK.NORMAL;
          }
        }
      };
      var zIndex = {
        name: 'z-index',
        initialValue: 'auto',
        prefix: false,
        type: PropertyDescriptorParsingType.VALUE,
        parse: function parse(token) {
          if (token.type === TokenType.IDENT_TOKEN) {
            return {
              auto: true,
              order: 0
            };
          }

          if (isNumberToken(token)) {
            return {
              auto: false,
              order: token.number
            };
          }

          throw new Error("Invalid z-index number parsed");
        }
      };
      var opacity = {
        name: 'opacity',
        initialValue: '1',
        type: PropertyDescriptorParsingType.VALUE,
        prefix: false,
        parse: function parse(token) {
          if (isNumberToken(token)) {
            return token.number;
          }

          return 1;
        }
      };
      var textDecorationColor = {
        name: "text-decoration-color",
        initialValue: 'transparent',
        prefix: false,
        type: PropertyDescriptorParsingType.TYPE_VALUE,
        format: 'color'
      };
      var textDecorationLine = {
        name: 'text-decoration-line',
        initialValue: 'none',
        prefix: false,
        type: PropertyDescriptorParsingType.LIST,
        parse: function parse(tokens) {
          return tokens.filter(isIdentToken).map(function (token) {
            switch (token.value) {
              case 'underline':
                return 1
                /* UNDERLINE */
                ;

              case 'overline':
                return 2
                /* OVERLINE */
                ;

              case 'line-through':
                return 3
                /* LINE_THROUGH */
                ;

              case 'none':
                return 4
                /* BLINK */
                ;
            }

            return 0
            /* NONE */
            ;
          }).filter(function (line) {
            return line !== 0
            /* NONE */
            ;
          });
        }
      };
      var fontFamily = {
        name: "font-family",
        initialValue: '',
        prefix: false,
        type: PropertyDescriptorParsingType.LIST,
        parse: function parse(tokens) {
          var accumulator = [];
          var results = [];
          tokens.forEach(function (token) {
            switch (token.type) {
              case TokenType.IDENT_TOKEN:
              case TokenType.STRING_TOKEN:
                accumulator.push(token.value);
                break;

              case TokenType.NUMBER_TOKEN:
                accumulator.push(token.number.toString());
                break;

              case TokenType.COMMA_TOKEN:
                results.push(accumulator.join(' '));
                accumulator.length = 0;
                break;
            }
          });

          if (accumulator.length) {
            results.push(accumulator.join(' '));
          }

          return results.map(function (result) {
            return result.indexOf(' ') === -1 ? result : "'" + result + "'";
          });
        }
      };
      var fontSize = {
        name: "font-size",
        initialValue: '0',
        prefix: false,
        type: PropertyDescriptorParsingType.TYPE_VALUE,
        format: 'length'
      };
      var fontWeight = {
        name: 'font-weight',
        initialValue: 'normal',
        type: PropertyDescriptorParsingType.VALUE,
        prefix: false,
        parse: function parse(token) {
          if (isNumberToken(token)) {
            return token.number;
          }

          if (isIdentToken(token)) {
            switch (token.value) {
              case 'bold':
                return 700;

              case 'normal':
              default:
                return 400;
            }
          }

          return 400;
        }
      };
      var fontVariant = {
        name: 'font-variant',
        initialValue: 'none',
        type: PropertyDescriptorParsingType.LIST,
        prefix: false,
        parse: function parse(tokens) {
          return tokens.filter(isIdentToken).map(function (token) {
            return token.value;
          });
        }
      };
      var FONT_STYLE;

      (function (FONT_STYLE) {
        FONT_STYLE["NORMAL"] = "normal";
        FONT_STYLE["ITALIC"] = "italic";
        FONT_STYLE["OBLIQUE"] = "oblique";
      })(FONT_STYLE || (FONT_STYLE = {}));

      var fontStyle = {
        name: 'font-style',
        initialValue: 'normal',
        prefix: false,
        type: PropertyDescriptorParsingType.IDENT_VALUE,
        parse: function parse(overflow) {
          switch (overflow) {
            case 'oblique':
              return FONT_STYLE.OBLIQUE;

            case 'italic':
              return FONT_STYLE.ITALIC;

            case 'normal':
            default:
              return FONT_STYLE.NORMAL;
          }
        }
      };

      var contains = function contains(bit, value) {
        return (bit & value) !== 0;
      };

      var content = {
        name: 'content',
        initialValue: 'none',
        type: PropertyDescriptorParsingType.LIST,
        prefix: false,
        parse: function parse(tokens) {
          if (tokens.length === 0) {
            return [];
          }

          var first = tokens[0];

          if (first.type === TokenType.IDENT_TOKEN && first.value === 'none') {
            return [];
          }

          return tokens;
        }
      };
      var counterIncrement = {
        name: 'counter-increment',
        initialValue: 'none',
        prefix: true,
        type: PropertyDescriptorParsingType.LIST,
        parse: function parse(tokens) {
          if (tokens.length === 0) {
            return null;
          }

          var first = tokens[0];

          if (first.type === TokenType.IDENT_TOKEN && first.value === 'none') {
            return null;
          }

          var increments = [];
          var filtered = tokens.filter(nonWhiteSpace);

          for (var i = 0; i < filtered.length; i++) {
            var counter = filtered[i];
            var next = filtered[i + 1];

            if (counter.type === TokenType.IDENT_TOKEN) {
              var increment = next && isNumberToken(next) ? next.number : 1;
              increments.push({
                counter: counter.value,
                increment: increment
              });
            }
          }

          return increments;
        }
      };
      var counterReset = {
        name: 'counter-reset',
        initialValue: 'none',
        prefix: true,
        type: PropertyDescriptorParsingType.LIST,
        parse: function parse(tokens) {
          if (tokens.length === 0) {
            return [];
          }

          var resets = [];
          var filtered = tokens.filter(nonWhiteSpace);

          for (var i = 0; i < filtered.length; i++) {
            var counter = filtered[i];
            var next = filtered[i + 1];

            if (isIdentToken(counter) && counter.value !== 'none') {
              var reset = next && isNumberToken(next) ? next.number : 0;
              resets.push({
                counter: counter.value,
                reset: reset
              });
            }
          }

          return resets;
        }
      };
      var quotes = {
        name: 'quotes',
        initialValue: 'none',
        prefix: true,
        type: PropertyDescriptorParsingType.LIST,
        parse: function parse(tokens) {
          if (tokens.length === 0) {
            return null;
          }

          var first = tokens[0];

          if (first.type === TokenType.IDENT_TOKEN && first.value === 'none') {
            return null;
          }

          var quotes = [];
          var filtered = tokens.filter(isStringToken);

          if (filtered.length % 2 !== 0) {
            return null;
          }

          for (var i = 0; i < filtered.length; i += 2) {
            var open_1 = filtered[i].value;
            var close_1 = filtered[i + 1].value;
            quotes.push({
              open: open_1,
              close: close_1
            });
          }

          return quotes;
        }
      };

      var getQuote = function getQuote(quotes, depth, open) {
        if (!quotes) {
          return '';
        }

        var quote = quotes[Math.min(depth, quotes.length - 1)];

        if (!quote) {
          return '';
        }

        return open ? quote.open : quote.close;
      };

      var boxShadow = {
        name: 'box-shadow',
        initialValue: 'none',
        type: PropertyDescriptorParsingType.LIST,
        prefix: false,
        parse: function parse(tokens) {
          if (tokens.length === 1 && isIdentWithValue(tokens[0], 'none')) {
            return [];
          }

          return parseFunctionArgs(tokens).map(function (values) {
            var shadow = {
              color: 0x000000ff,
              offsetX: ZERO_LENGTH,
              offsetY: ZERO_LENGTH,
              blur: ZERO_LENGTH,
              spread: ZERO_LENGTH,
              inset: false
            };
            var c = 0;

            for (var i = 0; i < values.length; i++) {
              var token = values[i];

              if (isIdentWithValue(token, 'inset')) {
                shadow.inset = true;
              } else if (isLength(token)) {
                if (c === 0) {
                  shadow.offsetX = token;
                } else if (c === 1) {
                  shadow.offsetY = token;
                } else if (c === 2) {
                  shadow.blur = token;
                } else {
                  shadow.spread = token;
                }

                c++;
              } else {
                shadow.color = color.parse(token);
              }
            }

            return shadow;
          });
        }
      };

      var CSSParsedDeclaration =
      /** @class */
      function () {
        function CSSParsedDeclaration(declaration) {
          this.backgroundClip = parse(backgroundClip, declaration.backgroundClip);
          this.backgroundColor = parse(backgroundColor, declaration.backgroundColor);
          this.backgroundImage = parse(backgroundImage, declaration.backgroundImage);
          this.backgroundOrigin = parse(backgroundOrigin, declaration.backgroundOrigin);
          this.backgroundPosition = parse(backgroundPosition, declaration.backgroundPosition);
          this.backgroundRepeat = parse(backgroundRepeat, declaration.backgroundRepeat);
          this.backgroundSize = parse(backgroundSize, declaration.backgroundSize);
          this.borderTopColor = parse(borderTopColor, declaration.borderTopColor);
          this.borderRightColor = parse(borderRightColor, declaration.borderRightColor);
          this.borderBottomColor = parse(borderBottomColor, declaration.borderBottomColor);
          this.borderLeftColor = parse(borderLeftColor, declaration.borderLeftColor);
          this.borderTopLeftRadius = parse(borderTopLeftRadius, declaration.borderTopLeftRadius);
          this.borderTopRightRadius = parse(borderTopRightRadius, declaration.borderTopRightRadius);
          this.borderBottomRightRadius = parse(borderBottomRightRadius, declaration.borderBottomRightRadius);
          this.borderBottomLeftRadius = parse(borderBottomLeftRadius, declaration.borderBottomLeftRadius);
          this.borderTopStyle = parse(borderTopStyle, declaration.borderTopStyle);
          this.borderRightStyle = parse(borderRightStyle, declaration.borderRightStyle);
          this.borderBottomStyle = parse(borderBottomStyle, declaration.borderBottomStyle);
          this.borderLeftStyle = parse(borderLeftStyle, declaration.borderLeftStyle);
          this.borderTopWidth = parse(borderTopWidth, declaration.borderTopWidth);
          this.borderRightWidth = parse(borderRightWidth, declaration.borderRightWidth);
          this.borderBottomWidth = parse(borderBottomWidth, declaration.borderBottomWidth);
          this.borderLeftWidth = parse(borderLeftWidth, declaration.borderLeftWidth);
          this.boxShadow = parse(boxShadow, declaration.boxShadow);
          this.color = parse(color$1, declaration.color);
          this.display = parse(display, declaration.display);
          this["float"] = parse(_float, declaration.cssFloat);
          this.fontFamily = parse(fontFamily, declaration.fontFamily);
          this.fontSize = parse(fontSize, declaration.fontSize);
          this.fontStyle = parse(fontStyle, declaration.fontStyle);
          this.fontVariant = parse(fontVariant, declaration.fontVariant);
          this.fontWeight = parse(fontWeight, declaration.fontWeight);
          this.letterSpacing = parse(letterSpacing, declaration.letterSpacing);
          this.lineBreak = parse(lineBreak, declaration.lineBreak);
          this.lineHeight = parse(lineHeight, declaration.lineHeight);
          this.listStyleImage = parse(listStyleImage, declaration.listStyleImage);
          this.listStylePosition = parse(listStylePosition, declaration.listStylePosition);
          this.listStyleType = parse(listStyleType, declaration.listStyleType);
          this.marginTop = parse(marginTop, declaration.marginTop);
          this.marginRight = parse(marginRight, declaration.marginRight);
          this.marginBottom = parse(marginBottom, declaration.marginBottom);
          this.marginLeft = parse(marginLeft, declaration.marginLeft);
          this.opacity = parse(opacity, declaration.opacity);
          var overflowTuple = parse(overflow, declaration.overflow);
          this.overflowX = overflowTuple[0];
          this.overflowY = overflowTuple[overflowTuple.length > 1 ? 1 : 0];
          this.overflowWrap = parse(overflowWrap, declaration.overflowWrap);
          this.paddingTop = parse(paddingTop, declaration.paddingTop);
          this.paddingRight = parse(paddingRight, declaration.paddingRight);
          this.paddingBottom = parse(paddingBottom, declaration.paddingBottom);
          this.paddingLeft = parse(paddingLeft, declaration.paddingLeft);
          this.position = parse(position, declaration.position);
          this.textAlign = parse(textAlign, declaration.textAlign);
          this.textDecorationColor = parse(textDecorationColor, declaration.textDecorationColor || declaration.color);
          this.textDecorationLine = parse(textDecorationLine, declaration.textDecorationLine);
          this.textShadow = parse(textShadow, declaration.textShadow);
          this.textTransform = parse(textTransform, declaration.textTransform);
          this.transform = parse(transform, declaration.transform);
          this.transformOrigin = parse(transformOrigin, declaration.transformOrigin);
          this.visibility = parse(visibility, declaration.visibility);
          this.wordBreak = parse(wordBreak, declaration.wordBreak);
          this.zIndex = parse(zIndex, declaration.zIndex);
        }

        CSSParsedDeclaration.prototype.isVisible = function () {
          return this.display > 0 && this.opacity > 0 && this.visibility === VISIBILITY.VISIBLE;
        };

        CSSParsedDeclaration.prototype.isTransparent = function () {
          return isTransparent(this.backgroundColor);
        };

        CSSParsedDeclaration.prototype.isTransformed = function () {
          return this.transform !== null;
        };

        CSSParsedDeclaration.prototype.isPositioned = function () {
          return this.position !== POSITION.STATIC;
        };

        CSSParsedDeclaration.prototype.isPositionedWithZIndex = function () {
          return this.isPositioned() && !this.zIndex.auto;
        };

        CSSParsedDeclaration.prototype.isFloating = function () {
          return this["float"] !== FLOAT.NONE;
        };

        CSSParsedDeclaration.prototype.isInlineLevel = function () {
          return contains(this.display, 4
          /* INLINE */
          ) || contains(this.display, 33554432
          /* INLINE_BLOCK */
          ) || contains(this.display, 268435456
          /* INLINE_FLEX */
          ) || contains(this.display, 536870912
          /* INLINE_GRID */
          ) || contains(this.display, 67108864
          /* INLINE_LIST_ITEM */
          ) || contains(this.display, 134217728
          /* INLINE_TABLE */
          );
        };

        return CSSParsedDeclaration;
      }();

      var CSSParsedPseudoDeclaration =
      /** @class */
      function () {
        function CSSParsedPseudoDeclaration(declaration) {
          this.content = parse(content, declaration.content);
          this.quotes = parse(quotes, declaration.quotes);
        }

        return CSSParsedPseudoDeclaration;
      }();

      var CSSParsedCounterDeclaration =
      /** @class */
      function () {
        function CSSParsedCounterDeclaration(declaration) {
          this.counterIncrement = parse(counterIncrement, declaration.counterIncrement);
          this.counterReset = parse(counterReset, declaration.counterReset);
        }

        return CSSParsedCounterDeclaration;
      }(); // eslint-disable-next-line @typescript-eslint/no-explicit-any


      var parse = function parse(descriptor, style) {
        var tokenizer = new Tokenizer();
        var value = style !== null && typeof style !== 'undefined' ? style.toString() : descriptor.initialValue;
        tokenizer.write(value);
        var parser = new Parser(tokenizer.read());

        switch (descriptor.type) {
          case PropertyDescriptorParsingType.IDENT_VALUE:
            var token = parser.parseComponentValue();
            return descriptor.parse(isIdentToken(token) ? token.value : descriptor.initialValue);

          case PropertyDescriptorParsingType.VALUE:
            return descriptor.parse(parser.parseComponentValue());

          case PropertyDescriptorParsingType.LIST:
            return descriptor.parse(parser.parseComponentValues());

          case PropertyDescriptorParsingType.TOKEN_VALUE:
            return parser.parseComponentValue();

          case PropertyDescriptorParsingType.TYPE_VALUE:
            switch (descriptor.format) {
              case 'angle':
                return angle.parse(parser.parseComponentValue());

              case 'color':
                return color.parse(parser.parseComponentValue());

              case 'image':
                return image.parse(parser.parseComponentValue());

              case 'length':
                var length_1 = parser.parseComponentValue();
                return isLength(length_1) ? length_1 : ZERO_LENGTH;

              case 'length-percentage':
                var value_1 = parser.parseComponentValue();
                return isLengthPercentage(value_1) ? value_1 : ZERO_LENGTH;
            }

        }

        throw new Error("Attempting to parse unsupported css format type " + descriptor.format);
      };

      var ElementContainer =
      /** @class */
      function () {
        function ElementContainer(element) {
          this.styles = new CSSParsedDeclaration(window.getComputedStyle(element, null));
          this.textNodes = [];
          this.elements = [];

          if (this.styles.transform !== null && isHTMLElementNode(element)) {
            // getBoundingClientRect takes transforms into account
            element.style.transform = 'none';
          }

          this.bounds = parseBounds(element);
          this.flags = 0;
        }

        return ElementContainer;
      }();

      var TextBounds =
      /** @class */
      function () {
        function TextBounds(text, bounds) {
          this.text = text;
          this.bounds = bounds;
        }

        return TextBounds;
      }();

      var parseTextBounds = function parseTextBounds(value, styles, node) {
        var textList = breakText(value, styles);
        var textBounds = [];
        var offset = 0;
        textList.forEach(function (text) {
          if (styles.textDecorationLine.length || text.trim().length > 0) {
            if (FEATURES.SUPPORT_RANGE_BOUNDS) {
              textBounds.push(new TextBounds(text, getRangeBounds(node, offset, text.length)));
            } else {
              var replacementNode = node.splitText(text.length);
              textBounds.push(new TextBounds(text, getWrapperBounds(node)));
              node = replacementNode;
            }
          } else if (!FEATURES.SUPPORT_RANGE_BOUNDS) {
            node = node.splitText(text.length);
          }

          offset += text.length;
        });
        return textBounds;
      };

      var getWrapperBounds = function getWrapperBounds(node) {
        var ownerDocument = node.ownerDocument;

        if (ownerDocument) {
          var wrapper = ownerDocument.createElement('html2canvaswrapper');
          wrapper.appendChild(node.cloneNode(true));
          var parentNode = node.parentNode;

          if (parentNode) {
            parentNode.replaceChild(wrapper, node);
            var bounds = parseBounds(wrapper);

            if (wrapper.firstChild) {
              parentNode.replaceChild(wrapper.firstChild, wrapper);
            }

            return bounds;
          }
        }

        return new Bounds(0, 0, 0, 0);
      };

      var getRangeBounds = function getRangeBounds(node, offset, length) {
        var ownerDocument = node.ownerDocument;

        if (!ownerDocument) {
          throw new Error('Node has no owner document');
        }

        var range = ownerDocument.createRange();
        range.setStart(node, offset);
        range.setEnd(node, offset + length);
        return Bounds.fromClientRect(range.getBoundingClientRect());
      };

      var breakText = function breakText(value, styles) {
        return styles.letterSpacing !== 0 ? toCodePoints(value).map(function (i) {
          return fromCodePoint(i);
        }) : breakWords(value, styles);
      };

      var breakWords = function breakWords(str, styles) {
        var breaker = LineBreaker(str, {
          lineBreak: styles.lineBreak,
          wordBreak: styles.overflowWrap === OVERFLOW_WRAP.BREAK_WORD ? 'break-word' : styles.wordBreak
        });
        var words = [];
        var bk;

        while (!(bk = breaker.next()).done) {
          if (bk.value) {
            words.push(bk.value.slice());
          }
        }

        return words;
      };

      var TextContainer =
      /** @class */
      function () {
        function TextContainer(node, styles) {
          this.text = transform$1(node.data, styles.textTransform);
          this.textBounds = parseTextBounds(this.text, styles, node);
        }

        return TextContainer;
      }();

      var transform$1 = function transform$1(text, transform) {
        switch (transform) {
          case TEXT_TRANSFORM.LOWERCASE:
            return text.toLowerCase();

          case TEXT_TRANSFORM.CAPITALIZE:
            return text.replace(CAPITALIZE, capitalize);

          case TEXT_TRANSFORM.UPPERCASE:
            return text.toUpperCase();

          default:
            return text;
        }
      };

      var CAPITALIZE = /(^|\s|:|-|\(|\))([a-z])/g;

      var capitalize = function capitalize(m, p1, p2) {
        if (m.length > 0) {
          return p1 + p2.toUpperCase();
        }

        return m;
      };

      var ImageElementContainer =
      /** @class */
      function (_super) {
        __extends(ImageElementContainer, _super);

        function ImageElementContainer(img) {
          var _this = _super.call(this, img) || this;

          _this.src = img.currentSrc || img.src;
          _this.intrinsicWidth = img.naturalWidth;
          _this.intrinsicHeight = img.naturalHeight;
          CacheStorage.getInstance().addImage(_this.src);
          return _this;
        }

        return ImageElementContainer;
      }(ElementContainer);

      var CanvasElementContainer =
      /** @class */
      function (_super) {
        __extends(CanvasElementContainer, _super);

        function CanvasElementContainer(canvas) {
          var _this = _super.call(this, canvas) || this;

          _this.canvas = canvas;
          _this.intrinsicWidth = canvas.width;
          _this.intrinsicHeight = canvas.height;
          return _this;
        }

        return CanvasElementContainer;
      }(ElementContainer);

      var SVGElementContainer =
      /** @class */
      function (_super) {
        __extends(SVGElementContainer, _super);

        function SVGElementContainer(img) {
          var _this = _super.call(this, img) || this;

          var s = new XMLSerializer();
          _this.svg = "data:image/svg+xml," + encodeURIComponent(s.serializeToString(img));
          _this.intrinsicWidth = img.width.baseVal.value;
          _this.intrinsicHeight = img.height.baseVal.value;
          CacheStorage.getInstance().addImage(_this.svg);
          return _this;
        }

        return SVGElementContainer;
      }(ElementContainer);

      var LIElementContainer =
      /** @class */
      function (_super) {
        __extends(LIElementContainer, _super);

        function LIElementContainer(element) {
          var _this = _super.call(this, element) || this;

          _this.value = element.value;
          return _this;
        }

        return LIElementContainer;
      }(ElementContainer);

      var OLElementContainer =
      /** @class */
      function (_super) {
        __extends(OLElementContainer, _super);

        function OLElementContainer(element) {
          var _this = _super.call(this, element) || this;

          _this.start = element.start;
          _this.reversed = typeof element.reversed === 'boolean' && element.reversed === true;
          return _this;
        }

        return OLElementContainer;
      }(ElementContainer);

      var CHECKBOX_BORDER_RADIUS = [{
        type: TokenType.DIMENSION_TOKEN,
        flags: 0,
        unit: 'px',
        number: 3
      }];
      var RADIO_BORDER_RADIUS = [{
        type: TokenType.PERCENTAGE_TOKEN,
        flags: 0,
        number: 50
      }];

      var reformatInputBounds = function reformatInputBounds(bounds) {
        if (bounds.width > bounds.height) {
          return new Bounds(bounds.left + (bounds.width - bounds.height) / 2, bounds.top, bounds.height, bounds.height);
        } else if (bounds.width < bounds.height) {
          return new Bounds(bounds.left, bounds.top + (bounds.height - bounds.width) / 2, bounds.width, bounds.width);
        }

        return bounds;
      };

      var getInputValue = function getInputValue(node) {
        var value = node.type === PASSWORD ? new Array(node.value.length + 1).join("\u2022") : node.value;
        return value.length === 0 ? node.placeholder || '' : value;
      };

      var CHECKBOX = 'checkbox';
      var RADIO = 'radio';
      var PASSWORD = 'password';
      var INPUT_COLOR = 0x2a2a2aff;

      var InputElementContainer =
      /** @class */
      function (_super) {
        __extends(InputElementContainer, _super);

        function InputElementContainer(input) {
          var _this = _super.call(this, input) || this;

          _this.type = input.type.toLowerCase();
          _this.checked = input.checked;
          _this.value = getInputValue(input);

          if (_this.type === CHECKBOX || _this.type === RADIO) {
            _this.styles.backgroundColor = 0xdededeff;
            _this.styles.borderTopColor = _this.styles.borderRightColor = _this.styles.borderBottomColor = _this.styles.borderLeftColor = 0xa5a5a5ff;
            _this.styles.borderTopWidth = _this.styles.borderRightWidth = _this.styles.borderBottomWidth = _this.styles.borderLeftWidth = 1;
            _this.styles.borderTopStyle = _this.styles.borderRightStyle = _this.styles.borderBottomStyle = _this.styles.borderLeftStyle = BORDER_STYLE.SOLID;
            _this.styles.backgroundClip = [BACKGROUND_CLIP.BORDER_BOX];
            _this.styles.backgroundOrigin = [0
            /* BORDER_BOX */
            ];
            _this.bounds = reformatInputBounds(_this.bounds);
          }

          switch (_this.type) {
            case CHECKBOX:
              _this.styles.borderTopRightRadius = _this.styles.borderTopLeftRadius = _this.styles.borderBottomRightRadius = _this.styles.borderBottomLeftRadius = CHECKBOX_BORDER_RADIUS;
              break;

            case RADIO:
              _this.styles.borderTopRightRadius = _this.styles.borderTopLeftRadius = _this.styles.borderBottomRightRadius = _this.styles.borderBottomLeftRadius = RADIO_BORDER_RADIUS;
              break;
          }

          return _this;
        }

        return InputElementContainer;
      }(ElementContainer);

      var SelectElementContainer =
      /** @class */
      function (_super) {
        __extends(SelectElementContainer, _super);

        function SelectElementContainer(element) {
          var _this = _super.call(this, element) || this;

          var option = element.options[element.selectedIndex || 0];
          _this.value = option ? option.text || '' : '';
          return _this;
        }

        return SelectElementContainer;
      }(ElementContainer);

      var TextareaElementContainer =
      /** @class */
      function (_super) {
        __extends(TextareaElementContainer, _super);

        function TextareaElementContainer(element) {
          var _this = _super.call(this, element) || this;

          _this.value = element.value;
          return _this;
        }

        return TextareaElementContainer;
      }(ElementContainer);

      var parseColor = function parseColor(value) {
        return color.parse(Parser.create(value).parseComponentValue());
      };

      var IFrameElementContainer =
      /** @class */
      function (_super) {
        __extends(IFrameElementContainer, _super);

        function IFrameElementContainer(iframe) {
          var _this = _super.call(this, iframe) || this;

          _this.src = iframe.src;
          _this.width = parseInt(iframe.width, 10) || 0;
          _this.height = parseInt(iframe.height, 10) || 0;
          _this.backgroundColor = _this.styles.backgroundColor;

          try {
            if (iframe.contentWindow && iframe.contentWindow.document && iframe.contentWindow.document.documentElement) {
              _this.tree = parseTree(iframe.contentWindow.document.documentElement); // http://www.w3.org/TR/css3-background/#special-backgrounds

              var documentBackgroundColor = iframe.contentWindow.document.documentElement ? parseColor(getComputedStyle(iframe.contentWindow.document.documentElement).backgroundColor) : COLORS.TRANSPARENT;
              var bodyBackgroundColor = iframe.contentWindow.document.body ? parseColor(getComputedStyle(iframe.contentWindow.document.body).backgroundColor) : COLORS.TRANSPARENT;
              _this.backgroundColor = isTransparent(documentBackgroundColor) ? isTransparent(bodyBackgroundColor) ? _this.styles.backgroundColor : bodyBackgroundColor : documentBackgroundColor;
            }
          } catch (e) {}

          return _this;
        }

        return IFrameElementContainer;
      }(ElementContainer);

      var LIST_OWNERS = ['OL', 'UL', 'MENU'];

      var parseNodeTree = function parseNodeTree(node, parent, root) {
        for (var childNode = node.firstChild, nextNode = void 0; childNode; childNode = nextNode) {
          nextNode = childNode.nextSibling;

          if (isTextNode(childNode) && childNode.data.trim().length > 0) {
            parent.textNodes.push(new TextContainer(childNode, parent.styles));
          } else if (isElementNode(childNode)) {
            var container = createContainer(childNode);

            if (container.styles.isVisible()) {
              if (createsRealStackingContext(childNode, container, root)) {
                container.flags |= 4
                /* CREATES_REAL_STACKING_CONTEXT */
                ;
              } else if (createsStackingContext(container.styles)) {
                container.flags |= 2
                /* CREATES_STACKING_CONTEXT */
                ;
              }

              if (LIST_OWNERS.indexOf(childNode.tagName) !== -1) {
                container.flags |= 8
                /* IS_LIST_OWNER */
                ;
              }

              parent.elements.push(container);

              if (!isTextareaElement(childNode) && !isSVGElement(childNode) && !isSelectElement(childNode)) {
                parseNodeTree(childNode, container, root);
              }
            }
          }
        }
      };

      var createContainer = function createContainer(element) {
        if (isImageElement(element)) {
          return new ImageElementContainer(element);
        }

        if (isCanvasElement(element)) {
          return new CanvasElementContainer(element);
        }

        if (isSVGElement(element)) {
          return new SVGElementContainer(element);
        }

        if (isLIElement(element)) {
          return new LIElementContainer(element);
        }

        if (isOLElement(element)) {
          return new OLElementContainer(element);
        }

        if (isInputElement(element)) {
          return new InputElementContainer(element);
        }

        if (isSelectElement(element)) {
          return new SelectElementContainer(element);
        }

        if (isTextareaElement(element)) {
          return new TextareaElementContainer(element);
        }

        if (isIFrameElement(element)) {
          return new IFrameElementContainer(element);
        }

        return new ElementContainer(element);
      };

      var parseTree = function parseTree(element) {
        var container = createContainer(element);
        container.flags |= 4
        /* CREATES_REAL_STACKING_CONTEXT */
        ;
        parseNodeTree(element, container, container);
        return container;
      };

      var createsRealStackingContext = function createsRealStackingContext(node, container, root) {
        return container.styles.isPositionedWithZIndex() || container.styles.opacity < 1 || container.styles.isTransformed() || isBodyElement(node) && root.styles.isTransparent();
      };

      var createsStackingContext = function createsStackingContext(styles) {
        return styles.isPositioned() || styles.isFloating();
      };

      var isTextNode = function isTextNode(node) {
        return node.nodeType === Node.TEXT_NODE;
      };

      var isElementNode = function isElementNode(node) {
        return node.nodeType === Node.ELEMENT_NODE;
      };

      var isHTMLElementNode = function isHTMLElementNode(node) {
        return isElementNode(node) && typeof node.style !== 'undefined' && !isSVGElementNode(node);
      };

      var isSVGElementNode = function isSVGElementNode(element) {
        return typeof element.className === 'object';
      };

      var isLIElement = function isLIElement(node) {
        return node.tagName === 'LI';
      };

      var isOLElement = function isOLElement(node) {
        return node.tagName === 'OL';
      };

      var isInputElement = function isInputElement(node) {
        return node.tagName === 'INPUT';
      };

      var isHTMLElement = function isHTMLElement(node) {
        return node.tagName === 'HTML';
      };

      var isSVGElement = function isSVGElement(node) {
        return node.tagName === 'svg';
      };

      var isBodyElement = function isBodyElement(node) {
        return node.tagName === 'BODY';
      };

      var isCanvasElement = function isCanvasElement(node) {
        return node.tagName === 'CANVAS';
      };

      var isImageElement = function isImageElement(node) {
        return node.tagName === 'IMG';
      };

      var isIFrameElement = function isIFrameElement(node) {
        return node.tagName === 'IFRAME';
      };

      var isStyleElement = function isStyleElement(node) {
        return node.tagName === 'STYLE';
      };

      var isScriptElement = function isScriptElement(node) {
        return node.tagName === 'SCRIPT';
      };

      var isTextareaElement = function isTextareaElement(node) {
        return node.tagName === 'TEXTAREA';
      };

      var isSelectElement = function isSelectElement(node) {
        return node.tagName === 'SELECT';
      };

      var CounterState =
      /** @class */
      function () {
        function CounterState() {
          this.counters = {};
        }

        CounterState.prototype.getCounterValue = function (name) {
          var counter = this.counters[name];

          if (counter && counter.length) {
            return counter[counter.length - 1];
          }

          return 1;
        };

        CounterState.prototype.getCounterValues = function (name) {
          var counter = this.counters[name];
          return counter ? counter : [];
        };

        CounterState.prototype.pop = function (counters) {
          var _this = this;

          counters.forEach(function (counter) {
            return _this.counters[counter].pop();
          });
        };

        CounterState.prototype.parse = function (style) {
          var _this = this;

          var counterIncrement = style.counterIncrement;
          var counterReset = style.counterReset;
          var canReset = true;

          if (counterIncrement !== null) {
            counterIncrement.forEach(function (entry) {
              var counter = _this.counters[entry.counter];

              if (counter && entry.increment !== 0) {
                canReset = false;
                counter[Math.max(0, counter.length - 1)] += entry.increment;
              }
            });
          }

          var counterNames = [];

          if (canReset) {
            counterReset.forEach(function (entry) {
              var counter = _this.counters[entry.counter];
              counterNames.push(entry.counter);

              if (!counter) {
                counter = _this.counters[entry.counter] = [];
              }

              counter.push(entry.reset);
            });
          }

          return counterNames;
        };

        return CounterState;
      }();

      var ROMAN_UPPER = {
        integers: [1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1],
        values: ['M', 'CM', 'D', 'CD', 'C', 'XC', 'L', 'XL', 'X', 'IX', 'V', 'IV', 'I']
      };
      var ARMENIAN = {
        integers: [9000, 8000, 7000, 6000, 5000, 4000, 3000, 2000, 1000, 900, 800, 700, 600, 500, 400, 300, 200, 100, 90, 80, 70, 60, 50, 40, 30, 20, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1],
        values: ['Ք', 'Փ', 'Ւ', 'Ց', 'Ր', 'Տ', 'Վ', 'Ս', 'Ռ', 'Ջ', 'Պ', 'Չ', 'Ո', 'Շ', 'Ն', 'Յ', 'Մ', 'Ճ', 'Ղ', 'Ձ', 'Հ', 'Կ', 'Ծ', 'Խ', 'Լ', 'Ի', 'Ժ', 'Թ', 'Ը', 'Է', 'Զ', 'Ե', 'Դ', 'Գ', 'Բ', 'Ա']
      };
      var HEBREW = {
        integers: [10000, 9000, 8000, 7000, 6000, 5000, 4000, 3000, 2000, 1000, 400, 300, 200, 100, 90, 80, 70, 60, 50, 40, 30, 20, 19, 18, 17, 16, 15, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1],
        values: ['י׳', 'ט׳', 'ח׳', 'ז׳', 'ו׳', 'ה׳', 'ד׳', 'ג׳', 'ב׳', 'א׳', 'ת', 'ש', 'ר', 'ק', 'צ', 'פ', 'ע', 'ס', 'נ', 'מ', 'ל', 'כ', 'יט', 'יח', 'יז', 'טז', 'טו', 'י', 'ט', 'ח', 'ז', 'ו', 'ה', 'ד', 'ג', 'ב', 'א']
      };
      var GEORGIAN = {
        integers: [10000, 9000, 8000, 7000, 6000, 5000, 4000, 3000, 2000, 1000, 900, 800, 700, 600, 500, 400, 300, 200, 100, 90, 80, 70, 60, 50, 40, 30, 20, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1],
        values: ['ჵ', 'ჰ', 'ჯ', 'ჴ', 'ხ', 'ჭ', 'წ', 'ძ', 'ც', 'ჩ', 'შ', 'ყ', 'ღ', 'ქ', 'ფ', 'ჳ', 'ტ', 'ს', 'რ', 'ჟ', 'პ', 'ო', 'ჲ', 'ნ', 'მ', 'ლ', 'კ', 'ი', 'თ', 'ჱ', 'ზ', 'ვ', 'ე', 'დ', 'გ', 'ბ', 'ა']
      };

      var createAdditiveCounter = function createAdditiveCounter(value, min, max, symbols, fallback, suffix) {
        if (value < min || value > max) {
          return createCounterText(value, fallback, suffix.length > 0);
        }

        return symbols.integers.reduce(function (string, integer, index) {
          while (value >= integer) {
            value -= integer;
            string += symbols.values[index];
          }

          return string;
        }, '') + suffix;
      };

      var createCounterStyleWithSymbolResolver = function createCounterStyleWithSymbolResolver(value, codePointRangeLength, isNumeric, resolver) {
        var string = '';

        do {
          if (!isNumeric) {
            value--;
          }

          string = resolver(value) + string;
          value /= codePointRangeLength;
        } while (value * codePointRangeLength >= codePointRangeLength);

        return string;
      };

      var createCounterStyleFromRange = function createCounterStyleFromRange(value, codePointRangeStart, codePointRangeEnd, isNumeric, suffix) {
        var codePointRangeLength = codePointRangeEnd - codePointRangeStart + 1;
        return (value < 0 ? '-' : '') + (createCounterStyleWithSymbolResolver(Math.abs(value), codePointRangeLength, isNumeric, function (codePoint) {
          return fromCodePoint(Math.floor(codePoint % codePointRangeLength) + codePointRangeStart);
        }) + suffix);
      };

      var createCounterStyleFromSymbols = function createCounterStyleFromSymbols(value, symbols, suffix) {
        if (suffix === void 0) {
          suffix = '. ';
        }

        var codePointRangeLength = symbols.length;
        return createCounterStyleWithSymbolResolver(Math.abs(value), codePointRangeLength, false, function (codePoint) {
          return symbols[Math.floor(codePoint % codePointRangeLength)];
        }) + suffix;
      };

      var CJK_ZEROS = 1 << 0;
      var CJK_TEN_COEFFICIENTS = 1 << 1;
      var CJK_TEN_HIGH_COEFFICIENTS = 1 << 2;
      var CJK_HUNDRED_COEFFICIENTS = 1 << 3;

      var createCJKCounter = function createCJKCounter(value, numbers, multipliers, negativeSign, suffix, flags) {
        if (value < -9999 || value > 9999) {
          return createCounterText(value, LIST_STYLE_TYPE.CJK_DECIMAL, suffix.length > 0);
        }

        var tmp = Math.abs(value);
        var string = suffix;

        if (tmp === 0) {
          return numbers[0] + string;
        }

        for (var digit = 0; tmp > 0 && digit <= 4; digit++) {
          var coefficient = tmp % 10;

          if (coefficient === 0 && contains(flags, CJK_ZEROS) && string !== '') {
            string = numbers[coefficient] + string;
          } else if (coefficient > 1 || coefficient === 1 && digit === 0 || coefficient === 1 && digit === 1 && contains(flags, CJK_TEN_COEFFICIENTS) || coefficient === 1 && digit === 1 && contains(flags, CJK_TEN_HIGH_COEFFICIENTS) && value > 100 || coefficient === 1 && digit > 1 && contains(flags, CJK_HUNDRED_COEFFICIENTS)) {
            string = numbers[coefficient] + (digit > 0 ? multipliers[digit - 1] : '') + string;
          } else if (coefficient === 1 && digit > 0) {
            string = multipliers[digit - 1] + string;
          }

          tmp = Math.floor(tmp / 10);
        }

        return (value < 0 ? negativeSign : '') + string;
      };

      var CHINESE_INFORMAL_MULTIPLIERS = '十百千萬';
      var CHINESE_FORMAL_MULTIPLIERS = '拾佰仟萬';
      var JAPANESE_NEGATIVE = 'マイナス';
      var KOREAN_NEGATIVE = '마이너스';

      var createCounterText = function createCounterText(value, type, appendSuffix) {
        var defaultSuffix = appendSuffix ? '. ' : '';
        var cjkSuffix = appendSuffix ? '、' : '';
        var koreanSuffix = appendSuffix ? ', ' : '';
        var spaceSuffix = appendSuffix ? ' ' : '';

        switch (type) {
          case LIST_STYLE_TYPE.DISC:
            return '•' + spaceSuffix;

          case LIST_STYLE_TYPE.CIRCLE:
            return '◦' + spaceSuffix;

          case LIST_STYLE_TYPE.SQUARE:
            return '◾' + spaceSuffix;

          case LIST_STYLE_TYPE.DECIMAL_LEADING_ZERO:
            var string = createCounterStyleFromRange(value, 48, 57, true, defaultSuffix);
            return string.length < 4 ? "0" + string : string;

          case LIST_STYLE_TYPE.CJK_DECIMAL:
            return createCounterStyleFromSymbols(value, '〇一二三四五六七八九', cjkSuffix);

          case LIST_STYLE_TYPE.LOWER_ROMAN:
            return createAdditiveCounter(value, 1, 3999, ROMAN_UPPER, LIST_STYLE_TYPE.DECIMAL, defaultSuffix).toLowerCase();

          case LIST_STYLE_TYPE.UPPER_ROMAN:
            return createAdditiveCounter(value, 1, 3999, ROMAN_UPPER, LIST_STYLE_TYPE.DECIMAL, defaultSuffix);

          case LIST_STYLE_TYPE.LOWER_GREEK:
            return createCounterStyleFromRange(value, 945, 969, false, defaultSuffix);

          case LIST_STYLE_TYPE.LOWER_ALPHA:
            return createCounterStyleFromRange(value, 97, 122, false, defaultSuffix);

          case LIST_STYLE_TYPE.UPPER_ALPHA:
            return createCounterStyleFromRange(value, 65, 90, false, defaultSuffix);

          case LIST_STYLE_TYPE.ARABIC_INDIC:
            return createCounterStyleFromRange(value, 1632, 1641, true, defaultSuffix);

          case LIST_STYLE_TYPE.ARMENIAN:
          case LIST_STYLE_TYPE.UPPER_ARMENIAN:
            return createAdditiveCounter(value, 1, 9999, ARMENIAN, LIST_STYLE_TYPE.DECIMAL, defaultSuffix);

          case LIST_STYLE_TYPE.LOWER_ARMENIAN:
            return createAdditiveCounter(value, 1, 9999, ARMENIAN, LIST_STYLE_TYPE.DECIMAL, defaultSuffix).toLowerCase();

          case LIST_STYLE_TYPE.BENGALI:
            return createCounterStyleFromRange(value, 2534, 2543, true, defaultSuffix);

          case LIST_STYLE_TYPE.CAMBODIAN:
          case LIST_STYLE_TYPE.KHMER:
            return createCounterStyleFromRange(value, 6112, 6121, true, defaultSuffix);

          case LIST_STYLE_TYPE.CJK_EARTHLY_BRANCH:
            return createCounterStyleFromSymbols(value, '子丑寅卯辰巳午未申酉戌亥', cjkSuffix);

          case LIST_STYLE_TYPE.CJK_HEAVENLY_STEM:
            return createCounterStyleFromSymbols(value, '甲乙丙丁戊己庚辛壬癸', cjkSuffix);

          case LIST_STYLE_TYPE.CJK_IDEOGRAPHIC:
          case LIST_STYLE_TYPE.TRAD_CHINESE_INFORMAL:
            return createCJKCounter(value, '零一二三四五六七八九', CHINESE_INFORMAL_MULTIPLIERS, '負', cjkSuffix, CJK_TEN_COEFFICIENTS | CJK_TEN_HIGH_COEFFICIENTS | CJK_HUNDRED_COEFFICIENTS);

          case LIST_STYLE_TYPE.TRAD_CHINESE_FORMAL:
            return createCJKCounter(value, '零壹貳參肆伍陸柒捌玖', CHINESE_FORMAL_MULTIPLIERS, '負', cjkSuffix, CJK_ZEROS | CJK_TEN_COEFFICIENTS | CJK_TEN_HIGH_COEFFICIENTS | CJK_HUNDRED_COEFFICIENTS);

          case LIST_STYLE_TYPE.SIMP_CHINESE_INFORMAL:
            return createCJKCounter(value, '零一二三四五六七八九', CHINESE_INFORMAL_MULTIPLIERS, '负', cjkSuffix, CJK_TEN_COEFFICIENTS | CJK_TEN_HIGH_COEFFICIENTS | CJK_HUNDRED_COEFFICIENTS);

          case LIST_STYLE_TYPE.SIMP_CHINESE_FORMAL:
            return createCJKCounter(value, '零壹贰叁肆伍陆柒捌玖', CHINESE_FORMAL_MULTIPLIERS, '负', cjkSuffix, CJK_ZEROS | CJK_TEN_COEFFICIENTS | CJK_TEN_HIGH_COEFFICIENTS | CJK_HUNDRED_COEFFICIENTS);

          case LIST_STYLE_TYPE.JAPANESE_INFORMAL:
            return createCJKCounter(value, '〇一二三四五六七八九', '十百千万', JAPANESE_NEGATIVE, cjkSuffix, 0);

          case LIST_STYLE_TYPE.JAPANESE_FORMAL:
            return createCJKCounter(value, '零壱弐参四伍六七八九', '拾百千万', JAPANESE_NEGATIVE, cjkSuffix, CJK_ZEROS | CJK_TEN_COEFFICIENTS | CJK_TEN_HIGH_COEFFICIENTS);

          case LIST_STYLE_TYPE.KOREAN_HANGUL_FORMAL:
            return createCJKCounter(value, '영일이삼사오육칠팔구', '십백천만', KOREAN_NEGATIVE, koreanSuffix, CJK_ZEROS | CJK_TEN_COEFFICIENTS | CJK_TEN_HIGH_COEFFICIENTS);

          case LIST_STYLE_TYPE.KOREAN_HANJA_INFORMAL:
            return createCJKCounter(value, '零一二三四五六七八九', '十百千萬', KOREAN_NEGATIVE, koreanSuffix, 0);

          case LIST_STYLE_TYPE.KOREAN_HANJA_FORMAL:
            return createCJKCounter(value, '零壹貳參四五六七八九', '拾百千', KOREAN_NEGATIVE, koreanSuffix, CJK_ZEROS | CJK_TEN_COEFFICIENTS | CJK_TEN_HIGH_COEFFICIENTS);

          case LIST_STYLE_TYPE.DEVANAGARI:
            return createCounterStyleFromRange(value, 0x966, 0x96f, true, defaultSuffix);

          case LIST_STYLE_TYPE.GEORGIAN:
            return createAdditiveCounter(value, 1, 19999, GEORGIAN, LIST_STYLE_TYPE.DECIMAL, defaultSuffix);

          case LIST_STYLE_TYPE.GUJARATI:
            return createCounterStyleFromRange(value, 0xae6, 0xaef, true, defaultSuffix);

          case LIST_STYLE_TYPE.GURMUKHI:
            return createCounterStyleFromRange(value, 0xa66, 0xa6f, true, defaultSuffix);

          case LIST_STYLE_TYPE.HEBREW:
            return createAdditiveCounter(value, 1, 10999, HEBREW, LIST_STYLE_TYPE.DECIMAL, defaultSuffix);

          case LIST_STYLE_TYPE.HIRAGANA:
            return createCounterStyleFromSymbols(value, 'あいうえおかきくけこさしすせそたちつてとなにぬねのはひふへほまみむめもやゆよらりるれろわゐゑをん');

          case LIST_STYLE_TYPE.HIRAGANA_IROHA:
            return createCounterStyleFromSymbols(value, 'いろはにほへとちりぬるをわかよたれそつねならむうゐのおくやまけふこえてあさきゆめみしゑひもせす');

          case LIST_STYLE_TYPE.KANNADA:
            return createCounterStyleFromRange(value, 0xce6, 0xcef, true, defaultSuffix);

          case LIST_STYLE_TYPE.KATAKANA:
            return createCounterStyleFromSymbols(value, 'アイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロワヰヱヲン', cjkSuffix);

          case LIST_STYLE_TYPE.KATAKANA_IROHA:
            return createCounterStyleFromSymbols(value, 'イロハニホヘトチリヌルヲワカヨタレソツネナラムウヰノオクヤマケフコエテアサキユメミシヱヒモセス', cjkSuffix);

          case LIST_STYLE_TYPE.LAO:
            return createCounterStyleFromRange(value, 0xed0, 0xed9, true, defaultSuffix);

          case LIST_STYLE_TYPE.MONGOLIAN:
            return createCounterStyleFromRange(value, 0x1810, 0x1819, true, defaultSuffix);

          case LIST_STYLE_TYPE.MYANMAR:
            return createCounterStyleFromRange(value, 0x1040, 0x1049, true, defaultSuffix);

          case LIST_STYLE_TYPE.ORIYA:
            return createCounterStyleFromRange(value, 0xb66, 0xb6f, true, defaultSuffix);

          case LIST_STYLE_TYPE.PERSIAN:
            return createCounterStyleFromRange(value, 0x6f0, 0x6f9, true, defaultSuffix);

          case LIST_STYLE_TYPE.TAMIL:
            return createCounterStyleFromRange(value, 0xbe6, 0xbef, true, defaultSuffix);

          case LIST_STYLE_TYPE.TELUGU:
            return createCounterStyleFromRange(value, 0xc66, 0xc6f, true, defaultSuffix);

          case LIST_STYLE_TYPE.THAI:
            return createCounterStyleFromRange(value, 0xe50, 0xe59, true, defaultSuffix);

          case LIST_STYLE_TYPE.TIBETAN:
            return createCounterStyleFromRange(value, 0xf20, 0xf29, true, defaultSuffix);

          case LIST_STYLE_TYPE.DECIMAL:
          default:
            return createCounterStyleFromRange(value, 48, 57, true, defaultSuffix);
        }
      };

      var IGNORE_ATTRIBUTE = 'data-html2canvas-ignore';

      var DocumentCloner =
      /** @class */
      function () {
        function DocumentCloner(element, options) {
          this.options = options;
          this.scrolledElements = [];
          this.referenceElement = element;
          this.counters = new CounterState();
          this.quoteDepth = 0;

          if (!element.ownerDocument) {
            throw new Error('Cloned element does not have an owner document');
          }

          this.documentElement = this.cloneNode(element.ownerDocument.documentElement);
        }

        DocumentCloner.prototype.toIFrame = function (ownerDocument, windowSize) {
          var _this = this;

          var iframe = createIFrameContainer(ownerDocument, windowSize);

          if (!iframe.contentWindow) {
            return Promise.reject("Unable to find iframe window");
          }

          var scrollX = ownerDocument.defaultView.pageXOffset;
          var scrollY = ownerDocument.defaultView.pageYOffset;
          var cloneWindow = iframe.contentWindow;
          var documentClone = cloneWindow.document;
          /* Chrome doesn't detect relative background-images assigned in inline <style> sheets when fetched through getComputedStyle
           if window url is about:blank, we can assign the url to current by writing onto the document
           */

          var iframeLoad = iframeLoader(iframe).then(function () {
            return __awaiter(_this, void 0, void 0, function () {
              var onclone;
              return __generator(this, function (_a) {
                switch (_a.label) {
                  case 0:
                    this.scrolledElements.forEach(restoreNodeScroll);

                    if (cloneWindow) {
                      cloneWindow.scrollTo(windowSize.left, windowSize.top);

                      if (/(iPad|iPhone|iPod)/g.test(navigator.userAgent) && (cloneWindow.scrollY !== windowSize.top || cloneWindow.scrollX !== windowSize.left)) {
                        documentClone.documentElement.style.top = -windowSize.top + 'px';
                        documentClone.documentElement.style.left = -windowSize.left + 'px';
                        documentClone.documentElement.style.position = 'absolute';
                      }
                    }

                    onclone = this.options.onclone;

                    if (typeof this.clonedReferenceElement === 'undefined') {
                      return [2
                      /*return*/
                      , Promise.reject("Error finding the " + this.referenceElement.nodeName + " in the cloned document")];
                    }

                    if (!(documentClone.fonts && documentClone.fonts.ready)) return [3
                    /*break*/
                    , 2];
                    return [4
                    /*yield*/
                    , documentClone.fonts.ready];

                  case 1:
                    _a.sent();

                    _a.label = 2;

                  case 2:
                    if (typeof onclone === 'function') {
                      return [2
                      /*return*/
                      , Promise.resolve().then(function () {
                        return onclone(documentClone);
                      }).then(function () {
                        return iframe;
                      })];
                    }

                    return [2
                    /*return*/
                    , iframe];
                }
              });
            });
          });
          documentClone.open();
          documentClone.write(serializeDoctype(document.doctype) + "<html></html>"); // Chrome scrolls the parent document for some reason after the write to the cloned window???

          restoreOwnerScroll(this.referenceElement.ownerDocument, scrollX, scrollY);
          documentClone.replaceChild(documentClone.adoptNode(this.documentElement), documentClone.documentElement);
          documentClone.close();
          return iframeLoad;
        };

        DocumentCloner.prototype.createElementClone = function (node) {
          if (isCanvasElement(node)) {
            return this.createCanvasClone(node);
          }
          /*
          if (isIFrameElement(node)) {
              return this.createIFrameClone(node);
          }
          */


          if (isStyleElement(node)) {
            return this.createStyleClone(node);
          }

          var clone = node.cloneNode(false); // @ts-ignore

          if (isImageElement(clone) && clone.loading === 'lazy') {
            // @ts-ignore
            clone.loading = 'eager';
          }

          return clone;
        };

        DocumentCloner.prototype.createStyleClone = function (node) {
          try {
            var sheet = node.sheet;

            if (sheet && sheet.cssRules) {
              var css = [].slice.call(sheet.cssRules, 0).reduce(function (css, rule) {
                if (rule && typeof rule.cssText === 'string') {
                  return css + rule.cssText;
                }

                return css;
              }, '');
              var style = node.cloneNode(false);
              style.textContent = css;
              return style;
            }
          } catch (e) {
            // accessing node.sheet.cssRules throws a DOMException
            Logger.getInstance(this.options.id).error('Unable to access cssRules property', e);

            if (e.name !== 'SecurityError') {
              throw e;
            }
          }

          return node.cloneNode(false);
        };

        DocumentCloner.prototype.createCanvasClone = function (canvas) {
          if (this.options.inlineImages && canvas.ownerDocument) {
            var img = canvas.ownerDocument.createElement('img');

            try {
              img.src = canvas.toDataURL();
              return img;
            } catch (e) {
              Logger.getInstance(this.options.id).info("Unable to clone canvas contents, canvas is tainted");
            }
          }

          var clonedCanvas = canvas.cloneNode(false);

          try {
            clonedCanvas.width = canvas.width;
            clonedCanvas.height = canvas.height;
            var ctx = canvas.getContext('2d');
            var clonedCtx = clonedCanvas.getContext('2d');

            if (clonedCtx) {
              if (ctx) {
                clonedCtx.putImageData(ctx.getImageData(0, 0, canvas.width, canvas.height), 0, 0);
              } else {
                clonedCtx.drawImage(canvas, 0, 0);
              }
            }

            return clonedCanvas;
          } catch (e) {}

          return clonedCanvas;
        };
        /*
        createIFrameClone(iframe: HTMLIFrameElement) {
            const tempIframe = <HTMLIFrameElement>iframe.cloneNode(false);
            const iframeKey = generateIframeKey();
            tempIframe.setAttribute('data-html2canvas-internal-iframe-key', iframeKey);
             const {width, height} = parseBounds(iframe);
             this.resourceLoader.cache[iframeKey] = getIframeDocumentElement(iframe, this.options)
                .then(documentElement => {
                    return this.renderer(
                        documentElement,
                        {
                            allowTaint: this.options.allowTaint,
                            backgroundColor: '#ffffff',
                            canvas: null,
                            imageTimeout: this.options.imageTimeout,
                            logging: this.options.logging,
                            proxy: this.options.proxy,
                            removeContainer: this.options.removeContainer,
                            scale: this.options.scale,
                            foreignObjectRendering: this.options.foreignObjectRendering,
                            useCORS: this.options.useCORS,
                            target: new CanvasRenderer(),
                            width,
                            height,
                            x: 0,
                            y: 0,
                            windowWidth: documentElement.ownerDocument.defaultView.innerWidth,
                            windowHeight: documentElement.ownerDocument.defaultView.innerHeight,
                            scrollX: documentElement.ownerDocument.defaultView.pageXOffset,
                            scrollY: documentElement.ownerDocument.defaultView.pageYOffset
                        },
                    );
                })
                .then(
                    (canvas: HTMLCanvasElement) =>
                        new Promise((resolve, reject) => {
                            const iframeCanvas = document.createElement('img');
                            iframeCanvas.onload = () => resolve(canvas);
                            iframeCanvas.onerror = (event) => {
                                // Empty iframes may result in empty "data:," URLs, which are invalid from the <img>'s point of view
                                // and instead of `onload` cause `onerror` and unhandled rejection warnings
                                // https://github.com/niklasvh/html2canvas/issues/1502
                                iframeCanvas.src == 'data:,' ? resolve(canvas) : reject(event);
                            };
                            iframeCanvas.src = canvas.toDataURL();
                            if (tempIframe.parentNode && iframe.ownerDocument && iframe.ownerDocument.defaultView) {
                                tempIframe.parentNode.replaceChild(
                                    copyCSSStyles(
                                        iframe.ownerDocument.defaultView.getComputedStyle(iframe),
                                        iframeCanvas
                                    ),
                                    tempIframe
                                );
                            }
                        })
                );
            return tempIframe;
        }
        */


        DocumentCloner.prototype.cloneNode = function (node) {
          if (isTextNode(node)) {
            return document.createTextNode(node.data);
          }

          if (!node.ownerDocument) {
            return node.cloneNode(false);
          }

          var window = node.ownerDocument.defaultView;

          if (window && isElementNode(node) && (isHTMLElementNode(node) || isSVGElementNode(node))) {
            var clone = this.createElementClone(node);
            var style = window.getComputedStyle(node);
            var styleBefore = window.getComputedStyle(node, ':before');
            var styleAfter = window.getComputedStyle(node, ':after');

            if (this.referenceElement === node && isHTMLElementNode(clone)) {
              this.clonedReferenceElement = clone;
            }

            if (isBodyElement(clone)) {
              createPseudoHideStyles(clone);
            }

            var counters = this.counters.parse(new CSSParsedCounterDeclaration(style));
            var before = this.resolvePseudoContent(node, clone, styleBefore, PseudoElementType.BEFORE);

            for (var child = node.firstChild; child; child = child.nextSibling) {
              if (!isElementNode(child) || !isScriptElement(child) && !child.hasAttribute(IGNORE_ATTRIBUTE) && (typeof this.options.ignoreElements !== 'function' || !this.options.ignoreElements(child))) {
                if (!this.options.copyStyles || !isElementNode(child) || !isStyleElement(child)) {
                  clone.appendChild(this.cloneNode(child));
                }
              }
            }

            if (before) {
              clone.insertBefore(before, clone.firstChild);
            }

            var after = this.resolvePseudoContent(node, clone, styleAfter, PseudoElementType.AFTER);

            if (after) {
              clone.appendChild(after);
            }

            this.counters.pop(counters);

            if (style && (this.options.copyStyles || isSVGElementNode(node)) && !isIFrameElement(node)) {
              copyCSSStyles(style, clone);
            } //this.inlineAllImages(clone);


            if (node.scrollTop !== 0 || node.scrollLeft !== 0) {
              this.scrolledElements.push([clone, node.scrollLeft, node.scrollTop]);
            }

            if ((isTextareaElement(node) || isSelectElement(node)) && (isTextareaElement(clone) || isSelectElement(clone))) {
              clone.value = node.value;
            }

            return clone;
          }

          return node.cloneNode(false);
        };

        DocumentCloner.prototype.resolvePseudoContent = function (node, clone, style, pseudoElt) {
          var _this = this;

          if (!style) {
            return;
          }

          var value = style.content;
          var document = clone.ownerDocument;

          if (!document || !value || value === 'none' || value === '-moz-alt-content' || style.display === 'none') {
            return;
          }

          this.counters.parse(new CSSParsedCounterDeclaration(style));
          var declaration = new CSSParsedPseudoDeclaration(style);
          var anonymousReplacedElement = document.createElement('html2canvaspseudoelement');
          copyCSSStyles(style, anonymousReplacedElement);
          declaration.content.forEach(function (token) {
            if (token.type === TokenType.STRING_TOKEN) {
              anonymousReplacedElement.appendChild(document.createTextNode(token.value));
            } else if (token.type === TokenType.URL_TOKEN) {
              var img = document.createElement('img');
              img.src = token.value;
              img.style.opacity = '1';
              anonymousReplacedElement.appendChild(img);
            } else if (token.type === TokenType.FUNCTION) {
              if (token.name === 'attr') {
                var attr = token.values.filter(isIdentToken);

                if (attr.length) {
                  anonymousReplacedElement.appendChild(document.createTextNode(node.getAttribute(attr[0].value) || ''));
                }
              } else if (token.name === 'counter') {
                var _a = token.values.filter(nonFunctionArgSeparator),
                    counter = _a[0],
                    counterStyle = _a[1];

                if (counter && isIdentToken(counter)) {
                  var counterState = _this.counters.getCounterValue(counter.value);

                  var counterType = counterStyle && isIdentToken(counterStyle) ? listStyleType.parse(counterStyle.value) : LIST_STYLE_TYPE.DECIMAL;
                  anonymousReplacedElement.appendChild(document.createTextNode(createCounterText(counterState, counterType, false)));
                }
              } else if (token.name === 'counters') {
                var _b = token.values.filter(nonFunctionArgSeparator),
                    counter = _b[0],
                    delim = _b[1],
                    counterStyle = _b[2];

                if (counter && isIdentToken(counter)) {
                  var counterStates = _this.counters.getCounterValues(counter.value);

                  var counterType_1 = counterStyle && isIdentToken(counterStyle) ? listStyleType.parse(counterStyle.value) : LIST_STYLE_TYPE.DECIMAL;
                  var separator = delim && delim.type === TokenType.STRING_TOKEN ? delim.value : '';
                  var text = counterStates.map(function (value) {
                    return createCounterText(value, counterType_1, false);
                  }).join(separator);
                  anonymousReplacedElement.appendChild(document.createTextNode(text));
                }
              }
            } else if (token.type === TokenType.IDENT_TOKEN) {
              switch (token.value) {
                case 'open-quote':
                  anonymousReplacedElement.appendChild(document.createTextNode(getQuote(declaration.quotes, _this.quoteDepth++, true)));
                  break;

                case 'close-quote':
                  anonymousReplacedElement.appendChild(document.createTextNode(getQuote(declaration.quotes, --_this.quoteDepth, false)));
                  break;

                default:
                  // safari doesn't parse string tokens correctly because of lack of quotes
                  anonymousReplacedElement.appendChild(document.createTextNode(token.value));
              }
            }
          });
          anonymousReplacedElement.className = PSEUDO_HIDE_ELEMENT_CLASS_BEFORE + " " + PSEUDO_HIDE_ELEMENT_CLASS_AFTER;
          var newClassName = pseudoElt === PseudoElementType.BEFORE ? " " + PSEUDO_HIDE_ELEMENT_CLASS_BEFORE : " " + PSEUDO_HIDE_ELEMENT_CLASS_AFTER;

          if (isSVGElementNode(clone)) {
            clone.className.baseValue += newClassName;
          } else {
            clone.className += newClassName;
          }

          return anonymousReplacedElement;
        };

        DocumentCloner.destroy = function (container) {
          if (container.parentNode) {
            container.parentNode.removeChild(container);
            return true;
          }

          return false;
        };

        return DocumentCloner;
      }();

      var PseudoElementType;

      (function (PseudoElementType) {
        PseudoElementType[PseudoElementType["BEFORE"] = 0] = "BEFORE";
        PseudoElementType[PseudoElementType["AFTER"] = 1] = "AFTER";
      })(PseudoElementType || (PseudoElementType = {}));

      var createIFrameContainer = function createIFrameContainer(ownerDocument, bounds) {
        var cloneIframeContainer = ownerDocument.createElement('iframe');
        cloneIframeContainer.className = 'html2canvas-container';
        cloneIframeContainer.style.visibility = 'hidden';
        cloneIframeContainer.style.position = 'fixed';
        cloneIframeContainer.style.left = '-10000px';
        cloneIframeContainer.style.top = '0px';
        cloneIframeContainer.style.border = '0';
        cloneIframeContainer.width = bounds.width.toString();
        cloneIframeContainer.height = bounds.height.toString();
        cloneIframeContainer.scrolling = 'no'; // ios won't scroll without it

        cloneIframeContainer.setAttribute(IGNORE_ATTRIBUTE, 'true');
        ownerDocument.body.appendChild(cloneIframeContainer);
        return cloneIframeContainer;
      };

      var iframeLoader = function iframeLoader(iframe) {
        return new Promise(function (resolve, reject) {
          var cloneWindow = iframe.contentWindow;

          if (!cloneWindow) {
            return reject("No window assigned for iframe");
          }

          var documentClone = cloneWindow.document;

          cloneWindow.onload = iframe.onload = documentClone.onreadystatechange = function () {
            cloneWindow.onload = iframe.onload = documentClone.onreadystatechange = null;
            var interval = setInterval(function () {
              if (documentClone.body.childNodes.length > 0 && documentClone.readyState === 'complete') {
                clearInterval(interval);
                resolve(iframe);
              }
            }, 50);
          };
        });
      };

      var copyCSSStyles = function copyCSSStyles(style, target) {
        // Edge does not provide value for cssText
        for (var i = style.length - 1; i >= 0; i--) {
          var property = style.item(i); // Safari shows pseudoelements if content is set

          if (property !== 'content') {
            target.style.setProperty(property, style.getPropertyValue(property));
          }
        }

        return target;
      };

      var serializeDoctype = function serializeDoctype(doctype) {
        var str = '';

        if (doctype) {
          str += '<!DOCTYPE ';

          if (doctype.name) {
            str += doctype.name;
          }

          if (doctype.internalSubset) {
            str += doctype.internalSubset;
          }

          if (doctype.publicId) {
            str += "\"" + doctype.publicId + "\"";
          }

          if (doctype.systemId) {
            str += "\"" + doctype.systemId + "\"";
          }

          str += '>';
        }

        return str;
      };

      var restoreOwnerScroll = function restoreOwnerScroll(ownerDocument, x, y) {
        if (ownerDocument && ownerDocument.defaultView && (x !== ownerDocument.defaultView.pageXOffset || y !== ownerDocument.defaultView.pageYOffset)) {
          ownerDocument.defaultView.scrollTo(x, y);
        }
      };

      var restoreNodeScroll = function restoreNodeScroll(_a) {
        var element = _a[0],
            x = _a[1],
            y = _a[2];
        element.scrollLeft = x;
        element.scrollTop = y;
      };

      var PSEUDO_BEFORE = ':before';
      var PSEUDO_AFTER = ':after';
      var PSEUDO_HIDE_ELEMENT_CLASS_BEFORE = '___html2canvas___pseudoelement_before';
      var PSEUDO_HIDE_ELEMENT_CLASS_AFTER = '___html2canvas___pseudoelement_after';
      var PSEUDO_HIDE_ELEMENT_STYLE = "{\n    content: \"\" !important;\n    display: none !important;\n}";

      var createPseudoHideStyles = function createPseudoHideStyles(body) {
        createStyles(body, "." + PSEUDO_HIDE_ELEMENT_CLASS_BEFORE + PSEUDO_BEFORE + PSEUDO_HIDE_ELEMENT_STYLE + "\n         ." + PSEUDO_HIDE_ELEMENT_CLASS_AFTER + PSEUDO_AFTER + PSEUDO_HIDE_ELEMENT_STYLE);
      };

      var createStyles = function createStyles(body, styles) {
        var document = body.ownerDocument;

        if (document) {
          var style = document.createElement('style');
          style.textContent = styles;
          body.appendChild(style);
        }
      };

      var PathType;

      (function (PathType) {
        PathType[PathType["VECTOR"] = 0] = "VECTOR";
        PathType[PathType["BEZIER_CURVE"] = 1] = "BEZIER_CURVE";
      })(PathType || (PathType = {}));

      var equalPath = function equalPath(a, b) {
        if (a.length === b.length) {
          return a.some(function (v, i) {
            return v === b[i];
          });
        }

        return false;
      };

      var transformPath = function transformPath(path, deltaX, deltaY, deltaW, deltaH) {
        return path.map(function (point, index) {
          switch (index) {
            case 0:
              return point.add(deltaX, deltaY);

            case 1:
              return point.add(deltaX + deltaW, deltaY);

            case 2:
              return point.add(deltaX + deltaW, deltaY + deltaH);

            case 3:
              return point.add(deltaX, deltaY + deltaH);
          }

          return point;
        });
      };

      var Vector =
      /** @class */
      function () {
        function Vector(x, y) {
          this.type = PathType.VECTOR;
          this.x = x;
          this.y = y;
        }

        Vector.prototype.add = function (deltaX, deltaY) {
          return new Vector(this.x + deltaX, this.y + deltaY);
        };

        return Vector;
      }();

      var lerp = function lerp(a, b, t) {
        return new Vector(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t);
      };

      var BezierCurve =
      /** @class */
      function () {
        function BezierCurve(start, startControl, endControl, end) {
          this.type = PathType.BEZIER_CURVE;
          this.start = start;
          this.startControl = startControl;
          this.endControl = endControl;
          this.end = end;
        }

        BezierCurve.prototype.subdivide = function (t, firstHalf) {
          var ab = lerp(this.start, this.startControl, t);
          var bc = lerp(this.startControl, this.endControl, t);
          var cd = lerp(this.endControl, this.end, t);
          var abbc = lerp(ab, bc, t);
          var bccd = lerp(bc, cd, t);
          var dest = lerp(abbc, bccd, t);
          return firstHalf ? new BezierCurve(this.start, ab, abbc, dest) : new BezierCurve(dest, bccd, cd, this.end);
        };

        BezierCurve.prototype.add = function (deltaX, deltaY) {
          return new BezierCurve(this.start.add(deltaX, deltaY), this.startControl.add(deltaX, deltaY), this.endControl.add(deltaX, deltaY), this.end.add(deltaX, deltaY));
        };

        BezierCurve.prototype.reverse = function () {
          return new BezierCurve(this.end, this.endControl, this.startControl, this.start);
        };

        return BezierCurve;
      }();

      var isBezierCurve = function isBezierCurve(path) {
        return path.type === PathType.BEZIER_CURVE;
      };

      var BoundCurves =
      /** @class */
      function () {
        function BoundCurves(element) {
          var styles = element.styles;
          var bounds = element.bounds;

          var _a = getAbsoluteValueForTuple(styles.borderTopLeftRadius, bounds.width, bounds.height),
              tlh = _a[0],
              tlv = _a[1];

          var _b = getAbsoluteValueForTuple(styles.borderTopRightRadius, bounds.width, bounds.height),
              trh = _b[0],
              trv = _b[1];

          var _c = getAbsoluteValueForTuple(styles.borderBottomRightRadius, bounds.width, bounds.height),
              brh = _c[0],
              brv = _c[1];

          var _d = getAbsoluteValueForTuple(styles.borderBottomLeftRadius, bounds.width, bounds.height),
              blh = _d[0],
              blv = _d[1];

          var factors = [];
          factors.push((tlh + trh) / bounds.width);
          factors.push((blh + brh) / bounds.width);
          factors.push((tlv + blv) / bounds.height);
          factors.push((trv + brv) / bounds.height);
          var maxFactor = Math.max.apply(Math, factors);

          if (maxFactor > 1) {
            tlh /= maxFactor;
            tlv /= maxFactor;
            trh /= maxFactor;
            trv /= maxFactor;
            brh /= maxFactor;
            brv /= maxFactor;
            blh /= maxFactor;
            blv /= maxFactor;
          }

          var topWidth = bounds.width - trh;
          var rightHeight = bounds.height - brv;
          var bottomWidth = bounds.width - brh;
          var leftHeight = bounds.height - blv;
          var borderTopWidth = styles.borderTopWidth;
          var borderRightWidth = styles.borderRightWidth;
          var borderBottomWidth = styles.borderBottomWidth;
          var borderLeftWidth = styles.borderLeftWidth;
          var paddingTop = getAbsoluteValue(styles.paddingTop, element.bounds.width);
          var paddingRight = getAbsoluteValue(styles.paddingRight, element.bounds.width);
          var paddingBottom = getAbsoluteValue(styles.paddingBottom, element.bounds.width);
          var paddingLeft = getAbsoluteValue(styles.paddingLeft, element.bounds.width);
          this.topLeftBorderBox = tlh > 0 || tlv > 0 ? getCurvePoints(bounds.left, bounds.top, tlh, tlv, CORNER.TOP_LEFT) : new Vector(bounds.left, bounds.top);
          this.topRightBorderBox = trh > 0 || trv > 0 ? getCurvePoints(bounds.left + topWidth, bounds.top, trh, trv, CORNER.TOP_RIGHT) : new Vector(bounds.left + bounds.width, bounds.top);
          this.bottomRightBorderBox = brh > 0 || brv > 0 ? getCurvePoints(bounds.left + bottomWidth, bounds.top + rightHeight, brh, brv, CORNER.BOTTOM_RIGHT) : new Vector(bounds.left + bounds.width, bounds.top + bounds.height);
          this.bottomLeftBorderBox = blh > 0 || blv > 0 ? getCurvePoints(bounds.left, bounds.top + leftHeight, blh, blv, CORNER.BOTTOM_LEFT) : new Vector(bounds.left, bounds.top + bounds.height);
          this.topLeftPaddingBox = tlh > 0 || tlv > 0 ? getCurvePoints(bounds.left + borderLeftWidth, bounds.top + borderTopWidth, Math.max(0, tlh - borderLeftWidth), Math.max(0, tlv - borderTopWidth), CORNER.TOP_LEFT) : new Vector(bounds.left + borderLeftWidth, bounds.top + borderTopWidth);
          this.topRightPaddingBox = trh > 0 || trv > 0 ? getCurvePoints(bounds.left + Math.min(topWidth, bounds.width + borderLeftWidth), bounds.top + borderTopWidth, topWidth > bounds.width + borderLeftWidth ? 0 : trh - borderLeftWidth, trv - borderTopWidth, CORNER.TOP_RIGHT) : new Vector(bounds.left + bounds.width - borderRightWidth, bounds.top + borderTopWidth);
          this.bottomRightPaddingBox = brh > 0 || brv > 0 ? getCurvePoints(bounds.left + Math.min(bottomWidth, bounds.width - borderLeftWidth), bounds.top + Math.min(rightHeight, bounds.height + borderTopWidth), Math.max(0, brh - borderRightWidth), brv - borderBottomWidth, CORNER.BOTTOM_RIGHT) : new Vector(bounds.left + bounds.width - borderRightWidth, bounds.top + bounds.height - borderBottomWidth);
          this.bottomLeftPaddingBox = blh > 0 || blv > 0 ? getCurvePoints(bounds.left + borderLeftWidth, bounds.top + leftHeight, Math.max(0, blh - borderLeftWidth), blv - borderBottomWidth, CORNER.BOTTOM_LEFT) : new Vector(bounds.left + borderLeftWidth, bounds.top + bounds.height - borderBottomWidth);
          this.topLeftContentBox = tlh > 0 || tlv > 0 ? getCurvePoints(bounds.left + borderLeftWidth + paddingLeft, bounds.top + borderTopWidth + paddingTop, Math.max(0, tlh - (borderLeftWidth + paddingLeft)), Math.max(0, tlv - (borderTopWidth + paddingTop)), CORNER.TOP_LEFT) : new Vector(bounds.left + borderLeftWidth + paddingLeft, bounds.top + borderTopWidth + paddingTop);
          this.topRightContentBox = trh > 0 || trv > 0 ? getCurvePoints(bounds.left + Math.min(topWidth, bounds.width + borderLeftWidth + paddingLeft), bounds.top + borderTopWidth + paddingTop, topWidth > bounds.width + borderLeftWidth + paddingLeft ? 0 : trh - borderLeftWidth + paddingLeft, trv - (borderTopWidth + paddingTop), CORNER.TOP_RIGHT) : new Vector(bounds.left + bounds.width - (borderRightWidth + paddingRight), bounds.top + borderTopWidth + paddingTop);
          this.bottomRightContentBox = brh > 0 || brv > 0 ? getCurvePoints(bounds.left + Math.min(bottomWidth, bounds.width - (borderLeftWidth + paddingLeft)), bounds.top + Math.min(rightHeight, bounds.height + borderTopWidth + paddingTop), Math.max(0, brh - (borderRightWidth + paddingRight)), brv - (borderBottomWidth + paddingBottom), CORNER.BOTTOM_RIGHT) : new Vector(bounds.left + bounds.width - (borderRightWidth + paddingRight), bounds.top + bounds.height - (borderBottomWidth + paddingBottom));
          this.bottomLeftContentBox = blh > 0 || blv > 0 ? getCurvePoints(bounds.left + borderLeftWidth + paddingLeft, bounds.top + leftHeight, Math.max(0, blh - (borderLeftWidth + paddingLeft)), blv - (borderBottomWidth + paddingBottom), CORNER.BOTTOM_LEFT) : new Vector(bounds.left + borderLeftWidth + paddingLeft, bounds.top + bounds.height - (borderBottomWidth + paddingBottom));
        }

        return BoundCurves;
      }();

      var CORNER;

      (function (CORNER) {
        CORNER[CORNER["TOP_LEFT"] = 0] = "TOP_LEFT";
        CORNER[CORNER["TOP_RIGHT"] = 1] = "TOP_RIGHT";
        CORNER[CORNER["BOTTOM_RIGHT"] = 2] = "BOTTOM_RIGHT";
        CORNER[CORNER["BOTTOM_LEFT"] = 3] = "BOTTOM_LEFT";
      })(CORNER || (CORNER = {}));

      var getCurvePoints = function getCurvePoints(x, y, r1, r2, position) {
        var kappa = 4 * ((Math.sqrt(2) - 1) / 3);
        var ox = r1 * kappa; // control point offset horizontal

        var oy = r2 * kappa; // control point offset vertical

        var xm = x + r1; // x-middle

        var ym = y + r2; // y-middle

        switch (position) {
          case CORNER.TOP_LEFT:
            return new BezierCurve(new Vector(x, ym), new Vector(x, ym - oy), new Vector(xm - ox, y), new Vector(xm, y));

          case CORNER.TOP_RIGHT:
            return new BezierCurve(new Vector(x, y), new Vector(x + ox, y), new Vector(xm, ym - oy), new Vector(xm, ym));

          case CORNER.BOTTOM_RIGHT:
            return new BezierCurve(new Vector(xm, y), new Vector(xm, y + oy), new Vector(x + ox, ym), new Vector(x, ym));

          case CORNER.BOTTOM_LEFT:
          default:
            return new BezierCurve(new Vector(xm, ym), new Vector(xm - ox, ym), new Vector(x, y + oy), new Vector(x, y));
        }
      };

      var calculateBorderBoxPath = function calculateBorderBoxPath(curves) {
        return [curves.topLeftBorderBox, curves.topRightBorderBox, curves.bottomRightBorderBox, curves.bottomLeftBorderBox];
      };

      var calculateContentBoxPath = function calculateContentBoxPath(curves) {
        return [curves.topLeftContentBox, curves.topRightContentBox, curves.bottomRightContentBox, curves.bottomLeftContentBox];
      };

      var calculatePaddingBoxPath = function calculatePaddingBoxPath(curves) {
        return [curves.topLeftPaddingBox, curves.topRightPaddingBox, curves.bottomRightPaddingBox, curves.bottomLeftPaddingBox];
      };

      var TransformEffect =
      /** @class */
      function () {
        function TransformEffect(offsetX, offsetY, matrix) {
          this.type = 0
          /* TRANSFORM */
          ;
          this.offsetX = offsetX;
          this.offsetY = offsetY;
          this.matrix = matrix;
          this.target = 2
          /* BACKGROUND_BORDERS */
          | 4
          /* CONTENT */
          ;
        }

        return TransformEffect;
      }();

      var ClipEffect =
      /** @class */
      function () {
        function ClipEffect(path, target) {
          this.type = 1
          /* CLIP */
          ;
          this.target = target;
          this.path = path;
        }

        return ClipEffect;
      }();

      var isTransformEffect = function isTransformEffect(effect) {
        return effect.type === 0
        /* TRANSFORM */
        ;
      };

      var isClipEffect = function isClipEffect(effect) {
        return effect.type === 1
        /* CLIP */
        ;
      };

      var StackingContext =
      /** @class */
      function () {
        function StackingContext(container) {
          this.element = container;
          this.inlineLevel = [];
          this.nonInlineLevel = [];
          this.negativeZIndex = [];
          this.zeroOrAutoZIndexOrTransformedOrOpacity = [];
          this.positiveZIndex = [];
          this.nonPositionedFloats = [];
          this.nonPositionedInlineLevel = [];
        }

        return StackingContext;
      }();

      var ElementPaint =
      /** @class */
      function () {
        function ElementPaint(element, parentStack) {
          this.container = element;
          this.effects = parentStack.slice(0);
          this.curves = new BoundCurves(element);

          if (element.styles.transform !== null) {
            var offsetX = element.bounds.left + element.styles.transformOrigin[0].number;
            var offsetY = element.bounds.top + element.styles.transformOrigin[1].number;
            var matrix = element.styles.transform;
            this.effects.push(new TransformEffect(offsetX, offsetY, matrix));
          }

          if (element.styles.overflowX !== OVERFLOW.VISIBLE) {
            var borderBox = calculateBorderBoxPath(this.curves);
            var paddingBox = calculatePaddingBoxPath(this.curves);

            if (equalPath(borderBox, paddingBox)) {
              this.effects.push(new ClipEffect(borderBox, 2
              /* BACKGROUND_BORDERS */
              | 4
              /* CONTENT */
              ));
            } else {
              this.effects.push(new ClipEffect(borderBox, 2
              /* BACKGROUND_BORDERS */
              ));
              this.effects.push(new ClipEffect(paddingBox, 4
              /* CONTENT */
              ));
            }
          }
        }

        ElementPaint.prototype.getParentEffects = function () {
          var effects = this.effects.slice(0);

          if (this.container.styles.overflowX !== OVERFLOW.VISIBLE) {
            var borderBox = calculateBorderBoxPath(this.curves);
            var paddingBox = calculatePaddingBoxPath(this.curves);

            if (!equalPath(borderBox, paddingBox)) {
              effects.push(new ClipEffect(paddingBox, 2
              /* BACKGROUND_BORDERS */
              | 4
              /* CONTENT */
              ));
            }
          }

          return effects;
        };

        return ElementPaint;
      }();

      var parseStackTree = function parseStackTree(parent, stackingContext, realStackingContext, listItems) {
        parent.container.elements.forEach(function (child) {
          var treatAsRealStackingContext = contains(child.flags, 4
          /* CREATES_REAL_STACKING_CONTEXT */
          );
          var createsStackingContext = contains(child.flags, 2
          /* CREATES_STACKING_CONTEXT */
          );
          var paintContainer = new ElementPaint(child, parent.getParentEffects());

          if (contains(child.styles.display, 2048
          /* LIST_ITEM */
          )) {
            listItems.push(paintContainer);
          }

          var listOwnerItems = contains(child.flags, 8
          /* IS_LIST_OWNER */
          ) ? [] : listItems;

          if (treatAsRealStackingContext || createsStackingContext) {
            var parentStack = treatAsRealStackingContext || child.styles.isPositioned() ? realStackingContext : stackingContext;
            var stack = new StackingContext(paintContainer);

            if (child.styles.isPositioned() || child.styles.opacity < 1 || child.styles.isTransformed()) {
              var order_1 = child.styles.zIndex.order;

              if (order_1 < 0) {
                var index_1 = 0;
                parentStack.negativeZIndex.some(function (current, i) {
                  if (order_1 > current.element.container.styles.zIndex.order) {
                    index_1 = i;
                    return false;
                  } else if (index_1 > 0) {
                    return true;
                  }

                  return false;
                });
                parentStack.negativeZIndex.splice(index_1, 0, stack);
              } else if (order_1 > 0) {
                var index_2 = 0;
                parentStack.positiveZIndex.some(function (current, i) {
                  if (order_1 >= current.element.container.styles.zIndex.order) {
                    index_2 = i + 1;
                    return false;
                  } else if (index_2 > 0) {
                    return true;
                  }

                  return false;
                });
                parentStack.positiveZIndex.splice(index_2, 0, stack);
              } else {
                parentStack.zeroOrAutoZIndexOrTransformedOrOpacity.push(stack);
              }
            } else {
              if (child.styles.isFloating()) {
                parentStack.nonPositionedFloats.push(stack);
              } else {
                parentStack.nonPositionedInlineLevel.push(stack);
              }
            }

            parseStackTree(paintContainer, stack, treatAsRealStackingContext ? stack : realStackingContext, listOwnerItems);
          } else {
            if (child.styles.isInlineLevel()) {
              stackingContext.inlineLevel.push(paintContainer);
            } else {
              stackingContext.nonInlineLevel.push(paintContainer);
            }

            parseStackTree(paintContainer, stackingContext, realStackingContext, listOwnerItems);
          }

          if (contains(child.flags, 8
          /* IS_LIST_OWNER */
          )) {
            processListItems(child, listOwnerItems);
          }
        });
      };

      var processListItems = function processListItems(owner, elements) {
        var numbering = owner instanceof OLElementContainer ? owner.start : 1;
        var reversed = owner instanceof OLElementContainer ? owner.reversed : false;

        for (var i = 0; i < elements.length; i++) {
          var item = elements[i];

          if (item.container instanceof LIElementContainer && typeof item.container.value === 'number' && item.container.value !== 0) {
            numbering = item.container.value;
          }

          item.listValue = createCounterText(numbering, item.container.styles.listStyleType, true);
          numbering += reversed ? -1 : 1;
        }
      };

      var parseStackingContexts = function parseStackingContexts(container) {
        var paintContainer = new ElementPaint(container, []);
        var root = new StackingContext(paintContainer);
        var listItems = [];
        parseStackTree(paintContainer, root, root, listItems);
        processListItems(paintContainer.container, listItems);
        return root;
      };

      var parsePathForBorder = function parsePathForBorder(curves, borderSide) {
        switch (borderSide) {
          case 0:
            return createPathFromCurves(curves.topLeftBorderBox, curves.topLeftPaddingBox, curves.topRightBorderBox, curves.topRightPaddingBox);

          case 1:
            return createPathFromCurves(curves.topRightBorderBox, curves.topRightPaddingBox, curves.bottomRightBorderBox, curves.bottomRightPaddingBox);

          case 2:
            return createPathFromCurves(curves.bottomRightBorderBox, curves.bottomRightPaddingBox, curves.bottomLeftBorderBox, curves.bottomLeftPaddingBox);

          case 3:
          default:
            return createPathFromCurves(curves.bottomLeftBorderBox, curves.bottomLeftPaddingBox, curves.topLeftBorderBox, curves.topLeftPaddingBox);
        }
      };

      var createPathFromCurves = function createPathFromCurves(outer1, inner1, outer2, inner2) {
        var path = [];

        if (isBezierCurve(outer1)) {
          path.push(outer1.subdivide(0.5, false));
        } else {
          path.push(outer1);
        }

        if (isBezierCurve(outer2)) {
          path.push(outer2.subdivide(0.5, true));
        } else {
          path.push(outer2);
        }

        if (isBezierCurve(inner2)) {
          path.push(inner2.subdivide(0.5, true).reverse());
        } else {
          path.push(inner2);
        }

        if (isBezierCurve(inner1)) {
          path.push(inner1.subdivide(0.5, false).reverse());
        } else {
          path.push(inner1);
        }

        return path;
      };

      var paddingBox = function paddingBox(element) {
        var bounds = element.bounds;
        var styles = element.styles;
        return bounds.add(styles.borderLeftWidth, styles.borderTopWidth, -(styles.borderRightWidth + styles.borderLeftWidth), -(styles.borderTopWidth + styles.borderBottomWidth));
      };

      var contentBox = function contentBox(element) {
        var styles = element.styles;
        var bounds = element.bounds;
        var paddingLeft = getAbsoluteValue(styles.paddingLeft, bounds.width);
        var paddingRight = getAbsoluteValue(styles.paddingRight, bounds.width);
        var paddingTop = getAbsoluteValue(styles.paddingTop, bounds.width);
        var paddingBottom = getAbsoluteValue(styles.paddingBottom, bounds.width);
        return bounds.add(paddingLeft + styles.borderLeftWidth, paddingTop + styles.borderTopWidth, -(styles.borderRightWidth + styles.borderLeftWidth + paddingLeft + paddingRight), -(styles.borderTopWidth + styles.borderBottomWidth + paddingTop + paddingBottom));
      };

      var calculateBackgroundPositioningArea = function calculateBackgroundPositioningArea(backgroundOrigin, element) {
        if (backgroundOrigin === 0
        /* BORDER_BOX */
        ) {
            return element.bounds;
          }

        if (backgroundOrigin === 2
        /* CONTENT_BOX */
        ) {
            return contentBox(element);
          }

        return paddingBox(element);
      };

      var calculateBackgroundPaintingArea = function calculateBackgroundPaintingArea(backgroundClip, element) {
        if (backgroundClip === BACKGROUND_CLIP.BORDER_BOX) {
          return element.bounds;
        }

        if (backgroundClip === BACKGROUND_CLIP.CONTENT_BOX) {
          return contentBox(element);
        }

        return paddingBox(element);
      };

      var calculateBackgroundRendering = function calculateBackgroundRendering(container, index, intrinsicSize) {
        var backgroundPositioningArea = calculateBackgroundPositioningArea(getBackgroundValueForIndex(container.styles.backgroundOrigin, index), container);
        var backgroundPaintingArea = calculateBackgroundPaintingArea(getBackgroundValueForIndex(container.styles.backgroundClip, index), container);
        var backgroundImageSize = calculateBackgroundSize(getBackgroundValueForIndex(container.styles.backgroundSize, index), intrinsicSize, backgroundPositioningArea);
        var sizeWidth = backgroundImageSize[0],
            sizeHeight = backgroundImageSize[1];
        var position = getAbsoluteValueForTuple(getBackgroundValueForIndex(container.styles.backgroundPosition, index), backgroundPositioningArea.width - sizeWidth, backgroundPositioningArea.height - sizeHeight);
        var path = calculateBackgroundRepeatPath(getBackgroundValueForIndex(container.styles.backgroundRepeat, index), position, backgroundImageSize, backgroundPositioningArea, backgroundPaintingArea);
        var offsetX = Math.round(backgroundPositioningArea.left + position[0]);
        var offsetY = Math.round(backgroundPositioningArea.top + position[1]);
        return [path, offsetX, offsetY, sizeWidth, sizeHeight];
      };

      var isAuto = function isAuto(token) {
        return isIdentToken(token) && token.value === BACKGROUND_SIZE.AUTO;
      };

      var hasIntrinsicValue = function hasIntrinsicValue(value) {
        return typeof value === 'number';
      };

      var calculateBackgroundSize = function calculateBackgroundSize(size, _a, bounds) {
        var intrinsicWidth = _a[0],
            intrinsicHeight = _a[1],
            intrinsicProportion = _a[2];
        var first = size[0],
            second = size[1];

        if (isLengthPercentage(first) && second && isLengthPercentage(second)) {
          return [getAbsoluteValue(first, bounds.width), getAbsoluteValue(second, bounds.height)];
        }

        var hasIntrinsicProportion = hasIntrinsicValue(intrinsicProportion);

        if (isIdentToken(first) && (first.value === BACKGROUND_SIZE.CONTAIN || first.value === BACKGROUND_SIZE.COVER)) {
          if (hasIntrinsicValue(intrinsicProportion)) {
            var targetRatio = bounds.width / bounds.height;
            return targetRatio < intrinsicProportion !== (first.value === BACKGROUND_SIZE.COVER) ? [bounds.width, bounds.width / intrinsicProportion] : [bounds.height * intrinsicProportion, bounds.height];
          }

          return [bounds.width, bounds.height];
        }

        var hasIntrinsicWidth = hasIntrinsicValue(intrinsicWidth);
        var hasIntrinsicHeight = hasIntrinsicValue(intrinsicHeight);
        var hasIntrinsicDimensions = hasIntrinsicWidth || hasIntrinsicHeight; // If the background-size is auto or auto auto:

        if (isAuto(first) && (!second || isAuto(second))) {
          // If the image has both horizontal and vertical intrinsic dimensions, it's rendered at that size.
          if (hasIntrinsicWidth && hasIntrinsicHeight) {
            return [intrinsicWidth, intrinsicHeight];
          } // If the image has no intrinsic dimensions and has no intrinsic proportions,
          // it's rendered at the size of the background positioning area.


          if (!hasIntrinsicProportion && !hasIntrinsicDimensions) {
            return [bounds.width, bounds.height];
          } // TODO If the image has no intrinsic dimensions but has intrinsic proportions, it's rendered as if contain had been specified instead.
          // If the image has only one intrinsic dimension and has intrinsic proportions, it's rendered at the size corresponding to that one dimension.
          // The other dimension is computed using the specified dimension and the intrinsic proportions.


          if (hasIntrinsicDimensions && hasIntrinsicProportion) {
            var width_1 = hasIntrinsicWidth ? intrinsicWidth : intrinsicHeight * intrinsicProportion;
            var height_1 = hasIntrinsicHeight ? intrinsicHeight : intrinsicWidth / intrinsicProportion;
            return [width_1, height_1];
          } // If the image has only one intrinsic dimension but has no intrinsic proportions,
          // it's rendered using the specified dimension and the other dimension of the background positioning area.


          var width_2 = hasIntrinsicWidth ? intrinsicWidth : bounds.width;
          var height_2 = hasIntrinsicHeight ? intrinsicHeight : bounds.height;
          return [width_2, height_2];
        } // If the image has intrinsic proportions, it's stretched to the specified dimension.
        // The unspecified dimension is computed using the specified dimension and the intrinsic proportions.


        if (hasIntrinsicProportion) {
          var width_3 = 0;
          var height_3 = 0;

          if (isLengthPercentage(first)) {
            width_3 = getAbsoluteValue(first, bounds.width);
          } else if (isLengthPercentage(second)) {
            height_3 = getAbsoluteValue(second, bounds.height);
          }

          if (isAuto(first)) {
            width_3 = height_3 * intrinsicProportion;
          } else if (!second || isAuto(second)) {
            height_3 = width_3 / intrinsicProportion;
          }

          return [width_3, height_3];
        } // If the image has no intrinsic proportions, it's stretched to the specified dimension.
        // The unspecified dimension is computed using the image's corresponding intrinsic dimension,
        // if there is one. If there is no such intrinsic dimension,
        // it becomes the corresponding dimension of the background positioning area.


        var width = null;
        var height = null;

        if (isLengthPercentage(first)) {
          width = getAbsoluteValue(first, bounds.width);
        } else if (second && isLengthPercentage(second)) {
          height = getAbsoluteValue(second, bounds.height);
        }

        if (width !== null && (!second || isAuto(second))) {
          height = hasIntrinsicWidth && hasIntrinsicHeight ? width / intrinsicWidth * intrinsicHeight : bounds.height;
        }

        if (height !== null && isAuto(first)) {
          width = hasIntrinsicWidth && hasIntrinsicHeight ? height / intrinsicHeight * intrinsicWidth : bounds.width;
        }

        if (width !== null && height !== null) {
          return [width, height];
        }

        throw new Error("Unable to calculate background-size for element");
      };

      var getBackgroundValueForIndex = function getBackgroundValueForIndex(values, index) {
        var value = values[index];

        if (typeof value === 'undefined') {
          return values[0];
        }

        return value;
      };

      var calculateBackgroundRepeatPath = function calculateBackgroundRepeatPath(repeat, _a, _b, backgroundPositioningArea, backgroundPaintingArea) {
        var x = _a[0],
            y = _a[1];
        var width = _b[0],
            height = _b[1];

        switch (repeat) {
          case BACKGROUND_REPEAT.REPEAT_X:
            return [new Vector(Math.round(backgroundPositioningArea.left), Math.round(backgroundPositioningArea.top + y)), new Vector(Math.round(backgroundPositioningArea.left + backgroundPositioningArea.width), Math.round(backgroundPositioningArea.top + y)), new Vector(Math.round(backgroundPositioningArea.left + backgroundPositioningArea.width), Math.round(height + backgroundPositioningArea.top + y)), new Vector(Math.round(backgroundPositioningArea.left), Math.round(height + backgroundPositioningArea.top + y))];

          case BACKGROUND_REPEAT.REPEAT_Y:
            return [new Vector(Math.round(backgroundPositioningArea.left + x), Math.round(backgroundPositioningArea.top)), new Vector(Math.round(backgroundPositioningArea.left + x + width), Math.round(backgroundPositioningArea.top)), new Vector(Math.round(backgroundPositioningArea.left + x + width), Math.round(backgroundPositioningArea.height + backgroundPositioningArea.top)), new Vector(Math.round(backgroundPositioningArea.left + x), Math.round(backgroundPositioningArea.height + backgroundPositioningArea.top))];

          case BACKGROUND_REPEAT.NO_REPEAT:
            return [new Vector(Math.round(backgroundPositioningArea.left + x), Math.round(backgroundPositioningArea.top + y)), new Vector(Math.round(backgroundPositioningArea.left + x + width), Math.round(backgroundPositioningArea.top + y)), new Vector(Math.round(backgroundPositioningArea.left + x + width), Math.round(backgroundPositioningArea.top + y + height)), new Vector(Math.round(backgroundPositioningArea.left + x), Math.round(backgroundPositioningArea.top + y + height))];

          default:
            return [new Vector(Math.round(backgroundPaintingArea.left), Math.round(backgroundPaintingArea.top)), new Vector(Math.round(backgroundPaintingArea.left + backgroundPaintingArea.width), Math.round(backgroundPaintingArea.top)), new Vector(Math.round(backgroundPaintingArea.left + backgroundPaintingArea.width), Math.round(backgroundPaintingArea.height + backgroundPaintingArea.top)), new Vector(Math.round(backgroundPaintingArea.left), Math.round(backgroundPaintingArea.height + backgroundPaintingArea.top))];
        }
      };

      var SMALL_IMAGE = 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7';
      var SAMPLE_TEXT = 'Hidden Text';

      var FontMetrics =
      /** @class */
      function () {
        function FontMetrics(document) {
          this._data = {};
          this._document = document;
        }

        FontMetrics.prototype.parseMetrics = function (fontFamily, fontSize) {
          var container = this._document.createElement('div');

          var img = this._document.createElement('img');

          var span = this._document.createElement('span');

          var body = this._document.body;
          container.style.visibility = 'hidden';
          container.style.fontFamily = fontFamily;
          container.style.fontSize = fontSize;
          container.style.margin = '0';
          container.style.padding = '0';
          body.appendChild(container);
          img.src = SMALL_IMAGE;
          img.width = 1;
          img.height = 1;
          img.style.margin = '0';
          img.style.padding = '0';
          img.style.verticalAlign = 'baseline';
          span.style.fontFamily = fontFamily;
          span.style.fontSize = fontSize;
          span.style.margin = '0';
          span.style.padding = '0';
          span.appendChild(this._document.createTextNode(SAMPLE_TEXT));
          container.appendChild(span);
          container.appendChild(img);
          var baseline = img.offsetTop - span.offsetTop + 2;
          container.removeChild(span);
          container.appendChild(this._document.createTextNode(SAMPLE_TEXT));
          container.style.lineHeight = 'normal';
          img.style.verticalAlign = 'super';
          var middle = img.offsetTop - container.offsetTop + 2;
          body.removeChild(container);
          return {
            baseline: baseline,
            middle: middle
          };
        };

        FontMetrics.prototype.getMetrics = function (fontFamily, fontSize) {
          var key = fontFamily + " " + fontSize;

          if (typeof this._data[key] === 'undefined') {
            this._data[key] = this.parseMetrics(fontFamily, fontSize);
          }

          return this._data[key];
        };

        return FontMetrics;
      }();

      var MASK_OFFSET = 10000;

      var CanvasRenderer =
      /** @class */
      function () {
        function CanvasRenderer(options) {
          this._activeEffects = [];
          this.canvas = options.canvas ? options.canvas : document.createElement('canvas');
          this.ctx = this.canvas.getContext('2d');
          this.options = options;

          if (!options.canvas) {
            this.canvas.width = Math.floor(options.width * options.scale);
            this.canvas.height = Math.floor(options.height * options.scale);
            this.canvas.style.width = options.width + "px";
            this.canvas.style.height = options.height + "px";
          }

          this.fontMetrics = new FontMetrics(document);
          this.ctx.scale(this.options.scale, this.options.scale);
          this.ctx.translate(-options.x + options.scrollX, -options.y + options.scrollY);
          this.ctx.textBaseline = 'bottom';
          this._activeEffects = [];
          Logger.getInstance(options.id).debug("Canvas renderer initialized (" + options.width + "x" + options.height + " at " + options.x + "," + options.y + ") with scale " + options.scale);
        }

        CanvasRenderer.prototype.applyEffects = function (effects, target) {
          var _this = this;

          while (this._activeEffects.length) {
            this.popEffect();
          }

          effects.filter(function (effect) {
            return contains(effect.target, target);
          }).forEach(function (effect) {
            return _this.applyEffect(effect);
          });
        };

        CanvasRenderer.prototype.applyEffect = function (effect) {
          this.ctx.save();

          if (isTransformEffect(effect)) {
            this.ctx.translate(effect.offsetX, effect.offsetY);
            this.ctx.transform(effect.matrix[0], effect.matrix[1], effect.matrix[2], effect.matrix[3], effect.matrix[4], effect.matrix[5]);
            this.ctx.translate(-effect.offsetX, -effect.offsetY);
          }

          if (isClipEffect(effect)) {
            this.path(effect.path);
            this.ctx.clip();
          }

          this._activeEffects.push(effect);
        };

        CanvasRenderer.prototype.popEffect = function () {
          this._activeEffects.pop();

          this.ctx.restore();
        };

        CanvasRenderer.prototype.renderStack = function (stack) {
          return __awaiter(this, void 0, void 0, function () {
            var styles;
            return __generator(this, function (_a) {
              switch (_a.label) {
                case 0:
                  styles = stack.element.container.styles;
                  if (!styles.isVisible()) return [3
                  /*break*/
                  , 2];
                  this.ctx.globalAlpha = styles.opacity;
                  return [4
                  /*yield*/
                  , this.renderStackContent(stack)];

                case 1:
                  _a.sent();

                  _a.label = 2;

                case 2:
                  return [2
                  /*return*/
                  ];
              }
            });
          });
        };

        CanvasRenderer.prototype.renderNode = function (paint) {
          return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
              switch (_a.label) {
                case 0:
                  if (!paint.container.styles.isVisible()) return [3
                  /*break*/
                  , 3];
                  return [4
                  /*yield*/
                  , this.renderNodeBackgroundAndBorders(paint)];

                case 1:
                  _a.sent();

                  return [4
                  /*yield*/
                  , this.renderNodeContent(paint)];

                case 2:
                  _a.sent();

                  _a.label = 3;

                case 3:
                  return [2
                  /*return*/
                  ];
              }
            });
          });
        };

        CanvasRenderer.prototype.renderTextWithLetterSpacing = function (text, letterSpacing) {
          var _this = this;

          if (letterSpacing === 0) {
            this.ctx.fillText(text.text, text.bounds.left, text.bounds.top + text.bounds.height);
          } else {
            var letters = toCodePoints(text.text).map(function (i) {
              return fromCodePoint(i);
            });
            letters.reduce(function (left, letter) {
              _this.ctx.fillText(letter, left, text.bounds.top + text.bounds.height);

              return left + _this.ctx.measureText(letter).width;
            }, text.bounds.left);
          }
        };

        CanvasRenderer.prototype.createFontStyle = function (styles) {
          var fontVariant = styles.fontVariant.filter(function (variant) {
            return variant === 'normal' || variant === 'small-caps';
          }).join('');
          var fontFamily = styles.fontFamily.join(', ');
          var fontSize = isDimensionToken(styles.fontSize) ? "" + styles.fontSize.number + styles.fontSize.unit : styles.fontSize.number + "px";
          return [[styles.fontStyle, fontVariant, styles.fontWeight, fontSize, fontFamily].join(' '), fontFamily, fontSize];
        };

        CanvasRenderer.prototype.renderTextNode = function (text, styles) {
          return __awaiter(this, void 0, void 0, function () {
            var _a, font, fontFamily, fontSize;

            var _this = this;

            return __generator(this, function (_b) {
              _a = this.createFontStyle(styles), font = _a[0], fontFamily = _a[1], fontSize = _a[2];
              this.ctx.font = font;
              text.textBounds.forEach(function (text) {
                _this.ctx.fillStyle = asString(styles.color);

                _this.renderTextWithLetterSpacing(text, styles.letterSpacing);

                var textShadows = styles.textShadow;

                if (textShadows.length && text.text.trim().length) {
                  textShadows.slice(0).reverse().forEach(function (textShadow) {
                    _this.ctx.shadowColor = asString(textShadow.color);
                    _this.ctx.shadowOffsetX = textShadow.offsetX.number * _this.options.scale;
                    _this.ctx.shadowOffsetY = textShadow.offsetY.number * _this.options.scale;
                    _this.ctx.shadowBlur = textShadow.blur.number;

                    _this.ctx.fillText(text.text, text.bounds.left, text.bounds.top + text.bounds.height);
                  });
                  _this.ctx.shadowColor = '';
                  _this.ctx.shadowOffsetX = 0;
                  _this.ctx.shadowOffsetY = 0;
                  _this.ctx.shadowBlur = 0;
                }

                if (styles.textDecorationLine.length) {
                  _this.ctx.fillStyle = asString(styles.textDecorationColor || styles.color);
                  styles.textDecorationLine.forEach(function (textDecorationLine) {
                    switch (textDecorationLine) {
                      case 1
                      /* UNDERLINE */
                      :
                        // Draws a line at the baseline of the font
                        // TODO As some browsers display the line as more than 1px if the font-size is big,
                        // need to take that into account both in position and size
                        var baseline = _this.fontMetrics.getMetrics(fontFamily, fontSize).baseline;

                        _this.ctx.fillRect(text.bounds.left, Math.round(text.bounds.top + baseline), text.bounds.width, 1);

                        break;

                      case 2
                      /* OVERLINE */
                      :
                        _this.ctx.fillRect(text.bounds.left, Math.round(text.bounds.top), text.bounds.width, 1);

                        break;

                      case 3
                      /* LINE_THROUGH */
                      :
                        // TODO try and find exact position for line-through
                        var middle = _this.fontMetrics.getMetrics(fontFamily, fontSize).middle;

                        _this.ctx.fillRect(text.bounds.left, Math.ceil(text.bounds.top + middle), text.bounds.width, 1);

                        break;
                    }
                  });
                }
              });
              return [2
              /*return*/
              ];
            });
          });
        };

        CanvasRenderer.prototype.renderReplacedElement = function (container, curves, image) {
          if (image && container.intrinsicWidth > 0 && container.intrinsicHeight > 0) {
            var box = contentBox(container);
            var path = calculatePaddingBoxPath(curves);
            this.path(path);
            this.ctx.save();
            this.ctx.clip();
            this.ctx.drawImage(image, 0, 0, container.intrinsicWidth, container.intrinsicHeight, box.left, box.top, box.width, box.height);
            this.ctx.restore();
          }
        };

        CanvasRenderer.prototype.renderNodeContent = function (paint) {
          return __awaiter(this, void 0, void 0, function () {
            var container, curves, styles, _i, _a, child, image, e_1, image, e_2, iframeRenderer, canvas, size, bounds, x, textBounds, img, image, url, e_3, bounds;

            return __generator(this, function (_b) {
              switch (_b.label) {
                case 0:
                  this.applyEffects(paint.effects, 4
                  /* CONTENT */
                  );
                  container = paint.container;
                  curves = paint.curves;
                  styles = container.styles;
                  _i = 0, _a = container.textNodes;
                  _b.label = 1;

                case 1:
                  if (!(_i < _a.length)) return [3
                  /*break*/
                  , 4];
                  child = _a[_i];
                  return [4
                  /*yield*/
                  , this.renderTextNode(child, styles)];

                case 2:
                  _b.sent();

                  _b.label = 3;

                case 3:
                  _i++;
                  return [3
                  /*break*/
                  , 1];

                case 4:
                  if (!(container instanceof ImageElementContainer)) return [3
                  /*break*/
                  , 8];
                  _b.label = 5;

                case 5:
                  _b.trys.push([5, 7,, 8]);

                  return [4
                  /*yield*/
                  , this.options.cache.match(container.src)];

                case 6:
                  image = _b.sent();
                  this.renderReplacedElement(container, curves, image);
                  return [3
                  /*break*/
                  , 8];

                case 7:
                  e_1 = _b.sent();
                  Logger.getInstance(this.options.id).error("Error loading image " + container.src);
                  return [3
                  /*break*/
                  , 8];

                case 8:
                  if (container instanceof CanvasElementContainer) {
                    this.renderReplacedElement(container, curves, container.canvas);
                  }

                  if (!(container instanceof SVGElementContainer)) return [3
                  /*break*/
                  , 12];
                  _b.label = 9;

                case 9:
                  _b.trys.push([9, 11,, 12]);

                  return [4
                  /*yield*/
                  , this.options.cache.match(container.svg)];

                case 10:
                  image = _b.sent();
                  this.renderReplacedElement(container, curves, image);
                  return [3
                  /*break*/
                  , 12];

                case 11:
                  e_2 = _b.sent();
                  Logger.getInstance(this.options.id).error("Error loading svg " + container.svg.substring(0, 255));
                  return [3
                  /*break*/
                  , 12];

                case 12:
                  if (!(container instanceof IFrameElementContainer && container.tree)) return [3
                  /*break*/
                  , 14];
                  iframeRenderer = new CanvasRenderer({
                    id: this.options.id,
                    scale: this.options.scale,
                    backgroundColor: container.backgroundColor,
                    x: 0,
                    y: 0,
                    scrollX: 0,
                    scrollY: 0,
                    width: container.width,
                    height: container.height,
                    cache: this.options.cache,
                    windowWidth: container.width,
                    windowHeight: container.height
                  });
                  return [4
                  /*yield*/
                  , iframeRenderer.render(container.tree)];

                case 13:
                  canvas = _b.sent();

                  if (container.width && container.height) {
                    this.ctx.drawImage(canvas, 0, 0, container.width, container.height, container.bounds.left, container.bounds.top, container.bounds.width, container.bounds.height);
                  }

                  _b.label = 14;

                case 14:
                  if (container instanceof InputElementContainer) {
                    size = Math.min(container.bounds.width, container.bounds.height);

                    if (container.type === CHECKBOX) {
                      if (container.checked) {
                        this.ctx.save();
                        this.path([new Vector(container.bounds.left + size * 0.39363, container.bounds.top + size * 0.79), new Vector(container.bounds.left + size * 0.16, container.bounds.top + size * 0.5549), new Vector(container.bounds.left + size * 0.27347, container.bounds.top + size * 0.44071), new Vector(container.bounds.left + size * 0.39694, container.bounds.top + size * 0.5649), new Vector(container.bounds.left + size * 0.72983, container.bounds.top + size * 0.23), new Vector(container.bounds.left + size * 0.84, container.bounds.top + size * 0.34085), new Vector(container.bounds.left + size * 0.39363, container.bounds.top + size * 0.79)]);
                        this.ctx.fillStyle = asString(INPUT_COLOR);
                        this.ctx.fill();
                        this.ctx.restore();
                      }
                    } else if (container.type === RADIO) {
                      if (container.checked) {
                        this.ctx.save();
                        this.ctx.beginPath();
                        this.ctx.arc(container.bounds.left + size / 2, container.bounds.top + size / 2, size / 4, 0, Math.PI * 2, true);
                        this.ctx.fillStyle = asString(INPUT_COLOR);
                        this.ctx.fill();
                        this.ctx.restore();
                      }
                    }
                  }

                  if (isTextInputElement(container) && container.value.length) {
                    this.ctx.font = this.createFontStyle(styles)[0];
                    this.ctx.fillStyle = asString(styles.color);
                    this.ctx.textBaseline = 'middle';
                    this.ctx.textAlign = canvasTextAlign(container.styles.textAlign);
                    bounds = contentBox(container);
                    x = 0;

                    switch (container.styles.textAlign) {
                      case TEXT_ALIGN.CENTER:
                        x += bounds.width / 2;
                        break;

                      case TEXT_ALIGN.RIGHT:
                        x += bounds.width;
                        break;
                    }

                    textBounds = bounds.add(x, 0, 0, -bounds.height / 2 + 1);
                    this.ctx.save();
                    this.path([new Vector(bounds.left, bounds.top), new Vector(bounds.left + bounds.width, bounds.top), new Vector(bounds.left + bounds.width, bounds.top + bounds.height), new Vector(bounds.left, bounds.top + bounds.height)]);
                    this.ctx.clip();
                    this.renderTextWithLetterSpacing(new TextBounds(container.value, textBounds), styles.letterSpacing);
                    this.ctx.restore();
                    this.ctx.textBaseline = 'bottom';
                    this.ctx.textAlign = 'left';
                  }

                  if (!contains(container.styles.display, 2048
                  /* LIST_ITEM */
                  )) return [3
                  /*break*/
                  , 20];
                  if (!(container.styles.listStyleImage !== null)) return [3
                  /*break*/
                  , 19];
                  img = container.styles.listStyleImage;
                  if (!(img.type === CSSImageType.URL)) return [3
                  /*break*/
                  , 18];
                  image = void 0;
                  url = img.url;
                  _b.label = 15;

                case 15:
                  _b.trys.push([15, 17,, 18]);

                  return [4
                  /*yield*/
                  , this.options.cache.match(url)];

                case 16:
                  image = _b.sent();
                  this.ctx.drawImage(image, container.bounds.left - (image.width + 10), container.bounds.top);
                  return [3
                  /*break*/
                  , 18];

                case 17:
                  e_3 = _b.sent();
                  Logger.getInstance(this.options.id).error("Error loading list-style-image " + url);
                  return [3
                  /*break*/
                  , 18];

                case 18:
                  return [3
                  /*break*/
                  , 20];

                case 19:
                  if (paint.listValue && container.styles.listStyleType !== LIST_STYLE_TYPE.NONE) {
                    this.ctx.font = this.createFontStyle(styles)[0];
                    this.ctx.fillStyle = asString(styles.color);
                    this.ctx.textBaseline = 'middle';
                    this.ctx.textAlign = 'right';
                    bounds = new Bounds(container.bounds.left, container.bounds.top + getAbsoluteValue(container.styles.paddingTop, container.bounds.width), container.bounds.width, computeLineHeight(styles.lineHeight, styles.fontSize.number) / 2 + 1);
                    this.renderTextWithLetterSpacing(new TextBounds(paint.listValue, bounds), styles.letterSpacing);
                    this.ctx.textBaseline = 'bottom';
                    this.ctx.textAlign = 'left';
                  }

                  _b.label = 20;

                case 20:
                  return [2
                  /*return*/
                  ];
              }
            });
          });
        };

        CanvasRenderer.prototype.renderStackContent = function (stack) {
          return __awaiter(this, void 0, void 0, function () {
            var _i, _a, child, _b, _c, child, _d, _e, child, _f, _g, child, _h, _j, child, _k, _l, child, _m, _o, child;

            return __generator(this, function (_p) {
              switch (_p.label) {
                case 0:
                  // https://www.w3.org/TR/css-position-3/#painting-order
                  // 1. the background and borders of the element forming the stacking context.
                  return [4
                  /*yield*/
                  , this.renderNodeBackgroundAndBorders(stack.element)];

                case 1:
                  // https://www.w3.org/TR/css-position-3/#painting-order
                  // 1. the background and borders of the element forming the stacking context.
                  _p.sent();

                  _i = 0, _a = stack.negativeZIndex;
                  _p.label = 2;

                case 2:
                  if (!(_i < _a.length)) return [3
                  /*break*/
                  , 5];
                  child = _a[_i];
                  return [4
                  /*yield*/
                  , this.renderStack(child)];

                case 3:
                  _p.sent();

                  _p.label = 4;

                case 4:
                  _i++;
                  return [3
                  /*break*/
                  , 2];

                case 5:
                  // 3. For all its in-flow, non-positioned, block-level descendants in tree order:
                  return [4
                  /*yield*/
                  , this.renderNodeContent(stack.element)];

                case 6:
                  // 3. For all its in-flow, non-positioned, block-level descendants in tree order:
                  _p.sent();

                  _b = 0, _c = stack.nonInlineLevel;
                  _p.label = 7;

                case 7:
                  if (!(_b < _c.length)) return [3
                  /*break*/
                  , 10];
                  child = _c[_b];
                  return [4
                  /*yield*/
                  , this.renderNode(child)];

                case 8:
                  _p.sent();

                  _p.label = 9;

                case 9:
                  _b++;
                  return [3
                  /*break*/
                  , 7];

                case 10:
                  _d = 0, _e = stack.nonPositionedFloats;
                  _p.label = 11;

                case 11:
                  if (!(_d < _e.length)) return [3
                  /*break*/
                  , 14];
                  child = _e[_d];
                  return [4
                  /*yield*/
                  , this.renderStack(child)];

                case 12:
                  _p.sent();

                  _p.label = 13;

                case 13:
                  _d++;
                  return [3
                  /*break*/
                  , 11];

                case 14:
                  _f = 0, _g = stack.nonPositionedInlineLevel;
                  _p.label = 15;

                case 15:
                  if (!(_f < _g.length)) return [3
                  /*break*/
                  , 18];
                  child = _g[_f];
                  return [4
                  /*yield*/
                  , this.renderStack(child)];

                case 16:
                  _p.sent();

                  _p.label = 17;

                case 17:
                  _f++;
                  return [3
                  /*break*/
                  , 15];

                case 18:
                  _h = 0, _j = stack.inlineLevel;
                  _p.label = 19;

                case 19:
                  if (!(_h < _j.length)) return [3
                  /*break*/
                  , 22];
                  child = _j[_h];
                  return [4
                  /*yield*/
                  , this.renderNode(child)];

                case 20:
                  _p.sent();

                  _p.label = 21;

                case 21:
                  _h++;
                  return [3
                  /*break*/
                  , 19];

                case 22:
                  _k = 0, _l = stack.zeroOrAutoZIndexOrTransformedOrOpacity;
                  _p.label = 23;

                case 23:
                  if (!(_k < _l.length)) return [3
                  /*break*/
                  , 26];
                  child = _l[_k];
                  return [4
                  /*yield*/
                  , this.renderStack(child)];

                case 24:
                  _p.sent();

                  _p.label = 25;

                case 25:
                  _k++;
                  return [3
                  /*break*/
                  , 23];

                case 26:
                  _m = 0, _o = stack.positiveZIndex;
                  _p.label = 27;

                case 27:
                  if (!(_m < _o.length)) return [3
                  /*break*/
                  , 30];
                  child = _o[_m];
                  return [4
                  /*yield*/
                  , this.renderStack(child)];

                case 28:
                  _p.sent();

                  _p.label = 29;

                case 29:
                  _m++;
                  return [3
                  /*break*/
                  , 27];

                case 30:
                  return [2
                  /*return*/
                  ];
              }
            });
          });
        };

        CanvasRenderer.prototype.mask = function (paths) {
          this.ctx.beginPath();
          this.ctx.moveTo(0, 0);
          this.ctx.lineTo(this.canvas.width, 0);
          this.ctx.lineTo(this.canvas.width, this.canvas.height);
          this.ctx.lineTo(0, this.canvas.height);
          this.ctx.lineTo(0, 0);
          this.formatPath(paths.slice(0).reverse());
          this.ctx.closePath();
        };

        CanvasRenderer.prototype.path = function (paths) {
          this.ctx.beginPath();
          this.formatPath(paths);
          this.ctx.closePath();
        };

        CanvasRenderer.prototype.formatPath = function (paths) {
          var _this = this;

          paths.forEach(function (point, index) {
            var start = isBezierCurve(point) ? point.start : point;

            if (index === 0) {
              _this.ctx.moveTo(start.x, start.y);
            } else {
              _this.ctx.lineTo(start.x, start.y);
            }

            if (isBezierCurve(point)) {
              _this.ctx.bezierCurveTo(point.startControl.x, point.startControl.y, point.endControl.x, point.endControl.y, point.end.x, point.end.y);
            }
          });
        };

        CanvasRenderer.prototype.renderRepeat = function (path, pattern, offsetX, offsetY) {
          this.path(path);
          this.ctx.fillStyle = pattern;
          this.ctx.translate(offsetX, offsetY);
          this.ctx.fill();
          this.ctx.translate(-offsetX, -offsetY);
        };

        CanvasRenderer.prototype.resizeImage = function (image, width, height) {
          if (image.width === width && image.height === height) {
            return image;
          }

          var canvas = this.canvas.ownerDocument.createElement('canvas');
          canvas.width = width;
          canvas.height = height;
          var ctx = canvas.getContext('2d');
          ctx.drawImage(image, 0, 0, image.width, image.height, 0, 0, width, height);
          return canvas;
        };

        CanvasRenderer.prototype.renderBackgroundImage = function (container) {
          return __awaiter(this, void 0, void 0, function () {
            var index, _loop_1, this_1, _i, _a, backgroundImage;

            return __generator(this, function (_b) {
              switch (_b.label) {
                case 0:
                  index = container.styles.backgroundImage.length - 1;

                  _loop_1 = function _loop_1(backgroundImage) {
                    var image, url, e_4, _a, path, x, y, width, height, pattern, _b, path, x, y, width, height, _c, lineLength, x0, x1, y0, y1, canvas, ctx, gradient_1, pattern, _d, path, left, top_1, width, height, position, x, y, _e, rx, ry, radialGradient_1, midX, midY, f, invF;

                    return __generator(this, function (_f) {
                      switch (_f.label) {
                        case 0:
                          if (!(backgroundImage.type === CSSImageType.URL)) return [3
                          /*break*/
                          , 5];
                          image = void 0;
                          url = backgroundImage.url;
                          _f.label = 1;

                        case 1:
                          _f.trys.push([1, 3,, 4]);

                          return [4
                          /*yield*/
                          , this_1.options.cache.match(url)];

                        case 2:
                          image = _f.sent();
                          return [3
                          /*break*/
                          , 4];

                        case 3:
                          e_4 = _f.sent();
                          Logger.getInstance(this_1.options.id).error("Error loading background-image " + url);
                          return [3
                          /*break*/
                          , 4];

                        case 4:
                          if (image) {
                            _a = calculateBackgroundRendering(container, index, [image.width, image.height, image.width / image.height]), path = _a[0], x = _a[1], y = _a[2], width = _a[3], height = _a[4];
                            pattern = this_1.ctx.createPattern(this_1.resizeImage(image, width, height), 'repeat');
                            this_1.renderRepeat(path, pattern, x, y);
                          }

                          return [3
                          /*break*/
                          , 6];

                        case 5:
                          if (isLinearGradient(backgroundImage)) {
                            _b = calculateBackgroundRendering(container, index, [null, null, null]), path = _b[0], x = _b[1], y = _b[2], width = _b[3], height = _b[4];
                            _c = calculateGradientDirection(backgroundImage.angle, width, height), lineLength = _c[0], x0 = _c[1], x1 = _c[2], y0 = _c[3], y1 = _c[4];
                            canvas = document.createElement('canvas');
                            canvas.width = width;
                            canvas.height = height;
                            ctx = canvas.getContext('2d');
                            gradient_1 = ctx.createLinearGradient(x0, y0, x1, y1);
                            processColorStops(backgroundImage.stops, lineLength).forEach(function (colorStop) {
                              return gradient_1.addColorStop(colorStop.stop, asString(colorStop.color));
                            });
                            ctx.fillStyle = gradient_1;
                            ctx.fillRect(0, 0, width, height);

                            if (width > 0 && height > 0) {
                              pattern = this_1.ctx.createPattern(canvas, 'repeat');
                              this_1.renderRepeat(path, pattern, x, y);
                            }
                          } else if (isRadialGradient(backgroundImage)) {
                            _d = calculateBackgroundRendering(container, index, [null, null, null]), path = _d[0], left = _d[1], top_1 = _d[2], width = _d[3], height = _d[4];
                            position = backgroundImage.position.length === 0 ? [FIFTY_PERCENT] : backgroundImage.position;
                            x = getAbsoluteValue(position[0], width);
                            y = getAbsoluteValue(position[position.length - 1], height);
                            _e = calculateRadius(backgroundImage, x, y, width, height), rx = _e[0], ry = _e[1];

                            if (rx > 0 && rx > 0) {
                              radialGradient_1 = this_1.ctx.createRadialGradient(left + x, top_1 + y, 0, left + x, top_1 + y, rx);
                              processColorStops(backgroundImage.stops, rx * 2).forEach(function (colorStop) {
                                return radialGradient_1.addColorStop(colorStop.stop, asString(colorStop.color));
                              });
                              this_1.path(path);
                              this_1.ctx.fillStyle = radialGradient_1;

                              if (rx !== ry) {
                                midX = container.bounds.left + 0.5 * container.bounds.width;
                                midY = container.bounds.top + 0.5 * container.bounds.height;
                                f = ry / rx;
                                invF = 1 / f;
                                this_1.ctx.save();
                                this_1.ctx.translate(midX, midY);
                                this_1.ctx.transform(1, 0, 0, f, 0, 0);
                                this_1.ctx.translate(-midX, -midY);
                                this_1.ctx.fillRect(left, invF * (top_1 - midY) + midY, width, height * invF);
                                this_1.ctx.restore();
                              } else {
                                this_1.ctx.fill();
                              }
                            }
                          }

                          _f.label = 6;

                        case 6:
                          index--;
                          return [2
                          /*return*/
                          ];
                      }
                    });
                  };

                  this_1 = this;
                  _i = 0, _a = container.styles.backgroundImage.slice(0).reverse();
                  _b.label = 1;

                case 1:
                  if (!(_i < _a.length)) return [3
                  /*break*/
                  , 4];
                  backgroundImage = _a[_i];
                  return [5
                  /*yield**/
                  , _loop_1(backgroundImage)];

                case 2:
                  _b.sent();

                  _b.label = 3;

                case 3:
                  _i++;
                  return [3
                  /*break*/
                  , 1];

                case 4:
                  return [2
                  /*return*/
                  ];
              }
            });
          });
        };

        CanvasRenderer.prototype.renderBorder = function (color, side, curvePoints) {
          return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
              this.path(parsePathForBorder(curvePoints, side));
              this.ctx.fillStyle = asString(color);
              this.ctx.fill();
              return [2
              /*return*/
              ];
            });
          });
        };

        CanvasRenderer.prototype.renderNodeBackgroundAndBorders = function (paint) {
          return __awaiter(this, void 0, void 0, function () {
            var styles, hasBackground, borders, backgroundPaintingArea, side, _i, borders_1, border;

            var _this = this;

            return __generator(this, function (_a) {
              switch (_a.label) {
                case 0:
                  this.applyEffects(paint.effects, 2
                  /* BACKGROUND_BORDERS */
                  );
                  styles = paint.container.styles;
                  hasBackground = !isTransparent(styles.backgroundColor) || styles.backgroundImage.length;
                  borders = [{
                    style: styles.borderTopStyle,
                    color: styles.borderTopColor
                  }, {
                    style: styles.borderRightStyle,
                    color: styles.borderRightColor
                  }, {
                    style: styles.borderBottomStyle,
                    color: styles.borderBottomColor
                  }, {
                    style: styles.borderLeftStyle,
                    color: styles.borderLeftColor
                  }];
                  backgroundPaintingArea = calculateBackgroundCurvedPaintingArea(getBackgroundValueForIndex(styles.backgroundClip, 0), paint.curves);
                  if (!(hasBackground || styles.boxShadow.length)) return [3
                  /*break*/
                  , 2];
                  this.ctx.save();
                  this.path(backgroundPaintingArea);
                  this.ctx.clip();

                  if (!isTransparent(styles.backgroundColor)) {
                    this.ctx.fillStyle = asString(styles.backgroundColor);
                    this.ctx.fill();
                  }

                  return [4
                  /*yield*/
                  , this.renderBackgroundImage(paint.container)];

                case 1:
                  _a.sent();

                  this.ctx.restore();
                  styles.boxShadow.slice(0).reverse().forEach(function (shadow) {
                    _this.ctx.save();

                    var borderBoxArea = calculateBorderBoxPath(paint.curves);
                    var maskOffset = shadow.inset ? 0 : MASK_OFFSET;
                    var shadowPaintingArea = transformPath(borderBoxArea, -maskOffset + (shadow.inset ? 1 : -1) * shadow.spread.number, (shadow.inset ? 1 : -1) * shadow.spread.number, shadow.spread.number * (shadow.inset ? -2 : 2), shadow.spread.number * (shadow.inset ? -2 : 2));

                    if (shadow.inset) {
                      _this.path(borderBoxArea);

                      _this.ctx.clip();

                      _this.mask(shadowPaintingArea);
                    } else {
                      _this.mask(borderBoxArea);

                      _this.ctx.clip();

                      _this.path(shadowPaintingArea);
                    }

                    _this.ctx.shadowOffsetX = shadow.offsetX.number + maskOffset;
                    _this.ctx.shadowOffsetY = shadow.offsetY.number;
                    _this.ctx.shadowColor = asString(shadow.color);
                    _this.ctx.shadowBlur = shadow.blur.number;
                    _this.ctx.fillStyle = shadow.inset ? asString(shadow.color) : 'rgba(0,0,0,1)';

                    _this.ctx.fill();

                    _this.ctx.restore();
                  });
                  _a.label = 2;

                case 2:
                  side = 0;
                  _i = 0, borders_1 = borders;
                  _a.label = 3;

                case 3:
                  if (!(_i < borders_1.length)) return [3
                  /*break*/
                  , 7];
                  border = borders_1[_i];
                  if (!(border.style !== BORDER_STYLE.NONE && !isTransparent(border.color))) return [3
                  /*break*/
                  , 5];
                  return [4
                  /*yield*/
                  , this.renderBorder(border.color, side, paint.curves)];

                case 4:
                  _a.sent();

                  _a.label = 5;

                case 5:
                  side++;
                  _a.label = 6;

                case 6:
                  _i++;
                  return [3
                  /*break*/
                  , 3];

                case 7:
                  return [2
                  /*return*/
                  ];
              }
            });
          });
        };

        CanvasRenderer.prototype.render = function (element) {
          return __awaiter(this, void 0, void 0, function () {
            var stack;
            return __generator(this, function (_a) {
              switch (_a.label) {
                case 0:
                  if (this.options.backgroundColor) {
                    this.ctx.fillStyle = asString(this.options.backgroundColor);
                    this.ctx.fillRect(this.options.x - this.options.scrollX, this.options.y - this.options.scrollY, this.options.width, this.options.height);
                  }

                  stack = parseStackingContexts(element);
                  return [4
                  /*yield*/
                  , this.renderStack(stack)];

                case 1:
                  _a.sent();

                  this.applyEffects([], 2
                  /* BACKGROUND_BORDERS */
                  );
                  return [2
                  /*return*/
                  , this.canvas];
              }
            });
          });
        };

        return CanvasRenderer;
      }();

      var isTextInputElement = function isTextInputElement(container) {
        if (container instanceof TextareaElementContainer) {
          return true;
        } else if (container instanceof SelectElementContainer) {
          return true;
        } else if (container instanceof InputElementContainer && container.type !== RADIO && container.type !== CHECKBOX) {
          return true;
        }

        return false;
      };

      var calculateBackgroundCurvedPaintingArea = function calculateBackgroundCurvedPaintingArea(clip, curves) {
        switch (clip) {
          case BACKGROUND_CLIP.BORDER_BOX:
            return calculateBorderBoxPath(curves);

          case BACKGROUND_CLIP.CONTENT_BOX:
            return calculateContentBoxPath(curves);

          case BACKGROUND_CLIP.PADDING_BOX:
          default:
            return calculatePaddingBoxPath(curves);
        }
      };

      var canvasTextAlign = function canvasTextAlign(textAlign) {
        switch (textAlign) {
          case TEXT_ALIGN.CENTER:
            return 'center';

          case TEXT_ALIGN.RIGHT:
            return 'right';

          case TEXT_ALIGN.LEFT:
          default:
            return 'left';
        }
      };

      var ForeignObjectRenderer =
      /** @class */
      function () {
        function ForeignObjectRenderer(options) {
          this.canvas = options.canvas ? options.canvas : document.createElement('canvas');
          this.ctx = this.canvas.getContext('2d');
          this.options = options;
          this.canvas.width = Math.floor(options.width * options.scale);
          this.canvas.height = Math.floor(options.height * options.scale);
          this.canvas.style.width = options.width + "px";
          this.canvas.style.height = options.height + "px";
          this.ctx.scale(this.options.scale, this.options.scale);
          this.ctx.translate(-options.x + options.scrollX, -options.y + options.scrollY);
          Logger.getInstance(options.id).debug("EXPERIMENTAL ForeignObject renderer initialized (" + options.width + "x" + options.height + " at " + options.x + "," + options.y + ") with scale " + options.scale);
        }

        ForeignObjectRenderer.prototype.render = function (element) {
          return __awaiter(this, void 0, void 0, function () {
            var svg, img;
            return __generator(this, function (_a) {
              switch (_a.label) {
                case 0:
                  svg = createForeignObjectSVG(Math.max(this.options.windowWidth, this.options.width) * this.options.scale, Math.max(this.options.windowHeight, this.options.height) * this.options.scale, this.options.scrollX * this.options.scale, this.options.scrollY * this.options.scale, element);
                  return [4
                  /*yield*/
                  , loadSerializedSVG$1(svg)];

                case 1:
                  img = _a.sent();

                  if (this.options.backgroundColor) {
                    this.ctx.fillStyle = asString(this.options.backgroundColor);
                    this.ctx.fillRect(0, 0, this.options.width * this.options.scale, this.options.height * this.options.scale);
                  }

                  this.ctx.drawImage(img, -this.options.x * this.options.scale, -this.options.y * this.options.scale);
                  return [2
                  /*return*/
                  , this.canvas];
              }
            });
          });
        };

        return ForeignObjectRenderer;
      }();

      var loadSerializedSVG$1 = function loadSerializedSVG$1(svg) {
        return new Promise(function (resolve, reject) {
          var img = new Image();

          img.onload = function () {
            resolve(img);
          };

          img.onerror = reject;
          img.src = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(new XMLSerializer().serializeToString(svg));
        });
      };

      var _this = undefined;

      var parseColor$1 = function parseColor$1(value) {
        return color.parse(Parser.create(value).parseComponentValue());
      };

      var html2canvas = function html2canvas(element, options) {
        if (options === void 0) {
          options = {};
        }

        return renderElement(element, options);
      };

      if (typeof window !== 'undefined') {
        CacheStorage.setContext(window);
      }

      var renderElement = function renderElement(element, opts) {
        return __awaiter(_this, void 0, void 0, function () {
          var ownerDocument, defaultView, instanceName, _a, width, height, left, top, defaultResourceOptions, resourceOptions, defaultOptions, options, windowBounds, documentCloner, clonedElement, container, documentBackgroundColor, bodyBackgroundColor, bgColor, defaultBackgroundColor, backgroundColor, renderOptions, canvas, renderer, root, renderer;

          return __generator(this, function (_b) {
            switch (_b.label) {
              case 0:
                ownerDocument = element.ownerDocument;

                if (!ownerDocument) {
                  throw new Error("Element is not attached to a Document");
                }

                defaultView = ownerDocument.defaultView;

                if (!defaultView) {
                  throw new Error("Document is not attached to a Window");
                }

                instanceName = (Math.round(Math.random() * 1000) + Date.now()).toString(16);
                _a = isBodyElement(element) || isHTMLElement(element) ? parseDocumentSize(ownerDocument) : parseBounds(element), width = _a.width, height = _a.height, left = _a.left, top = _a.top;
                defaultResourceOptions = {
                  allowTaint: false,
                  imageTimeout: 15000,
                  proxy: undefined,
                  useCORS: false
                };
                resourceOptions = _assign({}, defaultResourceOptions, opts);
                defaultOptions = {
                  backgroundColor: '#ffffff',
                  cache: opts.cache ? opts.cache : CacheStorage.create(instanceName, resourceOptions),
                  logging: true,
                  removeContainer: true,
                  foreignObjectRendering: false,
                  scale: defaultView.devicePixelRatio || 1,
                  windowWidth: defaultView.innerWidth,
                  windowHeight: defaultView.innerHeight,
                  scrollX: defaultView.pageXOffset,
                  scrollY: defaultView.pageYOffset,
                  x: left,
                  y: top,
                  width: Math.ceil(width),
                  height: Math.ceil(height),
                  id: instanceName
                };
                options = _assign({}, defaultOptions, resourceOptions, opts);
                windowBounds = new Bounds(options.scrollX, options.scrollY, options.windowWidth, options.windowHeight);
                Logger.create({
                  id: instanceName,
                  enabled: options.logging
                });
                Logger.getInstance(instanceName).debug("Starting document clone");
                documentCloner = new DocumentCloner(element, {
                  id: instanceName,
                  onclone: options.onclone,
                  ignoreElements: options.ignoreElements,
                  inlineImages: options.foreignObjectRendering,
                  copyStyles: options.foreignObjectRendering
                });
                clonedElement = documentCloner.clonedReferenceElement;

                if (!clonedElement) {
                  return [2
                  /*return*/
                  , Promise.reject("Unable to find element in cloned iframe")];
                }

                return [4
                /*yield*/
                , documentCloner.toIFrame(ownerDocument, windowBounds)];

              case 1:
                container = _b.sent();
                documentBackgroundColor = ownerDocument.documentElement ? parseColor$1(getComputedStyle(ownerDocument.documentElement).backgroundColor) : COLORS.TRANSPARENT;
                bodyBackgroundColor = ownerDocument.body ? parseColor$1(getComputedStyle(ownerDocument.body).backgroundColor) : COLORS.TRANSPARENT;
                bgColor = opts.backgroundColor;
                defaultBackgroundColor = typeof bgColor === 'string' ? parseColor$1(bgColor) : bgColor === null ? COLORS.TRANSPARENT : 0xffffffff;
                backgroundColor = element === ownerDocument.documentElement ? isTransparent(documentBackgroundColor) ? isTransparent(bodyBackgroundColor) ? defaultBackgroundColor : bodyBackgroundColor : documentBackgroundColor : defaultBackgroundColor;
                renderOptions = {
                  id: instanceName,
                  cache: options.cache,
                  canvas: options.canvas,
                  backgroundColor: backgroundColor,
                  scale: options.scale,
                  x: options.x,
                  y: options.y,
                  scrollX: options.scrollX,
                  scrollY: options.scrollY,
                  width: options.width,
                  height: options.height,
                  windowWidth: options.windowWidth,
                  windowHeight: options.windowHeight
                };
                if (!options.foreignObjectRendering) return [3
                /*break*/
                , 3];
                Logger.getInstance(instanceName).debug("Document cloned, using foreign object rendering");
                renderer = new ForeignObjectRenderer(renderOptions);
                return [4
                /*yield*/
                , renderer.render(clonedElement)];

              case 2:
                canvas = _b.sent();
                return [3
                /*break*/
                , 5];

              case 3:
                Logger.getInstance(instanceName).debug("Document cloned, using computed rendering");
                CacheStorage.attachInstance(options.cache);
                Logger.getInstance(instanceName).debug("Starting DOM parsing");
                root = parseTree(clonedElement);
                CacheStorage.detachInstance();

                if (backgroundColor === root.styles.backgroundColor) {
                  root.styles.backgroundColor = COLORS.TRANSPARENT;
                }

                Logger.getInstance(instanceName).debug("Starting renderer");
                renderer = new CanvasRenderer(renderOptions);
                return [4
                /*yield*/
                , renderer.render(root)];

              case 4:
                canvas = _b.sent();
                _b.label = 5;

              case 5:
                if (options.removeContainer === true) {
                  if (!DocumentCloner.destroy(container)) {
                    Logger.getInstance(instanceName).error("Cannot detach cloned iframe as it is not in the DOM anymore");
                  }
                }

                Logger.getInstance(instanceName).debug("Finished rendering");
                Logger.destroy(instanceName);
                CacheStorage.destroy(instanceName);
                return [2
                /*return*/
                , canvas];
            }
          });
        });
      };

      return html2canvas;
    }); //# sourceMappingURL=html2canvas.js.map

    /***/

  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/surveyprocess/surveyprocess.page.html":
  /*!*********************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/surveyprocess/surveyprocess.page.html ***!
    \*********************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppSurveyprocessSurveyprocessPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\r\n  <ion-progress-bar [value]=\"totalpercent\" mode=\"ios\" color=\"success\" class=\"progress-bar-height\"></ion-progress-bar>\r\n</ion-header>\r\n\r\n<ion-content *ngIf=\"isdataloaded && this.mainmenuitems[this.selectedmainmenuindex].viewmode == ViewModes.CAMERA\" [forceOverscroll]=\"false\">\r\n  <ion-grid class=\"ion-no-padding\">\r\n    <ion-row>\r\n      <ion-row style=\"width: 100%;\" *ngIf=\"isdataloaded\">\r\n        <ion-col size=\"12\" class=\"actionareacol\">\r\n          <ion-row class=\"ion-justify-content-center ion-align-items-center\">\r\n            <p class=\"shotinfo\">\r\n              {{this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[this.selectedshotindex].shotinfo}}\r\n            </p>\r\n          </ion-row>\r\n        </ion-col>\r\n      </ion-row>\r\n      <ion-row class=\"actionarea\" *ngIf=\"isdataloaded\">\r\n        <ion-row style=\"width: 100%;\">\r\n          <ion-col size=\"12\" class=\"actionareacol\">\r\n            <ion-row class=\"ion-justify-content-center\">\r\n              <ion-button *ngIf=\"!displayflashrow\" fill=\"clear\" (click)=\"changeZoom()\" class=\"zoombutton\">{{currentzoom}}x</ion-button>\r\n              <a *ngIf=\"!displayflashrow\" (click)=\"switchCamera()\" class=\"circularbutton\"><img src=\"../../assets/images/switch-camera.svg\"/></a>\r\n              <a (click)=\"displayflashrow = !displayflashrow\" class=\"flashbutton\"><ion-icon name=\"flash-outline\"></ion-icon></a>\r\n              <ion-row *ngIf=\"displayflashrow\">\r\n                <ion-button style=\"margin-top: 8px;\" color=\"light\" size=\"small\" (click)=\"changeFlashMode(auto)\">Auto</ion-button>\r\n                <ion-button style=\"margin-top: 8px;\" color=\"light\" size=\"small\" (click)=\"changeFlashMode(on)\">On</ion-button>\r\n                <ion-button style=\"margin-top: 8px;\" color=\"light\" size=\"small\" (click)=\"changeFlashMode(off)\">Off</ion-button>\r\n              </ion-row>\r\n            </ion-row>\r\n          </ion-col>\r\n        </ion-row>\r\n        <ion-col size=\"12\" class=\"actionareacol translucent-background\">\r\n          <ion-row class=\"childbuttons ion-justify-content-center mainbuttonscontainer\">\r\n            <div #submenuscroll class=\"scroll\" scrollX=\"true\">\r\n              <ng-container *ngFor=\"let button of mainmenuitems[selectedmainmenuindex].children; let i = index\">\r\n              <ion-button *ngIf=\"button.isvisible\" id=\"submenu{{i}}\" fill=\"clear\"\r\n                [ngClass]=\"{'completed-inactive' : !button.ispending && !button.isactive, 'completed' : !button.ispending && button.isactive, 'active' : button.ispending && button.isactive, 'normal' : button.ispending && !button.isactive}\"\r\n                (click)=\"toggleSubMenuSelection(i)\">{{button.name}}</ion-button>\r\n              </ng-container>\r\n            </div>\r\n          </ion-row>\r\n          <ion-row class=\"ion-justify-content-center\">\r\n            <ion-button fill=\"clear\" (click)=\"takePicture()\" class=\"capturebutton\"></ion-button>\r\n            <ion-button\r\n              *ngIf=\"this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].capturedshots.length > 0\"\r\n              class=\"gallerybutton\" (click)=\"toggleGallerybar(false)\">\r\n              <img\r\n                [src]=\"this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].capturedshots[this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].capturedshots.length - 1].shotimage\" />\r\n            </ion-button>\r\n          </ion-row>\r\n          <ion-row class=\"mainbuttons ion-justify-content-center mainbuttonscontainer\">\r\n            <div #mainscroll class=\"scroll\" scrollX=\"true\">\r\n              <ng-container *ngFor=\"let button of mainmenuitems; let i = index\">\r\n              <ion-button id=\"mainmenu{{i}}\" fill=\"clear\" [ngClass]=\"[ button.isactive ? 'active' : 'normal']\"\r\n              *ngIf=\"button.isvisible\" (click)=\"toggleMainMenuSelection(i)\">{{button.name}}\r\n              </ion-button>\r\n            </ng-container>\r\n            </div>\r\n          </ion-row>\r\n          <ion-row>\r\n            <ion-col class=\"ion-padding\">\r\n              <ion-button style=\"margin-bottom: 24px;\" expand=\"full\" color=\"primary\" size=\"small\"\r\n              (click)=\"handleSurveyExit()\">Exit Survey</ion-button>\r\n            </ion-col>\r\n            <ion-col class=\"ion-padding\" *ngIf=\"ispendingitemsmode\">\r\n              <ion-button style=\"margin-bottom: 24px;\" expand=\"full\" color=\"danger\" size=\"small\"\r\n              (click)=\"handlePendingItemsSwitch()\">Pending Items</ion-button>\r\n            </ion-col>\r\n          </ion-row>\r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-row>\r\n  </ion-grid>\r\n\r\n  <!-- Sidebar for highlighting step process to follow -->\r\n  <ion-grid class=\"ion-no-padding\">\r\n    <ion-row *ngIf=\"issidemenucollapsed\">\r\n      <ion-button fill=\"clear\" class=\"infobutton\" (click)=\"toggleSidebar(false)\">i</ion-button>\r\n    </ion-row>\r\n    <ion-row *ngIf=\"!issidemenucollapsed\">\r\n      <ion-button class=\"infobutton\" fill=\"clear\" (click)=\"toggleSidebar(true)\">x</ion-button>\r\n    </ion-row>\r\n    <div *ngIf=\"!issidemenucollapsed && isdataloaded\" class=\"sidestepper\">\r\n      <div\r\n        *ngFor=\"let childshot of mainmenuitems[selectedmainmenuindex].children[selectedsubmenuindex].shots; let i = index\">\r\n        <ion-row>\r\n          <div class=\"stepper-index\">{{i + 1}}</div>\r\n          <p class=\"stepper-title\">Step</p>\r\n        </ion-row>\r\n        <ion-row>\r\n          <ion-col>\r\n            <ion-row class=\"stepper-list-row\">\r\n              <p [ngClass]=\"childshot.shotstatus ? 'stepper-text-active' : 'stepper-text-default'\">\r\n                {{childshot.shotinfo}}</p>\r\n            </ion-row>\r\n            <ion-row class=\"stepper-list-row\">\r\n              <p [ngClass]=\"childshot.questionstatus ? 'stepper-text-active' : 'stepper-text-default'\">\r\n                {{childshot.questioninfo}}</p>\r\n            </ion-row>\r\n          </ion-col>\r\n        </ion-row>\r\n      </div>\r\n    </div>\r\n  </ion-grid>\r\n\r\n  <!-- Sidebar for showing gallery view -->\r\n  <ion-grid class=\"ion-no-padding\">\r\n    <ion-row *ngIf=\"!isgallerymenucollapsed\">\r\n      <ion-button class=\"galleryclosebutton\" fill=\"clear\" (click)=\"toggleGallerybar(true)\">x</ion-button>\r\n    </ion-row>\r\n    <ion-row class=\"gallerysidebar galleryscrollcontainer\" *ngIf=\"isdataloaded && !isgallerymenucollapsed\">\r\n      <div class=\"scroll\" scrollY=\"true\">\r\n        <ion-button color=\"dark\" class=\"cameraimagesbutton\"\r\n          *ngFor=\"let shot of this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].capturedshots; let i = index\"\r\n          (click)=\"handleGalleryViewSwitch(shot)\">\r\n          <img [src]=\"shot.shotimage\" />\r\n        </ion-button>\r\n      </div>\r\n    </ion-row>\r\n  </ion-grid>\r\n\r\n  <!-- CHECK EXISTENCE VIEW -->\r\n  <ion-grid class=\"checkexistenceview\"\r\n    *ngIf=\"isdataloaded && this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].checkexistence && !this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].isexistencechecked\">\r\n    <!-- Row for choice questions -->\r\n    <ion-row class=\"checkexistenceview-row ion-padding-horizontal\">\r\n      <ion-col size=\"12\">\r\n        <p>\r\n          Is {{this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].name}} present?\r\n        </p>\r\n        <ion-row class=\"ion-float-right\">\r\n          <ion-button fill=\"clear\" size=\"small\" (click)=\"handleExistence(true)\">Yes</ion-button>\r\n          <ion-button fill=\"clear\" size=\"small\" (click)=\"handleExistence(false)\">No</ion-button>\r\n        </ion-row>\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n\r\n  <!-- QUESTIONARE VIEW -->\r\n  <ion-grid class=\"questionaireview\"\r\n    *ngIf=\"isdataloaded && this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[this.selectedshotindex].promptquestion\">\r\n\r\n    <!-- Row for choice questions -->\r\n    <ion-row class=\"questionaireview-row ion-padding-horizontal\"\r\n      *ngIf=\"this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[this.selectedshotindex].questiontype === QuestionTypes.OPTIONS\">\r\n      <ion-col size=\"12\">\r\n        <p>\r\n          {{this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[this.selectedshotindex].question}}\r\n        </p>\r\n        <ion-row class=\"ion-float-right\">\r\n          <ion-button fill=\"clear\" size=\"small\"\r\n            *ngFor=\"let action of this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[this.selectedshotindex].actions\"\r\n            (click)=\"handleAnswerSubmission(action)\">{{action | titlecase}}</ion-button>\r\n        </ion-row>\r\n      </ion-col>\r\n    </ion-row>\r\n\r\n    <!-- Row for input number questions -->\r\n    <ion-row class=\"questionaireview-row ion-padding-horizontal\"\r\n      *ngIf=\"this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[this.selectedshotindex].questiontype === QuestionTypes.INPUT_NUMBER\">\r\n      <ion-col size=\"12\">\r\n        <p>\r\n          {{this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[this.selectedshotindex].question}}\r\n        </p>\r\n        <form [formGroup]=\"activeForm\" novalidate>\r\n          <ion-input type=\"number\" class=\"form-control\" autocomplete=\"off\"\r\n            formControlName=\"{{this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[this.selectedshotindex].inputformcontrol}}\">\r\n          </ion-input>\r\n          <div class=\"error_div\">\r\n            <div\r\n              *ngIf=\"activeForm.get(this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[this.selectedshotindex].inputformcontrol).value === '' && activeForm.get(this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[this.selectedshotindex].inputformcontrol).dirty\">\r\n              <span class=\"error\">Field input is required.</span>\r\n            </div>\r\n          </div>\r\n        </form>\r\n        <ion-row class=\"ion-float-right\">\r\n          <ion-button fill=\"clear\" size=\"small\" (click)=\"handleInputSubmission(activeForm)\">\r\n            {{this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[this.selectedshotindex].actions[0] | titlecase}}\r\n          </ion-button>\r\n        </ion-row>\r\n      </ion-col>\r\n    </ion-row>\r\n\r\n    <!-- Row for input text questions -->\r\n    <ion-row class=\"questionaireview-row ion-padding-horizontal\"\r\n      *ngIf=\"this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[this.selectedshotindex].questiontype === QuestionTypes.INPUT_TEXT\">\r\n      <ion-col size=\"12\">\r\n        <p>\r\n          {{this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[this.selectedshotindex].question}}\r\n        </p>\r\n        <form [formGroup]=\"activeForm\" novalidate>\r\n          <ion-input class=\"form-control\" autocomplete=\"off\"\r\n            formControlName=\"{{this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[this.selectedshotindex].inputformcontrol}}\">\r\n          </ion-input>\r\n          <div class=\"error_div\">\r\n            <div\r\n              *ngIf=\"activeForm.get(this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[this.selectedshotindex].inputformcontrol).value === '' && activeForm.get(this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[this.selectedshotindex].inputformcontrol).dirty\">\r\n              <span class=\"error\">Field input is required.</span>\r\n            </div>\r\n          </div>\r\n        </form>\r\n        <ion-row class=\"ion-float-right\">\r\n          <ion-button fill=\"clear\" size=\"small\" (click)=\"handleInputTextSubmission(activeForm)\">\r\n            {{this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[this.selectedshotindex].actions[0] | titlecase}}\r\n          </ion-button>\r\n        </ion-row>\r\n      </ion-col>\r\n    </ion-row>\r\n\r\n    <!-- Row for question type 5 -->\r\n    <ion-row class=\"questionaireview-row ion-padding-horizontal\"\r\n      *ngIf=\"this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[this.selectedshotindex].questiontype === QuestionTypes.INPUT_SHOT_NAME\">\r\n      <ion-col size=\"12\">\r\n        <p>\r\n          {{this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[this.selectedshotindex].question}}\r\n        </p>\r\n        <form [formGroup]=\"activeForm\" novalidate>\r\n          <ion-input type=\"text\" class=\"form-control\" autocomplete=\"off\"\r\n            formControlName=\"shotname\">\r\n          </ion-input>\r\n          <div class=\"error_div\">\r\n            <div\r\n            *ngIf=\"activeForm.get('shotname').value === '' && activeForm.get('shotname').dirty\">\r\n              <span class=\"error\">Field input is required.</span>\r\n            </div>\r\n          </div>\r\n        </form>\r\n        <ion-row class=\"ion-float-right\">\r\n          <ion-button fill=\"clear\" size=\"small\" (click)=\"handleShotNameSubmission(activeForm)\">\r\n            {{this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[this.selectedshotindex].actions[0] | titlecase}}\r\n          </ion-button>\r\n        </ion-row>\r\n      </ion-col>\r\n    </ion-row>\r\n\r\n    <!-- Row for utilities questions -->\r\n    <ion-row class=\"questionaireview-row ion-padding-horizontal\"\r\n      *ngIf=\"this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[this.selectedshotindex].questiontype === QuestionTypes.INPUT_UTILITIES_AUTOCOMPLETE\">\r\n      <ion-col size=\"12\">\r\n        <p>\r\n          {{this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[this.selectedshotindex].question}}\r\n        </p>\r\n        <form [formGroup]=\"activeForm\" novalidate>\r\n          <app-auto-complete [dataList]=\"utilities\" class=\"form-control\" mode=\"object\"\r\n            formControlName=\"{{this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[this.selectedshotindex].inputformcontrol}}\"\r\n            #make>\r\n          </app-auto-complete>\r\n          <div class=\"error_div\">\r\n            <div\r\n              *ngIf=\"activeForm.get(this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[this.selectedshotindex].inputformcontrol).value === '' && activeForm.get(this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[this.selectedshotindex].inputformcontrol).dirty\">\r\n              <span class=\"error\">Field input is required.</span>\r\n            </div>\r\n          </div>\r\n        </form>\r\n        <ion-row class=\"ion-float-right\">\r\n          <ion-button fill=\"clear\" size=\"small\" (click)=\"handleUtilitySubmission()\">\r\n            {{this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[this.selectedshotindex].actions[0] | titlecase}}\r\n          </ion-button>\r\n        </ion-row>\r\n      </ion-col>\r\n    </ion-row>\r\n\r\n    <!-- Row for roof materials questions -->\r\n    <ion-row class=\"questionaireview-row ion-padding-horizontal\"\r\n      *ngIf=\"this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[this.selectedshotindex].questiontype === QuestionTypes.INPUT_ROOF_MATERIAL_AUTOCOMPLETE\">\r\n      <ion-col size=\"12\">\r\n        <p>\r\n          {{this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[this.selectedshotindex].question}}\r\n        </p>\r\n        <form [formGroup]=\"activeForm\" novalidate>\r\n          <app-auto-complete [dataList]=\"roofmaterials\" class=\"form-control\" mode=\"object\"\r\n            formControlName=\"{{this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[this.selectedshotindex].inputformcontrol}}\"\r\n            #make>\r\n          </app-auto-complete>\r\n          <div class=\"error_div\">\r\n            <div\r\n              *ngIf=\"activeForm.get(this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[this.selectedshotindex].inputformcontrol).value === '' && activeForm.get(this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[this.selectedshotindex].inputformcontrol).dirty\">\r\n              <span class=\"error\">Field input is required.</span>\r\n            </div>\r\n          </div>\r\n        </form>\r\n        <ion-row class=\"ion-float-right\">\r\n          <ion-button fill=\"clear\" size=\"small\" (click)=\"handleRoofMaterialSubmission()\">\r\n            {{this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[this.selectedshotindex].actions[0] | titlecase}}\r\n          </ion-button>\r\n        </ion-row>\r\n      </ion-col>\r\n    </ion-row>\r\n\r\n    <!-- Row for inverter make and model questions -->\r\n    <ion-row class=\"questionaireview-row ion-padding-horizontal\"\r\n      *ngIf=\"this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[this.selectedshotindex].questiontype === QuestionTypes.INPUT_INVERTER_AUTOCOMPLETE\">\r\n      <ion-col size=\"12\">\r\n        <p>\r\n          {{this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[this.selectedshotindex].question}}\r\n        </p>\r\n        <form [formGroup]=\"activeForm\" novalidate>\r\n          <app-auto-complete placeholder=\"inverter make*\" [dataList]=\"invertermakes\" class=\"form-control\" mode=\"object\"\r\n            formControlName=\"invertermake\" #invertermake>\r\n          </app-auto-complete>\r\n          <div class=\"error_div\">\r\n            <div *ngIf=\"activeForm.get('invertermake').value === '' && activeForm.get('invertermake').dirty\">\r\n              <span class=\"error\">Field input is required.</span>\r\n            </div>\r\n          </div>\r\n          <app-auto-complete placeholder=\"inverter model*\" [dataList]=\"invertermodels\" class=\"form-control\"\r\n            mode=\"object\" formControlName=\"invertermodel\" #invertermodel>\r\n          </app-auto-complete>\r\n          <div class=\"error_div\">\r\n            <div *ngIf=\"activeForm.get('invertermodel').value === '' && activeForm.get('invertermodel').dirty\">\r\n              <span class=\"error\">Field input is required.</span>\r\n            </div>\r\n          </div>\r\n        </form>\r\n        <ion-row class=\"ion-float-right\">\r\n          <ion-button fill=\"clear\" size=\"small\" (click)=\"handleInverterFieldsSubmission()\">\r\n            {{this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[this.selectedshotindex].actions[0] | titlecase}}\r\n          </ion-button>\r\n        </ion-row>\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n</ion-content>\r\n\r\n<ion-content *ngIf=\"isdataloaded && this.mainmenuitems[this.selectedmainmenuindex].viewmode == ViewModes.FORM\" [forceOverscroll]=\"false\">\r\n  <form [formGroup]=\"activeForm\" class=\"white-bg\" *ngIf=\"surveytype === 'battery'\">\r\n    <p class=\"formheader\">Additional Information</p>\r\n    <ion-grid class=\"ion-padding\">\r\n      <ion-row>\r\n        <ion-col>\r\n          <ion-label position=\"fixed\">Utility*</ion-label>\r\n          <app-auto-complete [dataList]=\"utilities\" mode=\"object\" formControlName=\"utility\" #utility></app-auto-complete>\r\n        </ion-col>\r\n      </ion-row>\r\n      <ion-row>\r\n        <ion-col>\r\n          <ion-label position=\"fixed\">Module make*</ion-label>\r\n          <app-auto-complete [dataList]=\"solarmakes\" mode=\"object\" formControlName=\"modulemake\"></app-auto-complete>\r\n        </ion-col>\r\n      </ion-row>\r\n      <ion-row>\r\n        <ion-col>\r\n          <ion-label position=\"fixed\">Module model*</ion-label>\r\n          <app-auto-complete [dataList]=\"solarmodels\" mode=\"object\" formControlName=\"modulemodel\"></app-auto-complete>\r\n        </ion-col>\r\n      </ion-row>\r\n      <ion-row>\r\n        <ion-col>\r\n          <ion-label position=\"fixed\">Battery backup*</ion-label>\r\n          <ion-radio-group formControlName=\"batterybackup\">\r\n            <ion-item>\r\n              <ion-label>Partial</ion-label>\r\n              <ion-radio slot=\"start\" value=\"partial\"></ion-radio>\r\n            </ion-item>\r\n            <ion-item>\r\n              <ion-label>Whole</ion-label>\r\n              <ion-radio slot=\"start\" value=\"whole\"></ion-radio>\r\n            </ion-item>\r\n          </ion-radio-group>\r\n        </ion-col>\r\n      </ion-row>\r\n      <ion-row>\r\n        <ion-col>\r\n          <ion-label position=\"fixed\">Interconnection*</ion-label>\r\n          <ion-radio-group formControlName=\"interconnection\">\r\n            <ion-item>\r\n              <ion-label>Backfed</ion-label>\r\n              <ion-radio slot=\"start\" value=\"backfed\"></ion-radio>\r\n            </ion-item>\r\n            <ion-item>\r\n              <ion-label>Dreate main breaker</ion-label>\r\n              <ion-radio slot=\"start\" value=\"dreatemainbreaker\"></ion-radio>\r\n            </ion-item>\r\n            <ion-item>\r\n              <ion-label>SST with CT</ion-label>\r\n              <ion-radio slot=\"start\" value=\"sstwithct\"></ion-radio>\r\n            </ion-item>\r\n            <ion-item>\r\n              <ion-label>Load Side Tap</ion-label>\r\n              <ion-radio slot=\"start\" value=\"loadsidetap\"></ion-radio>\r\n            </ion-item>\r\n            <ion-item>\r\n              <ion-label>SST with location of SST</ion-label>\r\n              <ion-radio slot=\"start\" value=\"sstwithlocationofsst\"></ion-radio>\r\n            </ion-item>\r\n          </ion-radio-group>\r\n        </ion-col>\r\n      </ion-row>\r\n      <ion-row>\r\n        <ion-col>\r\n          <ion-label position=\"fixed\">Service feed source*</ion-label>\r\n          <ion-radio-group formControlName=\"servicefeedsource\">\r\n            <ion-item>\r\n              <ion-label>Overhead</ion-label>\r\n              <ion-radio slot=\"start\" value=\"overhead\"></ion-radio>\r\n            </ion-item>\r\n            <ion-item>\r\n              <ion-label>Underground</ion-label>\r\n              <ion-radio slot=\"start\" value=\"underground\"></ion-radio>\r\n            </ion-item>\r\n          </ion-radio-group>\r\n        </ion-col>\r\n      </ion-row>\r\n      <ion-row>\r\n        <ion-col>\r\n          <ion-label position=\"fixed\">Additional notes</ion-label>\r\n          <ion-textarea class=\"ion-no-margin ion-no-padding comment_box\" rows=\"3\" formControlName=\"additionalnotes\">\r\n          </ion-textarea>\r\n        </ion-col>\r\n      </ion-row>\r\n      <ion-row>\r\n        <ion-col><ion-button class=\"action-button-color\" fill=\"clear\" (click)=\"handleFormBack()\">Back</ion-button></ion-col>\r\n        <ion-col size=\"auto\">\r\n          <ion-button class=\"action-button-color\" fill=\"clear\" (click)=\"handleCompleteSurveyDataSubmission()\">Submit\r\n            Survey</ion-button>\r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-grid>\r\n  </form>\r\n  <form [formGroup]=\"activeForm\" class=\"white-bg\" *ngIf=\"surveytype === 'pv'\">\r\n    <p class=\"formheader\">Additional Information</p>\r\n    <ion-grid class=\"ion-padding\">\r\n      <ion-row>\r\n        <ion-col>\r\n          <ion-label position=\"fixed\">Type of Roof Material*</ion-label>\r\n          <app-auto-complete [dataList]=\"roofmaterials\" mode=\"object\" formControlName=\"roofmaterial\" #roofmaterial></app-auto-complete>\r\n        </ion-col>\r\n      </ion-row>\r\n      <ion-row>\r\n        <ion-col>\r\n          <ion-label position=\"fixed\">Service feed source*</ion-label>\r\n          <ion-radio-group formControlName=\"servicefeedsource\">\r\n            <ion-item>\r\n              <ion-label>Overhead</ion-label>\r\n              <ion-radio slot=\"start\" value=\"overhead\"></ion-radio>\r\n            </ion-item>\r\n            <ion-item>\r\n              <ion-label>Underground</ion-label>\r\n              <ion-radio slot=\"start\" value=\"underground\"></ion-radio>\r\n            </ion-item>\r\n          </ion-radio-group>\r\n        </ion-col>\r\n      </ion-row>\r\n      <ion-row>\r\n        <ion-col>\r\n          <ion-label position=\"fixed\">Any Existing Solar System*</ion-label>\r\n          <ion-radio-group formControlName=\"existingsolarsystem\">\r\n            <ion-item>\r\n              <ion-label>Yes</ion-label>\r\n              <ion-radio slot=\"start\" value=\"true\"></ion-radio>\r\n            </ion-item>\r\n            <ion-item>\r\n              <ion-label>No</ion-label>\r\n              <ion-radio slot=\"start\" value=\"false\"></ion-radio>\r\n            </ion-item>\r\n          </ion-radio-group>\r\n        </ion-col>\r\n      </ion-row>\r\n      <ion-row *ngIf=\"existingsolarsystem\">\r\n        <ion-col>\r\n          <ion-label position=\"fixed\">Details Of Existing System</ion-label>\r\n          <ion-textarea class=\"ion-no-margin ion-no-padding comment_box\" rows=\"3\" formControlName=\"detailsofexisitingsystem\">\r\n          </ion-textarea>\r\n        </ion-col>\r\n      </ion-row>\r\n      <ion-row>\r\n        <ion-col>\r\n          <ion-label position=\"fixed\">Is It Newly Constructed?*</ion-label>\r\n          <ion-radio-group formControlName=\"newconstruction\">\r\n            <ion-item>\r\n              <ion-label>Yes</ion-label>\r\n              <ion-radio slot=\"start\" value=\"true\"></ion-radio>\r\n            </ion-item>\r\n            <ion-item>\r\n              <ion-label>No</ion-label>\r\n              <ion-radio slot=\"start\" value=\"false\"></ion-radio>\r\n            </ion-item>\r\n          </ion-radio-group>\r\n        </ion-col>\r\n      </ion-row>\r\n      <ion-row *ngIf='newconstruction'>\r\n        \r\n      </ion-row>\r\n      <ion-row>\r\n        <ion-col>\r\n          <ion-label position=\"fixed\">Additional notes</ion-label>\r\n          <ion-textarea class=\"ion-no-margin ion-no-padding comment_box\" rows=\"3\" formControlName=\"additionalnotes\">\r\n          </ion-textarea>\r\n        </ion-col>\r\n      </ion-row>\r\n      <ion-row>\r\n        <ion-col><ion-button class=\"action-button-color\" fill=\"clear\" (click)=\"handleFormBack()\">Back</ion-button></ion-col>\r\n        <ion-col size=\"auto\">\r\n          <ion-button class=\"action-button-color\" fill=\"clear\" (click)=\"handleCompleteSurveyDataSubmission()\">Submit\r\n            Survey</ion-button>\r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-grid>\r\n  </form>\r\n  <form [formGroup]=\"activeForm\" class=\"white-bg\" *ngIf=\"surveytype === 'pvbattery'\">\r\n    <p class=\"formheader\">Additional Information</p>\r\n    <ion-grid class=\"ion-padding\">\r\n      <ion-row>\r\n        <ion-col>\r\n          <ion-label position=\"fixed\">Utility*</ion-label>\r\n          <app-auto-complete [dataList]=\"utilities\" mode=\"object\" formControlName=\"utility\" #utility></app-auto-complete>\r\n        </ion-col>\r\n      </ion-row>\r\n      <ion-row>\r\n        <ion-col>\r\n          <ion-label position=\"fixed\">Battery backup*</ion-label>\r\n          <ion-radio-group formControlName=\"batterybackup\">\r\n            <ion-item>\r\n              <ion-label>Partial</ion-label>\r\n              <ion-radio slot=\"start\" value=\"partial\"></ion-radio>\r\n            </ion-item>\r\n            <ion-item>\r\n              <ion-label>Whole</ion-label>\r\n              <ion-radio slot=\"start\" value=\"whole\"></ion-radio>\r\n            </ion-item>\r\n          </ion-radio-group>\r\n        </ion-col>\r\n      </ion-row>\r\n      <ion-row>\r\n        <ion-col>\r\n          <ion-label position=\"fixed\">Interconnection*</ion-label>\r\n          <ion-radio-group formControlName=\"interconnection\">\r\n            <ion-item>\r\n              <ion-label>Backfed</ion-label>\r\n              <ion-radio slot=\"start\" value=\"backfed\"></ion-radio>\r\n            </ion-item>\r\n            <ion-item>\r\n              <ion-label>Dreate main breaker</ion-label>\r\n              <ion-radio slot=\"start\" value=\"dreatemainbreaker\"></ion-radio>\r\n            </ion-item>\r\n            <ion-item>\r\n              <ion-label>SST with CT</ion-label>\r\n              <ion-radio slot=\"start\" value=\"sstwithct\"></ion-radio>\r\n            </ion-item>\r\n            <ion-item>\r\n              <ion-label>Load Side Tap</ion-label>\r\n              <ion-radio slot=\"start\" value=\"loadsidetap\"></ion-radio>\r\n            </ion-item>\r\n            <ion-item>\r\n              <ion-label>SST with location of SST</ion-label>\r\n              <ion-radio slot=\"start\" value=\"sstwithlocationofsst\"></ion-radio>\r\n            </ion-item>\r\n          </ion-radio-group>\r\n        </ion-col>\r\n      </ion-row>\r\n      <ion-row>\r\n        <ion-col>\r\n          <ion-label position=\"fixed\">Service feed source*</ion-label>\r\n          <ion-radio-group formControlName=\"servicefeedsource\">\r\n            <ion-item>\r\n              <ion-label>Overhead</ion-label>\r\n              <ion-radio slot=\"start\" value=\"overhead\"></ion-radio>\r\n            </ion-item>\r\n            <ion-item>\r\n              <ion-label>Underground</ion-label>\r\n              <ion-radio slot=\"start\" value=\"underground\"></ion-radio>\r\n            </ion-item>\r\n          </ion-radio-group>\r\n        </ion-col>\r\n      </ion-row>\r\n      <ion-row>\r\n        <ion-col>\r\n          <ion-label position=\"fixed\">Additional notes</ion-label>\r\n          <ion-textarea class=\"ion-no-margin ion-no-padding comment_box\" rows=\"3\" formControlName=\"additionalnotes\">\r\n          </ion-textarea>\r\n        </ion-col>\r\n      </ion-row>\r\n      <ion-row>\r\n        <ion-col><ion-button class=\"action-button-color\" fill=\"clear\" (click)=\"handleFormBack()\">Back</ion-button></ion-col>\r\n        <ion-col size=\"auto\">\r\n          <ion-button class=\"action-button-color\" fill=\"clear\" (click)=\"handleCompleteSurveyDataSubmission()\">Submit\r\n            Survey</ion-button>\r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-grid>\r\n  </form>\r\n</ion-content>\r\n\r\n<ion-content *ngIf=\"isdataloaded && this.mainmenuitems[this.selectedmainmenuindex].viewmode == ViewModes.MAP\" [forceOverscroll]=\"false\">\r\n  <ion-grid class=\"ion-no-padding\" #screen id=\"canvasarea\">\r\n    <ion-row>\r\n      <ion-button fill=\"clear\" class=\"backbutton z-top\" (click)=\"handleEquipmentMarkingBack()\"><ion-icon slot=\"icon-only\" name=\"chevron-back-outline\"></ion-icon></ion-button>\r\n      <ion-button fill=\"clear\" class=\"savebutton z-top\" (click)=\"handleEquipmentMarkingSave()\"><ion-icon slot=\"icon-only\" name=\"save-outline\"></ion-icon></ion-button>\r\n    </ion-row>\r\n    <ion-row class=\"locationmarkingboundary ion-justify-content-center ion-align-items-center\">\r\n      <pinch-zoom [limit-zoom]=\"6\">\r\n        <img class=\"siteimage\" src=\"{{sitelocationimage}}\" style=\"height: 100vh;\"/>\r\n    </pinch-zoom>\r\n    </ion-row>\r\n    <ion-row class=\"legendscontainer\">\r\n      <ion-col class=\"legend ion-text-center\" *ngFor=\"let item of equipments\">\r\n        <div class=\"dotcontainer\"\r\n          [ngStyle]=\"item.enabled ? {'background-color': item.color} : {'background-color': item.disabledcolor}\">\r\n          <span id=\"item.id\" class=\"dot\" [ngStyle]=\"{'background-color': item.color}\"\r\n            cdkDragBoundary=\".locationmarkingboundary\" cdkDrag (cdkDragEnded)=\"dragEnded($event, item)\">\r\n          </span>\r\n        </div>\r\n        <p [ngClass]=\"[ item.enabled ? 'legendtext' : 'disabledlegendtext']\">{{item.name}}</p>\r\n        <ion-button fill=\"clear\" size=\"small\" class=\"undobutton\" [ngClass]=\"[ item.enabled ? 'hidden' : 'unhidden']\"\r\n          (click)=\"reverttoOriginalPosition(item)\">\r\n          <img class=\"undoimage\" src=\"../../assets/images/undoarrow.svg\" />\r\n        </ion-button>\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n</ion-content>\r\n\r\n<ion-content *ngIf=\"isdataloaded && this.mainmenuitems[this.selectedmainmenuindex].viewmode == ViewModes.GALLERY\" [forceOverscroll]=\"false\">\r\n  <ion-slides #slides pager=\"true\" [options]=\"slideOpts\" (ionSlidesDidLoad)=\"this.slideDidChange();\" (ionSlideDidChange)=\"this.slideDidChange();\">\r\n    <ion-slide *ngFor=\"let shot of this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].capturedshots; let i = index\">\r\n      <img class=\"slideimage\" [src]=\"shot.shotimage\" />\r\n    </ion-slide>\r\n  </ion-slides>\r\n  <ion-button fill=\"clear\" class=\"backbutton z-top\" (click)=\"handleGalleryBack()\"><ion-icon slot=\"icon-only\" name=\"chevron-back-outline\"></ion-icon></ion-button>\r\n  <ion-button fill=\"clear\" class=\"savebutton z-top\" (click)=\"handleShotDelete()\"><ion-icon slot=\"icon-only\" name=\"trash-outline\"></ion-icon></ion-button>\r\n</ion-content>\r\n\r\n<ion-content *ngIf=\"isdataloaded && viewpendingitems\" [forceOverscroll]=\"false\" class=\"white-bg\">\r\n  <ion-grid class=\"ion-padding\">\r\n    <ion-row>\r\n      <ion-col size=\"2\">\r\n        <ion-button fill=\"clear\" class=\"solidbackbutton\" (click)=\"handlePendingItemsBack()\"><ion-icon slot=\"icon-only\" name=\"chevron-back-outline\"></ion-icon></ion-button>\r\n      </ion-col>\r\n      <ion-col>\r\n        <p class=\"section-title\">PENDING DETAILS</p>\r\n      </ion-col>\r\n    </ion-row>\r\n    <ion-row class=\"fullwidth\" *ngFor=\"let mainmenu of pendingmenuitems; let mainindex = index\">\r\n      <p class=\"pending-menu-title\">{{mainmenu.name | titlecase}}</p>\r\n        <ion-row class=\"fullwidth\" *ngFor=\"let childmenu of mainmenu.pendingchilds; let childindex = index\">\r\n          <p class=\"pending-title\">{{childindex + 1}}. {{childmenu.name}}</p>\r\n            <ion-row class=\"fullwidth\" *ngFor=\"let shot of childmenu.pendingshots; let shotindex = index\">\r\n              <ion-button fill=\"clear\" class=\"pending-text\" (click)=\"handlePendingShotClick(mainmenu.index, childmenu.index, shot.index)\">{{shot.name}}</ion-button>\r\n            </ion-row>\r\n        </ion-row>\r\n    </ion-row>\r\n</ion-grid>\r\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/model/survey-storage.model.ts":
  /*!***********************************************!*\
    !*** ./src/app/model/survey-storage.model.ts ***!
    \***********************************************/

  /*! exports provided: SurveyStorageModel */

  /***/
  function srcAppModelSurveyStorageModelTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SurveyStorageModel", function () {
      return SurveyStorageModel;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");

    var SurveyStorageModel = function SurveyStorageModel() {
      _classCallCheck(this, SurveyStorageModel);
    };
    /***/

  },

  /***/
  "./src/app/surveyprocess/surveyprocess-routing.module.ts":
  /*!***************************************************************!*\
    !*** ./src/app/surveyprocess/surveyprocess-routing.module.ts ***!
    \***************************************************************/

  /*! exports provided: SurveyprocessPageRoutingModule */

  /***/
  function srcAppSurveyprocessSurveyprocessRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SurveyprocessPageRoutingModule", function () {
      return SurveyprocessPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _surveyprocess_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./surveyprocess.page */
    "./src/app/surveyprocess/surveyprocess.page.ts");

    var routes = [{
      path: '',
      component: _surveyprocess_page__WEBPACK_IMPORTED_MODULE_3__["SurveyprocessPage"]
    }];

    var SurveyprocessPageRoutingModule = function SurveyprocessPageRoutingModule() {
      _classCallCheck(this, SurveyprocessPageRoutingModule);
    };

    SurveyprocessPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], SurveyprocessPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/surveyprocess/surveyprocess.module.ts":
  /*!*******************************************************!*\
    !*** ./src/app/surveyprocess/surveyprocess.module.ts ***!
    \*******************************************************/

  /*! exports provided: SurveyprocessPageModule */

  /***/
  function srcAppSurveyprocessSurveyprocessModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SurveyprocessPageModule", function () {
      return SurveyprocessPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _surveyprocess_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./surveyprocess-routing.module */
    "./src/app/surveyprocess/surveyprocess-routing.module.ts");
    /* harmony import */


    var _surveyprocess_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./surveyprocess.page */
    "./src/app/surveyprocess/surveyprocess.page.ts");
    /* harmony import */


    var _ionic_native_camera_preview_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! @ionic-native/camera-preview/ngx */
    "./node_modules/@ionic-native/camera-preview/ngx/index.js");
    /* harmony import */


    var _ionic_native_diagnostic_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! @ionic-native/diagnostic/ngx */
    "./node_modules/@ionic-native/diagnostic/ngx/index.js");
    /* harmony import */


    var _utilities_utilities_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! ../utilities/utilities.module */
    "./src/app/utilities/utilities.module.ts");
    /* harmony import */


    var _angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
    /*! @angular/cdk/drag-drop */
    "./node_modules/@angular/cdk/esm2015/drag-drop.js");
    /* harmony import */


    var _ionic_native_insomnia_ngx__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
    /*! @ionic-native/insomnia/ngx */
    "./node_modules/@ionic-native/insomnia/ngx/index.js");
    /* harmony import */


    var ngx_pinch_zoom__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
    /*! ngx-pinch-zoom */
    "./node_modules/ngx-pinch-zoom/fesm2015/ngx-pinch-zoom.js");

    var SurveyprocessPageModule = function SurveyprocessPageModule() {
      _classCallCheck(this, SurveyprocessPageModule);
    };

    SurveyprocessPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _utilities_utilities_module__WEBPACK_IMPORTED_MODULE_9__["UtilitiesModule"], _angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_10__["DragDropModule"], _surveyprocess_routing_module__WEBPACK_IMPORTED_MODULE_5__["SurveyprocessPageRoutingModule"], ngx_pinch_zoom__WEBPACK_IMPORTED_MODULE_12__["PinchZoomModule"]],
      declarations: [_surveyprocess_page__WEBPACK_IMPORTED_MODULE_6__["SurveyprocessPage"]],
      providers: [_ionic_native_camera_preview_ngx__WEBPACK_IMPORTED_MODULE_7__["CameraPreview"], _ionic_native_diagnostic_ngx__WEBPACK_IMPORTED_MODULE_8__["Diagnostic"], _ionic_native_insomnia_ngx__WEBPACK_IMPORTED_MODULE_11__["Insomnia"]]
    })], SurveyprocessPageModule);
    /***/
  },

  /***/
  "./src/app/surveyprocess/surveyprocess.page.scss":
  /*!*******************************************************!*\
    !*** ./src/app/surveyprocess/surveyprocess.page.scss ***!
    \*******************************************************/

  /*! exports provided: default */

  /***/
  function srcAppSurveyprocessSurveyprocessPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "ion-content {\n  --ion-background-color: #ffffff;\n}\n\nhtml,\nbody {\n  background-color: transparent !important;\n}\n\nion-app {\n  --background: transparent !important;\n}\n\nion-content {\n  --background: transparent !important;\n}\n\napp-ar ion-content {\n  --background: transparent;\n}\n\n.translucent-background {\n  background-color: #000000aa;\n}\n\n.error {\n  color: #df3e3e;\n  font-size: 11px;\n  margin-left: 5px;\n}\n\n.defaultcameraoptions {\n  background-color: #000000;\n}\n\n.actionarea {\n  position: absolute;\n  bottom: 0em;\n  margin-left: 0px;\n  margin-right: 0px;\n}\n\n.actionareacol {\n  padding-left: 0px;\n  padding-right: 0px;\n}\n\n.actionarea .mainbuttons {\n  margin-left: 0px;\n  margin-right: 0px;\n}\n\n.actionarea .mainbuttons .active {\n  color: #ffffff;\n  font-size: 14px;\n  font-weight: 600;\n  padding: 0 4px;\n}\n\n.actionarea .mainbuttons .normal {\n  color: #ffffff;\n  font-size: 14px;\n  opacity: 0.5;\n  font-weight: 100;\n  padding: 0 4px;\n}\n\n.actionarea .childbuttons .active {\n  color: #ffffff;\n  font-size: 14px;\n  font-weight: 600;\n  padding: 0 4px;\n}\n\n.actionarea .childbuttons .completed {\n  color: #6ab04c;\n  font-size: 14px;\n  font-weight: 600;\n  padding: 0 4px;\n}\n\n.actionarea .childbuttons .completed-inactive {\n  color: #6ab04c;\n  opacity: 0.7;\n  font-size: 14px;\n  font-weight: 100;\n  padding: 0 4px;\n}\n\n.actionarea .childbuttons .normal {\n  color: #ffffff;\n  font-size: 14px;\n  opacity: 0.5;\n  font-weight: 100;\n  padding: 0 4px;\n}\n\n.actionarea .gallerybutton {\n  width: 70px;\n  height: 70px;\n  position: absolute;\n  right: 50px;\n  padding: 0px;\n  box-shadow: none;\n  border: 2px solid #ffffff;\n  border-radius: 10px;\n}\n\n.actionarea .gallerybutton img {\n  width: 70px;\n  max-width: 70px;\n}\n\n.mainbuttonscontainer {\n  width: 100vw;\n  overflow: hidden;\n  white-space: nowrap;\n}\n\n.mainbuttonscontainer ::-webkit-scrollbar {\n  display: none;\n}\n\n.mainbuttonscontainer .scroll {\n  overflow: auto;\n}\n\n.actionarea .capturebutton {\n  background-color: #ffffffaa;\n  width: 70px;\n  height: 70px;\n  border-radius: 50%;\n  min-width: 0px;\n  border: 4px solid #ffffff;\n  margin: 4px 0px 4px 0px;\n}\n\n.actionarea .zoombutton {\n  width: 36px;\n  height: 36px;\n  border-radius: 50%;\n  min-width: 0px;\n  border: 1px solid #ffffff;\n  font-size: 0.7em;\n  font-weight: 600;\n  color: #ffffff;\n}\n\n.actionarea .circularbutton {\n  width: 36px;\n  height: 36px;\n  border: 1px solid #ffffff;\n  border-radius: 50%;\n  color: #ffffff;\n  margin-top: 4px;\n  margin-left: 4px;\n}\n\n.actionarea .circularbutton img {\n  width: 56%;\n  margin-left: 7px;\n  margin-top: 7px;\n}\n\n.actionarea .flashbutton {\n  width: 36px;\n  height: 36px;\n  border: 1px solid #ffffff;\n  border-radius: 50%;\n  color: #ffffff;\n  margin-top: 4px;\n  margin-left: 4px;\n}\n\n.actionarea .flashbutton ion-icon {\n  margin-left: 8px;\n  margin-top: 8px;\n}\n\n.sidestepper {\n  background-color: #ffffffe7;\n  position: fixed;\n  top: 71px;\n  right: 16px;\n  width: 200px;\n  border-radius: 14px;\n  padding: 8px;\n}\n\n.stepper-index {\n  width: 24px;\n  height: 24px;\n  background-color: #3880ff;\n  border-radius: 50%;\n  text-align: center;\n  padding-top: 4px;\n  color: #ffffff;\n  font-size: 12px;\n  margin: 12px;\n  font-weight: 600;\n  margin-bottom: 0px;\n}\n\n.stepper-title {\n  font-size: 14px;\n  font-weight: 600;\n  color: #000000;\n  padding-top: 1px;\n  margin-bottom: 8px;\n}\n\n.sidestepper .stepper-list-row {\n  margin-left: 15px;\n  margin-top: 6px;\n}\n\n.sidestepper .stepper-text-active {\n  font-size: 12px;\n  font-weight: 600;\n  margin-bottom: 0px;\n  margin-top: 2px;\n  margin-left: 6px;\n  color: #4f8339;\n}\n\n.sidestepper .stepper-text-default {\n  font-size: 12px;\n  margin-bottom: 0px;\n  margin-top: 2px;\n  margin-left: 6px;\n  color: #272727;\n}\n\n.infobutton {\n  position: absolute;\n  right: 16px;\n  top: 26px;\n  background-color: #ffffffd7;\n  width: 36px;\n  height: 36px;\n  border-radius: 50%;\n  color: #282829;\n  font-weight: 600;\n  border: 2px solid #ffffff;\n}\n\n.gallerysidebar {\n  position: fixed;\n  top: 71px;\n  left: 16px;\n  width: 100px;\n  border-radius: 14px;\n  padding-top: 8px;\n}\n\n.galleryscrollcontainer {\n  height: 60vh;\n  overflow: hidden;\n  white-space: nowrap;\n}\n\n.galleryscrollcontainer ::-webkit-scrollbar {\n  display: none;\n}\n\n.galleryscrollcontainer .scroll {\n  overflow: auto;\n}\n\n.galleryclosebutton {\n  position: absolute;\n  left: 16px;\n  top: 26px;\n  background-color: #ffffffd7;\n  width: 36px;\n  height: 36px;\n  border-radius: 50%;\n  color: #282829;\n  font-weight: 600;\n  border: 2px solid #ffffff;\n}\n\n.gallerysidebar .cameraimagesbutton {\n  width: 70px;\n  height: 70px;\n  border: 2px solid #ffffff;\n  border-radius: 10px;\n  padding: 0px;\n  box-shadow: none;\n  display: block;\n}\n\n.gallerysidebar .cameraimagesbutton img {\n  width: 70px;\n  max-width: 70px;\n}\n\n.questionaireview {\n  width: 76vw;\n  position: relative;\n  top: 30vh;\n}\n\n.questionaireview-row {\n  background-color: #ffffff;\n  border-radius: 12px;\n}\n\n.questionaireview-row p {\n  font-size: 14px;\n}\n\n.shotinfo {\n  background-color: #6ab04c8a;\n  color: #ffffff;\n  font-size: 0.7em;\n  font-weight: 600;\n  padding: 4px 8px;\n  border-radius: 12px;\n  border: 1px solid #6ab04c;\n  margin-bottom: 0;\n}\n\n.checkexistenceview {\n  width: 76vw;\n  position: relative;\n  top: 30vh;\n}\n\n.checkexistenceview-row {\n  background-color: #ffffff;\n  border-radius: 12px;\n}\n\n.checkexistenceview-row p {\n  font-size: 14px;\n}\n\n.formheader {\n  background-color: #666666;\n  height: 36px;\n  color: #ffffff;\n  margin: 0px;\n  padding-top: 7px;\n  padding-left: 16px;\n  font-weight: 600;\n}\n\n.locationmarkingboundary .col {\n  padding-left: 0px;\n}\n\n.legend {\n  height: 52px;\n  background-color: #fff;\n  cursor: move;\n  transition: box-shadow 200ms cubic-bezier(0, 0, 0.2, 1);\n  box-shadow: 0 3px 1px -2px rgba(0, 0, 0, 0.2), 0 2px 2px 0 rgba(0, 0, 0, 0.14), 0 1px 5px 0 rgba(0, 0, 0, 0.12);\n}\n\n.legend .legendtext {\n  margin-bottom: 0;\n  margin-top: 0;\n  font-size: 0.8em;\n  color: #000000;\n  font-weight: 600;\n  text-align: center;\n}\n\n.disabledlegend {\n  height: 52px;\n  background-color: #fff;\n  cursor: move;\n  transition: box-shadow 200ms cubic-bezier(0, 0, 0.2, 1);\n  box-shadow: 0 3px 1px -2px rgba(0, 0, 0, 0.2), 0 2px 2px 0 rgba(0, 0, 0, 0.14), 0 1px 5px 0 rgba(0, 0, 0, 0.12);\n}\n\n.disabledlegendtext {\n  margin-bottom: 0;\n  margin-top: 0;\n  font-size: 0.8em;\n  color: #999999;\n  font-weight: 600;\n  text-align: center;\n}\n\n.undobutton {\n  position: absolute;\n  top: -3px;\n  right: -6px;\n}\n\n.hidden {\n  display: none;\n}\n\n.unhidden {\n  display: block;\n}\n\n.undoimage {\n  width: 14px;\n}\n\n.dotcontainer {\n  height: 20px;\n  width: 20px;\n  margin-top: 4px;\n  background-color: #bbb;\n  border-radius: 4px;\n  display: inline-block;\n}\n\n.legendscontainer {\n  position: absolute;\n  bottom: 0;\n  left: 0;\n  width: 100%;\n}\n\n.dot {\n  height: 20px;\n  width: 20px;\n  background-color: #bbb;\n  border-radius: 4px;\n  display: inline-block;\n}\n\n.backbutton {\n  position: absolute;\n  top: 8px;\n  left: 8px;\n  width: 38px;\n  height: 38px;\n  color: #282829;\n  background-color: #ffffffd7;\n  font-size: 8px;\n  border: 2px solid #ffffff;\n  border-radius: 50%;\n}\n\n.savebutton {\n  position: absolute;\n  top: 8px;\n  right: 8px;\n  width: 38px;\n  height: 38px;\n  color: #282829;\n  background-color: #ffffffd7;\n  font-size: 8px;\n  border: 2px solid #ffffff;\n  border-radius: 50%;\n}\n\n.solidbackbutton {\n  width: 38px;\n  height: 38px;\n  color: #ffffff;\n  background-color: #666666;\n  font-size: 8px;\n  border: 2px solid #666666;\n  border-radius: 50%;\n}\n\nion-slides {\n  height: 100%;\n}\n\n.slideimage {\n  -o-object-fit: cover;\n     object-fit: cover;\n  height: 100%;\n  width: auto !important;\n}\n\n.pending-menu-title {\n  font-size: 18px;\n  font-weight: 600;\n  background-color: #ff6b6b;\n  padding: 6px;\n  margin-bottom: 0px;\n  color: #fff;\n  border-radius: 4px;\n  width: 100%;\n}\n\n.pending-title {\n  font-size: 16px;\n  font-weight: 600;\n  color: #666666;\n  padding-top: 1px;\n  margin-bottom: 8px;\n}\n\n.pending-text {\n  font-size: 14px;\n  margin-bottom: 0px;\n  margin-top: 2px;\n  font-weight: 600;\n  color: #ff6b6b;\n}\n\n.fullwidth {\n  width: 100%;\n}\n\n.section-title {\n  font-size: 20px;\n  font-weight: 600;\n  margin-bottom: 0px;\n  margin-top: 11px;\n}\n\n.siteimage {\n  display: block;\n  width: 100%;\n  height: 100%;\n  -o-object-fit: contain;\n     object-fit: contain;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc3VydmV5cHJvY2Vzcy9GOlxcbW9iaWxlYXBwL3NyY1xcYXBwXFxzdXJ2ZXlwcm9jZXNzXFxzdXJ2ZXlwcm9jZXNzLnBhZ2Uuc2NzcyIsInNyYy9hcHAvc3VydmV5cHJvY2Vzcy9zdXJ2ZXlwcm9jZXNzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLCtCQUFBO0FDQ0Y7O0FERUE7O0VBRUUsd0NBQUE7QUNDRjs7QURFQTtFQUNFLG9DQUFBO0FDQ0Y7O0FERUE7RUFDRSxvQ0FBQTtBQ0NGOztBREVBO0VBQ0UseUJBQUE7QUNDRjs7QURFQTtFQUNFLDJCQUFBO0FDQ0Y7O0FERUE7RUFDRSxjQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0FDQ0Y7O0FERUE7RUFDRSx5QkFBQTtBQ0NGOztBREVBO0VBQ0Usa0JBQUE7RUFDQSxXQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtBQ0NGOztBREVBO0VBQ0UsaUJBQUE7RUFDQSxrQkFBQTtBQ0NGOztBREVBO0VBQ0UsZ0JBQUE7RUFDQSxpQkFBQTtBQ0NGOztBREVBO0VBQ0UsY0FBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7QUNDRjs7QURFQTtFQUNFLGNBQUE7RUFDQSxlQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtBQ0NGOztBREVBO0VBQ0UsY0FBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7QUNDRjs7QURFQTtFQUNFLGNBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0FDQ0Y7O0FERUE7RUFDRSxjQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7QUNDRjs7QURFQTtFQUNFLGNBQUE7RUFDQSxlQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtBQ0NGOztBREVBO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSx5QkFBQTtFQUNBLG1CQUFBO0FDQ0Y7O0FERUE7RUFDRSxXQUFBO0VBQ0EsZUFBQTtBQ0NGOztBREVBO0VBQ0UsWUFBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7QUNDRjs7QURDRTtFQUNFLGFBQUE7QUNDSjs7QURFRTtFQUNFLGNBQUE7QUNBSjs7QURJQTtFQUNFLDJCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLGNBQUE7RUFDQSx5QkFBQTtFQUNBLHVCQUFBO0FDREY7O0FESUE7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsY0FBQTtFQUNBLHlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7QUNERjs7QURJQTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0EseUJBQUE7RUFDQSxrQkFBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7QUNERjs7QURJQTtFQUNFLFVBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7QUNERjs7QURJQTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0EseUJBQUE7RUFDQSxrQkFBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7QUNERjs7QURJQTtFQUNFLGdCQUFBO0VBQ0EsZUFBQTtBQ0RGOztBRElBO0VBQ0UsMkJBQUE7RUFDQSxlQUFBO0VBQ0EsU0FBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0FDREY7O0FESUE7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLHlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtFQUNBLGVBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtBQ0RGOztBRElBO0VBQ0UsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7QUNERjs7QURJQTtFQUNFLGlCQUFBO0VBQ0EsZUFBQTtBQ0RGOztBRElBO0VBQ0UsZUFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0FDREY7O0FESUE7RUFDRSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0FDREY7O0FESUE7RUFDRSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxTQUFBO0VBQ0EsMkJBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0VBQ0EseUJBQUE7QUNERjs7QURJQTtFQUVFLGVBQUE7RUFDQSxTQUFBO0VBQ0EsVUFBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0FDRkY7O0FES0E7RUFDRSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtBQ0ZGOztBRElFO0VBQ0UsYUFBQTtBQ0ZKOztBREtFO0VBQ0UsY0FBQTtBQ0hKOztBRE9BO0VBQ0Usa0JBQUE7RUFDQSxVQUFBO0VBQ0EsU0FBQTtFQUNBLDJCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtFQUNBLHlCQUFBO0FDSkY7O0FET0E7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLHlCQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0FDSkY7O0FET0E7RUFDRSxXQUFBO0VBQ0EsZUFBQTtBQ0pGOztBRE9BO0VBQ0UsV0FBQTtFQUNBLGtCQUFBO0VBQ0EsU0FBQTtBQ0pGOztBRE9BO0VBQ0UseUJBQUE7RUFDQSxtQkFBQTtBQ0pGOztBRE9BO0VBQ0UsZUFBQTtBQ0pGOztBRE9BO0VBQ0UsMkJBQUE7RUFDQSxjQUFBO0VBQ0EsZ0JBQUE7RUFDQSxnQkFBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSx5QkFBQTtFQUNBLGdCQUFBO0FDSkY7O0FET0E7RUFDRSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxTQUFBO0FDSkY7O0FET0E7RUFDRSx5QkFBQTtFQUNBLG1CQUFBO0FDSkY7O0FET0E7RUFDRSxlQUFBO0FDSkY7O0FET0E7RUFDRSx5QkFBQTtFQUNBLFlBQUE7RUFDQSxjQUFBO0VBQ0EsV0FBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtBQ0pGOztBRE9BO0VBQ0UsaUJBQUE7QUNKRjs7QURPQTtFQUNFLFlBQUE7RUFDQSxzQkFBQTtFQUNBLFlBQUE7RUFDQSx1REFBQTtFQUNBLCtHQUFBO0FDSkY7O0FEUUE7RUFDRSxnQkFBQTtFQUNBLGFBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0FDTEY7O0FEUUE7RUFDRSxZQUFBO0VBQ0Esc0JBQUE7RUFDQSxZQUFBO0VBQ0EsdURBQUE7RUFDQSwrR0FBQTtBQ0xGOztBRFNBO0VBQ0UsZ0JBQUE7RUFDQSxhQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtBQ05GOztBRFNBO0VBQ0Usa0JBQUE7RUFDQSxTQUFBO0VBQ0EsV0FBQTtBQ05GOztBRFNBO0VBQ0UsYUFBQTtBQ05GOztBRFNBO0VBQ0UsY0FBQTtBQ05GOztBRFNBO0VBQ0UsV0FBQTtBQ05GOztBRFNBO0VBQ0UsWUFBQTtFQUNBLFdBQUE7RUFDQSxlQUFBO0VBQ0Esc0JBQUE7RUFDQSxrQkFBQTtFQUNBLHFCQUFBO0FDTkY7O0FEU0E7RUFDRSxrQkFBQTtFQUNBLFNBQUE7RUFDQSxPQUFBO0VBQ0EsV0FBQTtBQ05GOztBRFNBO0VBQ0UsWUFBQTtFQUNBLFdBQUE7RUFDQSxzQkFBQTtFQUNBLGtCQUFBO0VBQ0EscUJBQUE7QUNORjs7QURTQTtFQUNFLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLFNBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGNBQUE7RUFDQSwyQkFBQTtFQUNBLGNBQUE7RUFDQSx5QkFBQTtFQUNBLGtCQUFBO0FDTkY7O0FEU0E7RUFDRSxrQkFBQTtFQUNBLFFBQUE7RUFDQSxVQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxjQUFBO0VBQ0EsMkJBQUE7RUFDQSxjQUFBO0VBQ0EseUJBQUE7RUFDQSxrQkFBQTtBQ05GOztBRFNBO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxjQUFBO0VBQ0EseUJBQUE7RUFDQSxjQUFBO0VBQ0EseUJBQUE7RUFDQSxrQkFBQTtBQ05GOztBRFNBO0VBQ0UsWUFBQTtBQ05GOztBRFNBO0VBQ0Usb0JBQUE7S0FBQSxpQkFBQTtFQUNBLFlBQUE7RUFDQSxzQkFBQTtBQ05GOztBRFNBO0VBQ0UsZUFBQTtFQUNBLGdCQUFBO0VBQ0EseUJBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0FDTkY7O0FEU0E7RUFDRSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtBQ05GOztBRFNBO0VBQ0UsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtBQ05GOztBRFNBO0VBQ0UsV0FBQTtBQ05GOztBRFNBO0VBQ0UsZUFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtBQ05GOztBRFNBO0VBQ0UsY0FBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0Esc0JBQUE7S0FBQSxtQkFBQTtBQ05GIiwiZmlsZSI6InNyYy9hcHAvc3VydmV5cHJvY2Vzcy9zdXJ2ZXlwcm9jZXNzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jb250ZW50IHtcclxuICAtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yOiAjZmZmZmZmO1xyXG59XHJcblxyXG5odG1sLFxyXG5ib2R5IHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG5pb24tYXBwIHtcclxuICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50ICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbmlvbi1jb250ZW50IHtcclxuICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50ICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbmFwcC1hciBpb24tY29udGVudCB7XHJcbiAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxufVxyXG5cclxuLnRyYW5zbHVjZW50LWJhY2tncm91bmQge1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICMwMDAwMDBhYTtcclxufVxyXG5cclxuLmVycm9yIHtcclxuICBjb2xvcjogcmdiKDIyMywgNjIsIDYyKTtcclxuICBmb250LXNpemU6IDExcHg7XHJcbiAgbWFyZ2luLWxlZnQ6IDVweDtcclxufVxyXG5cclxuLmRlZmF1bHRjYW1lcmFvcHRpb25zIHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMDAwMDAwO1xyXG59XHJcblxyXG4uYWN0aW9uYXJlYSB7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIGJvdHRvbTogMGVtO1xyXG4gIG1hcmdpbi1sZWZ0OiAwcHg7XHJcbiAgbWFyZ2luLXJpZ2h0OiAwcHg7XHJcbn1cclxuXHJcbi5hY3Rpb25hcmVhY29sIHtcclxuICBwYWRkaW5nLWxlZnQ6IDBweDtcclxuICBwYWRkaW5nLXJpZ2h0OiAwcHg7XHJcbn1cclxuXHJcbi5hY3Rpb25hcmVhIC5tYWluYnV0dG9ucyB7XHJcbiAgbWFyZ2luLWxlZnQ6IDBweDtcclxuICBtYXJnaW4tcmlnaHQ6IDBweDtcclxufVxyXG5cclxuLmFjdGlvbmFyZWEgLm1haW5idXR0b25zIC5hY3RpdmUge1xyXG4gIGNvbG9yOiAjZmZmZmZmO1xyXG4gIGZvbnQtc2l6ZTogMTRweDtcclxuICBmb250LXdlaWdodDogNjAwO1xyXG4gIHBhZGRpbmc6IDAgNHB4O1xyXG59XHJcblxyXG4uYWN0aW9uYXJlYSAubWFpbmJ1dHRvbnMgLm5vcm1hbCB7XHJcbiAgY29sb3I6ICNmZmZmZmY7XHJcbiAgZm9udC1zaXplOiAxNHB4O1xyXG4gIG9wYWNpdHk6IDAuNTtcclxuICBmb250LXdlaWdodDogMTAwO1xyXG4gIHBhZGRpbmc6IDAgNHB4O1xyXG59XHJcblxyXG4uYWN0aW9uYXJlYSAuY2hpbGRidXR0b25zIC5hY3RpdmUge1xyXG4gIGNvbG9yOiAjZmZmZmZmO1xyXG4gIGZvbnQtc2l6ZTogMTRweDtcclxuICBmb250LXdlaWdodDogNjAwO1xyXG4gIHBhZGRpbmc6IDAgNHB4O1xyXG59XHJcblxyXG4uYWN0aW9uYXJlYSAuY2hpbGRidXR0b25zIC5jb21wbGV0ZWQge1xyXG4gIGNvbG9yOiAjNmFiMDRjO1xyXG4gIGZvbnQtc2l6ZTogMTRweDtcclxuICBmb250LXdlaWdodDogNjAwO1xyXG4gIHBhZGRpbmc6IDAgNHB4O1xyXG59XHJcblxyXG4uYWN0aW9uYXJlYSAuY2hpbGRidXR0b25zIC5jb21wbGV0ZWQtaW5hY3RpdmUge1xyXG4gIGNvbG9yOiAjNmFiMDRjO1xyXG4gIG9wYWNpdHk6IDAuNztcclxuICBmb250LXNpemU6IDE0cHg7XHJcbiAgZm9udC13ZWlnaHQ6IDEwMDtcclxuICBwYWRkaW5nOiAwIDRweDtcclxufVxyXG5cclxuLmFjdGlvbmFyZWEgLmNoaWxkYnV0dG9ucyAubm9ybWFsIHtcclxuICBjb2xvcjogI2ZmZmZmZjtcclxuICBmb250LXNpemU6IDE0cHg7XHJcbiAgb3BhY2l0eTogMC41O1xyXG4gIGZvbnQtd2VpZ2h0OiAxMDA7XHJcbiAgcGFkZGluZzogMCA0cHg7XHJcbn1cclxuXHJcbi5hY3Rpb25hcmVhIC5nYWxsZXJ5YnV0dG9uIHtcclxuICB3aWR0aDogNzBweDtcclxuICBoZWlnaHQ6IDcwcHg7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIHJpZ2h0OiA1MHB4O1xyXG4gIHBhZGRpbmc6IDBweDtcclxuICBib3gtc2hhZG93OiBub25lO1xyXG4gIGJvcmRlcjogMnB4IHNvbGlkICNmZmZmZmY7XHJcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcclxufVxyXG5cclxuLmFjdGlvbmFyZWEgLmdhbGxlcnlidXR0b24gaW1nIHtcclxuICB3aWR0aDogNzBweDtcclxuICBtYXgtd2lkdGg6IDcwcHg7XHJcbn1cclxuXHJcbi5tYWluYnV0dG9uc2NvbnRhaW5lciB7XHJcbiAgd2lkdGg6IDEwMHZ3O1xyXG4gIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcclxuXHJcbiAgOjotd2Via2l0LXNjcm9sbGJhciB7XHJcbiAgICBkaXNwbGF5OiBub25lO1xyXG4gIH1cclxuXHJcbiAgLnNjcm9sbCB7XHJcbiAgICBvdmVyZmxvdzogYXV0bztcclxuICB9XHJcbn1cclxuXHJcbi5hY3Rpb25hcmVhIC5jYXB0dXJlYnV0dG9uIHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmZmZmYWE7XHJcbiAgd2lkdGg6IDcwcHg7XHJcbiAgaGVpZ2h0OiA3MHB4O1xyXG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICBtaW4td2lkdGg6IDBweDtcclxuICBib3JkZXI6IDRweCBzb2xpZCAjZmZmZmZmO1xyXG4gIG1hcmdpbjogNHB4IDBweCA0cHggMHB4O1xyXG59XHJcblxyXG4uYWN0aW9uYXJlYSAuem9vbWJ1dHRvbiB7XHJcbiAgd2lkdGg6IDM2cHg7XHJcbiAgaGVpZ2h0OiAzNnB4O1xyXG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICBtaW4td2lkdGg6IDBweDtcclxuICBib3JkZXI6IDFweCBzb2xpZCAjZmZmZmZmO1xyXG4gIGZvbnQtc2l6ZTogMC43ZW07XHJcbiAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICBjb2xvcjogI2ZmZmZmZjtcclxufVxyXG5cclxuLmFjdGlvbmFyZWEgLmNpcmN1bGFyYnV0dG9uIHtcclxuICB3aWR0aDogMzZweDtcclxuICBoZWlnaHQ6IDM2cHg7XHJcbiAgYm9yZGVyOiAxcHggc29saWQgI2ZmZmZmZjtcclxuICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgY29sb3I6ICNmZmZmZmY7XHJcbiAgbWFyZ2luLXRvcDogNHB4O1xyXG4gIG1hcmdpbi1sZWZ0OiA0cHg7XHJcbn1cclxuXHJcbi5hY3Rpb25hcmVhIC5jaXJjdWxhcmJ1dHRvbiBpbWcge1xyXG4gIHdpZHRoOiA1NiU7XHJcbiAgbWFyZ2luLWxlZnQ6IDdweDtcclxuICBtYXJnaW4tdG9wOiA3cHg7XHJcbn1cclxuXHJcbi5hY3Rpb25hcmVhIC5mbGFzaGJ1dHRvbiB7XHJcbiAgd2lkdGg6IDM2cHg7XHJcbiAgaGVpZ2h0OiAzNnB4O1xyXG4gIGJvcmRlcjogMXB4IHNvbGlkICNmZmZmZmY7XHJcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gIGNvbG9yOiAjZmZmZmZmO1xyXG4gIG1hcmdpbi10b3A6IDRweDtcclxuICBtYXJnaW4tbGVmdDogNHB4O1xyXG59XHJcblxyXG4uYWN0aW9uYXJlYSAuZmxhc2hidXR0b24gaW9uLWljb24ge1xyXG4gIG1hcmdpbi1sZWZ0OiA4cHg7XHJcbiAgbWFyZ2luLXRvcDogOHB4O1xyXG59XHJcblxyXG4uc2lkZXN0ZXBwZXIge1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICNmZmZmZmZlNztcclxuICBwb3NpdGlvbjogZml4ZWQ7XHJcbiAgdG9wOiA3MXB4O1xyXG4gIHJpZ2h0OiAxNnB4O1xyXG4gIHdpZHRoOiAyMDBweDtcclxuICBib3JkZXItcmFkaXVzOiAxNHB4O1xyXG4gIHBhZGRpbmc6IDhweDtcclxufVxyXG5cclxuLnN0ZXBwZXItaW5kZXgge1xyXG4gIHdpZHRoOiAyNHB4O1xyXG4gIGhlaWdodDogMjRweDtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMzg4MGZmO1xyXG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgcGFkZGluZy10b3A6IDRweDtcclxuICBjb2xvcjogI2ZmZmZmZjtcclxuICBmb250LXNpemU6IDEycHg7XHJcbiAgbWFyZ2luOiAxMnB4O1xyXG4gIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgbWFyZ2luLWJvdHRvbTogMHB4O1xyXG59XHJcblxyXG4uc3RlcHBlci10aXRsZSB7XHJcbiAgZm9udC1zaXplOiAxNHB4O1xyXG4gIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgY29sb3I6ICMwMDAwMDA7XHJcbiAgcGFkZGluZy10b3A6IDFweDtcclxuICBtYXJnaW4tYm90dG9tOiA4cHg7XHJcbn1cclxuXHJcbi5zaWRlc3RlcHBlciAuc3RlcHBlci1saXN0LXJvdyB7XHJcbiAgbWFyZ2luLWxlZnQ6IDE1cHg7XHJcbiAgbWFyZ2luLXRvcDogNnB4O1xyXG59XHJcblxyXG4uc2lkZXN0ZXBwZXIgLnN0ZXBwZXItdGV4dC1hY3RpdmUge1xyXG4gIGZvbnQtc2l6ZTogMTJweDtcclxuICBmb250LXdlaWdodDogNjAwO1xyXG4gIG1hcmdpbi1ib3R0b206IDBweDtcclxuICBtYXJnaW4tdG9wOiAycHg7XHJcbiAgbWFyZ2luLWxlZnQ6IDZweDtcclxuICBjb2xvcjogIzRmODMzOTtcclxufVxyXG5cclxuLnNpZGVzdGVwcGVyIC5zdGVwcGVyLXRleHQtZGVmYXVsdCB7XHJcbiAgZm9udC1zaXplOiAxMnB4O1xyXG4gIG1hcmdpbi1ib3R0b206IDBweDtcclxuICBtYXJnaW4tdG9wOiAycHg7XHJcbiAgbWFyZ2luLWxlZnQ6IDZweDtcclxuICBjb2xvcjogIzI3MjcyNztcclxufVxyXG5cclxuLmluZm9idXR0b24ge1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICByaWdodDogMTZweDtcclxuICB0b3A6IDI2cHg7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZmZmZmQ3O1xyXG4gIHdpZHRoOiAzNnB4O1xyXG4gIGhlaWdodDogMzZweDtcclxuICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgY29sb3I6ICMyODI4Mjk7XHJcbiAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICBib3JkZXI6IDJweCBzb2xpZCAjZmZmZmZmO1xyXG59XHJcblxyXG4uZ2FsbGVyeXNpZGViYXIge1xyXG4gIC8vIGJhY2tncm91bmQtY29sb3I6ICNkODBjMGNhYTtcclxuICBwb3NpdGlvbjogZml4ZWQ7XHJcbiAgdG9wOiA3MXB4O1xyXG4gIGxlZnQ6IDE2cHg7XHJcbiAgd2lkdGg6IDEwMHB4O1xyXG4gIGJvcmRlci1yYWRpdXM6IDE0cHg7XHJcbiAgcGFkZGluZy10b3A6IDhweDtcclxufVxyXG5cclxuLmdhbGxlcnlzY3JvbGxjb250YWluZXIge1xyXG4gIGhlaWdodDogNjB2aDtcclxuICBvdmVyZmxvdzogaGlkZGVuO1xyXG4gIHdoaXRlLXNwYWNlOiBub3dyYXA7XHJcblxyXG4gIDo6LXdlYmtpdC1zY3JvbGxiYXIge1xyXG4gICAgZGlzcGxheTogbm9uZTtcclxuICB9XHJcblxyXG4gIC5zY3JvbGwge1xyXG4gICAgb3ZlcmZsb3c6IGF1dG87XHJcbiAgfVxyXG59XHJcblxyXG4uZ2FsbGVyeWNsb3NlYnV0dG9uIHtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgbGVmdDogMTZweDtcclxuICB0b3A6IDI2cHg7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZmZmZmQ3O1xyXG4gIHdpZHRoOiAzNnB4O1xyXG4gIGhlaWdodDogMzZweDtcclxuICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgY29sb3I6ICMyODI4Mjk7XHJcbiAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICBib3JkZXI6IDJweCBzb2xpZCAjZmZmZmZmO1xyXG59XHJcblxyXG4uZ2FsbGVyeXNpZGViYXIgLmNhbWVyYWltYWdlc2J1dHRvbiB7XHJcbiAgd2lkdGg6IDcwcHg7XHJcbiAgaGVpZ2h0OiA3MHB4O1xyXG4gIGJvcmRlcjogMnB4IHNvbGlkICNmZmZmZmY7XHJcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuICBwYWRkaW5nOiAwcHg7XHJcbiAgYm94LXNoYWRvdzogbm9uZTtcclxuICBkaXNwbGF5OiBibG9jaztcclxufVxyXG5cclxuLmdhbGxlcnlzaWRlYmFyIC5jYW1lcmFpbWFnZXNidXR0b24gaW1nIHtcclxuICB3aWR0aDogNzBweDtcclxuICBtYXgtd2lkdGg6IDcwcHg7XHJcbn1cclxuXHJcbi5xdWVzdGlvbmFpcmV2aWV3IHtcclxuICB3aWR0aDogNzZ2dztcclxuICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgdG9wOiAzMHZoO1xyXG59XHJcblxyXG4ucXVlc3Rpb25haXJldmlldy1yb3cge1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICNmZmZmZmY7XHJcbiAgYm9yZGVyLXJhZGl1czogMTJweDtcclxufVxyXG5cclxuLnF1ZXN0aW9uYWlyZXZpZXctcm93IHAge1xyXG4gIGZvbnQtc2l6ZTogMTRweDtcclxufVxyXG5cclxuLnNob3RpbmZvIHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjNmFiMDRjOGE7XHJcbiAgY29sb3I6ICNmZmZmZmY7XHJcbiAgZm9udC1zaXplOiAwLjdlbTtcclxuICBmb250LXdlaWdodDogNjAwO1xyXG4gIHBhZGRpbmc6IDRweCA4cHg7XHJcbiAgYm9yZGVyLXJhZGl1czogMTJweDtcclxuICBib3JkZXI6IDFweCBzb2xpZCAjNmFiMDRjO1xyXG4gIG1hcmdpbi1ib3R0b206IDA7XHJcbn1cclxuXHJcbi5jaGVja2V4aXN0ZW5jZXZpZXcge1xyXG4gIHdpZHRoOiA3NnZ3O1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICB0b3A6IDMwdmg7XHJcbn1cclxuXHJcbi5jaGVja2V4aXN0ZW5jZXZpZXctcm93IHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmZmZmO1xyXG4gIGJvcmRlci1yYWRpdXM6IDEycHg7XHJcbn1cclxuXHJcbi5jaGVja2V4aXN0ZW5jZXZpZXctcm93IHAge1xyXG4gIGZvbnQtc2l6ZTogMTRweDtcclxufVxyXG5cclxuLmZvcm1oZWFkZXIge1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICM2NjY2NjY7XHJcbiAgaGVpZ2h0OiAzNnB4O1xyXG4gIGNvbG9yOiAjZmZmZmZmO1xyXG4gIG1hcmdpbjogMHB4O1xyXG4gIHBhZGRpbmctdG9wOiA3cHg7XHJcbiAgcGFkZGluZy1sZWZ0OiAxNnB4O1xyXG4gIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbn1cclxuXHJcbi5sb2NhdGlvbm1hcmtpbmdib3VuZGFyeSAuY29sIHtcclxuICBwYWRkaW5nLWxlZnQ6IDBweDtcclxufVxyXG5cclxuLmxlZ2VuZCB7XHJcbiAgaGVpZ2h0OiA1MnB4O1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XHJcbiAgY3Vyc29yOiBtb3ZlO1xyXG4gIHRyYW5zaXRpb246IGJveC1zaGFkb3cgMjAwbXMgY3ViaWMtYmV6aWVyKDAsIDAsIDAuMiwgMSk7XHJcbiAgYm94LXNoYWRvdzogMCAzcHggMXB4IC0ycHggcmdiYSgwLCAwLCAwLCAwLjIpLCAwIDJweCAycHggMCByZ2JhKDAsIDAsIDAsIDAuMTQpLFxyXG4gICAgMCAxcHggNXB4IDAgcmdiYSgwLCAwLCAwLCAwLjEyKTtcclxufVxyXG5cclxuLmxlZ2VuZCAubGVnZW5kdGV4dCB7XHJcbiAgbWFyZ2luLWJvdHRvbTogMDtcclxuICBtYXJnaW4tdG9wOiAwO1xyXG4gIGZvbnQtc2l6ZTogMC44ZW07XHJcbiAgY29sb3I6ICMwMDAwMDA7XHJcbiAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbn1cclxuXHJcbi5kaXNhYmxlZGxlZ2VuZCB7XHJcbiAgaGVpZ2h0OiA1MnB4O1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XHJcbiAgY3Vyc29yOiBtb3ZlO1xyXG4gIHRyYW5zaXRpb246IGJveC1zaGFkb3cgMjAwbXMgY3ViaWMtYmV6aWVyKDAsIDAsIDAuMiwgMSk7XHJcbiAgYm94LXNoYWRvdzogMCAzcHggMXB4IC0ycHggcmdiYSgwLCAwLCAwLCAwLjIpLCAwIDJweCAycHggMCByZ2JhKDAsIDAsIDAsIDAuMTQpLFxyXG4gICAgMCAxcHggNXB4IDAgcmdiYSgwLCAwLCAwLCAwLjEyKTtcclxufVxyXG5cclxuLmRpc2FibGVkbGVnZW5kdGV4dCB7XHJcbiAgbWFyZ2luLWJvdHRvbTogMDtcclxuICBtYXJnaW4tdG9wOiAwO1xyXG4gIGZvbnQtc2l6ZTogMC44ZW07XHJcbiAgY29sb3I6ICM5OTk5OTk7XHJcbiAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbn1cclxuXHJcbi51bmRvYnV0dG9uIHtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgdG9wOiAtM3B4O1xyXG4gIHJpZ2h0OiAtNnB4O1xyXG59XHJcblxyXG4uaGlkZGVuIHtcclxuICBkaXNwbGF5OiBub25lO1xyXG59XHJcblxyXG4udW5oaWRkZW4ge1xyXG4gIGRpc3BsYXk6IGJsb2NrO1xyXG59XHJcblxyXG4udW5kb2ltYWdlIHtcclxuICB3aWR0aDogMTRweDtcclxufVxyXG5cclxuLmRvdGNvbnRhaW5lciB7XHJcbiAgaGVpZ2h0OiAyMHB4O1xyXG4gIHdpZHRoOiAyMHB4O1xyXG4gIG1hcmdpbi10b3A6IDRweDtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjYmJiO1xyXG4gIGJvcmRlci1yYWRpdXM6IDRweDtcclxuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbn1cclxuXHJcbi5sZWdlbmRzY29udGFpbmVyIHtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgYm90dG9tOiAwO1xyXG4gIGxlZnQ6IDA7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbn1cclxuXHJcbi5kb3Qge1xyXG4gIGhlaWdodDogMjBweDtcclxuICB3aWR0aDogMjBweDtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjYmJiO1xyXG4gIGJvcmRlci1yYWRpdXM6IDRweDtcclxuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbn1cclxuXHJcbi5iYWNrYnV0dG9uIHtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgdG9wOiA4cHg7XHJcbiAgbGVmdDogOHB4O1xyXG4gIHdpZHRoOiAzOHB4O1xyXG4gIGhlaWdodDogMzhweDtcclxuICBjb2xvcjogIzI4MjgyOTtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmZmZmZDc7XHJcbiAgZm9udC1zaXplOiA4cHg7XHJcbiAgYm9yZGVyOiAycHggc29saWQgI2ZmZmZmZjtcclxuICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbn1cclxuXHJcbi5zYXZlYnV0dG9uIHtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgdG9wOiA4cHg7XHJcbiAgcmlnaHQ6IDhweDtcclxuICB3aWR0aDogMzhweDtcclxuICBoZWlnaHQ6IDM4cHg7XHJcbiAgY29sb3I6ICMyODI4Mjk7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZmZmZmQ3O1xyXG4gIGZvbnQtc2l6ZTogOHB4O1xyXG4gIGJvcmRlcjogMnB4IHNvbGlkICNmZmZmZmY7XHJcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG59XHJcblxyXG4uc29saWRiYWNrYnV0dG9uIHtcclxuICB3aWR0aDogMzhweDtcclxuICBoZWlnaHQ6IDM4cHg7XHJcbiAgY29sb3I6ICNmZmZmZmY7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogIzY2NjY2NjtcclxuICBmb250LXNpemU6IDhweDtcclxuICBib3JkZXI6IDJweCBzb2xpZCAjNjY2NjY2O1xyXG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcclxufVxyXG5cclxuaW9uLXNsaWRlcyB7XHJcbiAgaGVpZ2h0OiAxMDAlO1xyXG59XHJcblxyXG4uc2xpZGVpbWFnZSB7XHJcbiAgb2JqZWN0LWZpdDogY292ZXI7XHJcbiAgaGVpZ2h0OiAxMDAlO1xyXG4gIHdpZHRoOiBhdXRvICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5wZW5kaW5nLW1lbnUtdGl0bGUge1xyXG4gIGZvbnQtc2l6ZTogMThweDtcclxuICBmb250LXdlaWdodDogNjAwO1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICNmZjZiNmI7XHJcbiAgcGFkZGluZzogNnB4O1xyXG4gIG1hcmdpbi1ib3R0b206IDBweDtcclxuICBjb2xvcjogI2ZmZjtcclxuICBib3JkZXItcmFkaXVzOiA0cHg7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbn1cclxuXHJcbi5wZW5kaW5nLXRpdGxlIHtcclxuICBmb250LXNpemU6IDE2cHg7XHJcbiAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICBjb2xvcjogIzY2NjY2NjtcclxuICBwYWRkaW5nLXRvcDogMXB4O1xyXG4gIG1hcmdpbi1ib3R0b206IDhweDtcclxufVxyXG5cclxuLnBlbmRpbmctdGV4dCB7XHJcbiAgZm9udC1zaXplOiAxNHB4O1xyXG4gIG1hcmdpbi1ib3R0b206IDBweDtcclxuICBtYXJnaW4tdG9wOiAycHg7XHJcbiAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICBjb2xvcjogI2ZmNmI2YjtcclxufVxyXG5cclxuLmZ1bGx3aWR0aCB7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbn1cclxuXHJcbi5zZWN0aW9uLXRpdGxlIHtcclxuICBmb250LXNpemU6IDIwcHg7XHJcbiAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICBtYXJnaW4tYm90dG9tOiAwcHg7XHJcbiAgbWFyZ2luLXRvcDogMTFweDtcclxufVxyXG5cclxuLnNpdGVpbWFnZSB7XHJcbiAgZGlzcGxheTogYmxvY2s7XHJcbiAgd2lkdGg6IDEwMCU7IFxyXG4gIGhlaWdodDogMTAwJTtcclxuICBvYmplY3QtZml0OiBjb250YWluO1xyXG59XHJcbiIsImlvbi1jb250ZW50IHtcbiAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjogI2ZmZmZmZjtcbn1cblxuaHRtbCxcbmJvZHkge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xufVxuXG5pb24tYXBwIHtcbiAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xufVxuXG5pb24tY29udGVudCB7XG4gIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQgIWltcG9ydGFudDtcbn1cblxuYXBwLWFyIGlvbi1jb250ZW50IHtcbiAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbn1cblxuLnRyYW5zbHVjZW50LWJhY2tncm91bmQge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMDAwMDAwYWE7XG59XG5cbi5lcnJvciB7XG4gIGNvbG9yOiAjZGYzZTNlO1xuICBmb250LXNpemU6IDExcHg7XG4gIG1hcmdpbi1sZWZ0OiA1cHg7XG59XG5cbi5kZWZhdWx0Y2FtZXJhb3B0aW9ucyB7XG4gIGJhY2tncm91bmQtY29sb3I6ICMwMDAwMDA7XG59XG5cbi5hY3Rpb25hcmVhIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBib3R0b206IDBlbTtcbiAgbWFyZ2luLWxlZnQ6IDBweDtcbiAgbWFyZ2luLXJpZ2h0OiAwcHg7XG59XG5cbi5hY3Rpb25hcmVhY29sIHtcbiAgcGFkZGluZy1sZWZ0OiAwcHg7XG4gIHBhZGRpbmctcmlnaHQ6IDBweDtcbn1cblxuLmFjdGlvbmFyZWEgLm1haW5idXR0b25zIHtcbiAgbWFyZ2luLWxlZnQ6IDBweDtcbiAgbWFyZ2luLXJpZ2h0OiAwcHg7XG59XG5cbi5hY3Rpb25hcmVhIC5tYWluYnV0dG9ucyAuYWN0aXZlIHtcbiAgY29sb3I6ICNmZmZmZmY7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgcGFkZGluZzogMCA0cHg7XG59XG5cbi5hY3Rpb25hcmVhIC5tYWluYnV0dG9ucyAubm9ybWFsIHtcbiAgY29sb3I6ICNmZmZmZmY7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgb3BhY2l0eTogMC41O1xuICBmb250LXdlaWdodDogMTAwO1xuICBwYWRkaW5nOiAwIDRweDtcbn1cblxuLmFjdGlvbmFyZWEgLmNoaWxkYnV0dG9ucyAuYWN0aXZlIHtcbiAgY29sb3I6ICNmZmZmZmY7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgcGFkZGluZzogMCA0cHg7XG59XG5cbi5hY3Rpb25hcmVhIC5jaGlsZGJ1dHRvbnMgLmNvbXBsZXRlZCB7XG4gIGNvbG9yOiAjNmFiMDRjO1xuICBmb250LXNpemU6IDE0cHg7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG4gIHBhZGRpbmc6IDAgNHB4O1xufVxuXG4uYWN0aW9uYXJlYSAuY2hpbGRidXR0b25zIC5jb21wbGV0ZWQtaW5hY3RpdmUge1xuICBjb2xvcjogIzZhYjA0YztcbiAgb3BhY2l0eTogMC43O1xuICBmb250LXNpemU6IDE0cHg7XG4gIGZvbnQtd2VpZ2h0OiAxMDA7XG4gIHBhZGRpbmc6IDAgNHB4O1xufVxuXG4uYWN0aW9uYXJlYSAuY2hpbGRidXR0b25zIC5ub3JtYWwge1xuICBjb2xvcjogI2ZmZmZmZjtcbiAgZm9udC1zaXplOiAxNHB4O1xuICBvcGFjaXR5OiAwLjU7XG4gIGZvbnQtd2VpZ2h0OiAxMDA7XG4gIHBhZGRpbmc6IDAgNHB4O1xufVxuXG4uYWN0aW9uYXJlYSAuZ2FsbGVyeWJ1dHRvbiB7XG4gIHdpZHRoOiA3MHB4O1xuICBoZWlnaHQ6IDcwcHg7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgcmlnaHQ6IDUwcHg7XG4gIHBhZGRpbmc6IDBweDtcbiAgYm94LXNoYWRvdzogbm9uZTtcbiAgYm9yZGVyOiAycHggc29saWQgI2ZmZmZmZjtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbn1cblxuLmFjdGlvbmFyZWEgLmdhbGxlcnlidXR0b24gaW1nIHtcbiAgd2lkdGg6IDcwcHg7XG4gIG1heC13aWR0aDogNzBweDtcbn1cblxuLm1haW5idXR0b25zY29udGFpbmVyIHtcbiAgd2lkdGg6IDEwMHZ3O1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICB3aGl0ZS1zcGFjZTogbm93cmFwO1xufVxuLm1haW5idXR0b25zY29udGFpbmVyIDo6LXdlYmtpdC1zY3JvbGxiYXIge1xuICBkaXNwbGF5OiBub25lO1xufVxuLm1haW5idXR0b25zY29udGFpbmVyIC5zY3JvbGwge1xuICBvdmVyZmxvdzogYXV0bztcbn1cblxuLmFjdGlvbmFyZWEgLmNhcHR1cmVidXR0b24ge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmZmZmYWE7XG4gIHdpZHRoOiA3MHB4O1xuICBoZWlnaHQ6IDcwcHg7XG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgbWluLXdpZHRoOiAwcHg7XG4gIGJvcmRlcjogNHB4IHNvbGlkICNmZmZmZmY7XG4gIG1hcmdpbjogNHB4IDBweCA0cHggMHB4O1xufVxuXG4uYWN0aW9uYXJlYSAuem9vbWJ1dHRvbiB7XG4gIHdpZHRoOiAzNnB4O1xuICBoZWlnaHQ6IDM2cHg7XG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgbWluLXdpZHRoOiAwcHg7XG4gIGJvcmRlcjogMXB4IHNvbGlkICNmZmZmZmY7XG4gIGZvbnQtc2l6ZTogMC43ZW07XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG4gIGNvbG9yOiAjZmZmZmZmO1xufVxuXG4uYWN0aW9uYXJlYSAuY2lyY3VsYXJidXR0b24ge1xuICB3aWR0aDogMzZweDtcbiAgaGVpZ2h0OiAzNnB4O1xuICBib3JkZXI6IDFweCBzb2xpZCAjZmZmZmZmO1xuICBib3JkZXItcmFkaXVzOiA1MCU7XG4gIGNvbG9yOiAjZmZmZmZmO1xuICBtYXJnaW4tdG9wOiA0cHg7XG4gIG1hcmdpbi1sZWZ0OiA0cHg7XG59XG5cbi5hY3Rpb25hcmVhIC5jaXJjdWxhcmJ1dHRvbiBpbWcge1xuICB3aWR0aDogNTYlO1xuICBtYXJnaW4tbGVmdDogN3B4O1xuICBtYXJnaW4tdG9wOiA3cHg7XG59XG5cbi5hY3Rpb25hcmVhIC5mbGFzaGJ1dHRvbiB7XG4gIHdpZHRoOiAzNnB4O1xuICBoZWlnaHQ6IDM2cHg7XG4gIGJvcmRlcjogMXB4IHNvbGlkICNmZmZmZmY7XG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgY29sb3I6ICNmZmZmZmY7XG4gIG1hcmdpbi10b3A6IDRweDtcbiAgbWFyZ2luLWxlZnQ6IDRweDtcbn1cblxuLmFjdGlvbmFyZWEgLmZsYXNoYnV0dG9uIGlvbi1pY29uIHtcbiAgbWFyZ2luLWxlZnQ6IDhweDtcbiAgbWFyZ2luLXRvcDogOHB4O1xufVxuXG4uc2lkZXN0ZXBwZXIge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmZmZmZTc7XG4gIHBvc2l0aW9uOiBmaXhlZDtcbiAgdG9wOiA3MXB4O1xuICByaWdodDogMTZweDtcbiAgd2lkdGg6IDIwMHB4O1xuICBib3JkZXItcmFkaXVzOiAxNHB4O1xuICBwYWRkaW5nOiA4cHg7XG59XG5cbi5zdGVwcGVyLWluZGV4IHtcbiAgd2lkdGg6IDI0cHg7XG4gIGhlaWdodDogMjRweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzM4ODBmZjtcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIHBhZGRpbmctdG9wOiA0cHg7XG4gIGNvbG9yOiAjZmZmZmZmO1xuICBmb250LXNpemU6IDEycHg7XG4gIG1hcmdpbjogMTJweDtcbiAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgbWFyZ2luLWJvdHRvbTogMHB4O1xufVxuXG4uc3RlcHBlci10aXRsZSB7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgY29sb3I6ICMwMDAwMDA7XG4gIHBhZGRpbmctdG9wOiAxcHg7XG4gIG1hcmdpbi1ib3R0b206IDhweDtcbn1cblxuLnNpZGVzdGVwcGVyIC5zdGVwcGVyLWxpc3Qtcm93IHtcbiAgbWFyZ2luLWxlZnQ6IDE1cHg7XG4gIG1hcmdpbi10b3A6IDZweDtcbn1cblxuLnNpZGVzdGVwcGVyIC5zdGVwcGVyLXRleHQtYWN0aXZlIHtcbiAgZm9udC1zaXplOiAxMnB4O1xuICBmb250LXdlaWdodDogNjAwO1xuICBtYXJnaW4tYm90dG9tOiAwcHg7XG4gIG1hcmdpbi10b3A6IDJweDtcbiAgbWFyZ2luLWxlZnQ6IDZweDtcbiAgY29sb3I6ICM0ZjgzMzk7XG59XG5cbi5zaWRlc3RlcHBlciAuc3RlcHBlci10ZXh0LWRlZmF1bHQge1xuICBmb250LXNpemU6IDEycHg7XG4gIG1hcmdpbi1ib3R0b206IDBweDtcbiAgbWFyZ2luLXRvcDogMnB4O1xuICBtYXJnaW4tbGVmdDogNnB4O1xuICBjb2xvcjogIzI3MjcyNztcbn1cblxuLmluZm9idXR0b24ge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHJpZ2h0OiAxNnB4O1xuICB0b3A6IDI2cHg7XG4gIGJhY2tncm91bmQtY29sb3I6ICNmZmZmZmZkNztcbiAgd2lkdGg6IDM2cHg7XG4gIGhlaWdodDogMzZweDtcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xuICBjb2xvcjogIzI4MjgyOTtcbiAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgYm9yZGVyOiAycHggc29saWQgI2ZmZmZmZjtcbn1cblxuLmdhbGxlcnlzaWRlYmFyIHtcbiAgcG9zaXRpb246IGZpeGVkO1xuICB0b3A6IDcxcHg7XG4gIGxlZnQ6IDE2cHg7XG4gIHdpZHRoOiAxMDBweDtcbiAgYm9yZGVyLXJhZGl1czogMTRweDtcbiAgcGFkZGluZy10b3A6IDhweDtcbn1cblxuLmdhbGxlcnlzY3JvbGxjb250YWluZXIge1xuICBoZWlnaHQ6IDYwdmg7XG4gIG92ZXJmbG93OiBoaWRkZW47XG4gIHdoaXRlLXNwYWNlOiBub3dyYXA7XG59XG4uZ2FsbGVyeXNjcm9sbGNvbnRhaW5lciA6Oi13ZWJraXQtc2Nyb2xsYmFyIHtcbiAgZGlzcGxheTogbm9uZTtcbn1cbi5nYWxsZXJ5c2Nyb2xsY29udGFpbmVyIC5zY3JvbGwge1xuICBvdmVyZmxvdzogYXV0bztcbn1cblxuLmdhbGxlcnljbG9zZWJ1dHRvbiB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgbGVmdDogMTZweDtcbiAgdG9wOiAyNnB4O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmZmZmZDc7XG4gIHdpZHRoOiAzNnB4O1xuICBoZWlnaHQ6IDM2cHg7XG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgY29sb3I6ICMyODI4Mjk7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG4gIGJvcmRlcjogMnB4IHNvbGlkICNmZmZmZmY7XG59XG5cbi5nYWxsZXJ5c2lkZWJhciAuY2FtZXJhaW1hZ2VzYnV0dG9uIHtcbiAgd2lkdGg6IDcwcHg7XG4gIGhlaWdodDogNzBweDtcbiAgYm9yZGVyOiAycHggc29saWQgI2ZmZmZmZjtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgcGFkZGluZzogMHB4O1xuICBib3gtc2hhZG93OiBub25lO1xuICBkaXNwbGF5OiBibG9jaztcbn1cblxuLmdhbGxlcnlzaWRlYmFyIC5jYW1lcmFpbWFnZXNidXR0b24gaW1nIHtcbiAgd2lkdGg6IDcwcHg7XG4gIG1heC13aWR0aDogNzBweDtcbn1cblxuLnF1ZXN0aW9uYWlyZXZpZXcge1xuICB3aWR0aDogNzZ2dztcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICB0b3A6IDMwdmg7XG59XG5cbi5xdWVzdGlvbmFpcmV2aWV3LXJvdyB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNmZmZmZmY7XG4gIGJvcmRlci1yYWRpdXM6IDEycHg7XG59XG5cbi5xdWVzdGlvbmFpcmV2aWV3LXJvdyBwIHtcbiAgZm9udC1zaXplOiAxNHB4O1xufVxuXG4uc2hvdGluZm8ge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjNmFiMDRjOGE7XG4gIGNvbG9yOiAjZmZmZmZmO1xuICBmb250LXNpemU6IDAuN2VtO1xuICBmb250LXdlaWdodDogNjAwO1xuICBwYWRkaW5nOiA0cHggOHB4O1xuICBib3JkZXItcmFkaXVzOiAxMnB4O1xuICBib3JkZXI6IDFweCBzb2xpZCAjNmFiMDRjO1xuICBtYXJnaW4tYm90dG9tOiAwO1xufVxuXG4uY2hlY2tleGlzdGVuY2V2aWV3IHtcbiAgd2lkdGg6IDc2dnc7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgdG9wOiAzMHZoO1xufVxuXG4uY2hlY2tleGlzdGVuY2V2aWV3LXJvdyB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNmZmZmZmY7XG4gIGJvcmRlci1yYWRpdXM6IDEycHg7XG59XG5cbi5jaGVja2V4aXN0ZW5jZXZpZXctcm93IHAge1xuICBmb250LXNpemU6IDE0cHg7XG59XG5cbi5mb3JtaGVhZGVyIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzY2NjY2NjtcbiAgaGVpZ2h0OiAzNnB4O1xuICBjb2xvcjogI2ZmZmZmZjtcbiAgbWFyZ2luOiAwcHg7XG4gIHBhZGRpbmctdG9wOiA3cHg7XG4gIHBhZGRpbmctbGVmdDogMTZweDtcbiAgZm9udC13ZWlnaHQ6IDYwMDtcbn1cblxuLmxvY2F0aW9ubWFya2luZ2JvdW5kYXJ5IC5jb2wge1xuICBwYWRkaW5nLWxlZnQ6IDBweDtcbn1cblxuLmxlZ2VuZCB7XG4gIGhlaWdodDogNTJweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcbiAgY3Vyc29yOiBtb3ZlO1xuICB0cmFuc2l0aW9uOiBib3gtc2hhZG93IDIwMG1zIGN1YmljLWJlemllcigwLCAwLCAwLjIsIDEpO1xuICBib3gtc2hhZG93OiAwIDNweCAxcHggLTJweCByZ2JhKDAsIDAsIDAsIDAuMiksIDAgMnB4IDJweCAwIHJnYmEoMCwgMCwgMCwgMC4xNCksIDAgMXB4IDVweCAwIHJnYmEoMCwgMCwgMCwgMC4xMik7XG59XG5cbi5sZWdlbmQgLmxlZ2VuZHRleHQge1xuICBtYXJnaW4tYm90dG9tOiAwO1xuICBtYXJnaW4tdG9wOiAwO1xuICBmb250LXNpemU6IDAuOGVtO1xuICBjb2xvcjogIzAwMDAwMDtcbiAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG4uZGlzYWJsZWRsZWdlbmQge1xuICBoZWlnaHQ6IDUycHg7XG4gIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XG4gIGN1cnNvcjogbW92ZTtcbiAgdHJhbnNpdGlvbjogYm94LXNoYWRvdyAyMDBtcyBjdWJpYy1iZXppZXIoMCwgMCwgMC4yLCAxKTtcbiAgYm94LXNoYWRvdzogMCAzcHggMXB4IC0ycHggcmdiYSgwLCAwLCAwLCAwLjIpLCAwIDJweCAycHggMCByZ2JhKDAsIDAsIDAsIDAuMTQpLCAwIDFweCA1cHggMCByZ2JhKDAsIDAsIDAsIDAuMTIpO1xufVxuXG4uZGlzYWJsZWRsZWdlbmR0ZXh0IHtcbiAgbWFyZ2luLWJvdHRvbTogMDtcbiAgbWFyZ2luLXRvcDogMDtcbiAgZm9udC1zaXplOiAwLjhlbTtcbiAgY29sb3I6ICM5OTk5OTk7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxuLnVuZG9idXR0b24ge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogLTNweDtcbiAgcmlnaHQ6IC02cHg7XG59XG5cbi5oaWRkZW4ge1xuICBkaXNwbGF5OiBub25lO1xufVxuXG4udW5oaWRkZW4ge1xuICBkaXNwbGF5OiBibG9jaztcbn1cblxuLnVuZG9pbWFnZSB7XG4gIHdpZHRoOiAxNHB4O1xufVxuXG4uZG90Y29udGFpbmVyIHtcbiAgaGVpZ2h0OiAyMHB4O1xuICB3aWR0aDogMjBweDtcbiAgbWFyZ2luLXRvcDogNHB4O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjYmJiO1xuICBib3JkZXItcmFkaXVzOiA0cHg7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbn1cblxuLmxlZ2VuZHNjb250YWluZXIge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGJvdHRvbTogMDtcbiAgbGVmdDogMDtcbiAgd2lkdGg6IDEwMCU7XG59XG5cbi5kb3Qge1xuICBoZWlnaHQ6IDIwcHg7XG4gIHdpZHRoOiAyMHB4O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjYmJiO1xuICBib3JkZXItcmFkaXVzOiA0cHg7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbn1cblxuLmJhY2tidXR0b24ge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogOHB4O1xuICBsZWZ0OiA4cHg7XG4gIHdpZHRoOiAzOHB4O1xuICBoZWlnaHQ6IDM4cHg7XG4gIGNvbG9yOiAjMjgyODI5O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmZmZmZDc7XG4gIGZvbnQtc2l6ZTogOHB4O1xuICBib3JkZXI6IDJweCBzb2xpZCAjZmZmZmZmO1xuICBib3JkZXItcmFkaXVzOiA1MCU7XG59XG5cbi5zYXZlYnV0dG9uIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0b3A6IDhweDtcbiAgcmlnaHQ6IDhweDtcbiAgd2lkdGg6IDM4cHg7XG4gIGhlaWdodDogMzhweDtcbiAgY29sb3I6ICMyODI4Mjk7XG4gIGJhY2tncm91bmQtY29sb3I6ICNmZmZmZmZkNztcbiAgZm9udC1zaXplOiA4cHg7XG4gIGJvcmRlcjogMnB4IHNvbGlkICNmZmZmZmY7XG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcbn1cblxuLnNvbGlkYmFja2J1dHRvbiB7XG4gIHdpZHRoOiAzOHB4O1xuICBoZWlnaHQ6IDM4cHg7XG4gIGNvbG9yOiAjZmZmZmZmO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjNjY2NjY2O1xuICBmb250LXNpemU6IDhweDtcbiAgYm9yZGVyOiAycHggc29saWQgIzY2NjY2NjtcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xufVxuXG5pb24tc2xpZGVzIHtcbiAgaGVpZ2h0OiAxMDAlO1xufVxuXG4uc2xpZGVpbWFnZSB7XG4gIG9iamVjdC1maXQ6IGNvdmVyO1xuICBoZWlnaHQ6IDEwMCU7XG4gIHdpZHRoOiBhdXRvICFpbXBvcnRhbnQ7XG59XG5cbi5wZW5kaW5nLW1lbnUtdGl0bGUge1xuICBmb250LXNpemU6IDE4cHg7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG4gIGJhY2tncm91bmQtY29sb3I6ICNmZjZiNmI7XG4gIHBhZGRpbmc6IDZweDtcbiAgbWFyZ2luLWJvdHRvbTogMHB4O1xuICBjb2xvcjogI2ZmZjtcbiAgYm9yZGVyLXJhZGl1czogNHB4O1xuICB3aWR0aDogMTAwJTtcbn1cblxuLnBlbmRpbmctdGl0bGUge1xuICBmb250LXNpemU6IDE2cHg7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG4gIGNvbG9yOiAjNjY2NjY2O1xuICBwYWRkaW5nLXRvcDogMXB4O1xuICBtYXJnaW4tYm90dG9tOiA4cHg7XG59XG5cbi5wZW5kaW5nLXRleHQge1xuICBmb250LXNpemU6IDE0cHg7XG4gIG1hcmdpbi1ib3R0b206IDBweDtcbiAgbWFyZ2luLXRvcDogMnB4O1xuICBmb250LXdlaWdodDogNjAwO1xuICBjb2xvcjogI2ZmNmI2Yjtcbn1cblxuLmZ1bGx3aWR0aCB7XG4gIHdpZHRoOiAxMDAlO1xufVxuXG4uc2VjdGlvbi10aXRsZSB7XG4gIGZvbnQtc2l6ZTogMjBweDtcbiAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgbWFyZ2luLWJvdHRvbTogMHB4O1xuICBtYXJnaW4tdG9wOiAxMXB4O1xufVxuXG4uc2l0ZWltYWdlIHtcbiAgZGlzcGxheTogYmxvY2s7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDEwMCU7XG4gIG9iamVjdC1maXQ6IGNvbnRhaW47XG59Il19 */";
    /***/
  },

  /***/
  "./src/app/surveyprocess/surveyprocess.page.ts":
  /*!*****************************************************!*\
    !*** ./src/app/surveyprocess/surveyprocess.page.ts ***!
    \*****************************************************/

  /*! exports provided: QUESTIONTYPE, VIEWMODE, SurveyprocessPage */

  /***/
  function srcAppSurveyprocessSurveyprocessPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "QUESTIONTYPE", function () {
      return QUESTIONTYPE;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "VIEWMODE", function () {
      return VIEWMODE;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SurveyprocessPage", function () {
      return SurveyprocessPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _ionic_native_camera_preview_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic-native/camera-preview/ngx */
    "./node_modules/@ionic-native/camera-preview/ngx/index.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _ionic_native_diagnostic_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @ionic-native/diagnostic/ngx */
    "./node_modules/@ionic-native/diagnostic/ngx/index.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _utilities_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! ../utilities.service */
    "./src/app/utilities.service.ts");
    /* harmony import */


    var _api_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! ../api.service */
    "./src/app/api.service.ts");
    /* harmony import */


    var html2canvas__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
    /*! html2canvas */
    "./node_modules/html2canvas/dist/html2canvas.js");
    /* harmony import */


    var html2canvas__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(html2canvas__WEBPACK_IMPORTED_MODULE_10__);
    /* harmony import */


    var _model_survey_storage_model__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
    /*! ../model/survey-storage.model */
    "./src/app/model/survey-storage.model.ts");
    /* harmony import */


    var _ionic_storage__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
    /*! @ionic/storage */
    "./node_modules/@ionic/storage/fesm2015/ionic-storage.js");
    /* harmony import */


    var _utilities_auto_complete_auto_complete_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(
    /*! ../utilities/auto-complete/auto-complete.component */
    "./src/app/utilities/auto-complete/auto-complete.component.ts");
    /* harmony import */


    var _storage_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(
    /*! ../storage.service */
    "./src/app/storage.service.ts");
    /* harmony import */


    var _ionic_native_insomnia_ngx__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(
    /*! @ionic-native/insomnia/ngx */
    "./node_modules/@ionic-native/insomnia/ngx/index.js");
    /* harmony import */


    var dom_to_image__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(
    /*! dom-to-image */
    "./node_modules/dom-to-image/src/dom-to-image.js");
    /* harmony import */


    var dom_to_image__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(dom_to_image__WEBPACK_IMPORTED_MODULE_16__);

    var QUESTIONTYPE;

    (function (QUESTIONTYPE) {
      QUESTIONTYPE[QUESTIONTYPE["NONE"] = 0] = "NONE";
      QUESTIONTYPE[QUESTIONTYPE["OPTIONS"] = 1] = "OPTIONS";
      QUESTIONTYPE[QUESTIONTYPE["INPUT_NUMBER"] = 2] = "INPUT_NUMBER";
      QUESTIONTYPE[QUESTIONTYPE["INPUT_UTILITIES_AUTOCOMPLETE"] = 3] = "INPUT_UTILITIES_AUTOCOMPLETE";
      QUESTIONTYPE[QUESTIONTYPE["INPUT_INVERTER_AUTOCOMPLETE"] = 4] = "INPUT_INVERTER_AUTOCOMPLETE";
      QUESTIONTYPE[QUESTIONTYPE["INPUT_SHOT_NAME"] = 5] = "INPUT_SHOT_NAME";
      QUESTIONTYPE[QUESTIONTYPE["INPUT_ROOF_MATERIAL_AUTOCOMPLETE"] = 6] = "INPUT_ROOF_MATERIAL_AUTOCOMPLETE";
      QUESTIONTYPE[QUESTIONTYPE["INPUT_TEXT"] = 7] = "INPUT_TEXT";
    })(QUESTIONTYPE || (QUESTIONTYPE = {}));

    var VIEWMODE;

    (function (VIEWMODE) {
      VIEWMODE[VIEWMODE["NONE"] = -1] = "NONE";
      VIEWMODE[VIEWMODE["CAMERA"] = 0] = "CAMERA";
      VIEWMODE[VIEWMODE["FORM"] = 1] = "FORM";
      VIEWMODE[VIEWMODE["MAP"] = 2] = "MAP";
      VIEWMODE[VIEWMODE["GALLERY"] = 3] = "GALLERY";
    })(VIEWMODE || (VIEWMODE = {}));

    var SurveyprocessPage = /*#__PURE__*/function () {
      function SurveyprocessPage(cameraPreview, route, http, diagnostic, navController, alertController, storage, utilitieservice, apiService, changedetectorref, platform, routeroutlet, storageService, insomnia) {
        var _this53 = this;

        _classCallCheck(this, SurveyprocessPage);

        this.cameraPreview = cameraPreview;
        this.route = route;
        this.http = http;
        this.diagnostic = diagnostic;
        this.navController = navController;
        this.alertController = alertController;
        this.storage = storage;
        this.utilitieservice = utilitieservice;
        this.apiService = apiService;
        this.changedetectorref = changedetectorref;
        this.platform = platform;
        this.routeroutlet = routeroutlet;
        this.storageService = storageService;
        this.insomnia = insomnia;
        this.QuestionTypes = QUESTIONTYPE;
        this.ViewModes = VIEWMODE;
        this.slideOpts = {
          speed: 400
        };
        this.sliderIndex = 0;
        this.surveystoreddata = {};
        this.selectedmainmenuindex = 0;
        this.selectedsubmenuindex = 0;
        this.selectedshotindex = 0;
        this.previousmainmenuindex = 0;
        this.previoussubmenuindex = 0;
        this.previousshotindex = 0;
        this.previousviewmode = 0;
        this.viewpendingitems = false;
        this.ispendingitemsmode = false;
        this.iscapturingallowed = true;
        this.currentzoom = 1;
        this.maxzoom = 0;
        this.displayflashrow = false;
        this.hardwareCameraEnabled = true;
        this.issidemenucollapsed = true;
        this.isgallerymenucollapsed = true;
        this.isdataloaded = false;
        this.totalpercent = 0;
        this.shotcompletecount = 0;
        this.totalimagestoupload = 1;
        this.imageuploadindex = 1;
        this.utilities = [];
        this.invertermodels = [];
        this.invertermakes = [];
        this.solarmakes = [];
        this.solarmodels = [];
        this.roofmaterials = [];
        this.equipments = [{
          id: 3,
          name: "MSP",
          color: "#ff0000",
          disabledcolor: "#ff000080",
          enabled: true,
          event: null
        }, {
          id: 4,
          name: "INV",
          color: "#6d9eeb",
          disabledcolor: "#6d9eeb80",
          enabled: true,
          event: null
        }, {
          id: 5,
          name: "BT",
          color: "#ff00ff",
          disabledcolor: "#ff00ff80",
          enabled: true,
          event: null
        }, {
          id: 6,
          name: "GP",
          color: "#00ffff",
          disabledcolor: "#00ffff80",
          enabled: true,
          event: null
        }, {
          id: 7,
          name: "EEQ",
          color: "#ffff00",
          disabledcolor: "#ffff0080",
          enabled: true,
          event: null
        }];
        this.acdisconnectequipment = {
          id: 1,
          name: "ACD",
          color: "#fec412",
          disabledcolor: "#fec41280",
          enabled: true,
          event: null
        };
        this.pvmeterequipment = {
          id: 2,
          name: "PVM",
          color: "#6aa84f",
          disabledcolor: "#6aa84f80",
          enabled: true,
          event: null
        };
        this.surveyid = +this.route.snapshot.paramMap.get('id');
        this.surveytype = this.route.snapshot.paramMap.get('type');
        this.surveycity = this.route.snapshot.paramMap.get('city');
        this.surveystate = this.route.snapshot.paramMap.get('state');
        this.latitude = +this.route.snapshot.paramMap.get('lat');
        this.longitude = +this.route.snapshot.paramMap.get('long');

        if (this.platform.is('ios')) {
          this.platformname = "iphone";
        } else if (this.platform.is('android')) {
          this.platformname = "android";
        } else {
          this.platformname = "other";
        }

        this.platform.backButton.subscribeWithPriority(10, function () {
          console.log('Handler was called!');

          _this53.handleSurveyExit();

          navController.pop();
        });

        if (this.surveytype == "battery") {
          this.totalstepcount = 16;
          this.batteryForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormGroup"]({
            modulemake: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required]),
            modulemodel: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required]),
            invertermake: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required]),
            invertermodel: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required]),
            numberofmodules: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required]),
            additionalnotes: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormControl"]('', []),
            batterybackup: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required]),
            servicefeedsource: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required]),
            mainbreakersize: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required]),
            msprating: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required]),
            msplocation: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required]),
            mspbreaker: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required]),
            utilitymeter: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required]),
            utility: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required]),
            pvinverterlocation: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required]),
            pvmeter: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required]),
            acdisconnect: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required]),
            interconnection: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required]),
            shotname: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormControl"]('', [])
          });
          this.activeForm = this.batteryForm; // this.storage.clear();

          this.storage.get(this.surveyid + '').then(function (data) {
            console.log(data);

            if (data) {
              _this53.mainmenuitems = data.menuitems;
              _this53.totalpercent = data.currentprogress;
              _this53.selectedmainmenuindex = data.selectedmainmenuindex;
              _this53.selectedsubmenuindex = data.selectedsubmenuindex;
              _this53.selectedshotindex = data.selectedshotindex;
              _this53.shotcompletecount = data.shotcompletecount;
              _this53.previousmainmenuindex = data.previousmainmenuindex;
              _this53.previoussubmenuindex = data.previoussubmenuindex;
              _this53.previousshotindex = data.previousshotindex;
              _this53.surveyid = data.surveyid;
              _this53.surveytype = data.surveytype;
              _this53.surveycity = data.city;
              _this53.surveystate = data.state;
              _this53.latitude = data.latitude;
              _this53.longitude = data.longitude; // restore form

              Object.keys(data.formdata).forEach(function (key) {
                var control = null;
                control = _this53.activeForm.get(key);
                control.setValue(data.formdata[key]);
              });
              _this53.isdataloaded = true;

              _this53.handleViewModeSwitch();

              _this53.activeForm.get('invertermake').valueChanges.subscribe(function (val) {
                _this53.getInverterModels(_this53.activeForm.get('invertermake').value.id);
              });

              _this53.activeForm.get('modulemake').valueChanges.subscribe(function (val) {
                _this53.getSolarModels(_this53.activeForm.get('modulemake').value.id);
              });
            } else {
              _this53.http.get("assets/surveyprocessjson/battery.json").subscribe(function (data) {
                _this53.mainmenuitems = JSON.parse(JSON.stringify(data));
                _this53.isdataloaded = true;

                _this53.mainmenuitems.forEach(function (element) {
                  if (element.isactive) {
                    _this53.selectedmainmenuindex = _this53.mainmenuitems.indexOf(element);
                  }
                });

                _this53.activeForm.get('invertermake').valueChanges.subscribe(function (val) {
                  _this53.getInverterModels(_this53.activeForm.get('invertermake').value.id);
                });

                _this53.activeForm.get('modulemake').valueChanges.subscribe(function (val) {
                  _this53.getSolarModels(_this53.activeForm.get('modulemake').value.id);
                });
              });
            }
          });
          this.getSiteLocationGoogleImageFromService();
        } else if (this.surveytype == "pvbattery") {
          this.totalstepcount = 13;
          this.pvbatteryForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormGroup"]({
            msplocation: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required]),
            msprating: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required]),
            mainbreakersize: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required]),
            mspbreaker: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required]),
            utilitymeter: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required]),
            framing: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required]),
            framingsize: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required]),
            distancebetweentworafts: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required]),
            utility: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required]),
            batterybackup: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required]),
            servicefeedsource: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required]),
            interconnection: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required]),
            mountingtype: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required]),
            rooftype: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required]),
            roofmaterial: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required]),
            shotname: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormControl"]('', []),
            additionalnotes: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormControl"]('', [])
          });
          this.activeForm = this.pvbatteryForm; // this.storage.clear();

          this.storage.get(this.surveyid + '').then(function (data) {
            console.log(data);

            if (data) {
              _this53.mainmenuitems = data.menuitems;
              _this53.totalpercent = data.currentprogress;
              _this53.selectedmainmenuindex = data.selectedmainmenuindex;
              _this53.selectedsubmenuindex = data.selectedsubmenuindex;
              _this53.selectedshotindex = data.selectedshotindex;
              _this53.shotcompletecount = data.shotcompletecount;
              _this53.previousmainmenuindex = data.previousmainmenuindex;
              _this53.previoussubmenuindex = data.previoussubmenuindex;
              _this53.previousshotindex = data.previousshotindex;
              _this53.surveyid = data.surveyid;
              _this53.surveytype = data.surveytype;
              _this53.surveycity = data.city;
              _this53.surveystate = data.state;
              _this53.latitude = data.latitude;
              _this53.longitude = data.longitude; // restore form

              Object.keys(data.formdata).forEach(function (key) {
                var control = null;
                control = _this53.activeForm.get(key);
                control.setValue(data.formdata[key]);
              });
              _this53.isdataloaded = true;

              _this53.handleViewModeSwitch();
            } else {
              _this53.http.get("assets/surveyprocessjson/pvbattery.json").subscribe(function (data) {
                _this53.mainmenuitems = JSON.parse(JSON.stringify(data));
                _this53.isdataloaded = true;

                _this53.mainmenuitems.forEach(function (element) {
                  if (element.isactive) {
                    _this53.selectedmainmenuindex = _this53.mainmenuitems.indexOf(element);
                  }
                });
              });
            }
          });
          this.getSiteLocationGoogleImageFromService();
        } else if (this.surveytype == "pv") {}
      }

      _createClass(SurveyprocessPage, [{
        key: "formatDateInBackendFormat",
        value: function formatDateInBackendFormat() {
          var d = new Date();
          var ye = new Intl.DateTimeFormat('en', {
            year: 'numeric'
          }).format(d);
          var mo = new Intl.DateTimeFormat('en', {
            month: '2-digit'
          }).format(d);
          var da = new Intl.DateTimeFormat('en', {
            day: '2-digit'
          }).format(d);
          return "".concat(ye, "-").concat(mo, "-").concat(da);
        }
      }, {
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this54 = this;

          this.routeroutlet.swipeGesture = false; // camera options (Size and location). In the following example, the preview uses the rear camera and display the preview in the back of the webview

          this.cameraPreviewOpts = {
            x: 0,
            y: 0,
            width: window.screen.width,
            height: window.screen.height,
            camera: 'rear',
            tapPhoto: true,
            tapFocus: true,
            previewDrag: true,
            toBack: true,
            alpha: 1
          };
          this.startCamera();
          setTimeout(function () {
            _this54.cameraPreview.getMaxZoom().then(function (value) {
              _this54.maxzoom = value;

              if (_this54.maxzoom > 5) {
                _this54.maxzoom = 5;
              }
            }, function (error) {});
          }, 2000);
        }
      }, {
        key: "ngOnDestroy",
        value: function ngOnDestroy() {
          this.stopCamera();
        }
      }, {
        key: "getUtilities",
        value: function getUtilities() {
          var _this55 = this;

          this.utilitieservice.showLoading('Loading').then(function () {
            _this55.apiService.getUtilities().subscribe(function (response) {
              _this55.utilitieservice.hideLoading().then(function () {
                _this55.utilities = response;

                _this55.changedetectorref.detectChanges();
              });
            }, function (responseError) {
              _this55.utilitieservice.hideLoading().then(function () {
                var error = responseError.error;

                _this55.utilitieservice.errorSnackBar(error.message[0].messages[0].message);
              });
            });
          });
        }
      }, {
        key: "getRoofMaterials",
        value: function getRoofMaterials() {
          var _this56 = this;

          this.utilitieservice.showLoading('Loading').then(function () {
            _this56.apiService.getRoofMaterials().subscribe(function (response) {
              _this56.utilitieservice.hideLoading().then(function () {
                _this56.roofmaterials = response;

                _this56.changedetectorref.detectChanges();
              });
            }, function (responseError) {
              _this56.utilitieservice.hideLoading().then(function () {
                var error = responseError.error;

                _this56.utilitieservice.errorSnackBar(error.message[0].messages[0].message);
              });
            });
          });
        }
      }, {
        key: "getInverterModels",
        value: function getInverterModels(selectedmakeid) {
          var _this57 = this;

          this.utilitieservice.showLoading('Getting inverter models').then(function (success) {
            _this57.apiService.getInverterMade(selectedmakeid).subscribe(function (response) {
              _this57.utilitieservice.hideLoading();

              _this57.invertermodels = response;
            }, function (responseError) {
              _this57.utilitieservice.hideLoading();

              var error = responseError.error;

              _this57.utilitieservice.errorSnackBar(error.message[0].messages[0].message);
            });
          });
        }
      }, {
        key: "getInverterMakes",
        value: function getInverterMakes() {
          var _this58 = this;

          this.utilitieservice.showLoading('Loading').then(function () {
            _this58.apiService.getInverterMake().subscribe(function (response) {
              _this58.utilitieservice.hideLoading().then(function () {
                _this58.invertermakes = response;

                _this58.changedetectorref.detectChanges();
              });
            }, function (responseError) {
              _this58.utilitieservice.hideLoading().then(function () {
                var error = responseError.error;

                _this58.utilitieservice.errorSnackBar(error.message[0].messages[0].message);
              });
            });
          });
        }
      }, {
        key: "getSolarModels",
        value: function getSolarModels(selectedsolarmakeid) {
          var _this59 = this;

          this.utilitieservice.showLoading('Getting solar models').then(function (success) {
            _this59.apiService.getSolarMade(selectedsolarmakeid).subscribe(function (response) {
              _this59.utilitieservice.hideLoading().then(function () {
                _this59.solarmodels = response;
              });
            }, function (responseError) {
              _this59.utilitieservice.hideLoading().then(function () {
                var error = responseError.error;

                _this59.utilitieservice.errorSnackBar(error.message[0].messages[0].message);
              });
            });
          });
        }
      }, {
        key: "getSolarMakes",
        value: function getSolarMakes() {
          var _this60 = this;

          this.utilitieservice.showLoading('Loading').then(function () {
            _this60.apiService.getSolarMake().subscribe(function (response) {
              _this60.utilitieservice.hideLoading().then(function () {
                _this60.solarmakes = response;

                _this60.changedetectorref.detectChanges();

                _this60.getUtilities();
              });
            }, function (responseError) {
              _this60.utilitieservice.hideLoading().then(function () {
                var error = responseError.error;

                _this60.utilitieservice.errorSnackBar(error.message[0].messages[0].message);
              });
            });
          });
        }
      }, {
        key: "dragEnded",
        value: function dragEnded(event, item) {
          item.enabled = false;
          item.event = event;
        }
      }, {
        key: "reverttoOriginalPosition",
        value: function reverttoOriginalPosition(item) {
          item.event.source.element.nativeElement.style.transform = 'none'; // visually reset element to its origin

          var source = item.event.source;
          source._passiveTransform = {
            x: 0,
            y: 0
          };
          item.enabled = true;
        }
      }, {
        key: "toggleSidebar",
        value: function toggleSidebar(isopen) {
          this.isgallerymenucollapsed = true;
          this.issidemenucollapsed = isopen;
        }
      }, {
        key: "toggleGallerybar",
        value: function toggleGallerybar(isopen) {
          this.issidemenucollapsed = true;
          this.isgallerymenucollapsed = isopen;
        }
      }, {
        key: "toggleMainMenuSelection",
        value: function toggleMainMenuSelection(index) {
          var _this61 = this;

          this.issidemenucollapsed = true;
          this.isgallerymenucollapsed = true; //Retaining previous state

          this.previousmainmenuindex = this.selectedmainmenuindex;
          this.previoussubmenuindex = this.selectedsubmenuindex;
          this.previousshotindex = this.selectedshotindex; //Set questionstatus true for question type 5

          if (this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].capturedshots.length > 0 && this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[this.selectedshotindex].questiontype == this.QuestionTypes.INPUT_SHOT_NAME) {
            this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[this.selectedshotindex].questionstatus = true;
            this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[this.selectedshotindex].ispending = false;
          } //Unset previous menu and select new one


          this.mainmenuitems[this.selectedmainmenuindex].isactive = false;
          this.selectedmainmenuindex = index;
          this.mainmenuitems[this.selectedmainmenuindex].isactive = true;

          if (this.mainmenuitems[this.selectedmainmenuindex].children.length > 0) {
            var issubmenuset = false;
            this.mainmenuitems[this.selectedmainmenuindex].children.forEach(function (element) {
              if (element.ispending && !issubmenuset) {
                element.isactive = true;
                issubmenuset = true;
                _this61.selectedsubmenuindex = _this61.mainmenuitems[_this61.selectedmainmenuindex].children.indexOf(element);
                var isshotmenuset = false;
                element.shots.forEach(function (shot) {
                  if (shot.ispending && !isshotmenuset) {
                    shot.isactive = true;
                    isshotmenuset = true;
                    _this61.selectedshotindex = element.shots.indexOf(shot);
                  }
                });
              }
            });
          }

          this.handleViewModeSwitch();
        }
      }, {
        key: "toggleSubMenuSelection",
        value: function toggleSubMenuSelection(index) {
          this.issidemenucollapsed = true;
          this.isgallerymenucollapsed = true;
          this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].isactive = false;
          this.selectedsubmenuindex = index;
          this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].isactive = true;
          this.selectedshotindex = 0;
        }
      }, {
        key: "startCamera",
        value: function startCamera() {
          var _this62 = this;

          if (this.hardwareCameraEnabled) {
            this.diagnostic.requestCameraAuthorization(true).then(function (mode) {
              switch (mode) {
                case _this62.diagnostic.permissionStatus.NOT_REQUESTED:
                  _this62.showCameraDenied();

                  break;

                case _this62.diagnostic.permissionStatus.DENIED_ALWAYS:
                  _this62.showCameraDenied();

                  break;

                case _this62.diagnostic.permissionStatus.DENIED_ONCE:
                  _this62.showCameraDenied();

                  break;

                case _this62.diagnostic.permissionStatus.GRANTED:
                  _this62.startCameraAfterPermission();

                  break;

                case 'authorized_when_in_use':
                  _this62.startCameraAfterPermission();

                  break;
              }
            }, function (error) {});
          } else {
            this.startCameraAfterPermission();
          }
        }
      }, {
        key: "showCameraDenied",
        value: function showCameraDenied() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            var _this63 = this;

            var alert;
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.alertController.create({
                      header: 'Error',
                      subHeader: 'Camera permission denied',
                      buttons: [{
                        text: 'OK',
                        handler: function handler() {
                          _this63.navController.navigateRoot('homepage');
                        }
                      }],
                      backdropDismiss: false
                    });

                  case 2:
                    alert = _context.sent;
                    _context.next = 5;
                    return alert.present();

                  case 5:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "startCameraAfterPermission",
        value: function startCameraAfterPermission() {
          if (this.hardwareCameraEnabled) {
            this.cameraPreview.startCamera(this.cameraPreviewOpts).then(function (res) {}, function (err) {});
          } else {}
        }
      }, {
        key: "stopCamera",
        value: function stopCamera() {
          if (this.hardwareCameraEnabled) {
            this.cameraPreview.stopCamera().then(function (result) {});
          }
        }
      }, {
        key: "switchCamera",
        value: function switchCamera() {
          this.cameraPreview.switchCamera();
        }
      }, {
        key: "changeFlashMode",
        value: function changeFlashMode(flashmode) {
          this.cameraPreview.setFlashMode(flashmode);
          this.displayflashrow = !this.displayflashrow;
        }
      }, {
        key: "changeZoom",
        value: function changeZoom() {
          if (this.currentzoom < this.maxzoom) {
            this.currentzoom = this.currentzoom + 1;
          } else {
            this.currentzoom = 1;
          }

          console.log(this.currentzoom);
          this.cameraPreview.setZoom(this.currentzoom);
        }
      }, {
        key: "takePicture",
        value: function takePicture() {
          var _this64 = this;

          this.issidemenucollapsed = true;
          this.isgallerymenucollapsed = true;

          if (this.hardwareCameraEnabled && this.iscapturingallowed) {
            this.cameraPreview.takePicture({
              width: 0,
              height: 0,
              quality: 0
            }).then(function (photo) {
              _this64.capturedImage = 'data:image/png;base64,' + photo;

              if (!_this64.mainmenuitems[_this64.selectedmainmenuindex].children[_this64.selectedsubmenuindex].allowmultipleshots) {
                var captureshot = {
                  menuindex: _this64.selectedmainmenuindex,
                  submenuindex: _this64.selectedsubmenuindex,
                  shotindex: _this64.selectedshotindex,
                  shotimage: _this64.capturedImage,
                  imagekey: _this64.mainmenuitems[_this64.selectedmainmenuindex].children[_this64.selectedsubmenuindex].shots[_this64.selectedshotindex].imagekey,
                  imagename: _this64.mainmenuitems[_this64.selectedmainmenuindex].children[_this64.selectedsubmenuindex].shots[_this64.selectedshotindex].imagename
                };

                _this64.mainmenuitems[_this64.selectedmainmenuindex].children[_this64.selectedsubmenuindex].capturedshots.push(captureshot);
              } else {
                var captureshot = {
                  menuindex: _this64.selectedmainmenuindex,
                  submenuindex: _this64.selectedsubmenuindex,
                  shotindex: _this64.selectedshotindex,
                  shotimage: _this64.capturedImage,
                  imagekey: _this64.mainmenuitems[_this64.selectedmainmenuindex].children[_this64.selectedsubmenuindex].shots[_this64.selectedshotindex].imagekey,
                  imagename: _this64.mainmenuitems[_this64.selectedmainmenuindex].children[_this64.selectedsubmenuindex].shots[_this64.selectedshotindex].imagename + (_this64.mainmenuitems[_this64.selectedmainmenuindex].children[_this64.selectedsubmenuindex].capturedshots.length + 1)
                };

                _this64.mainmenuitems[_this64.selectedmainmenuindex].children[_this64.selectedsubmenuindex].capturedshots.push(captureshot);
              }

              _this64.mainmenuitems[_this64.selectedmainmenuindex].children[_this64.selectedsubmenuindex].shots[_this64.selectedshotindex].shotstatus = true;

              if (_this64.mainmenuitems[_this64.selectedmainmenuindex].children[_this64.selectedsubmenuindex].shots[_this64.selectedshotindex].questiontype != QUESTIONTYPE.NONE) {
                if (!_this64.mainmenuitems[_this64.selectedmainmenuindex].children[_this64.selectedsubmenuindex].shots[_this64.selectedshotindex].questionstatus) {
                  _this64.mainmenuitems[_this64.selectedmainmenuindex].children[_this64.selectedsubmenuindex].shots[_this64.selectedshotindex].promptquestion = true;
                  _this64.iscapturingallowed = false;

                  if (_this64.mainmenuitems[_this64.selectedmainmenuindex].children[_this64.selectedsubmenuindex].shots[_this64.selectedshotindex].questiontype === QUESTIONTYPE.INPUT_UTILITIES_AUTOCOMPLETE) {
                    _this64.getUtilities();
                  } else if (_this64.mainmenuitems[_this64.selectedmainmenuindex].children[_this64.selectedsubmenuindex].shots[_this64.selectedshotindex].questiontype === QUESTIONTYPE.INPUT_INVERTER_AUTOCOMPLETE) {
                    _this64.getInverterMakes();
                  } else if (_this64.mainmenuitems[_this64.selectedmainmenuindex].children[_this64.selectedsubmenuindex].shots[_this64.selectedshotindex].questiontype === QUESTIONTYPE.INPUT_ROOF_MATERIAL_AUTOCOMPLETE) {
                    _this64.getRoofMaterials();
                  }
                } else {
                  _this64.markShotCompletion(_this64.selectedshotindex);
                }
              } else {
                if (!_this64.mainmenuitems[_this64.selectedmainmenuindex].children[_this64.selectedsubmenuindex].allowmultipleshots) {
                  _this64.mainmenuitems[_this64.selectedmainmenuindex].children[_this64.selectedsubmenuindex].shots[_this64.selectedshotindex].questionstatus = true;

                  _this64.handleMenuSwitch();
                } else {
                  if (!_this64.mainmenuitems[_this64.selectedmainmenuindex].children[_this64.selectedsubmenuindex].shots[_this64.selectedshotindex].questionstatus) {
                    _this64.mainmenuitems[_this64.selectedmainmenuindex].children[_this64.selectedsubmenuindex].shots[_this64.selectedshotindex].questionstatus = true;

                    _this64.markShotCompletion(_this64.selectedshotindex);

                    _this64.updateProgressStatus();
                  }
                }
              }
            }, function (error) {});
          } else {}
        }
      }, {
        key: "handleAnswerSubmission",
        value: function handleAnswerSubmission(result) {
          this.iscapturingallowed = true;
          this.issidemenucollapsed = true;
          this.isgallerymenucollapsed = true;
          this.activeForm.get(this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[this.selectedshotindex].inputformcontrol).setValue(result);
          this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[this.selectedshotindex].result = result;
          this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[this.selectedshotindex].promptquestion = false;
          this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[this.selectedshotindex].questionstatus = true;

          if (this.surveytype == "pvbattery" && this.selectedmainmenuindex == 1 && this.selectedsubmenuindex == 0 && this.selectedshotindex == 0) {
            this.handleGroundShotsVisibility();
          } else if (this.surveytype == "pvbattery" && this.selectedmainmenuindex == 1 && this.selectedsubmenuindex == 0 && this.selectedshotindex == 1) {
            this.handleAtticSectionVisibility();
          }

          this.handleMenuSwitch();
        }
      }, {
        key: "handleGroundShotsVisibility",
        value: function handleGroundShotsVisibility() {
          var mountingtypecontrol = this.activeForm.get("mountingtype");

          if (mountingtypecontrol.value == "both" || mountingtypecontrol.value == "ground") {
            this.mainmenuitems[this.selectedmainmenuindex].children[1].isvisible = true;
            this.mainmenuitems[this.selectedmainmenuindex].children[1].ispending = true;
            this.mainmenuitems[this.selectedmainmenuindex].children[1].shots[0].ispending = true;
            this.mainmenuitems[this.selectedmainmenuindex].children[1].shots[0].shotstatus = false;
          } else {
            this.mainmenuitems[this.selectedmainmenuindex].children[1].isvisible = false;
            this.mainmenuitems[this.selectedmainmenuindex].children[1].ispending = false;
            this.mainmenuitems[this.selectedmainmenuindex].children[1].shots[0].ispending = false;
            this.mainmenuitems[this.selectedmainmenuindex].children[1].shots[0].shotstatus = true;
          }
        }
      }, {
        key: "handleAtticSectionVisibility",
        value: function handleAtticSectionVisibility() {
          var mountingtypecontrol = this.activeForm.get("rooftype");

          if (mountingtypecontrol.value == "both" || mountingtypecontrol.value == "pitch") {
            this.mainmenuitems[2].isvisible = true;
            this.mainmenuitems[2].ispending = true;
            this.mainmenuitems[2].children[0].ispending = true;
            this.mainmenuitems[2].children[0].shots.forEach(function (element) {
              element.ispending = true;
              element.questionstatus = false;
              element.shotstatus = false;
            });
            this.activeForm.get("framing").setValidators([_angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required]);
            this.activeForm.get("framingsize").setValidators([_angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required]);
            this.activeForm.get("distancebetweentworafts").setValidators([_angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required]);
          } else {
            this.mainmenuitems[2].isvisible = false;
            this.mainmenuitems[2].ispending = false;
            this.mainmenuitems[2].children[0].ispending = false;
            this.mainmenuitems[2].children[0].shots.forEach(function (element) {
              element.ispending = false;
              element.questionstatus = true;
              element.shotstatus = true;
            });
            this.activeForm.get("framing").clearValidators();
            this.activeForm.get("framingsize").clearValidators();
            this.activeForm.get("distancebetweentworafts").clearValidators();
          }
        }
      }, {
        key: "handleInputSubmission",
        value: function handleInputSubmission(form) {
          var control = form.get(this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[this.selectedshotindex].inputformcontrol);

          if (control.value != "") {
            this.handleAnswerSubmission(control.value);
          } else {
            control.markAsTouched();
            control.markAsDirty();
          }
        }
      }, {
        key: "handleInputTextSubmission",
        value: function handleInputTextSubmission(form) {
          var control = form.get(this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[this.selectedshotindex].inputformcontrol);

          if (control.value != "") {
            this.handleAnswerSubmission(control.value);
          } else {
            control.markAsTouched();
            control.markAsDirty();
          }
        }
      }, {
        key: "handleShotNameSubmission",
        value: function handleShotNameSubmission(form) {
          var shotnameformcontrol = form.get("shotname");

          if (shotnameformcontrol.value != "") {
            var shots = this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].capturedshots;
            shots[shots.length - 1].imagename = shotnameformcontrol.value;
            this.iscapturingallowed = true;
            this.issidemenucollapsed = true;
            this.isgallerymenucollapsed = true;
            this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[this.selectedshotindex].promptquestion = false;
            form.get("shotname").setValue("");

            if (this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].capturedshots.length == 1) {
              this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].ispending = false;
              this.mainmenuitems[this.selectedmainmenuindex].ispending = false;
              this.updateProgressStatus();
            }
          } else {
            shotnameformcontrol.markAsTouched();
            shotnameformcontrol.markAsDirty();
          }
        }
      }, {
        key: "handleInverterFieldsSubmission",
        value: function handleInverterFieldsSubmission() {
          var invertermakecontrol = this.activeForm.get("invertermake");
          var invertermodelcontrol = this.activeForm.get("invertermodel");

          if (invertermakecontrol.value != "" && invertermodelcontrol.value != "") {
            this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[this.selectedshotindex].promptquestion = false;
            this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[this.selectedshotindex].questionstatus = true;
            this.handleMenuSwitch();
          } else {
            invertermakecontrol.markAsTouched();
            invertermakecontrol.markAsDirty();
            invertermodelcontrol.markAsTouched();
            invertermodelcontrol.markAsDirty();
          }
        }
      }, {
        key: "handleUtilitySubmission",
        value: function handleUtilitySubmission() {
          var utilitycontrol = this.activeForm.get("utility");

          if (utilitycontrol.value != "") {
            this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[this.selectedshotindex].promptquestion = false;
            this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[this.selectedshotindex].questionstatus = true;
            this.handleMenuSwitch();
          } else {
            utilitycontrol.markAsTouched();
            utilitycontrol.markAsDirty();
          }
        }
      }, {
        key: "handleRoofMaterialSubmission",
        value: function handleRoofMaterialSubmission() {
          var roofmaterialcontrol = this.activeForm.get("roofmaterial");

          if (roofmaterialcontrol.value != "") {
            this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].allowmultipleshots = true;
            this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[this.selectedshotindex].promptquestion = false;
            this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[this.selectedshotindex].questionstatus = true;
            this.handleMenuSwitch();
          } else {
            roofmaterialcontrol.markAsTouched();
            roofmaterialcontrol.markAsDirty();
          }
        }
      }, {
        key: "handleSurveyExit",
        value: function handleSurveyExit() {
          this.cameraPreview.stopCamera();
          var data = this.preparesurveystorage();
          data.saved = true;
          this.storage.set(this.surveyid + '', data);
          this.utilitieservice.setDataRefresh(true);
          this.navController.navigateBack('surveyoroverview');
        }
      }, {
        key: "preparesurveystorage",
        value: function preparesurveystorage() {
          var surveyStorageModel = new _model_survey_storage_model__WEBPACK_IMPORTED_MODULE_11__["SurveyStorageModel"]();
          surveyStorageModel.menuitems = this.mainmenuitems;
          surveyStorageModel.currentprogress = this.totalpercent;
          surveyStorageModel.formdata = this.activeForm.value;
          surveyStorageModel.selectedmainmenuindex = this.selectedmainmenuindex;
          surveyStorageModel.selectedsubmenuindex = this.selectedsubmenuindex;
          surveyStorageModel.selectedshotindex = this.selectedshotindex;
          surveyStorageModel.shotcompletecount = this.shotcompletecount;
          surveyStorageModel.previousmainmenuindex = this.previousmainmenuindex;
          surveyStorageModel.previoussubmenuindex = this.previoussubmenuindex;
          surveyStorageModel.previousshotindex = this.previousshotindex;
          surveyStorageModel.surveyid = this.surveyid;
          surveyStorageModel.surveytype = this.surveytype;
          surveyStorageModel.city = this.surveycity;
          surveyStorageModel.state = this.surveystate;
          surveyStorageModel.latitude = this.latitude;
          surveyStorageModel.longitude = this.longitude;
          return surveyStorageModel;
        }
      }, {
        key: "handleExistence",
        value: function handleExistence(doesexist) {
          this.issidemenucollapsed = true;
          this.isgallerymenucollapsed = true;
          this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].isexistencechecked = true;

          if (doesexist) {
            this.activeForm.get(this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].inputformcontrol).setValue(true);
          } else {
            this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots.forEach(function (element) {
              element.ispending = false;
              element.shotstatus = true;
              element.questionstatus = true;
            });
            this.activeForm.get(this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].inputformcontrol).setValue(false);
            this.handleMenuSwitch();
          }
        }
      }, {
        key: "handleMenuSwitch",
        value: function handleMenuSwitch() {
          this.iscapturingallowed = true; //Retaining previous shots

          this.previousmainmenuindex = this.selectedmainmenuindex;
          this.previoussubmenuindex = this.selectedsubmenuindex;
          this.previousshotindex = this.selectedshotindex;

          if (!this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].allowmultipleshots) {
            this.markShotCompletion(this.selectedshotindex);
            this.updateProgressStatus();

            if (this.selectedshotindex < this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots.length - 1) {
              this.selectedshotindex += 1;
            } else {
              if (this.selectedsubmenuindex < this.mainmenuitems[this.selectedmainmenuindex].children.length - 1) {
                this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].isactive = false;
                var nextvisibleitemfound = false;

                for (var index = this.selectedsubmenuindex; index < this.mainmenuitems[this.selectedmainmenuindex].children.length - 1; index++) {
                  var element = this.mainmenuitems[this.selectedmainmenuindex].children[index + 1];

                  if (element.isvisible && !nextvisibleitemfound) {
                    nextvisibleitemfound = true;
                    this.selectedsubmenuindex = index + 1;
                    this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].isactive = true;
                    this.selectedshotindex = 0;
                    this.scrollToSubmenuElement(this.selectedsubmenuindex);
                  }
                }

                if (!nextvisibleitemfound) {
                  if (this.selectedmainmenuindex < this.mainmenuitems.length - 1) {
                    //Unset previous menu and select new one
                    this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].isactive = false;
                    this.mainmenuitems[this.selectedmainmenuindex].isactive = false;
                    var nextvisiblemainitemfound = false;

                    for (var _index = this.selectedmainmenuindex; _index < this.mainmenuitems.length - 1; _index++) {
                      var _element = this.mainmenuitems[_index + 1];

                      if (_element.isvisible && !nextvisiblemainitemfound) {
                        nextvisiblemainitemfound = true;
                        this.selectedmainmenuindex = _index + 1;
                        this.mainmenuitems[this.selectedmainmenuindex].isactive = true;
                        this.selectedshotindex = 0;
                        this.selectedsubmenuindex = 0;
                        this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].isactive = true;
                        this.scrollToMainmenuElement(this.selectedmainmenuindex);
                        this.handleViewModeSwitch();
                      }
                    }
                  }
                }
              } else {
                if (this.selectedmainmenuindex < this.mainmenuitems.length - 1) {
                  //Unset previous menu and select new one
                  this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].isactive = false;
                  this.mainmenuitems[this.selectedmainmenuindex].isactive = false;
                  var nextvisiblemainitemfound = false;

                  for (var _index2 = this.selectedmainmenuindex; _index2 < this.mainmenuitems.length - 1; _index2++) {
                    var _element2 = this.mainmenuitems[_index2 + 1];

                    if (_element2.isvisible && !nextvisiblemainitemfound) {
                      nextvisiblemainitemfound = true;
                      this.selectedmainmenuindex = _index2 + 1;
                      this.mainmenuitems[this.selectedmainmenuindex].isactive = true;
                      this.selectedshotindex = 0;
                      this.selectedsubmenuindex = 0;
                      this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].isactive = true;
                      this.scrollToMainmenuElement(this.selectedmainmenuindex);
                      this.handleViewModeSwitch();
                    }
                  }

                  if (!nextvisiblemainitemfound) {}
                }
              }
            }
          } else {
            if (this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].capturedshots.length > 0) {
              this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[this.selectedshotindex].questionstatus = true;
              this.markShotCompletion(this.selectedshotindex);
              this.updateProgressStatus();
            }
          }
        }
      }, {
        key: "scrollToSubmenuElement",
        value: function scrollToSubmenuElement(index) {
          var el = document.getElementById("submenu" + index);
          var rect = el.getBoundingClientRect(); // scrollLeft as 0px, scrollTop as "topBound"px, move in 800 milliseconds

          this.submenuscroll.nativeElement.scrollLeft = rect.left;
        }
      }, {
        key: "scrollToMainmenuElement",
        value: function scrollToMainmenuElement(index) {
          var el = document.getElementById("mainmenu" + index);
          var rect = el.getBoundingClientRect(); // scrollLeft as 0px, scrollTop as "topBound"px, move in 800 milliseconds

          this.mainscroll.nativeElement.scrollLeft = rect.left;
        }
      }, {
        key: "markShotCompletion",
        value: function markShotCompletion(index) {
          var _this65 = this;

          if (this.mainmenuitems[this.selectedmainmenuindex].children.length > 0) {
            if (this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[index].shotstatus && this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[index].questionstatus) {
              this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[index].ispending = false;
              var ispendingset = false;
              this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].ispending = false;
              this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots.forEach(function (element) {
                if (element.ispending && !ispendingset) {
                  ispendingset = true;
                  _this65.mainmenuitems[_this65.selectedmainmenuindex].children[_this65.selectedsubmenuindex].ispending = true;
                }
              });
              this.markMainMenuCompletion();
            }
          } else {
            this.markMainMenuCompletion();
          }
        }
      }, {
        key: "markMainMenuCompletion",
        value: function markMainMenuCompletion() {
          var _this66 = this;

          var ispendingset = false;

          if (this.mainmenuitems[this.selectedmainmenuindex].children.length > 0) {
            this.mainmenuitems[this.selectedmainmenuindex].ispending = false;
            this.mainmenuitems[this.selectedmainmenuindex].children.forEach(function (element) {
              if (element.ispending && !ispendingset) {
                ispendingset = true;
                _this66.mainmenuitems[_this66.selectedmainmenuindex].ispending = true;
              }
            });
          } else {
            this.mainmenuitems[this.selectedmainmenuindex].ispending = false;
          }
        }
      }, {
        key: "updateProgressStatus",
        value: function updateProgressStatus() {
          this.shotcompletecount += 1;
          this.totalpercent = this.shotcompletecount / this.totalstepcount;
        }
      }, {
        key: "checkProcessCompletion",
        value: function checkProcessCompletion() {
          var _this67 = this;

          var ispendingset = false;
          var checkstatus = true;
          this.mainmenuitems.forEach(function (element) {
            if (element.ispending && !ispendingset) {
              ispendingset = true;
              checkstatus = false;

              _this67.preparePendingItemsList();
            }
          });
          return checkstatus;
        }
      }, {
        key: "preparePendingItemsList",
        value: function preparePendingItemsList() {
          this.pendingmenuitems = [];

          for (var mainindex = 0; mainindex < this.mainmenuitems.length; mainindex++) {
            var element = this.mainmenuitems[mainindex];

            if (element.ispending) {
              if (element.children.length > 0) {
                var menu = {
                  index: mainindex,
                  pendingchilds: [],
                  name: element.name
                };

                for (var childindex = 0; childindex < element.children.length; childindex++) {
                  var child = element.children[childindex];

                  if (child.ispending) {
                    if (child.shots.length > 0) {
                      var childitem = {
                        index: childindex,
                        pendingshots: [],
                        name: child.name
                      };

                      for (var shotindex = 0; shotindex < child.shots.length; shotindex++) {
                        var shot = child.shots[shotindex];

                        if (shot.ispending) {
                          var shotitem = {
                            index: shotindex,
                            name: shot.shotinfo
                          };
                          childitem.pendingshots.push(shotitem);
                        }
                      }

                      menu.pendingchilds.push(childitem);
                    } else {
                      var childitem = {
                        index: childindex,
                        pendingshots: [],
                        name: child.name
                      };
                      menu.pendingchilds.push(childitem);
                    }
                  }
                }

                this.pendingmenuitems.push(menu);
              } else {
                var menu = {
                  index: mainindex,
                  pendingchilds: [],
                  name: element.name
                };
                this.pendingmenuitems.push(menu);
              }
            }
          }
        }
      }, {
        key: "handleCompleteSurveyDataSubmission",
        value: function handleCompleteSurveyDataSubmission() {
          var _this68 = this;

          //Code to save current status
          var data = this.preparesurveystorage();
          data.saved = true;
          this.storage.set(this.surveyid + '', data);
          this.utilitieservice.setDataRefresh(true);
          var isutilitymanualinput = false;

          if (this.activeForm.get("utility").value == null || this.activeForm.get("utility").value == "") {
            if (this.utility.manualinput != "") {
              isutilitymanualinput = true;
              this.activeForm.get("utility").setValue(this.utility.manualinput);
            }
          }

          if (this.activeForm.status == 'INVALID') {
            this.displayIncompleteFormAlert();
          } else {
            this.markMainMenuCompletion();

            if (this.checkProcessCompletion()) {
              this.utilitieservice.showLoading('Saving Survey').then(function () {
                // const isutilityfound = this.utilities.some(el => el.name === this.batteryForm.get("utility").value.name);
                if (isutilitymanualinput) {
                  var _data2 = {
                    name: _this68.utility.manualinput,
                    source: _this68.platformname,
                    lastused: _this68.formatDateInBackendFormat(),
                    city: _this68.surveycity,
                    state: _this68.surveystate,
                    addedby: _this68.storageService.getUserID()
                  };

                  _this68.apiService.addUtility(_data2).subscribe(function (data) {
                    _this68.selectedutilityid = data.id;

                    if (_this68.surveytype == "battery") {
                      _this68.saveFormData();
                    } else if (_this68.surveytype == "pvbattery") {
                      _this68.savePVBatteryFormData();
                    }
                  }, function (error) {
                    _this68.utilitieservice.hideLoading().then(function () {
                      _this68.utilitieservice.errorSnackBar(JSON.stringify(error));
                    });
                  });
                } else {
                  _this68.selectedutilityid = _this68.activeForm.get("utility").value.id;

                  if (_this68.surveytype == "battery") {
                    _this68.saveFormData();
                  } else if (_this68.surveytype == "pvbattery") {
                    _this68.savePVBatteryFormData();
                  }
                }
              });
            } else {
              this.displayAlertForRemainingShots();
            }
          }
        }
      }, {
        key: "saveFormData",
        value: function saveFormData() {
          var _this69 = this;

          var data = {
            modulemake: this.batteryForm.get("modulemake").value.id,
            modulemodel: this.batteryForm.get("modulemodel").value.id,
            invertermake: this.batteryForm.get("invertermake").value.name,
            invertermodel: this.batteryForm.get("invertermodel").value.name,
            numberofmodules: parseInt(this.batteryForm.get("numberofmodules").value),
            additionalnotes: this.batteryForm.get("additionalnotes").value,
            batterybackup: this.batteryForm.get("batterybackup").value,
            servicefeedsource: this.batteryForm.get("servicefeedsource").value,
            mainbreakersize: parseInt(this.batteryForm.get("mainbreakersize").value),
            msprating: parseInt(this.batteryForm.get("msprating").value),
            msplocation: this.batteryForm.get("msplocation").value,
            mspbreaker: this.batteryForm.get("mspbreaker").value,
            utilitymeter: this.batteryForm.get("utilitymeter").value,
            utility: this.selectedutilityid,
            pvinverterlocation: this.batteryForm.get("pvinverterlocation").value,
            pvmeter: JSON.parse(this.batteryForm.get("pvmeter").value),
            acdisconnect: JSON.parse(this.batteryForm.get("acdisconnect").value),
            interconnection: this.batteryForm.get("interconnection").value,
            status: 'surveycompleted'
          };
          this.apiService.updateSurveyForm(data, this.surveyid).subscribe(function (data) {
            _this69.utilitieservice.hideLoading().then(function () {
              _this69.insomnia.keepAwake().then(function () {
                console.log('success');
              }, function () {
                return console.log('error');
              });

              _this69.uploadImagesToServer();
            });
          }, function (error) {
            _this69.utilitieservice.hideLoading().then(function () {
              _this69.utilitieservice.errorSnackBar(JSON.stringify(error));
            });
          });
        }
      }, {
        key: "savePVBatteryFormData",
        value: function savePVBatteryFormData() {
          var _this70 = this;

          var data = {
            msplocation: this.activeForm.get("msplocation").value,
            msprating: parseInt(this.activeForm.get("msprating").value),
            mainbreakersize: parseInt(this.activeForm.get("mainbreakersize").value),
            mspbreaker: this.activeForm.get("mspbreaker").value,
            utilitymeter: this.activeForm.get("utilitymeter").value,
            framing: this.activeForm.get("framing").value,
            framingsize: this.activeForm.get("framingsize").value,
            distancebetweentworafts: this.activeForm.get("distancebetweentworafts").value,
            utility: this.selectedutilityid,
            batterybackup: this.activeForm.get("batterybackup").value,
            servicefeedsource: this.activeForm.get("servicefeedsource").value,
            interconnection: this.activeForm.get("interconnection").value,
            mountingtype: this.activeForm.get("mountingtype").value,
            rooftype: this.activeForm.get("rooftype").value,
            roofmaterial: this.activeForm.get("roofmaterial").value.id,
            additionalnotes: this.activeForm.get("additionalnotes").value,
            status: 'surveycompleted'
          };
          this.apiService.updateSurveyForm(data, this.surveyid).subscribe(function (data) {
            _this70.utilitieservice.hideLoading().then(function () {
              _this70.insomnia.keepAwake().then(function () {
                console.log('success');
              }, function () {
                return console.log('error');
              });

              _this70.uploadImagesToServer();
            });
          }, function (error) {
            _this70.utilitieservice.hideLoading().then(function () {
              _this70.utilitieservice.errorSnackBar(JSON.stringify(error));
            });
          });
        }
      }, {
        key: "displayIncompleteFormAlert",
        value: function displayIncompleteFormAlert() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
            var _this71 = this;

            var error;
            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    error = '';
                    Object.keys(this.activeForm.controls).forEach(function (key) {
                      var control = _this71.activeForm.get(key);

                      if (control.invalid) {
                        if (error !== '') {
                          error = error + '<br/>';
                        }

                        if (control.errors.required === true) {
                          error = error + "Input for field " + key + ' is missing.';
                        }

                        if (control.errors.email === true) {
                          error = error + 'Invalid email';
                        }

                        if (control.errors.error !== null && control.errors.error !== undefined) {
                          error = error + control.errors.error;
                        }
                      }
                    });
                    this.utilitieservice.showAlert(error);

                  case 3:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2, this);
          }));
        }
      }, {
        key: "displayAlertForRemainingShots",
        value: function displayAlertForRemainingShots() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
            var _this72 = this;

            var alert;
            return regeneratorRuntime.wrap(function _callee3$(_context3) {
              while (1) {
                switch (_context3.prev = _context3.next) {
                  case 0:
                    _context3.next = 2;
                    return this.alertController.create({
                      header: 'Incomplete',
                      subHeader: 'Please check list of pending items and try submitting the survey once all required information is filled.',
                      buttons: [{
                        text: 'VIEW PENDING ITEMS',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: function handler() {
                          _this72.viewpendingitems = true;
                          _this72.ispendingitemsmode = true;

                          _this72.cameraPreview.stopCamera();

                          _this72.previousviewmode = _this72.mainmenuitems[_this72.selectedmainmenuindex].viewmode;
                          _this72.previousmainmenuindex = _this72.selectedmainmenuindex;
                          _this72.previoussubmenuindex = _this72.selectedsubmenuindex;
                          _this72.previousshotindex = _this72.selectedshotindex;
                          _this72.mainmenuitems[_this72.selectedmainmenuindex].viewmode = VIEWMODE.NONE;
                        }
                      }],
                      backdropDismiss: false
                    });

                  case 2:
                    alert = _context3.sent;
                    _context3.next = 5;
                    return alert.present();

                  case 5:
                  case "end":
                    return _context3.stop();
                }
              }
            }, _callee3, this);
          }));
        }
      }, {
        key: "uploadImagesToServer",
        value: function uploadImagesToServer() {
          var _this73 = this;

          var imagesArray = [];
          this.mainmenuitems.forEach(function (mainmenu) {
            mainmenu.children.forEach(function (child) {
              child.capturedshots.forEach(function (shot) {
                imagesArray.push(shot);
              });
            });
          });

          if (this.equipmentscanvasimage != "") {
            var captureshot = {
              menuindex: -1,
              submenuindex: -1,
              shotindex: imagesArray.length + 1,
              shotimage: this.equipmentscanvasimage,
              imagekey: "electricalslocation",
              imagename: "electricalslocation"
            };
            imagesArray.push(captureshot);
          }

          this.utilitieservice.showLoading('Uploading Images').then(function () {
            _this73.totalimagestoupload = imagesArray.length;

            _this73.uploadImageByIndex(imagesArray);
          });
        }
      }, {
        key: "uploadImageByIndex",
        value: function uploadImageByIndex(mapOfImages) {
          var _this74 = this;

          if (mapOfImages.length !== 0) {
            var imageToUpload = mapOfImages[0];
            var blob = this.utilitieservice.getBlobFromImageData(imageToUpload.shotimage);
            var filename = '';

            if (imageToUpload.imagename === '') {
              filename = Date.now().toString() + '.png';
            } else {
              filename = imageToUpload.imagename + '.png';
            }

            this.utilitieservice.setLoadingMessage('Uploading ' + this.imageuploadindex + ' of ' + this.totalimagestoupload);
            this.apiService.uploadImage(this.surveyid, imageToUpload.imagekey, blob, filename).subscribe(function (data) {
              _this74.imageuploadindex++;
              mapOfImages.splice(0, 1);

              _this74.uploadImageByIndex(mapOfImages);
            }, function (error) {
              _this74.imageuploadindex++;
              mapOfImages.splice(0, 1);

              _this74.uploadImageByIndex(mapOfImages);
            });
          } else {
            this.utilitieservice.hideLoading().then(function () {
              _this74.utilitieservice.showSuccessModal('Survey have been saved').then(function (modal) {
                modal.present();
                modal.onWillDismiss().then(function (dismissed) {
                  _this74.storage.remove("" + _this74.surveyid);

                  _this74.utilitieservice.sethomepageSurveyRefresh(true);

                  _this74.navController.navigateRoot('surveyoroverview');

                  _this74.insomnia.allowSleepAgain().then(function () {
                    return console.log('success');
                  }, function () {
                    return console.log('error');
                  });
                });
              });
            });
          }
        }
      }, {
        key: "handleViewModeSwitch",
        value: function handleViewModeSwitch() {
          if (this.mainmenuitems[this.selectedmainmenuindex].viewmode == VIEWMODE.CAMERA) {
            this.startCameraAfterPermission();
          } else if (this.mainmenuitems[this.selectedmainmenuindex].viewmode == VIEWMODE.FORM) {
            this.cameraPreview.stopCamera();

            if (this.surveytype == 'battery') {
              this.getSolarMakes();
            } else if (this.surveytype == 'pvbattery') {
              this.getUtilities();
            }
          } else if (this.mainmenuitems[this.selectedmainmenuindex].viewmode == VIEWMODE.MAP) {
            this.cameraPreview.stopCamera();

            if (JSON.parse(this.activeForm.get("acdisconnect").value)) {
              this.equipments.splice(0, 0, this.acdisconnectequipment);
            }

            if (JSON.parse(this.activeForm.get("pvmeter").value)) {
              this.equipments.splice(1, 0, this.pvmeterequipment);
            }
          }
        }
      }, {
        key: "handlePendingItemsSwitch",
        value: function handlePendingItemsSwitch() {
          this.preparePendingItemsList();

          if (this.pendingmenuitems.length > 0) {
            this.ispendingitemsmode = true;
          } else {
            this.ispendingitemsmode = false;
          }

          this.viewpendingitems = true;
          this.cameraPreview.stopCamera();
          this.previousviewmode = this.mainmenuitems[this.selectedmainmenuindex].viewmode;
          this.previousmainmenuindex = this.selectedmainmenuindex;
          this.previoussubmenuindex = this.selectedsubmenuindex;
          this.previousshotindex = this.selectedshotindex;
          this.mainmenuitems[this.selectedmainmenuindex].viewmode = VIEWMODE.NONE;
        }
      }, {
        key: "handlePendingItemsBack",
        value: function handlePendingItemsBack() {
          this.viewpendingitems = false;
          this.startCameraAfterPermission();
          this.selectedmainmenuindex = this.previousmainmenuindex;
          this.selectedsubmenuindex = this.previoussubmenuindex;
          this.selectedshotindex = this.previousshotindex;
          this.mainmenuitems[this.selectedmainmenuindex].viewmode = this.previousviewmode;
          this.mainmenuitems[this.selectedmainmenuindex].isactive = true;
          this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].isactive = true;
        }
      }, {
        key: "handlePendingShotClick",
        value: function handlePendingShotClick(menuindex, childindex, shotindex) {
          this.mainmenuitems[this.previousmainmenuindex].isactive = false;
          this.mainmenuitems[this.previousmainmenuindex].viewmode = this.previousviewmode;

          if (this.mainmenuitems[this.previousmainmenuindex].children.length > 0) {
            this.mainmenuitems[this.previousmainmenuindex].children[this.previoussubmenuindex].isactive = false;
          }

          this.viewpendingitems = false;
          this.startCameraAfterPermission();
          this.selectedmainmenuindex = menuindex;
          this.selectedsubmenuindex = childindex;
          this.selectedshotindex = shotindex;
          this.mainmenuitems[this.selectedmainmenuindex].isactive = true;

          if (this.mainmenuitems[this.selectedmainmenuindex].children.length > 0) {
            this.mainmenuitems[this.selectedmainmenuindex].children[childindex].isactive = true;
          }
        }
      }, {
        key: "handleEquipmentMarkingBack",
        value: function handleEquipmentMarkingBack() {
          this.startCameraAfterPermission();
          this.mainmenuitems[this.selectedmainmenuindex].isactive = false;
          this.selectedmainmenuindex = this.previousmainmenuindex;
          this.selectedsubmenuindex = this.previoussubmenuindex;
          this.selectedshotindex = this.previousshotindex;
          this.mainmenuitems[this.selectedmainmenuindex].isactive = true;
        }
      }, {
        key: "handleEquipmentMarkingSave",
        value: function handleEquipmentMarkingSave() {
          this.handleCanvasImageSaveOfMap();
        }
      }, {
        key: "getSiteLocationGoogleImageFromService",
        value: function getSiteLocationGoogleImageFromService() {
          var _this75 = this;

          this.apiService.getGoogleImage(this.latitude, this.longitude).subscribe(function (data) {
            _this75.createImageFromBlob(data);
          }, function (error) {
            console.log(error);
          });
        }
      }, {
        key: "createImageFromBlob",
        value: function createImageFromBlob(image) {
          var _this76 = this;

          var reader = new FileReader();

          if (image) {
            reader.readAsDataURL(image);
          }

          reader.onloadend = function (e) {
            _this76.sitelocationimage = reader.result;
          };
        }
      }, {
        key: "handleCanvasImageSaveOfMap",
        value: function handleCanvasImageSaveOfMap() {
          var _this77 = this;

          var canvasarea = document.getElementById('canvasarea');

          if (this.platform.is('ios')) {
            html2canvas__WEBPACK_IMPORTED_MODULE_10___default()(canvasarea, {
              width: this.platform.width(),
              height: this.platform.height(),
              scrollX: 0,
              scrollY: 0,
              x: 0
            }).then(function (canvas) {
              _this77.equipmentscanvasimage = canvas.toDataURL('image/jpeg');

              _this77.updateProgressStatus();

              _this77.markShotCompletion(_this77.selectedshotindex);

              _this77.startCameraAfterPermission();

              _this77.mainmenuitems[_this77.selectedmainmenuindex].isactive = false;
              _this77.selectedmainmenuindex = _this77.previousmainmenuindex;
              _this77.selectedsubmenuindex = _this77.previoussubmenuindex;
              _this77.selectedshotindex = _this77.previousshotindex;
              _this77.mainmenuitems[_this77.selectedmainmenuindex].isactive = true;
            });
          } else {
            dom_to_image__WEBPACK_IMPORTED_MODULE_16__["toPng"](canvasarea).then(function (dataUrl) {
              _this77.equipmentscanvasimage = dataUrl;

              _this77.updateProgressStatus();

              _this77.markShotCompletion(_this77.selectedshotindex);

              _this77.startCameraAfterPermission();

              _this77.mainmenuitems[_this77.selectedmainmenuindex].isactive = false;
              _this77.selectedmainmenuindex = _this77.previousmainmenuindex;
              _this77.selectedsubmenuindex = _this77.previoussubmenuindex;
              _this77.selectedshotindex = _this77.previousshotindex;
              _this77.mainmenuitems[_this77.selectedmainmenuindex].isactive = true;
            })["catch"](function (error) {
              console.error('oops, something went wrong!', error);
            });
          }
        }
      }, {
        key: "handleGalleryViewSwitch",
        value: function handleGalleryViewSwitch(shot) {
          var _this78 = this;

          this.stopCamera();
          this.isgallerymenucollapsed = true;
          this.issidemenucollapsed = true;
          this.previousviewmode = this.mainmenuitems[this.selectedmainmenuindex].viewmode;
          this.mainmenuitems[this.selectedmainmenuindex].viewmode = VIEWMODE.GALLERY;
          setTimeout(function () {
            var activeshot = _this78.mainmenuitems[_this78.selectedmainmenuindex].children[_this78.selectedsubmenuindex].capturedshots.indexOf(shot);

            _this78.slider.slideTo(activeshot, 0);
          });
        }
      }, {
        key: "handleGalleryBack",
        value: function handleGalleryBack() {
          this.mainmenuitems[this.selectedmainmenuindex].viewmode = this.previousviewmode;
          this.startCameraAfterPermission();
        }
      }, {
        key: "handleShotDelete",
        value: function handleShotDelete() {
          if (this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].capturedshots.length > 0) {
            if (this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].capturedshots.length == 1) {
              this.sliderIndex = 0;
            }

            this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].capturedshots.splice(this.sliderIndex, 1);
            this.slideDidChange();
          }

          if (this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].capturedshots.length == 0) {
            this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[this.selectedshotindex].shotstatus = false;

            if (this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[this.selectedshotindex].questiontype == QUESTIONTYPE.NONE) {
              this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[this.selectedshotindex].questionstatus = false;
            }

            this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[this.selectedshotindex].ispending = true;
            this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].ispending = true;
            this.handleGalleryBack();
          }
        }
      }, {
        key: "slideDidChange",
        value: function slideDidChange() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
            return regeneratorRuntime.wrap(function _callee4$(_context4) {
              while (1) {
                switch (_context4.prev = _context4.next) {
                  case 0:
                    _context4.next = 2;
                    return this.slider.getActiveIndex();

                  case 2:
                    this.sliderIndex = _context4.sent;
                    return _context4.abrupt("return", Promise.resolve());

                  case 4:
                  case "end":
                    return _context4.stop();
                }
              }
            }, _callee4, this);
          }));
        }
      }, {
        key: "handleFormBack",
        value: function handleFormBack() {
          this.mainmenuitems[this.selectedmainmenuindex].isactive = false;
          this.selectedmainmenuindex = this.previousmainmenuindex;
          this.selectedsubmenuindex = this.previoussubmenuindex;
          this.selectedshotindex = this.previousshotindex;
          this.mainmenuitems[this.selectedmainmenuindex].isactive = true;
          this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].isactive = true;
          this.mainmenuitems[this.selectedmainmenuindex].children[this.selectedsubmenuindex].shots[this.selectedshotindex].isactive = true;
          this.startCameraAfterPermission();
        }
      }]);

      return SurveyprocessPage;
    }();

    SurveyprocessPage.ctorParameters = function () {
      return [{
        type: _ionic_native_camera_preview_ngx__WEBPACK_IMPORTED_MODULE_2__["CameraPreview"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"]
      }, {
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"]
      }, {
        type: _ionic_native_diagnostic_ngx__WEBPACK_IMPORTED_MODULE_6__["Diagnostic"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["NavController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["AlertController"]
      }, {
        type: _ionic_storage__WEBPACK_IMPORTED_MODULE_12__["Storage"]
      }, {
        type: _utilities_service__WEBPACK_IMPORTED_MODULE_8__["UtilitiesService"]
      }, {
        type: _api_service__WEBPACK_IMPORTED_MODULE_9__["ApiService"]
      }, {
        type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["Platform"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonRouterOutlet"]
      }, {
        type: _storage_service__WEBPACK_IMPORTED_MODULE_14__["StorageService"]
      }, {
        type: _ionic_native_insomnia_ngx__WEBPACK_IMPORTED_MODULE_15__["Insomnia"]
      }];
    };

    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('screen', {
      "static": false
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"])], SurveyprocessPage.prototype, "screen", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('slides', {
      "static": false
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonSlides"])], SurveyprocessPage.prototype, "slider", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('utility', {
      "static": false
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _utilities_auto_complete_auto_complete_component__WEBPACK_IMPORTED_MODULE_13__["AutoCompleteComponent"])], SurveyprocessPage.prototype, "utility", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('roofmaterial', {
      "static": false
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _utilities_auto_complete_auto_complete_component__WEBPACK_IMPORTED_MODULE_13__["AutoCompleteComponent"])], SurveyprocessPage.prototype, "roofmaterial", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('mainscroll', {
      "static": false
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)], SurveyprocessPage.prototype, "mainscroll", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('submenuscroll', {
      "static": false
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)], SurveyprocessPage.prototype, "submenuscroll", void 0);
    SurveyprocessPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-surveyprocess',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./surveyprocess.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/surveyprocess/surveyprocess.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./surveyprocess.page.scss */
      "./src/app/surveyprocess/surveyprocess.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_native_camera_preview_ngx__WEBPACK_IMPORTED_MODULE_2__["CameraPreview"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"], _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"], _ionic_native_diagnostic_ngx__WEBPACK_IMPORTED_MODULE_6__["Diagnostic"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["NavController"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["AlertController"], _ionic_storage__WEBPACK_IMPORTED_MODULE_12__["Storage"], _utilities_service__WEBPACK_IMPORTED_MODULE_8__["UtilitiesService"], _api_service__WEBPACK_IMPORTED_MODULE_9__["ApiService"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["Platform"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonRouterOutlet"], _storage_service__WEBPACK_IMPORTED_MODULE_14__["StorageService"], _ionic_native_insomnia_ngx__WEBPACK_IMPORTED_MODULE_15__["Insomnia"]])], SurveyprocessPage);
    /***/
  }
}]);
//# sourceMappingURL=surveyprocess-surveyprocess-module-es5.js.map