function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["homepage-homepage-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/homepage/design/completed/completed.component.html":
  /*!**********************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/homepage/design/completed/completed.component.html ***!
    \**********************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppHomepageDesignCompletedCompletedComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<p>\r\n  completed works!\r\n</p>\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/homepage/design/delivered/delivered.component.html":
  /*!**********************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/homepage/design/delivered/delivered.component.html ***!
    \**********************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppHomepageDesignDeliveredDeliveredComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<p>\r\n  delivered works!\r\n</p>\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/homepage/design/inreview/inreview.component.html":
  /*!********************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/homepage/design/inreview/inreview.component.html ***!
    \********************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppHomepageDesignInreviewInreviewComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<p>\r\n  inreview works!\r\n</p>\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/homepage/design/pending/pending.component.html":
  /*!******************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/homepage/design/pending/pending.component.html ***!
    \******************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppHomepageDesignPendingPendingComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-content>\r\n  <ion-refresher slot=\"fixed\" (ionRefresh)=\"getDesigns($event)\">\r\n    <ion-refresher-content pullingIcon=\"arrow-dropdown\" pullingText=\"Pull down to refresh\" refreshingSpinner=\"lines\"></ion-refresher-content>\r\n  </ion-refresher>\r\n  <ion-grid *ngIf=\"listOfDesignDataHelper.length !== 0\">\r\n    <ion-row *ngFor=\"let item of listOfDesignDataHelper;let i = index\">\r\n        <ion-col size=\"12\" class=\"ion-margin-top\">\r\n                <span class=\"ion-padding\" *ngIf=\"today === item.date\">\r\n                    Today\r\n                  </span>\r\n            <span class=\"ion-padding\" *ngIf=\"today !== item.date\">\r\n                      {{item.date | date: 'dd MMM yyyy'}}\r\n                </span>\r\n        </ion-col>\r\n        <ion-col *ngFor=\"let designData of item.listOfDesigns;let i = index \" size=\"6\">\r\n            <div class=\"ion-no-padding custom-card\" style=\"height: 100%;\">\r\n                <p class=\"customer-name\" [routerLink]=\"['/design-details/',designData.id]\"\r\n                      routerDirection=\"forward\">{{designData.name}}\r\n                      <span class=\"chipdetail\" style=\"background-color: #1289A7;\" [routerLink]=\"['/design-details/',designData.id]\" routerDirection=\"forward\">\r\n                        {{designData.deliverydate | date: 'hh:mm a'}}\r\n                    </span>\r\n            </p>\r\n                <span class=\"customer-email\" [routerLink]=\"['/design-details/',designData.id]\"\r\n                      routerDirection=\"forward\">{{designData.email}}</span>\r\n                <a href=\"tel:{{designData.phonenumber}}\" style=\"text-decoration: none;\" class=\"z-100\">\r\n                    <span class=\"customer-phone\">{{designData.phonenumber}}</span></a>\r\n                <span class=\"customer-address z-100\"\r\n                      (click)=\"openAddressOnMap(designData.address)\">{{(designData.address | slice:0:60) + (designData.address.length > 60 ? '...' : '')}}</span>\r\n\r\n                <ion-row style=\"margin-bottom: 8px;\">\r\n                    <span class=\"chipdetail\" style=\"background-color: #95afc0;\" >Wattmonk</span>\r\n                    <span class=\"chipdetail\" style=\"background-color: #95afc0;\" >{{designData?.formattedjobtype}}</span>\r\n                      <!-- <span class=\"chipdetail\" style=\"background-color: rgb(246, 77, 10);\" *ngIf=\"designData.isoverdue\">Overdue</span> -->\r\n                </ion-row>\r\n                <ion-row class=\"ion-no-margin ion-no-margin\">\r\n                    <ion-col></ion-col>\r\n                    <!-- <ion-col class=\"ion-no-margin ion-no-padding\"> -->\r\n                    <!-- <ion-col class=\"ion-no-margin ion-no-padding\" *ngIf=\"designData.deliverydate == currentDate\"> -->\r\n                        <!-- <ion-button class=\"ion-no-margin ion-no-padding\" fill=\"clear\" [routerLink]=\"['/surveyprocess/' + designData.id + '/' + designData.jobtype + '/' + designData.latitude + '/' + designData.longitude + '/' + designData.city + '/' + designData.state]\"\r\n                        routerDirection=\"forward\">\r\n                            Start Survey\r\n                        </ion-button> -->\r\n                    <!-- </ion-col> -->\r\n                </ion-row>\r\n                <ion-progress-bar [value]=\"designData.totalpercent\" mode=\"ios\" color=\"success\" class=\"progress-bar-height\"></ion-progress-bar>\r\n            </div>\r\n        </ion-col>\r\n    </ion-row>\r\n    <ion-row>\r\n        <ion-col size=\"12\" style=\"height: 100px;\">\r\n        </ion-col>\r\n    </ion-row>\r\n</ion-grid>\r\n\r\n<div *ngIf=\"listOfDesignDataHelper.length === 0\" class=\"h-100 d-flex flex-column align-center justify-center\">\r\n    <ion-img src=\"/assets/images/blank.png\" class=\"placeholder\"></ion-img>\r\n</div>\r\n</ion-content>\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/homepage/homepage.page.html":
  /*!***********************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/homepage/homepage.page.html ***!
    \***********************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppHomepageHomepagePageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-content style=\"position: relative;\">\r\n    <!-- <ion-header class=\"ion-no-border white-bg\" style=\"position: relative;\">\r\n        <ion-toolbar> -->\r\n    <ion-grid>\r\n        <ion-row class=\"ion-align-items-center\">\r\n            <ion-col *ngIf=\"showHome === true\">\r\n                <h1 class=\"ion-no-padding ion-no-margin home\">Home</h1>\r\n            </ion-col>\r\n            <!-- <ion-col *ngIf=\"showSearchBar === true\" >\r\n                <ion-searchbar debounce=\"0\" placeholder=\"home\" class=\"custom\"></ion-searchbar>\r\n            </ion-col> -->\r\n            <ion-col size=\"auto\" *ngIf=\"showHome === true\">\r\n                <div class=\"notification-padding\" (click)=\"searchbar()\">\r\n                    <ion-img src=\"/assets/images/icons8-search.svg\" class=\"notification-icon\"></ion-img>\r\n                </div>\r\n            </ion-col>\r\n            <ion-col size=\"auto\" style=\"position: relative;\">\r\n                <div class=\"notification-padding\" [routerLink]=\"['/profile']\" routerDirection=\"forward\">\r\n                    <ion-img src=\"/assets/images/notification.svg\" class=\"notification-icon\"></ion-img>\r\n                    <!-- <span class=\"badge\">\r\n                                4\r\n                            </span> -->\r\n                </div>\r\n            </ion-col>\r\n        </ion-row>\r\n    </ion-grid>\r\n    <!-- </ion-toolbar> -->\r\n    <!-- </ion-header> -->\r\n    <ion-tabs style=\"margin-top: 52px;\">\r\n        <ion-tab-bar slot=\"top\" class=\"ion-no-border\">\r\n            <ion-tab-button tab=\"design\" *ngIf=\"isUserDesigner\">\r\n                <ion-label>Designs</ion-label>\r\n            </ion-tab-button>\r\n            <ion-tab-button tab=\"survey\" *ngIf=\"isUserSurveyor\">\r\n                <ion-label>Surveys</ion-label>\r\n            </ion-tab-button>\r\n        </ion-tab-bar>\r\n    </ion-tabs>\r\n\r\n    <!-- <ion-tabs style=\"margin-top: 20%;\">\r\n        <ion-tab-bar slot=\"top\">\r\n          <ion-tab-button tab=\"pending\">\r\n            <ion-label>Pending</ion-label>\r\n          </ion-tab-button>\r\n          <ion-tab-button tab=\"completed\">\r\n            <ion-label>Completed</ion-label>\r\n          </ion-tab-button>\r\n          <ion-tab-button tab=\"inreview\">\r\n            <ion-label>Review</ion-label>\r\n          </ion-tab-button>\r\n          <ion-tab-button tab=\"delivered\">\r\n            <ion-label>Delivered</ion-label>\r\n          </ion-tab-button>\r\n        </ion-tab-bar>\r\n      </ion-tabs> -->\r\n\r\n    <ion-grid style=\"position: absolute;\">\r\n        <div class=\"searchbar_div\">\r\n            <ion-grid *ngIf=\"searchDesginItem && searchDesginItem.length !== 0\">\r\n                <ion-row *ngFor=\"let searchitem of searchDesginItem;\" (click)=\"getdesigndata(searchitem)\">\r\n                    <ion-col size=\"2\">\r\n                        <ion-img class=\"profile-icon\" src=\"/assets/images/icons8-checked.svg\"></ion-img>\r\n                    </ion-col>\r\n                    <ion-col size=\"10\" style=\"margin-top: 6px;\">\r\n                        <div style=\"display: flex; justify-content: space-between;\">\r\n                            <span class=\"history-name\">{{searchitem.name}}</span>\r\n                            <span class=\"history-add\">{{searchitem.created_at | date:'dd/MM/yyyy'}}</span>\r\n                        </div>\r\n                        <div>\r\n                              <span class=\"history-add\">\r\n                                {{searchitem.address}}\r\n                              </span>\r\n                        </div>\r\n                        <!-- <div>\r\n                              <span class=\"assign\">\r\n                               desgined assign to.....\r\n                              </span>\r\n                        </div> -->\r\n                    </ion-col>\r\n                </ion-row>\r\n            </ion-grid>\r\n            <ion-grid *ngIf=\"(searchSurveyItem && searchSurveyItem.length !== 0)\">\r\n                <ion-row *ngFor=\"let searchitem of searchSurveyItem\" (click)=\"getdesigndata(searchitem)\">\r\n                    <ion-col size=\"2\">\r\n                        <ion-img class=\"profile-icon\" src=\"/assets/images/icons8-checked.svg\"></ion-img>\r\n                    </ion-col>\r\n                    <ion-col size=\"10\" style=\"margin-top: 6px;\">\r\n                        <div style=\"display: flex; justify-content: space-between;\">\r\n                            <span class=\"history-name\">{{searchitem.name}}</span>\r\n                            <span class=\"history-add\">{{searchitem.created_at | date:'dd/MM/yyyy'}}</span>\r\n                        </div>\r\n                        <div>\r\n                              <span class=\"history-add\">\r\n                                {{searchitem.address}}\r\n                              </span>\r\n                        </div>\r\n                        <!-- <div>\r\n                              <span class=\"assign\">\r\n                               desgined assign to.....\r\n                              </span>\r\n                        </div> -->\r\n                    </ion-col>\r\n                </ion-row>\r\n            </ion-grid>\r\n        </div>\r\n        <div class=\"searchbar_div nodata_div\">\r\n            <ng-template #noDesignandSurvey>\r\n                <ion-grid\r\n                        *ngIf=\"searchbarElement !== '' && (searchSurveyItem && searchSurveyItem.length === 0) && (searchDesginItem && searchDesginItem.length === 0)\">\r\n                    <div class=\"h-100 d-flex flex-column align-center justify-center\">\r\n                        <span>No desgin or survey found</span>\r\n                    </div>\r\n                </ion-grid>\r\n            </ng-template>\r\n        </div>\r\n    </ion-grid>\r\n\r\n</ion-content>\r\n\r\n<ion-footer class=\"ion-no-border white-bg\" *ngIf=\"showFooter\">\r\n    <div class=\"position-relative\">\r\n        <ion-fab horizontal=\"center\" class=\"fab-position position-absolute\" *ngIf=\"isUserSurveyor && isUserDesigner\">\r\n            <ion-fab-button (click)=\"scheduledPage()\" [disabled]='!netSwitch' routerDirection=\"forward\" mode=\"md\">\r\n                <ion-icon name=\"add\"></ion-icon>\r\n            </ion-fab-button>\r\n        </ion-fab>\r\n        <ion-grid class=\"bottom-bar ion-no-margin ion-no-padding\">\r\n            <ion-row>\r\n                <ion-col size=\"6\">\r\n                    <div class=\"tab\">\r\n                        <ion-img src=\"/assets/images/home-outline.svg\" class=\"tab-icon\"></ion-img>\r\n                        <span class=\"tabText\">Home</span>\r\n                    </div>\r\n                </ion-col>\r\n                <!-- <ion-col size=\"4\" [routerLink]=\"['/message']\">\r\n                    <div class=\"tab\">\r\n                        <ion-img src=\"/assets/images/message-outline.svg\" class=\"tab-icon\"></ion-img>\r\n                        <span class=\"tabText\">Messages</span>\r\n                    </div>\r\n                </ion-col> -->\r\n                <ion-col size=\"6\" [routerLink]=\"['/profile']\" routerDirection=\"forward\">\r\n                    <div class=\"tab\">\r\n                        <ion-img src=\"/assets/images/account-outline.svg\" class=\"tab-icon\"></ion-img>\r\n                        <span class=\"tabText\">Profile</span>\r\n                    </div>\r\n                </ion-col>\r\n            </ion-row>\r\n        </ion-grid>\r\n    </div>\r\n\r\n</ion-footer>\r\n\r\n";
    /***/
  },

  /***/
  "./src/app/homepage/design/completed/completed.component.scss":
  /*!********************************************************************!*\
    !*** ./src/app/homepage/design/completed/completed.component.scss ***!
    \********************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppHomepageDesignCompletedCompletedComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2hvbWVwYWdlL2Rlc2lnbi9jb21wbGV0ZWQvY29tcGxldGVkLmNvbXBvbmVudC5zY3NzIn0= */";
    /***/
  },

  /***/
  "./src/app/homepage/design/completed/completed.component.ts":
  /*!******************************************************************!*\
    !*** ./src/app/homepage/design/completed/completed.component.ts ***!
    \******************************************************************/

  /*! exports provided: CompletedComponent */

  /***/
  function srcAppHomepageDesignCompletedCompletedComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CompletedComponent", function () {
      return CompletedComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");

    var CompletedComponent = /*#__PURE__*/function () {
      function CompletedComponent() {
        _classCallCheck(this, CompletedComponent);
      }

      _createClass(CompletedComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }]);

      return CompletedComponent;
    }();

    CompletedComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-completed',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./completed.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/homepage/design/completed/completed.component.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./completed.component.scss */
      "./src/app/homepage/design/completed/completed.component.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])], CompletedComponent);
    /***/
  },

  /***/
  "./src/app/homepage/design/delivered/delivered.component.scss":
  /*!********************************************************************!*\
    !*** ./src/app/homepage/design/delivered/delivered.component.scss ***!
    \********************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppHomepageDesignDeliveredDeliveredComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2hvbWVwYWdlL2Rlc2lnbi9kZWxpdmVyZWQvZGVsaXZlcmVkLmNvbXBvbmVudC5zY3NzIn0= */";
    /***/
  },

  /***/
  "./src/app/homepage/design/delivered/delivered.component.ts":
  /*!******************************************************************!*\
    !*** ./src/app/homepage/design/delivered/delivered.component.ts ***!
    \******************************************************************/

  /*! exports provided: DeliveredComponent */

  /***/
  function srcAppHomepageDesignDeliveredDeliveredComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DeliveredComponent", function () {
      return DeliveredComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");

    var DeliveredComponent = /*#__PURE__*/function () {
      function DeliveredComponent() {
        _classCallCheck(this, DeliveredComponent);
      }

      _createClass(DeliveredComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }]);

      return DeliveredComponent;
    }();

    DeliveredComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-delivered',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./delivered.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/homepage/design/delivered/delivered.component.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./delivered.component.scss */
      "./src/app/homepage/design/delivered/delivered.component.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])], DeliveredComponent);
    /***/
  },

  /***/
  "./src/app/homepage/design/inreview/inreview.component.scss":
  /*!******************************************************************!*\
    !*** ./src/app/homepage/design/inreview/inreview.component.scss ***!
    \******************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppHomepageDesignInreviewInreviewComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2hvbWVwYWdlL2Rlc2lnbi9pbnJldmlldy9pbnJldmlldy5jb21wb25lbnQuc2NzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/homepage/design/inreview/inreview.component.ts":
  /*!****************************************************************!*\
    !*** ./src/app/homepage/design/inreview/inreview.component.ts ***!
    \****************************************************************/

  /*! exports provided: InreviewComponent */

  /***/
  function srcAppHomepageDesignInreviewInreviewComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "InreviewComponent", function () {
      return InreviewComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");

    var InreviewComponent = /*#__PURE__*/function () {
      function InreviewComponent() {
        _classCallCheck(this, InreviewComponent);
      }

      _createClass(InreviewComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }]);

      return InreviewComponent;
    }();

    InreviewComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-inreview',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./inreview.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/homepage/design/inreview/inreview.component.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./inreview.component.scss */
      "./src/app/homepage/design/inreview/inreview.component.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])], InreviewComponent);
    /***/
  },

  /***/
  "./src/app/homepage/design/pending/pending.component.scss":
  /*!****************************************************************!*\
    !*** ./src/app/homepage/design/pending/pending.component.scss ***!
    \****************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppHomepageDesignPendingPendingComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".custom-card {\n  display: flex;\n  flex-direction: column;\n  background: #fff;\n  border-radius: 4px;\n  box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.3);\n  padding: 8px 12px;\n}\n\n.customer-name {\n  font-size: 1em;\n  color: #434343;\n  font-weight: bold;\n  display: table;\n  margin: 0px;\n}\n\n.customer-email {\n  font-size: 0.8em;\n  color: #B4B4B4;\n}\n\n.customer-phone {\n  font-size: 0.8em;\n  color: #4272B9;\n}\n\n.customer-address {\n  margin-top: 16px;\n  margin-bottom: 16px;\n  font-size: 0.8em;\n  color: #4272B9;\n}\n\n.timestamp {\n  font-size: 0.7em;\n}\n\n.chipdetail {\n  display: inline;\n  vertical-align: middle;\n  background-color: #95afc0;\n  font-size: 0.6em;\n  padding: 4px 10px;\n  border-radius: 10px;\n  text-align: center;\n  color: #fff;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaG9tZXBhZ2UvZGVzaWduL3BlbmRpbmcvRjpcXG1vYmlsZWFwcC9zcmNcXGFwcFxcaG9tZXBhZ2VcXGRlc2lnblxccGVuZGluZ1xccGVuZGluZy5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvaG9tZXBhZ2UvZGVzaWduL3BlbmRpbmcvcGVuZGluZy5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGFBQUE7RUFDQSxzQkFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSwwQ0FBQTtFQUNBLGlCQUFBO0FDQ0o7O0FERUU7RUFDRSxjQUFBO0VBQ0EsY0FBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtFQUNBLFdBQUE7QUNDSjs7QURFRTtFQUNFLGdCQUFBO0VBQ0EsY0FBQTtBQ0NKOztBREVFO0VBQ0UsZ0JBQUE7RUFDQSxjQUFBO0FDQ0o7O0FERUU7RUFDRSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0FDQ0o7O0FERUU7RUFDRSxnQkFBQTtBQ0NKOztBREVFO0VBQ0UsZUFBQTtFQUNBLHNCQUFBO0VBQ0EseUJBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7QUNDSiIsImZpbGUiOiJzcmMvYXBwL2hvbWVwYWdlL2Rlc2lnbi9wZW5kaW5nL3BlbmRpbmcuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY3VzdG9tLWNhcmQge1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgICBiYWNrZ3JvdW5kOiAjZmZmO1xyXG4gICAgYm9yZGVyLXJhZGl1czogNHB4O1xyXG4gICAgYm94LXNoYWRvdzogMCAxcHggMnB4IDAgcmdiYSgwLCAwLCAwLCAwLjMpO1xyXG4gICAgcGFkZGluZzogOHB4IDEycHg7XHJcbiAgfVxyXG4gIFxyXG4gIC5jdXN0b21lci1uYW1lIHtcclxuICAgIGZvbnQtc2l6ZTogMWVtO1xyXG4gICAgY29sb3I6ICM0MzQzNDM7XHJcbiAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgIGRpc3BsYXk6dGFibGU7XHJcbiAgICBtYXJnaW46IDBweDtcclxuICB9XHJcbiAgXHJcbiAgLmN1c3RvbWVyLWVtYWlsIHtcclxuICAgIGZvbnQtc2l6ZTogMC44ZW07XHJcbiAgICBjb2xvcjogI0I0QjRCNDtcclxuICB9XHJcbiAgXHJcbiAgLmN1c3RvbWVyLXBob25lIHtcclxuICAgIGZvbnQtc2l6ZTogMC44ZW07XHJcbiAgICBjb2xvcjogIzQyNzJCOTtcclxuICB9XHJcbiAgXHJcbiAgLmN1c3RvbWVyLWFkZHJlc3Mge1xyXG4gICAgbWFyZ2luLXRvcDogMTZweDtcclxuICAgIG1hcmdpbi1ib3R0b206IDE2cHg7XHJcbiAgICBmb250LXNpemU6IDAuOGVtO1xyXG4gICAgY29sb3I6ICM0MjcyQjk7XHJcbiAgfVxyXG4gIFxyXG4gIC50aW1lc3RhbXAge1xyXG4gICAgZm9udC1zaXplOiAwLjdlbTtcclxuICB9XHJcbiAgXHJcbiAgLmNoaXBkZXRhaWx7XHJcbiAgICBkaXNwbGF5OiBpbmxpbmU7XHJcbiAgICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzk1YWZjMDtcclxuICAgIGZvbnQtc2l6ZTogMC42ZW07XHJcbiAgICBwYWRkaW5nOiA0cHggMTBweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBjb2xvcjogI2ZmZjtcclxufSIsIi5jdXN0b20tY2FyZCB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gIGJhY2tncm91bmQ6ICNmZmY7XG4gIGJvcmRlci1yYWRpdXM6IDRweDtcbiAgYm94LXNoYWRvdzogMCAxcHggMnB4IDAgcmdiYSgwLCAwLCAwLCAwLjMpO1xuICBwYWRkaW5nOiA4cHggMTJweDtcbn1cblxuLmN1c3RvbWVyLW5hbWUge1xuICBmb250LXNpemU6IDFlbTtcbiAgY29sb3I6ICM0MzQzNDM7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICBkaXNwbGF5OiB0YWJsZTtcbiAgbWFyZ2luOiAwcHg7XG59XG5cbi5jdXN0b21lci1lbWFpbCB7XG4gIGZvbnQtc2l6ZTogMC44ZW07XG4gIGNvbG9yOiAjQjRCNEI0O1xufVxuXG4uY3VzdG9tZXItcGhvbmUge1xuICBmb250LXNpemU6IDAuOGVtO1xuICBjb2xvcjogIzQyNzJCOTtcbn1cblxuLmN1c3RvbWVyLWFkZHJlc3Mge1xuICBtYXJnaW4tdG9wOiAxNnB4O1xuICBtYXJnaW4tYm90dG9tOiAxNnB4O1xuICBmb250LXNpemU6IDAuOGVtO1xuICBjb2xvcjogIzQyNzJCOTtcbn1cblxuLnRpbWVzdGFtcCB7XG4gIGZvbnQtc2l6ZTogMC43ZW07XG59XG5cbi5jaGlwZGV0YWlsIHtcbiAgZGlzcGxheTogaW5saW5lO1xuICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjOTVhZmMwO1xuICBmb250LXNpemU6IDAuNmVtO1xuICBwYWRkaW5nOiA0cHggMTBweDtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBjb2xvcjogI2ZmZjtcbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/homepage/design/pending/pending.component.ts":
  /*!**************************************************************!*\
    !*** ./src/app/homepage/design/pending/pending.component.ts ***!
    \**************************************************************/

  /*! exports provided: PendingComponent */

  /***/
  function srcAppHomepageDesignPendingPendingComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "PendingComponent", function () {
      return PendingComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var src_app_homepage_design_design_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! src/app/homepage/design/design.component */
    "./src/app/homepage/design/design.component.ts");
    /* harmony import */


    var _ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic-native/launch-navigator/ngx */
    "./node_modules/@ionic-native/launch-navigator/ngx/index.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var src_app_utilities_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! src/app/utilities.service */
    "./src/app/utilities.service.ts");
    /* harmony import */


    var src_app_api_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! src/app/api.service */
    "./src/app/api.service.ts");
    /* harmony import */


    var _ionic_storage__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! @ionic/storage */
    "./node_modules/@ionic/storage/fesm2015/ionic-storage.js"); // import { SurveyStorageModel } from 'src/app/model/survey-storage.model';


    var PendingComponent = /*#__PURE__*/function () {
      function PendingComponent(launchNavigator, datePipe, cdr, utils, storage, apiService) {
        var _this = this;

        _classCallCheck(this, PendingComponent);

        this.launchNavigator = launchNavigator;
        this.datePipe = datePipe;
        this.cdr = cdr;
        this.utils = utils;
        this.storage = storage;
        this.apiService = apiService;
        this.listOfDesignData = [];
        this.listOfDesignDataHelper = [];
        this.currentDate = new Date();
        this.options = {
          start: '',
          app: this.launchNavigator.APP.GOOGLE_MAPS
        };
        var latestDate = new Date();
        this.today = datePipe.transform(latestDate, 'M/dd/yy');
        console.log('date', this.today);

        this.apiService._OnMessageReceivedSubject.subscribe(function (r) {
          console.log('message received! ', r);

          _this.getDesigns();
        });
      }

      _createClass(PendingComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          console.log("ngoninit");
          console.log(this.currentDate.toISOString());
        }
      }, {
        key: "ionViewDidEnter",
        value: function ionViewDidEnter(event) {
          var _this2 = this;

          this.getDesigns(event);
          this.designRefreshSubscription = this.utils.getHomepageDesignRefresh().subscribe(function (result) {
            _this2.getDesigns(null);
          });
          this.dataRefreshSubscription = this.utils.getDataRefresh().subscribe(function (result) {
            if (_this2.listOfDesignData != null && _this2.listOfDesignData.length > 0) {
              _this2.formatDesignData(_this2.listOfDesignData);
            }
          });
        }
      }, {
        key: "getDesigns",
        value: function getDesigns(event) {
          var showLoader = true;

          if (event != null && event !== undefined) {
            showLoader = false;
          }

          this.fetchPendingDesigns(event);
        }
      }, {
        key: "fetchPendingDesigns",
        value: function fetchPendingDesigns(event, showLoader) {
          var _this3 = this;

          this.listOfDesignData = [];
          this.listOfDesignDataHelper = [];
          this.utils.showLoadingWithPullRefreshSupport(showLoader, 'Getting Designs').then(function (success) {
            _this3.apiService.getDesignSurveys("status=designassigned&status=designinprocess").subscribe(function (response) {
              _this3.utils.hideLoadingWithPullRefreshSupport(showLoader).then(function () {
                console.log(response);

                _this3.formatDesignData(response);

                if (event !== null) {
                  event.target.complete();
                }
              });
            }, function (responseError) {
              _this3.utils.hideLoadingWithPullRefreshSupport(showLoader).then(function () {
                if (event !== null) {
                  event.target.complete();
                }

                var error = responseError.error;

                _this3.utils.errorSnackBar(error.message[0].messages[0].message);
              });
            });
          });
        }
      }, {
        key: "openAddressOnMap",
        value: function openAddressOnMap(address) {
          this.launchNavigator.navigate(address, this.options);
        }
      }, {
        key: "formatDesignData",
        value: function formatDesignData(records) {
          var _this4 = this;

          this.listOfDesignData = this.fillinDynamicData(records);
          console.log(this.listOfDesignData);
          var tempData = [];
          this.listOfDesignData.forEach(function (designItem) {
            if (tempData.length === 0) {
              var listOfDesigns = new src_app_homepage_design_design_component__WEBPACK_IMPORTED_MODULE_2__["DesginDataHelper"]();
              listOfDesigns.date = _this4.datePipe.transform(designItem.deliverydate, 'M/d/yy');
              listOfDesigns.listOfDesigns.push(designItem);
              tempData.push(listOfDesigns);
            } else {
              var added = false;
              tempData.forEach(function (designList) {
                if (!added) {
                  if (designList.date === _this4.datePipe.transform(designList.deliverydate, 'M/d/yy')) {
                    designList.listOfDesigns.push(designList);
                    added = true;
                  }
                }
              });

              if (!added) {
                var _listOfDesigns = new src_app_homepage_design_design_component__WEBPACK_IMPORTED_MODULE_2__["DesginDataHelper"]();

                _listOfDesigns.date = _this4.datePipe.transform(designItem.deliverydate, 'M/d/yy');

                _listOfDesigns.listOfDesigns.push(designItem);

                tempData.push(_listOfDesigns);
                added = true;
              }
            }
          });
          this.listOfDesignDataHelper = tempData.sort(function (a, b) {
            var dateA = new Date(a.date).getTime(),
                dateB = new Date(b.date).getTime();
            return dateA - dateB;
          });
          this.cdr.detectChanges();
        }
      }, {
        key: "fillinDynamicData",
        value: function fillinDynamicData(records) {
          var _this5 = this;

          records.forEach(function (element) {
            element.formattedjobtype = _this5.utils.getJobTypeName(element.jobtype);

            _this5.storage.get('' + element.id).then(function (data) {
              console.log(data);

              if (data) {
                element.totalpercent = data.currentprogress;
              } else {
                element.totalpercent = 0;
              }
            });
          });
          return records;
        }
      }]);

      return PendingComponent;
    }();

    PendingComponent.ctorParameters = function () {
      return [{
        type: _ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_3__["LaunchNavigator"]
      }, {
        type: _angular_common__WEBPACK_IMPORTED_MODULE_4__["DatePipe"]
      }, {
        type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"]
      }, {
        type: src_app_utilities_service__WEBPACK_IMPORTED_MODULE_5__["UtilitiesService"]
      }, {
        type: _ionic_storage__WEBPACK_IMPORTED_MODULE_7__["Storage"]
      }, {
        type: src_app_api_service__WEBPACK_IMPORTED_MODULE_6__["ApiService"]
      }];
    };

    PendingComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-pending',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./pending.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/homepage/design/pending/pending.component.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./pending.component.scss */
      "./src/app/homepage/design/pending/pending.component.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_3__["LaunchNavigator"], _angular_common__WEBPACK_IMPORTED_MODULE_4__["DatePipe"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"], src_app_utilities_service__WEBPACK_IMPORTED_MODULE_5__["UtilitiesService"], _ionic_storage__WEBPACK_IMPORTED_MODULE_7__["Storage"], src_app_api_service__WEBPACK_IMPORTED_MODULE_6__["ApiService"]])], PendingComponent);
    /***/
  },

  /***/
  "./src/app/homepage/homepage-routing.module.ts":
  /*!*****************************************************!*\
    !*** ./src/app/homepage/homepage-routing.module.ts ***!
    \*****************************************************/

  /*! exports provided: HomepagePageRoutingModule */

  /***/
  function srcAppHomepageHomepageRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "HomepagePageRoutingModule", function () {
      return HomepagePageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _homepage_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./homepage.page */
    "./src/app/homepage/homepage.page.ts");
    /* harmony import */


    var _design_design_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ./design/design.component */
    "./src/app/homepage/design/design.component.ts");
    /* harmony import */


    var _survey_survey_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./survey/survey.component */
    "./src/app/homepage/survey/survey.component.ts");

    var routes = [{
      path: '',
      component: _homepage_page__WEBPACK_IMPORTED_MODULE_3__["HomepagePage"],
      children: [// { path: 'design', loadChildren: () => import(`./design/design.module`).then(m => m.DesignModule) },
      {
        path: 'design',
        component: _design_design_component__WEBPACK_IMPORTED_MODULE_4__["DesignComponent"]
      }, {
        path: 'survey',
        component: _survey_survey_component__WEBPACK_IMPORTED_MODULE_5__["SurveyComponent"]
      }]
    }];

    var HomepagePageRoutingModule = function HomepagePageRoutingModule() {
      _classCallCheck(this, HomepagePageRoutingModule);
    };

    HomepagePageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], HomepagePageRoutingModule);
    /***/
  },

  /***/
  "./src/app/homepage/homepage.module.ts":
  /*!*********************************************!*\
    !*** ./src/app/homepage/homepage.module.ts ***!
    \*********************************************/

  /*! exports provided: HomepagePageModule */

  /***/
  function srcAppHomepageHomepageModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "HomepagePageModule", function () {
      return HomepagePageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _homepage_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./homepage-routing.module */
    "./src/app/homepage/homepage-routing.module.ts");
    /* harmony import */


    var _homepage_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./homepage.page */
    "./src/app/homepage/homepage.page.ts");
    /* harmony import */


    var _survey_survey_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ./survey/survey.component */
    "./src/app/homepage/survey/survey.component.ts");
    /* harmony import */


    var _design_design_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! ./design/design.component */
    "./src/app/homepage/design/design.component.ts");
    /* harmony import */


    var _ionic_native_diagnostic_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! @ionic-native/diagnostic/ngx */
    "./node_modules/@ionic-native/diagnostic/ngx/index.js");
    /* harmony import */


    var _ionic_native_native_geocoder_ngx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
    /*! @ionic-native/native-geocoder/ngx */
    "./node_modules/@ionic-native/native-geocoder/ngx/index.js");
    /* harmony import */


    var _ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
    /*! @ionic-native/launch-navigator/ngx */
    "./node_modules/@ionic-native/launch-navigator/ngx/index.js");
    /* harmony import */


    var ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
    /*! ion-bottom-drawer */
    "./node_modules/ion-bottom-drawer/fesm2015/ion-bottom-drawer.js");
    /* harmony import */


    var _utilities_utilities_module__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(
    /*! ../utilities/utilities.module */
    "./src/app/utilities/utilities.module.ts");
    /* harmony import */


    var _design_pending_pending_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(
    /*! ./design/pending/pending.component */
    "./src/app/homepage/design/pending/pending.component.ts");
    /* harmony import */


    var _design_completed_completed_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(
    /*! ./design/completed/completed.component */
    "./src/app/homepage/design/completed/completed.component.ts");
    /* harmony import */


    var _design_delivered_delivered_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(
    /*! ./design/delivered/delivered.component */
    "./src/app/homepage/design/delivered/delivered.component.ts");
    /* harmony import */


    var _design_inreview_inreview_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(
    /*! ./design/inreview/inreview.component */
    "./src/app/homepage/design/inreview/inreview.component.ts");
    /* harmony import */


    var _declinepage_declinepage_page__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(
    /*! ../declinepage/declinepage.page */
    "./src/app/declinepage/declinepage.page.ts");
    /* harmony import */


    var _ionic_native_chooser_ngx__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(
    /*! @ionic-native/chooser/ngx */
    "./node_modules/@ionic-native/chooser/ngx/index.js");
    /* harmony import */


    var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(
    /*! @ionic-native/file/ngx */
    "./node_modules/@ionic-native/file/ngx/index.js");
    /* harmony import */


    var _ionic_native_network_ngx__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(
    /*! @ionic-native/network/ngx */
    "./node_modules/@ionic-native/network/ngx/index.js");
    /* harmony import */


    var _email_model_email_model_page__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(
    /*! ../email-model/email-model.page */
    "./src/app/email-model/email-model.page.ts");
    /* harmony import */


    var _shared_shared_module__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(
    /*! ../shared/shared.module */
    "./src/app/shared/shared.module.ts");

    var HomepagePageModule = function HomepagePageModule() {
      _classCallCheck(this, HomepagePageModule);
    };

    HomepagePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      entryComponents: [_declinepage_declinepage_page__WEBPACK_IMPORTED_MODULE_18__["DeclinepagePage"], _email_model_email_model_page__WEBPACK_IMPORTED_MODULE_22__["EmailModelPage"]],
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _homepage_routing_module__WEBPACK_IMPORTED_MODULE_5__["HomepagePageRoutingModule"], ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_12__["IonBottomDrawerModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"], _utilities_utilities_module__WEBPACK_IMPORTED_MODULE_13__["UtilitiesModule"], _shared_shared_module__WEBPACK_IMPORTED_MODULE_23__["SharedModule"]],
      declarations: [_homepage_page__WEBPACK_IMPORTED_MODULE_6__["HomepagePage"], _survey_survey_component__WEBPACK_IMPORTED_MODULE_7__["SurveyComponent"], _design_design_component__WEBPACK_IMPORTED_MODULE_8__["DesignComponent"], _design_pending_pending_component__WEBPACK_IMPORTED_MODULE_14__["PendingComponent"], _design_completed_completed_component__WEBPACK_IMPORTED_MODULE_15__["CompletedComponent"], _design_inreview_inreview_component__WEBPACK_IMPORTED_MODULE_17__["InreviewComponent"], _design_delivered_delivered_component__WEBPACK_IMPORTED_MODULE_16__["DeliveredComponent"], _declinepage_declinepage_page__WEBPACK_IMPORTED_MODULE_18__["DeclinepagePage"]],
      providers: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["DatePipe"], _ionic_native_diagnostic_ngx__WEBPACK_IMPORTED_MODULE_9__["Diagnostic"], _ionic_native_native_geocoder_ngx__WEBPACK_IMPORTED_MODULE_10__["NativeGeocoder"], _ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_11__["LaunchNavigator"], _ionic_native_chooser_ngx__WEBPACK_IMPORTED_MODULE_19__["Chooser"], _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_20__["File"], _ionic_native_network_ngx__WEBPACK_IMPORTED_MODULE_21__["Network"]]
    })], HomepagePageModule);
    /***/
  },

  /***/
  "./src/app/homepage/homepage.page.scss":
  /*!*********************************************!*\
    !*** ./src/app/homepage/homepage.page.scss ***!
    \*********************************************/

  /*! exports provided: default */

  /***/
  function srcAppHomepageHomepagePageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".notification-icon {\n  width: 24px;\n  height: 24px;\n}\n\n.home {\n  font-size: 22px;\n  margin-left: 6px;\n}\n\n.notification-badge {\n  font-size: 10px;\n  margin-left: -15px;\n  margin-top: -20px;\n}\n\n.notification-padding {\n  position: relative;\n  padding: 8px;\n}\n\n.badge {\n  width: 18px;\n  height: 18px;\n  position: absolute;\n  top: 0;\n  right: 0;\n  background: #3c78d8;\n  color: white;\n  box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.5);\n  border-radius: 50%;\n  font-size: 0.5em;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  border: 1px solid white;\n}\n\nion-searchbar.custom {\n  --background: none;\n  --box-shadow: none;\n  background: white;\n  border-radius: 0.5em;\n  box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1);\n  max-height: 40px;\n}\n\n.titleTab {\n  text-align: center;\n  color: #898989;\n}\n\n.titleBorder {\n  width: 70px;\n  border-bottom: 3px solid #D9726D;\n  border-radius: 2px;\n}\n\n.cardText {\n  margin: 0px;\n}\n\n.card_detail {\n  margin: 0px;\n  color: #3960B8;\n}\n\n.search_loc {\n  font-size: 14px;\n  color: #3960B8;\n}\n\n.search_text_div {\n  display: flex;\n  justify-content: space-between;\n}\n\n.survey_div {\n  border: 1px solid #FAE0C3;\n  padding: 6px;\n  background-color: #FAE0C3;\n  border-radius: 5px;\n}\n\n.nodata_div {\n  max-width: 290px !important;\n  width: 290px !important;\n}\n\n.search_text {\n  color: #9E9E9E;\n}\n\n.tab {\n  padding-top: 1em;\n  padding-bottom: 1em;\n  padding-bottom: 1em;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n\n.bottom-bar {\n  margin: 8px;\n  border-radius: 50px;\n  box-shadow: 0 -2px 8px 0 rgba(0, 0, 0, 0.1);\n  border: 2px solid white;\n  background: #FFFAEB;\n}\n\n.tabText {\n  margin-left: 8px;\n  font-size: 1em;\n}\n\n.tab-icon {\n  width: 24px;\n  height: 24px;\n}\n\n.fab-position {\n  bottom: 48px;\n}\n\nion-fab-button {\n  --border-width: 2px;\n  --border-style: solid;\n  --box-shadow: 0 0px 8px 0 rgba(0, 0, 0, 0.3);\n  --border-color: white;\n  --background: #3c78d8;\n}\n\nion-tab-bar {\n  --border: none;\n}\n\nion-tab-button {\n  font-size: 1em;\n  --color: #9E9E9E;\n  --color-selected: #3c78d8;\n}\n\nion-tab-button[aria-selected=true] {\n  border-bottom: 3px solid #3c78d8;\n  border-bottom-left-radius: 2px;\n  border-bottom-right-radius: 2px;\n}\n\n.searchbar_div {\n  box-shadow: 0 4px 3px 0 rgba(0, 0, 0, 0.1);\n  border-radius: 4px;\n  margin-top: -24px;\n  width: 94%;\n  margin-left: 5px;\n  background: white;\n  max-width: 94%;\n}\n\n.profile-icon {\n  width: 50px;\n  height: 50px;\n  margin-right: 3px;\n  margin-left: -7px;\n}\n\n.history-name {\n  font-size: 16px;\n  color: #787574;\n}\n\n.history-add {\n  color: #CFCBCA;\n  font-size: 14px;\n}\n\n.assign {\n  font-size: 14px;\n  color: #878382;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaG9tZXBhZ2UvRjpcXG1vYmlsZWFwcC9zcmNcXGFwcFxcaG9tZXBhZ2VcXGhvbWVwYWdlLnBhZ2Uuc2NzcyIsInNyYy9hcHAvaG9tZXBhZ2UvaG9tZXBhZ2UucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUVBO0VBQ0ksV0FBQTtFQUNBLFlBQUE7QUNESjs7QURJQTtFQUNJLGVBQUE7RUFDQSxnQkFBQTtBQ0RKOztBRElBO0VBQ0ksZUFBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7QUNESjs7QURJQTtFQUNJLGtCQUFBO0VBQ0EsWUFBQTtBQ0RKOztBRElBO0VBQ0ksV0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLE1BQUE7RUFDQSxRQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0VBQ0EsMENBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7RUFDQSx1QkFBQTtBQ0RKOztBRElBO0VBQ0ksa0JBQUE7RUFDQSxrQkFBQTtFQUNBLGlCQUFBO0VBQ0Esb0JBQUE7RUFDQSwwQ0FBQTtFQUNBLGdCQUFBO0FDREo7O0FES0E7RUFDSSxrQkFBQTtFQUNBLGNBQUE7QUNGSjs7QURNQTtFQUNJLFdBQUE7RUFDQSxnQ0FBQTtFQUNBLGtCQUFBO0FDSEo7O0FETUE7RUFDSSxXQUFBO0FDSEo7O0FETUE7RUFDSSxXQUFBO0VBQ0EsY0FBQTtBQ0hKOztBRE1BO0VBQ0ksZUFBQTtFQUNBLGNBQUE7QUNISjs7QURNQTtFQUNJLGFBQUE7RUFDQSw4QkFBQTtBQ0hKOztBRE1BO0VBQ0kseUJBQUE7RUFDQSxZQUFBO0VBQ0EseUJBQUE7RUFDQSxrQkFBQTtBQ0hKOztBRE1BO0VBQ0ksMkJBQUE7RUFDQSx1QkFBQTtBQ0hKOztBRE1BO0VBQ0ksY0FBQTtBQ0hKOztBRGFBO0VBQ0ksZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLG1CQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7QUNWSjs7QURhQTtFQUNJLFdBQUE7RUFDQSxtQkFBQTtFQUNBLDJDQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQ1ZKOztBRGFBO0VBQ0ksZ0JBQUE7RUFDQSxjQUFBO0FDVko7O0FEYUE7RUFDSSxXQUFBO0VBQ0EsWUFBQTtBQ1ZKOztBRGFBO0VBQ0ksWUFBQTtBQ1ZKOztBRGFBO0VBQ0ksbUJBQUE7RUFDQSxxQkFBQTtFQUNBLDRDQUFBO0VBQ0EscUJBQUE7RUFDQSxxQkFBQTtBQ1ZKOztBRGFBO0VBQ0ksY0FBQTtBQ1ZKOztBRGFBO0VBQ0ksY0FBQTtFQUNBLGdCQUFBO0VBQ0EseUJBQUE7QUNWSjs7QURhQTtFQUNJLGdDQUFBO0VBQ0EsOEJBQUE7RUFDQSwrQkFBQTtBQ1ZKOztBRGFBO0VBQ0ksMENBQUE7RUFDQSxrQkFBQTtFQUNBLGlCQUFBO0VBQ0EsVUFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0FDVko7O0FEY0E7RUFDSSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0VBQ0EsaUJBQUE7QUNYSjs7QURlRTtFQUNFLGVBQUE7RUFDQSxjQUFBO0FDWko7O0FEZUU7RUFDRSxjQUFBO0VBQ0UsZUFBQTtBQ1pOOztBRGVFO0VBQ0ksZUFBQTtFQUNBLGNBQUE7QUNaTiIsImZpbGUiOiJzcmMvYXBwL2hvbWVwYWdlL2hvbWVwYWdlLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG5cclxuLm5vdGlmaWNhdGlvbi1pY29uIHtcclxuICAgIHdpZHRoOiAyNHB4O1xyXG4gICAgaGVpZ2h0OiAyNHB4O1xyXG59XHJcblxyXG4uaG9tZXtcclxuICAgIGZvbnQtc2l6ZTogMjJweDtcclxuICAgIG1hcmdpbi1sZWZ0OiA2cHg7XHJcbn1cclxuXHJcbi5ub3RpZmljYXRpb24tYmFkZ2Uge1xyXG4gICAgZm9udC1zaXplOiAxMHB4O1xyXG4gICAgbWFyZ2luLWxlZnQ6IC0xNXB4O1xyXG4gICAgbWFyZ2luLXRvcDogLTIwcHg7XHJcbn1cclxuXHJcbi5ub3RpZmljYXRpb24tcGFkZGluZyB7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICBwYWRkaW5nOiA4cHg7XHJcbn1cclxuXHJcbi5iYWRnZSB7XHJcbiAgICB3aWR0aDogMThweDtcclxuICAgIGhlaWdodDogMThweDtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHRvcDogMDtcclxuICAgIHJpZ2h0OiAwO1xyXG4gICAgYmFja2dyb3VuZDogIzNjNzhkODtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgIGJveC1zaGFkb3c6IDAgMXB4IDNweCAwIHJnYmEoMCwgMCwgMCwgMC41KTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgIGZvbnQtc2l6ZTogMC41ZW07XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgd2hpdGU7XHJcbn1cclxuXHJcbmlvbi1zZWFyY2hiYXIuY3VzdG9tIHtcclxuICAgIC0tYmFja2dyb3VuZDogbm9uZTtcclxuICAgIC0tYm94LXNoYWRvdzogbm9uZTtcclxuICAgIGJhY2tncm91bmQ6IHdoaXRlO1xyXG4gICAgYm9yZGVyLXJhZGl1czogMC41ZW07XHJcbiAgICBib3gtc2hhZG93OiAwIDFweCAzcHggMCByZ2JhKDAsIDAsIDAsIDAuMSk7XHJcbiAgICBtYXgtaGVpZ2h0OiA0MHB4O1xyXG59XHJcblxyXG5cclxuLnRpdGxlVGFiIHtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGNvbG9yOiAjODk4OTg5O1xyXG4gICAgLy8gICAgIGJvcmRlci1ib3R0b206IDJweCBzb2xpZCAjRDk3MjZEO1xyXG59XHJcblxyXG4udGl0bGVCb3JkZXIge1xyXG4gICAgd2lkdGg6IDcwcHg7XHJcbiAgICBib3JkZXItYm90dG9tOiAzcHggc29saWQgI0Q5NzI2RDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDJweDtcclxufVxyXG5cclxuLmNhcmRUZXh0IHtcclxuICAgIG1hcmdpbjogMHB4O1xyXG59XHJcblxyXG4uY2FyZF9kZXRhaWwge1xyXG4gICAgbWFyZ2luOiAwcHg7XHJcbiAgICBjb2xvcjogIzM5NjBCODtcclxufVxyXG5cclxuLnNlYXJjaF9sb2Mge1xyXG4gICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgY29sb3I6ICMzOTYwQjg7XHJcbn1cclxuXHJcbi5zZWFyY2hfdGV4dF9kaXYge1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxufVxyXG5cclxuLnN1cnZleV9kaXYge1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgI0ZBRTBDMztcclxuICAgIHBhZGRpbmc6IDZweDtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNGQUUwQzM7XHJcbiAgICBib3JkZXItcmFkaXVzOiA1cHg7XHJcbn1cclxuXHJcbi5ub2RhdGFfZGl2e1xyXG4gICAgbWF4LXdpZHRoOiAyOTBweCAhaW1wb3J0YW50O1xyXG4gICAgd2lkdGg6IDI5MHB4ICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5zZWFyY2hfdGV4dCB7XHJcbiAgICBjb2xvcjogIzlFOUU5RTtcclxufVxyXG5cclxuLy8uaW9uLXRhYi1iYXIudGFic3R5bGUge1xyXG4vLyAgICAtLWJhY2tncm91bmQ6IG5vbmU7XHJcbi8vICAgIC0tYm94LXNoYWRvdzogbm9uZTtcclxuLy8gICAgYm94LXNoYWRvdzogMCAxcHggM3B4IDAgcmdiYSgwLCAwLCAwLCAwLjUpO1xyXG4vLyAgICBiYWNrZ3JvdW5kOiAjRkZGQUVCO1xyXG4vL31cclxuXHJcbi50YWIge1xyXG4gICAgcGFkZGluZy10b3A6IDFlbTtcclxuICAgIHBhZGRpbmctYm90dG9tOiAxZW07XHJcbiAgICBwYWRkaW5nLWJvdHRvbTogMWVtO1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxufVxyXG5cclxuLmJvdHRvbS1iYXIge1xyXG4gICAgbWFyZ2luOiA4cHg7XHJcbiAgICBib3JkZXItcmFkaXVzOiA1MHB4O1xyXG4gICAgYm94LXNoYWRvdzogMCAtMnB4IDhweCAwIHJnYmEoMCwgMCwgMCwgMC4xKTtcclxuICAgIGJvcmRlcjogMnB4IHNvbGlkIHdoaXRlO1xyXG4gICAgYmFja2dyb3VuZDogI0ZGRkFFQjtcclxufVxyXG5cclxuLnRhYlRleHQge1xyXG4gICAgbWFyZ2luLWxlZnQ6IDhweDtcclxuICAgIGZvbnQtc2l6ZTogMWVtO1xyXG59XHJcblxyXG4udGFiLWljb24ge1xyXG4gICAgd2lkdGg6IDI0cHg7XHJcbiAgICBoZWlnaHQ6IDI0cHg7XHJcbn1cclxuXHJcbi5mYWItcG9zaXRpb24ge1xyXG4gICAgYm90dG9tOiA0OHB4O1xyXG59XHJcblxyXG5pb24tZmFiLWJ1dHRvbiB7XHJcbiAgICAtLWJvcmRlci13aWR0aDogMnB4O1xyXG4gICAgLS1ib3JkZXItc3R5bGU6IHNvbGlkO1xyXG4gICAgLS1ib3gtc2hhZG93OiAwIDBweCA4cHggMCByZ2JhKDAsIDAsIDAsIDAuMyk7XHJcbiAgICAtLWJvcmRlci1jb2xvcjogd2hpdGU7XHJcbiAgICAtLWJhY2tncm91bmQ6ICMzYzc4ZDg7XHJcbn1cclxuXHJcbmlvbi10YWItYmFyIHtcclxuICAgIC0tYm9yZGVyOiBub25lO1xyXG59XHJcblxyXG5pb24tdGFiLWJ1dHRvbiB7XHJcbiAgICBmb250LXNpemU6IDFlbTtcclxuICAgIC0tY29sb3I6ICM5RTlFOUU7XHJcbiAgICAtLWNvbG9yLXNlbGVjdGVkOiAjM2M3OGQ4O1xyXG59XHJcblxyXG5pb24tdGFiLWJ1dHRvblthcmlhLXNlbGVjdGVkPXRydWVdIHtcclxuICAgIGJvcmRlci1ib3R0b206IDNweCBzb2xpZCAjM2M3OGQ4O1xyXG4gICAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogMnB4O1xyXG4gICAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDJweDtcclxufVxyXG5cclxuLnNlYXJjaGJhcl9kaXZ7XHJcbiAgICBib3gtc2hhZG93OiAwIDRweCAzcHggMCByZ2JhKDAsIDAsIDAsIDAuMSk7XHJcbiAgICBib3JkZXItcmFkaXVzOiA0cHg7XHJcbiAgICBtYXJnaW4tdG9wOiAtMjRweDtcclxuICAgIHdpZHRoOiA5NCU7XHJcbiAgICBtYXJnaW4tbGVmdDogNXB4O1xyXG4gICAgYmFja2dyb3VuZDogd2hpdGU7XHJcbiAgICBtYXgtd2lkdGg6IDk0JTtcclxufVxyXG5cclxuXHJcbi5wcm9maWxlLWljb257XHJcbiAgICB3aWR0aDogNTBweDtcclxuICAgIGhlaWdodDogNTBweDtcclxuICAgIG1hcmdpbi1yaWdodDogM3B4O1xyXG4gICAgbWFyZ2luLWxlZnQ6IC03cHg7XHJcbiAgIFxyXG4gIH1cclxuXHJcbiAgLmhpc3RvcnktbmFtZXtcclxuICAgIGZvbnQtc2l6ZTogMTZweDsgXHJcbiAgICBjb2xvcjogIzc4NzU3NDtcclxuICB9XHJcblxyXG4gIC5oaXN0b3J5LWFkZHtcclxuICAgIGNvbG9yOiAjQ0ZDQkNBO1xyXG4gICAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgfVxyXG5cclxuICAuYXNzaWdue1xyXG4gICAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICAgIGNvbG9yOiAjODc4MzgyO1xyXG4gIH1cclxuIiwiLm5vdGlmaWNhdGlvbi1pY29uIHtcbiAgd2lkdGg6IDI0cHg7XG4gIGhlaWdodDogMjRweDtcbn1cblxuLmhvbWUge1xuICBmb250LXNpemU6IDIycHg7XG4gIG1hcmdpbi1sZWZ0OiA2cHg7XG59XG5cbi5ub3RpZmljYXRpb24tYmFkZ2Uge1xuICBmb250LXNpemU6IDEwcHg7XG4gIG1hcmdpbi1sZWZ0OiAtMTVweDtcbiAgbWFyZ2luLXRvcDogLTIwcHg7XG59XG5cbi5ub3RpZmljYXRpb24tcGFkZGluZyB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgcGFkZGluZzogOHB4O1xufVxuXG4uYmFkZ2Uge1xuICB3aWR0aDogMThweDtcbiAgaGVpZ2h0OiAxOHB4O1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogMDtcbiAgcmlnaHQ6IDA7XG4gIGJhY2tncm91bmQ6ICMzYzc4ZDg7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgYm94LXNoYWRvdzogMCAxcHggM3B4IDAgcmdiYSgwLCAwLCAwLCAwLjUpO1xuICBib3JkZXItcmFkaXVzOiA1MCU7XG4gIGZvbnQtc2l6ZTogMC41ZW07XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBib3JkZXI6IDFweCBzb2xpZCB3aGl0ZTtcbn1cblxuaW9uLXNlYXJjaGJhci5jdXN0b20ge1xuICAtLWJhY2tncm91bmQ6IG5vbmU7XG4gIC0tYm94LXNoYWRvdzogbm9uZTtcbiAgYmFja2dyb3VuZDogd2hpdGU7XG4gIGJvcmRlci1yYWRpdXM6IDAuNWVtO1xuICBib3gtc2hhZG93OiAwIDFweCAzcHggMCByZ2JhKDAsIDAsIDAsIDAuMSk7XG4gIG1heC1oZWlnaHQ6IDQwcHg7XG59XG5cbi50aXRsZVRhYiB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgY29sb3I6ICM4OTg5ODk7XG59XG5cbi50aXRsZUJvcmRlciB7XG4gIHdpZHRoOiA3MHB4O1xuICBib3JkZXItYm90dG9tOiAzcHggc29saWQgI0Q5NzI2RDtcbiAgYm9yZGVyLXJhZGl1czogMnB4O1xufVxuXG4uY2FyZFRleHQge1xuICBtYXJnaW46IDBweDtcbn1cblxuLmNhcmRfZGV0YWlsIHtcbiAgbWFyZ2luOiAwcHg7XG4gIGNvbG9yOiAjMzk2MEI4O1xufVxuXG4uc2VhcmNoX2xvYyB7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgY29sb3I6ICMzOTYwQjg7XG59XG5cbi5zZWFyY2hfdGV4dF9kaXYge1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG59XG5cbi5zdXJ2ZXlfZGl2IHtcbiAgYm9yZGVyOiAxcHggc29saWQgI0ZBRTBDMztcbiAgcGFkZGluZzogNnB4O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjRkFFMEMzO1xuICBib3JkZXItcmFkaXVzOiA1cHg7XG59XG5cbi5ub2RhdGFfZGl2IHtcbiAgbWF4LXdpZHRoOiAyOTBweCAhaW1wb3J0YW50O1xuICB3aWR0aDogMjkwcHggIWltcG9ydGFudDtcbn1cblxuLnNlYXJjaF90ZXh0IHtcbiAgY29sb3I6ICM5RTlFOUU7XG59XG5cbi50YWIge1xuICBwYWRkaW5nLXRvcDogMWVtO1xuICBwYWRkaW5nLWJvdHRvbTogMWVtO1xuICBwYWRkaW5nLWJvdHRvbTogMWVtO1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbn1cblxuLmJvdHRvbS1iYXIge1xuICBtYXJnaW46IDhweDtcbiAgYm9yZGVyLXJhZGl1czogNTBweDtcbiAgYm94LXNoYWRvdzogMCAtMnB4IDhweCAwIHJnYmEoMCwgMCwgMCwgMC4xKTtcbiAgYm9yZGVyOiAycHggc29saWQgd2hpdGU7XG4gIGJhY2tncm91bmQ6ICNGRkZBRUI7XG59XG5cbi50YWJUZXh0IHtcbiAgbWFyZ2luLWxlZnQ6IDhweDtcbiAgZm9udC1zaXplOiAxZW07XG59XG5cbi50YWItaWNvbiB7XG4gIHdpZHRoOiAyNHB4O1xuICBoZWlnaHQ6IDI0cHg7XG59XG5cbi5mYWItcG9zaXRpb24ge1xuICBib3R0b206IDQ4cHg7XG59XG5cbmlvbi1mYWItYnV0dG9uIHtcbiAgLS1ib3JkZXItd2lkdGg6IDJweDtcbiAgLS1ib3JkZXItc3R5bGU6IHNvbGlkO1xuICAtLWJveC1zaGFkb3c6IDAgMHB4IDhweCAwIHJnYmEoMCwgMCwgMCwgMC4zKTtcbiAgLS1ib3JkZXItY29sb3I6IHdoaXRlO1xuICAtLWJhY2tncm91bmQ6ICMzYzc4ZDg7XG59XG5cbmlvbi10YWItYmFyIHtcbiAgLS1ib3JkZXI6IG5vbmU7XG59XG5cbmlvbi10YWItYnV0dG9uIHtcbiAgZm9udC1zaXplOiAxZW07XG4gIC0tY29sb3I6ICM5RTlFOUU7XG4gIC0tY29sb3Itc2VsZWN0ZWQ6ICMzYzc4ZDg7XG59XG5cbmlvbi10YWItYnV0dG9uW2FyaWEtc2VsZWN0ZWQ9dHJ1ZV0ge1xuICBib3JkZXItYm90dG9tOiAzcHggc29saWQgIzNjNzhkODtcbiAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogMnB4O1xuICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogMnB4O1xufVxuXG4uc2VhcmNoYmFyX2RpdiB7XG4gIGJveC1zaGFkb3c6IDAgNHB4IDNweCAwIHJnYmEoMCwgMCwgMCwgMC4xKTtcbiAgYm9yZGVyLXJhZGl1czogNHB4O1xuICBtYXJnaW4tdG9wOiAtMjRweDtcbiAgd2lkdGg6IDk0JTtcbiAgbWFyZ2luLWxlZnQ6IDVweDtcbiAgYmFja2dyb3VuZDogd2hpdGU7XG4gIG1heC13aWR0aDogOTQlO1xufVxuXG4ucHJvZmlsZS1pY29uIHtcbiAgd2lkdGg6IDUwcHg7XG4gIGhlaWdodDogNTBweDtcbiAgbWFyZ2luLXJpZ2h0OiAzcHg7XG4gIG1hcmdpbi1sZWZ0OiAtN3B4O1xufVxuXG4uaGlzdG9yeS1uYW1lIHtcbiAgZm9udC1zaXplOiAxNnB4O1xuICBjb2xvcjogIzc4NzU3NDtcbn1cblxuLmhpc3RvcnktYWRkIHtcbiAgY29sb3I6ICNDRkNCQ0E7XG4gIGZvbnQtc2l6ZTogMTRweDtcbn1cblxuLmFzc2lnbiB7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgY29sb3I6ICM4NzgzODI7XG59Il19 */";
    /***/
  },

  /***/
  "./src/app/homepage/homepage.page.ts":
  /*!*******************************************!*\
    !*** ./src/app/homepage/homepage.page.ts ***!
    \*******************************************/

  /*! exports provided: HomepagePage */

  /***/
  function srcAppHomepageHomepagePageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "HomepagePage", function () {
      return HomepagePage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _utilities_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ../utilities.service */
    "./src/app/utilities.service.ts");
    /* harmony import */


    var _api_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../api.service */
    "./src/app/api.service.ts");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _storage_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ../storage.service */
    "./src/app/storage.service.ts");
    /* harmony import */


    var _ionic_native_diagnostic_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @ionic-native/diagnostic/ngx */
    "./node_modules/@ionic-native/diagnostic/ngx/index.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _ionic_native_geolocation_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! @ionic-native/geolocation/ngx */
    "./node_modules/@ionic-native/geolocation/ngx/index.js");
    /* harmony import */


    var _ionic_native_native_geocoder_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! @ionic-native/native-geocoder/ngx */
    "./node_modules/@ionic-native/native-geocoder/ngx/index.js");
    /* harmony import */


    var ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
    /*! ion-bottom-drawer */
    "./node_modules/ion-bottom-drawer/fesm2015/ion-bottom-drawer.js");
    /* harmony import */


    var _cometchat_pro_cordova_ionic_chat__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
    /*! @cometchat-pro/cordova-ionic-chat */
    "./node_modules/@cometchat-pro/cordova-ionic-chat/CometChat.js");
    /* harmony import */


    var _cometchat_pro_cordova_ionic_chat__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_cometchat_pro_cordova_ionic_chat__WEBPACK_IMPORTED_MODULE_11__);
    /* harmony import */


    var _model_constants__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
    /*! ../model/constants */
    "./src/app/model/constants.ts");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _contants__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(
    /*! ../contants */
    "./src/app/contants.ts");
    /* harmony import */


    var _networkdetect_service__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(
    /*! ../networkdetect.service */
    "./src/app/networkdetect.service.ts");

    var HomepagePage = /*#__PURE__*/function () {
      function HomepagePage(utilities, apiService, nativeGeocoder, platform, datePipe, storage, diagnostic, alertController, geolocation, toastController, route, network) {
        _classCallCheck(this, HomepagePage);

        this.utilities = utilities;
        this.apiService = apiService;
        this.nativeGeocoder = nativeGeocoder;
        this.platform = platform;
        this.datePipe = datePipe;
        this.storage = storage;
        this.diagnostic = diagnostic;
        this.alertController = alertController;
        this.geolocation = geolocation;
        this.toastController = toastController;
        this.route = route;
        this.network = network;
        this.ionInput = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.searchQuery = '';
        this.searchbarElement = '';
        this.isUserSurveyor = false;
        this.isUserDesigner = false;
        this.showSearchBar = false;
        this.showHome = true;
        this.showFooter = true; // Geocoder configuration

        this.geoEncoderOptions = {
          useLocale: true,
          maxResults: 5
        };
        this.searchDesginItem = [];
        this.searchSurveyItem = [];
        this.drawerState = ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_10__["DrawerState"].Docked; // this.initializeItems();
        //this.scheduledPage();
      }

      _createClass(HomepagePage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this6 = this;

          this.setupCometChatUser();
          this.requestLocationPermission();
          this.updateUserPushToken();
          this.subscription = this.utilities.getBottomBarHomepage().subscribe(function (value) {
            _this6.showFooter = value;
          });

          if (this.storage.getUser().role.id === _contants__WEBPACK_IMPORTED_MODULE_14__["ROLES"].Surveyor) {
            // surveyor will only see survey tab
            this.isUserSurveyor = true;
            this.isUserDesigner = false;
            this.route.navigate(['homepage/survey']);
          } else if (this.storage.getUser().role.id === _contants__WEBPACK_IMPORTED_MODULE_14__["ROLES"].Designer) {
            // designer will only see design tab
            this.isUserSurveyor = false;
            this.isUserDesigner = true;
            this.route.navigate(['homepage/design']);
          } else if (this.storage.getUser().role.id === _contants__WEBPACK_IMPORTED_MODULE_14__["ROLES"].BD || this.storage.getUser().role.id === _contants__WEBPACK_IMPORTED_MODULE_14__["ROLES"].Admin || this.storage.getUser().role.id === _contants__WEBPACK_IMPORTED_MODULE_14__["ROLES"].ContractorAdmin || this.storage.getUser().role.id === _contants__WEBPACK_IMPORTED_MODULE_14__["ROLES"].ContractorSuperAdmin || this.storage.getUser().role.id === _contants__WEBPACK_IMPORTED_MODULE_14__["ROLES"].SuperAdmin) {
            // admin will see both tabs
            this.isUserSurveyor = true;
            this.isUserDesigner = true;
            this.route.navigate(['homepage/design']);
          }
        }
      }, {
        key: "updateUserPushToken",
        value: function updateUserPushToken() {
          this.apiService.pushtoken(this.storage.getUserID(), {
            "newpushtoken": localStorage.getItem("pushtoken")
          }).subscribe(function (data) {}, function (error) {});
        }
      }, {
        key: "ngOnDestroy",
        value: function ngOnDestroy() {
          this.subscription.unsubscribe();
        }
      }, {
        key: "initializeItems",
        value: function initializeItems() {
          this.items = ['Amsterdam', 'Bogota'];
        }
      }, {
        key: "setupCometChatUser",
        value: function setupCometChatUser() {
          var user = new _cometchat_pro_cordova_ionic_chat__WEBPACK_IMPORTED_MODULE_11__["CometChat"].User(this.storage.getUserID());
          user.setName(this.storage.getUser().firstname + ' ' + this.storage.getUser().lastname);

          _cometchat_pro_cordova_ionic_chat__WEBPACK_IMPORTED_MODULE_11__["CometChat"].createUser(user, _model_constants__WEBPACK_IMPORTED_MODULE_12__["COMET_CHAT_AUTH_KEY"]).then(function (user) {
            console.log('user created', user);
          }, function (error) {
            console.log('error', error);
          });

          _cometchat_pro_cordova_ionic_chat__WEBPACK_IMPORTED_MODULE_11__["CometChat"].login(this.storage.getUserID(), _model_constants__WEBPACK_IMPORTED_MODULE_12__["COMET_CHAT_AUTH_KEY"]).then(function (user) {
            console.log('Login Successful:', {
              user: user
            });
          }, function (error) {
            console.log('Login failed with exception:', {
              error: error
            });
          });
        }
      }, {
        key: "getItems",
        value: function getItems(ev) {
          // Reset items back to all of the items
          this.initializeItems(); // set val to the value of the searchbar

          var val = ev.target.value; // if the value is an empty string don't filter the items

          if (val && val.trim() !== '') {
            this.items = this.items.filter(function (item) {
              return item.toLowerCase().indexOf(val.toLowerCase()) > -1;
            });
          }
        }
      }, {
        key: "searchDesginAndSurvey",
        value: function searchDesginAndSurvey(event) {
          var _this7 = this;

          console.log(event, this.searchbarElement);

          if (this.searchbarElement !== '') {
            this.apiService.searchAllDesgin(this.searchbarElement).subscribe(function (searchModel) {
              // console.log(searchModel);
              _this7.searchDesginItem = [];
              _this7.searchSurveyItem = [];

              if (event.target.value !== '') {
                searchModel.filter(function (element) {
                  if (element.type == 'design') {
                    _this7.searchDesginItem = searchModel; // console.log(this.searchDesginItem);
                  } else {
                    _this7.searchSurveyItem = searchModel;
                  }
                });
                console.log(_this7.searchDesginItem);
              } else {
                _this7.searchDesginItem = [];
                _this7.searchSurveyItem = [];
              }
            }, function (error) {
              console.log(error);
            });
          } else {
            this.route.navigate(['homepage/design']);
          }
        }
      }, {
        key: "getdesigndata",
        value: function getdesigndata() {
          var serchTermData = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {
            'type': ''
          };
          console.log(serchTermData.name);
          this.name = serchTermData.name;
          this.searchbarElement = this.name;

          if (serchTermData.type == 'design') {
            this.route.navigate(['homepage/design'], {
              queryParams: {
                serchTerm: serchTermData.id
              }
            });
          } else if (serchTermData.type == 'survey') {
            this.route.navigate(['homepage/survey'], {
              queryParams: {
                serchTerm: serchTermData.id
              }
            });
          } else {
            this.route.navigate(['homepage/design']);
          }

          this.searchDesginItem = [];
          this.searchSurveyItem = [];
        }
      }, {
        key: "searchbar",
        value: function searchbar() {
          this.route.navigate(['/search-bar1']);
        }
      }, {
        key: "requestLocationPermission",
        value: function requestLocationPermission() {
          var _this8 = this;

          this.platform.ready().then(function () {
            _this8.diagnostic.requestLocationAuthorization(_this8.diagnostic.locationAuthorizationMode.WHEN_IN_USE).then(function (mode) {
              console.log(mode);

              switch (mode) {
                case _this8.diagnostic.permissionStatus.NOT_REQUESTED:
                  // this.goBack();
                  break;

                case _this8.diagnostic.permissionStatus.DENIED_ALWAYS:
                  _this8.showLocationDenied();

                  break;

                case _this8.diagnostic.permissionStatus.DENIED_ONCE:
                  // this.goBack();
                  break;

                case _this8.diagnostic.permissionStatus.GRANTED:
                  _this8.fetchLocation();

                  break;

                case _this8.diagnostic.permissionStatus.GRANTED_WHEN_IN_USE:
                  _this8.fetchLocation();

                  break;

                case 'authorized_when_in_use':
                  _this8.fetchLocation();

                  break;
              }
            }, function (rejection) {
              console.log(rejection);
            });
          });
        }
      }, {
        key: "showLocationDenied",
        value: function showLocationDenied() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            var toast;
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.toastController.create({
                      header: 'Error',
                      message: 'Location services denied, please enable them manually',
                      cssClass: 'my-custom-class',
                      buttons: [{
                        text: 'OK',
                        handler: function handler() {}
                      }]
                    });

                  case 2:
                    toast = _context.sent;
                    toast.present();

                  case 4:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "fetchLocation",
        value: function fetchLocation() {
          var _this9 = this;

          this.diagnostic.isGpsLocationEnabled().then(function (status) {
            if (status === true) {
              // this.utilities.showLoading('Getting Location').then(() => {
              _this9.getGeoLocation(); // });

            } else {
              _this9.askToChangeSettings();
            }
          });
        }
      }, {
        key: "askToChangeSettings",
        value: function askToChangeSettings() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
            var _this10 = this;

            var toast;
            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    _context2.next = 2;
                    return this.toastController.create({
                      header: 'Location Disabled',
                      message: 'Please enable location services',
                      cssClass: 'my-custom-class',
                      buttons: [{
                        text: 'OK',
                        handler: function handler() {
                          _this10.changeLocationSettings();
                        }
                      }, {
                        text: 'Cancel',
                        handler: function handler() {}
                      }]
                    });

                  case 2:
                    toast = _context2.sent;
                    toast.present();

                  case 4:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2, this);
          }));
        }
      }, {
        key: "getGeoLocation",
        value: function getGeoLocation() {
          var _this11 = this;

          this.geolocation.getCurrentPosition().then(function (resp) {
            console.log('resp', resp);

            _this11.getGeoEncoder(resp.coords.latitude, resp.coords.longitude);
          })["catch"](function (error) {
            _this11.utilities.errorSnackBar('Unable to get location');

            console.log('Error getting location', error);

            _this11.showNoLocation();
          });
        }
      }, {
        key: "getGeoEncoder",
        value: function getGeoEncoder(latitude, longitude) {
          var _this12 = this;

          // this.utilities.hideLoading().then((success) => {
          this.nativeGeocoder.reverseGeocode(latitude, longitude, this.geoEncoderOptions).then(function (result) {
            console.log('resu', result);
            var address = {
              address: _this12.generateAddress(result[0]),
              lat: latitude,
              "long": longitude,
              country: result[0].countryName,
              state: result[0].administrativeArea,
              city: result[0].locality,
              postalcode: result[0].postalCode
            };

            _this12.utilities.setAddress(address);
          })["catch"](function (error) {
            _this12.showNoLocation();

            alert('Error getting location' + JSON.stringify(error));
          });
        }
      }, {
        key: "generateAddress",
        value: function generateAddress(addressObj) {
          var obj = [];
          var address = '';

          for (var key in addressObj) {
            obj.push(addressObj[key]);
          }

          obj.reverse();

          for (var val in obj) {
            if (obj[val].length) {
              address += obj[val] + ', ';
            }
          }

          return address.slice(0, -2);
        }
      }, {
        key: "changeLocationSettings",
        value: function changeLocationSettings() {
          var _this13 = this;

          this.diagnostic.switchToLocationSettings();
          this.diagnostic.registerLocationStateChangeHandler(function (state) {
            console.log(state);

            if (_this13.platform.is('android') && state !== _this13.diagnostic.locationMode.LOCATION_OFF) {
              _this13.checkLocationAccess();
            }
          });
        }
      }, {
        key: "checkLocationAccess",
        value: function checkLocationAccess() {
          var _this14 = this;

          console.log('Getting location');
          this.diagnostic.isLocationAuthorized().then(function (success) {
            _this14.fetchLocation();
          }, function (error) {
            _this14.utilities.errorSnackBar('GPS Not Allowed');
          });
        }
      }, {
        key: "showNoLocation",
        value: function showNoLocation() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
            var alert;
            return regeneratorRuntime.wrap(function _callee3$(_context3) {
              while (1) {
                switch (_context3.prev = _context3.next) {
                  case 0:
                    _context3.next = 2;
                    return this.alertController.create({
                      header: 'Error',
                      subHeader: 'Unable to get location',
                      buttons: [{
                        text: 'OK',
                        handler: function handler() {// this.goBack();
                        }
                      }],
                      backdropDismiss: false
                    });

                  case 2:
                    alert = _context3.sent;
                    _context3.next = 5;
                    return alert.present();

                  case 5:
                  case "end":
                    return _context3.stop();
                }
              }
            }, _callee3, this);
          }));
        }
      }, {
        key: "ionViewDidEnter",
        value: function ionViewDidEnter() {
          var _this15 = this;

          this.network.networkSwitch.subscribe(function (data) {
            _this15.netSwitch = data;
            console.log(_this15.netSwitch);
          });
          this.network.networkDisconnect();
          this.network.networkConnect();
          this.subscription = this.platform.backButton.subscribe(function () {
            if (_this15.showSearchBar === true) {
              _this15.showSearchBar = false;
            } else {
              navigator.app.exitApp();
            }
          });
        }
      }, {
        key: "ionViewWillLeave",
        value: function ionViewWillLeave() {
          this.subscription.unsubscribe();
        }
      }, {
        key: "scheduledPage",
        value: function scheduledPage() {
          if (this.route.url == '/homepage/design') {
            this.route.navigate(['/schedule/design']);
          } else {
            this.route.navigate(['/schedule/survey']);
          }
        }
      }, {
        key: "showHom",
        value: function showHom() {
          this.showHome = true;
          this.showSearchBar = false;
          this.searchSurveyItem = [];
          this.searchDesginItem = [];
          this.searchbarElement = '';
          this.getdesigndata();
        }
      }, {
        key: "onClick",
        value: function onClick() {
          this.showHome = false;
          this.showSearchBar = true;
        }
      }]);

      return HomepagePage;
    }();

    HomepagePage.ctorParameters = function () {
      return [{
        type: _utilities_service__WEBPACK_IMPORTED_MODULE_2__["UtilitiesService"]
      }, {
        type: _api_service__WEBPACK_IMPORTED_MODULE_3__["ApiService"]
      }, {
        type: _ionic_native_native_geocoder_ngx__WEBPACK_IMPORTED_MODULE_9__["NativeGeocoder"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["Platform"]
      }, {
        type: _angular_common__WEBPACK_IMPORTED_MODULE_4__["DatePipe"]
      }, {
        type: _storage_service__WEBPACK_IMPORTED_MODULE_5__["StorageService"]
      }, {
        type: _ionic_native_diagnostic_ngx__WEBPACK_IMPORTED_MODULE_6__["Diagnostic"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["AlertController"]
      }, {
        type: _ionic_native_geolocation_ngx__WEBPACK_IMPORTED_MODULE_8__["Geolocation"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["ToastController"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_13__["Router"]
      }, {
        type: _networkdetect_service__WEBPACK_IMPORTED_MODULE_15__["NetworkdetectService"]
      }];
    };

    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)], HomepagePage.prototype, "ionInput", void 0);
    HomepagePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-homepage',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./homepage.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/homepage/homepage.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./homepage.page.scss */
      "./src/app/homepage/homepage.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_utilities_service__WEBPACK_IMPORTED_MODULE_2__["UtilitiesService"], _api_service__WEBPACK_IMPORTED_MODULE_3__["ApiService"], _ionic_native_native_geocoder_ngx__WEBPACK_IMPORTED_MODULE_9__["NativeGeocoder"], _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["Platform"], _angular_common__WEBPACK_IMPORTED_MODULE_4__["DatePipe"], _storage_service__WEBPACK_IMPORTED_MODULE_5__["StorageService"], _ionic_native_diagnostic_ngx__WEBPACK_IMPORTED_MODULE_6__["Diagnostic"], _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["AlertController"], _ionic_native_geolocation_ngx__WEBPACK_IMPORTED_MODULE_8__["Geolocation"], _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["ToastController"], _angular_router__WEBPACK_IMPORTED_MODULE_13__["Router"], _networkdetect_service__WEBPACK_IMPORTED_MODULE_15__["NetworkdetectService"]])], HomepagePage);
    /***/
  }
}]);
//# sourceMappingURL=homepage-homepage-module-es5.js.map