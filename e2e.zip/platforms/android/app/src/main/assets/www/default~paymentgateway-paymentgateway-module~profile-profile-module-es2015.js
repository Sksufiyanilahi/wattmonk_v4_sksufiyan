(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~paymentgateway-paymentgateway-module~profile-profile-module"],{

/***/ "./node_modules/ngx-paypal/fesm2015/ngx-paypal.js":
/*!********************************************************!*\
  !*** ./node_modules/ngx-paypal/fesm2015/ngx-paypal.js ***!
  \********************************************************/
/*! exports provided: NgxPayPalModule, PayPalEnvironment, PayPalFunding, PayPalIntegrationType, PayPalConfig, NgxPaypalComponent, ɵa */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NgxPayPalModule", function() { return NgxPayPalModule; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PayPalEnvironment", function() { return PayPalEnvironment; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PayPalFunding", function() { return PayPalFunding; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PayPalIntegrationType", function() { return PayPalIntegrationType; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PayPalConfig", function() { return PayPalConfig; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NgxPaypalComponent", function() { return NgxPaypalComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵa", function() { return NgxPaypalComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");




/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
/** @enum {number} */
const PayPalFunding = {
    Card: 0,
    Credit: 1,
    Elv: 2,
};
PayPalFunding[PayPalFunding.Card] = 'Card';
PayPalFunding[PayPalFunding.Credit] = 'Credit';
PayPalFunding[PayPalFunding.Elv] = 'Elv';

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
/** @enum {number} */
const PayPalIntegrationType = {
    ClientSideREST: 0,
    ServerSideREST: 1,
};
PayPalIntegrationType[PayPalIntegrationType.ClientSideREST] = 'ClientSideREST';
PayPalIntegrationType[PayPalIntegrationType.ServerSideREST] = 'ServerSideREST';

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
class PayPalConfig {
    /**
     * @param {?} integrationType
     * @param {?} environment
     * @param {?} config
     */
    constructor(integrationType, environment, config) {
        this.integrationType = integrationType;
        this.environment = environment;
        /**
         * Show 'Pay Now' button config
         */
        this.commit = true;
        /**
         * Set the intent of the payment.
         */
        this.intent = 'sale';
        Object.assign(this, config);
    }
}

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
class NgxPaypalComponent {
    constructor() {
        /**
         * Indicates if global configuration (provided via 'forRoot') is used
         */
        this.useGlobalConfig = false;
        /**
         * Used for indicating delayed rendered if container is not yet ready in DOM
         */
        this.registerPayPalScriptWhenContainerIsReady = false;
        /**
         * Polling interval if paypal script is pending
         */
        this.defaultPollInterval = 50;
        /**
         * Polling will stop after polling reaches this number
         */
        this.maximumPollWaitTime = 5000;
        /**
         * Name of the global variable where paypal is stored
         */
        this.paypalWindowName = 'paypal';
        /**
         * Name of the global variable indicating that script was initiated (added to page)
         */
        this.paypalWindowScriptInitiated = 'ngx-paypal-script-initiated';
        /**
         * PayPal integration script url
         */
        this.paypalScriptUrl = 'https://www.paypalobjects.com/api/checkout.js';
        this.payPalButtonContainerIdPrefix = 'ngx-paypal-button-container-';
        this.ngUnsubscribe = new rxjs__WEBPACK_IMPORTED_MODULE_1__["Subject"]();
    }
    /**
     * @param {?} content
     * @return {?}
     */
    set payPalButtonContainerElem(content) {
        if (content) {
            this._payPalButtonContainerElem = content;
        }
    }
    /**
     * @param {?} changes
     * @return {?}
     */
    ngOnChanges(changes) {
        // init when config once its available
        if (this.config) {
            this.initPayPal();
        }
    }
    /**
     * @return {?}
     */
    ngAfterViewInit() {
        // register script if element is ready in dom
        if (this.registerPayPalScriptWhenContainerIsReady && this._payPalButtonContainerElem) {
            this.setupScript();
            this.registerPayPalScriptWhenContainerIsReady = false;
        }
    }
    /**
     * @return {?}
     */
    ngOnDestroy() {
        this.ngUnsubscribe.next();
        this.ngUnsubscribe.complete();
    }
    /**
     * @return {?}
     */
    initPayPal() {
        // set unique paypal container button id
        this.payPalButtonContainerId = `${this.payPalButtonContainerIdPrefix}${this.getPseudoUniqueNumber()}`;
        // check if paypal was already register and if so, don't add it to page again
        if (!window[this.paypalWindowName]) {
            // check if script is pending
            if (window[this.paypalWindowScriptInitiated] === true) {
                this.pollUntilScriptAvailable();
            }
            else {
                // register script and set global flag
                window[this.paypalWindowScriptInitiated] = true;
                this.addPayPalScriptToPage();
            }
        }
        else {
            // just register payment
            this.handleScriptRegistering();
        }
    }
    /**
     * @return {?}
     */
    getPseudoUniqueNumber() {
        return new Date().valueOf();
    }
    /**
     * Used when there are multiple paypal components on the same page beacuse only 1 of them
     * may register paypal script. The other has to be polling until paypal is available or component destroyed
     * @return {?}
     */
    pollUntilScriptAvailable() {
        /** @type {?} */
        const obs = Object(rxjs__WEBPACK_IMPORTED_MODULE_1__["interval"])(this.defaultPollInterval)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["takeUntil"])(this.ngUnsubscribe), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])((x) => {
            if (x >= this.maximumPollWaitTime) {
                console.warn(`PayPal script was not loaded after '${this.maximumPollWaitTime}' maximum polling time.`);
                obs.unsubscribe();
                return;
            }
            // check if paypal script exists
            if (window[this.paypalWindowName]) {
                // register script
                this.handleScriptRegistering();
                // stop execution
                obs.unsubscribe();
            }
        }))
            .subscribe();
    }
    /**
     * @return {?}
     */
    addPayPalScriptToPage() {
        /** @type {?} */
        const script = document.createElement('script');
        script.innerHTML = '';
        script.src = this.paypalScriptUrl;
        script.onload = () => this.handleScriptRegistering();
        script.async = true;
        script.defer = true;
        this.paypalScriptElem.nativeElement.appendChild(script);
    }
    /**
     * @return {?}
     */
    handleScriptRegistering() {
        // check if container with requested id exists
        // this is here because dynamically switching between components would cause PayPal to
        // throw an error if the container already existed before
        if (this._payPalButtonContainerElem && this._payPalButtonContainerElem.nativeElement &&
            this._payPalButtonContainerElem.nativeElement.id === this.payPalButtonContainerId) {
            // container is ready, setup script right away
            this.setupScript();
        }
        else {
            // container is not ready, delay registering until it is
            this.registerPayPalScriptWhenContainerIsReady = true;
        }
    }
    /**
     * @return {?}
     */
    setupScript() {
        // first clear container
        if (!this._payPalButtonContainerElem) {
            throw Error(`Cannot setup script because paypal button container with id '${this.payPalButtonContainerId}' is not yet ready`);
        }
        this._payPalButtonContainerElem.nativeElement.innerHTML = '';
        if (!window[this.paypalWindowName]) {
            throw Error('PayPal script is not available');
        }
        // render PayPal button as per their docs at
        // https://developer.paypal.com/docs/integration/direct/express-checkout/integration-jsv4/add-paypal-button/
        window[this.paypalWindowName].Button.render({
            // set environment
            env: this.config.environment.toString(),
            // Show the buyer a 'Pay Now' button in the checkout flow
            commit: this.config.commit,
            // init client for client side integration
            client: this.getClient(),
            // set button config if available
            style: this.config.button,
            // set funding if available
            funding: this.getFunding(),
            // payment() is called when the button is clicked
            payment: (data, actions) => {
                if (this.config.integrationType === PayPalIntegrationType.ServerSideREST) {
                    // client needs to create payment on server side
                    if (!this.config.payment) {
                        throw Error(`You need set up a create payment method and return
                            PayPal's payment id when using server side integration`);
                    }
                    // Paypal expects promise with payment id (string) to be returned
                    return this.config.payment().toPromise()
                        .then(paymentId => {
                        return paymentId;
                    });
                }
                if (this.config.integrationType === PayPalIntegrationType.ClientSideREST) {
                    if (!this.config.transactions || !Array.isArray(this.config.transactions) || this.config.transactions.length <= 0) {
                        throw Error(`You need to provide at least 1 transaction for client side integration`);
                    }
                    /** @type {?} */
                    const experienceConfig = this.config.experience;
                    return actions.payment.create({
                        payment: {
                            // Allow user to specifify intent, else use default 'sale'.
                            intent: this.config.intent ? this.config.intent : 'sale',
                            transactions: this.config.transactions
                        },
                        experience: {
                            input_fields: {
                                no_shipping: (experienceConfig && experienceConfig.noShipping) ? 1 : 0
                            },
                            presentation: {
                                brand_name: (experienceConfig && experienceConfig.brandName) ? experienceConfig.brandName : null,
                                logo_image: (experienceConfig && experienceConfig.logoImage) ? experienceConfig.logoImage : null,
                                locale_code: (experienceConfig && experienceConfig.localeCode) ? experienceConfig.localeCode : null
                            }
                        }
                    });
                }
            },
            // onAuthorize() is called when the buyer approves the payment
            onAuthorize: (data, actions) => {
                if (this.config.integrationType === PayPalIntegrationType.ServerSideREST) {
                    // client needs to server to execute the payment
                    if (!this.config.onAuthorize) {
                        throw Error(`You need set up an execute method when using server side integration`);
                    }
                    // Paypal expects promise
                    return this.config.onAuthorize(data, actions).toPromise();
                }
                if (this.config.integrationType === PayPalIntegrationType.ClientSideREST) {
                    // Make a call to the REST api to execute the payment
                    return actions.payment.execute().then(() => {
                        if (!this.config.onPaymentComplete) {
                            throw Error(`You should provide some callback when payment is finished when using client side integration`);
                        }
                        this.config.onPaymentComplete(data, actions);
                    });
                }
            },
            onError: (err) => {
                if (this.config.onError) {
                    this.config.onError(err);
                }
            },
            onCancel: (data, actions) => {
                if (this.config.onCancel) {
                    this.config.onCancel(data, actions);
                }
            },
            onClick: () => {
                if (this.config.onClick) {
                    this.config.onClick();
                }
            },
            validate: (actions) => {
                if (this.config.validate) {
                    this.config.validate(actions);
                }
            }
        }, `#${this.payPalButtonContainerId}`);
    }
    /**
     * @return {?}
     */
    getClient() {
        if (this.config.integrationType === PayPalIntegrationType.ClientSideREST) {
            if (!this.config.client) {
                throw Error(`You need to setup client information when using client side integration`);
            }
            return {
                production: this.config.client.production,
                sandbox: this.config.client.sandbox
            };
        }
        return undefined;
    }
    /**
     * @return {?}
     */
    getFunding() {
        // resolve funding to use paypal's properties
        if (!this.config.funding) {
            // no funding provided
            return undefined;
        }
        /** @type {?} */
        const allowed = [];
        /** @type {?} */
        const disallowed = [];
        if (this.config.funding.allowed) {
            this.config.funding.allowed.forEach(type => {
                allowed.push(this.mapFundingType(type));
            });
        }
        if (this.config.funding.disallowed) {
            this.config.funding.disallowed.forEach(type => {
                disallowed.push(this.mapFundingType(type));
            });
        }
        return {
            allowed: allowed,
            disallowed: disallowed
        };
    }
    /**
     * @param {?} type
     * @return {?}
     */
    mapFundingType(type) {
        if (type === PayPalFunding.Card) {
            return paypal.FUNDING.CARD;
        }
        if (type === PayPalFunding.Credit) {
            return paypal.FUNDING.CREDIT;
        }
        if (type === PayPalFunding.Elv) {
            return paypal.FUNDING.ELV;
        }
        throw Error(`Unsupported funding type '${type}'`);
    }
}
NgxPaypalComponent.decorators = [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"], args: [{
                changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ChangeDetectionStrategy"].OnPush,
                selector: 'ngx-paypal',
                template: `
    <div #payPalScriptElem></div>
    <div #payPalButtonContainerElem [id]="payPalButtonContainerId"></div>
    `
            }] }
];
/** @nocollapse */
NgxPaypalComponent.ctorParameters = () => [];
NgxPaypalComponent.propDecorators = {
    config: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    useGlobalConfig: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    paypalScriptElem: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"], args: ['payPalScriptElem',] }],
    payPalButtonContainerElem: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"], args: ['payPalButtonContainerElem',] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
class NgxPayPalModule {
}
NgxPayPalModule.decorators = [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"], args: [{
                imports: [],
                declarations: [
                    NgxPaypalComponent,
                ],
                exports: [
                    NgxPaypalComponent,
                ]
            },] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
/** @enum {string} */
const PayPalEnvironment = {
    Sandbox: 'sandbox',
    Production: 'production',
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */



//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmd4LXBheXBhbC5qcy5tYXAiLCJzb3VyY2VzIjpbIm5nOi8vbmd4LXBheXBhbC9saWIvbW9kZWxzL3BheXBhbC1mdW5kaW5nLnRzIiwibmc6Ly9uZ3gtcGF5cGFsL2xpYi9tb2RlbHMvcGF5cGFsLWludGVncmF0aW9uLnRzIiwibmc6Ly9uZ3gtcGF5cGFsL2xpYi9tb2RlbHMvcGF5cGFsLW1vZGVscy50cyIsIm5nOi8vbmd4LXBheXBhbC9saWIvY29tcG9uZW50cy9wYXlwYWwtY29tcG9uZW50LnRzIiwibmc6Ly9uZ3gtcGF5cGFsL2xpYi9uZ3gtcGF5cGFsLm1vZHVsZS50cyIsIm5nOi8vbmd4LXBheXBhbC9saWIvbW9kZWxzL3BheXBhbC1lbnZpcm9ubWVudC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgZW51bSBQYXlQYWxGdW5kaW5nIHtcclxuICAgIENhcmQsXHJcbiAgICBDcmVkaXQsXHJcbiAgICBFbHZcclxufVxyXG4iLCJleHBvcnQgZW51bSBQYXlQYWxJbnRlZ3JhdGlvblR5cGUge1xyXG4gICAgQ2xpZW50U2lkZVJFU1QsXHJcbiAgICBTZXJ2ZXJTaWRlUkVTVCxcclxufVxyXG4iLCJpbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XHJcblxyXG5pbXBvcnQgeyBQYXlQYWxGdW5kaW5nIH0gZnJvbSAnLi9wYXlwYWwtZnVuZGluZyc7XHJcbmltcG9ydCB7IFBheVBhbEVudmlyb25tZW50IH0gZnJvbSAnLi9wYXlwYWwtZW52aXJvbm1lbnQnO1xyXG5pbXBvcnQgeyBQYXlQYWxJbnRlZ3JhdGlvblR5cGUgfSBmcm9tICcuL3BheXBhbC1pbnRlZ3JhdGlvbic7XHJcblxyXG5leHBvcnQgY2xhc3MgUGF5UGFsQ29uZmlnIHtcclxuXHJcbiAgICAvKipcclxuICAgICAqIFNob3cgJ1BheSBOb3cnIGJ1dHRvbiBjb25maWdcclxuICAgICAqL1xyXG4gICAgcHVibGljIGNvbW1pdCA9IHRydWU7XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBTZXQgdGhlIGludGVudCBvZiB0aGUgcGF5bWVudC5cclxuICAgICAqL1xyXG4gICAgcHVibGljIGludGVudCA9ICdzYWxlJztcclxuXHJcbiAgICAvKipcclxuICAgICAqIENhbGxlZCB0byBjcmVhdGUgbmV3IHBheW1lbnQgZm9yIHNlcnZlciBzaWRlIGludGVncmF0aW9uXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBwYXltZW50PzogKCkgPT4gT2JzZXJ2YWJsZTxzdHJpbmc+O1xyXG5cclxuICAgIC8qKlxyXG4gICAgICogQ2FsbGVkIHRvIGV4ZWN1dGUgcGF5bWVudCBmb3Igc2VydmVyIHNpZGUgaW50ZWdyYXRpb25cclxuICAgICAqL1xyXG4gICAgcHVibGljIG9uQXV0aG9yaXplPzogKGRhdGE6IElQYXlQYWxQYXltZW50Q29tcGxldGVEYXRhLCBhY3Rpb25zOiBhbnkpID0+IE9ic2VydmFibGU8dm9pZD47XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBDbGllbnQgdG9rZW5zIGZvciBjbGllbnQgc2lkZSBpbnRlZ3JhdGlvblxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgY2xpZW50PzogSVBheXBhbENsaWVudDtcclxuXHJcbiAgICAvKipcclxuICAgICAqIEFycmF5IG9mIHRyYW5zYWN0aW9uLCByZXF1aXJlZCBmb3IgY2xpZW50IHNpZGUgaW50ZWdyYXRpb25cclxuICAgICAqL1xyXG4gICAgcHVibGljIHRyYW5zYWN0aW9ucz86IElQYXlQYWxUcmFuc2FjdGlvbltdO1xyXG5cclxuICAgIC8qKlxyXG4gICAgICogUGF5bWVudCBFeHBlcmllbmNlIGNvbmZpZ3VyYXRpb25zXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBleHBlcmllbmNlPzogSVBheVBhbEV4cGVyaWVuY2U7XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBDYWxsZWQgZm9yIGNsaWVudCBzaWRlIGludGVncmF0aW9uIHdoZW4gcGF5bWVudCBpcyBleGVjdXRlZFxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgb25QYXltZW50Q29tcGxldGU/OiAoZGF0YTogSVBheVBhbFBheW1lbnRDb21wbGV0ZURhdGEsIGFjdGlvbnM6IGFueSkgPT4gdm9pZDtcclxuXHJcbiAgICAvKipcclxuICAgICAqIEJ1dHRvbiBjb25maWd1cmF0aW9uXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBidXR0b24/OiBJUGF5UGFsQnV0dG9uU3R5bGU7XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBQYXlwYWwgZnVuZGluZyBjb25maWd1cmF0aW9uXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBmdW5kaW5nPzogSVBheVBhbEZ1bmRpbmc7XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBDYWxsZWQgd2hlbiBQYXlQYWwgZXhwZXJpZW5jZXMgYW4gZXJyb3JcclxuICAgICAqL1xyXG4gICAgcHVibGljIG9uRXJyb3I/OiAoZXJyOiBhbnkpID0+IHZvaWQ7XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBUaGlzIGhhbmRsZXIgd2lsbCBiZSBjYWxsZWQgZm9yIGV2ZXJ5IGNsaWNrIG9uIHRoZSBQYXlQYWwgYnV0dG9uXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBvbkNsaWNrPzogKCkgPT4gdm9pZDtcclxuXHJcbiAgICAvKipcclxuICAgICAqIENhbGxlZCB3aGVuIHVzZXIgY2FuY2VscyBwYXltZW50XHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBvbkNhbmNlbD86IChkYXRhOiBJUGF5UGFsQ2FuY2VsUGF5bWVudCwgYWN0aW9uczogYW55KSA9PiB2b2lkO1xyXG5cclxuICAgIC8qKlxyXG4gICAgICogQ2FuIGJlIHVzZWQgdG8gdmFsaWRhdGlvbiBhcyBjYW4gYmUgc2VlbiBoZXJlOiBodHRwczovL2RldmVsb3Blci5wYXlwYWwuY29tL2RlbW8vY2hlY2tvdXQvIy9wYXR0ZXJuL3ZhbGlkYXRpb25cclxuICAgICAqL1xyXG4gICAgcHVibGljIHZhbGlkYXRlPzogKGFjdGlvbnM6IGFueSkgPT4gdm9pZDtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcihcclxuICAgICAgICAvKipcclxuICAgICAgICAgKiBUeXBlIG9mIHRoZSBpbnRlZ3JhdGlvblxyXG4gICAgICAgICAqL1xyXG4gICAgICAgIHB1YmxpYyBpbnRlZ3JhdGlvblR5cGU6IFBheVBhbEludGVncmF0aW9uVHlwZSxcclxuICAgICAgICAvKipcclxuICAgICAgICAgKiBFbnZpcm9ubWVudFxyXG4gICAgICAgICAqL1xyXG4gICAgICAgIHB1YmxpYyBlbnZpcm9ubWVudDogUGF5UGFsRW52aXJvbm1lbnQsXHJcbiAgICAgICAgY29uZmlnOiB7XHJcbiAgICAgICAgICAgIG9uRXJyb3I/OiAoZXJyOiBhbnkpID0+IHZvaWQsXHJcbiAgICAgICAgICAgIG9uQ2xpY2s/OiAoKSA9PiB2b2lkLFxyXG4gICAgICAgICAgICB2YWxpZGF0ZT86IChhY3Rpb25zOiBhbnkpID0+IHZvaWQ7XHJcbiAgICAgICAgICAgIG9uQ2FuY2VsPzogKGRhdGE6IElQYXlQYWxDYW5jZWxQYXltZW50LCBhY3Rpb25zOiBhbnkpID0+IHZvaWQsXHJcbiAgICAgICAgICAgIHBheW1lbnQ/OiAoKSA9PiBPYnNlcnZhYmxlPHN0cmluZz4sXHJcbiAgICAgICAgICAgIGludGVudD86IHN0cmluZyxcclxuICAgICAgICAgICAgb25BdXRob3JpemU/OiAoZGF0YTogSVBheVBhbFBheW1lbnRDb21wbGV0ZURhdGEsIGFjdGlvbnM6IGFueSkgPT4gT2JzZXJ2YWJsZTx2b2lkPixcclxuICAgICAgICAgICAgY2xpZW50PzogSVBheXBhbENsaWVudCxcclxuICAgICAgICAgICAgb25QYXltZW50Q29tcGxldGU/OiAoZGF0YTogSVBheVBhbFBheW1lbnRDb21wbGV0ZURhdGEsIGFjdGlvbnM6IGFueSkgPT4gdm9pZCxcclxuICAgICAgICAgICAgdHJhbnNhY3Rpb25zPzogSVBheVBhbFRyYW5zYWN0aW9uW10sXHJcbiAgICAgICAgICAgIG5vdGVfdG9fcGF5ZXI/OiBzdHJpbmc7XHJcbiAgICAgICAgICAgIGV4cGVyaWVuY2U/OiBJUGF5UGFsRXhwZXJpZW5jZSxcclxuICAgICAgICAgICAgY29tbWl0PzogYm9vbGVhbixcclxuICAgICAgICAgICAgYnV0dG9uPzogSVBheVBhbEJ1dHRvblN0eWxlLFxyXG4gICAgICAgICAgICBmdW5kaW5nPzogSVBheVBhbEZ1bmRpbmdcclxuICAgICAgICB9KSB7XHJcbiAgICAgICAgT2JqZWN0LmFzc2lnbih0aGlzLCBjb25maWcpO1xyXG4gICAgfVxyXG59XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIElQYXlQYWxQYXltZW50Q29tcGxldGVEYXRhIHtcclxuICAgIGludGVudDogc3RyaW5nO1xyXG4gICAgb3JkZXJJRDogc3RyaW5nO1xyXG4gICAgcGF5ZXJJRDogc3RyaW5nO1xyXG4gICAgcGF5bWVudElEOiBzdHJpbmc7XHJcbiAgICBwYXltZW50VG9rZW46IHN0cmluZztcclxuICAgIHJldHVyblVybDogc3RyaW5nO1xyXG59XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIElQYXlQYWxDYW5jZWxQYXltZW50IHtcclxuICAgIGRhdGE6IElQYXlQYWxDYW5jZWxQYXltZW50RGF0YTtcclxuICAgIGFjdGlvbnM6IGFueTtcclxufVxyXG5cclxuZXhwb3J0IGludGVyZmFjZSBJUGF5UGFsQ2FuY2VsUGF5bWVudERhdGEge1xyXG4gICAgYmlsbGluZ0lEOiBzdHJpbmc7XHJcbiAgICBjYW5jZWxVcmw6IHN0cmluZztcclxuICAgIGludGVudDogc3RyaW5nO1xyXG4gICAgcGF5bWVudElEOiBzdHJpbmc7XHJcbiAgICBwYXltZW50VG9rZW46IHN0cmluZztcclxufVxyXG5cclxuZXhwb3J0IGludGVyZmFjZSBJUGF5cGFsQ2xpZW50IHtcclxuICAgIHNhbmRib3g/OiBzdHJpbmc7XHJcbiAgICBwcm9kdWN0aW9uPzogc3RyaW5nO1xyXG59XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIElQYXlQYWxUcmFuc2FjdGlvbiB7XHJcbiAgICBhbW91bnQ6IElQYXlQYWxBbW91bnQ7XHJcbiAgICBkZXNjcmlwdGlvbj86IHN0cmluZztcclxuICAgIGN1c3RvbT86IHN0cmluZztcclxuICAgIHBheW1lbnRfb3B0aW9ucz86IElQYXlQYWxUcmFuc2FjdGlvblBheW1lbnRPcHRpb25zO1xyXG4gICAgaW52b2ljZV9udW1iZXI/OiBzdHJpbmc7XHJcbiAgICBzb2Z0X2Rlc2NyaXB0b3I/OiBzdHJpbmc7XHJcbiAgICBpdGVtX2xpc3Q/OiBJUGF5UGFsVHJhbnNhY3Rpb25JdGVtTGlzdDtcclxufVxyXG5cclxuZXhwb3J0IGludGVyZmFjZSBJUGF5UGFsVHJhbnNhY3Rpb25JdGVtTGlzdCB7XHJcbiAgICBpdGVtcz86IElQYXlQYWxUcmFuc2FjdGlvbkl0ZW1bXTtcclxuICAgIHNoaXBwaW5nX2FkZHJlc3M/OiBJUGF5UGFsVHJhbnNhY3Rpb25TaGlwcGluZ0FkZHJlc3M7XHJcbn1cclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgSVBheVBhbFRyYW5zYWN0aW9uSXRlbSB7XHJcbiAgICBuYW1lOiBzdHJpbmc7XHJcbiAgICBjdXJyZW5jeTogc3RyaW5nO1xyXG4gICAgcHJpY2U6IG51bWJlcjtcclxuICAgIHF1YW50aXR5OiBudW1iZXI7XHJcblxyXG4gICAgZGVzY3JpcHRpb24/OiBzdHJpbmc7XHJcbiAgICB0YXg/OiBudW1iZXI7XHJcbiAgICBza3U/OiBzdHJpbmc7XHJcbn1cclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgSVBheVBhbEFtb3VudCB7XHJcbiAgICB0b3RhbDogbnVtYmVyO1xyXG4gICAgY3VycmVuY3k6IHN0cmluZztcclxuICAgIGRldGFpbHM/OiBJUGF5UGFsQW1vdW50RGV0YWlscztcclxufVxyXG5cclxuZXhwb3J0IGludGVyZmFjZSBJUGF5UGFsVHJhbnNhY3Rpb25TaGlwcGluZ0FkZHJlc3Mge1xyXG4gICAgcmVjaXBpZW50X25hbWU6IHN0cmluZztcclxuICAgIGxpbmUxOiBzdHJpbmc7XHJcbiAgICBsaW5lMj86IHN0cmluZztcclxuICAgIGNpdHk6IHN0cmluZztcclxuICAgIGNvdW50cnlfY29kZTogc3RyaW5nO1xyXG4gICAgcG9zdGFsX2NvZGU6IHN0cmluZztcclxuICAgIHBob25lOiBzdHJpbmc7XHJcbiAgICBzdGF0ZTogc3RyaW5nO1xyXG59XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIElQYXlQYWxBbW91bnREZXRhaWxzIHtcclxuICAgIHN1YnRvdGFsOiBudW1iZXI7XHJcbiAgICB0YXg6IG51bWJlcjtcclxuICAgIHNoaXBwaW5nOiBudW1iZXI7XHJcbiAgICBoYW5kbGluZ19mZWU6IG51bWJlcjtcclxuICAgIHNoaXBwaW5nX2Rpc2NvdW50OiBudW1iZXI7XHJcbiAgICBpbnN1cmFuY2U6IG51bWJlcjtcclxufVxyXG5cclxuZXhwb3J0IGludGVyZmFjZSBJUGF5UGFsVHJhbnNhY3Rpb25QYXltZW50T3B0aW9ucyB7XHJcbiAgICBhbGxvd2VkX3BheW1lbnRfbWV0aG9kPzogc3RyaW5nO1xyXG59XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIElQYXlQYWxFeHBlcmllbmNlIHtcclxuICAgIC8qKiBJbmRpY2F0ZXMgd2hldGhlciBQYXlQYWwgZGlzcGxheXMgc2hpcHBpbmcgYWRkcmVzcyBmaWVsZHMgb24gdGhlIGV4cGVyaWVuY2UgcGFnZXMgKi9cclxuICAgIG5vU2hpcHBpbmc/OiBib29sZWFuO1xyXG4gICAgLyoqIEEgbGFiZWwgdGhhdCBvdmVycmlkZXMgdGhlIGJ1c2luZXNzIG5hbWUgaW4gdGhlIFBheVBhbCBhY2NvdW50IG9uIHRoZSBQYXlQYWwgcGFnZXMuIE1heCBsZW5ndGg6IDEyNyBjaGFyYWN0ZXJzLiAqL1xyXG4gICAgYnJhbmROYW1lPzogc3RyaW5nO1xyXG4gICAgLyoqIFVSTCB0byB0aGUgbG9nbyBpbWFnZSAoZ2lmLCBqcGcsIG9yIHBuZykuIFRoZSBpbWFnZSdzIG1heGltdW0gd2lkdGggaXMgMTkwIHBpeGVscyBhbmQgbWF4aW11bSBoZWlnaHQgaXMgNjAgcGl4ZWxzLiAqL1xyXG4gICAgbG9nb0ltYWdlPzogc3RyaW5nO1xyXG4gICAgLyoqIExvY2FsZSBpbiB3aGljaCB0byBkaXNwbGF5IFBheVBhbCBwYWdlICovXHJcbiAgICBsb2NhbGVDb2RlPzogc3RyaW5nO1xyXG59XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIElQYXlQYWxCdXR0b25TdHlsZSB7XHJcbiAgICBsYWJlbD86ICdjaGVja291dCcgfCAncGF5JyB8ICdidXlub3cnIHwgJ3BheXBhbCc7XHJcbiAgICBzaXplPzogJ3NtYWxsJyB8ICdtZWRpdW0nIHwgJ2xhcmdlJyB8ICdyZXNwb25zaXZlJztcclxuICAgIHNoYXBlPzogJ3BpbGwnIHwgJ3JlY3QnO1xyXG4gICAgY29sb3I/OiAnZ29sZCcgfCAnYmx1ZScgfCAnc2lsdmVyJyB8ICdibGFjayc7XHJcbiAgICBsYXlvdXQ/OiAnaG9yaXpvbnRhbCcgfCAndmVydGljYWwnO1xyXG4gICAgdGFnbGluZT86IGZhbHNlO1xyXG4gICAgZnVuZGluZ2ljb25zPzogYm9vbGVhbjtcclxuICAgIGJyYW5kaW5nPzogYm9vbGVhbjtcclxufVxyXG5cclxuZXhwb3J0IGludGVyZmFjZSBJUGF5UGFsRnVuZGluZyB7XHJcbiAgICBhbGxvd2VkOiBQYXlQYWxGdW5kaW5nW107XHJcbiAgICBkaXNhbGxvd2VkOiBQYXlQYWxGdW5kaW5nW107XHJcbn1cclxuXHJcbiIsImltcG9ydCB7XHJcbiAgICBBZnRlclZpZXdJbml0LFxyXG4gICAgQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3ksXHJcbiAgICBDb21wb25lbnQsXHJcbiAgICBFbGVtZW50UmVmLFxyXG4gICAgSW5wdXQsXHJcbiAgICBPbkNoYW5nZXMsXHJcbiAgICBPbkRlc3Ryb3ksXHJcbiAgICBTaW1wbGVDaGFuZ2VzLFxyXG4gICAgVmlld0NoaWxkLFxyXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBpbnRlcnZhbCwgU3ViamVjdCB9IGZyb20gJ3J4anMnO1xyXG5pbXBvcnQgeyBtYXAsIHRha2VVbnRpbCB9IGZyb20gJ3J4anMvb3BlcmF0b3JzJztcclxuXHJcbmltcG9ydCB7IFBheVBhbEZ1bmRpbmcgfSBmcm9tICcuLi9tb2RlbHMvcGF5cGFsLWZ1bmRpbmcnO1xyXG5pbXBvcnQgeyBQYXlQYWxJbnRlZ3JhdGlvblR5cGUgfSBmcm9tICcuLi9tb2RlbHMvcGF5cGFsLWludGVncmF0aW9uJztcclxuaW1wb3J0IHsgSVBheXBhbENsaWVudCwgSVBheVBhbFBheW1lbnRDb21wbGV0ZURhdGEsIFBheVBhbENvbmZpZyB9IGZyb20gJy4uL21vZGVscy9wYXlwYWwtbW9kZWxzJztcclxuXHJcbi8qKlxyXG4gKiBHbG9iYWwgdmFyaWFibGUgd2hlcmUgUGF5UGFsIGlzIGxvYWRlZCB0b1xyXG4gKi9cclxuZGVjbGFyZSB2YXIgcGF5cGFsOiBhbnk7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIGNoYW5nZURldGVjdGlvbjogQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3kuT25QdXNoLFxyXG4gICAgc2VsZWN0b3I6ICduZ3gtcGF5cGFsJyxcclxuICAgIHRlbXBsYXRlOiBgXHJcbiAgICA8ZGl2ICNwYXlQYWxTY3JpcHRFbGVtPjwvZGl2PlxyXG4gICAgPGRpdiAjcGF5UGFsQnV0dG9uQ29udGFpbmVyRWxlbSBbaWRdPVwicGF5UGFsQnV0dG9uQ29udGFpbmVySWRcIj48L2Rpdj5cclxuICAgIGBcclxufSlcclxuZXhwb3J0IGNsYXNzIE5neFBheXBhbENvbXBvbmVudCBpbXBsZW1lbnRzIE9uQ2hhbmdlcywgQWZ0ZXJWaWV3SW5pdCwgT25EZXN0cm95IHtcclxuXHJcbiAgICAvKipcclxuICAgICAqIENvbmZpZ3VyYXRpb24gZm9yIHBheXBhbC5cclxuICAgICAqL1xyXG4gICAgQElucHV0KCkgY29uZmlnOiBQYXlQYWxDb25maWc7XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBJbmRpY2F0ZXMgaWYgZ2xvYmFsIGNvbmZpZ3VyYXRpb24gKHByb3ZpZGVkIHZpYSAnZm9yUm9vdCcpIGlzIHVzZWRcclxuICAgICAqL1xyXG4gICAgQElucHV0KCkgdXNlR2xvYmFsQ29uZmlnID0gZmFsc2U7XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBDb250YWluZXIgZm9yIHBheXBhbCBzY3JpcHRcclxuICAgICAqL1xyXG4gICAgQFZpZXdDaGlsZCgncGF5UGFsU2NyaXB0RWxlbScpIHBheXBhbFNjcmlwdEVsZW06IEVsZW1lbnRSZWY7XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBVc2VkIGZvciBpbmRpY2F0aW5nIGRlbGF5ZWQgcmVuZGVyZWQgaWYgY29udGFpbmVyIGlzIG5vdCB5ZXQgcmVhZHkgaW4gRE9NXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgcmVnaXN0ZXJQYXlQYWxTY3JpcHRXaGVuQ29udGFpbmVySXNSZWFkeSA9IGZhbHNlO1xyXG5cclxuICAgIC8qKlxyXG4gICAgICogSG9sZHMgY3VycmVudCBjb250YWluZXIgZWxlbWVudFxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIF9wYXlQYWxCdXR0b25Db250YWluZXJFbGVtPzogRWxlbWVudFJlZjtcclxuICAgIEBWaWV3Q2hpbGQoJ3BheVBhbEJ1dHRvbkNvbnRhaW5lckVsZW0nKSBzZXQgcGF5UGFsQnV0dG9uQ29udGFpbmVyRWxlbShjb250ZW50OiBFbGVtZW50UmVmKSB7XHJcbiAgICAgICAgaWYgKGNvbnRlbnQpIHtcclxuICAgICAgICAgICAgdGhpcy5fcGF5UGFsQnV0dG9uQ29udGFpbmVyRWxlbSA9IGNvbnRlbnQ7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogUG9sbGluZyBpbnRlcnZhbCBpZiBwYXlwYWwgc2NyaXB0IGlzIHBlbmRpbmdcclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSByZWFkb25seSBkZWZhdWx0UG9sbEludGVydmFsID0gNTA7XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBQb2xsaW5nIHdpbGwgc3RvcCBhZnRlciBwb2xsaW5nIHJlYWNoZXMgdGhpcyBudW1iZXJcclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSByZWFkb25seSBtYXhpbXVtUG9sbFdhaXRUaW1lID0gNTAwMDtcclxuXHJcbiAgICAvKipcclxuICAgICogTmFtZSBvZiB0aGUgZ2xvYmFsIHZhcmlhYmxlIHdoZXJlIHBheXBhbCBpcyBzdG9yZWRcclxuICAgICovXHJcbiAgICBwcml2YXRlIHJlYWRvbmx5IHBheXBhbFdpbmRvd05hbWUgPSAncGF5cGFsJztcclxuXHJcbiAgICAvKipcclxuICAgICAqIE5hbWUgb2YgdGhlIGdsb2JhbCB2YXJpYWJsZSBpbmRpY2F0aW5nIHRoYXQgc2NyaXB0IHdhcyBpbml0aWF0ZWQgKGFkZGVkIHRvIHBhZ2UpXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgcmVhZG9ubHkgcGF5cGFsV2luZG93U2NyaXB0SW5pdGlhdGVkID0gJ25neC1wYXlwYWwtc2NyaXB0LWluaXRpYXRlZCc7XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBQYXlQYWwgaW50ZWdyYXRpb24gc2NyaXB0IHVybFxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIHJlYWRvbmx5IHBheXBhbFNjcmlwdFVybCA9ICdodHRwczovL3d3dy5wYXlwYWxvYmplY3RzLmNvbS9hcGkvY2hlY2tvdXQuanMnO1xyXG5cclxuICAgIC8qKlxyXG4gICAgICogSWQgb2YgdGhlIGVsZW1lbnQgd2hlcmUgUGF5UGFsIGJ1dHRvbiB3aWxsIGJlIHJlbmRlcmVkXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBwYXlQYWxCdXR0b25Db250YWluZXJJZD86IHN0cmluZztcclxuXHJcbiAgICBwcml2YXRlIHJlYWRvbmx5IHBheVBhbEJ1dHRvbkNvbnRhaW5lcklkUHJlZml4ID0gJ25neC1wYXlwYWwtYnV0dG9uLWNvbnRhaW5lci0nO1xyXG5cclxuICAgIHByaXZhdGUgcmVhZG9ubHkgbmdVbnN1YnNjcmliZTogU3ViamVjdDx2b2lkPiA9IG5ldyBTdWJqZWN0PHZvaWQ+KCk7XHJcblxyXG4gICAgY29uc3RydWN0b3IoXHJcbiAgICApIHtcclxuICAgIH1cclxuXHJcbiAgICBuZ09uQ2hhbmdlcyhjaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKTogdm9pZCB7XHJcbiAgICAgICAgLy8gaW5pdCB3aGVuIGNvbmZpZyBvbmNlIGl0cyBhdmFpbGFibGVcclxuICAgICAgICBpZiAodGhpcy5jb25maWcpIHtcclxuICAgICAgICAgICAgdGhpcy5pbml0UGF5UGFsKCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIG5nQWZ0ZXJWaWV3SW5pdCgpOiB2b2lkIHtcclxuICAgICAgICAvLyByZWdpc3RlciBzY3JpcHQgaWYgZWxlbWVudCBpcyByZWFkeSBpbiBkb21cclxuICAgICAgICBpZiAodGhpcy5yZWdpc3RlclBheVBhbFNjcmlwdFdoZW5Db250YWluZXJJc1JlYWR5ICYmIHRoaXMuX3BheVBhbEJ1dHRvbkNvbnRhaW5lckVsZW0pIHtcclxuICAgICAgICAgICAgdGhpcy5zZXR1cFNjcmlwdCgpO1xyXG4gICAgICAgICAgICB0aGlzLnJlZ2lzdGVyUGF5UGFsU2NyaXB0V2hlbkNvbnRhaW5lcklzUmVhZHkgPSBmYWxzZTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkRlc3Ryb3koKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5uZ1Vuc3Vic2NyaWJlLm5leHQoKTtcclxuICAgICAgICB0aGlzLm5nVW5zdWJzY3JpYmUuY29tcGxldGUoKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIGluaXRQYXlQYWwoKTogdm9pZCB7XHJcbiAgICAgICAgLy8gc2V0IHVuaXF1ZSBwYXlwYWwgY29udGFpbmVyIGJ1dHRvbiBpZFxyXG4gICAgICAgIHRoaXMucGF5UGFsQnV0dG9uQ29udGFpbmVySWQgPSBgJHt0aGlzLnBheVBhbEJ1dHRvbkNvbnRhaW5lcklkUHJlZml4fSR7dGhpcy5nZXRQc2V1ZG9VbmlxdWVOdW1iZXIoKX1gO1xyXG4gICAgICAgIC8vIGNoZWNrIGlmIHBheXBhbCB3YXMgYWxyZWFkeSByZWdpc3RlciBhbmQgaWYgc28sIGRvbid0IGFkZCBpdCB0byBwYWdlIGFnYWluXHJcbiAgICAgICAgaWYgKCF3aW5kb3dbdGhpcy5wYXlwYWxXaW5kb3dOYW1lXSkge1xyXG4gICAgICAgICAgICAvLyBjaGVjayBpZiBzY3JpcHQgaXMgcGVuZGluZ1xyXG4gICAgICAgICAgICBpZiAod2luZG93W3RoaXMucGF5cGFsV2luZG93U2NyaXB0SW5pdGlhdGVkXSA9PT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5wb2xsVW50aWxTY3JpcHRBdmFpbGFibGUoKTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIC8vIHJlZ2lzdGVyIHNjcmlwdCBhbmQgc2V0IGdsb2JhbCBmbGFnXHJcbiAgICAgICAgICAgICAgICB3aW5kb3dbdGhpcy5wYXlwYWxXaW5kb3dTY3JpcHRJbml0aWF0ZWRdID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIHRoaXMuYWRkUGF5UGFsU2NyaXB0VG9QYWdlKCk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgLy8ganVzdCByZWdpc3RlciBwYXltZW50XHJcbiAgICAgICAgICAgIHRoaXMuaGFuZGxlU2NyaXB0UmVnaXN0ZXJpbmcoKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBnZXRQc2V1ZG9VbmlxdWVOdW1iZXIoKTogbnVtYmVyIHtcclxuICAgICAgICByZXR1cm4gbmV3IERhdGUoKS52YWx1ZU9mKCk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBVc2VkIHdoZW4gdGhlcmUgYXJlIG11bHRpcGxlIHBheXBhbCBjb21wb25lbnRzIG9uIHRoZSBzYW1lIHBhZ2UgYmVhY3VzZSBvbmx5IDEgb2YgdGhlbVxyXG4gICAgICogbWF5IHJlZ2lzdGVyIHBheXBhbCBzY3JpcHQuIFRoZSBvdGhlciBoYXMgdG8gYmUgcG9sbGluZyB1bnRpbCBwYXlwYWwgaXMgYXZhaWxhYmxlIG9yIGNvbXBvbmVudCBkZXN0cm95ZWRcclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBwb2xsVW50aWxTY3JpcHRBdmFpbGFibGUoKTogdm9pZCB7XHJcbiAgICAgICAgY29uc3Qgb2JzID0gaW50ZXJ2YWwodGhpcy5kZWZhdWx0UG9sbEludGVydmFsKVxyXG4gICAgICAgICAgICAucGlwZShcclxuICAgICAgICAgICAgICAgIHRha2VVbnRpbCh0aGlzLm5nVW5zdWJzY3JpYmUpLFxyXG4gICAgICAgICAgICAgICAgbWFwKCh4KSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHggPj0gdGhpcy5tYXhpbXVtUG9sbFdhaXRUaW1lKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUud2FybihgUGF5UGFsIHNjcmlwdCB3YXMgbm90IGxvYWRlZCBhZnRlciAnJHt0aGlzLm1heGltdW1Qb2xsV2FpdFRpbWV9JyBtYXhpbXVtIHBvbGxpbmcgdGltZS5gKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgb2JzLnVuc3Vic2NyaWJlKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIC8vIGNoZWNrIGlmIHBheXBhbCBzY3JpcHQgZXhpc3RzXHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHdpbmRvd1t0aGlzLnBheXBhbFdpbmRvd05hbWVdKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIHJlZ2lzdGVyIHNjcmlwdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmhhbmRsZVNjcmlwdFJlZ2lzdGVyaW5nKCk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBzdG9wIGV4ZWN1dGlvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvYnMudW5zdWJzY3JpYmUoKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICApXHJcbiAgICAgICAgICAgIC5zdWJzY3JpYmUoKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIGFkZFBheVBhbFNjcmlwdFRvUGFnZSgpOiB2b2lkIHtcclxuICAgICAgICBjb25zdCBzY3JpcHQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzY3JpcHQnKTtcclxuICAgICAgICBzY3JpcHQuaW5uZXJIVE1MID0gJyc7XHJcbiAgICAgICAgc2NyaXB0LnNyYyA9IHRoaXMucGF5cGFsU2NyaXB0VXJsO1xyXG4gICAgICAgIHNjcmlwdC5vbmxvYWQgPSAoKSA9PiB0aGlzLmhhbmRsZVNjcmlwdFJlZ2lzdGVyaW5nKCk7XHJcbiAgICAgICAgc2NyaXB0LmFzeW5jID0gdHJ1ZTtcclxuICAgICAgICBzY3JpcHQuZGVmZXIgPSB0cnVlO1xyXG5cclxuICAgICAgICB0aGlzLnBheXBhbFNjcmlwdEVsZW0ubmF0aXZlRWxlbWVudC5hcHBlbmRDaGlsZChzY3JpcHQpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgaGFuZGxlU2NyaXB0UmVnaXN0ZXJpbmcoKTogdm9pZCB7XHJcbiAgICAgICAgLy8gY2hlY2sgaWYgY29udGFpbmVyIHdpdGggcmVxdWVzdGVkIGlkIGV4aXN0c1xyXG4gICAgICAgIC8vIHRoaXMgaXMgaGVyZSBiZWNhdXNlIGR5bmFtaWNhbGx5IHN3aXRjaGluZyBiZXR3ZWVuIGNvbXBvbmVudHMgd291bGQgY2F1c2UgUGF5UGFsIHRvXHJcbiAgICAgICAgLy8gdGhyb3cgYW4gZXJyb3IgaWYgdGhlIGNvbnRhaW5lciBhbHJlYWR5IGV4aXN0ZWQgYmVmb3JlXHJcbiAgICAgICAgaWYgKHRoaXMuX3BheVBhbEJ1dHRvbkNvbnRhaW5lckVsZW0gJiYgdGhpcy5fcGF5UGFsQnV0dG9uQ29udGFpbmVyRWxlbS5uYXRpdmVFbGVtZW50ICYmXHJcbiAgICAgICAgICAgIHRoaXMuX3BheVBhbEJ1dHRvbkNvbnRhaW5lckVsZW0ubmF0aXZlRWxlbWVudC5pZCA9PT0gdGhpcy5wYXlQYWxCdXR0b25Db250YWluZXJJZCkge1xyXG4gICAgICAgICAgICAvLyBjb250YWluZXIgaXMgcmVhZHksIHNldHVwIHNjcmlwdCByaWdodCBhd2F5XHJcbiAgICAgICAgICAgIHRoaXMuc2V0dXBTY3JpcHQoKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAvLyBjb250YWluZXIgaXMgbm90IHJlYWR5LCBkZWxheSByZWdpc3RlcmluZyB1bnRpbCBpdCBpc1xyXG4gICAgICAgICAgICB0aGlzLnJlZ2lzdGVyUGF5UGFsU2NyaXB0V2hlbkNvbnRhaW5lcklzUmVhZHkgPSB0cnVlO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIHNldHVwU2NyaXB0KCk6IHZvaWQge1xyXG4gICAgICAgIC8vIGZpcnN0IGNsZWFyIGNvbnRhaW5lclxyXG4gICAgICAgIGlmICghdGhpcy5fcGF5UGFsQnV0dG9uQ29udGFpbmVyRWxlbSkge1xyXG4gICAgICAgICAgICB0aHJvdyBFcnJvcihgQ2Fubm90IHNldHVwIHNjcmlwdCBiZWNhdXNlIHBheXBhbCBidXR0b24gY29udGFpbmVyIHdpdGggaWQgJyR7dGhpcy5wYXlQYWxCdXR0b25Db250YWluZXJJZH0nIGlzIG5vdCB5ZXQgcmVhZHlgKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRoaXMuX3BheVBhbEJ1dHRvbkNvbnRhaW5lckVsZW0ubmF0aXZlRWxlbWVudC5pbm5lckhUTUwgPSAnJztcclxuXHJcbiAgICAgICAgaWYgKCF3aW5kb3dbdGhpcy5wYXlwYWxXaW5kb3dOYW1lXSkge1xyXG4gICAgICAgICAgICB0aHJvdyBFcnJvcignUGF5UGFsIHNjcmlwdCBpcyBub3QgYXZhaWxhYmxlJyk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvLyByZW5kZXIgUGF5UGFsIGJ1dHRvbiBhcyBwZXIgdGhlaXIgZG9jcyBhdFxyXG4gICAgICAgIC8vIGh0dHBzOi8vZGV2ZWxvcGVyLnBheXBhbC5jb20vZG9jcy9pbnRlZ3JhdGlvbi9kaXJlY3QvZXhwcmVzcy1jaGVja291dC9pbnRlZ3JhdGlvbi1qc3Y0L2FkZC1wYXlwYWwtYnV0dG9uL1xyXG4gICAgICAgIHdpbmRvd1t0aGlzLnBheXBhbFdpbmRvd05hbWVdLkJ1dHRvbi5yZW5kZXIoe1xyXG4gICAgICAgICAgICAvLyBzZXQgZW52aXJvbm1lbnRcclxuICAgICAgICAgICAgZW52OiB0aGlzLmNvbmZpZy5lbnZpcm9ubWVudC50b1N0cmluZygpLFxyXG5cclxuICAgICAgICAgICAgLy8gU2hvdyB0aGUgYnV5ZXIgYSAnUGF5IE5vdycgYnV0dG9uIGluIHRoZSBjaGVja291dCBmbG93XHJcbiAgICAgICAgICAgIGNvbW1pdDogdGhpcy5jb25maWcuY29tbWl0LFxyXG5cclxuICAgICAgICAgICAgLy8gaW5pdCBjbGllbnQgZm9yIGNsaWVudCBzaWRlIGludGVncmF0aW9uXHJcbiAgICAgICAgICAgIGNsaWVudDogdGhpcy5nZXRDbGllbnQoKSxcclxuXHJcbiAgICAgICAgICAgIC8vIHNldCBidXR0b24gY29uZmlnIGlmIGF2YWlsYWJsZVxyXG4gICAgICAgICAgICBzdHlsZTogdGhpcy5jb25maWcuYnV0dG9uLFxyXG5cclxuICAgICAgICAgICAgLy8gc2V0IGZ1bmRpbmcgaWYgYXZhaWxhYmxlXHJcbiAgICAgICAgICAgIGZ1bmRpbmc6IHRoaXMuZ2V0RnVuZGluZygpLFxyXG5cclxuICAgICAgICAgICAgLy8gcGF5bWVudCgpIGlzIGNhbGxlZCB3aGVuIHRoZSBidXR0b24gaXMgY2xpY2tlZFxyXG4gICAgICAgICAgICBwYXltZW50OiAoZGF0YSwgYWN0aW9ucykgPT4ge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuY29uZmlnLmludGVncmF0aW9uVHlwZSA9PT0gUGF5UGFsSW50ZWdyYXRpb25UeXBlLlNlcnZlclNpZGVSRVNUKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gY2xpZW50IG5lZWRzIHRvIGNyZWF0ZSBwYXltZW50IG9uIHNlcnZlciBzaWRlXHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKCF0aGlzLmNvbmZpZy5wYXltZW50KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRocm93IEVycm9yKGBZb3UgbmVlZCBzZXQgdXAgYSBjcmVhdGUgcGF5bWVudCBtZXRob2QgYW5kIHJldHVyblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgUGF5UGFsJ3MgcGF5bWVudCBpZCB3aGVuIHVzaW5nIHNlcnZlciBzaWRlIGludGVncmF0aW9uYCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAvLyBQYXlwYWwgZXhwZWN0cyBwcm9taXNlIHdpdGggcGF5bWVudCBpZCAoc3RyaW5nKSB0byBiZSByZXR1cm5lZFxyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLmNvbmZpZy5wYXltZW50KCkudG9Qcm9taXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgLnRoZW4ocGF5bWVudElkID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBwYXltZW50SWQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLmNvbmZpZy5pbnRlZ3JhdGlvblR5cGUgPT09IFBheVBhbEludGVncmF0aW9uVHlwZS5DbGllbnRTaWRlUkVTVCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICghdGhpcy5jb25maWcudHJhbnNhY3Rpb25zIHx8ICFBcnJheS5pc0FycmF5KHRoaXMuY29uZmlnLnRyYW5zYWN0aW9ucykgfHwgdGhpcy5jb25maWcudHJhbnNhY3Rpb25zLmxlbmd0aCA8PSAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRocm93IEVycm9yKGBZb3UgbmVlZCB0byBwcm92aWRlIGF0IGxlYXN0IDEgdHJhbnNhY3Rpb24gZm9yIGNsaWVudCBzaWRlIGludGVncmF0aW9uYCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICBjb25zdCBleHBlcmllbmNlQ29uZmlnID0gdGhpcy5jb25maWcuZXhwZXJpZW5jZTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gYWN0aW9ucy5wYXltZW50LmNyZWF0ZSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBheW1lbnQ6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIEFsbG93IHVzZXIgdG8gc3BlY2lmaWZ5IGludGVudCwgZWxzZSB1c2UgZGVmYXVsdCAnc2FsZScuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbnRlbnQ6IHRoaXMuY29uZmlnLmludGVudCA/IHRoaXMuY29uZmlnLmludGVudCA6ICdzYWxlJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRyYW5zYWN0aW9uczogdGhpcy5jb25maWcudHJhbnNhY3Rpb25zXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGV4cGVyaWVuY2U6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlucHV0X2ZpZWxkczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5vX3NoaXBwaW5nOiAoZXhwZXJpZW5jZUNvbmZpZyAmJiBleHBlcmllbmNlQ29uZmlnLm5vU2hpcHBpbmcpID8gMSA6IDBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcmVzZW50YXRpb246IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmFuZF9uYW1lOiAoZXhwZXJpZW5jZUNvbmZpZyAmJiBleHBlcmllbmNlQ29uZmlnLmJyYW5kTmFtZSkgPyBleHBlcmllbmNlQ29uZmlnLmJyYW5kTmFtZSA6IG51bGwsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbG9nb19pbWFnZTogKGV4cGVyaWVuY2VDb25maWcgJiYgZXhwZXJpZW5jZUNvbmZpZy5sb2dvSW1hZ2UpID8gZXhwZXJpZW5jZUNvbmZpZy5sb2dvSW1hZ2UgOiBudWxsLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxvY2FsZV9jb2RlOiAoZXhwZXJpZW5jZUNvbmZpZyAmJiBleHBlcmllbmNlQ29uZmlnLmxvY2FsZUNvZGUpID8gZXhwZXJpZW5jZUNvbmZpZy5sb2NhbGVDb2RlIDogbnVsbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcblxyXG4gICAgICAgICAgICAvLyBvbkF1dGhvcml6ZSgpIGlzIGNhbGxlZCB3aGVuIHRoZSBidXllciBhcHByb3ZlcyB0aGUgcGF5bWVudFxyXG4gICAgICAgICAgICBvbkF1dGhvcml6ZTogKGRhdGE6IElQYXlQYWxQYXltZW50Q29tcGxldGVEYXRhLCBhY3Rpb25zOiBhbnkpID0+IHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLmNvbmZpZy5pbnRlZ3JhdGlvblR5cGUgPT09IFBheVBhbEludGVncmF0aW9uVHlwZS5TZXJ2ZXJTaWRlUkVTVCkge1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIGNsaWVudCBuZWVkcyB0byBzZXJ2ZXIgdG8gZXhlY3V0ZSB0aGUgcGF5bWVudFxyXG4gICAgICAgICAgICAgICAgICAgIGlmICghdGhpcy5jb25maWcub25BdXRob3JpemUpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhyb3cgRXJyb3IoYFlvdSBuZWVkIHNldCB1cCBhbiBleGVjdXRlIG1ldGhvZCB3aGVuIHVzaW5nIHNlcnZlciBzaWRlIGludGVncmF0aW9uYCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAvLyBQYXlwYWwgZXhwZWN0cyBwcm9taXNlXHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuY29uZmlnLm9uQXV0aG9yaXplKGRhdGEsIGFjdGlvbnMpLnRvUHJvbWlzZSgpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLmNvbmZpZy5pbnRlZ3JhdGlvblR5cGUgPT09IFBheVBhbEludGVncmF0aW9uVHlwZS5DbGllbnRTaWRlUkVTVCkge1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIE1ha2UgYSBjYWxsIHRvIHRoZSBSRVNUIGFwaSB0byBleGVjdXRlIHRoZSBwYXltZW50XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGFjdGlvbnMucGF5bWVudC5leGVjdXRlKCkudGhlbigoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICghdGhpcy5jb25maWcub25QYXltZW50Q29tcGxldGUpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRocm93IEVycm9yKGBZb3Ugc2hvdWxkIHByb3ZpZGUgc29tZSBjYWxsYmFjayB3aGVuIHBheW1lbnQgaXMgZmluaXNoZWQgd2hlbiB1c2luZyBjbGllbnQgc2lkZSBpbnRlZ3JhdGlvbmApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuY29uZmlnLm9uUGF5bWVudENvbXBsZXRlKGRhdGEsIGFjdGlvbnMpO1xyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LFxyXG5cclxuICAgICAgICAgICAgb25FcnJvcjogKGVycikgPT4ge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuY29uZmlnLm9uRXJyb3IpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmNvbmZpZy5vbkVycm9yKGVycik7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcblxyXG4gICAgICAgICAgICBvbkNhbmNlbDogKGRhdGEsIGFjdGlvbnMpID0+IHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLmNvbmZpZy5vbkNhbmNlbCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuY29uZmlnLm9uQ2FuY2VsKGRhdGEsIGFjdGlvbnMpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBvbkNsaWNrOiAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5jb25maWcub25DbGljaykge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuY29uZmlnLm9uQ2xpY2soKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgdmFsaWRhdGU6IChhY3Rpb25zKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5jb25maWcudmFsaWRhdGUpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmNvbmZpZy52YWxpZGF0ZShhY3Rpb25zKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGAjJHt0aGlzLnBheVBhbEJ1dHRvbkNvbnRhaW5lcklkfWApO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgZ2V0Q2xpZW50KCk6IElQYXlwYWxDbGllbnQgfCB1bmRlZmluZWQge1xyXG4gICAgICAgIGlmICh0aGlzLmNvbmZpZy5pbnRlZ3JhdGlvblR5cGUgPT09IFBheVBhbEludGVncmF0aW9uVHlwZS5DbGllbnRTaWRlUkVTVCkge1xyXG4gICAgICAgICAgICBpZiAoIXRoaXMuY29uZmlnLmNsaWVudCkge1xyXG4gICAgICAgICAgICAgICAgdGhyb3cgRXJyb3IoYFlvdSBuZWVkIHRvIHNldHVwIGNsaWVudCBpbmZvcm1hdGlvbiB3aGVuIHVzaW5nIGNsaWVudCBzaWRlIGludGVncmF0aW9uYCk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICBwcm9kdWN0aW9uOiB0aGlzLmNvbmZpZy5jbGllbnQucHJvZHVjdGlvbixcclxuICAgICAgICAgICAgICAgIHNhbmRib3g6IHRoaXMuY29uZmlnLmNsaWVudC5zYW5kYm94XHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gdW5kZWZpbmVkO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgZ2V0RnVuZGluZygpOiB7XHJcbiAgICAgICAgYWxsb3dlZDogYW55W10sXHJcbiAgICAgICAgZGlzYWxsb3dlZDogYW55W11cclxuICAgIH0gfCB1bmRlZmluZWQge1xyXG4gICAgICAgIC8vIHJlc29sdmUgZnVuZGluZyB0byB1c2UgcGF5cGFsJ3MgcHJvcGVydGllc1xyXG4gICAgICAgIGlmICghdGhpcy5jb25maWcuZnVuZGluZykge1xyXG4gICAgICAgICAgICAvLyBubyBmdW5kaW5nIHByb3ZpZGVkXHJcbiAgICAgICAgICAgIHJldHVybiB1bmRlZmluZWQ7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBjb25zdCBhbGxvd2VkOiBhbnlbXSA9IFtdO1xyXG4gICAgICAgIGNvbnN0IGRpc2FsbG93ZWQ6IGFueVtdID0gW107XHJcblxyXG4gICAgICAgIGlmICh0aGlzLmNvbmZpZy5mdW5kaW5nLmFsbG93ZWQpIHtcclxuICAgICAgICAgICAgdGhpcy5jb25maWcuZnVuZGluZy5hbGxvd2VkLmZvckVhY2godHlwZSA9PiB7XHJcbiAgICAgICAgICAgICAgICBhbGxvd2VkLnB1c2godGhpcy5tYXBGdW5kaW5nVHlwZSh0eXBlKSk7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKHRoaXMuY29uZmlnLmZ1bmRpbmcuZGlzYWxsb3dlZCkge1xyXG4gICAgICAgICAgICB0aGlzLmNvbmZpZy5mdW5kaW5nLmRpc2FsbG93ZWQuZm9yRWFjaCh0eXBlID0+IHtcclxuICAgICAgICAgICAgICAgIGRpc2FsbG93ZWQucHVzaCh0aGlzLm1hcEZ1bmRpbmdUeXBlKHR5cGUpKTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICBhbGxvd2VkOiBhbGxvd2VkLFxyXG4gICAgICAgICAgICBkaXNhbGxvd2VkOiBkaXNhbGxvd2VkXHJcbiAgICAgICAgfTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIG1hcEZ1bmRpbmdUeXBlKHR5cGU6IFBheVBhbEZ1bmRpbmcpOiBhbnkge1xyXG4gICAgICAgIGlmICh0eXBlID09PSBQYXlQYWxGdW5kaW5nLkNhcmQpIHtcclxuICAgICAgICAgICAgcmV0dXJuIHBheXBhbC5GVU5ESU5HLkNBUkQ7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICh0eXBlID09PSBQYXlQYWxGdW5kaW5nLkNyZWRpdCkge1xyXG4gICAgICAgICAgICByZXR1cm4gcGF5cGFsLkZVTkRJTkcuQ1JFRElUO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAodHlwZSA9PT0gUGF5UGFsRnVuZGluZy5FbHYpIHtcclxuICAgICAgICAgICAgcmV0dXJuIHBheXBhbC5GVU5ESU5HLkVMVjtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhyb3cgRXJyb3IoYFVuc3VwcG9ydGVkIGZ1bmRpbmcgdHlwZSAnJHt0eXBlfSdgKTtcclxuICAgIH1cclxufVxyXG5cclxuIiwiaW1wb3J0IHsgTmdNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuXHJcbmltcG9ydCB7IE5neFBheXBhbENvbXBvbmVudCB9IGZyb20gJy4vY29tcG9uZW50cy9wYXlwYWwtY29tcG9uZW50JztcclxuXHJcbkBOZ01vZHVsZSh7XHJcbiAgaW1wb3J0czogW1xyXG4gIF0sXHJcbiAgZGVjbGFyYXRpb25zOiBbXHJcbiAgICBOZ3hQYXlwYWxDb21wb25lbnQsXHJcbiAgXSxcclxuICBleHBvcnRzOiBbXHJcbiAgICBOZ3hQYXlwYWxDb21wb25lbnQsXHJcbiAgXVxyXG59KVxyXG5leHBvcnQgY2xhc3MgTmd4UGF5UGFsTW9kdWxlIHtcclxufVxyXG5cclxuXHJcbiIsImV4cG9ydCBlbnVtIFBheVBhbEVudmlyb25tZW50IHtcclxuICAgIFNhbmRib3ggPSAnc2FuZGJveCcsXHJcbiAgICBQcm9kdWN0aW9uID0gJ3Byb2R1Y3Rpb24nXHJcbn1cclxuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7SUFDSSxPQUFJO0lBQ0osU0FBTTtJQUNOLE1BQUc7Ozs7Ozs7Ozs7OztJQ0ZILGlCQUFjO0lBQ2QsaUJBQWM7Ozs7Ozs7OztBQ0lsQixNQUFhLFlBQVk7Ozs7OztJQXdFckIsWUFJVyxlQUFzQyxFQUl0QyxXQUE4QixFQUNyQyxNQWdCQztRQXJCTSxvQkFBZSxHQUFmLGVBQWUsQ0FBdUI7UUFJdEMsZ0JBQVcsR0FBWCxXQUFXLENBQW1COzs7O1FBM0VsQyxXQUFNLEdBQUcsSUFBSSxDQUFDOzs7O1FBS2QsV0FBTSxHQUFHLE1BQU0sQ0FBQztRQXdGbkIsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsTUFBTSxDQUFDLENBQUM7S0FDL0I7Q0FDSjs7Ozs7O0FDMUdELE1BK0JhLGtCQUFrQjtJQWtFM0I7Ozs7UUF4RFMsb0JBQWUsR0FBRyxLQUFLLENBQUM7Ozs7UUFVekIsNkNBQXdDLEdBQUcsS0FBSyxDQUFDOzs7O1FBZXhDLHdCQUFtQixHQUFHLEVBQUUsQ0FBQzs7OztRQUt6Qix3QkFBbUIsR0FBRyxJQUFJLENBQUM7Ozs7UUFLM0IscUJBQWdCLEdBQUcsUUFBUSxDQUFDOzs7O1FBSzVCLGdDQUEyQixHQUFHLDZCQUE2QixDQUFDOzs7O1FBSzVELG9CQUFlLEdBQUcsK0NBQStDLENBQUM7UUFPbEUsa0NBQTZCLEdBQUcsOEJBQThCLENBQUM7UUFFL0Qsa0JBQWEsR0FBa0IsSUFBSSxPQUFPLEVBQVEsQ0FBQztLQUluRTs7Ozs7SUExQ0QsSUFBNEMseUJBQXlCLENBQUMsT0FBbUI7UUFDckYsSUFBSSxPQUFPLEVBQUU7WUFDVCxJQUFJLENBQUMsMEJBQTBCLEdBQUcsT0FBTyxDQUFDO1NBQzdDO0tBQ0o7Ozs7O0lBd0NELFdBQVcsQ0FBQyxPQUFzQjs7UUFFOUIsSUFBSSxJQUFJLENBQUMsTUFBTSxFQUFFO1lBQ2IsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1NBQ3JCO0tBQ0o7Ozs7SUFFRCxlQUFlOztRQUVYLElBQUksSUFBSSxDQUFDLHdDQUF3QyxJQUFJLElBQUksQ0FBQywwQkFBMEIsRUFBRTtZQUNsRixJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7WUFDbkIsSUFBSSxDQUFDLHdDQUF3QyxHQUFHLEtBQUssQ0FBQztTQUN6RDtLQUNKOzs7O0lBRUQsV0FBVztRQUNQLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxFQUFFLENBQUM7UUFDMUIsSUFBSSxDQUFDLGFBQWEsQ0FBQyxRQUFRLEVBQUUsQ0FBQztLQUNqQzs7OztJQUVPLFVBQVU7O1FBRWQsSUFBSSxDQUFDLHVCQUF1QixHQUFHLEdBQUcsSUFBSSxDQUFDLDZCQUE2QixHQUFHLElBQUksQ0FBQyxxQkFBcUIsRUFBRSxFQUFFLENBQUM7O1FBRXRHLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLEVBQUU7O1lBRWhDLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQywyQkFBMkIsQ0FBQyxLQUFLLElBQUksRUFBRTtnQkFDbkQsSUFBSSxDQUFDLHdCQUF3QixFQUFFLENBQUM7YUFDbkM7aUJBQU07O2dCQUVILE1BQU0sQ0FBQyxJQUFJLENBQUMsMkJBQTJCLENBQUMsR0FBRyxJQUFJLENBQUM7Z0JBQ2hELElBQUksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO2FBQ2hDO1NBRUo7YUFBTTs7WUFFSCxJQUFJLENBQUMsdUJBQXVCLEVBQUUsQ0FBQztTQUNsQztLQUNKOzs7O0lBRU8scUJBQXFCO1FBQ3pCLE9BQU8sSUFBSSxJQUFJLEVBQUUsQ0FBQyxPQUFPLEVBQUUsQ0FBQztLQUMvQjs7Ozs7O0lBTU8sd0JBQXdCOztjQUN0QixHQUFHLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQzthQUN6QyxJQUFJLENBQ0QsU0FBUyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsRUFDN0IsR0FBRyxDQUFDLENBQUMsQ0FBQztZQUNGLElBQUksQ0FBQyxJQUFJLElBQUksQ0FBQyxtQkFBbUIsRUFBRTtnQkFDL0IsT0FBTyxDQUFDLElBQUksQ0FBQyx1Q0FBdUMsSUFBSSxDQUFDLG1CQUFtQix5QkFBeUIsQ0FBQyxDQUFDO2dCQUN2RyxHQUFHLENBQUMsV0FBVyxFQUFFLENBQUM7Z0JBQ2xCLE9BQU87YUFDVjs7WUFHRCxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsRUFBRTs7Z0JBRS9CLElBQUksQ0FBQyx1QkFBdUIsRUFBRSxDQUFDOztnQkFHL0IsR0FBRyxDQUFDLFdBQVcsRUFBRSxDQUFDO2FBQ3JCO1NBQ0osQ0FBQyxDQUNMO2FBQ0EsU0FBUyxFQUFFO0tBQ25COzs7O0lBRU8scUJBQXFCOztjQUNuQixNQUFNLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUM7UUFDL0MsTUFBTSxDQUFDLFNBQVMsR0FBRyxFQUFFLENBQUM7UUFDdEIsTUFBTSxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDO1FBQ2xDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsTUFBTSxJQUFJLENBQUMsdUJBQXVCLEVBQUUsQ0FBQztRQUNyRCxNQUFNLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQztRQUNwQixNQUFNLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQztRQUVwQixJQUFJLENBQUMsZ0JBQWdCLENBQUMsYUFBYSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQztLQUMzRDs7OztJQUVPLHVCQUF1Qjs7OztRQUkzQixJQUFJLElBQUksQ0FBQywwQkFBMEIsSUFBSSxJQUFJLENBQUMsMEJBQTBCLENBQUMsYUFBYTtZQUNoRixJQUFJLENBQUMsMEJBQTBCLENBQUMsYUFBYSxDQUFDLEVBQUUsS0FBSyxJQUFJLENBQUMsdUJBQXVCLEVBQUU7O1lBRW5GLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztTQUN0QjthQUFNOztZQUVILElBQUksQ0FBQyx3Q0FBd0MsR0FBRyxJQUFJLENBQUM7U0FDeEQ7S0FDSjs7OztJQUVPLFdBQVc7O1FBRWYsSUFBSSxDQUFDLElBQUksQ0FBQywwQkFBMEIsRUFBRTtZQUNsQyxNQUFNLEtBQUssQ0FBQyxnRUFBZ0UsSUFBSSxDQUFDLHVCQUF1QixvQkFBb0IsQ0FBQyxDQUFDO1NBQ2pJO1FBRUQsSUFBSSxDQUFDLDBCQUEwQixDQUFDLGFBQWEsQ0FBQyxTQUFTLEdBQUcsRUFBRSxDQUFDO1FBRTdELElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLEVBQUU7WUFDaEMsTUFBTSxLQUFLLENBQUMsZ0NBQWdDLENBQUMsQ0FBQztTQUNqRDs7O1FBSUQsTUFBTSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7O1lBRXhDLEdBQUcsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxRQUFRLEVBQUU7O1lBR3ZDLE1BQU0sRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU07O1lBRzFCLE1BQU0sRUFBRSxJQUFJLENBQUMsU0FBUyxFQUFFOztZQUd4QixLQUFLLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNOztZQUd6QixPQUFPLEVBQUUsSUFBSSxDQUFDLFVBQVUsRUFBRTs7WUFHMUIsT0FBTyxFQUFFLENBQUMsSUFBSSxFQUFFLE9BQU87Z0JBQ25CLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxlQUFlLEtBQUsscUJBQXFCLENBQUMsY0FBYyxFQUFFOztvQkFFdEUsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFO3dCQUN0QixNQUFNLEtBQUssQ0FBQzttRkFDK0MsQ0FBQyxDQUFDO3FCQUNoRTs7b0JBR0QsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sRUFBRSxDQUFDLFNBQVMsRUFBRTt5QkFDbkMsSUFBSSxDQUFDLFNBQVM7d0JBQ1gsT0FBTyxTQUFTLENBQUM7cUJBQ3BCLENBQUMsQ0FBQztpQkFDVjtnQkFFRCxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsZUFBZSxLQUFLLHFCQUFxQixDQUFDLGNBQWMsRUFBRTtvQkFDdEUsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsWUFBWSxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLE1BQU0sSUFBSSxDQUFDLEVBQUU7d0JBQy9HLE1BQU0sS0FBSyxDQUFDLHdFQUF3RSxDQUFDLENBQUM7cUJBQ3pGOzswQkFFSyxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLFVBQVU7b0JBQy9DLE9BQU8sT0FBTyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUM7d0JBQzFCLE9BQU8sRUFBRTs7NEJBRUwsTUFBTSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLE1BQU07NEJBQ3hELFlBQVksRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVk7eUJBQ3pDO3dCQUNELFVBQVUsRUFBRTs0QkFDUixZQUFZLEVBQUU7Z0NBQ1YsV0FBVyxFQUFFLENBQUMsZ0JBQWdCLElBQUksZ0JBQWdCLENBQUMsVUFBVSxJQUFJLENBQUMsR0FBRyxDQUFDOzZCQUN6RTs0QkFDRCxZQUFZLEVBQUU7Z0NBQ1YsVUFBVSxFQUFFLENBQUMsZ0JBQWdCLElBQUksZ0JBQWdCLENBQUMsU0FBUyxJQUFJLGdCQUFnQixDQUFDLFNBQVMsR0FBRyxJQUFJO2dDQUNoRyxVQUFVLEVBQUUsQ0FBQyxnQkFBZ0IsSUFBSSxnQkFBZ0IsQ0FBQyxTQUFTLElBQUksZ0JBQWdCLENBQUMsU0FBUyxHQUFHLElBQUk7Z0NBQ2hHLFdBQVcsRUFBRSxDQUFDLGdCQUFnQixJQUFJLGdCQUFnQixDQUFDLFVBQVUsSUFBSSxnQkFBZ0IsQ0FBQyxVQUFVLEdBQUcsSUFBSTs2QkFDdEc7eUJBQ0o7cUJBQ0osQ0FBQyxDQUFDO2lCQUNOO2FBQ0o7O1lBR0QsV0FBVyxFQUFFLENBQUMsSUFBZ0MsRUFBRSxPQUFZO2dCQUN4RCxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsZUFBZSxLQUFLLHFCQUFxQixDQUFDLGNBQWMsRUFBRTs7b0JBRXRFLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsRUFBRTt3QkFDMUIsTUFBTSxLQUFLLENBQUMsc0VBQXNFLENBQUMsQ0FBQztxQkFDdkY7O29CQUdELE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxDQUFDLFNBQVMsRUFBRSxDQUFDO2lCQUM3RDtnQkFFRCxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsZUFBZSxLQUFLLHFCQUFxQixDQUFDLGNBQWMsRUFBRTs7b0JBRXRFLE9BQU8sT0FBTyxDQUFDLE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFJLENBQUM7d0JBQ2xDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLGlCQUFpQixFQUFFOzRCQUNoQyxNQUFNLEtBQUssQ0FBQyw4RkFBOEYsQ0FBQyxDQUFDO3lCQUMvRzt3QkFDRCxJQUFJLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsQ0FBQztxQkFDaEQsQ0FBQyxDQUFDO2lCQUNOO2FBQ0o7WUFFRCxPQUFPLEVBQUUsQ0FBQyxHQUFHO2dCQUNULElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUU7b0JBQ3JCLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2lCQUM1QjthQUNKO1lBRUQsUUFBUSxFQUFFLENBQUMsSUFBSSxFQUFFLE9BQU87Z0JBQ3BCLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEVBQUU7b0JBQ3RCLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsQ0FBQztpQkFDdkM7YUFDSjtZQUNELE9BQU8sRUFBRTtnQkFDTCxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFO29CQUNyQixJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sRUFBRSxDQUFDO2lCQUN6QjthQUNKO1lBQ0QsUUFBUSxFQUFFLENBQUMsT0FBTztnQkFDZCxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxFQUFFO29CQUN0QixJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQztpQkFDakM7YUFDSjtTQUNKLEVBQUUsSUFBSSxJQUFJLENBQUMsdUJBQXVCLEVBQUUsQ0FBQyxDQUFDO0tBQzFDOzs7O0lBRU8sU0FBUztRQUNiLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxlQUFlLEtBQUsscUJBQXFCLENBQUMsY0FBYyxFQUFFO1lBQ3RFLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRTtnQkFDckIsTUFBTSxLQUFLLENBQUMseUVBQXlFLENBQUMsQ0FBQzthQUMxRjtZQUVELE9BQU87Z0JBQ0gsVUFBVSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLFVBQVU7Z0JBQ3pDLE9BQU8sRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPO2FBQ3RDLENBQUM7U0FDTDtRQUVELE9BQU8sU0FBUyxDQUFDO0tBQ3BCOzs7O0lBRU8sVUFBVTs7UUFLZCxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUU7O1lBRXRCLE9BQU8sU0FBUyxDQUFDO1NBQ3BCOztjQUVLLE9BQU8sR0FBVSxFQUFFOztjQUNuQixVQUFVLEdBQVUsRUFBRTtRQUU1QixJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLE9BQU8sRUFBRTtZQUM3QixJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLElBQUk7Z0JBQ3BDLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO2FBQzNDLENBQUMsQ0FBQztTQUNOO1FBRUQsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxVQUFVLEVBQUU7WUFDaEMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxJQUFJO2dCQUN2QyxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQzthQUM5QyxDQUFDLENBQUM7U0FDTjtRQUVELE9BQU87WUFDSCxPQUFPLEVBQUUsT0FBTztZQUNoQixVQUFVLEVBQUUsVUFBVTtTQUN6QixDQUFDO0tBQ0w7Ozs7O0lBRU8sY0FBYyxDQUFDLElBQW1CO1FBQ3RDLElBQUksSUFBSSxLQUFLLGFBQWEsQ0FBQyxJQUFJLEVBQUU7WUFDN0IsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQztTQUM5QjtRQUNELElBQUksSUFBSSxLQUFLLGFBQWEsQ0FBQyxNQUFNLEVBQUU7WUFDL0IsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQztTQUNoQztRQUNELElBQUksSUFBSSxLQUFLLGFBQWEsQ0FBQyxHQUFHLEVBQUU7WUFDNUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQztTQUM3QjtRQUNELE1BQU0sS0FBSyxDQUFDLDZCQUE2QixJQUFJLEdBQUcsQ0FBQyxDQUFDO0tBQ3JEOzs7WUEvVkosU0FBUyxTQUFDO2dCQUNQLGVBQWUsRUFBRSx1QkFBdUIsQ0FBQyxNQUFNO2dCQUMvQyxRQUFRLEVBQUUsWUFBWTtnQkFDdEIsUUFBUSxFQUFFOzs7S0FHVDthQUNKOzs7OztxQkFNSSxLQUFLOzhCQUtMLEtBQUs7K0JBS0wsU0FBUyxTQUFDLGtCQUFrQjt3Q0FXNUIsU0FBUyxTQUFDLDJCQUEyQjs7Ozs7OztBQ3pEMUMsTUFjYSxlQUFlOzs7WUFWM0IsUUFBUSxTQUFDO2dCQUNSLE9BQU8sRUFBRSxFQUNSO2dCQUNELFlBQVksRUFBRTtvQkFDWixrQkFBa0I7aUJBQ25CO2dCQUNELE9BQU8sRUFBRTtvQkFDUCxrQkFBa0I7aUJBQ25CO2FBQ0Y7Ozs7Ozs7OztJQ1pHLFNBQVUsU0FBUztJQUNuQixZQUFhLFlBQVk7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7In0=

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/paymentgateway/paymentgateway.page.html":
/*!***********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/paymentgateway/paymentgateway.page.html ***!
  \***********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar>\r\n    <ion-title>Order Design</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n<ion-content>\r\n  <ion-list>\r\n    <ion-radio-group value=\"24\"  mode=\"md\" (ionChange)=\"select($event)\">\r\n      <ion-list-header>\r\n        <ion-label>Select priority for delivering design</ion-label>\r\n      </ion-list-header>\r\n  \r\n      <ion-item>\r\n        <ion-label>0-8 hrs</ion-label>\r\n        <ion-radio slot=\"start\" value=\"50\"></ion-radio>\r\n      </ion-item>\r\n  \r\n      <ion-item>\r\n        <ion-label>8-12 hrs</ion-label>\r\n        <ion-radio slot=\"start\" value=\"36\"></ion-radio>\r\n      </ion-item>\r\n  \r\n      <ion-item>\r\n        <ion-label>12-18hrs</ion-label>\r\n        <ion-radio slot=\"start\" value=\"30\"></ion-radio>\r\n      </ion-item>\r\n\r\n\r\n      <ion-item>\r\n        <ion-label>18-24hrs</ion-label>\r\n        <ion-radio slot=\"start\" value=\"24\"></ion-radio>\r\n      </ion-item>\r\n    </ion-radio-group>\r\n  </ion-list>\r\n\r\n  <ion-grid>\r\n    <ion-row ion-padding>\r\n      <ion-col size=\"3.5\">\r\n        <ion-label>Left amount</ion-label>\r\n          <p style=\"text-align: center;font-size: 13px;\">{{user.amount}}</p>\r\n      </ion-col>\r\n      <ion-col size=\"0.5\" style=\"display: flex;align-items: flex-end;\">\r\n\r\n          <p style=\"text-align: center;font-size: 13px;\">+</p>\r\n      </ion-col>\r\n      <ion-col size=\"4\">\r\n        <ion-label>Design amount</ion-label>\r\n        <p style=\"text-align: center;font-size: 13px;\">{{value}}</p>\r\n      </ion-col>\r\n      <ion-col size=\"4\">\r\n        <ion-label>Total cost</ion-label>\r\n        <p style=\"text-align: center;font-size: 13px;\">{{user.amount + value}}</p>\r\n      </ion-col>\r\n      \r\n        \r\n\r\n    </ion-row>\r\n    <ion-row>\r\n      <ion-col size=\"4\">\r\n        <ion-button color=\"primary\">Add money</ion-button>\r\n      </ion-col>\r\n      <ion-col size=\"4\">\r\n        <ion-button color=\"warning\">Pay with wallet</ion-button>\r\n      </ion-col>\r\n      <ion-col size=\"4\" >\r\n        <ion-button color=\"light\">Pay with card</ion-button>\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n\r\n  \r\n\r\n \r\n\r\n</ion-content>\r\n");

/***/ }),

/***/ "./src/app/paymentgateway/paymentgateway-routing.module.ts":
/*!*****************************************************************!*\
  !*** ./src/app/paymentgateway/paymentgateway-routing.module.ts ***!
  \*****************************************************************/
/*! exports provided: PaymentgatewayPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PaymentgatewayPageRoutingModule", function() { return PaymentgatewayPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _paymentgateway_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./paymentgateway.page */ "./src/app/paymentgateway/paymentgateway.page.ts");




const routes = [
    {
        path: '',
        component: _paymentgateway_page__WEBPACK_IMPORTED_MODULE_3__["PaymentgatewayPage"]
    }
];
let PaymentgatewayPageRoutingModule = class PaymentgatewayPageRoutingModule {
};
PaymentgatewayPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], PaymentgatewayPageRoutingModule);



/***/ }),

/***/ "./src/app/paymentgateway/paymentgateway.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/paymentgateway/paymentgateway.module.ts ***!
  \*********************************************************/
/*! exports provided: PaymentgatewayPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PaymentgatewayPageModule", function() { return PaymentgatewayPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _paymentgateway_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./paymentgateway-routing.module */ "./src/app/paymentgateway/paymentgateway-routing.module.ts");
/* harmony import */ var _paymentgateway_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./paymentgateway.page */ "./src/app/paymentgateway/paymentgateway.page.ts");
/* harmony import */ var ngx_paypal__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ngx-paypal */ "./node_modules/ngx-paypal/fesm2015/ngx-paypal.js");
/* harmony import */ var _ionic_native_stripe_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic-native/stripe/ngx */ "./node_modules/@ionic-native/stripe/ngx/index.js");









let PaymentgatewayPageModule = class PaymentgatewayPageModule {
};
PaymentgatewayPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _paymentgateway_routing_module__WEBPACK_IMPORTED_MODULE_5__["PaymentgatewayPageRoutingModule"],
            ngx_paypal__WEBPACK_IMPORTED_MODULE_7__["NgxPayPalModule"]
        ],
        declarations: [_paymentgateway_page__WEBPACK_IMPORTED_MODULE_6__["PaymentgatewayPage"]],
        providers: [
            _ionic_native_stripe_ngx__WEBPACK_IMPORTED_MODULE_8__["Stripe"]
        ]
    })
], PaymentgatewayPageModule);



/***/ }),

/***/ "./src/app/paymentgateway/paymentgateway.page.scss":
/*!*********************************************************!*\
  !*** ./src/app/paymentgateway/paymentgateway.page.scss ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".error {\n  color: #df3e3e;\n  font-size: 11px;\n  margin-left: 5px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGF5bWVudGdhdGV3YXkvRjpcXG1vYmlsZWFwcC9zcmNcXGFwcFxccGF5bWVudGdhdGV3YXlcXHBheW1lbnRnYXRld2F5LnBhZ2Uuc2NzcyIsInNyYy9hcHAvcGF5bWVudGdhdGV3YXkvcGF5bWVudGdhdGV3YXkucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksY0FBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtBQ0NKIiwiZmlsZSI6InNyYy9hcHAvcGF5bWVudGdhdGV3YXkvcGF5bWVudGdhdGV3YXkucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmVycm9yIHtcclxuICAgIGNvbG9yOiByZ2IoMjIzLCA2MiwgNjIpO1xyXG4gICAgZm9udC1zaXplOiAxMXB4O1xyXG4gICAgbWFyZ2luLWxlZnQ6IDVweDtcclxuICB9IiwiLmVycm9yIHtcbiAgY29sb3I6ICNkZjNlM2U7XG4gIGZvbnQtc2l6ZTogMTFweDtcbiAgbWFyZ2luLWxlZnQ6IDVweDtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/paymentgateway/paymentgateway.page.ts":
/*!*******************************************************!*\
  !*** ./src/app/paymentgateway/paymentgateway.page.ts ***!
  \*******************************************************/
/*! exports provided: PaymentgatewayPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PaymentgatewayPage", function() { return PaymentgatewayPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _storage_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../storage.service */ "./src/app/storage.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");




// import {
//   IPayPalConfig,
//   ICreateOrderRequest 
// } from 'ngx-paypal';
let PaymentgatewayPage = class PaymentgatewayPage {
    constructor(storage, navController) {
        this.storage = storage;
        this.navController = navController;
        this.value = 24;
    }
    ngOnInit() {
        this.user = this.storage.getUser();
    }
    routerLink() {
        this.navController.navigateRoot('add-money');
    }
    select(e) {
        console.log(e);
        this.value = parseInt(e.target.value);
    }
};
PaymentgatewayPage.ctorParameters = () => [
    { type: _storage_service__WEBPACK_IMPORTED_MODULE_2__["StorageService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"] }
];
PaymentgatewayPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-paymentgateway',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./paymentgateway.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/paymentgateway/paymentgateway.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./paymentgateway.page.scss */ "./src/app/paymentgateway/paymentgateway.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_storage_service__WEBPACK_IMPORTED_MODULE_2__["StorageService"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"]])
], PaymentgatewayPage);



/***/ })

}]);
//# sourceMappingURL=default~paymentgateway-paymentgateway-module~profile-profile-module-es2015.js.map