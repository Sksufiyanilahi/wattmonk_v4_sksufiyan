function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["chat-chat-module"], {
  /***/
  "./node_modules/@ionic-native/chooser/ngx/index.js":
  /*!*********************************************************!*\
    !*** ./node_modules/@ionic-native/chooser/ngx/index.js ***!
    \*********************************************************/

  /*! exports provided: Chooser */

  /***/
  function node_modulesIonicNativeChooserNgxIndexJs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Chooser", function () {
      return Chooser;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _ionic_native_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic-native/core */
    "./node_modules/@ionic-native/core/index.js");

    var Chooser =
    /** @class */
    function (_super) {
      Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(Chooser, _super);

      function Chooser() {
        return _super !== null && _super.apply(this, arguments) || this;
      }

      Chooser.prototype.getFile = function (accept) {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "getFile", {}, arguments);
      };

      Chooser.prototype.getFileMetadata = function (accept) {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "getFileMetadata", {}, arguments);
      };

      Chooser.pluginName = "Chooser";
      Chooser.plugin = "cordova-plugin-chooser";
      Chooser.pluginRef = "chooser";
      Chooser.repo = "https://github.com/cyph/cordova-plugin-chooser";
      Chooser.platforms = ["Android", "iOS"];
      Chooser = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])()], Chooser);
      return Chooser;
    }(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["IonicNativePlugin"]); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvQGlvbmljLW5hdGl2ZS9wbHVnaW5zL2Nob29zZXIvbmd4L2luZGV4LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQSxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQzNDLE9BQU8sOEJBQXNDLE1BQU0sb0JBQW9CLENBQUM7O0lBc0QzQywyQkFBaUI7Ozs7SUFRNUMseUJBQU8sYUFBQyxNQUFlO0lBV3ZCLGlDQUFlLGFBQUMsTUFBZTs7Ozs7O0lBbkJwQixPQUFPO1FBRG5CLFVBQVUsRUFBRTtPQUNBLE9BQU87a0JBdkRwQjtFQXVENkIsaUJBQWlCO1NBQWpDLE9BQU8iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBDb3Jkb3ZhLCBJb25pY05hdGl2ZVBsdWdpbiwgUGx1Z2luIH0gZnJvbSAnQGlvbmljLW5hdGl2ZS9jb3JlJztcblxuZXhwb3J0IGludGVyZmFjZSBDaG9vc2VyUmVzdWx0IHtcbiAgZGF0YT86IFVpbnQ4QXJyYXk7XG4gIGRhdGFVUkk/OiBzdHJpbmc7XG4gIG1lZGlhVHlwZTogc3RyaW5nO1xuICBuYW1lOiBzdHJpbmc7XG4gIHVyaTogc3RyaW5nO1xufVxuXG4vKipcbiAqIEBuYW1lIENob29zZXJcbiAqIEBkZXNjcmlwdGlvblxuICogRmlsZSBjaG9vc2VyIHBsdWdpbiBmb3IgQ29yZG92YS5cbiAqXG4gKiBUaGUgZm9sbG93aW5nIG11c3QgYmUgYWRkZWQgdG8gY29uZmlnLnhtbCB0byBwcmV2ZW50IGNyYXNoaW5nIHdoZW4gc2VsZWN0aW5nIGxhcmdlIGZpbGVzIG9uIEFuZHJvaWQ6XG4gKiBgYGB4bWxcbiAqIDxwbGF0Zm9ybSBuYW1lPVwiYW5kcm9pZFwiPlxuICogIDxlZGl0LWNvbmZpZ1xuICogICAgZmlsZT1cImFwcC9zcmMvbWFpbi9BbmRyb2lkTWFuaWZlc3QueG1sXCJcbiAqICAgIG1vZGU9XCJtZXJnZVwiXG4gKiAgICB0YXJnZXQ9XCIvbWFuaWZlc3QvYXBwbGljYXRpb25cIj5cbiAqICAgIDxhcHBsaWNhdGlvbiBhbmRyb2lkOmxhcmdlSGVhcD1cInRydWVcIiAvPlxuICogIDwvZWRpdC1jb25maWc+XG4gKiA8L3BsYXRmb3JtPlxuICogYGBgXG4gKlxuICogQHVzYWdlXG4gKiBgYGB0eXBlc2NyaXB0XG4gKiBpbXBvcnQgeyBDaG9vc2VyIH0gZnJvbSAnQGlvbmljLW5hdGl2ZS9jaG9vc2VyL25neCc7XG4gKlxuICpcbiAqIGNvbnN0cnVjdG9yKHByaXZhdGUgY2hvb3NlcjogQ2hvb3NlcikgeyB9XG4gKlxuICogLi4uXG4gKlxuICpcbiAqIHRoaXMuY2hvb3Nlci5nZXRGaWxlKClcbiAqICAgLnRoZW4oZmlsZSA9PiBjb25zb2xlLmxvZyhmaWxlID8gZmlsZS5uYW1lIDogJ2NhbmNlbGVkJykpXG4gKiAgIC5jYXRjaCgoZXJyb3I6IGFueSkgPT4gY29uc29sZS5lcnJvcihlcnJvcikpO1xuICpcbiAqIGBgYFxuICpcbiAqIEBpbnRlcmZhY2VzXG4gKiBDaG9vc2VyUmVzdWx0XG4gKi9cbkBQbHVnaW4oe1xuICBwbHVnaW5OYW1lOiAnQ2hvb3NlcicsXG4gIHBsdWdpbjogJ2NvcmRvdmEtcGx1Z2luLWNob29zZXInLFxuICBwbHVnaW5SZWY6ICdjaG9vc2VyJyxcbiAgcmVwbzogJ2h0dHBzOi8vZ2l0aHViLmNvbS9jeXBoL2NvcmRvdmEtcGx1Z2luLWNob29zZXInLFxuICBwbGF0Zm9ybXM6IFsnQW5kcm9pZCcsICdpT1MnXSxcbn0pXG5ASW5qZWN0YWJsZSgpXG5leHBvcnQgY2xhc3MgQ2hvb3NlciBleHRlbmRzIElvbmljTmF0aXZlUGx1Z2luIHtcbiAgLyoqXG4gICAqIERpc3BsYXlzIG5hdGl2ZSBwcm9tcHQgZm9yIHVzZXIgdG8gc2VsZWN0IGEgZmlsZS5cbiAgICogQHBhcmFtIHtzdHJpbmd9IFthY2NlcHRdIE9wdGlvbmFsIE1JTUUgdHlwZSBmaWx0ZXIgKGUuZy4gJ2ltYWdlL2dpZix2aWRlby8qJykuXG4gICAqIEByZXR1cm4ge1Byb21pc2U8YW55Pn0gUHJvbWlzZSBjb250YWluaW5nIHNlbGVjdGVkIGZpbGUncyByYXcgYmluYXJ5IGRhdGEsXG4gICAqIGJhc2U2NC1lbmNvZGVkIGRhdGE6IFVSSSwgTUlNRSB0eXBlLCBkaXNwbGF5IG5hbWUsIGFuZCBvcmlnaW5hbCBVUkkuXG4gICAqL1xuICBAQ29yZG92YSgpXG4gIGdldEZpbGUoYWNjZXB0Pzogc3RyaW5nKTogUHJvbWlzZTxDaG9vc2VyUmVzdWx0IHwgdW5kZWZpbmVkPiB7XG4gICAgcmV0dXJuO1xuICB9XG4gIC8qKlxuICAgKiBEaXNwbGF5cyBuYXRpdmUgcHJvbXB0IGZvciB1c2VyIHRvIHNlbGVjdCBhIGZpbGUuXG4gICAqIEBwYXJhbSB7c3RyaW5nfSBbYWNjZXB0XSBPcHRpb25hbCBNSU1FIHR5cGUgZmlsdGVyIChlLmcuICdpbWFnZS9naWYsdmlkZW8vKicpLlxuICAgKiBAcmV0dXJucyB7UHJvbWlzZTxhbnk+fSBQcm9taXNlIGNvbnRhaW5pbmcgc2VsZWN0ZWQgZmlsZSdzIE1JTUUgdHlwZSwgZGlzcGxheSBuYW1lLCBhbmQgb3JpZ2luYWwgVVJJLlxuICAgKiBJZiB1c2VyIGNhbmNlbHMsIHByb21pc2Ugd2lsbCBiZSByZXNvbHZlZCBhcyB1bmRlZmluZWQuXG4gICAqIElmIGVycm9yIG9jY3VycywgcHJvbWlzZSB3aWxsIGJlIHJlamVjdGVkLlxuICAgKi9cbiAgQENvcmRvdmEoKVxuICBnZXRGaWxlTWV0YWRhdGEoYWNjZXB0Pzogc3RyaW5nKTogUHJvbWlzZTxDaG9vc2VyUmVzdWx0IHwgdW5kZWZpbmVkPiB7XG4gICAgcmV0dXJuO1xuICB9XG59XG4iXX0=

    /***/

  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/chat/chat.page.html":
  /*!***************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/chat/chat.page.html ***!
    \***************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppChatChatPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\r\n    <ion-toolbar>\r\n        <ion-buttons slot=\"start\">\r\n            <ion-button fill=\"clear\" size=\"small\" class=\"ion-no-padding\" (click)=\"goBack()\">\r\n                <ion-img src=\"/assets/images/back.svg\" class=\"action-icon\"></ion-img>\r\n            </ion-button>\r\n        </ion-buttons>\r\n        <ion-title *ngIf=\"currentData\">\r\n            <div class=\"Inline\"><img\r\n                    src=\"{{currentData.avatar || 'https://i0.wp.com/www.winhelponline.com/blog/wp-content/uploads/2017/12/user.png?resize=256%2C256&quality=100&ssl=1' }}\"\r\n                    class=\"circular\"></div>\r\n            <div class=\"Inline\"><span style=\"padding:5px;\">{{currentData.name}}</span></div>\r\n            <p style=\"margin: 0px; font-size: small; padding-bottom: 2px;\">{{currentUserStatus}}</p>\r\n        </ion-title>\r\n    </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content padding #content [scrollEvents]=\"true\" (ionScrollStart)=\"logScrollStart()\"\r\n             (ionScroll)=\"logScrolling($event)\" (ionScrollEnd)=\"logScrollEnd()\">\r\n    <ion-list *ngIf=\"currentData\">\r\n        <div *ngFor=\"let message of userMessages\">\r\n            <div class=\"chat\" *ngIf=\"message !== undefined\">\r\n\t\t\t<span [class]=\"message.sender.uid === currentData.uid ? 'message me' : 'message you'\"\r\n                  *ngIf=\"message.type == 'text'\">\r\n\t\t\t\t{{message.text}}\r\n\t\t\t</span>\r\n\r\n                <span [class]=\"message.sender.uid === currentData.uid ? 'message meMedia' : 'message youMedia'\"\r\n                      *ngIf=\"message.type == 'image'\">\r\n\t\t\t\t<img src={{message.data.url}} style=\"height: 150px; width: 150px;\">\r\n\t\t\t</span>\r\n\r\n                <span [class]=\"message.sender.uid === currentData.uid ? 'message meMedia' : 'message youMedia'\"\r\n                      *ngIf=\"message.type == 'video'\">\r\n\t\t\t\t<video width=\"150px\" height=\"150px\" preload=\"auto\" controls>\r\n\t\t\t\t\t<source src={{message.data.url}}>\r\n\t\t\t\t</video>\r\n\t\t\t</span>\r\n\r\n                <span [class]=\"message.sender.uid === currentData.uid ? 'message me' : 'message you'\"\r\n                      *ngIf=\"message.type == 'file'\">\r\n                \t\t\t\t{{message.sender.name}} has sent you a file, you can download it<span\r\n                        style=\"font-weight: bold; font-style: italic;\"> here.</span>\r\n                \t\t\t</span>\r\n\r\n                <span class=\"imgSpan\">\r\n\t\t\t\t<img src=\"{{(message.deliveredAt > 0) ? (message.readAt > 0) ? ('../assets/images/readAt.png') : ('../assets/images/deliveredAt.png') : (message.readAt) ? ('../assets/images/readAt.png') : 'https://2.bp.blogspot.com/-XItmlQeH_-4/Vj9iojIcOHI/AAAAAAAA-f8/mU7SLoGV8Lk/s320/Single%2BTick%2BCheck%2BMark%2BPHOTO.jpg'}}\"\r\n                     [class]=\"message.sender.uid === currentData.uid ? 'hideTicks' : 'showTicks'\"\r\n                     style=\"width: 11px; height: 11px; margin-bottom: -5px;\">\r\n\t\t\t</span>\r\n            </div>\r\n        </div>\r\n    </ion-list>\r\n</ion-content>\r\n<ion-footer no-border>\r\n    <ion-toolbar>\r\n        <div class=\"bar bar-footer bar-balanced chat-box-container\">\r\n            <ion-input class=\"chat-editor-box\" placeholder=\"Type Your Message Here..\" type=\"text\"\r\n                       [(ngModel)]=\"messageText\" (ionBlur)=\"checkBlur()\" (ionFocus)=\"checkFocus()\"\r\n                       (ionInput)=\"checkInput()\"></ion-input>\r\n            <div class=\"btnSendChatView\">\r\n                <button item-right clear (click)='showActionSheet()' class=\"btnAttachMediaView\">\r\n                    <ion-icon name=\"attach\" class=\"btnAttachMedia\"></ion-icon>\r\n                </button>\r\n            </div>\r\n            <div class=\"btnSendChatView\">\r\n                <button item-right clear (click)='sendMessage()' class=\"btnSendChatView\">\r\n                    <ion-icon name=\"send\" class=\"btnSendChat\"></ion-icon>\r\n                </button>\r\n            </div>\r\n        </div>\r\n    </ion-toolbar>\r\n</ion-footer>\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/chat/image-viewer/image-viewer.component.html":
  /*!*****************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/chat/image-viewer/image-viewer.component.html ***!
    \*****************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppChatImageViewerImageViewerComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\r\n    <ion-toolbar color=\"dark\">\r\n        <ion-buttons slot=\"start\">\r\n            <ion-button (click)=\"closeModal()\">\r\n                <ion-icon slot=\"icon-only\" name=\"close\"></ion-icon>\r\n            </ion-button>\r\n        </ion-buttons>\r\n        <ion-title>Image</ion-title>\r\n    </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content [forceOverscroll]=\"false\" color=\"dark\" fullscreen=\"true\">\r\n    <div class=\"swiper-zoom-container\" style=\"height: 100%;\"></div>\r\n</ion-content>\r\n";
    /***/
  },

  /***/
  "./src/app/chat/chat-routing.module.ts":
  /*!*********************************************!*\
    !*** ./src/app/chat/chat-routing.module.ts ***!
    \*********************************************/

  /*! exports provided: ChatPageRoutingModule */

  /***/
  function srcAppChatChatRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ChatPageRoutingModule", function () {
      return ChatPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _chat_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./chat.page */
    "./src/app/chat/chat.page.ts");

    var routes = [{
      path: '',
      component: _chat_page__WEBPACK_IMPORTED_MODULE_3__["ChatPage"]
    }];

    var ChatPageRoutingModule = function ChatPageRoutingModule() {
      _classCallCheck(this, ChatPageRoutingModule);
    };

    ChatPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], ChatPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/chat/chat.module.ts":
  /*!*************************************!*\
    !*** ./src/app/chat/chat.module.ts ***!
    \*************************************/

  /*! exports provided: ChatPageModule */

  /***/
  function srcAppChatChatModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ChatPageModule", function () {
      return ChatPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _chat_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./chat-routing.module */
    "./src/app/chat/chat-routing.module.ts");
    /* harmony import */


    var _chat_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./chat.page */
    "./src/app/chat/chat.page.ts");
    /* harmony import */


    var _image_viewer_image_viewer_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ./image-viewer/image-viewer.component */
    "./src/app/chat/image-viewer/image-viewer.component.ts");
    /* harmony import */


    var _ionic_native_chooser_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! @ionic-native/chooser/ngx */
    "./node_modules/@ionic-native/chooser/ngx/index.js");
    /* harmony import */


    var _ionic_native_in_app_browser_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! @ionic-native/in-app-browser/ngx */
    "./node_modules/@ionic-native/in-app-browser/ngx/index.js"); // import { ImagePicker } from '@ionic-native/image-picker/ngx';


    var ChatPageModule = function ChatPageModule() {
      _classCallCheck(this, ChatPageModule);
    };

    ChatPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _chat_routing_module__WEBPACK_IMPORTED_MODULE_5__["ChatPageRoutingModule"]],
      declarations: [_chat_page__WEBPACK_IMPORTED_MODULE_6__["ChatPage"], _image_viewer_image_viewer_component__WEBPACK_IMPORTED_MODULE_7__["ImageViewerComponent"]],
      providers: [_ionic_native_chooser_ngx__WEBPACK_IMPORTED_MODULE_8__["Chooser"], _ionic_native_in_app_browser_ngx__WEBPACK_IMPORTED_MODULE_9__["InAppBrowser"]]
    })], ChatPageModule);
    /***/
  },

  /***/
  "./src/app/chat/chat.page.scss":
  /*!*************************************!*\
    !*** ./src/app/chat/chat.page.scss ***!
    \*************************************/

  /*! exports provided: default */

  /***/
  function srcAppChatChatPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "ion-avatar {\n  max-width: 25px;\n  max-height: 25px;\n}\n\n.circular {\n  width: 24px;\n  height: 24px;\n  border-radius: 50%;\n}\n\n.Inline {\n  display: inline-flex;\n  vertical-align: middle;\n}\n\n.chat-box-container {\n  bottom: 2px;\n  display: inline-flex;\n  padding: 0 8px 0 8px;\n  background: white;\n  width: 100%;\n}\n\n.chat-editor-box {\n  display: inline-flex;\n  justify-items: center;\n  background: white;\n  align-content: center;\n  align-items: center;\n  border: 1px solid #ccc;\n  border-radius: 24px;\n  padding-left: 4px !important;\n  font-size: 14px;\n  min-height: 38px;\n  max-height: 100px;\n}\n\n.btnSendChatView, .btnAttachMediaView {\n  height: 38px;\n  width: 38px;\n  margin-left: 4px;\n  background: #3c78d8;\n  color: white;\n  display: flex;\n  justify-content: center;\n  align-content: center;\n  align-items: center;\n  vertical-align: middle;\n  border-radius: 50%;\n}\n\n.btnSendChat, .btnAttachMedia {\n  height: 24px;\n  width: 24px;\n}\n\n.chat {\n  font-family: sans-serif;\n  display: flex;\n  flex-direction: column;\n}\n\n.message {\n  margin: 0.2em 0;\n  padding: 0.5em;\n  max-width: 70%;\n}\n\n.me {\n  margin-left: 13px;\n  align-self: flex-start;\n  background-color: #F1F0F0;\n  color: black;\n  border-radius: 10px 10px 10px 0px;\n}\n\n.you {\n  align-self: flex-end;\n  background-color: #3c78d8;\n  color: white;\n  border-radius: 10px 10px 0px 10px;\n  display: inline-block;\n  margin-right: 13px;\n}\n\n.youMedia {\n  align-self: flex-end;\n  color: white;\n  display: inline-block;\n  margin-right: 13px;\n}\n\n.meMedia {\n  align-self: flex-start;\n  color: black;\n}\n\n.videoClass {\n  background-color: none;\n  border-radius: none;\n}\n\n.showTicks {\n  display: block;\n}\n\n.hideTicks {\n  display: none;\n}\n\n.imgSpan {\n  align-self: flex-end;\n  display: inline-block;\n  position: relative;\n  top: -15px;\n  left: 0px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY2hhdC9GOlxcbW9iaWxlYXBwL3NyY1xcYXBwXFxjaGF0XFxjaGF0LnBhZ2Uuc2NzcyIsInNyYy9hcHAvY2hhdC9jaGF0LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGVBQUE7RUFDQSxnQkFBQTtBQ0NGOztBRENBO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFFQSxrQkFBQTtBQ0VGOztBRENBO0VBRUUsb0JBQUE7RUFDQSxzQkFBQTtBQ0NGOztBREdBO0VBQ0UsV0FBQTtFQUNBLG9CQUFBO0VBQ0Esb0JBQUE7RUFDQSxpQkFBQTtFQUNBLFdBQUE7QUNBRjs7QURFQTtFQUNFLG9CQUFBO0VBQ0EscUJBQUE7RUFDQSxpQkFBQTtFQUNBLHFCQUFBO0VBQ0EsbUJBQUE7RUFDQSxzQkFBQTtFQUNBLG1CQUFBO0VBQ0EsNEJBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtBQ0NGOztBREdBO0VBQ0UsWUFBQTtFQUNBLFdBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7RUFDQSx1QkFBQTtFQUNBLHFCQUFBO0VBQ0EsbUJBQUE7RUFDQSxzQkFBQTtFQUNBLGtCQUFBO0FDQUY7O0FER0E7RUFDRSxZQUFBO0VBQ0EsV0FBQTtBQ0FGOztBREdBO0VBQ0UsdUJBQUE7RUFDQSxhQUFBO0VBQ0Esc0JBQUE7QUNBRjs7QURHQTtFQUNFLGVBQUE7RUFDQSxjQUFBO0VBQ0EsY0FBQTtBQ0FGOztBREdBO0VBQ0UsaUJBQUE7RUFDQSxzQkFBQTtFQUNBLHlCQUFBO0VBQ0EsWUFBQTtFQUNBLGlDQUFBO0FDQUY7O0FER0E7RUFDRSxvQkFBQTtFQUNBLHlCQUFBO0VBQ0EsWUFBQTtFQUNBLGlDQUFBO0VBQ0EscUJBQUE7RUFDQSxrQkFBQTtBQ0FGOztBREdBO0VBQ0Usb0JBQUE7RUFDQSxZQUFBO0VBQ0EscUJBQUE7RUFDQSxrQkFBQTtBQ0FGOztBREdBO0VBQ0Usc0JBQUE7RUFDQSxZQUFBO0FDQUY7O0FER0E7RUFDRSxzQkFBQTtFQUNBLG1CQUFBO0FDQUY7O0FER0E7RUFDRSxjQUFBO0FDQUY7O0FER0E7RUFDRSxhQUFBO0FDQUY7O0FER0E7RUFDRSxvQkFBQTtFQUNBLHFCQUFBO0VBQ0Esa0JBQUE7RUFDQSxVQUFBO0VBQ0EsU0FBQTtBQ0FGIiwiZmlsZSI6InNyYy9hcHAvY2hhdC9jaGF0LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1hdmF0YXIge1xyXG4gIG1heC13aWR0aDogMjVweDtcclxuICBtYXgtaGVpZ2h0OiAyNXB4O1xyXG59XHJcbi5jaXJjdWxhcntcclxuICB3aWR0aDoyNHB4O1xyXG4gIGhlaWdodDoyNHB4O1xyXG4gIC13ZWJraXQtYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcclxufVxyXG5cclxuLklubGluZXtcclxuXHJcbiAgZGlzcGxheTogaW5saW5lLWZsZXg7XHJcbiAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcclxuXHJcbn1cclxuXHJcbi5jaGF0LWJveC1jb250YWluZXJ7XHJcbiAgYm90dG9tOiAycHg7XHJcbiAgZGlzcGxheTogaW5saW5lLWZsZXg7XHJcbiAgcGFkZGluZzogMCA4cHggMCA4cHg7XHJcbiAgYmFja2dyb3VuZDogd2hpdGU7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbn1cclxuLmNoYXQtZWRpdG9yLWJveHtcclxuICBkaXNwbGF5OiBpbmxpbmUtZmxleDtcclxuICBqdXN0aWZ5LWl0ZW1zOiBjZW50ZXI7XHJcbiAgYmFja2dyb3VuZDogd2hpdGU7XHJcbiAgYWxpZ24tY29udGVudDogY2VudGVyO1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgYm9yZGVyOiAxcHggc29saWQgI2NjYztcclxuICBib3JkZXItcmFkaXVzOiAyNHB4O1xyXG4gIHBhZGRpbmctbGVmdDogNHB4ICFpbXBvcnRhbnQ7XHJcbiAgZm9udC1zaXplOiAxNHB4O1xyXG4gIG1pbi1oZWlnaHQ6IDM4cHg7XHJcbiAgbWF4LWhlaWdodDogMTAwcHg7XHJcbn1cclxuXHJcblxyXG4uYnRuU2VuZENoYXRWaWV3LCAuYnRuQXR0YWNoTWVkaWFWaWV3e1xyXG4gIGhlaWdodDogMzhweDtcclxuICB3aWR0aDogMzhweDtcclxuICBtYXJnaW4tbGVmdDogNHB4O1xyXG4gIGJhY2tncm91bmQ6ICMzYzc4ZDg7XHJcbiAgY29sb3I6IHdoaXRlO1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgYWxpZ24tY29udGVudDogY2VudGVyO1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcclxuICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbn1cclxuXHJcbi5idG5TZW5kQ2hhdCwgLmJ0bkF0dGFjaE1lZGlhe1xyXG4gIGhlaWdodDogMjRweDtcclxuICB3aWR0aDogMjRweDtcclxufVxyXG5cclxuLmNoYXQge1xyXG4gIGZvbnQtZmFtaWx5OiBzYW5zLXNlcmlmO1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxufVxyXG5cclxuLm1lc3NhZ2Uge1xyXG4gIG1hcmdpbjogMC4yZW0gMDtcclxuICBwYWRkaW5nOiAwLjVlbTtcclxuICBtYXgtd2lkdGg6IDcwJTtcclxufVxyXG5cclxuLm1lIHtcclxuICBtYXJnaW4tbGVmdDogMTNweDtcclxuICBhbGlnbi1zZWxmOiBmbGV4LXN0YXJ0O1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICNGMUYwRjA7XHJcbiAgY29sb3I6IGJsYWNrO1xyXG4gIGJvcmRlci1yYWRpdXM6IDEwcHggMTBweCAxMHB4IDBweDtcclxufVxyXG5cclxuLnlvdSB7XHJcbiAgYWxpZ24tc2VsZjogZmxleC1lbmQ7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjojM2M3OGQ4O1xyXG4gIGNvbG9yOiB3aGl0ZTtcclxuICBib3JkZXItcmFkaXVzOiAxMHB4IDEwcHggMHB4IDEwcHg7XHJcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gIG1hcmdpbi1yaWdodDogMTNweDtcclxufVxyXG5cclxuLnlvdU1lZGlhe1xyXG4gIGFsaWduLXNlbGY6IGZsZXgtZW5kO1xyXG4gIGNvbG9yOiB3aGl0ZTtcclxuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgbWFyZ2luLXJpZ2h0OiAxM3B4O1xyXG59XHJcblxyXG4ubWVNZWRpYXtcclxuICBhbGlnbi1zZWxmOiBmbGV4LXN0YXJ0O1xyXG4gIGNvbG9yOiBibGFjaztcclxufVxyXG5cclxuLnZpZGVvQ2xhc3N7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogbm9uZTtcclxuICBib3JkZXItcmFkaXVzOiBub25lO1xyXG59XHJcblxyXG4uc2hvd1RpY2tze1xyXG4gIGRpc3BsYXk6IGJsb2NrO1xyXG59XHJcblxyXG4uaGlkZVRpY2tze1xyXG4gIGRpc3BsYXk6IG5vbmU7XHJcbn1cclxuXHJcbi5pbWdTcGFue1xyXG4gIGFsaWduLXNlbGY6IGZsZXgtZW5kO1xyXG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgdG9wOiAtMTVweDtcclxuICBsZWZ0OiAwcHg7XHJcbn1cclxuIiwiaW9uLWF2YXRhciB7XG4gIG1heC13aWR0aDogMjVweDtcbiAgbWF4LWhlaWdodDogMjVweDtcbn1cblxuLmNpcmN1bGFyIHtcbiAgd2lkdGg6IDI0cHg7XG4gIGhlaWdodDogMjRweDtcbiAgLXdlYmtpdC1ib3JkZXItcmFkaXVzOiA1MCU7XG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcbn1cblxuLklubGluZSB7XG4gIGRpc3BsYXk6IGlubGluZS1mbGV4O1xuICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xufVxuXG4uY2hhdC1ib3gtY29udGFpbmVyIHtcbiAgYm90dG9tOiAycHg7XG4gIGRpc3BsYXk6IGlubGluZS1mbGV4O1xuICBwYWRkaW5nOiAwIDhweCAwIDhweDtcbiAgYmFja2dyb3VuZDogd2hpdGU7XG4gIHdpZHRoOiAxMDAlO1xufVxuXG4uY2hhdC1lZGl0b3ItYm94IHtcbiAgZGlzcGxheTogaW5saW5lLWZsZXg7XG4gIGp1c3RpZnktaXRlbXM6IGNlbnRlcjtcbiAgYmFja2dyb3VuZDogd2hpdGU7XG4gIGFsaWduLWNvbnRlbnQ6IGNlbnRlcjtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgYm9yZGVyOiAxcHggc29saWQgI2NjYztcbiAgYm9yZGVyLXJhZGl1czogMjRweDtcbiAgcGFkZGluZy1sZWZ0OiA0cHggIWltcG9ydGFudDtcbiAgZm9udC1zaXplOiAxNHB4O1xuICBtaW4taGVpZ2h0OiAzOHB4O1xuICBtYXgtaGVpZ2h0OiAxMDBweDtcbn1cblxuLmJ0blNlbmRDaGF0VmlldywgLmJ0bkF0dGFjaE1lZGlhVmlldyB7XG4gIGhlaWdodDogMzhweDtcbiAgd2lkdGg6IDM4cHg7XG4gIG1hcmdpbi1sZWZ0OiA0cHg7XG4gIGJhY2tncm91bmQ6ICMzYzc4ZDg7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIGFsaWduLWNvbnRlbnQ6IGNlbnRlcjtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xufVxuXG4uYnRuU2VuZENoYXQsIC5idG5BdHRhY2hNZWRpYSB7XG4gIGhlaWdodDogMjRweDtcbiAgd2lkdGg6IDI0cHg7XG59XG5cbi5jaGF0IHtcbiAgZm9udC1mYW1pbHk6IHNhbnMtc2VyaWY7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG59XG5cbi5tZXNzYWdlIHtcbiAgbWFyZ2luOiAwLjJlbSAwO1xuICBwYWRkaW5nOiAwLjVlbTtcbiAgbWF4LXdpZHRoOiA3MCU7XG59XG5cbi5tZSB7XG4gIG1hcmdpbi1sZWZ0OiAxM3B4O1xuICBhbGlnbi1zZWxmOiBmbGV4LXN0YXJ0O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjRjFGMEYwO1xuICBjb2xvcjogYmxhY2s7XG4gIGJvcmRlci1yYWRpdXM6IDEwcHggMTBweCAxMHB4IDBweDtcbn1cblxuLnlvdSB7XG4gIGFsaWduLXNlbGY6IGZsZXgtZW5kO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjM2M3OGQ4O1xuICBjb2xvcjogd2hpdGU7XG4gIGJvcmRlci1yYWRpdXM6IDEwcHggMTBweCAwcHggMTBweDtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICBtYXJnaW4tcmlnaHQ6IDEzcHg7XG59XG5cbi55b3VNZWRpYSB7XG4gIGFsaWduLXNlbGY6IGZsZXgtZW5kO1xuICBjb2xvcjogd2hpdGU7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgbWFyZ2luLXJpZ2h0OiAxM3B4O1xufVxuXG4ubWVNZWRpYSB7XG4gIGFsaWduLXNlbGY6IGZsZXgtc3RhcnQ7XG4gIGNvbG9yOiBibGFjaztcbn1cblxuLnZpZGVvQ2xhc3Mge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiBub25lO1xuICBib3JkZXItcmFkaXVzOiBub25lO1xufVxuXG4uc2hvd1RpY2tzIHtcbiAgZGlzcGxheTogYmxvY2s7XG59XG5cbi5oaWRlVGlja3Mge1xuICBkaXNwbGF5OiBub25lO1xufVxuXG4uaW1nU3BhbiB7XG4gIGFsaWduLXNlbGY6IGZsZXgtZW5kO1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgdG9wOiAtMTVweDtcbiAgbGVmdDogMHB4O1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/chat/chat.page.ts":
  /*!***********************************!*\
    !*** ./src/app/chat/chat.page.ts ***!
    \***********************************/

  /*! exports provided: ChatPage */

  /***/
  function srcAppChatChatPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ChatPage", function () {
      return ChatPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _cometchat_pro_cordova_ionic_chat_CometChat__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @cometchat-pro/cordova-ionic-chat/CometChat */
    "./node_modules/@cometchat-pro/cordova-ionic-chat/CometChat.js");
    /* harmony import */


    var _cometchat_pro_cordova_ionic_chat_CometChat__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_cometchat_pro_cordova_ionic_chat_CometChat__WEBPACK_IMPORTED_MODULE_4__);
    /* harmony import */


    var _ionic_native_chooser_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic-native/chooser/ngx */
    "./node_modules/@ionic-native/chooser/ngx/index.js");
    /* harmony import */


    var _ionic_native_in_app_browser_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @ionic-native/in-app-browser/ngx */
    "./node_modules/@ionic-native/in-app-browser/ngx/index.js");
    /* harmony import */


    var _utilities_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ../utilities.service */
    "./src/app/utilities.service.ts");
    /* harmony import */


    var _image_viewer_image_viewer_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! ./image-viewer/image-viewer.component */
    "./src/app/chat/image-viewer/image-viewer.component.ts"); // import { ImagePicker } from '@ionic-native/image-picker/ngx';


    var ChatPage = /*#__PURE__*/function () {
      function ChatPage(route, navController, utilities, router, chooser, iab, actionSheetController, // private imagePicker: ImagePicker,
      modalController) {
        _classCallCheck(this, ChatPage);

        this.route = route;
        this.navController = navController;
        this.utilities = utilities;
        this.router = router;
        this.chooser = chooser;
        this.iab = iab;
        this.actionSheetController = actionSheetController;
        this.modalController = modalController;
        this.id = '';
        this.conversation = [];
        this.limit = 50;
        this.loggedInUserData = _cometchat_pro_cordova_ionic_chat_CometChat__WEBPACK_IMPORTED_MODULE_4__["CometChat"].getLoggedinUser();
        this.listenerId = 'OneOnOneMessageListners';
        this.showImage = 0;
        this.imageUrl = '';
        this.id = this.route.snapshot.paramMap.get('id');
        this.messagesRequest = new _cometchat_pro_cordova_ionic_chat_CometChat__WEBPACK_IMPORTED_MODULE_4__["CometChat"].MessagesRequestBuilder().setLimit(this.limit).setUID(this.id).build();
      }

      _createClass(ChatPage, [{
        key: "ionViewWillEnter",
        value: function ionViewWillEnter() {
          var _this = this;

          setTimeout(function () {
            console.log('scrolled caled');

            _this.content.scrollToBottom(300);
          }, 2000);
        }
      }, {
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this2 = this;

          _cometchat_pro_cordova_ionic_chat_CometChat__WEBPACK_IMPORTED_MODULE_4__["CometChat"].getUser(this.id).then(function (user) {
            console.log('User details fetched for user:', user);
            _this2.currentData = user;
            _this2.currentUserStatus = _this2.currentData.status;

            _this2.loadMessages();

            _this2.addMessageEventListner(); // this.addTypingListner();
            // this.addDeliveryReadEventListners();


            _this2.addUserEventListner();
          }, function (error) {
            console.log('User details fetching failed with error:', error);
          });
        }
      }, {
        key: "loadMessages",
        value: function loadMessages() {
          var _this3 = this;

          this.utilities.showLoading('Getting Conversation').then(function () {
            _this3.messagesRequest.fetchPrevious().then(function (messages) {
              _this3.utilities.hideLoading().then(function () {
                console.log('Message list fetched:', messages); // Handle the list of messages

                _this3.userMessages = messages; // this.userMessages.prepend(messages);
                // CometChat.markMessageAsRead(messages);

                console.log('UserMessages are ', _this3.userMessages); // this.content.scrollToBottom(1500);

                _this3.sendReadBulkReceipts();

                _this3.moveToBottom();
              });
            }, function (error) {
              _this3.utilities.hideLoading().then(function () {
                console.log('Message fetching failed with error:', error);
              });
            });
          });
        }
      }, {
        key: "addUserEventListner",
        value: function addUserEventListner() {
          var _this4 = this;

          var listenerID = 'UserEventsListner';

          _cometchat_pro_cordova_ionic_chat_CometChat__WEBPACK_IMPORTED_MODULE_4__["CometChat"].addUserListener(listenerID, new _cometchat_pro_cordova_ionic_chat_CometChat__WEBPACK_IMPORTED_MODULE_4__["CometChat"].UserListener({
            onUserOnline: function onUserOnline(onlineUser) {
              console.log('On User Online:', {
                onlineUser: onlineUser
              });

              if (onlineUser.uid === _this4.currentData.uid) {
                _this4.currentUserStatus = 'Online';
              }
            },
            onUserOffline: function onUserOffline(offlineUser) {
              console.log('On User Offline:', {
                offlineUser: offlineUser
              });

              if (offlineUser.uid === _this4.currentData.uid) {
                _this4.currentUserStatus = 'Offline';
              }
            }
          }));
        }
      }, {
        key: "viewImage",
        value: function viewImage(src) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            var modal;
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.modalController.create({
                      component: _image_viewer_image_viewer_component__WEBPACK_IMPORTED_MODULE_8__["ImageViewerComponent"],
                      componentProps: {
                        imgSource: src
                      },
                      cssClass: 'modal-fullscreen',
                      keyboardClose: true,
                      showBackdrop: true
                    });

                  case 2:
                    modal = _context.sent;
                    _context.next = 5;
                    return modal.present();

                  case 5:
                    return _context.abrupt("return", _context.sent);

                  case 6:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "loadPreviousMessages",
        value: function loadPreviousMessages() {
          var _this5 = this;

          this.messagesRequest.fetchPrevious().then(function (messages) {
            console.log('Message list fetched:', messages); // Handle the list of messages

            var newMessages = messages; // this.userMessages = messages;
            // this.userMessages.prepend(messages);

            if (newMessages !== '') {
              _this5.userMessages = newMessages.concat(_this5.userMessages);
            }

            console.log('UserMessages are ', _this5.userMessages); // this.content.scrollToBottom(1500);
          }, function (error) {
            console.log('Message fetching failed with error:', error);
          });
        }
      }, {
        key: "moveToBottom",
        value: function moveToBottom() {
          console.log('here moving to bottom');
          this.content.scrollToBottom(1500);
        }
      }, {
        key: "logScrollStart",
        value: function logScrollStart() {// console.log('logScrollStart : When Scroll Starts');
        }
      }, {
        key: "logScrolling",
        value: function logScrolling($event) {
          // console.log('logScrolling : When Scrolling ', $event.detail.scrollTop);
          if ($event.detail.scrollTop === 0) {
            // console.log('scroll reached to top');
            this.loadPreviousMessages();
          }
        }
      }, {
        key: "logScrollEnd",
        value: function logScrollEnd() {// console.log('logScrollEnd : When Scroll Ends');
        }
      }, {
        key: "addMessageEventListner",
        value: function addMessageEventListner() {
          var _this6 = this;

          // var listenerID = "OneOnOneMessage";
          _cometchat_pro_cordova_ionic_chat_CometChat__WEBPACK_IMPORTED_MODULE_4__["CometChat"].addMessageListener(this.listenerId, new _cometchat_pro_cordova_ionic_chat_CometChat__WEBPACK_IMPORTED_MODULE_4__["CometChat"].MessageListener({
            onTextMessageReceived: function onTextMessageReceived(textMessage) {
              console.log('Text message successfully', textMessage);

              if (textMessage.receiverID === _this6.loggedInUserData.uid && textMessage.sender.uid !== _this6.loggedInUserData.uid) {
                console.log('here the user has pushed 111');

                _this6.userMessages.push(textMessage); // CometChat.markMessageAsRead(textMessage);


                _this6.sendReadReceipts(textMessage);

                _this6.moveToBottom();
              } // Handle text message

            },
            onMediaMessageReceived: function onMediaMessageReceived(mediaMessage) {
              console.log('Media message received successfully', mediaMessage); // Handle media message
            },
            onCutomMessageReceived: function onCutomMessageReceived(customMessage) {
              console.log('Media message received successfully', customMessage); // Handle media message
            },
            onMessageDelivered: function onMessageDelivered(messageReceipt) {
              console.log('MessageDeliverd', {
                messageReceipt: messageReceipt
              });

              _this6.updateDeliveredAt(messageReceipt);

              _this6.messageStatus = '';
            },
            onMessageRead: function onMessageRead(messageReceipt) {
              console.log('MessageRead', {
                messageReceipt: messageReceipt
              });

              _this6.updatedeReadAt(messageReceipt);

              _this6.messageStatus = '';
            },
            onTypingStarted: function onTypingStarted(typingIndicator) {
              console.log('Typing started :', typingIndicator);
              console.log('Typing uid :', typingIndicator.sender.uid);

              if (typingIndicator.sender.uid === _this6.currentData.uid) {
                _this6.currentUserStatus = 'typing....';
              }
            },
            onTypingEnded: function onTypingEnded(typingIndicator) {
              console.log('Typing ended :', typingIndicator);
              console.log('onTypingEnded uid :', typingIndicator.sender.uid);

              if (typingIndicator.sender.uid === _this6.currentData.uid) {
                _this6.currentUserStatus = _this6.currentData.status;
              }
            }
          }));
        }
      }, {
        key: "addDeliveryReadEventListners",
        value: function addDeliveryReadEventListners() {
          var _this7 = this;

          var listenerId = 'OneOnOneMessageDeliveryReadListners';

          _cometchat_pro_cordova_ionic_chat_CometChat__WEBPACK_IMPORTED_MODULE_4__["CometChat"].addMessageListener('listenerId', new _cometchat_pro_cordova_ionic_chat_CometChat__WEBPACK_IMPORTED_MODULE_4__["CometChat"].MessageListener({
            onMessageDelivered: function onMessageDelivered(messageReceipt) {
              console.log('MessageDeliverd', {
                messageReceipt: messageReceipt
              });

              _this7.updateDeliveredAt(messageReceipt);

              _this7.messageStatus = '';
            },
            onMessageRead: function onMessageRead(messageReceipt) {
              console.log('MessageRead', {
                messageReceipt: messageReceipt
              });

              _this7.updatedeReadAt(messageReceipt);

              _this7.messageStatus = '';
            }
          }));
        }
      }, {
        key: "addTypingListner",
        value: function addTypingListner() {
          var _this8 = this;

          var listenerId = 'OneOnOneTypingListner';

          _cometchat_pro_cordova_ionic_chat_CometChat__WEBPACK_IMPORTED_MODULE_4__["CometChat"].addMessageListener(listenerId, new _cometchat_pro_cordova_ionic_chat_CometChat__WEBPACK_IMPORTED_MODULE_4__["CometChat"].MessageListener({
            onTypingStarted: function onTypingStarted(typingIndicator) {
              console.log('Typing started :', typingIndicator);
              console.log('Typing uid :', typingIndicator.sender.uid);

              if (typingIndicator.sender.uid === _this8.currentData.uid) {
                _this8.currentUserStatus = 'typing....';
              }
            },
            onTypingEnded: function onTypingEnded(typingIndicator) {
              console.log('Typing ended :', typingIndicator);
              console.log('onTypingEnded uid :', typingIndicator.sender.uid);

              if (typingIndicator.sender.uid === _this8.currentData.uid) {
                _this8.currentUserStatus = _this8.currentData.status;
              }
            }
          }));
        }
      }, {
        key: "sendMessage",
        value: function sendMessage() {
          var _this9 = this;

          console.log('tapped on send Message ', this.messageText);

          if (this.messageText !== '') {
            var messageType = _cometchat_pro_cordova_ionic_chat_CometChat__WEBPACK_IMPORTED_MODULE_4__["CometChat"].MESSAGE_TYPE.TEXT;
            var receiverType = _cometchat_pro_cordova_ionic_chat_CometChat__WEBPACK_IMPORTED_MODULE_4__["CometChat"].RECEIVER_TYPE.USER;
            var textMessage = new _cometchat_pro_cordova_ionic_chat_CometChat__WEBPACK_IMPORTED_MODULE_4__["CometChat"].TextMessage(this.currentData.uid, this.messageText, receiverType);

            _cometchat_pro_cordova_ionic_chat_CometChat__WEBPACK_IMPORTED_MODULE_4__["CometChat"].sendMessage(textMessage).then(function (message) {
              console.log('Message sent successfully:', message); // Text Message Sent Successfully

              _this9.userMessages.push(message);

              _this9.messageText = ''; // this.content.scrollToBottom(1500);

              _this9.moveToBottom();
            }, function (error) {
              console.log('Message sending failed with error:', error);
            });
          }
        }
      }, {
        key: "checkBlur",
        value: function checkBlur() {
          console.log('checkBlur called');
          var receiverId = this.currentData.uid;
          var receiverType = _cometchat_pro_cordova_ionic_chat_CometChat__WEBPACK_IMPORTED_MODULE_4__["CometChat"].RECEIVER_TYPE.USER;
          var typingNotification = new _cometchat_pro_cordova_ionic_chat_CometChat__WEBPACK_IMPORTED_MODULE_4__["CometChat"].TypingIndicator(receiverId, receiverType);

          _cometchat_pro_cordova_ionic_chat_CometChat__WEBPACK_IMPORTED_MODULE_4__["CometChat"].endTyping(typingNotification);
        }
      }, {
        key: "checkFocus",
        value: function checkFocus() {
          console.log('checkFocus called');
        }
      }, {
        key: "checkInput",
        value: function checkInput() {
          console.log('checkInput called');
          var receiverId = this.currentData.uid;
          var receiverType = _cometchat_pro_cordova_ionic_chat_CometChat__WEBPACK_IMPORTED_MODULE_4__["CometChat"].RECEIVER_TYPE.USER;
          var typingNotification = new _cometchat_pro_cordova_ionic_chat_CometChat__WEBPACK_IMPORTED_MODULE_4__["CometChat"].TypingIndicator(receiverId, receiverType);

          _cometchat_pro_cordova_ionic_chat_CometChat__WEBPACK_IMPORTED_MODULE_4__["CometChat"].startTyping(typingNotification);
        }
      }, {
        key: "updatedeReadAt",
        value: function updatedeReadAt(messageReceipt) {
          for (var i = 0; i < this.userMessages.length; i++) {
            if (this.userMessages[i].id === messageReceipt.messageId) {
              console.log('here the Read item is', this.userMessages[i]);
              var timestamp = Number(messageReceipt.timestamp);
              this.userMessages[i].readAt = timestamp;
              console.log('here the readAt is', this.userMessages[i].readAt);
            }
          }
        }
      }, {
        key: "updateDeliveredAt",
        value: function updateDeliveredAt(messageReceipt) {
          for (var i = 0; i < this.userMessages.length; i++) {
            if (this.userMessages[i].id === messageReceipt.messageId) {
              console.log('here the Delivered item is', this.userMessages[i]);
              var timestamp = Number(messageReceipt.timestamp);
              this.userMessages[i].deliveredAt = timestamp;
            }
          }
        }
      }, {
        key: "sendReadReceipts",
        value: function sendReadReceipts(message) {
          for (var i = 0; i < this.userMessages.length; i++) {
            if (this.userMessages[i].id === message.id && this.userMessages[i].sender.uid !== this.loggedInUserData.uid) {
              console.log('here the sendReadReceipts item is', this.userMessages[i]);

              _cometchat_pro_cordova_ionic_chat_CometChat__WEBPACK_IMPORTED_MODULE_4__["CometChat"].markAsRead(this.userMessages[i].id, this.userMessages[i].sender.uid, this.userMessages[i].receiverType);
            }
          }
        }
      }, {
        key: "sendReadBulkReceipts",
        value: function sendReadBulkReceipts() {
          for (var i = 0; i < this.userMessages.length; i++) {
            if (this.userMessages[i].receiver !== this.currentData.uid) {
              _cometchat_pro_cordova_ionic_chat_CometChat__WEBPACK_IMPORTED_MODULE_4__["CometChat"].markAsRead(this.userMessages[i].id, this.userMessages[i].sender.uid, this.userMessages[i].receiverType);
            }
          }
        }
      }, {
        key: "showActionSheet",
        value: function showActionSheet() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
            var _this10 = this;

            var actionSheet;
            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    _context2.next = 2;
                    return this.actionSheetController.create({
                      header: 'Actions',
                      buttons: [{
                        text: 'Image',
                        handler: function handler() {
                          console.log('IMAGE PICKER CLICKED');

                          _this10.ImagePicker();
                        }
                      }, {
                        text: 'Document',
                        handler: function handler() {
                          console.log('DOCUMENT PICKER CLICKED');

                          _this10.DocumentPicker();
                        }
                      }, {
                        text: 'Cancel',
                        role: 'cancel',
                        handler: function handler() {
                          console.log('Cancel clicked');
                        }
                      }]
                    });

                  case 2:
                    actionSheet = _context2.sent;
                    _context2.next = 5;
                    return actionSheet.present();

                  case 5:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2, this);
          }));
        }
      }, {
        key: "DocumentPicker",
        value: function DocumentPicker() {
          var _this11 = this;

          this.chooser.getFile('all').then(function (response) {
            var blob_nw = _this11.dataURItoBlob(response.dataURI);

            var file = {
              file: blob_nw,
              type: response.mediaType,
              name: response.name
            };
            _this11.messageMedia = file;

            _this11.sendMediaMessage();
          })["catch"](function (e) {
            return console.log(e);
          });
        }
      }, {
        key: "ImagePicker",
        value: function ImagePicker() {// const options = {
          //   outputType: 1
          // };
          // this.imagePicker.getPictures(options)
          //   .then((results) => {
          //     results[0] = 'data:image/jpeg;base64,' + results[0];
          //     const blob_nw = this.dataURItoBlob(results[0]);
          //     const date = new Date();
          //     const file = {
          //       file: blob_nw,
          //       type: 'image/jpeg',
          //       name: 'temp_img' + date.getTime()
          //     };
          //     this.messageMedia = file;
          //     this.sendMediaMessage();
          //   }, (err) => {
          //     console.log(err);
          //   });
        }
      }, {
        key: "dataURItoBlob",
        value: function dataURItoBlob(dataURI) {
          var byteString = atob(dataURI.split(',')[1]);
          var mimeString = dataURI.split(',')[0].split(':')[1].split(';')[0];
          var ab = new ArrayBuffer(byteString.length);
          var ia = new Uint8Array(ab);

          for (var i = 0; i < byteString.length; i++) {
            ia[i] = byteString.charCodeAt(i);
          }

          var bb = new Blob([ab], {
            type: mimeString
          });
          return bb;
        }
      }, {
        key: "sendMediaMessage",
        value: function sendMediaMessage() {
          var _this12 = this;

          var messageType = _cometchat_pro_cordova_ionic_chat_CometChat__WEBPACK_IMPORTED_MODULE_4__["CometChat"].MESSAGE_TYPE.IMAGE;

          if (this.messageMedia.type.split('/')[0] === 'image') {
            messageType = _cometchat_pro_cordova_ionic_chat_CometChat__WEBPACK_IMPORTED_MODULE_4__["CometChat"].MESSAGE_TYPE.IMAGE;
          } else if (this.messageMedia.type.split('/')[0] === 'video') {
            messageType = _cometchat_pro_cordova_ionic_chat_CometChat__WEBPACK_IMPORTED_MODULE_4__["CometChat"].MESSAGE_TYPE.VIDEO;
          } else {
            messageType = _cometchat_pro_cordova_ionic_chat_CometChat__WEBPACK_IMPORTED_MODULE_4__["CometChat"].MESSAGE_TYPE.FILE;
          }

          var receiverType = _cometchat_pro_cordova_ionic_chat_CometChat__WEBPACK_IMPORTED_MODULE_4__["CometChat"].RECEIVER_TYPE.USER;
          var mediaMessage = new _cometchat_pro_cordova_ionic_chat_CometChat__WEBPACK_IMPORTED_MODULE_4__["CometChat"].MediaMessage(this.currentData.uid, this.messageMedia.file, messageType, receiverType);
          console.log('mediaMessage', mediaMessage);

          _cometchat_pro_cordova_ionic_chat_CometChat__WEBPACK_IMPORTED_MODULE_4__["CometChat"].sendMessage(mediaMessage).then(function (message) {
            console.log('cometchat send media message', message);

            _this12.userMessages.push(message);

            _this12.messageMedia = {};

            _this12.moveToBottom();
          }, function (error) {
            console.log('Media message sending failed with error', error);
          });
        }
      }, {
        key: "openLink",
        value: function openLink(url) {
          this.iab.create(url, '_system');
        }
      }, {
        key: "goBack",
        value: function goBack() {
          this.navController.pop();
        }
      }]);

      return ChatPage;
    }();

    ChatPage.ctorParameters = function () {
      return [{
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"]
      }, {
        type: _utilities_service__WEBPACK_IMPORTED_MODULE_7__["UtilitiesService"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
      }, {
        type: _ionic_native_chooser_ngx__WEBPACK_IMPORTED_MODULE_5__["Chooser"]
      }, {
        type: _ionic_native_in_app_browser_ngx__WEBPACK_IMPORTED_MODULE_6__["InAppBrowser"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ActionSheetController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"]
      }];
    };

    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('content', {
      "static": true
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)], ChatPage.prototype, "content", void 0);
    ChatPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-chat',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./chat.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/chat/chat.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./chat.page.scss */
      "./src/app/chat/chat.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"], _utilities_service__WEBPACK_IMPORTED_MODULE_7__["UtilitiesService"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _ionic_native_chooser_ngx__WEBPACK_IMPORTED_MODULE_5__["Chooser"], _ionic_native_in_app_browser_ngx__WEBPACK_IMPORTED_MODULE_6__["InAppBrowser"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ActionSheetController"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"]])], ChatPage);
    /***/
  },

  /***/
  "./src/app/chat/image-viewer/image-viewer.component.scss":
  /*!***************************************************************!*\
    !*** ./src/app/chat/image-viewer/image-viewer.component.scss ***!
    \***************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppChatImageViewerImageViewerComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "ion-slides {\n  height: 100%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY2hhdC9pbWFnZS12aWV3ZXIvRjpcXG1vYmlsZWFwcC9zcmNcXGFwcFxcY2hhdFxcaW1hZ2Utdmlld2VyXFxpbWFnZS12aWV3ZXIuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL2NoYXQvaW1hZ2Utdmlld2VyL2ltYWdlLXZpZXdlci5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFlBQUE7QUNDRiIsImZpbGUiOiJzcmMvYXBwL2NoYXQvaW1hZ2Utdmlld2VyL2ltYWdlLXZpZXdlci5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1zbGlkZXMge1xyXG4gIGhlaWdodDogMTAwJTtcclxufVxyXG4iLCJpb24tc2xpZGVzIHtcbiAgaGVpZ2h0OiAxMDAlO1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/chat/image-viewer/image-viewer.component.ts":
  /*!*************************************************************!*\
    !*** ./src/app/chat/image-viewer/image-viewer.component.ts ***!
    \*************************************************************/

  /*! exports provided: ImageViewerComponent */

  /***/
  function srcAppChatImageViewerImageViewerComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ImageViewerComponent", function () {
      return ImageViewerComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");

    var ImageViewerComponent = /*#__PURE__*/function () {
      function ImageViewerComponent(modalController) {
        _classCallCheck(this, ImageViewerComponent);

        this.modalController = modalController;
      }

      _createClass(ImageViewerComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "closeModal",
        value: function closeModal() {
          this.modalController.dismiss();
        }
      }]);

      return ImageViewerComponent;
    }();

    ImageViewerComponent.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]
      }];
    };

    ImageViewerComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-image-viewer',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./image-viewer.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/chat/image-viewer/image-viewer.component.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./image-viewer.component.scss */
      "./src/app/chat/image-viewer/image-viewer.component.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]])], ImageViewerComponent);
    /***/
  }
}]);
//# sourceMappingURL=chat-chat-module-es5.js.map