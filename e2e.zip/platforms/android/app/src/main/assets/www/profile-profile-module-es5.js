function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["profile-profile-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/profile/profile-history/profile-history.component.html":
  /*!**************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/profile/profile-history/profile-history.component.html ***!
    \**************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppProfileProfileHistoryProfileHistoryComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-content style=\"--background: #FEF8F8;\">\r\n   <ion-grid>\r\n    <ion-row >\r\n      <ion-col size=\"2\">\r\n        <ion-img class=\"profile-icon\" src=\"/assets/images/icons8-checked.svg\"></ion-img>\r\n      </ion-col>\r\n      <ion-col size=\"10\" style=\"margin-top: 6px;\">\r\n        <div style=\"display: flex; justify-content: space-between;\">\r\n          <span class=\"history-name\" >Will Smith</span>\r\n          <span class=\"history-add\" >updated May 2,2020</span>\r\n        </div>\r\n        <div>\r\n          <span class=\"history-add\" >\r\n            25,Wanright,St Providence Road USA\r\n          </span>\r\n        </div>\r\n        <div>\r\n          <span class=\"assign\">\r\n           desgined assign to.....\r\n          </span>\r\n        </div>\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n</ion-content>";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/profile/profile-notification/profile-notification.component.html":
  /*!************************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/profile/profile-notification/profile-notification.component.html ***!
    \************************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppProfileProfileNotificationProfileNotificationComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-content style=\"--background: #e9f1ff;\">\r\n   <ion-grid style=\"text-align: center;\">\r\n       <ion-spinner name=\"dots\" *ngIf=\"!showLoader\"></ion-spinner>\r\n    <ion-row *ngIf=\"notification.length >0;else noNotification\">\r\n      <ion-col class=\"padding_adjust\">\r\n        <ion-item lines=\"none\" style=\"--background: #e9f1ff;\" *ngFor=\"let notifications of notification\">\r\n          <ion-img class=\"profile-icon\" src=\"/assets/images/icons8-checked.svg\"></ion-img>\r\n          <ion-label>\r\n            <h2 style=\"white-space: normal;font-size:14px !important\">{{notifications.message}}</h2>\r\n            <p>{{notifications.created_at | date:'dd/MM/yyyy'}}</p>\r\n          </ion-label>\r\n        </ion-item>\r\n      </ion-col>\r\n    </ion-row>\r\n        <ng-template #noNotification>\r\n          <ion-row>\r\n            <ion-col style=\"text-align: center;margin-top: 50%;\"> \r\n              No Notification Found\r\n            </ion-col>\r\n          </ion-row>\r\n        </ng-template>\r\n  </ion-grid>\r\n</ion-content>";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/profile/profile.page.html":
  /*!*********************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/profile/profile.page.html ***!
    \*********************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppProfileProfilePageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header class=\"ion-no-border\">\r\n    <ion-grid>\r\n        <ion-row>\r\n            <ion-col size=\"2\">\r\n                <!-- <ion-button  (click)=\"goBack()\" style=\"width: 55px !important; height:20px !important\"> -->\r\n                  <ion-button fill=\"clear\" (click)=\"goBack()\">\r\n                    <ion-img fill=\"clear\" src=\"assets/images/back.svg\" class=\"action-icon\"></ion-img>\r\n                  </ion-button>\r\n                <!-- </ion-button> -->\r\n            </ion-col>\r\n            <ion-col size=\"8\" ></ion-col>\r\n            <ion-col size=\"2\">\r\n                <ion-button fill=\"clear\" (click)=\"logout()\" [disabled]='enableDisable'>\r\n                    <ion-icon class=\"text-center\" class=\"_color\" name=\"log-out-outline\" style=\"font-size: 26px;width:48px;text-align: center;\"></ion-icon>\r\n                  </ion-button>\r\n                    <!-- <ion-icon class=\"action-button-color\" style=\"font-size: 26px;\"\r\n                              name=\"settings-outline\"></ion-icon> -->\r\n                <!-- </ion-button> -->\r\n            </ion-col>\r\n        </ion-row>\r\n    </ion-grid>\r\n</ion-header>\r\n<ion-content style=\"--background: #FEF8F8;\">\r\n\r\n    <ion-grid class=\"profile-background\">\r\n        <ion-row>\r\n            <ion-col size=\"12\">\r\n                <div style=\"text-align:center;\">\r\n                    <img src=\"assets/images/user_placeholder.jpg\" alt=\"User Image\" class=\"user-image\">\r\n                </div>\r\n            </ion-col>\r\n        </ion-row>\r\n        <ion-row>\r\n            <ion-col size=\"12\" class=\"ion-no-padding\">\r\n                <div style=\"text-align: center\">\r\n                    <span class=\"profile-name\">{{user.firstname}} {{user.lastname}}</span>\r\n                </div>\r\n            </ion-col>\r\n\r\n            <ion-col size=\"12\" class=\"ion-no-padding\">\r\n                <div style=\"text-align: center\">\r\n                    <span class=\"profile-email\">{{user.email}}</span>\r\n                </div>\r\n            </ion-col>\r\n            <ion-col size=\"12\" class=\"ion-no-padding\">\r\n                <div style=\"text-align: center\">\r\n                    <span class=\"profile-email\" *ngIf=\"user.role.name=='WattmonkAdmin' || user.role.name=='ContratorAdmin';else role\">{{\"Admin\"}}</span>\r\n                    <ng-template #role>\r\n                      <span class=\"profile-email\" *ngIf=\"user.role.name=='WattmonkAdmin' || user.role.name=='ContratorAdmin'\">{{user.role.name}}</span>\r\n                    </ng-template>\r\n                </div>\r\n            </ion-col>\r\n            <!-- <ion-col size=\"12\" class=\"ion-no-padding\">\r\n                <div style=\"text-align: center\">\r\n                    <span class=\"profile-amount\">Total points: {{user.amount}}</span>\r\n                </div>\r\n                <div style=\"text-align: center;color:#4272B9\" (click)=\"addPoints()\">Add points</div>\r\n            </ion-col> -->\r\n\r\n            <!-- <ion-col size=\"12\" class=\"ion-no-padding\">\r\n                <div style=\"text-align: center\">\r\n                    <span style=\"color: #BCBCBC;\">Male</span>\r\n                </div>\r\n            </ion-col> -->\r\n            <!-- <ion-col size=\"12\">\r\n                <div style=\"text-align: center\">\r\n                    <ion-badge class=\"badge-container\">\r\n                        <div class=\"dollar-badge\">\r\n                            <span style=\"color: grey;\">$50</span>\r\n                        </div>\r\n                    </ion-badge>\r\n                </div>\r\n            </ion-col> -->\r\n            <!-- <ion-col class=\"ion-align-items-center ion-text-center\">\r\n                <ion-button fill=\"clear\" class=\"action-button-color\" (click)=\"logout()\">Logout</ion-button>\r\n            </ion-col>\r\n            <ion-col class=\"ion-align-items-center ion-text-center\">\r\n                <ion-button fill=\"clear\" class=\"action-button-color\" (click)=\"syncSurvey()\">Sync Surveys</ion-button>\r\n            </ion-col> -->\r\n        </ion-row>\r\n        <!-- <ion-row> -->\r\n      \r\n        <!-- </ion-row> -->\r\n\r\n        <!-- <ion-row class=\"ion-justify-content-center\">\r\n          <ion-col size=\"6\">\r\n            <div style=\"text-align: center\">\r\n              <span>Notifications</span>\r\n            </div>\r\n\r\n          </ion-col>\r\n          <ion-col size=\"6\">\r\n            <div style=\"text-align: center\">\r\n              <span>History</span>\r\n            </div>\r\n\r\n          </ion-col>\r\n        </ion-row> -->\r\n    </ion-grid>\r\n    <ion-content style=\"--background: #FEF8F8;\">\r\n        <ion-tabs style=\"\r\n  position: inherit;\">\r\n            <ion-tab-bar slot=\"top\" class=\"ion-no-border\" class=\"profile-tab\">\r\n                <ion-tab-button tab=\"profile-notification\">\r\n                    <ion-label style=\"font-size: 16px;color:#4272B9\">Notifications</ion-label>\r\n                </ion-tab-button>\r\n                <!-- <ion-tab-button tab=\"history\">\r\n                    <ion-label style=\"font-size: 16px;\">History</ion-label>\r\n                </ion-tab-button> -->\r\n            </ion-tab-bar>\r\n        </ion-tabs>\r\n\r\n        <!-- <ion-content> -->\r\n            <!-- <ion-grid>\r\n              <ion-row class=\"ion-align-items-center\">\r\n                <ion-col size=\"3\">\r\n                  <ion-buttons>\r\n                    <ion-button>\r\n                      <ion-icon name=\"chevron-back-outline\"></ion-icon>\r\n                    </ion-button>\r\n                  </ion-buttons>\r\n                </ion-col>\r\n                <ion-col size=\"5\">\r\n                  <div style=\"text-align:center;\">\r\n                    <span>Jhon Doe</span>\r\n                  </div>\r\n                </ion-col>\r\n                <ion-col size=\"2\">\r\n                  <ion-buttons style=\"margin-left: 25px;\">\r\n                    <ion-button>\r\n                      <ion-icon name=\"settings-outline\"></ion-icon>\r\n                    </ion-button>\r\n                  </ion-buttons>\r\n                </ion-col>\r\n                <ion-col size=\"2\">\r\n                  <ion-buttons>\r\n                    <ion-button>\r\n                      <ion-icon name=\"trash-outline\"></ion-icon>\r\n                    </ion-button>\r\n                  </ion-buttons>\r\n                </ion-col>\r\n              </ion-row>\r\n\r\n              <ion-row class=\"ion-align-items-center\">\r\n                <ion-col>\r\n                  <div style=\"text-align: center;\">\r\n                    <span>nsrccs@gmail.com</span>\r\n                  </div>\r\n                </ion-col>\r\n              </ion-row>\r\n              <ion-row class=\"ion-align-items-center\" style=\"margin-top:-10px\">\r\n                <ion-col>\r\n                  <div style=\"text-align: center;\">\r\n                    <span>nsrccs@gmail.com</span>\r\n                  </div>\r\n                </ion-col>\r\n              </ion-row>\r\n\r\n            </ion-grid> -->\r\n        </ion-content>\r\n\r\n    <!-- </ion-content> -->\r\n\r\n</ion-content>\r\n";
    /***/
  },

  /***/
  "./src/app/profile/profile-history/profile-history.component.scss":
  /*!************************************************************************!*\
    !*** ./src/app/profile/profile-history/profile-history.component.scss ***!
    \************************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppProfileProfileHistoryProfileHistoryComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".profile-icon {\n  width: 50px;\n  height: 50px;\n  margin-right: 4px;\n}\n\n.history-name {\n  font-size: 16px;\n  color: #787574;\n}\n\n.history-add {\n  color: #CFCBCA;\n  font-size: 14px;\n}\n\n.assign {\n  font-size: 14px;\n  color: #878382;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcHJvZmlsZS9wcm9maWxlLWhpc3RvcnkvRjpcXG1vYmlsZWFwcC9zcmNcXGFwcFxccHJvZmlsZVxccHJvZmlsZS1oaXN0b3J5XFxwcm9maWxlLWhpc3RvcnkuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL3Byb2ZpbGUvcHJvZmlsZS1oaXN0b3J5L3Byb2ZpbGUtaGlzdG9yeS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQTtFQUNJLFdBQUE7RUFDQSxZQUFBO0VBQ0EsaUJBQUE7QUNBSjs7QURJRTtFQUNFLGVBQUE7RUFDQSxjQUFBO0FDREo7O0FESUU7RUFDRSxjQUFBO0VBQ0UsZUFBQTtBQ0ROOztBRElFO0VBQ0ksZUFBQTtFQUNBLGNBQUE7QUNETiIsImZpbGUiOiJzcmMvYXBwL3Byb2ZpbGUvcHJvZmlsZS1oaXN0b3J5L3Byb2ZpbGUtaGlzdG9yeS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4ucHJvZmlsZS1pY29ue1xyXG4gICAgd2lkdGg6IDUwcHg7XHJcbiAgICBoZWlnaHQ6IDUwcHg7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDRweDtcclxuICAgXHJcbiAgfVxyXG5cclxuICAuaGlzdG9yeS1uYW1le1xyXG4gICAgZm9udC1zaXplOiAxNnB4OyBcclxuICAgIGNvbG9yOiAjNzg3NTc0O1xyXG4gIH1cclxuXHJcbiAgLmhpc3RvcnktYWRke1xyXG4gICAgY29sb3I6ICNDRkNCQ0E7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICB9XHJcblxyXG4gIC5hc3NpZ257XHJcbiAgICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgICAgY29sb3I6ICM4NzgzODI7XHJcbiAgfSIsIi5wcm9maWxlLWljb24ge1xuICB3aWR0aDogNTBweDtcbiAgaGVpZ2h0OiA1MHB4O1xuICBtYXJnaW4tcmlnaHQ6IDRweDtcbn1cblxuLmhpc3RvcnktbmFtZSB7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgY29sb3I6ICM3ODc1NzQ7XG59XG5cbi5oaXN0b3J5LWFkZCB7XG4gIGNvbG9yOiAjQ0ZDQkNBO1xuICBmb250LXNpemU6IDE0cHg7XG59XG5cbi5hc3NpZ24ge1xuICBmb250LXNpemU6IDE0cHg7XG4gIGNvbG9yOiAjODc4MzgyO1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/profile/profile-history/profile-history.component.ts":
  /*!**********************************************************************!*\
    !*** ./src/app/profile/profile-history/profile-history.component.ts ***!
    \**********************************************************************/

  /*! exports provided: ProfileHistoryComponent */

  /***/
  function srcAppProfileProfileHistoryProfileHistoryComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ProfileHistoryComponent", function () {
      return ProfileHistoryComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");

    var ProfileHistoryComponent = /*#__PURE__*/function () {
      function ProfileHistoryComponent() {
        _classCallCheck(this, ProfileHistoryComponent);
      }

      _createClass(ProfileHistoryComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }]);

      return ProfileHistoryComponent;
    }();

    ProfileHistoryComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-profile-history',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./profile-history.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/profile/profile-history/profile-history.component.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./profile-history.component.scss */
      "./src/app/profile/profile-history/profile-history.component.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])], ProfileHistoryComponent);
    /***/
  },

  /***/
  "./src/app/profile/profile-notification/profile-notification.component.scss":
  /*!**********************************************************************************!*\
    !*** ./src/app/profile/profile-notification/profile-notification.component.scss ***!
    \**********************************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppProfileProfileNotificationProfileNotificationComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".profile-icon {\n  width: 50px;\n  height: 50px;\n  margin-right: 4px;\n}\n\n.padding_adjust {\n  padding-left: 0px !important;\n  padding-right: 0px !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcHJvZmlsZS9wcm9maWxlLW5vdGlmaWNhdGlvbi9GOlxcbW9iaWxlYXBwL3NyY1xcYXBwXFxwcm9maWxlXFxwcm9maWxlLW5vdGlmaWNhdGlvblxccHJvZmlsZS1ub3RpZmljYXRpb24uY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL3Byb2ZpbGUvcHJvZmlsZS1ub3RpZmljYXRpb24vcHJvZmlsZS1ub3RpZmljYXRpb24uY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0E7RUFDSSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0FDQUo7O0FESUU7RUFDRSw0QkFBQTtFQUNBLDZCQUFBO0FDREoiLCJmaWxlIjoic3JjL2FwcC9wcm9maWxlL3Byb2ZpbGUtbm90aWZpY2F0aW9uL3Byb2ZpbGUtbm90aWZpY2F0aW9uLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbi5wcm9maWxlLWljb257XHJcbiAgICB3aWR0aDogNTBweDtcclxuICAgIGhlaWdodDogNTBweDtcclxuICAgIG1hcmdpbi1yaWdodDogNHB4O1xyXG4gICBcclxuICB9XHJcblxyXG4gIC5wYWRkaW5nX2FkanVzdHtcclxuICAgIHBhZGRpbmctbGVmdDogMHB4ICFpbXBvcnRhbnQ7XHJcbiAgICBwYWRkaW5nLXJpZ2h0OiAwcHggIWltcG9ydGFudDs7XHJcbiAgfSIsIi5wcm9maWxlLWljb24ge1xuICB3aWR0aDogNTBweDtcbiAgaGVpZ2h0OiA1MHB4O1xuICBtYXJnaW4tcmlnaHQ6IDRweDtcbn1cblxuLnBhZGRpbmdfYWRqdXN0IHtcbiAgcGFkZGluZy1sZWZ0OiAwcHggIWltcG9ydGFudDtcbiAgcGFkZGluZy1yaWdodDogMHB4ICFpbXBvcnRhbnQ7XG59Il19 */";
    /***/
  },

  /***/
  "./src/app/profile/profile-notification/profile-notification.component.ts":
  /*!********************************************************************************!*\
    !*** ./src/app/profile/profile-notification/profile-notification.component.ts ***!
    \********************************************************************************/

  /*! exports provided: ProfileNotificationComponent */

  /***/
  function srcAppProfileProfileNotificationProfileNotificationComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ProfileNotificationComponent", function () {
      return ProfileNotificationComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var src_app_api_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! src/app/api.service */
    "./src/app/api.service.ts");
    /* harmony import */


    var src_app_utilities_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! src/app/utilities.service */
    "./src/app/utilities.service.ts");

    var ProfileNotificationComponent = /*#__PURE__*/function () {
      function ProfileNotificationComponent(apiservice, utilities) {
        _classCallCheck(this, ProfileNotificationComponent);

        this.apiservice = apiservice;
        this.utilities = utilities;
        this.notification = [];
        this.showLoader = false;
      }

      _createClass(ProfileNotificationComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.getNotification();
        }
      }, {
        key: "getNotification",
        value: function getNotification() {
          var _this = this;

          this.apiservice.profileNotification().subscribe(function (res) {
            _this.notification = res;
            _this.showLoader = true;
            console.log(_this.notification);
          });
        }
      }]);

      return ProfileNotificationComponent;
    }();

    ProfileNotificationComponent.ctorParameters = function () {
      return [{
        type: src_app_api_service__WEBPACK_IMPORTED_MODULE_2__["ApiService"]
      }, {
        type: src_app_utilities_service__WEBPACK_IMPORTED_MODULE_3__["UtilitiesService"]
      }];
    };

    ProfileNotificationComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-profile-notification',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./profile-notification.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/profile/profile-notification/profile-notification.component.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./profile-notification.component.scss */
      "./src/app/profile/profile-notification/profile-notification.component.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_api_service__WEBPACK_IMPORTED_MODULE_2__["ApiService"], src_app_utilities_service__WEBPACK_IMPORTED_MODULE_3__["UtilitiesService"]])], ProfileNotificationComponent);
    /***/
  },

  /***/
  "./src/app/profile/profile-routing.module.ts":
  /*!***************************************************!*\
    !*** ./src/app/profile/profile-routing.module.ts ***!
    \***************************************************/

  /*! exports provided: ProfilePageRoutingModule */

  /***/
  function srcAppProfileProfileRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ProfilePageRoutingModule", function () {
      return ProfilePageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _profile_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./profile.page */
    "./src/app/profile/profile.page.ts");
    /* harmony import */


    var _profile_notification_profile_notification_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ./profile-notification/profile-notification.component */
    "./src/app/profile/profile-notification/profile-notification.component.ts");
    /* harmony import */


    var _profile_history_profile_history_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./profile-history/profile-history.component */
    "./src/app/profile/profile-history/profile-history.component.ts");

    var routes = [{
      path: '',
      component: _profile_page__WEBPACK_IMPORTED_MODULE_3__["ProfilePage"],
      children: [{
        path: 'profile-notification',
        component: _profile_notification_profile_notification_component__WEBPACK_IMPORTED_MODULE_4__["ProfileNotificationComponent"]
      }, {
        path: 'history',
        component: _profile_history_profile_history_component__WEBPACK_IMPORTED_MODULE_5__["ProfileHistoryComponent"]
      }, {
        path: '',
        redirectTo: 'profile-notification',
        pathMatch: 'full'
      }]
    }];

    var ProfilePageRoutingModule = function ProfilePageRoutingModule() {
      _classCallCheck(this, ProfilePageRoutingModule);
    };

    ProfilePageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], ProfilePageRoutingModule);
    /***/
  },

  /***/
  "./src/app/profile/profile.module.ts":
  /*!*******************************************!*\
    !*** ./src/app/profile/profile.module.ts ***!
    \*******************************************/

  /*! exports provided: ProfilePageModule */

  /***/
  function srcAppProfileProfileModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ProfilePageModule", function () {
      return ProfilePageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _profile_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./profile-routing.module */
    "./src/app/profile/profile-routing.module.ts");
    /* harmony import */


    var _profile_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./profile.page */
    "./src/app/profile/profile.page.ts");
    /* harmony import */


    var _profile_notification_profile_notification_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ./profile-notification/profile-notification.component */
    "./src/app/profile/profile-notification/profile-notification.component.ts");
    /* harmony import */


    var _profile_history_profile_history_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! ./profile-history/profile-history.component */
    "./src/app/profile/profile-history/profile-history.component.ts");
    /* harmony import */


    var _paymentgateway_paymentgateway_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! ../paymentgateway/paymentgateway.module */
    "./src/app/paymentgateway/paymentgateway.module.ts");

    var ProfilePageModule = function ProfilePageModule() {
      _classCallCheck(this, ProfilePageModule);
    };

    ProfilePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      // entryComponents:[PaymentgatewayPage],
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _profile_routing_module__WEBPACK_IMPORTED_MODULE_5__["ProfilePageRoutingModule"], _paymentgateway_paymentgateway_module__WEBPACK_IMPORTED_MODULE_9__["PaymentgatewayPageModule"]],
      declarations: [_profile_page__WEBPACK_IMPORTED_MODULE_6__["ProfilePage"], _profile_notification_profile_notification_component__WEBPACK_IMPORTED_MODULE_7__["ProfileNotificationComponent"], _profile_history_profile_history_component__WEBPACK_IMPORTED_MODULE_8__["ProfileHistoryComponent"]]
    })], ProfilePageModule);
    /***/
  },

  /***/
  "./src/app/profile/profile.page.scss":
  /*!*******************************************!*\
    !*** ./src/app/profile/profile.page.scss ***!
    \*******************************************/

  /*! exports provided: default */

  /***/
  function srcAppProfileProfilePageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".profile-background {\n  width: 100%;\n  border-radius: 50% px;\n  background: white;\n}\n\n.user-image {\n  width: 120px;\n  height: 120px;\n  -o-object-fit: cover;\n     object-fit: cover;\n  border-radius: 50%;\n  border: 4px solid #4c8dff;\n}\n\n.profile-name {\n  color: #8B8B8B;\n  font-size: 20px;\n}\n\n.profile-amount {\n  color: #8B8B8B;\n  font-size: 20px;\n}\n\n.profile-email {\n  color: #7B7B7B;\n}\n\n.dollar-badge {\n  margin-top: 6px;\n  width: 60px;\n  height: 13px;\n}\n\n.profile-icon {\n  width: 50px;\n  height: 50px;\n  margin-right: 4px;\n}\n\n.badge-container {\n  background: #e9f1ff;\n  border-radius: 10px;\n}\n\n.profile-tab {\n  border-bottom-left-radius: 32px;\n  border-bottom-right-radius: 32px;\n}\n\nion-tab-bar {\n  --border: none;\n}\n\nion-tab-button {\n  font-size: 1em;\n  --color: #9E9E9E;\n  --color-selected: #3c78d8;\n}\n\n._color {\n  color: #6e6e6e;\n}\n\n.my-custom-modal-css .modal-wrapper {\n  height: 20%;\n  top: 80%;\n  position: absolute;\n  display: block;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcHJvZmlsZS9GOlxcbW9iaWxlYXBwL3NyY1xcYXBwXFxwcm9maWxlXFxwcm9maWxlLnBhZ2Uuc2NzcyIsInNyYy9hcHAvcHJvZmlsZS9wcm9maWxlLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFdBQUE7RUFDQSxxQkFBQTtFQUdBLGlCQUFBO0FDREY7O0FES0E7RUFDRSxZQUFBO0VBQ0EsYUFBQTtFQUNBLG9CQUFBO0tBQUEsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLHlCQUFBO0FDRkY7O0FETUE7RUFDRSxjQUFBO0VBQ0EsZUFBQTtBQ0hGOztBREtBO0VBQ0UsY0FBQTtFQUNBLGVBQUE7QUNGRjs7QURLQTtFQUNFLGNBQUE7QUNGRjs7QURLQTtFQUNFLGVBQUE7RUFDRSxXQUFBO0VBQ0EsWUFBQTtBQ0ZKOztBREtBO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxpQkFBQTtBQ0ZGOztBRE1BO0VBQ0UsbUJBQUE7RUFDQSxtQkFBQTtBQ0hGOztBRE1BO0VBQ0UsK0JBQUE7RUFDRSxnQ0FBQTtBQ0hKOztBRE9BO0VBQ0UsY0FBQTtBQ0pGOztBRE9BO0VBQ0UsY0FBQTtFQUNBLGdCQUFBO0VBQ0EseUJBQUE7QUNKRjs7QURhQTtFQUNFLGNBQUE7QUNWRjs7QURhQTtFQUNFLFdBQUE7RUFDQSxRQUFBO0VBQ0Esa0JBQUE7RUFDQSxjQUFBO0FDVkYiLCJmaWxlIjoic3JjL2FwcC9wcm9maWxlL3Byb2ZpbGUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnByb2ZpbGUtYmFja2dyb3VuZCB7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgYm9yZGVyLXJhZGl1czogNTAlcHg7XHJcbiAgLy8gYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogMzJweDtcclxuICAvLyBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogMzJweDtcclxuICBiYWNrZ3JvdW5kOiB3aGl0ZTtcclxuXHJcbn1cclxuXHJcbi51c2VyLWltYWdlIHtcclxuICB3aWR0aDogMTIwcHg7XHJcbiAgaGVpZ2h0OiAxMjBweDtcclxuICBvYmplY3QtZml0OiBjb3ZlcjtcclxuICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgYm9yZGVyOiA0cHggc29saWQgIzRjOGRmZjtcclxuXHJcbn1cclxuXHJcbi5wcm9maWxlLW5hbWV7XHJcbiAgY29sb3I6ICM4QjhCOEI7XHJcbiAgZm9udC1zaXplOiAyMHB4O1xyXG59XHJcbi5wcm9maWxlLWFtb3VudHtcclxuICBjb2xvcjogIzhCOEI4QjtcclxuICBmb250LXNpemU6IDIwcHg7XHJcbn1cclxuXHJcbi5wcm9maWxlLWVtYWlse1xyXG4gIGNvbG9yOiAjN0I3QjdCO1xyXG59XHJcblxyXG4uZG9sbGFyLWJhZGdle1xyXG4gIG1hcmdpbi10b3A6IDZweDtcclxuICAgIHdpZHRoOiA2MHB4O1xyXG4gICAgaGVpZ2h0OiAxM3B4O1xyXG59XHJcblxyXG4ucHJvZmlsZS1pY29ue1xyXG4gIHdpZHRoOiA1MHB4O1xyXG4gIGhlaWdodDogNTBweDtcclxuICBtYXJnaW4tcmlnaHQ6IDRweDtcclxuIFxyXG59XHJcblxyXG4uYmFkZ2UtY29udGFpbmVye1xyXG4gIGJhY2tncm91bmQ6ICNlOWYxZmY7XHJcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcclxufVxyXG5cclxuLnByb2ZpbGUtdGFie1xyXG4gIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDMycHg7XHJcbiAgICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogMzJweDtcclxufVxyXG5cclxuXHJcbmlvbi10YWItYmFyIHtcclxuICAtLWJvcmRlcjogbm9uZTtcclxufVxyXG5cclxuaW9uLXRhYi1idXR0b24ge1xyXG4gIGZvbnQtc2l6ZTogMWVtO1xyXG4gIC0tY29sb3I6ICM5RTlFOUU7XHJcbiAgLS1jb2xvci1zZWxlY3RlZDogIzNjNzhkODtcclxufVxyXG5cclxuLy8gaW9uLXRhYi1idXR0b25bYXJpYS1zZWxlY3RlZD10cnVlXSB7XHJcbi8vICAgYm9yZGVyLWJvdHRvbTogM3B4IHNvbGlkICMzYzc4ZDg7XHJcbi8vICAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogMnB4O1xyXG4vLyAgIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiAycHg7XHJcbi8vIH1cclxuXHJcbi5fY29sb3J7XHJcbiAgY29sb3I6ICM2ZTZlNmU7XHJcbn1cclxuXHJcbi5teS1jdXN0b20tbW9kYWwtY3NzIC5tb2RhbC13cmFwcGVyIHtcclxuICBoZWlnaHQ6IDIwJTtcclxuICB0b3A6IDgwJTtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7IFxyXG4gIGRpc3BsYXk6IGJsb2NrOyAgXHJcbn1cclxuXHJcblxyXG4iLCIucHJvZmlsZS1iYWNrZ3JvdW5kIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGJvcmRlci1yYWRpdXM6IDUwJSBweDtcbiAgYmFja2dyb3VuZDogd2hpdGU7XG59XG5cbi51c2VyLWltYWdlIHtcbiAgd2lkdGg6IDEyMHB4O1xuICBoZWlnaHQ6IDEyMHB4O1xuICBvYmplY3QtZml0OiBjb3ZlcjtcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xuICBib3JkZXI6IDRweCBzb2xpZCAjNGM4ZGZmO1xufVxuXG4ucHJvZmlsZS1uYW1lIHtcbiAgY29sb3I6ICM4QjhCOEI7XG4gIGZvbnQtc2l6ZTogMjBweDtcbn1cblxuLnByb2ZpbGUtYW1vdW50IHtcbiAgY29sb3I6ICM4QjhCOEI7XG4gIGZvbnQtc2l6ZTogMjBweDtcbn1cblxuLnByb2ZpbGUtZW1haWwge1xuICBjb2xvcjogIzdCN0I3Qjtcbn1cblxuLmRvbGxhci1iYWRnZSB7XG4gIG1hcmdpbi10b3A6IDZweDtcbiAgd2lkdGg6IDYwcHg7XG4gIGhlaWdodDogMTNweDtcbn1cblxuLnByb2ZpbGUtaWNvbiB7XG4gIHdpZHRoOiA1MHB4O1xuICBoZWlnaHQ6IDUwcHg7XG4gIG1hcmdpbi1yaWdodDogNHB4O1xufVxuXG4uYmFkZ2UtY29udGFpbmVyIHtcbiAgYmFja2dyb3VuZDogI2U5ZjFmZjtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbn1cblxuLnByb2ZpbGUtdGFiIHtcbiAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogMzJweDtcbiAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDMycHg7XG59XG5cbmlvbi10YWItYmFyIHtcbiAgLS1ib3JkZXI6IG5vbmU7XG59XG5cbmlvbi10YWItYnV0dG9uIHtcbiAgZm9udC1zaXplOiAxZW07XG4gIC0tY29sb3I6ICM5RTlFOUU7XG4gIC0tY29sb3Itc2VsZWN0ZWQ6ICMzYzc4ZDg7XG59XG5cbi5fY29sb3Ige1xuICBjb2xvcjogIzZlNmU2ZTtcbn1cblxuLm15LWN1c3RvbS1tb2RhbC1jc3MgLm1vZGFsLXdyYXBwZXIge1xuICBoZWlnaHQ6IDIwJTtcbiAgdG9wOiA4MCU7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgZGlzcGxheTogYmxvY2s7XG59Il19 */";
    /***/
  },

  /***/
  "./src/app/profile/profile.page.ts":
  /*!*****************************************!*\
    !*** ./src/app/profile/profile.page.ts ***!
    \*****************************************/

  /*! exports provided: ProfilePage */

  /***/
  function srcAppProfileProfilePageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ProfilePage", function () {
      return ProfilePage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _storage_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../storage.service */
    "./src/app/storage.service.ts");
    /* harmony import */


    var _api_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ../api.service */
    "./src/app/api.service.ts");
    /* harmony import */


    var _ionic_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic/storage */
    "./node_modules/@ionic/storage/fesm2015/ionic-storage.js");
    /* harmony import */


    var _model_constants__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ../model/constants */
    "./src/app/model/constants.ts");
    /* harmony import */


    var _utilities_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ../utilities.service */
    "./src/app/utilities.service.ts");

    var ProfilePage = /*#__PURE__*/function () {
      function ProfilePage(navController, apiService, storage, deviceStorage, utilities, toastController, modalController) {
        _classCallCheck(this, ProfilePage);

        this.navController = navController;
        this.apiService = apiService;
        this.storage = storage;
        this.deviceStorage = deviceStorage;
        this.utilities = utilities;
        this.toastController = toastController;
        this.modalController = modalController;
        this.imageUploadIndex = 1;
        this.totalImagesToUpload = 0;
        this.totalSurveys = 0;
        this.surveyIndex = 1;
        this.listOfSurveysToSave = [];
        this.enableDisable = false;
      }

      _createClass(ProfilePage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.enableDisable = false;
          this.user = this.storage.getUser();
          console.log(this.user);
        }
      }, {
        key: "goBack",
        value: function goBack() {
          this.navController.pop();
        }
      }, {
        key: "logout",
        value: function logout() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            var _this2 = this;

            var toast;
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    this.enableDisable = true;
                    _context.next = 3;
                    return this.toastController.create({
                      header: 'Please confirm',
                      message: 'Are you sure you want to logout?',
                      cssClass: 'my-custom-class',
                      buttons: [{
                        text: 'Yes',
                        handler: function handler() {
                          _this2.storage.logout();

                          _this2.deviceStorage.clear();

                          _this2.apiService.resetHeaders();

                          _this2.navController.navigateRoot('login');
                        }
                      }, {
                        text: 'No',
                        handler: function handler() {
                          _this2.enableDisable = false;
                        }
                      }]
                    });

                  case 3:
                    toast = _context.sent;
                    _context.next = 6;
                    return toast.present();

                  case 6:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "syncSurvey",
        value: function syncSurvey() {
          var _this3 = this;

          this.listOfSurveysToSave = [];
          this.deviceStorage.keys().then(function (listOfKeys) {
            listOfKeys.forEach(function (item) {
              _this3.deviceStorage.get(item).then(function (data) {
                if (data.saved) {
                  _this3.listOfSurveysToSave.push(data);
                }
              });
            });
          });
          this.utilities.showLoading('Uploading Images').then(function () {
            _this3.totalSurveys = _this3.listOfSurveysToSave.length;

            _this3.uploadAllSurveys();
          });
        }
      }, {
        key: "uploadAllSurveys",
        value: function uploadAllSurveys() {
          var _this4 = this;

          if (this.listOfSurveysToSave.length !== 0) {
            this.uploadAllImagesOfSurvey(this.listOfSurveysToSave[0]);
          } else {
            this.utilities.hideLoading().then(function () {
              _this4.utilities.showSuccessModal('Survey images have been uploaded').then(function (modal) {
                modal.present();
              });
            });
          }
        }
      }, {
        key: "uploadAllImagesOfSurvey",
        value: function uploadAllImagesOfSurvey(surveyData) {
          var mapOfImages = [];
          surveyData.surveyMenu.forEach(function (mainMenu) {
            if (mainMenu.imageModel !== null && mainMenu.imageModel !== undefined) {
              mainMenu.imageModel.forEach(function (imageModel) {
                if (imageModel.image !== '') {
                  var _image = new _model_constants__WEBPACK_IMPORTED_MODULE_6__["ImageUploadModel"]();

                  _image.key = imageModel.imageUploadTag;
                  _image.imageData = imageModel.image;
                  _image.imagename = imageModel.imageName;
                  mapOfImages.push(_image);
                }
              });
            }

            if (mainMenu.subMenu !== null && mainMenu.subMenu !== undefined) {
              mainMenu.subMenu.forEach(function (submenu) {
                submenu.images.forEach(function (imageModel) {
                  if (imageModel.image !== '') {
                    var _image2 = new _model_constants__WEBPACK_IMPORTED_MODULE_6__["ImageUploadModel"]();

                    _image2.key = imageModel.imageUploadTag;
                    _image2.imageData = imageModel.image;
                    _image2.imagename = imageModel.imageName;
                    mapOfImages.push(_image2);
                  }
                });
              });
            }
          });
          var image = new _model_constants__WEBPACK_IMPORTED_MODULE_6__["ImageUploadModel"]();
          image.key = 'electricalslocation';
          image.imageData = surveyData.canvasImage;
          image.imagename = 'electricalslocation';
          mapOfImages.push(image);
          this.imageUploadIndex = 1;
          this.totalImagesToUpload = mapOfImages.length;
          this.uploadImageByIndex(mapOfImages, surveyData.surveyid);
        }
      }, {
        key: "uploadImageByIndex",
        value: function uploadImageByIndex(mapOfImages, surveyId) {
          var _this5 = this;

          if (mapOfImages.length !== 0) {
            var imageToUpload = mapOfImages[0];
            var blob = this.utilities.getBlobFromImageData(imageToUpload.imageData);
            var filename = '';

            if (imageToUpload.imagename === '') {
              filename = Date.now().toString() + '.png';
            } else {
              filename = imageToUpload.imagename + '.png';
            }

            this.utilities.setLoadingMessage('Uploading Image ' + this.imageUploadIndex + '/' + this.totalImagesToUpload + ' of survey ' + this.surveyIndex + '/' + this.totalSurveys);
            this.apiService.uploadImage(surveyId, imageToUpload.key, blob, filename).subscribe(function (data) {
              _this5.imageUploadIndex++;
              mapOfImages.splice(0, 1);

              _this5.uploadImageByIndex(mapOfImages, surveyId);
            }, function (error) {
              _this5.imageUploadIndex++;
              mapOfImages.splice(0, 1);

              _this5.uploadImageByIndex(mapOfImages, surveyId);
            });
          } else {
            this.deviceStorage.remove(surveyId + '');
            this.surveyIndex++;
            this.listOfSurveysToSave.splice(0, 1);
            this.uploadAllSurveys();
          }
        }
      }, {
        key: "addPoints",
        value: function addPoints() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    this.navController.navigateForward('/paymentgateway');

                  case 1:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2, this);
          }));
        }
      }]);

      return ProfilePage;
    }();

    ProfilePage.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"]
      }, {
        type: _api_service__WEBPACK_IMPORTED_MODULE_4__["ApiService"]
      }, {
        type: _storage_service__WEBPACK_IMPORTED_MODULE_3__["StorageService"]
      }, {
        type: _ionic_storage__WEBPACK_IMPORTED_MODULE_5__["Storage"]
      }, {
        type: _utilities_service__WEBPACK_IMPORTED_MODULE_7__["UtilitiesService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]
      }];
    };

    ProfilePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-profile',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./profile.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/profile/profile.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./profile.page.scss */
      "./src/app/profile/profile.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"], _api_service__WEBPACK_IMPORTED_MODULE_4__["ApiService"], _storage_service__WEBPACK_IMPORTED_MODULE_3__["StorageService"], _ionic_storage__WEBPACK_IMPORTED_MODULE_5__["Storage"], _utilities_service__WEBPACK_IMPORTED_MODULE_7__["UtilitiesService"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]])], ProfilePage);
    /***/
  }
}]);
//# sourceMappingURL=profile-profile-module-es5.js.map