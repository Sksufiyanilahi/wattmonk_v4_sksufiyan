function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["searchbar-searchbar-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/searchbar/design/design.component.html":
  /*!**********************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/searchbar/design/design.component.html ***!
    \**********************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppSearchbarDesignDesignComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-content (click)=\"close()\" style=\"padding-bottom: 250px;\">\r\n  <ion-refresher slot=\"fixed\" (ionRefresh)=\"refreshDesigns($event)\">\r\n      <ion-refresher-content></ion-refresher-content>\r\n  </ion-refresher>\r\n  <ion-grid *ngIf=\"listOfDesignDataHelper.length !== 0\">\r\n      <ion-row *ngFor=\"let item of listOfDesignDataHelper;let i = index\" class=\"ion-margin-top\">\r\n          <ion-col size=\"12\">\r\n              <span class=\"ion-padding\" *ngIf=\"today === item.date\">\r\n                  Today\r\n                </span>\r\n              <span class=\"ion-padding\" *ngIf=\"today !== item.date\">\r\n                  {{item.date | date: 'dd MMM yyyy'}}\r\n              </span>\r\n          </ion-col>\r\n          <ion-col *ngFor=\"let designData of item.listOfDesigns;let i = index\" size=\"6\">\r\n            <div class=\"ion-padding custom-card\" style=\"height: 100%;\">\r\n                <span class=\"customer-name\" [routerLink]=\"['/design-details/',designData.id]\"\r\n                        routerDirection=\"forward\">{{designData.name}} </span>\r\n                        <span class=\"ion-text-end timestamp\" [routerLink]=\"['/design-details/',designData.id]\">\r\n                            {{designData.created_at | date: 'hh:mm a'}}\r\n                        </span>\r\n                <span class=\"customer-email\" [routerLink]=\"['/design-details/',designData.id]\"\r\n                        routerDirection=\"forward\">{{designData.email}}</span>\r\n                <a href=\"tel:{{designData.phonenumber}}\" style=\"text-decoration: none;\" class=\"z-100\">\r\n                    <span class=\"customer-phone\">{{designData.phonenumber}}</span></a>\r\n                <span class=\"customer-address z-100\"\r\n                        (click)=\"openAddressOnMap(designData.address)\">{{(designData.address | slice:0:60) + (designData.address.length > 60 ? '...' : '')}}</span>\r\n\r\n                <ion-row style=\"margin-bottom: 8px;\">\r\n                    <!-- <span class=\"chipdetail\" style=\"background-color: #95afc0;\" >Wattmonk</span> -->\r\n                    <!-- <span class=\"chipdetail\" style=\"background-color: #95afc0;\" >{{designData.formattedjobtype}}</span> -->\r\n                    <ion-col>    \r\n                        <span class=\"chipdetail\" style=\"background-color: rgb(246, 77, 10);\" *ngIf=\"designData.status == 'reviewfailed'\">Failed</span>\r\n                        <span class=\"chipdetail\" style=\"background-color: rgb(109, 187, 26);\" *ngIf=\"designData.status == 'reviewpassed'\">Passed</span>\r\n                    </ion-col>\r\n                </ion-row>\r\n                <ion-row class=\"ion-no-margin ion-no-margin\">\r\n                    <ion-col>\r\n                        <span *ngIf=\"designData.status == 'created' || designData.status == 'requestaccepted'\" style=\"float:right !important;\" class=\"ion-text-end action-button-color\" (click)=\"openDesigners(designData.id)\"\r\n                        >Assign</span>\r\n                        <span *ngIf=\"designData.status == 'outsourced'\" style=\"float:right !important;\" class=\"ion-text-end action-button-color\" (click)=\"openDesigners(designData.id)\"\r\n                        >Decline</span>\r\n                        <span *ngIf=\"designData.status == 'outsourced'\" style=\"float:right !important;\" class=\"ion-text-end action-button-color\" (click)=\"openDesigners(designData.id)\"\r\n                        >Accept</span>\r\n                        <span *ngIf=\"designData.status == 'requestdeclined'\"style=\"float:right !important;\" class=\"ion-text-end action-button-color\" (click)=\"openDesigners(designData.id)\"\r\n                        >Reassign</span>\r\n                        <span *ngIf=\"designData.status == 'reviewpassed'\" style=\"float:right !important;\" class=\"ion-text-end action-button-color\" (click)=\"openDesigners(designData.id)\"\r\n                        >Deliver</span>\r\n\r\n                    </ion-col>\r\n                    <!-- <ion-col class=\"ion-no-margin ion-no-padding\">\r\n                        <ion-button class=\"ion-no-margin ion-no-padding\" fill=\"clear\" [routerLink]=\"['/surveyprocess/' + designData.id + '/' + designData.jobtype + '/' + designData.latitude + '/' + designData.longitude]\"\r\n                        routerDirection=\"forward\">\r\n                            Restart Survey\r\n                        </ion-button>\r\n                    </ion-col> -->\r\n                </ion-row>\r\n                <!-- <ion-progress-bar [value]=\"1\" mode=\"ios\" color=\"success\" class=\"progress-bar-height\"></ion-progress-bar> -->\r\n                  <!-- <span class=\"ion-text-end timestamp\" [routerLink]=\"['/design-details/',designData.id]\" routerDirection=\"forward\">\r\n                        {{designData.deliverydate | date: 'hh:mm a'}}\r\n                   \r\n            </span> -->\r\n            </div>\r\n        </ion-col>\r\n      </ion-row>\r\n      <ion-row>\r\n          <ion-col size=\"12\" style=\"height: 100px;\">\r\n          </ion-col>\r\n      </ion-row>\r\n  </ion-grid>\r\n\r\n  <div *ngIf=\"listOfDesignDataHelper.length === 0\" class=\"h-100 d-flex flex-column align-center justify-center\">\r\n      <ion-img src=\"/assets/images/blank.png\" class=\"placeholder\"></ion-img>\r\n  </div>\r\n\r\n</ion-content>\r\n\r\n<ion-bottom-drawer [(state)]=\"drawerState\" minimumHeight=\"0\" dockedHeight=\"400\" draggable=\"false\" disableDrag=\"true\"\r\n                 shouldBounce=\"true\" distanceTop=\"0\" class=\"drawer\" style=\"z-index: 9999 !important;\">\r\n  <form [formGroup]=\"assignForm\">\r\n      <ion-grid class=\"drawer\">\r\n          <ion-row>\r\n              <ion-col size=\"12\">\r\n                  <app-user-selector placeholder=\"assign\" [assignees]=\"listOfAssignees\"\r\n                                     formControlName=\"assignedto\"></app-user-selector>\r\n              </ion-col>\r\n          </ion-row>\r\n          <ion-row style=\"margin-left: 8px;\">\r\n              <ion-col size=\"12\">\r\n                  <span class=\"input-placeholder\">comments</span>\r\n              </ion-col>\r\n              <ion-col size=\"12\" style=\"padding-top: 0px;\">\r\n                  <ion-textarea style=\"max-width: 98%;\" class=\"ion-no-margin ion-no-padding comment_box\" rows=\"3\"\r\n                                formControlName=\"comment\"></ion-textarea>\r\n              </ion-col>\r\n          </ion-row>\r\n          <ion-row style=\"justify-content: flex-end;\">\r\n              <ion-col size=\"auto\" style=\"padding-top: 0px; margin-right: 6px;\">\r\n                  <ion-button class=\"buttom-drawer-button\" (click)=\"assignToDesigner()\">\r\n                      Confirm\r\n                  </ion-button>\r\n              </ion-col>\r\n          </ion-row>\r\n      </ion-grid>\r\n  </form>\r\n\r\n</ion-bottom-drawer>";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/searchbar/searchbar.page.html":
  /*!*************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/searchbar/searchbar.page.html ***!
    \*************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppSearchbarSearchbarPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-content style=\"position: relative;\">\r\n  <!-- <ion-header class=\"ion-no-border white-bg\" style=\"position: relative;\">\r\n      <ion-toolbar> -->\r\n  <ion-grid>\r\n      <ion-row class=\"ion-align-items-center\">\r\n          <ion-col *ngIf=\"showHome === true\">\r\n              <h1 class=\"ion-no-padding ion-no-margin home\">Search</h1>\r\n          </ion-col>\r\n          <ion-col *ngIf=\"showSearchBar === true\">\r\n              <ion-searchbar debounce=\"0\" placeholder=\"search\" (ionClear)=\"showHom()\" [(ngModel)]=\"searchbarElement\"\r\n                             (ionChange)=\"searchDesginAndSurvey($event)\" class=\"custom\"></ion-searchbar>\r\n          </ion-col>\r\n          <ion-col size=\"auto\" *ngIf=\"showHome === true\">\r\n              <div class=\"notification-padding\" (click)=\"onClick()\">\r\n                  <ion-img src=\"/assets/images/icons8-search.svg\" class=\"notification-icon\"></ion-img>\r\n              </div>\r\n          </ion-col>\r\n          <!-- <ion-col size=\"auto\" style=\"position: relative;\">\r\n              <div class=\"notification-padding\" [routerLink]=\"['/profile']\" routerDirection=\"forward\">\r\n                  <ion-img src=\"/assets/images/notification.svg\" class=\"notification-icon\"></ion-img>\r\n                \r\n              </div>\r\n          </ion-col> -->\r\n      </ion-row>\r\n  </ion-grid>\r\n  <!-- </ion-toolbar> -->\r\n  <!-- </ion-header> -->\r\n  <ion-tabs style=\"margin-top: 52px;\">\r\n      <ion-tab-bar slot=\"top\" class=\"ion-no-border\">\r\n          <ion-tab-button tab=\"design\" *ngIf=\"isUserDesigner\">\r\n              <ion-label>Designs</ion-label>\r\n          </ion-tab-button>\r\n          <ion-tab-button tab=\"survey\" *ngIf=\"isUserSurveyor\">\r\n              <ion-label>Surveys</ion-label>\r\n          </ion-tab-button>\r\n      </ion-tab-bar>\r\n  </ion-tabs>\r\n  <ion-grid style=\"position: absolute;\">\r\n      <div class=\"searchbar_div\">\r\n          <ion-grid *ngIf=\"searchDesginItem && searchDesginItem.length !== 0\">\r\n              <ion-row *ngFor=\"let searchitem of searchDesginItem;\" (click)=\"getdesigndata(searchitem)\">\r\n                  <ion-col size=\"2\">\r\n                      <ion-img class=\"profile-icon\" src=\"/assets/images/icons8-checked.svg\"></ion-img>\r\n                  </ion-col>\r\n                  <ion-col size=\"10\" style=\"margin-top: 6px;\">\r\n                      <div style=\"display: flex; justify-content: space-between;\">\r\n                          <span class=\"history-name\">{{searchitem.name}}</span>\r\n                          <span class=\"history-add\">{{searchitem.created_at | date:'dd/MM/yyyy'}}</span>\r\n                      </div>\r\n                      <div>\r\n                            <span class=\"history-add\">\r\n                              {{searchitem.address}}\r\n                            </span>\r\n                      </div>\r\n                      <!-- <div>\r\n                            <span class=\"assign\">\r\n                             desgined assign to.....\r\n                            </span>\r\n                      </div> -->\r\n                  </ion-col>\r\n              </ion-row>\r\n          </ion-grid>\r\n          <ion-grid *ngIf=\"(searchSurveyItem && searchSurveyItem.length !== 0)\">\r\n              <ion-row *ngFor=\"let searchitem of searchSurveyItem\" (click)=\"getdesigndata(searchitem)\">\r\n                  <ion-col size=\"2\">\r\n                      <ion-img class=\"profile-icon\" src=\"/assets/images/icons8-checked.svg\"></ion-img>\r\n                  </ion-col>\r\n                  <ion-col size=\"10\" style=\"margin-top: 6px;\">\r\n                      <div style=\"display: flex; justify-content: space-between;\">\r\n                          <span class=\"history-name\">{{searchitem.name}}</span>\r\n                          <span class=\"history-add\">{{searchitem.created_at | date:'dd/MM/yyyy'}}</span>\r\n                      </div>\r\n                      <div>\r\n                            <span class=\"history-add\">\r\n                              {{searchitem.address}}\r\n                            </span>\r\n                      </div>\r\n                      <!-- <div>\r\n                            <span class=\"assign\">\r\n                             desgined assign to.....\r\n                            </span>\r\n                      </div> -->\r\n                  </ion-col>\r\n              </ion-row>\r\n          </ion-grid>\r\n      </div>\r\n      <div class=\"searchbar_div nodata_div\">\r\n          <ng-template #noDesignandSurvey>\r\n              <ion-grid\r\n                      *ngIf=\"searchbarElement !== '' && (searchSurveyItem && searchSurveyItem.length === 0) && (searchDesginItem && searchDesginItem.length === 0)\">\r\n                  <div class=\"h-100 d-flex flex-column align-center justify-center\">\r\n                      <span>No desgin or survey found</span>\r\n                  </div>\r\n              </ion-grid>\r\n          </ng-template>\r\n      </div>\r\n  </ion-grid>\r\n\r\n</ion-content>\r\n\r\n\r\n\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/searchbar/survey/survey.component.html":
  /*!**********************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/searchbar/survey/survey.component.html ***!
    \**********************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppSearchbarSurveySurveyComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-content>\r\n  <ion-refresher slot=\"fixed\" (ionRefresh)=\"getSurveys($event)\">\r\n      <ion-refresher-content></ion-refresher-content>\r\n  </ion-refresher>\r\n  <ion-grid *ngIf=\"listOfSurveyDataHelper.length !== 0\">\r\n      <ion-row *ngFor=\"let item of listOfSurveyDataHelper;let i = index\">\r\n          <ion-col size=\"12\" class=\"ion-margin-top\">\r\n                  <span class=\"ion-padding\" *ngIf=\"today === item.date\">\r\n                      Today\r\n                    </span>\r\n              <span class=\"ion-padding\" *ngIf=\"today !== item.date\">\r\n                        {{item.date | date: 'dd MMM yyyy'}}\r\n                  </span>\r\n          </ion-col>\r\n          <ion-col *ngFor=\"let surveyData of item.listOfSurveys;let i = index \" size=\"6\">\r\n              <div class=\"ion-padding custom-card\" style=\"height: 100%;\">\r\n                  <span class=\"customer-name\" [routerLink]=\"['/survey-detail/',surveyData.id]\"\r\n                        routerDirection=\"forward\">{{surveyData.name}}</span>\r\n                        <span style=\"float: right;\" class=\"ion-text-end timestamp\" [routerLink]=\"['/survey-detail/',surveyData.id]\" routerDirection=\"forward\">\r\n                            {{surveyData.datetime | date: 'hh:mm a'}}\r\n                        </span>\r\n                  <span class=\"customer-email\" [routerLink]=\"['/survey-detail/',surveyData.id]\"\r\n                        routerDirection=\"forward\">{{surveyData.email}}</span>\r\n                  <a href=\"tel:{{surveyData.phonenumber}}\" style=\"text-decoration: none;\" class=\"z-100\">\r\n                      <span class=\"customer-phone\">{{surveyData?.phonenumber}}</span></a>\r\n                  <span class=\"customer-address z-100\"\r\n                        (click)=\"openAddressOnMap(surveyData.address)\">{{(surveyData.address | slice:0:60) + (surveyData.address?.length > 60 ? '...' : '')}}</span>\r\n                  <ion-row class=\"ion-no-margin ion-no-margin\">\r\n                      <ion-col size=\"auto\" class=\"ion-no-margin ion-no-padding\"\r\n                               *ngIf=\"surveyData.status !== 'surveycompleted'\"\r\n                               [routerLink]=\"['/surveyprocess/' + surveyData.id + '/' + surveyData.jobtype + '/' + surveyData.latitude + '/' + surveyData.longitude]\"\r\n                               routerDirection=\"forward\">\r\n                          <span class=\"ion-text-end action-button-color\">Start Survey</span>\r\n                      </ion-col>\r\n                      <ion-col></ion-col>\r\n                      <ion-col size=\"auto\" class=\"ion-no-margin ion-no-padding\"\r\n                               *ngIf=\"surveyData.assignedto === null || surveyData.assignedto === undefined\">\r\n                               <span *ngIf=\"surveyData.status == 'created' || surveyData.status == 'requestaccepted'\" style=\"float:right !important;\" class=\"ion-text-end action-button-color\" (click)=\"openSurveyors(surveyData.id)\"\r\n                               >Assign</span>\r\n                               <span *ngIf=\"surveyData.status == 'outsourced'\" style=\"float:right !important;\" class=\"ion-text-end action-button-color\" (click)=\"openSurveyors(surveyData.id)\"\r\n                               >Decline</span>\r\n                               <span *ngIf=\"surveyData.status == 'outsourced'\" style=\"float:right !important;\" class=\"ion-text-end action-button-color\" (click)=\"openSurveyors(surveyData.id)\"\r\n                               >Accept</span>\r\n                               <span *ngIf=\"surveyData.status == 'requestdeclined'\"style=\"float:right !important;\" class=\"ion-text-end action-button-color\" (click)=\"openSurveyors(surveyData.id)\"\r\n                               >Reassign</span>\r\n                               <span *ngIf=\"surveyData.status == 'reviewpassed'\" style=\"float:right !important;\" class=\"ion-text-end action-button-color\" (click)=\"openSurveyors(surveyData.id)\"\r\n                               >Deliver</span>\r\n                      </ion-col>\r\n                  </ion-row>\r\n                  <!-- <span class=\"ion-text-end timestamp\" [routerLink]=\"['/survey-detail/',surveyData.id]\" routerDirection=\"forward\">\r\n                      {{surveyData.datetime | date: 'hh:mm a'}}\r\n                  </span> -->\r\n\r\n              </div>\r\n\r\n          </ion-col>\r\n      </ion-row>\r\n      <ion-row>\r\n          <ion-col size=\"12\" style=\"height: 100px;\">\r\n          </ion-col>\r\n      </ion-row>\r\n  </ion-grid>\r\n\r\n  <div *ngIf=\"listOfSurveyDataHelper.length === 0\" class=\"h-100 d-flex flex-column align-center justify-center\">\r\n      <ion-img src=\"/assets/images/blank.png\" class=\"placeholder\"></ion-img>\r\n  </div>\r\n\r\n</ion-content>\r\n\r\n<ion-bottom-drawer [(state)]=\"drawerState\" minimumHeight=\"0\" dockedHeight=\"300\" draggable=\"false\" disableDrag=\"true\"\r\n                 shouldBounce=\"false\" distanceTop=\"0\" class=\"drawer\" style=\"z-index: 9999 !important;\">\r\n  <form [formGroup]=\"assignForm\">\r\n      <ion-grid class=\"drawer\">\r\n          <ion-row>\r\n              <ion-col size=\"12\">\r\n                  <app-user-selector placeholder=\"assign\" [assignees]=\"listOfAssignees\"\r\n                                     formControlName=\"assignedto\"></app-user-selector>\r\n              </ion-col>\r\n          </ion-row>\r\n          <ion-row>\r\n              <ion-col size=\"auto\">\r\n                  <ion-button class=\"buttom-drawer-button\" (click)=\"assignToSurveyor()\">\r\n                      Confirm\r\n                  </ion-button>\r\n              </ion-col>\r\n              <ion-col size=\"auto\">\r\n                  <ion-button class=\"buttom-drawer-button-cancel\" fill=\"clear\" (click)=\"dismissBottomSheet()\">\r\n                      Cancel\r\n                  </ion-button>\r\n              </ion-col>\r\n          </ion-row>\r\n      </ion-grid>\r\n  </form>\r\n\r\n</ion-bottom-drawer>";
    /***/
  },

  /***/
  "./src/app/searchbar/design/design.component.scss":
  /*!********************************************************!*\
    !*** ./src/app/searchbar/design/design.component.scss ***!
    \********************************************************/

  /*! exports provided: default */

  /***/
  function srcAppSearchbarDesignDesignComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".custom-card {\n  display: flex;\n  flex-direction: column;\n  background: white;\n  border-radius: 12px;\n  box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.3);\n  height: 100%;\n}\n\n.customer-name {\n  font-size: 1em;\n  color: #434343;\n  font-weight: bold;\n}\n\n.customer-email {\n  font-size: 0.8em;\n  color: #B4B4B4;\n}\n\n.customer-phone {\n  font-size: 0.8em;\n  color: #4272B9;\n}\n\n.customer-address {\n  margin-top: 16px;\n  margin-bottom: 16px;\n  font-size: 0.8em;\n  color: #4272B9;\n}\n\nion-bottom-drawer {\n  --padding: 0 !important;\n  padding: 0 !important;\n  --background: #F3F3F3 !important;\n  background: #F3F3F3 !important;\n}\n\nion-bottom-drawer ion-content {\n  --background: #F3F3F3 !important;\n}\n\n.timestamp {\n  font-size: 0.7em;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2VhcmNoYmFyL2Rlc2lnbi9GOlxcbW9iaWxlYXBwL3NyY1xcYXBwXFxzZWFyY2hiYXJcXGRlc2lnblxcZGVzaWduLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9zZWFyY2hiYXIvZGVzaWduL2Rlc2lnbi5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGFBQUE7RUFDQSxzQkFBQTtFQUNBLGlCQUFBO0VBQ0EsbUJBQUE7RUFDQSwwQ0FBQTtFQUNBLFlBQUE7QUNDSjs7QURFRTtFQUNFLGNBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7QUNDSjs7QURFRTtFQUNFLGdCQUFBO0VBQ0EsY0FBQTtBQ0NKOztBREVFO0VBQ0UsZ0JBQUE7RUFDQSxjQUFBO0FDQ0o7O0FERUU7RUFDRSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0FDQ0o7O0FEZUU7RUFFRSx1QkFBQTtFQUNBLHFCQUFBO0VBRUEsZ0NBQUE7RUFDQSw4QkFBQTtBQ2RKOztBRGdCSTtFQUNFLGdDQUFBO0FDZE47O0FEa0JFO0VBQ0UsZ0JBQUE7QUNmSiIsImZpbGUiOiJzcmMvYXBwL3NlYXJjaGJhci9kZXNpZ24vZGVzaWduLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmN1c3RvbS1jYXJkIHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gICAgYmFja2dyb3VuZDogd2hpdGU7XHJcbiAgICBib3JkZXItcmFkaXVzOiAxMnB4O1xyXG4gICAgYm94LXNoYWRvdzogMCAxcHggMnB4IDAgcmdiYSgwLCAwLCAwLCAwLjMpO1xyXG4gICAgaGVpZ2h0OiAxMDAlO1xyXG4gIH1cclxuICBcclxuICAuY3VzdG9tZXItbmFtZSB7XHJcbiAgICBmb250LXNpemU6IDFlbTtcclxuICAgIGNvbG9yOiAjNDM0MzQzO1xyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgfVxyXG4gIFxyXG4gIC5jdXN0b21lci1lbWFpbCB7XHJcbiAgICBmb250LXNpemU6IDAuOGVtO1xyXG4gICAgY29sb3I6ICNCNEI0QjQ7XHJcbiAgfVxyXG4gIFxyXG4gIC5jdXN0b21lci1waG9uZSB7XHJcbiAgICBmb250LXNpemU6IDAuOGVtO1xyXG4gICAgY29sb3I6ICM0MjcyQjk7XHJcbiAgfVxyXG4gIFxyXG4gIC5jdXN0b21lci1hZGRyZXNzIHtcclxuICAgIG1hcmdpbi10b3A6IDE2cHg7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAxNnB4O1xyXG4gICAgZm9udC1zaXplOiAwLjhlbTtcclxuICAgIGNvbG9yOiAjNDI3MkI5O1xyXG4gIH1cclxuICBcclxuICAucGxhY2Vob2xkZXIge1xyXG4gICAgLy8gd2lkdGg6IDUwdncgIWltcG9ydGFudDtcclxuICB9XHJcbiAgXHJcbiAgLy8uZHJhd2VyIHtcclxuICAvLyAgYmFja2dyb3VuZDogI0YzRjNGMztcclxuICAvLyAgLS1iYWNrZ3JvdW5kOiAjRjNGM0YzO1xyXG4gIC8vfVxyXG4gIC8vXHJcbiAgLy8uaW9uLWJvdHRvbS1kcmF3ZXItc2Nyb2xsYWJsZS1jb250ZW50IHtcclxuICAvLyAgYmFja2dyb3VuZDogI0YzRjNGMyAhaW1wb3J0YW50O1xyXG4gIC8vfVxyXG4gIFxyXG4gIGlvbi1ib3R0b20tZHJhd2VyIHtcclxuICBcclxuICAgIC0tcGFkZGluZzogMCAhaW1wb3J0YW50O1xyXG4gICAgcGFkZGluZzogMCAhaW1wb3J0YW50O1xyXG4gIFxyXG4gICAgLS1iYWNrZ3JvdW5kOiAjRjNGM0YzICFpbXBvcnRhbnQ7XHJcbiAgICBiYWNrZ3JvdW5kOiAjRjNGM0YzICFpbXBvcnRhbnQ7XHJcbiAgXHJcbiAgICBpb24tY29udGVudCB7XHJcbiAgICAgIC0tYmFja2dyb3VuZDogI0YzRjNGMyAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gIH1cclxuICBcclxuICAudGltZXN0YW1wIHtcclxuICAgIGZvbnQtc2l6ZTogMC43ZW07XHJcbiAgfSIsIi5jdXN0b20tY2FyZCB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gIGJhY2tncm91bmQ6IHdoaXRlO1xuICBib3JkZXItcmFkaXVzOiAxMnB4O1xuICBib3gtc2hhZG93OiAwIDFweCAycHggMCByZ2JhKDAsIDAsIDAsIDAuMyk7XG4gIGhlaWdodDogMTAwJTtcbn1cblxuLmN1c3RvbWVyLW5hbWUge1xuICBmb250LXNpemU6IDFlbTtcbiAgY29sb3I6ICM0MzQzNDM7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xufVxuXG4uY3VzdG9tZXItZW1haWwge1xuICBmb250LXNpemU6IDAuOGVtO1xuICBjb2xvcjogI0I0QjRCNDtcbn1cblxuLmN1c3RvbWVyLXBob25lIHtcbiAgZm9udC1zaXplOiAwLjhlbTtcbiAgY29sb3I6ICM0MjcyQjk7XG59XG5cbi5jdXN0b21lci1hZGRyZXNzIHtcbiAgbWFyZ2luLXRvcDogMTZweDtcbiAgbWFyZ2luLWJvdHRvbTogMTZweDtcbiAgZm9udC1zaXplOiAwLjhlbTtcbiAgY29sb3I6ICM0MjcyQjk7XG59XG5cbmlvbi1ib3R0b20tZHJhd2VyIHtcbiAgLS1wYWRkaW5nOiAwICFpbXBvcnRhbnQ7XG4gIHBhZGRpbmc6IDAgIWltcG9ydGFudDtcbiAgLS1iYWNrZ3JvdW5kOiAjRjNGM0YzICFpbXBvcnRhbnQ7XG4gIGJhY2tncm91bmQ6ICNGM0YzRjMgIWltcG9ydGFudDtcbn1cbmlvbi1ib3R0b20tZHJhd2VyIGlvbi1jb250ZW50IHtcbiAgLS1iYWNrZ3JvdW5kOiAjRjNGM0YzICFpbXBvcnRhbnQ7XG59XG5cbi50aW1lc3RhbXAge1xuICBmb250LXNpemU6IDAuN2VtO1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/searchbar/design/design.component.ts":
  /*!******************************************************!*\
    !*** ./src/app/searchbar/design/design.component.ts ***!
    \******************************************************/

  /*! exports provided: DesignComponent */

  /***/
  function srcAppSearchbarDesignDesignComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DesignComponent", function () {
      return DesignComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var src_app_api_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! src/app/api.service */
    "./src/app/api.service.ts");
    /* harmony import */


    var src_app_utilities_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! src/app/utilities.service */
    "./src/app/utilities.service.ts");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var src_app_storage_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! src/app/storage.service */
    "./src/app/storage.service.ts");
    /* harmony import */


    var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! rxjs */
    "./node_modules/rxjs/_esm2015/index.js");
    /* harmony import */


    var _ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! @ionic-native/launch-navigator/ngx */
    "./node_modules/@ionic-native/launch-navigator/ngx/index.js");
    /* harmony import */


    var ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! ion-bottom-drawer */
    "./node_modules/ion-bottom-drawer/fesm2015/ion-bottom-drawer.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var src_app_homepage_design_design_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
    /*! src/app/homepage/design/design.component */
    "./src/app/homepage/design/design.component.ts");

    var DesignComponent = /*#__PURE__*/function () {
      function DesignComponent(utils, apiService, datePipe, storage, cdr, launchNavigator, formBuilder, route, router) {
        _classCallCheck(this, DesignComponent);

        this.utils = utils;
        this.apiService = apiService;
        this.datePipe = datePipe;
        this.storage = storage;
        this.cdr = cdr;
        this.launchNavigator = launchNavigator;
        this.formBuilder = formBuilder;
        this.route = route;
        this.router = router;
        this.listOfDesignDataHelper = [];
        this.listOfDesignsData = [];
        this.options = {
          start: '',
          app: this.launchNavigator.APP.GOOGLE_MAPS
        };
        this.drawerState = ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_8__["DrawerState"].Bottom;
        this.listOfAssignees = [];
        this.designId = 0;
        this.showBottomDraw = false;
        this.myFiles = [];
        this.isRequest = false;
        var latestDate = new Date();
        this.today = datePipe.transform(latestDate, 'M/dd/yy');
        console.log('date', this.today);
        this.assignForm = this.formBuilder.group({
          assignedto: new _angular_forms__WEBPACK_IMPORTED_MODULE_9__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_9__["Validators"].required]),
          comment: new _angular_forms__WEBPACK_IMPORTED_MODULE_9__["FormControl"]('')
        });
      }

      _createClass(DesignComponent, [{
        key: "ionViewDidEnter",
        value: function ionViewDidEnter() {// this.routeSubscription.unsubscribe();  
        }
      }, {
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this = this;

          // this.parentSubject.subscribe(event=>{
          //   this.filterData(event.serchTermData.id);
          // })
          // this.getDesign(event);
          this.routeSubscription = this.router.events.subscribe(function (event) {
            console.log("//", event);
            console.log(_this.router.url.indexOf('page'));

            if (event instanceof _angular_router__WEBPACK_IMPORTED_MODULE_10__["NavigationEnd"]) {
              console.log(event.url); // Trick the Router into believing it's last link wasn't previously loaded

              if (_this.router.url.indexOf('page') >= -1) {
                _this.router.navigated = false;

                var data = _this.route.queryParams.subscribe(function (_res) {
                  console.log('Serach Term', _res);

                  if (Object.keys(_res).length !== 0) {
                    //  this.ApplysearchDesginAndSurvey(_res.serchTerm)
                    _this.filterData(_res.serchTerm);
                  } else {
                    // this.refreshSubscription = this.utils.getHomepageDesignRefresh().subscribe((result) => {
                    _this.getDesign(null, false); // });

                  }
                });
              }
            }
          });
          this.getDesign(null, true);
        }
      }, {
        key: "ngOnDestroy",
        value: function ngOnDestroy() {//  this.refreshSubscription.unsubscribe();
          // this.routeSubscription.unsubscribe();
        }
      }, {
        key: "filterData",
        value: function filterData(serchTerm) {
          var _this2 = this;

          console.log(this.listOfDesignsData);
          var filterDataArray = this.listOfDesignsData.filter(function (x) {
            return x.id == serchTerm;
          });
          var tempData = [];
          filterDataArray.forEach(function (desginItem) {
            if (tempData.length === 0) {
              var listOfDesign = new src_app_homepage_design_design_component__WEBPACK_IMPORTED_MODULE_11__["DesginDataHelper"]();
              listOfDesign.date = _this2.datePipe.transform(desginItem.created_at, 'M/d/yy');
              listOfDesign.listOfDesigns.push(desginItem);
              tempData.push(listOfDesign);
            } else {
              var added = false;
              tempData.forEach(function (desginList) {
                if (!added) {
                  if (desginList.date === _this2.datePipe.transform(desginItem.created_at, 'M/d/yy')) {
                    desginList.listOfDesigns.push(desginItem);
                    added = true;
                  }
                }
              });

              if (!added) {
                var _listOfDesign = new src_app_homepage_design_design_component__WEBPACK_IMPORTED_MODULE_11__["DesginDataHelper"]();

                _listOfDesign.date = _this2.datePipe.transform(desginItem.created_at, 'M/d/yy');

                _listOfDesign.listOfDesigns.push(desginItem);

                tempData.push(_listOfDesign);
                added = true;

                _this2.listOfDesignDataHelper.push(_listOfDesign);

                console.log(_this2.listOfDesignDataHelper);
              }
            }
          });
          this.listOfDesignDataHelper = tempData;
          this.cdr.detectChanges();
        }
      }, {
        key: "getDesign",
        value: function getDesign(event, showLoader) {
          var _this3 = this;

          this.isRequest = true;
          this.listOfDesignsData = [];
          this.listOfDesignDataHelper = [];
          this.utils.showLoadingWithPullRefreshSupport(showLoader, 'Getting designs').then(function (success) {
            // debugger;
            _this3.apiService.getDesgin().subscribe(function (response) {
              _this3.utils.hideLoadingWithPullRefreshSupport(showLoader).then(function (loaderHidden) {
                // debugger;
                if (event !== null) {
                  event.target.complete();
                }

                console.log(response, '>>');
                _this3.listOfDesignsData = response;
                response.forEach(function (element) {
                  _this3.roleType = element.type;
                });
                ;
                console.log(_this3.roleType);
                var tempData = [];

                _this3.listOfDesignsData.forEach(function (desginItem) {
                  if (tempData.length === 0) {
                    var listOfDesign = new src_app_homepage_design_design_component__WEBPACK_IMPORTED_MODULE_11__["DesginDataHelper"]();
                    listOfDesign.date = _this3.datePipe.transform(desginItem.created_at, 'M/d/yy');
                    listOfDesign.listOfDesigns.push(desginItem);
                    tempData.push(listOfDesign);
                  } else {
                    var added = false;
                    tempData.forEach(function (desginList) {
                      if (!added) {
                        if (desginList.date === _this3.datePipe.transform(desginItem.created_at, 'M/d/yy')) {
                          desginList.listOfDesigns.push(desginItem);
                          added = true;
                        }
                      }
                    });

                    if (!added) {
                      var _listOfDesign2 = new src_app_homepage_design_design_component__WEBPACK_IMPORTED_MODULE_11__["DesginDataHelper"]();

                      _listOfDesign2.date = _this3.datePipe.transform(desginItem.created_at, 'M/d/yy');

                      _listOfDesign2.listOfDesigns.push(desginItem);

                      tempData.push(_listOfDesign2);
                      added = true;

                      _this3.listOfDesignDataHelper.push(_listOfDesign2);

                      console.log(_this3.listOfDesignDataHelper, "<<<<>>>>");
                    }
                  }
                });

                _this3.listOfDesignDataHelper = tempData;

                _this3.cdr.detectChanges();
              }, function (responseError) {
                _this3.utils.hideLoadingWithPullRefreshSupport(showLoader).then(function (loaderHidden) {
                  if (event !== null) {
                    event.target.complete();
                  }

                  var error = responseError.error;

                  _this3.utils.errorSnackBar(error.message[0].messages[0].message);
                });
              });
            }, function (responseError) {
              _this3.utils.hideLoadingWithPullRefreshSupport(showLoader).then(function (loaderHidden) {
                if (event !== null) {
                  event.target.complete();
                }

                var error = responseError.error;

                _this3.utils.errorSnackBar(error.message[0].messages[0].message);
              });
            });
          }, function (apiError) {
            _this3.utils.hideLoadingWithPullRefreshSupport(showLoader).then(function () {
              if (event !== null) {
                event.target.complete();
              }
            });
          });
        }
      }, {
        key: "openAddressOnMap",
        value: function openAddressOnMap(address) {
          this.launchNavigator.navigate(address, this.options);
        }
      }, {
        key: "dismissBottomSheet",
        value: function dismissBottomSheet() {
          console.log('this', this.drawerState);
          this.drawerState = ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_8__["DrawerState"].Bottom;
          this.utils.setBottomBarHomepage(true);
        }
      }, {
        key: "assignToDesigner",
        value: function assignToDesigner() {
          var _this4 = this;

          if (this.assignForm.status === 'INVALID') {
            this.utils.errorSnackBar('Please select a designer');
          } else {
            this.apiService.updateDesignForm(this.assignForm.value, this.designId).subscribe(function (value) {
              console.log('reach ', value);

              _this4.utils.showSnackBar('Design request has been assigned to' + ' ' + value.name + ' ' + 'successfully');

              _this4.dismissBottomSheet();

              _this4.showBottomDraw = false;

              _this4.utils.setHomepageDesignRefresh(true);
            }, function (error) {
              _this4.dismissBottomSheet();

              _this4.showBottomDraw = false;
            });
          }
        }
      }, {
        key: "openDesigners",
        value: function openDesigners(id) {
          var _this5 = this;

          if (this.listOfAssignees.length === 0) {
            this.utils.showLoading('Getting Designers').then(function () {
              _this5.apiService.getSurveyors().subscribe(function (assignees) {
                _this5.utils.hideLoading().then(function () {
                  _this5.listOfAssignees = []; // this.listOfAssignees.push(this.utils.getDefaultAssignee(this.storage.getUserID()));

                  assignees.forEach(function (item) {
                    return _this5.listOfAssignees.push(item);
                  });
                  console.log(_this5.listOfAssignees);
                  _this5.showBottomDraw = true;
                  _this5.designId = id;

                  _this5.utils.setBottomBarHomepage(false);

                  _this5.drawerState = ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_8__["DrawerState"].Docked;

                  _this5.assignForm.patchValue({
                    assignedto: 0
                  });
                });
              }, function (error) {
                _this5.utils.hideLoading().then(function () {
                  _this5.utils.errorSnackBar('Some error occurred. Please try again later');
                });
              });
            });
          } else {
            this.designId = id;
            this.utils.setBottomBarHomepage(false);
            this.drawerState = ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_8__["DrawerState"].Docked;
            this.assignForm.patchValue({
              assignedto: 0
            });
          }
        }
      }, {
        key: "close",
        value: function close() {
          if (this.showBottomDraw === true) {
            this.showBottomDraw = false;
            this.drawerState = ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_8__["DrawerState"].Bottom;
            this.utils.setBottomBarHomepage(true);
          } else {
            this.showBottomDraw = true;
          }
        }
      }, {
        key: "refreshDesigns",
        value: function refreshDesigns(event) {
          var showLoader = true;

          if (event !== null && event !== undefined) {
            showLoader = false;
          }

          this.getDesign(event, showLoader);
        }
      }]);

      return DesignComponent;
    }();

    DesignComponent.ctorParameters = function () {
      return [{
        type: src_app_utilities_service__WEBPACK_IMPORTED_MODULE_3__["UtilitiesService"]
      }, {
        type: src_app_api_service__WEBPACK_IMPORTED_MODULE_2__["ApiService"]
      }, {
        type: _angular_common__WEBPACK_IMPORTED_MODULE_4__["DatePipe"]
      }, {
        type: src_app_storage_service__WEBPACK_IMPORTED_MODULE_5__["StorageService"]
      }, {
        type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"]
      }, {
        type: _ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_7__["LaunchNavigator"]
      }, {
        type: _angular_forms__WEBPACK_IMPORTED_MODULE_9__["FormBuilder"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_10__["ActivatedRoute"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_10__["Router"]
      }];
    };

    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", rxjs__WEBPACK_IMPORTED_MODULE_6__["Subject"])], DesignComponent.prototype, "parentSubject", void 0);
    DesignComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-design',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./design.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/searchbar/design/design.component.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./design.component.scss */
      "./src/app/searchbar/design/design.component.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_utilities_service__WEBPACK_IMPORTED_MODULE_3__["UtilitiesService"], src_app_api_service__WEBPACK_IMPORTED_MODULE_2__["ApiService"], _angular_common__WEBPACK_IMPORTED_MODULE_4__["DatePipe"], src_app_storage_service__WEBPACK_IMPORTED_MODULE_5__["StorageService"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"], _ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_7__["LaunchNavigator"], _angular_forms__WEBPACK_IMPORTED_MODULE_9__["FormBuilder"], _angular_router__WEBPACK_IMPORTED_MODULE_10__["ActivatedRoute"], _angular_router__WEBPACK_IMPORTED_MODULE_10__["Router"]])], DesignComponent); // export class DesginDataHelper {
    //   listOfDesigns: DesginDataModel[];
    //   date: any;
    //   constructor() {
    //     this.listOfDesigns = [];
    //   }
    // }

    /***/
  },

  /***/
  "./src/app/searchbar/searchbar-routing.module.ts":
  /*!*******************************************************!*\
    !*** ./src/app/searchbar/searchbar-routing.module.ts ***!
    \*******************************************************/

  /*! exports provided: SearchbarPageRoutingModule */

  /***/
  function srcAppSearchbarSearchbarRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SearchbarPageRoutingModule", function () {
      return SearchbarPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _searchbar_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./searchbar.page */
    "./src/app/searchbar/searchbar.page.ts");
    /* harmony import */


    var _design_design_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ./design/design.component */
    "./src/app/searchbar/design/design.component.ts");
    /* harmony import */


    var _survey_survey_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./survey/survey.component */
    "./src/app/searchbar/survey/survey.component.ts");

    var routes = [{
      path: '',
      component: _searchbar_page__WEBPACK_IMPORTED_MODULE_3__["SearchbarPage"],
      children: [{
        path: 'design',
        component: _design_design_component__WEBPACK_IMPORTED_MODULE_4__["DesignComponent"]
      }, {
        path: 'survey',
        component: _survey_survey_component__WEBPACK_IMPORTED_MODULE_5__["SurveyComponent"]
      }]
    }];

    var SearchbarPageRoutingModule = function SearchbarPageRoutingModule() {
      _classCallCheck(this, SearchbarPageRoutingModule);
    };

    SearchbarPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], SearchbarPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/searchbar/searchbar.module.ts":
  /*!***********************************************!*\
    !*** ./src/app/searchbar/searchbar.module.ts ***!
    \***********************************************/

  /*! exports provided: SearchbarPageModule */

  /***/
  function srcAppSearchbarSearchbarModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SearchbarPageModule", function () {
      return SearchbarPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _searchbar_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./searchbar-routing.module */
    "./src/app/searchbar/searchbar-routing.module.ts");
    /* harmony import */


    var _searchbar_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./searchbar.page */
    "./src/app/searchbar/searchbar.page.ts");
    /* harmony import */


    var _utilities_utilities_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ../utilities/utilities.module */
    "./src/app/utilities/utilities.module.ts");
    /* harmony import */


    var _ionic_native_diagnostic_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! @ionic-native/diagnostic/ngx */
    "./node_modules/@ionic-native/diagnostic/ngx/index.js");
    /* harmony import */


    var _ionic_native_native_geocoder_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! @ionic-native/native-geocoder/ngx */
    "./node_modules/@ionic-native/native-geocoder/ngx/index.js");
    /* harmony import */


    var _ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
    /*! @ionic-native/launch-navigator/ngx */
    "./node_modules/@ionic-native/launch-navigator/ngx/index.js");
    /* harmony import */


    var _design_design_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
    /*! ./design/design.component */
    "./src/app/searchbar/design/design.component.ts");
    /* harmony import */


    var _survey_survey_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
    /*! ./survey/survey.component */
    "./src/app/searchbar/survey/survey.component.ts");
    /* harmony import */


    var ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(
    /*! ion-bottom-drawer */
    "./node_modules/ion-bottom-drawer/fesm2015/ion-bottom-drawer.js");

    var SearchbarPageModule = function SearchbarPageModule() {
      _classCallCheck(this, SearchbarPageModule);
    };

    SearchbarPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _searchbar_routing_module__WEBPACK_IMPORTED_MODULE_5__["SearchbarPageRoutingModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"], _utilities_utilities_module__WEBPACK_IMPORTED_MODULE_7__["UtilitiesModule"], ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_13__["IonBottomDrawerModule"]],
      declarations: [_searchbar_page__WEBPACK_IMPORTED_MODULE_6__["SearchbarPage"], _design_design_component__WEBPACK_IMPORTED_MODULE_11__["DesignComponent"], _survey_survey_component__WEBPACK_IMPORTED_MODULE_12__["SurveyComponent"]],
      providers: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["DatePipe"], _ionic_native_diagnostic_ngx__WEBPACK_IMPORTED_MODULE_8__["Diagnostic"], _ionic_native_native_geocoder_ngx__WEBPACK_IMPORTED_MODULE_9__["NativeGeocoder"], _ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_10__["LaunchNavigator"]]
    })], SearchbarPageModule);
    /***/
  },

  /***/
  "./src/app/searchbar/searchbar.page.scss":
  /*!***********************************************!*\
    !*** ./src/app/searchbar/searchbar.page.scss ***!
    \***********************************************/

  /*! exports provided: default */

  /***/
  function srcAppSearchbarSearchbarPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".notification-icon {\n  width: 24px;\n  height: 24px;\n}\n\n.home {\n  font-size: 22px;\n  margin-left: 6px;\n}\n\n.notification-badge {\n  font-size: 10px;\n  margin-left: -15px;\n  margin-top: -20px;\n}\n\n.notification-padding {\n  position: relative;\n  padding: 8px;\n}\n\n.badge {\n  width: 18px;\n  height: 18px;\n  position: absolute;\n  top: 0;\n  right: 0;\n  background: #3c78d8;\n  color: white;\n  box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.5);\n  border-radius: 50%;\n  font-size: 0.5em;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  border: 1px solid white;\n}\n\nion-searchbar.custom {\n  --background: none;\n  --box-shadow: none;\n  background: white;\n  border-radius: 0.5em;\n  box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1);\n  max-height: 40px;\n}\n\n.titleTab {\n  text-align: center;\n  color: #898989;\n}\n\n.titleBorder {\n  width: 70px;\n  border-bottom: 3px solid #D9726D;\n  border-radius: 2px;\n}\n\n.cardText {\n  margin: 0px;\n}\n\n.card_detail {\n  margin: 0px;\n  color: #3960B8;\n}\n\n.search_loc {\n  font-size: 14px;\n  color: #3960B8;\n}\n\n.search_text_div {\n  display: flex;\n  justify-content: space-between;\n}\n\n.survey_div {\n  border: 1px solid #FAE0C3;\n  padding: 6px;\n  background-color: #FAE0C3;\n  border-radius: 5px;\n}\n\n.nodata_div {\n  max-width: 290px !important;\n  width: 290px !important;\n}\n\n.search_text {\n  color: #9E9E9E;\n}\n\n.tab {\n  padding-top: 1em;\n  padding-bottom: 1em;\n  padding-bottom: 1em;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n\n.bottom-bar {\n  margin: 8px;\n  border-radius: 50px;\n  box-shadow: 0 -2px 8px 0 rgba(0, 0, 0, 0.1);\n  border: 2px solid white;\n  background: #FFFAEB;\n}\n\n.tabText {\n  margin-left: 8px;\n  font-size: 1em;\n}\n\n.tab-icon {\n  width: 24px;\n  height: 24px;\n}\n\n.fab-position {\n  bottom: 48px;\n}\n\nion-fab-button {\n  --border-width: 2px;\n  --border-style: solid;\n  --box-shadow: 0 0px 8px 0 rgba(0, 0, 0, 0.3);\n  --border-color: white;\n  --background: #3c78d8;\n}\n\nion-tab-bar {\n  --border: none;\n}\n\nion-tab-button {\n  font-size: 1em;\n  --color: #9E9E9E;\n  --color-selected: #3c78d8;\n}\n\nion-tab-button[aria-selected=true] {\n  border-bottom: 3px solid #3c78d8;\n  border-bottom-left-radius: 2px;\n  border-bottom-right-radius: 2px;\n}\n\n.searchbar_div {\n  box-shadow: 0 4px 3px 0 rgba(0, 0, 0, 0.1);\n  border-radius: 4px;\n  margin-top: -24px;\n  width: 94%;\n  margin-left: 5px;\n  background: white;\n  max-width: 94%;\n}\n\n.profile-icon {\n  width: 50px;\n  height: 50px;\n  margin-right: 3px;\n  margin-left: -7px;\n}\n\n.history-name {\n  font-size: 16px;\n  color: #787574;\n}\n\n.history-add {\n  color: #CFCBCA;\n  font-size: 14px;\n}\n\n.assign {\n  font-size: 14px;\n  color: #878382;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2VhcmNoYmFyL0Y6XFxtb2JpbGVhcHAvc3JjXFxhcHBcXHNlYXJjaGJhclxcc2VhcmNoYmFyLnBhZ2Uuc2NzcyIsInNyYy9hcHAvc2VhcmNoYmFyL3NlYXJjaGJhci5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBRUE7RUFDSSxXQUFBO0VBQ0EsWUFBQTtBQ0RKOztBRElBO0VBQ0ksZUFBQTtFQUNBLGdCQUFBO0FDREo7O0FESUE7RUFDSSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtBQ0RKOztBRElBO0VBQ0ksa0JBQUE7RUFDQSxZQUFBO0FDREo7O0FESUE7RUFDSSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsTUFBQTtFQUNBLFFBQUE7RUFDQSxtQkFBQTtFQUNBLFlBQUE7RUFDQSwwQ0FBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtFQUNBLHVCQUFBO0FDREo7O0FESUE7RUFDSSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7RUFDQSxvQkFBQTtFQUNBLDBDQUFBO0VBQ0EsZ0JBQUE7QUNESjs7QURLQTtFQUNJLGtCQUFBO0VBQ0EsY0FBQTtBQ0ZKOztBRE1BO0VBQ0ksV0FBQTtFQUNBLGdDQUFBO0VBQ0Esa0JBQUE7QUNISjs7QURNQTtFQUNJLFdBQUE7QUNISjs7QURNQTtFQUNJLFdBQUE7RUFDQSxjQUFBO0FDSEo7O0FETUE7RUFDSSxlQUFBO0VBQ0EsY0FBQTtBQ0hKOztBRE1BO0VBQ0ksYUFBQTtFQUNBLDhCQUFBO0FDSEo7O0FETUE7RUFDSSx5QkFBQTtFQUNBLFlBQUE7RUFDQSx5QkFBQTtFQUNBLGtCQUFBO0FDSEo7O0FETUE7RUFDSSwyQkFBQTtFQUNBLHVCQUFBO0FDSEo7O0FETUE7RUFDSSxjQUFBO0FDSEo7O0FEYUE7RUFDSSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsbUJBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtBQ1ZKOztBRGFBO0VBQ0ksV0FBQTtFQUNBLG1CQUFBO0VBQ0EsMkNBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0FDVko7O0FEYUE7RUFDSSxnQkFBQTtFQUNBLGNBQUE7QUNWSjs7QURhQTtFQUNJLFdBQUE7RUFDQSxZQUFBO0FDVko7O0FEYUE7RUFDSSxZQUFBO0FDVko7O0FEYUE7RUFDSSxtQkFBQTtFQUNBLHFCQUFBO0VBQ0EsNENBQUE7RUFDQSxxQkFBQTtFQUNBLHFCQUFBO0FDVko7O0FEYUE7RUFDSSxjQUFBO0FDVko7O0FEYUE7RUFDSSxjQUFBO0VBQ0EsZ0JBQUE7RUFDQSx5QkFBQTtBQ1ZKOztBRGFBO0VBQ0ksZ0NBQUE7RUFDQSw4QkFBQTtFQUNBLCtCQUFBO0FDVko7O0FEYUE7RUFDSSwwQ0FBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7RUFDQSxVQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLGNBQUE7QUNWSjs7QURjQTtFQUNJLFdBQUE7RUFDQSxZQUFBO0VBQ0EsaUJBQUE7RUFDQSxpQkFBQTtBQ1hKOztBRGVFO0VBQ0UsZUFBQTtFQUNBLGNBQUE7QUNaSjs7QURlRTtFQUNFLGNBQUE7RUFDRSxlQUFBO0FDWk47O0FEZUU7RUFDSSxlQUFBO0VBQ0EsY0FBQTtBQ1pOIiwiZmlsZSI6InNyYy9hcHAvc2VhcmNoYmFyL3NlYXJjaGJhci5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuXHJcbi5ub3RpZmljYXRpb24taWNvbiB7XHJcbiAgICB3aWR0aDogMjRweDtcclxuICAgIGhlaWdodDogMjRweDtcclxufVxyXG5cclxuLmhvbWV7XHJcbiAgICBmb250LXNpemU6IDIycHg7XHJcbiAgICBtYXJnaW4tbGVmdDogNnB4O1xyXG59XHJcblxyXG4ubm90aWZpY2F0aW9uLWJhZGdlIHtcclxuICAgIGZvbnQtc2l6ZTogMTBweDtcclxuICAgIG1hcmdpbi1sZWZ0OiAtMTVweDtcclxuICAgIG1hcmdpbi10b3A6IC0yMHB4O1xyXG59XHJcblxyXG4ubm90aWZpY2F0aW9uLXBhZGRpbmcge1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgcGFkZGluZzogOHB4O1xyXG59XHJcblxyXG4uYmFkZ2Uge1xyXG4gICAgd2lkdGg6IDE4cHg7XHJcbiAgICBoZWlnaHQ6IDE4cHg7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB0b3A6IDA7XHJcbiAgICByaWdodDogMDtcclxuICAgIGJhY2tncm91bmQ6ICMzYzc4ZDg7XHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbiAgICBib3gtc2hhZG93OiAwIDFweCAzcHggMCByZ2JhKDAsIDAsIDAsIDAuNSk7XHJcbiAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICBmb250LXNpemU6IDAuNWVtO1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkIHdoaXRlO1xyXG59XHJcblxyXG5pb24tc2VhcmNoYmFyLmN1c3RvbSB7XHJcbiAgICAtLWJhY2tncm91bmQ6IG5vbmU7XHJcbiAgICAtLWJveC1zaGFkb3c6IG5vbmU7XHJcbiAgICBiYWNrZ3JvdW5kOiB3aGl0ZTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDAuNWVtO1xyXG4gICAgYm94LXNoYWRvdzogMCAxcHggM3B4IDAgcmdiYSgwLCAwLCAwLCAwLjEpO1xyXG4gICAgbWF4LWhlaWdodDogNDBweDtcclxufVxyXG5cclxuXHJcbi50aXRsZVRhYiB7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBjb2xvcjogIzg5ODk4OTtcclxuICAgIC8vICAgICBib3JkZXItYm90dG9tOiAycHggc29saWQgI0Q5NzI2RDtcclxufVxyXG5cclxuLnRpdGxlQm9yZGVyIHtcclxuICAgIHdpZHRoOiA3MHB4O1xyXG4gICAgYm9yZGVyLWJvdHRvbTogM3B4IHNvbGlkICNEOTcyNkQ7XHJcbiAgICBib3JkZXItcmFkaXVzOiAycHg7XHJcbn1cclxuXHJcbi5jYXJkVGV4dCB7XHJcbiAgICBtYXJnaW46IDBweDtcclxufVxyXG5cclxuLmNhcmRfZGV0YWlsIHtcclxuICAgIG1hcmdpbjogMHB4O1xyXG4gICAgY29sb3I6ICMzOTYwQjg7XHJcbn1cclxuXHJcbi5zZWFyY2hfbG9jIHtcclxuICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgIGNvbG9yOiAjMzk2MEI4O1xyXG59XHJcblxyXG4uc2VhcmNoX3RleHRfZGl2IHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbn1cclxuXHJcbi5zdXJ2ZXlfZGl2IHtcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkICNGQUUwQzM7XHJcbiAgICBwYWRkaW5nOiA2cHg7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjRkFFMEMzO1xyXG4gICAgYm9yZGVyLXJhZGl1czogNXB4O1xyXG59XHJcblxyXG4ubm9kYXRhX2RpdntcclxuICAgIG1heC13aWR0aDogMjkwcHggIWltcG9ydGFudDtcclxuICAgIHdpZHRoOiAyOTBweCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uc2VhcmNoX3RleHQge1xyXG4gICAgY29sb3I6ICM5RTlFOUU7XHJcbn1cclxuXHJcbi8vLmlvbi10YWItYmFyLnRhYnN0eWxlIHtcclxuLy8gICAgLS1iYWNrZ3JvdW5kOiBub25lO1xyXG4vLyAgICAtLWJveC1zaGFkb3c6IG5vbmU7XHJcbi8vICAgIGJveC1zaGFkb3c6IDAgMXB4IDNweCAwIHJnYmEoMCwgMCwgMCwgMC41KTtcclxuLy8gICAgYmFja2dyb3VuZDogI0ZGRkFFQjtcclxuLy99XHJcblxyXG4udGFiIHtcclxuICAgIHBhZGRpbmctdG9wOiAxZW07XHJcbiAgICBwYWRkaW5nLWJvdHRvbTogMWVtO1xyXG4gICAgcGFkZGluZy1ib3R0b206IDFlbTtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbn1cclxuXHJcbi5ib3R0b20tYmFyIHtcclxuICAgIG1hcmdpbjogOHB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogNTBweDtcclxuICAgIGJveC1zaGFkb3c6IDAgLTJweCA4cHggMCByZ2JhKDAsIDAsIDAsIDAuMSk7XHJcbiAgICBib3JkZXI6IDJweCBzb2xpZCB3aGl0ZTtcclxuICAgIGJhY2tncm91bmQ6ICNGRkZBRUI7XHJcbn1cclxuXHJcbi50YWJUZXh0IHtcclxuICAgIG1hcmdpbi1sZWZ0OiA4cHg7XHJcbiAgICBmb250LXNpemU6IDFlbTtcclxufVxyXG5cclxuLnRhYi1pY29uIHtcclxuICAgIHdpZHRoOiAyNHB4O1xyXG4gICAgaGVpZ2h0OiAyNHB4O1xyXG59XHJcblxyXG4uZmFiLXBvc2l0aW9uIHtcclxuICAgIGJvdHRvbTogNDhweDtcclxufVxyXG5cclxuaW9uLWZhYi1idXR0b24ge1xyXG4gICAgLS1ib3JkZXItd2lkdGg6IDJweDtcclxuICAgIC0tYm9yZGVyLXN0eWxlOiBzb2xpZDtcclxuICAgIC0tYm94LXNoYWRvdzogMCAwcHggOHB4IDAgcmdiYSgwLCAwLCAwLCAwLjMpO1xyXG4gICAgLS1ib3JkZXItY29sb3I6IHdoaXRlO1xyXG4gICAgLS1iYWNrZ3JvdW5kOiAjM2M3OGQ4O1xyXG59XHJcblxyXG5pb24tdGFiLWJhciB7XHJcbiAgICAtLWJvcmRlcjogbm9uZTtcclxufVxyXG5cclxuaW9uLXRhYi1idXR0b24ge1xyXG4gICAgZm9udC1zaXplOiAxZW07XHJcbiAgICAtLWNvbG9yOiAjOUU5RTlFO1xyXG4gICAgLS1jb2xvci1zZWxlY3RlZDogIzNjNzhkODtcclxufVxyXG5cclxuaW9uLXRhYi1idXR0b25bYXJpYS1zZWxlY3RlZD10cnVlXSB7XHJcbiAgICBib3JkZXItYm90dG9tOiAzcHggc29saWQgIzNjNzhkODtcclxuICAgIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDJweDtcclxuICAgIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiAycHg7XHJcbn1cclxuXHJcbi5zZWFyY2hiYXJfZGl2e1xyXG4gICAgYm94LXNoYWRvdzogMCA0cHggM3B4IDAgcmdiYSgwLCAwLCAwLCAwLjEpO1xyXG4gICAgYm9yZGVyLXJhZGl1czogNHB4O1xyXG4gICAgbWFyZ2luLXRvcDogLTI0cHg7XHJcbiAgICB3aWR0aDogOTQlO1xyXG4gICAgbWFyZ2luLWxlZnQ6IDVweDtcclxuICAgIGJhY2tncm91bmQ6IHdoaXRlO1xyXG4gICAgbWF4LXdpZHRoOiA5NCU7XHJcbn1cclxuXHJcblxyXG4ucHJvZmlsZS1pY29ue1xyXG4gICAgd2lkdGg6IDUwcHg7XHJcbiAgICBoZWlnaHQ6IDUwcHg7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDNweDtcclxuICAgIG1hcmdpbi1sZWZ0OiAtN3B4O1xyXG4gICBcclxuICB9XHJcblxyXG4gIC5oaXN0b3J5LW5hbWV7XHJcbiAgICBmb250LXNpemU6IDE2cHg7IFxyXG4gICAgY29sb3I6ICM3ODc1NzQ7XHJcbiAgfVxyXG5cclxuICAuaGlzdG9yeS1hZGR7XHJcbiAgICBjb2xvcjogI0NGQ0JDQTtcclxuICAgICAgZm9udC1zaXplOiAxNHB4O1xyXG4gIH1cclxuXHJcbiAgLmFzc2lnbntcclxuICAgICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgICBjb2xvcjogIzg3ODM4MjtcclxuICB9XHJcbiIsIi5ub3RpZmljYXRpb24taWNvbiB7XG4gIHdpZHRoOiAyNHB4O1xuICBoZWlnaHQ6IDI0cHg7XG59XG5cbi5ob21lIHtcbiAgZm9udC1zaXplOiAyMnB4O1xuICBtYXJnaW4tbGVmdDogNnB4O1xufVxuXG4ubm90aWZpY2F0aW9uLWJhZGdlIHtcbiAgZm9udC1zaXplOiAxMHB4O1xuICBtYXJnaW4tbGVmdDogLTE1cHg7XG4gIG1hcmdpbi10b3A6IC0yMHB4O1xufVxuXG4ubm90aWZpY2F0aW9uLXBhZGRpbmcge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIHBhZGRpbmc6IDhweDtcbn1cblxuLmJhZGdlIHtcbiAgd2lkdGg6IDE4cHg7XG4gIGhlaWdodDogMThweDtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0b3A6IDA7XG4gIHJpZ2h0OiAwO1xuICBiYWNrZ3JvdW5kOiAjM2M3OGQ4O1xuICBjb2xvcjogd2hpdGU7XG4gIGJveC1zaGFkb3c6IDAgMXB4IDNweCAwIHJnYmEoMCwgMCwgMCwgMC41KTtcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xuICBmb250LXNpemU6IDAuNWVtO1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgYm9yZGVyOiAxcHggc29saWQgd2hpdGU7XG59XG5cbmlvbi1zZWFyY2hiYXIuY3VzdG9tIHtcbiAgLS1iYWNrZ3JvdW5kOiBub25lO1xuICAtLWJveC1zaGFkb3c6IG5vbmU7XG4gIGJhY2tncm91bmQ6IHdoaXRlO1xuICBib3JkZXItcmFkaXVzOiAwLjVlbTtcbiAgYm94LXNoYWRvdzogMCAxcHggM3B4IDAgcmdiYSgwLCAwLCAwLCAwLjEpO1xuICBtYXgtaGVpZ2h0OiA0MHB4O1xufVxuXG4udGl0bGVUYWIge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGNvbG9yOiAjODk4OTg5O1xufVxuXG4udGl0bGVCb3JkZXIge1xuICB3aWR0aDogNzBweDtcbiAgYm9yZGVyLWJvdHRvbTogM3B4IHNvbGlkICNEOTcyNkQ7XG4gIGJvcmRlci1yYWRpdXM6IDJweDtcbn1cblxuLmNhcmRUZXh0IHtcbiAgbWFyZ2luOiAwcHg7XG59XG5cbi5jYXJkX2RldGFpbCB7XG4gIG1hcmdpbjogMHB4O1xuICBjb2xvcjogIzM5NjBCODtcbn1cblxuLnNlYXJjaF9sb2Mge1xuICBmb250LXNpemU6IDE0cHg7XG4gIGNvbG9yOiAjMzk2MEI4O1xufVxuXG4uc2VhcmNoX3RleHRfZGl2IHtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xufVxuXG4uc3VydmV5X2RpdiB7XG4gIGJvcmRlcjogMXB4IHNvbGlkICNGQUUwQzM7XG4gIHBhZGRpbmc6IDZweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogI0ZBRTBDMztcbiAgYm9yZGVyLXJhZGl1czogNXB4O1xufVxuXG4ubm9kYXRhX2RpdiB7XG4gIG1heC13aWR0aDogMjkwcHggIWltcG9ydGFudDtcbiAgd2lkdGg6IDI5MHB4ICFpbXBvcnRhbnQ7XG59XG5cbi5zZWFyY2hfdGV4dCB7XG4gIGNvbG9yOiAjOUU5RTlFO1xufVxuXG4udGFiIHtcbiAgcGFkZGluZy10b3A6IDFlbTtcbiAgcGFkZGluZy1ib3R0b206IDFlbTtcbiAgcGFkZGluZy1ib3R0b206IDFlbTtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG59XG5cbi5ib3R0b20tYmFyIHtcbiAgbWFyZ2luOiA4cHg7XG4gIGJvcmRlci1yYWRpdXM6IDUwcHg7XG4gIGJveC1zaGFkb3c6IDAgLTJweCA4cHggMCByZ2JhKDAsIDAsIDAsIDAuMSk7XG4gIGJvcmRlcjogMnB4IHNvbGlkIHdoaXRlO1xuICBiYWNrZ3JvdW5kOiAjRkZGQUVCO1xufVxuXG4udGFiVGV4dCB7XG4gIG1hcmdpbi1sZWZ0OiA4cHg7XG4gIGZvbnQtc2l6ZTogMWVtO1xufVxuXG4udGFiLWljb24ge1xuICB3aWR0aDogMjRweDtcbiAgaGVpZ2h0OiAyNHB4O1xufVxuXG4uZmFiLXBvc2l0aW9uIHtcbiAgYm90dG9tOiA0OHB4O1xufVxuXG5pb24tZmFiLWJ1dHRvbiB7XG4gIC0tYm9yZGVyLXdpZHRoOiAycHg7XG4gIC0tYm9yZGVyLXN0eWxlOiBzb2xpZDtcbiAgLS1ib3gtc2hhZG93OiAwIDBweCA4cHggMCByZ2JhKDAsIDAsIDAsIDAuMyk7XG4gIC0tYm9yZGVyLWNvbG9yOiB3aGl0ZTtcbiAgLS1iYWNrZ3JvdW5kOiAjM2M3OGQ4O1xufVxuXG5pb24tdGFiLWJhciB7XG4gIC0tYm9yZGVyOiBub25lO1xufVxuXG5pb24tdGFiLWJ1dHRvbiB7XG4gIGZvbnQtc2l6ZTogMWVtO1xuICAtLWNvbG9yOiAjOUU5RTlFO1xuICAtLWNvbG9yLXNlbGVjdGVkOiAjM2M3OGQ4O1xufVxuXG5pb24tdGFiLWJ1dHRvblthcmlhLXNlbGVjdGVkPXRydWVdIHtcbiAgYm9yZGVyLWJvdHRvbTogM3B4IHNvbGlkICMzYzc4ZDg7XG4gIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDJweDtcbiAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDJweDtcbn1cblxuLnNlYXJjaGJhcl9kaXYge1xuICBib3gtc2hhZG93OiAwIDRweCAzcHggMCByZ2JhKDAsIDAsIDAsIDAuMSk7XG4gIGJvcmRlci1yYWRpdXM6IDRweDtcbiAgbWFyZ2luLXRvcDogLTI0cHg7XG4gIHdpZHRoOiA5NCU7XG4gIG1hcmdpbi1sZWZ0OiA1cHg7XG4gIGJhY2tncm91bmQ6IHdoaXRlO1xuICBtYXgtd2lkdGg6IDk0JTtcbn1cblxuLnByb2ZpbGUtaWNvbiB7XG4gIHdpZHRoOiA1MHB4O1xuICBoZWlnaHQ6IDUwcHg7XG4gIG1hcmdpbi1yaWdodDogM3B4O1xuICBtYXJnaW4tbGVmdDogLTdweDtcbn1cblxuLmhpc3RvcnktbmFtZSB7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgY29sb3I6ICM3ODc1NzQ7XG59XG5cbi5oaXN0b3J5LWFkZCB7XG4gIGNvbG9yOiAjQ0ZDQkNBO1xuICBmb250LXNpemU6IDE0cHg7XG59XG5cbi5hc3NpZ24ge1xuICBmb250LXNpemU6IDE0cHg7XG4gIGNvbG9yOiAjODc4MzgyO1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/searchbar/searchbar.page.ts":
  /*!*********************************************!*\
    !*** ./src/app/searchbar/searchbar.page.ts ***!
    \*********************************************/

  /*! exports provided: SearchbarPage */

  /***/
  function srcAppSearchbarSearchbarPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SearchbarPage", function () {
      return SearchbarPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _utilities_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ../utilities.service */
    "./src/app/utilities.service.ts");
    /* harmony import */


    var _api_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../api.service */
    "./src/app/api.service.ts");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _storage_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ../storage.service */
    "./src/app/storage.service.ts");
    /* harmony import */


    var _ionic_native_diagnostic_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @ionic-native/diagnostic/ngx */
    "./node_modules/@ionic-native/diagnostic/ngx/index.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _ionic_native_geolocation_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! @ionic-native/geolocation/ngx */
    "./node_modules/@ionic-native/geolocation/ngx/index.js");
    /* harmony import */


    var _ionic_native_native_geocoder_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! @ionic-native/native-geocoder/ngx */
    "./node_modules/@ionic-native/native-geocoder/ngx/index.js");
    /* harmony import */


    var rxjs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
    /*! rxjs */
    "./node_modules/rxjs/_esm2015/index.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _contants__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
    /*! ../contants */
    "./src/app/contants.ts");
    /* harmony import */


    var _homepage_design_design_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(
    /*! ../homepage/design/design.component */
    "./src/app/homepage/design/design.component.ts");

    var SearchbarPage = /*#__PURE__*/function () {
      function SearchbarPage(utilities, apiService, nativeGeocoder, platform, datePipe, storage, diagnostic, alertController, geolocation, toastController, route) {
        _classCallCheck(this, SearchbarPage);

        this.utilities = utilities;
        this.apiService = apiService;
        this.nativeGeocoder = nativeGeocoder;
        this.platform = platform;
        this.datePipe = datePipe;
        this.storage = storage;
        this.diagnostic = diagnostic;
        this.alertController = alertController;
        this.geolocation = geolocation;
        this.toastController = toastController;
        this.route = route;
        this.parentSubject = new rxjs__WEBPACK_IMPORTED_MODULE_10__["Subject"]();
        this.ionInput = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.searchQuery = '';
        this.searchbarElement = '';
        this.isUserSurveyor = false;
        this.isUserDesigner = false;
        this.showSearchBar = false;
        this.showHome = true;
        this.showFooter = true; // Geocoder configuration

        this.geoEncoderOptions = {
          useLocale: true,
          maxResults: 5
        };
        this.searchDesginItem = [];
        this.searchSurveyItem = [];
        this.pageType = '';
      }

      _createClass(SearchbarPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          // this.setupCometChatUser();
          // this.requestLocationPermission();
          // this.updateUserPushToken();
          // this.subscription = this.utilities.getBottomBarHomepage().subscribe((value) => {
          //   this.showFooter = value;
          // });
          if (this.storage.getUser().role.id === _contants__WEBPACK_IMPORTED_MODULE_12__["ROLES"].Surveyor) {
            // surveyor will only see survey tab
            this.isUserSurveyor = true;
            this.isUserDesigner = false;
            this.route.navigate(['searchbar/survey']);
          } else if (this.storage.getUser().role.id === _contants__WEBPACK_IMPORTED_MODULE_12__["ROLES"].Designer) {
            // designer will only see design tab
            this.isUserSurveyor = false;
            this.isUserDesigner = true;
            this.route.navigate(['searchbar/design']);
          } else if (this.storage.getUser().role.id === _contants__WEBPACK_IMPORTED_MODULE_12__["ROLES"].BD || this.storage.getUser().role.id === _contants__WEBPACK_IMPORTED_MODULE_12__["ROLES"].Admin || this.storage.getUser().role.id === _contants__WEBPACK_IMPORTED_MODULE_12__["ROLES"].ContractorAdmin) {
            // admin will see both tabs
            this.isUserSurveyor = true;
            this.isUserDesigner = true;
            this.route.navigate(['searchbar/design']);
          }
        }
      }, {
        key: "ngOnDestroy",
        value: function ngOnDestroy() {// this.subscription.unsubscribe();
        }
      }, {
        key: "getItems",
        value: function getItems(ev) {
          // set val to the value of the searchbar
          var val = ev.target.value; // if the value is an empty string don't filter the items

          if (val && val.trim() !== '') {
            this.items = this.items.filter(function (item) {
              return item.toLowerCase().indexOf(val.toLowerCase()) > -1;
            });
          }
        }
      }, {
        key: "searchDesginAndSurvey",
        value: function searchDesginAndSurvey(event) {
          var _this6 = this;

          console.log(event, this.searchbarElement);

          if (this.searchbarElement !== '') {
            this.apiService.searchAllDesgin(this.searchbarElement).subscribe(function (searchModel) {
              console.log(searchModel); // console.log(searchModel.design);
              // this.searchDesginItem = [];
              // this.searchSurveyItem = [];

              if (event.target.value !== '') {
                // searchModel.filter((element: any) => {
                // if (this == 'design') {
                if (_this6.route.url == '/searchbar/design') {
                  _this6.searchDesginItem = searchModel.design;
                } else {
                  _this6.searchSurveyItem = searchModel.survey;
                }

                console.log(_this6.searchDesginItem); // });

                console.log(_this6.searchSurveyItem);
              } else {
                _this6.searchDesginItem = [];
                _this6.searchSurveyItem = [];
              }
            }, function (error) {
              console.log(error);
            });
          } else {
            this.route.navigate(['searchbar/design']);
          }
        }
      }, {
        key: "getdesigndata",
        value: function getdesigndata() {
          var serchTermData = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {
            'type': ''
          };
          console.log(serchTermData);
          this.name = serchTermData.name == undefined ? '' : serchTermData.name;
          this.searchbarElement = this.name;

          if (this.route.url == '/searchbar/design') {
            this.pageType = 'Design'; // this.parentSubject.next(serchTermData.id);

            this.route.navigate(['searchbar/design'], {
              queryParams: {
                serchTerm: serchTermData.id
              }
            });
          } else if (this.route.url == '/searchbar/survey') {
            this.pageType = 'Survey'; // this.parentSubject.next(serchTermData.id);

            this.route.navigate(['/searchbar/survey'], {
              queryParams: {
                serchTerm: serchTermData.id
              }
            });
          } else {
            if (this.pageType == 'Survey') {
              this.route.navigate(['searchbar/survey']);
            } else if (this.pageType == 'Design') {
              this.route.navigate(['searchbar/design']);
            }
          }

          this.searchDesginItem = [];
          this.searchSurveyItem = [];
        }
      }, {
        key: "searchbar",
        value: function searchbar() {
          this.route.navigate(['/searchbar/design']);
        }
      }, {
        key: "requestLocationPermission",
        value: function requestLocationPermission() {
          var _this7 = this;

          this.platform.ready().then(function () {
            _this7.diagnostic.requestLocationAuthorization(_this7.diagnostic.locationAuthorizationMode.WHEN_IN_USE).then(function (mode) {
              console.log(mode);

              switch (mode) {
                case _this7.diagnostic.permissionStatus.NOT_REQUESTED:
                  // this.goBack();
                  break;

                case _this7.diagnostic.permissionStatus.DENIED_ALWAYS:
                  _this7.showLocationDenied();

                  break;

                case _this7.diagnostic.permissionStatus.DENIED_ONCE:
                  // this.goBack();
                  break;

                case _this7.diagnostic.permissionStatus.GRANTED:
                  _this7.fetchLocation();

                  break;

                case _this7.diagnostic.permissionStatus.GRANTED_WHEN_IN_USE:
                  _this7.fetchLocation();

                  break;

                case 'authorized_when_in_use':
                  _this7.fetchLocation();

                  break;
              }
            }, function (rejection) {
              console.log(rejection);
            });
          });
        }
      }, {
        key: "showLocationDenied",
        value: function showLocationDenied() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            var toast;
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.toastController.create({
                      header: 'Error',
                      message: 'Location services denied, please enable them manually',
                      cssClass: 'my-custom-class',
                      buttons: [{
                        text: 'OK',
                        handler: function handler() {}
                      }]
                    });

                  case 2:
                    toast = _context.sent;
                    toast.present();

                  case 4:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "fetchLocation",
        value: function fetchLocation() {
          var _this8 = this;

          this.diagnostic.isGpsLocationEnabled().then(function (status) {
            if (status === true) {
              // this.utilities.showLoading('Getting Location').then(() => {
              _this8.getGeoLocation(); // });

            } else {
              _this8.askToChangeSettings();
            }
          });
        }
      }, {
        key: "askToChangeSettings",
        value: function askToChangeSettings() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
            var _this9 = this;

            var toast;
            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    _context2.next = 2;
                    return this.toastController.create({
                      header: 'Location Disabled',
                      message: 'Please enable location services',
                      cssClass: 'my-custom-class',
                      buttons: [{
                        text: 'OK',
                        handler: function handler() {
                          _this9.changeLocationSettings();
                        }
                      }, {
                        text: 'Cancel',
                        handler: function handler() {}
                      }]
                    });

                  case 2:
                    toast = _context2.sent;
                    toast.present();

                  case 4:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2, this);
          }));
        }
      }, {
        key: "getGeoLocation",
        value: function getGeoLocation() {
          var _this10 = this;

          this.geolocation.getCurrentPosition().then(function (resp) {
            console.log('resp', resp);

            _this10.getGeoEncoder(resp.coords.latitude, resp.coords.longitude);
          })["catch"](function (error) {
            _this10.utilities.errorSnackBar('Unable to get location');

            console.log('Error getting location', error);

            _this10.showNoLocation();
          });
        }
      }, {
        key: "getGeoEncoder",
        value: function getGeoEncoder(latitude, longitude) {
          var _this11 = this;

          // this.utilities.hideLoading().then((success) => {
          this.nativeGeocoder.reverseGeocode(latitude, longitude, this.geoEncoderOptions).then(function (result) {
            console.log('resu', result);
            var address = {
              address: _this11.generateAddress(result[0]),
              lat: latitude,
              "long": longitude,
              country: result[0].countryName,
              state: result[0].administrativeArea,
              city: result[0].locality,
              postalcode: result[0].postalCode
            };

            _this11.utilities.setAddress(address);
          })["catch"](function (error) {
            _this11.showNoLocation();

            alert('Error getting location' + JSON.stringify(error));
          });
        }
      }, {
        key: "generateAddress",
        value: function generateAddress(addressObj) {
          var obj = [];
          var address = '';

          for (var key in addressObj) {
            obj.push(addressObj[key]);
          }

          obj.reverse();

          for (var val in obj) {
            if (obj[val].length) {
              address += obj[val] + ', ';
            }
          }

          return address.slice(0, -2);
        }
      }, {
        key: "changeLocationSettings",
        value: function changeLocationSettings() {
          var _this12 = this;

          this.diagnostic.switchToLocationSettings();
          this.diagnostic.registerLocationStateChangeHandler(function (state) {
            console.log(state);

            if (_this12.platform.is('android') && state !== _this12.diagnostic.locationMode.LOCATION_OFF) {
              _this12.checkLocationAccess();
            }
          });
        }
      }, {
        key: "checkLocationAccess",
        value: function checkLocationAccess() {
          var _this13 = this;

          console.log('Getting location');
          this.diagnostic.isLocationAuthorized().then(function (success) {
            _this13.fetchLocation();
          }, function (error) {
            _this13.utilities.errorSnackBar('GPS Not Allowed');
          });
        }
      }, {
        key: "showNoLocation",
        value: function showNoLocation() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
            var alert;
            return regeneratorRuntime.wrap(function _callee3$(_context3) {
              while (1) {
                switch (_context3.prev = _context3.next) {
                  case 0:
                    _context3.next = 2;
                    return this.alertController.create({
                      header: 'Error',
                      subHeader: 'Unable to get location',
                      buttons: [{
                        text: 'OK',
                        handler: function handler() {// this.goBack();
                        }
                      }],
                      backdropDismiss: false
                    });

                  case 2:
                    alert = _context3.sent;
                    _context3.next = 5;
                    return alert.present();

                  case 5:
                  case "end":
                    return _context3.stop();
                }
              }
            }, _callee3, this);
          }));
        }
      }, {
        key: "ionViewDidEnter",
        value: function ionViewDidEnter() {
          var _this14 = this;

          this.subscription = this.platform.backButton.subscribe(function () {
            if (_this14.showSearchBar === true) {
              _this14.showSearchBar = false;
            } else {// (navigator as any).app.exitApp();
            }
          });
        }
      }, {
        key: "ionViewWillLeave",
        value: function ionViewWillLeave() {
          this.subscription.unsubscribe();
        }
      }, {
        key: "showHom",
        value: function showHom() {
          // this.someEvent.emit('cancle');
          this.showHome = true;
          this.showSearchBar = false;
          this.searchSurveyItem = [];
          this.searchDesginItem = [];
          this.searchbarElement = '';
          this.getdesigndata();
        }
      }, {
        key: "onClick",
        value: function onClick() {
          this.showHome = false;
          this.showSearchBar = true;
        }
      }]);

      return SearchbarPage;
    }();

    SearchbarPage.ctorParameters = function () {
      return [{
        type: _utilities_service__WEBPACK_IMPORTED_MODULE_2__["UtilitiesService"]
      }, {
        type: _api_service__WEBPACK_IMPORTED_MODULE_3__["ApiService"]
      }, {
        type: _ionic_native_native_geocoder_ngx__WEBPACK_IMPORTED_MODULE_9__["NativeGeocoder"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["Platform"]
      }, {
        type: _angular_common__WEBPACK_IMPORTED_MODULE_4__["DatePipe"]
      }, {
        type: _storage_service__WEBPACK_IMPORTED_MODULE_5__["StorageService"]
      }, {
        type: _ionic_native_diagnostic_ngx__WEBPACK_IMPORTED_MODULE_6__["Diagnostic"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["AlertController"]
      }, {
        type: _ionic_native_geolocation_ngx__WEBPACK_IMPORTED_MODULE_8__["Geolocation"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["ToastController"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_11__["Router"]
      }];
    };

    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)], SearchbarPage.prototype, "ionInput", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])(_homepage_design_design_component__WEBPACK_IMPORTED_MODULE_13__["DesignComponent"], {
      "static": false
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _homepage_design_design_component__WEBPACK_IMPORTED_MODULE_13__["DesignComponent"])], SearchbarPage.prototype, "child", void 0);
    SearchbarPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-searchbar',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./searchbar.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/searchbar/searchbar.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./searchbar.page.scss */
      "./src/app/searchbar/searchbar.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_utilities_service__WEBPACK_IMPORTED_MODULE_2__["UtilitiesService"], _api_service__WEBPACK_IMPORTED_MODULE_3__["ApiService"], _ionic_native_native_geocoder_ngx__WEBPACK_IMPORTED_MODULE_9__["NativeGeocoder"], _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["Platform"], _angular_common__WEBPACK_IMPORTED_MODULE_4__["DatePipe"], _storage_service__WEBPACK_IMPORTED_MODULE_5__["StorageService"], _ionic_native_diagnostic_ngx__WEBPACK_IMPORTED_MODULE_6__["Diagnostic"], _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["AlertController"], _ionic_native_geolocation_ngx__WEBPACK_IMPORTED_MODULE_8__["Geolocation"], _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["ToastController"], _angular_router__WEBPACK_IMPORTED_MODULE_11__["Router"]])], SearchbarPage);
    /***/
  },

  /***/
  "./src/app/searchbar/survey/survey.component.scss":
  /*!********************************************************!*\
    !*** ./src/app/searchbar/survey/survey.component.scss ***!
    \********************************************************/

  /*! exports provided: default */

  /***/
  function srcAppSearchbarSurveySurveyComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".custom-card {\n  display: flex;\n  flex-direction: column;\n  background: white;\n  border-radius: 12px;\n  box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.3);\n}\n\n.customer-name {\n  font-size: 1.2em;\n  color: #434343;\n  font-weight: bold;\n}\n\n.customer-email {\n  font-size: 0.8em;\n  color: #B4B4B4;\n}\n\n.customer-phone {\n  font-size: 0.8em;\n  color: #4272B9;\n}\n\n.customer-address {\n  margin-top: 16px;\n  margin-bottom: 16px;\n  font-size: 0.8em;\n  color: #4272B9;\n}\n\n.timestamp {\n  font-size: 0.7em;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2VhcmNoYmFyL3N1cnZleS9GOlxcbW9iaWxlYXBwL3NyY1xcYXBwXFxzZWFyY2hiYXJcXHN1cnZleVxcc3VydmV5LmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9zZWFyY2hiYXIvc3VydmV5L3N1cnZleS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGFBQUE7RUFDQSxzQkFBQTtFQUNBLGlCQUFBO0VBQ0EsbUJBQUE7RUFDQSwwQ0FBQTtBQ0NKOztBREVFO0VBQ0UsZ0JBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7QUNDSjs7QURFRTtFQUNFLGdCQUFBO0VBQ0EsY0FBQTtBQ0NKOztBREVFO0VBQ0UsZ0JBQUE7RUFDQSxjQUFBO0FDQ0o7O0FERUU7RUFDRSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0FDQ0o7O0FETUU7RUFDRSxnQkFBQTtBQ0hKIiwiZmlsZSI6InNyYy9hcHAvc2VhcmNoYmFyL3N1cnZleS9zdXJ2ZXkuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY3VzdG9tLWNhcmQge1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgICBiYWNrZ3JvdW5kOiB3aGl0ZTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDEycHg7XHJcbiAgICBib3gtc2hhZG93OiAwIDFweCAycHggMCByZ2JhKDAsIDAsIDAsIDAuMyk7XHJcbiAgfVxyXG4gIFxyXG4gIC5jdXN0b21lci1uYW1lIHtcclxuICAgIGZvbnQtc2l6ZTogMS4yZW07XHJcbiAgICBjb2xvcjogIzQzNDM0MztcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gIH1cclxuICBcclxuICAuY3VzdG9tZXItZW1haWwge1xyXG4gICAgZm9udC1zaXplOiAwLjhlbTtcclxuICAgIGNvbG9yOiAjQjRCNEI0O1xyXG4gIH1cclxuICBcclxuICAuY3VzdG9tZXItcGhvbmUge1xyXG4gICAgZm9udC1zaXplOiAwLjhlbTtcclxuICAgIGNvbG9yOiAjNDI3MkI5O1xyXG4gIH1cclxuICBcclxuICAuY3VzdG9tZXItYWRkcmVzcyB7XHJcbiAgICBtYXJnaW4tdG9wOiAxNnB4O1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMTZweDtcclxuICAgIGZvbnQtc2l6ZTogMC44ZW07XHJcbiAgICBjb2xvcjogIzQyNzJCOTtcclxuICB9XHJcbiAgXHJcbiAgLnBsYWNlaG9sZGVyIHtcclxuICAgIC8vIHdpZHRoOiA1MHZ3ICFpbXBvcnRhbnQ7XHJcbiAgfVxyXG4gIFxyXG4gIC50aW1lc3RhbXAge1xyXG4gICAgZm9udC1zaXplOiAwLjdlbTtcclxuICB9IiwiLmN1c3RvbS1jYXJkIHtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgYmFja2dyb3VuZDogd2hpdGU7XG4gIGJvcmRlci1yYWRpdXM6IDEycHg7XG4gIGJveC1zaGFkb3c6IDAgMXB4IDJweCAwIHJnYmEoMCwgMCwgMCwgMC4zKTtcbn1cblxuLmN1c3RvbWVyLW5hbWUge1xuICBmb250LXNpemU6IDEuMmVtO1xuICBjb2xvcjogIzQzNDM0MztcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG59XG5cbi5jdXN0b21lci1lbWFpbCB7XG4gIGZvbnQtc2l6ZTogMC44ZW07XG4gIGNvbG9yOiAjQjRCNEI0O1xufVxuXG4uY3VzdG9tZXItcGhvbmUge1xuICBmb250LXNpemU6IDAuOGVtO1xuICBjb2xvcjogIzQyNzJCOTtcbn1cblxuLmN1c3RvbWVyLWFkZHJlc3Mge1xuICBtYXJnaW4tdG9wOiAxNnB4O1xuICBtYXJnaW4tYm90dG9tOiAxNnB4O1xuICBmb250LXNpemU6IDAuOGVtO1xuICBjb2xvcjogIzQyNzJCOTtcbn1cblxuLnRpbWVzdGFtcCB7XG4gIGZvbnQtc2l6ZTogMC43ZW07XG59Il19 */";
    /***/
  },

  /***/
  "./src/app/searchbar/survey/survey.component.ts":
  /*!******************************************************!*\
    !*** ./src/app/searchbar/survey/survey.component.ts ***!
    \******************************************************/

  /*! exports provided: SurveyComponent, SurveyDataHelper */

  /***/
  function srcAppSearchbarSurveySurveyComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SurveyComponent", function () {
      return SurveyComponent;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SurveyDataHelper", function () {
      return SurveyDataHelper;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var src_app_utilities_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! src/app/utilities.service */
    "./src/app/utilities.service.ts");
    /* harmony import */


    var src_app_api_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! src/app/api.service */
    "./src/app/api.service.ts");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @ionic-native/launch-navigator/ngx */
    "./node_modules/@ionic-native/launch-navigator/ngx/index.js");
    /* harmony import */


    var ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ion-bottom-drawer */
    "./node_modules/ion-bottom-drawer/fesm2015/ion-bottom-drawer.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var src_app_storage_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
    /*! src/app/storage.service */
    "./src/app/storage.service.ts");
    /* harmony import */


    var src_app_contants__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
    /*! src/app/contants */
    "./src/app/contants.ts");

    var SurveyComponent = /*#__PURE__*/function () {
      function SurveyComponent(utils, apiService, datePipe, navController, launchNavigator, formBuilder, cdr, router, route, storage) {
        _classCallCheck(this, SurveyComponent);

        this.utils = utils;
        this.apiService = apiService;
        this.datePipe = datePipe;
        this.navController = navController;
        this.launchNavigator = launchNavigator;
        this.formBuilder = formBuilder;
        this.cdr = cdr;
        this.router = router;
        this.route = route;
        this.storage = storage;
        this.listOfSurveyData = [];
        this.listOfSurveyDataHelper = [];
        this.options = {
          start: '',
          app: this.launchNavigator.APP.GOOGLE_MAPS
        };
        this.drawerState = ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_7__["DrawerState"].Bottom;
        this.surveyId = 0;
        this.listOfAssignees = [];
        var latestDate = new Date();
        this.today = datePipe.transform(latestDate, 'M/dd/yy');
        console.log('date', this.today);
        this.assignForm = this.formBuilder.group({
          assignedto: new _angular_forms__WEBPACK_IMPORTED_MODULE_8__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_8__["Validators"].required]),
          status: new _angular_forms__WEBPACK_IMPORTED_MODULE_8__["FormControl"]('surveyassigned', [_angular_forms__WEBPACK_IMPORTED_MODULE_8__["Validators"].required])
        });
      }

      _createClass(SurveyComponent, [{
        key: "ionViewDidEnter",
        value: function ionViewDidEnter() {
          // this.routeSubscription.unsubscribe();
          this.getSurveys(null);
        } // ngOnInit() {
        //   this.surveyRefreshSubscription = this.utils.getHomepageSurveyRefresh().subscribe((result) => {
        //     this.getSurvey();
        //   });
        // }

      }, {
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this15 = this;

          this.filterData(this.filterDataArray);
          this.routeSubscription = this.router.events.subscribe(function (event) {
            console.log("//", event);
            console.log(_this15.router.url.indexOf('page'));

            if (event instanceof _angular_router__WEBPACK_IMPORTED_MODULE_9__["NavigationEnd"]) {
              console.log(event.url); // Trick the Router into believing it's last link wasn't previously loaded

              if (_this15.router.url.indexOf('page') >= -1) {
                _this15.router.navigated = false;

                var data = _this15.route.queryParams.subscribe(function (_res) {
                  console.log('Serach Term', _res);

                  if (Object.keys(_res).length !== 0) {
                    //  this.ApplysearchDesginAndSurvey(_res.serchTerm)
                    _this15.filterData(_res.serchTerm);
                  } else {// this.surveyRefreshSubscription = this.utils.getHomepageSurveyRefresh().subscribe((result) => {
                    // this.getSurveys(null);
                    // });
                  }
                });
              }
            }
          }); // console.log('inside init');
          // this.routeSubscription = this.router.events.subscribe((event) => {
          //   if (event instanceof NavigationEnd) {
          //     // Trick the Router into believing it's last link wasn't previously loaded
          //     if (this.router.url.indexOf('page') > -1) {
          //       this.router.navigated = false;
          //       const data = this.route.queryParams.subscribe((_res: any) => {
          //         console.log('Search Term', _res);
          //         if (Object.keys(_res).length !== 0) {
          //           //  this.ApplysearchDesginAndSurvey(_res.serchTerm)
          //           this.filterData(_res.serchTerm);
          //         } else {
          //           this.surveyRefreshSubscription = this.utils.getHomepageSurveyRefresh().subscribe((result) => {
          //             this.getSurveys(null);
          //           });
          //         }
          //       });
          //     }
          //   }
          // });
          // this.getSurveys(null);
        }
      }, {
        key: "filterData",
        value: function filterData(serchTerm) {
          var _this16 = this;

          console.log(this.listOfSurveyData);
          this.filterDataArray = this.listOfSurveyData.filter(function (x) {
            return x.id == serchTerm;
          });
          var tempData = [];
          this.filterDataArray.forEach(function (surveyItem) {
            if (tempData.length === 0) {
              var listOfSurvey = new SurveyDataHelper();
              listOfSurvey.date = _this16.datePipe.transform(surveyItem.created_at, 'M/d/yy');
              listOfSurvey.listOfSurveys.push(surveyItem);
              tempData.push(listOfSurvey);
            } else {
              var added = false;
              tempData.forEach(function (surveyList) {
                if (!added) {
                  if (surveyList.date === _this16.datePipe.transform(surveyItem.created_at, 'M/d/yy')) {
                    surveyList.listOfSurveys.push(surveyItem);
                    added = true;
                  }
                }
              });

              if (!added) {
                var _listOfSurvey = new SurveyDataHelper();

                _listOfSurvey.date = _this16.datePipe.transform(surveyItem.created_at, 'M/d/yy');

                _listOfSurvey.listOfSurveys.push(surveyItem);

                tempData.push(_listOfSurvey);
                added = true;
              }
            }
          });
          this.listOfSurveyDataHelper = tempData;
          this.cdr.detectChanges();
        }
      }, {
        key: "ngOnDestroy",
        value: function ngOnDestroy() {
          this.surveyRefreshSubscription.unsubscribe();
        }
      }, {
        key: "getSurvey",
        value: function getSurvey(event, showLoader) {
          var _this17 = this;

          this.listOfSurveyData = [];
          this.listOfSurveyDataHelper = [];
          this.utils.showLoadingWithPullRefreshSupport(showLoader, 'Getting Surveys').then(function (success) {
            _this17.apiService.getSurvey().subscribe(function (response) {
              _this17.utils.hideLoadingWithPullRefreshSupport(showLoader).then(function () {
                if (event !== null) {
                  event.target.complete();
                }

                console.log(response);
                _this17.listOfSurveyData = response;
                var tempData = [];

                _this17.listOfSurveyData.forEach(function (surveyItem) {
                  if (tempData.length === 0) {
                    var listOfSurvey = new SurveyDataHelper();
                    listOfSurvey.date = _this17.datePipe.transform(surveyItem.datetime, 'M/d/yy');
                    listOfSurvey.listOfSurveys.push(surveyItem);
                    tempData.push(listOfSurvey);
                  } else {
                    var added = false;
                    tempData.forEach(function (surveyList) {
                      if (!added) {
                        if (surveyList.date === _this17.datePipe.transform(surveyItem.datetime, 'M/d/yy')) {
                          surveyList.listOfSurveys.push(surveyItem);
                          added = true;
                        }
                      }
                    });

                    if (!added) {
                      var _listOfSurvey2 = new SurveyDataHelper();

                      _listOfSurvey2.date = _this17.datePipe.transform(surveyItem.datetime, 'M/d/yy');

                      _listOfSurvey2.listOfSurveys.push(surveyItem);

                      tempData.push(_listOfSurvey2);
                      added = true;
                    }
                  }
                });

                _this17.listOfSurveyDataHelper = tempData;

                _this17.cdr.detectChanges();
              });
            }, function (responseError) {
              _this17.utils.hideLoadingWithPullRefreshSupport(showLoader).then(function () {
                if (event !== null) {
                  event.target.complete();
                }

                var error = responseError.error;

                _this17.utils.errorSnackBar(error.message[0].messages[0].message);
              });
            });
          });
        }
      }, {
        key: "getSurveyorSurveys",
        value: function getSurveyorSurveys(event, showLoader) {
          var _this18 = this;

          this.listOfSurveyData = [];
          this.listOfSurveyDataHelper = [];
          this.utils.showLoadingWithPullRefreshSupport(showLoader, 'Getting Surveys').then(function (success) {
            _this18.apiService.getSurveyorSurveys("").subscribe(function (response) {
              _this18.utils.hideLoadingWithPullRefreshSupport(showLoader).then(function () {
                if (event !== null) {
                  event.target.complete();
                }

                console.log(response);
                _this18.listOfSurveyData = response;
                var tempData = [];

                _this18.listOfSurveyData.forEach(function (surveyItem) {
                  if (tempData.length === 0) {
                    var listOfSurvey = new SurveyDataHelper();
                    listOfSurvey.date = _this18.datePipe.transform(surveyItem.datetime, 'M/d/yy');
                    listOfSurvey.listOfSurveys.push(surveyItem);
                    tempData.push(listOfSurvey);
                  } else {
                    var added = false;
                    tempData.forEach(function (surveyList) {
                      if (!added) {
                        if (surveyList.date === _this18.datePipe.transform(surveyItem.datetime, 'M/d/yy')) {
                          surveyList.listOfSurveys.push(surveyItem);
                          added = true;
                        }
                      }
                    });

                    if (!added) {
                      var _listOfSurvey3 = new SurveyDataHelper();

                      _listOfSurvey3.date = _this18.datePipe.transform(surveyItem.datetime, 'M/d/yy');

                      _listOfSurvey3.listOfSurveys.push(surveyItem);

                      tempData.push(_listOfSurvey3);
                      added = true;
                    }
                  }
                });

                _this18.listOfSurveyDataHelper = tempData;

                _this18.cdr.detectChanges();
              });
            }, function (responseError) {
              _this18.utils.hideLoadingWithPullRefreshSupport(showLoader).then(function () {
                if (event !== null) {
                  event.target.complete();
                }

                var error = responseError.error;

                _this18.utils.errorSnackBar(error.message[0].messages[0].message);
              });
            });
          });
        }
      }, {
        key: "openAddressOnMap",
        value: function openAddressOnMap(address) {
          this.launchNavigator.navigate(address, this.options);
        }
      }, {
        key: "dismissBottomSheet",
        value: function dismissBottomSheet() {
          this.drawerState = ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_7__["DrawerState"].Bottom;
          this.utils.setBottomBarHomepage(true);
        }
      }, {
        key: "assignToSurveyor",
        value: function assignToSurveyor() {
          var _this19 = this;

          if (this.assignForm.status === 'INVALID') {
            this.utils.errorSnackBar('Please select a surveyor');
          } else {
            this.apiService.updateSurveyForm(this.assignForm.value, this.surveyId).subscribe(function (value) {
              _this19.dismissBottomSheet();

              _this19.utils.sethomepageSurveyRefresh(true);
            }, function (error) {
              _this19.dismissBottomSheet();
            });
          }
        }
      }, {
        key: "openSurveyors",
        value: function openSurveyors(id) {
          var _this20 = this;

          this.utils.showLoading('Getting Surveyors').then(function () {
            _this20.apiService.getSurveyors().subscribe(function (assignees) {
              _this20.utils.hideLoading().then(function () {
                _this20.listOfAssignees = [];
                assignees.forEach(function (item) {
                  return _this20.listOfAssignees.push(item);
                });
                _this20.surveyId = id;

                _this20.utils.setBottomBarHomepage(false);

                _this20.drawerState = ion_bottom_drawer__WEBPACK_IMPORTED_MODULE_7__["DrawerState"].Docked;
                console.log(_this20.listOfAssignees);

                _this20.assignForm.patchValue({
                  assignedto: 0
                });
              });
            }, function (error) {
              _this20.utils.hideLoading().then(function () {
                _this20.utils.errorSnackBar('Some error occurred. Please try again later');
              });
            });
          });
        }
      }, {
        key: "getSurveys",
        value: function getSurveys(event) {
          var showLoader = true;

          if (event != null && event !== undefined) {
            showLoader = false;
          }

          if (this.storage.getUser().role.id === src_app_contants__WEBPACK_IMPORTED_MODULE_11__["ROLES"].Surveyor) {
            this.getSurveyorSurveys(event, showLoader);
          } else {
            this.getSurvey(event, showLoader);
          }
        }
      }]);

      return SurveyComponent;
    }();

    SurveyComponent.ctorParameters = function () {
      return [{
        type: src_app_utilities_service__WEBPACK_IMPORTED_MODULE_2__["UtilitiesService"]
      }, {
        type: src_app_api_service__WEBPACK_IMPORTED_MODULE_3__["ApiService"]
      }, {
        type: _angular_common__WEBPACK_IMPORTED_MODULE_4__["DatePipe"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["NavController"]
      }, {
        type: _ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_6__["LaunchNavigator"]
      }, {
        type: _angular_forms__WEBPACK_IMPORTED_MODULE_8__["FormBuilder"]
      }, {
        type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_9__["Router"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_9__["ActivatedRoute"]
      }, {
        type: src_app_storage_service__WEBPACK_IMPORTED_MODULE_10__["StorageService"]
      }];
    };

    SurveyComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-survey',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./survey.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/searchbar/survey/survey.component.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./survey.component.scss */
      "./src/app/searchbar/survey/survey.component.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_utilities_service__WEBPACK_IMPORTED_MODULE_2__["UtilitiesService"], src_app_api_service__WEBPACK_IMPORTED_MODULE_3__["ApiService"], _angular_common__WEBPACK_IMPORTED_MODULE_4__["DatePipe"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["NavController"], _ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_6__["LaunchNavigator"], _angular_forms__WEBPACK_IMPORTED_MODULE_8__["FormBuilder"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"], _angular_router__WEBPACK_IMPORTED_MODULE_9__["Router"], _angular_router__WEBPACK_IMPORTED_MODULE_9__["ActivatedRoute"], src_app_storage_service__WEBPACK_IMPORTED_MODULE_10__["StorageService"]])], SurveyComponent);

    var SurveyDataHelper = function SurveyDataHelper() {
      _classCallCheck(this, SurveyDataHelper);

      this.listOfSurveys = [];
    };
    /***/

  }
}]);
//# sourceMappingURL=searchbar-searchbar-module-es5.js.map